<?php
session_start();
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>سیستم طراحی برگه امتحان – حرفه‌ای</title>

  <!-- فونت‌ها -->
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;600;700&family=Shabnam:wght@400;700&family=Estedad:wght@400;600;700&display=swap" rel="stylesheet">
  
  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- html2canvas + jsPDF -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  
  <!-- jQuery for AJAX -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <style>
    html { scroll-behavior: smooth; }

    /* استایل مدال فرمول */
    .math-modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.6);
      animation: fadeIn 0.2s ease;
      backdrop-filter: blur(4px);
    }
    
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    .math-modal-content {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      margin: 3% auto;
      padding: 2px;
      border-radius: 20px;
      width: 90%;
      max-width: 700px;
      max-height: 85vh;
      overflow: hidden;
      animation: slideDown 0.3s ease;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    }

    .math-modal-inner {
      background: white;
      border-radius: 18px;
      padding: 25px;
      max-height: 85vh;
      overflow-y: auto;
    }
    
    @keyframes slideDown {
      from { transform: translateY(-50px) scale(0.9); opacity: 0; }
      to { transform: translateY(0) scale(1); opacity: 1; }
    }
    
    .math-preview {
      background: linear-gradient(135deg, #f9fafb 0%, #e5e7eb 100%);
      border: 3px solid #667eea;
      border-radius: 12px;
      padding: 20px;
      margin: 15px 0;
      min-height: 60px;
      font-size: 20px;
      text-align: center;
      box-shadow: inset 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .math-category {
      background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
      border-radius: 12px;
      padding: 15px;
      margin: 12px 0;
    }

    .math-category-title {
      font-weight: bold;
      font-size: 16px;
      color: #4b5563;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .math-button {
      padding: 10px 16px;
      margin: 6px 4px;
      border: 2px solid #667eea;
      border-radius: 10px;
      background: white;
      cursor: pointer;
      font-size: 16px;
      transition: all 0.2s;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .math-button:hover {
      background: #667eea;
      color: white;
      transform: translateY(-3px);
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }

    .math-button:active {
      transform: translateY(-1px);
    }

    /* استایل ویرایشگر RTL */
    [contenteditable="true"] {
      direction: rtl !important;
      text-align: right !important;
      unicode-bidi: plaintext !important;
    }
    
    [contenteditable="true"]:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
    }

    /* استایل تنظیم اندازه تصویر */
    .image-size-control {
      position: absolute;
      bottom: -35px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(102, 126, 234, 0.95);
      color: white;
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 12px;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.2s;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .image-container:hover .image-size-control {
      opacity: 1;
    }

    /* استایل‌های چاپ */
    @media print {
      @page {
        size: A4 portrait;
        margin: 10mm;
      }

      body > *:not(#print-area) {
        display: none !important;
      }

      body, html {
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        color: #000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      
      #print-area, #print-content {
        margin: 0 !important;
        padding: 0 !important;
        background: none !important;
      }
      
      #print-content .page {
        width: 190mm !important;
        height: 277mm !important;
        box-sizing: border-box !important;
        margin: 0 !important;
        padding: 6mm !important;
        box-shadow: none !important;
        border-radius: 0 !important;
        display: block !important;
        page-break-after: always;
        page-break-inside: avoid;
        overflow: hidden !important;
        position: relative !important;
      }

      #print-content .page:last-child {
        page-break-after: auto;
      }

      #print-content .question {
        page-break-inside: avoid !important;
        margin-bottom: 3mm !important;
      }
      
      #print-content .page-num {
        position: absolute !important;
        bottom: 5mm !important;
        left: 50% !important;
        transform: translateX(-50%) !important;
        z-index: 1000 !important;
      }
      
      #print-content .school {
        letter-spacing: normal !important;
        font-variant-ligatures: normal !important;
        font-feature-settings: "liga" 1, "curs" 1 !important;
      }
    }

    /* انیمیشن‌ها */
    .fade-in {
      animation: fadeIn 0.3s ease;
    }
    
    .slide-up {
      animation: slideUp 0.3s ease;
    }
    
    @keyframes slideUp {
      from { transform: translateY(20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    
    .toolbar-btn {
      transition: all 0.2s;
    }
    
    .toolbar-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    .toolbar-btn:active {
      transform: translateY(0);
    }

    .question-card {
      transition: all 0.3s;
    }
    
    .question-card:hover {
      box-shadow: 0 8px 16px rgba(102, 126, 234, 0.2);
      transform: translateY(-2px);
    }

    .dropdown-menu {
      animation: slideDown 0.2s ease;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    }

    @media (max-width: 768px) {
      .math-modal-content {
        width: 95%;
        margin: 10% auto;
      }
    }
  </style>
</head>

<body class="bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
  <div id="root"></div>

  <!-- مدال فرمول ریاضی حرفه‌ای -->
  <div id="mathModal" class="math-modal">
    <div class="math-modal-content">
      <div class="math-modal-inner">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <h3 style="font-size: 24px; font-weight: bold; color: #667eea; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 32px;">🧮</span>
            <span>افزودن فرمول ریاضی</span>
          </h3>
          <button onclick="closeMathModal()" style="font-size: 28px; border: none; background: #f3f4f6; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; transition: all 0.2s;" onmouseover="this.style.background='#e5e7eb'" onmouseout="this.style.background='#f3f4f6'">&times;</button>
        </div>
        
        <div class="math-preview" id="mathPreview">✨ پیش‌نمایش فرمول شما اینجا نمایش داده می‌شود</div>
        
        <div class="math-category">
          <div class="math-category-title">
            <span style="font-size: 20px;">➗</span>
            <span>کسرها</span>
          </div>
          <button class="math-button" onclick="insertMath('\\frac{}{}')">کسر (صورت/مخرج)</button>
          <button class="math-button" onclick="insertMath('\\frac{1}{2}')">یک دوم (½)</button>
          <button class="math-button" onclick="insertMath('\\frac{1}{3}')">یک سوم (⅓)</button>
          <button class="math-button" onclick="insertMath('\\frac{1}{4}')">یک چهارم (¼)</button>
          <button class="math-button" onclick="insertMath('\\frac{3}{4}')">سه چهارم (¾)</button>
        </div>

        <div class="math-category">
          <div class="math-category-title">
            <span style="font-size: 20px;">📐</span>
            <span>توان و جذر</span>
          </div>
          <button class="math-button" onclick="insertMath('^{2}')">توان دو (²)</button>
          <button class="math-button" onclick="insertMath('^{3}')">توان سه (³)</button>
          <button class="math-button" onclick="insertMath('^{}')">&nbsp;توان (xⁿ)</button>
          <button class="math-button" onclick="insertMath('\\sqrt{}')">جذر (√)</button>
          <button class="math-button" onclick="insertMath('\\sqrt[3]{}')">جذر سوم (∛)</button>
          <button class="math-button" onclick="insertMath('\\sqrt[n]{}')">جذر nام</button>
        </div>

        <div class="math-category">
          <div class="math-category-title">
            <span style="font-size: 20px;">➕</span>
            <span>علامت‌های ریاضی</span>
          </div>
          <button class="math-button" onclick="insertMath('\\times')">ضرب (×)</button>
          <button class="math-button" onclick="insertMath('\\div')">تقسیم (÷)</button>
          <button class="math-button" onclick="insertMath('\\pm')">مثبت منفی (±)</button>
          <button class="math-button" onclick="insertMath('\\neq')">مساوی نیست (≠)</button>
          <button class="math-button" onclick="insertMath('\\leq')">کوچکتر مساوی (≤)</button>
          <button class="math-button" onclick="insertMath('\\geq')">بزرگتر مساوی (≥)</button>
          <button class="math-button" onclick="insertMath('\\approx')">تقریباً (≈)</button>
          <button class="math-button" onclick="insertMath('\\infty')">بی‌نهایت (∞)</button>
        </div>

        <div class="math-category">
          <div class="math-category-title">
            <span style="font-size: 20px;">📝</span>
            <span>ویرایش دستی فرمول</span>
          </div>
          <textarea id="mathInput" style="width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px; font-family: monospace; min-height: 100px; direction: ltr; font-size: 14px;" placeholder="مثال: x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}"></textarea>
          <div style="margin-top: 8px; font-size: 12px; color: #6b7280;">
            💡 نکته: برای نوشتن فرمول از دستورات LaTeX استفاده کنید
          </div>
        </div>

        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 25px;">
          <button onclick="closeMathModal()" class="toolbar-btn" style="padding: 12px 24px; border: 2px solid #e5e7eb; border-radius: 10px; background: white; cursor: pointer; font-weight: bold;">انصراف</button>
          <button onclick="applyMathFormula()" class="toolbar-btn" style="padding: 12px 24px; border: none; border-radius: 10px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; cursor: pointer; font-weight: bold; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);">✓ اعمال فرمول</button>
        </div>
      </div>
    </div>
  </div>

  <!-- React -->
  <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  
  <script type="text/babel">
    const {useState, useEffect, useRef} = React;

    // تشخیص مسیر پایه برای AJAX
    const getBasePath = () => {
      const path = window.location.pathname;
      return path.substring(0, path.lastIndexOf('/') + 1);
    };
    const AJAX_BASE = getBasePath();

    window.currentMathSectionId = null;
    window.currentMathQuestionId = null;
    window.mathUpdateCallback = null;

    window.openMathModal = (sectionId, questionId, currentText, callback) => {
      window.currentMathSectionId = sectionId;
      window.currentMathQuestionId = questionId;
      window.mathUpdateCallback = callback;
      document.getElementById('mathInput').value = '';
      document.getElementById('mathPreview').innerHTML = renderMathPreview('');
      document.getElementById('mathModal').style.display = 'block';
    };

    window.closeMathModal = () => {
      document.getElementById('mathModal').style.display = 'none';
      window.currentMathSectionId = null;
      window.currentMathQuestionId = null;
      window.mathUpdateCallback = null;
    };

    window.insertMath = (formula) => {
      const input = document.getElementById('mathInput');
      const cursorPos = input.selectionStart;
      const textBefore = input.value.substring(0, cursorPos);
      const textAfter = input.value.substring(cursorPos);
      input.value = textBefore + formula + textAfter;
      document.getElementById('mathPreview').innerHTML = renderMathPreview(input.value);
      const newPos = cursorPos + formula.length;
      input.setSelectionRange(newPos, newPos);
      input.focus();
    };

    window.applyMathFormula = () => {
      const formula = document.getElementById('mathInput').value;
      if (window.mathUpdateCallback) {
        window.mathUpdateCallback(formula);
      }
      window.closeMathModal();
    };

    window.renderMathPreview = (latex) => {
      if (!latex) return '✨ پیش‌نمایش فرمول شما اینجا نمایش داده می‌شود';
      let preview = latex
        .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '<sup>$1</sup>/<sub>$2</sub>')
        .replace(/\\sqrt\{([^}]+)\}/g, '√<span style="text-decoration:overline;padding:0 4px;">$1</span>')
        .replace(/\\sqrt\[(\d+)\]\{([^}]+)\}/g, '<sup>$1</sup>√<span style="text-decoration:overline;padding:0 4px;">$2</span>')
        .replace(/\^{([^}]+)}/g, '<sup>$1</sup>')
        .replace(/\\times/g, '×')
        .replace(/\\div/g, '÷')
        .replace(/\\pm/g, '±')
        .replace(/\\neq/g, '≠')
        .replace(/\\leq/g, '≤')
        .replace(/\\geq/g, '≥')
        .replace(/\\approx/g, '≈')
        .replace(/\\infty/g, '∞');
      return preview || latex;
    };

    $(document).ready(function() {
      $('#mathInput').on('input', function() {
        $('#mathPreview').html(renderMathPreview($(this).val()));
      });
    });

    const faDigits = s => (s==null? "" : String(s).replace(/\d/g, d=>"۰۱۲۳۴۵۶۷۸۹"[+d]));
    const toFaNum = n => faDigits(n);

    const FONTS = {
      vazir:   { label:"وزیرمتن", css:"'Vazirmatn', sans-serif" },
      shabnam: { label:"شبنم",    css:"'Shabnam', sans-serif" },
      ustedad: { label:"استعداد", css:"'Estedad', sans-serif" },
      samim:   { label:"صمیم",    css:"'Samim', sans-serif" },
      sahel:   { label:"ساحل",    css:"'Sahel', sans-serif" },
      mardoto: { label:"مرتو",    css:"'Mardoto', sans-serif" },
    };

    const THEMES = {
      purple:{name:"بنفش", header:"linear-gradient(135deg,#667eea 0%,#764ba2 100%)", section:"linear-gradient(135deg,#667eea 0%,#764ba2 100%)"},
      blue:  {name:"آبی",   header:"linear-gradient(135deg,#4facfe 0%,#00f2fe 100%)", section:"linear-gradient(135deg,#4facfe 0%,#00f2fe 100%)"},
      pink:  {name:"صورتی", header:"linear-gradient(135deg,#f093fb 0%,#f5576c 100%)", section:"linear-gradient(135deg,#f093fb 0%,#f5576c 100%)"},
      neutral:{name:"ساده", header:"#f3f4f6", section:"#f3f4f6"},
    };

    const BORDER_STYLES = {
      solid:  {name:"ساده", css:"4px solid"},
      double: {name:"دوخطی", css:"6px double"},
      dashed: {name:"خط‌چین", css:"4px dashed"},
      dotted: {name:"نقطه‌چین", css:"4px dotted"},
      rainbow:{name:"رنگین‌کمان", css:"rainbow"},
    };

    const DENSITY = {
      compact: {name:"فشرده", padding:6, spacing:6, perPage:7},
      normal:  {name:"عادی",  padding:8, spacing:8, perPage:5},
      relaxed: {name:"راحت",  padding:12, spacing:12, perPage:4},
    };

    const FONT_SIZES = {
      '14': {question:14, option:12, header:16},
      '15': {question:15, option:13, header:17},
      '16': {question:16, option:14, header:18},
      '17': {question:17, option:15, header:19},
      '18': {question:18, option:15, header:20},
      '19': {question:19, option:16, header:21},
      '20': {question:20, option:17, header:22},
      '21': {question:21, option:18, header:23},
      '22': {question:22, option:18, header:24},
      '23': {question:23, option:19, header:25},
      '24': {question:24, option:20, header:26},
      '25': {question:25, option:21, header:27},
      '26': {question:26, option:22, header:28},
      '27': {question:27, option:22, header:29},
      '28': {question:28, option:23, header:30},
      '29': {question:29, option:24, header:31},
      '30': {question:30, option:25, header:32},
    };

    const loadGlobal = ()=>JSON.parse(localStorage.getItem("examGlobalSettings")||"{}");
    const saveGlobal = g => localStorage.setItem("examGlobalSettings", JSON.stringify(g));

    // کامپوننت ویرایشگر متن با پشتیبانی از فونت و سایز اختصاصی
    const RichTextEditor = ({sectionId, questionId, value, onChange, questionFontSize, questionFontFamily, onFontSizeChange, onFontFamilyChange}) => {
      const editorRef = useRef(null);
      const [initialized, setInitialized] = useState(false);

      useEffect(() => {
        if (editorRef.current && value && !initialized) {
          editorRef.current.innerHTML = value;
          setInitialized(true);
        }
      }, [value, initialized]);

      const handleFormat = (command, val = null) => {
        document.execCommand(command, false, val);
        if (editorRef.current) {
          onChange(editorRef.current.innerHTML);
        }
      };

      const handleInput = () => {
        if (editorRef.current) {
          onChange(editorRef.current.innerHTML);
        }
      };

      // اندازه فونت برای نمایش در ویرایشگر
      const editorFontSize = questionFontSize ? `${questionFontSize}px` : '14px';
      const editorFontFamily = questionFontFamily ? FONTS[questionFontFamily]?.css : FONTS.vazir.css;

      return (
        <div className="border-2 rounded-xl overflow-hidden" style={{borderColor: '#e5e7eb'}}>
          <div className="bg-gray-50 p-2 border-b flex items-center gap-2 flex-wrap">
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('bold')} title="بولد"><b>B</b></button>
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('italic')} title="ایتالیک"><i>I</i></button>
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('underline')} title="زیرخط"><u>U</u></button>
            
            <div className="border-r h-6 mx-1"></div>
            
            {/* فونت اختصاصی سوال */}
            <select 
              className="px-2 py-1 border rounded bg-white text-sm" 
              value={questionFontFamily || 'vazir'}
              onChange={(e) => onFontFamilyChange(e.target.value)}
              title="فونت سوال"
            >
              {Object.entries(FONTS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
            </select>
            
            {/* سایز فونت اختصاصی سوال */}
            <select 
              className="px-2 py-1 border rounded bg-white text-sm" 
              value={questionFontSize || '14'}
              onChange={(e) => onFontSizeChange(e.target.value)}
              title="سایز فونت سوال"
            >
              {Object.keys(FONT_SIZES).map(size => <option key={size} value={size}>{size} pt</option>)}
            </select>
            
            <div className="border-r h-6 mx-1"></div>
            
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('justifyRight')} title="راست‌چین">⫸</button>
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('justifyCenter')} title="وسط‌چین">↔</button>
            <button type="button" className="toolbar-btn px-3 py-1 border rounded bg-white hover:bg-gray-100" onClick={() => handleFormat('justifyLeft')} title="چپ‌چین">⫷</button>
          </div>
          <div 
            ref={editorRef} 
            contentEditable={true} 
            dir="rtl" 
            className="p-3 min-h-[80px] focus:outline-none" 
            style={{
              fontFamily: editorFontFamily, 
              fontSize: editorFontSize, 
              direction: 'rtl', 
              textAlign: 'right', 
              unicodeBidi: 'plaintext'
            }} 
            onInput={handleInput} 
            onPaste={(e) => {
              e.preventDefault(); 
              const text = e.clipboardData.getData('text/plain'); 
              document.execCommand('insertText', false, text);
            }}
          />
        </div>
      );
    };

    function App(){
      const [global, setGlobal] = useState(()=>({logo:"", logoScale:100, headerRounded:24, ...loadGlobal()}));
      const [info, setInfo] = useState({examName:"", schoolName:"دبستان پسرانه فرزانه ۳", examTitle:"ارزشیابی (دوره دوم)", grade:"چهارم", subject:"ریاضی", duration:"۶۰", totalScore:"۲۰", showDate:true, showName:true, showClass:true, showScore:true, showTeacher:true, teacherName:""});
      const [style, setStyle] = useState({theme:"purple", fontFamily:"vazir", fontSize:"14", borderStyle:"double", headerTextColor:"#ffffff", pageBg:"#ffffff", boxBg:"#ffffff", boxText:"#2d3748", boxBorder:"#667eea", fieldLine:"#222222", density:"normal"});
      const [sections, setSections] = useState([{id:1, title:"بخش ریاضی", icon:"📐", titleFont:"vazir", titleColor:"#ffffff", titleBg:"#667eea", questions:[]}]);
      const [view, setView] = useState("create");
      const [showSettings, setShowSettings] = useState(true);
      const [preview, setPreview] = useState(false);
      const [saved, setSaved] = useState([]);
      const [busyPdf, setBusyPdf] = useState(false);
      const [menuFor, setMenuFor] = useState(null);

      useEffect(()=>{ loadSavedExams(); }, []);
      useEffect(()=>{ saveGlobal(global); }, [global]);

      const loadSavedExams = () => {
        $.ajax({
          url: AJAX_BASE + 'ajax/exam_ajax.php', 
          type: 'POST', 
          data: { action: 'get_all' }, 
          dataType: 'json', 
          success: function(response) {
            if (response.success) {
              setSaved(response.data);
            }
          }, 
          error: function(xhr, status, error) {
            console.log('در حال بارگذاری آزمون‌ها...');
          }
        });
      };

      const updSection = (sid, fn)=> setSections(sections.map(s=>s.id===sid?fn({...s}):s));
      const addSection = ()=> setSections([...sections, {id:Date.now(), title:"بخش جدید", icon:"📝", titleFont:"vazir", titleColor:"#ffffff", titleBg:"#4b5563", questions:[]}]);
      const delSection = sid=>{if(sections.length===1) return alert("حداقل یک بخش لازم است"); setSections(sections.filter(s=>s.id!==sid));};
      
      // افزودن سوال با فونت و سایز پیش‌فرض
      const addQ = (sid, type="multiple")=>{
        updSection(sid, s=>{
          s.questions.push({
            id:Date.now(), 
            type, 
            text:"", 
            score:1, 
            images:[], 
            imageLayout:"horizontal", 
            imageAlignment:"center", 
            nextImageWidth: '150px', 
            imageUploadMode: 'custom',
            // فونت و سایز اختصاصی سوال
            questionFontSize: style.fontSize,
            questionFontFamily: style.fontFamily,
            ...(type==="multiple"?{options:["","","",""]}:{}), 
            ...(type==="descriptive"?{answerLines:3}:{})
          }); 
          return s;
        }); 
        setMenuFor(null);
      };
      
      const delQ = (sid,qid)=>updSection(sid, s=>{ s.questions=s.questions.filter(q=>q.id!==qid); return s; });
      const updQ = (sid,qid,f,v)=>updSection(sid, s=>{ s.questions=s.questions.map(q=>q.id===qid?{...q,[f]:v}:q); return s; });

      // آپلود لوگو - اصلاح شده
      const onUploadLogo = e => {
        const f = e.target.files?.[0]; 
        if (!f) return; 
        
        // بررسی نوع فایل
        if (!f.type.startsWith('image/')) {
          alert('لطفاً فقط فایل تصویری انتخاب کنید.');
          return;
        }
        
        // بررسی حجم فایل (حداکثر 5MB)
        if (f.size > 5 * 1024 * 1024) {
          alert('حجم فایل نباید بیشتر از 5 مگابایت باشد.');
          return;
        }
        
        const formData = new FormData(); 
        formData.append('logo', f); 
        
        $.ajax({
          url: AJAX_BASE + 'ajax/upload_logo.php', 
          type: 'POST', 
          data: formData, 
          processData: false, 
          contentType: false, 
          dataType: 'json',
          timeout: 10000, // 10 ثانیه timeout
          success: function(response) {
            if (response.success) {
              setGlobal(g => ({ ...g, logo: response.filePath })); 
              alert("✅ لوگو با موفقیت در سرور آپلود شد.");
            } else {
              alert('❌ خطا در آپلود لوگو: ' + response.message);
            }
          }, 
          error: function(xhr, status, error) {
            console.error('خطای آپلود:', status, error, xhr.responseText);
            
            // نمایش پیام خطای دقیق
            let errorMsg = 'خطای ارتباط با سرور.\n\n';
            if (xhr.status === 403) {
              errorMsg += '⚠️ خطای 403: دسترسی به فایل ajax/upload_logo.php ممنوع است.\n';
              errorMsg += 'لطفاً دسترسی پوشه ajax را بررسی کنید.';
            } else if (xhr.status === 404) {
              errorMsg += '⚠️ خطای 404: فایل ajax/upload_logo.php یافت نشد.\n';
              errorMsg += 'لطفاً مطمئن شوید پوشه ajax و فایل‌های آن روی سرور کپی شده‌اند.';
            } else if (xhr.status === 500) {
              errorMsg += '⚠️ خطای 500: خطای داخلی سرور.\n';
              errorMsg += 'لطفاً لاگ‌های سرور را بررسی کنید.';
            } else if (status === 'timeout') {
              errorMsg += '⚠️ زمان درخواست به پایان رسید.';
            } else {
              errorMsg += '⚠️ کد خطا: ' + xhr.status + '\n' + error;
            }
            
            // سوال از کاربر برای استفاده از حالت محلی
            if (confirm(errorMsg + '\n\n آیا می‌خواهید لوگو را به صورت موقت (محلی) اضافه کنید؟')) {
              const reader = new FileReader();
              reader.onload = function(event) {
                setGlobal(g => ({ ...g, logo: event.target.result }));
                alert("⚠️ لوگو به صورت موقت اضافه شد.\nتوجه: این لوگو فقط در این مرورگر ذخیره می‌شود و در صورت پاک کردن کش مرورگر از بین می‌رود.");
              };
              reader.readAsDataURL(f);
            }
          }
        }); 
        e.target.value = '';
      };
      
      // حذف لوگو - اصلاح شده
      const clearLogo = () => {
        const currentLogoPath = global.logo;
        if (!currentLogoPath) {
          return;
        }
        if (!confirm("آیا از حذف لوگو مطمئن هستید؟")) return;
        
        // اگر لوگو یک Data URL است، فقط از state حذف کن
        if (currentLogoPath.startsWith('data:')) {
          setGlobal(g => ({ ...g, logo: "" }));
          alert("لوگو با موفقیت حذف شد.");
          return;
        }
        
        const fileName = currentLogoPath.split('/').pop();
        $.ajax({
          url: AJAX_BASE + 'ajax/delete_logo.php',
          type: 'POST',
          data: JSON.stringify({ fileName: fileName }),
          contentType: 'application/json',
          dataType: 'json',
          success: function(response) {
            if (response.success) {
              setGlobal(g => ({ ...g, logo: "" }));
              alert("لوگو با موفقیت حذف شد.");
            } else {
              // در صورت خطا، باز هم از state حذف کن
              setGlobal(g => ({ ...g, logo: "" }));
              alert("لوگو حذف شد.");
            }
          },
          error: function(xhr, status, error) {
            // در صورت خطای سرور، فقط از state حذف کن
            setGlobal(g => ({ ...g, logo: "" }));
            alert("لوگو حذف شد.");
          }
        });
      };

      const uploadImg = (sid,qid,e)=>{
        const files=[...e.target.files]; 
        if(!files.length) return; 
        
        const section = sections.find(s => s.id === sid);
        const question = section.questions.find(q => q.id === qid);
        const mode = question.imageUploadMode || 'custom';
        const customWidth = parseInt(question.nextImageWidth) || 150;

        files.forEach(file=>{
            const r=new FileReader(); 
            r.onload = ev=> { 
                const imgSrc = ev.target.result;
                
                if (mode === 'actual') {
                    const img = new Image();
                    img.onload = () => {
                        updSection(sid, s=>{s.questions=s.questions.map(q=> q.id===qid?{...q, images:[...(q.images||[]), {src: imgSrc, width: `${img.naturalWidth}px`}]}:q); return s;});
                    };
                    img.src = imgSrc;
                } else {
                    let finalWidth = `${customWidth}px`;
                    if (mode === 'double') {
                        finalWidth = `${customWidth * 2}px`;
                    }
                    updSection(sid, s=>{s.questions=s.questions.map(q=> q.id===qid?{...q, images:[...(q.images||[]), {src: imgSrc, width: finalWidth}]}:q); return s;});
                }
            }; 
            r.readAsDataURL(file);
        }); 
        e.target.value="";
      };
      
      const rmImg = (sid,qid,ix)=>updSection(sid, s=>{s.questions=s.questions.map(q=> q.id===qid?{...q,images:q.images.filter((_,i)=>i!==ix)}:q); return s;});
      const updateImageWidth = (sid, qid, ix, newWidth) => {updSection(sid, s => {s.questions = s.questions.map(q => {if (q.id === qid) {const updatedImages = [...q.images]; updatedImages[ix] = { ...updatedImages[ix], width: newWidth }; return { ...q, images: updatedImages };} return q;}); return s;});};
      const resetAll = ()=>{if(!confirm("آیا می‌خواهید آزمون جدیدی ایجاد کنید؟ تمام تغییرات ذخیره نشده از بین خواهد رفت.")) return; setSections([{id:Date.now(), title:"بخش جدید", icon:"📝", titleFont:"vazir", titleColor:"#ffffff", titleBg:"#4b5563", questions:[]}]); setInfo({...info, examName:""});};
      
      // ذخیره آزمون - اصلاح شده با پشتیبانی از localStorage
      const saveExam = ()=>{
        if(!info.examName) return alert("لطفاً نام آزمون را وارد کنید"); 
        const data = {name: info.examName, subject: info.subject, info: info, style: style, global: global, sections: sections}; 
        
        $.ajax({
          url: AJAX_BASE + 'ajax/exam_ajax.php', 
          type: 'POST',
          data: { action: 'save', exam_data: JSON.stringify(data) },
          dataType: 'json', 
          success: function(response) {
            if (response.success) {
              alert("آزمون با موفقیت ذخیره شد"); 
              loadSavedExams();
            } else {
              alert("خطا در ذخیره‌سازی: " + response.message);
            }
          }, 
          error: function(xhr, status, error) {
            // ذخیره در localStorage به عنوان جایگزین
            try {
              const savedExams = JSON.parse(localStorage.getItem('savedExams') || '[]');
              const newId = Date.now().toString();
              
              // بررسی آزمون با نام یکسان
              const existingIndex = savedExams.findIndex(e => e.name === data.name);
              if (existingIndex >= 0) {
                savedExams[existingIndex] = {...data, id: savedExams[existingIndex].id};
              } else {
                savedExams.push({...data, id: newId});
              }
              
              localStorage.setItem('savedExams', JSON.stringify(savedExams));
              
              // بارگذاری مجدد لیست
              setSaved(savedExams.map(e => ({id: e.id, name: e.name, subject: e.subject})));
              
              alert("آزمون با موفقیت در حافظه محلی ذخیره شد");
            } catch (e) {
              alert("خطا در ذخیره‌سازی. لطفاً دوباره تلاش کنید.");
            }
          }
        });
      };
      
      // بارگذاری آزمون - اصلاح شده با پشتیبانی از localStorage
      const loadExam = (id)=>{
        $.ajax({
          url: AJAX_BASE + 'ajax/exam_ajax.php', 
          type: 'POST', 
          data: { action: 'get_one', id: id }, 
          dataType: 'json', 
          success: function(response) {
            if (response.success) {
              const x = response.data; 
              setInfo(x.info); 
              setStyle(x.style); 
              setSections(x.sections); 
              setGlobal(x.global || global); 
              setView("create"); 
              alert("آزمون با موفقیت بارگذاری شد");
            } else {
              alert("خطا در بارگذاری: " + response.message);
            }
          }, 
          error: function(xhr, status, error) {
            // بارگذاری از localStorage
            try {
              const savedExams = JSON.parse(localStorage.getItem('savedExams') || '[]');
              const exam = savedExams.find(e => e.id === id);
              if (exam) {
                setInfo(exam.info); 
                setStyle(exam.style); 
                setSections(exam.sections); 
                setGlobal(exam.global || global); 
                setView("create"); 
                alert("آزمون با موفقیت بارگذاری شد");
              } else {
                alert("آزمون یافت نشد.");
              }
            } catch (e) {
              alert("خطا در بارگذاری آزمون.");
            }
          }
        });
      };
      
      // حذف آزمون - اصلاح شده با پشتیبانی از localStorage
      const deleteExam = (id)=>{
        if(!confirm(`آیا از حذف این آزمون مطمئن هستید؟`)) return; 
        $.ajax({
          url: AJAX_BASE + 'ajax/exam_ajax.php', 
          type: 'POST', 
          data: { action: 'delete', id: id }, 
          dataType: 'json', 
          success: function(response) {
            if (response.success) {
              alert("آزمون با موفقیت حذف شد"); 
              loadSavedExams();
            } else {
              alert("خطا در حذف: " + response.message);
            }
          }, 
          error: function(xhr, status, error) {
            // حذف از localStorage
            try {
              const savedExams = JSON.parse(localStorage.getItem('savedExams') || '[]');
              const newExams = savedExams.filter(e => e.id !== id);
              localStorage.setItem('savedExams', JSON.stringify(newExams));
              setSaved(newExams.map(e => ({id: e.id, name: e.name, subject: e.subject})));
              alert("آزمون با موفقیت حذف شد");
            } catch (e) {
              alert("خطا در حذف آزمون.");
            }
          }
        });
      };

      // بارگذاری اولیه از localStorage
      useEffect(() => {
        try {
          const savedExams = JSON.parse(localStorage.getItem('savedExams') || '[]');
          if (savedExams.length > 0) {
            setSaved(prev => {
              const merged = [...prev];
              savedExams.forEach(e => {
                if (!merged.find(m => m.id === e.id)) {
                  merged.push({id: e.id, name: e.name, subject: e.subject});
                }
              });
              return merged;
            });
          }
        } catch (e) {}
      }, []);

      const buildHTML = ()=>{
        const theme = THEMES[style.theme];
        const fz = FONT_SIZES[style.fontSize];
        const den = DENSITY[style.density];
        const borderCss = (()=>{if(style.borderStyle==="rainbow"){ return `border:8px solid transparent;border-image:linear-gradient(45deg,#f06,#09f,#9f0,#ff0,#f06) 1;background-clip:padding-box;` } const bs=BORDER_STYLES[style.borderStyle]?.css||"4px solid"; return `border:${bs};border-color:${style.boxBorder};`;})();

        const line = ()=>`<span style="flex:1; border-bottom:1px dotted ${style.fieldLine}; margin: 0 3px;"></span>`;
        const sName = faDigits(info.schoolName); const sTitle = faDigits(info.examTitle); const sGrade = faDigits(info.grade); const sSubj = faDigits(info.subject); const sDur = faDigits(info.duration); const sScore = faDigits(info.totalScore); const sTeacher = faDigits(info.teacherName);
        const renderFormula = (text) => {if (!text) return ''; return text.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '<sup>$1</sup>/<sub>$2</sub>').replace(/\\sqrt\{([^}]+)\}/g, '√<span style="text-decoration:overline">$1</span>').replace(/\\sqrt\[(\d+)\]\{([^}]+)\}/g, '<sup>$1</sup>√<span style="text-decoration:overline">$2</span>').replace(/\^{([^}]+)}/g, '<sup>$1</sup>').replace(/\\times/g, '×').replace(/\\div/g, '÷').replace(/\\pm/g, '±').replace(/\\neq/g, '≠').replace(/\\leq/g, '≤').replace(/\\geq/g, '≥').replace(/\\approx/g, '≈').replace(/\\infty/g, '∞');};
        
        // --- PAGINATION LOGIC ---
        const allQuestions = [];
        let questionNumber = 1;
        sections.forEach(section => {
          if (section.questions.length > 0) {
            section.questions.forEach(q => {
              allQuestions.push({
                number: questionNumber++,
                section: section.title,
                icon: section.icon,
                sStyle: section,
                ...q
              });
            });
          }
        });

        const COST_PER_QUESTION_BASE = 10;
        const COST_PER_OPTION = 2;
        const COST_PER_IMAGE = 4;
        const COST_PER_DESCRIPTIVE_LINE = 1.5;
        const maxPageCost = den.perPage * COST_PER_QUESTION_BASE;

        const pages = [];
        let currentPage = [];
        let currentCost = 0;

        for (const question of allQuestions) {
          let questionCost = COST_PER_QUESTION_BASE;
          if (question.type === 'multiple') {
            questionCost += (question.options || []).filter(o => o.trim() !== '').length * COST_PER_OPTION;
          }
          if (question.type === 'descriptive') {
            questionCost += (question.answerLines || 3) * COST_PER_DESCRIPTIVE_LINE;
          }
          if (question.images && question.images.length > 0) {
            questionCost += question.images.length * COST_PER_IMAGE;
          }

          if (currentCost + questionCost > maxPageCost && currentPage.length > 0) {
            pages.push(currentPage);
            currentPage = [];
            currentCost = 0;
          }

          currentPage.push(question);
          currentCost += questionCost;
        }

        if (currentPage.length > 0) {
          pages.push(currentPage);
        }
        
        if (pages.length === 0 && sections.length > 0) {
            pages.push([]);
        }

        return `<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="UTF-8"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;600;700&family=Shabnam:wght@400;700&family=Estedad:wght@400;600;700&family=Samim:wght@400;700&family=Sahel:wght@400;700&family=Mardoto:wght@400;700&display=swap" rel="stylesheet"><style>@page { size:A4 portrait; margin:10mm; } *{box-sizing:border-box; font-family: ${FONTS[style.fontFamily].css};} html, body { margin:0; padding:0; -webkit-print-color-adjust:exact; print-color-adjust:exact; } .page{ width:190mm; height:277mm; background:${style.pageBg}; margin:0; position:relative; padding:6mm; ${borderCss} page-break-after:always; page-break-inside:avoid; overflow:hidden; border-radius:0; font-family: ${FONTS[style.fontFamily].css};} .page:last-child{ page-break-after:auto } .page-num{ position:absolute; bottom:5mm; left:50%; transform:translateX(-50%); font-size:10px; color:#666; font-weight:700; z-index: 1000;} .head{ background:${theme.header}; border-radius:${global.headerRounded}px; padding:8px 10px; margin-bottom:6mm; border:2px solid rgba(255,255,255,.5); display:grid; grid-template-columns: 110px 1fr 260px; gap:8px; align-items:center; } .logo-wrap{ background:rgba(255,255,255,.95); border-radius:${global.headerRounded-8}px; border:1px solid #e5e7eb; display:flex; align-items:center; justify-content:center; height:95px; overflow:hidden; } .logo-wrap img{ display:block; max-height:calc(${global.logoScale}%); max-width:95%; object-fit:contain } .titles{ text-align:center; color:${style.headerTextColor}; } .school{ font-size:${fz.header+6}px; font-weight:700; letter-spacing:normal; word-spacing:normal; font-variant-ligatures: normal; font-feature-settings: "liga" 1, "curs" 1; margin-bottom:4px; } .exam{ font-size:${fz.header+2}px; font-weight:700; opacity:.95 } .meta{ display:flex; gap:10px; justify-content:center; color:${style.headerTextColor}; margin-top:6px; font-size:${fz.option}px } .fields{ background:rgba(255,255,255,.92); border-radius:${global.headerRounded-8}px; padding:10px; border:1px solid #e5e7eb; display:grid; grid-template-columns: 1fr; gap:8px; font-size:${fz.option}px; color:#111827; } .row{ display:flex; align-items:center; gap: 4px; } .label{ font-weight:800; white-space:nowrap; } .section-title{ color:#fff; text-align:center; border-radius:10px; padding:6px 10px; font-weight:800; margin:8px 0 10px } .question{ background:${style.boxBg}; color:${style.boxText}; border:2px solid ${style.boxBorder}; border-radius:10px; padding:${den.padding}px; margin-bottom:${den.spacing}px; page-break-inside:avoid !important;} .q-head{ display:flex; align-items:flex-start; justify-content:space-between; gap:8px; margin-bottom:6px } .q-text{ font-weight:700; line-height:1.6; flex:1 } .q-score{ background:#f3f4f6; padding:2px 8px; border-radius:6px; font-size:10px; color:#4b5563; font-weight:700; white-space:nowrap } .imgs-h{ display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 } .imgs-v{ display:flex; flex-direction:column; gap:8px; align-items:center; margin:8px 0 } .img{ max-height:100px; border-radius:6px; border:1px solid #e5e7eb } .opts{ margin-top:4px; display:grid; grid-template-columns:1fr 1fr; gap:15px 30px; } .opt{ display:flex; align-items:center; gap:5px; } .opt-text{ display:flex; align-items:center; line-height:1.4 } .opt-line{ flex-grow:1; height:0; border-bottom:1px dotted ${style.fieldLine}; margin:0 3px; align-self:center; } .cb{ width:13px; height:13px; border:1.6px solid #111827; border-radius:3px; display:inline-block; flex-shrink:0; align-self:center; } .tf .opt{ align-items:center } .tf{ margin-top:4px; display:grid; grid-template-columns:1fr 1fr; gap:15px 30px; } .ans{ margin-top:8px; background:#fafafa; border:2px dashed #e5e7eb; border-radius:8px; padding:8px; min-height:40px } .lines{ display:flex; flex-direction:column; gap:${den.spacing+4}px } .line{ border-bottom:1px solid #cbd5e1; height:18px }</style></head><body>${pages.map((pg,pi)=> {
            let lastSectionTitle = '';
            const questionsHTML = pg.map(q => {
                // استفاده از سایز و فونت اختصاصی هر سوال
                const qFontSize = q.questionFontSize || style.fontSize;
                const qFontFamily = q.questionFontFamily || style.fontFamily;
                const qFz = FONT_SIZES[qFontSize] || fz;
                const qFontCss = FONTS[qFontFamily]?.css || FONTS[style.fontFamily].css;
                
                let sectionHeader = '';
                if (q.section !== lastSectionTitle) {
                    sectionHeader = `<div class="section-title" style="background:${q.sStyle.titleBg};color:${q.sStyle.titleColor};font-family:${FONTS[q.sStyle.titleFont]?.css || FONTS.vazir.css}">${faDigits(q.icon||"📝")} ${faDigits(q.section||"")}</div>`;
                    lastSectionTitle = q.section;
                }
                return `${sectionHeader}<div class="question"><div class="q-head"><div class="q-text" style="font-size:${qFz.question}px;font-family:${qFontCss}"><strong>${toFaNum(q.number)}-</strong> ${renderFormula(faDigits(q.text||""))}</div>${q.score?`<div class="q-score">${toFaNum(q.score)} نمره</div>`:""}</div>${q.images?.length?`<div class="${q.imageLayout==="vertical"?"imgs-v":"imgs-h"}" style="${q.imageLayout!=="vertical" ? `justify-content:${q.imageAlignment||"center"};`:""}">${q.images.map(img=>`<img class="img" src="${img.src}" alt="" style="width: ${img.width || '150px'}; max-width: 100%;"/>`).join("")}</div>`:""}${q.type==="multiple"?`<div class="opts">${(q.options||[]).map((t,i)=>t?`<div class="opt"><span class="opt-text" style="font-size:${qFz.option}px;font-family:${qFontCss}"><strong>${["الف","ب","ج","د"][i]})</strong> ${renderFormula(faDigits(t))}</span><span class="opt-line"></span><span class="cb"></span></div>`:"").join("")}</div>`:""}${q.type==="truefalse"?`<div class="tf"><div class="opt opt-tf"><span class="opt-text" style="font-size:${qFz.option}px;font-family:${qFontCss}"><strong>الف)</strong> درست</span><span class="cb"></span></div><div class="opt opt-tf"><span class="opt-text" style="font-size:${qFz.option}px;font-family:${qFontCss}"><strong>ب)</strong> نادرست</span><span class="cb"></span></div></div>`:""}${q.type==="descriptive"?`<div class="ans"><div class="lines">${Array(q.answerLines||3).fill(0).map(()=>`<div class="line"></div>`).join("")}</div></div>`:""}</div>`;
            }).join('');

            return `<div class="page"><div class="head"><div class="logo-wrap">${global.logo?`<img src="${global.logo}" alt="لوگو"/>`:`<span style="opacity:.6;font-size:12px">لوگو</span>`}</div><div class="titles"><div class="school">${sName||""}</div><div class="exam">${sTitle||""}</div><div class="meta">${sGrade?`<span>پایه: ${sGrade}</span>`:""} ${sSubj?`<span>درس: ${sSubj}</span>`:""} ${sDur?`<span>مدت: ${faDigits(sDur)} دقیقه</span>`:""} ${sScore?`<span>نمره کل: ${faDigits(sScore)}</span>`:""}</div></div><div class="fields">${info.showName?`<div class="row"><span class="label">نام و نام خانوادگی:</span>${line()}</div>`:""} ${info.showClass?`<div class="row"><span class="label">کلاس:</span>${line()}</div>`:""} ${info.showTeacher && sTeacher?`<div class="row"><span class="label">نام معلم:</span><span style="padding-right:5px">${sTeacher}</span></div>`:""} ${info.showDate?`<div class="row"><span class="label">تاریخ:</span>${line()}</div>`:""} ${info.showScore?`<div class="row"><span class="label">نمره:</span>${line()}</div>`:""}</div></div>${questionsHTML}<div class="page-num">صفحه ${toFaNum(pi+1)} از ${toFaNum(pages.length)}</div></div>`;
        }).join("")}</body></html>`;
      };

      const doPrint = ()=>{ const html = buildHTML(); const w = window.open("","_blank"); w.document.write(html); w.document.close(); setTimeout(()=>{ w.focus(); w.print(); }, 700); };
      const doPDF = async ()=>{ setBusyPdf(true); try{ const { jsPDF } = window.jspdf; const pdf = new jsPDF({orientation:"portrait", unit:"mm", format:"a4"}); const x = 10; const y = 10; const w = 190; const h = 277; const htmlContent = buildHTML(); const iframe = document.createElement('iframe'); iframe.style.position = 'absolute'; iframe.style.left = '-9999px'; iframe.style.width = '210mm'; iframe.style.height = '297mm'; document.body.appendChild(iframe); await new Promise((resolve, reject) => { iframe.onload = resolve; iframe.onerror = reject; const blob = new Blob([htmlContent], { type: 'text/html' }); iframe.src = URL.createObjectURL(blob); }); const iframeDoc = iframe.contentDocument; const iframeWin = iframe.contentWindow; if (iframeWin && iframeWin.document && iframeWin.document.fonts) { await iframeWin.document.fonts.ready; } await new Promise(resolve => setTimeout(resolve, 800)); const pages = iframeDoc.querySelectorAll(".page"); for(let i=0;i<pages.length;i++){ const pageEl = pages[i]; const canvas = await html2canvas(pageEl, { scale: 3, useCORS: true, allowTaint: true, backgroundColor: '#ffffff', logging: false, letterRendering: true, imageTimeout: 0 }); if(i>0) pdf.addPage(); const imgData = canvas.toDataURL("image/jpeg", 0.95); pdf.addImage(imgData, "JPEG", x, y, w, h); } pdf.save(`${faDigits(info.examName)||"آزمون"}.pdf`); URL.revokeObjectURL(iframe.src); document.body.removeChild(iframe); }catch(e){ console.error("PDF Generation Error:", e); alert("اشکال در ساخت PDF. لطفاً کنسول را برای جزئیات بررسی کنید."); } finally{ setBusyPdf(false); } };

      return (
        <>
          <div className="min-h-screen p-4" style={{fontFamily:FONTS[style.fontFamily].css}}>
            <div className="max-w-7xl mx-auto">
              <div className="bg-white rounded-2xl shadow-2xl p-6 mb-6 fade-in">
                <h1 className="text-3xl font-extrabold text-center mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">سیستم طراحی برگه امتحان حرفه‌ای</h1>
                <div className="flex flex-wrap gap-3 justify-center">
                  <button onClick={()=>setView("create")} className={`toolbar-btn px-5 py-2 rounded-xl font-bold transition-all ${view==="create"?"bg-purple-600 text-white shadow-lg":"bg-gray-100 hover:bg-gray-200"}`}>✏️ ایجاد آزمون</button>
                  <button onClick={()=>setView("saved")} className={`toolbar-btn px-5 py-2 rounded-xl font-bold transition-all ${view==="saved"?"bg-blue-600 text-white shadow-lg":"bg-gray-100 hover:bg-gray-200"}`}>💾 آزمون‌های ذخیره‌شده</button>
                </div>
                {view==="create" && (
                  <div className="flex flex-wrap gap-2 justify-center mt-4">
                    <button onClick={()=>setShowSettings(s=>!s)} className="toolbar-btn px-4 py-2 rounded-xl bg-gray-600 text-white hover:bg-gray-700">⚙️ {showSettings?"پنهان کردن":"نمایش"} تنظیمات</button>
                    <button onClick={()=>setPreview(p=>!p)} className="toolbar-btn px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700">👁️ {preview?"ویرایش":"پیش‌نمایش"}</button>
                    <button onClick={doPrint} className="toolbar-btn px-4 py-2 rounded-xl bg-purple-600 text-white hover:bg-purple-700">🖨️ چاپ</button>
                    <button onClick={doPDF} disabled={busyPdf} className="toolbar-btn px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-50 disabled:cursor-not-allowed">📄 {busyPdf?"در حال ساخت...":"PDF"}</button>
                    <button onClick={saveExam} className="toolbar-btn px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">💾 ذخیره</button>
                    <button onClick={resetAll} className="toolbar-btn px-4 py-2 rounded-xl bg-orange-500 text-white hover:bg-orange-600">🆕 آزمون جدید</button>
                  </div>
                )}
              </div>

              {view==="saved" && (
                <div className="bg-white rounded-2xl shadow-xl p-6 slide-up">
                  <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><span>📚</span><span>آزمون‌های ذخیره‌شده</span></h2>
                  {saved.length===0 ? (<div className="text-center py-20"><div className="text-6xl mb-4">📭</div><div className="text-gray-500 text-lg">هیچ آزمونی ذخیره نشده است</div><button onClick={()=>setView("create")} className="mt-4 px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700">ایجاد اولین آزمون</button></div>) : (<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{saved.map(x=>(<div key={x.id} className="question-card rounded-xl border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 p-5"><div className="flex items-start justify-between mb-2"><div className="font-extrabold text-lg text-purple-800">{x.name}</div><div className="text-2xl">📝</div></div><div className="text-sm text-gray-600 mb-4">📚 درس: <span className="font-bold">{x.subject}</span></div><div className="flex gap-2"><button className="toolbar-btn flex-1 rounded-lg bg-blue-600 text-white py-2 hover:bg-blue-700" onClick={()=>loadExam(x.id)}>📂 بارگذاری</button><button className="toolbar-btn rounded-lg bg-red-600 text-white px-3 hover:bg-red-700" onClick={()=>deleteExam(x.id)}>🗑️</button></div></div>))}</div>)}
                </div>
              )}
              {view==="create" && (
                <>
                  {/* تنظیمات */}
                  {showSettings && !preview && (
                    <div className="bg-white rounded-2xl shadow-xl p-6 mb-6 slide-up">
                      <h2 className="text-xl font-extrabold mb-4 flex items-center gap-2"><span>🎨</span><span>تنظیمات اصلی سربرگ</span></h2>
                      
                      {/* بخش لوگو */}
                      <div className="grid md:grid-cols-3 gap-4 mb-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                        <div className="md:col-span-2">
                          <label className="block font-bold mb-2 flex items-center gap-2"><span>🖼️</span><span>لوگوی مدرسه</span></label>
                          <div className="flex items-center gap-3 flex-wrap">
                            <input id="logo" type="file" accept="image/*" onChange={onUploadLogo} className="hidden"/>
                            <label htmlFor="logo" className="toolbar-btn px-4 py-2 bg-blue-600 text-white rounded-lg cursor-pointer">📤 انتخاب لوگو</label>
                            <button onClick={clearLogo} className="toolbar-btn px-4 py-2 bg-red-600 text-white rounded-lg">🗑️ حذف لوگو</button>
                            <div className="flex items-center gap-2"><span className="text-sm">اندازه:</span><input type="range" min="60" max="130" value={global.logoScale} onChange={e=>setGlobal(g=>({...g, logoScale:+e.target.value}))} className="w-32"/><span className="text-sm font-bold">{toFaNum(global.logoScale)}%</span></div>
                          </div>
                          {global.logo && (<div className="mt-3 p-3 border-2 rounded-xl bg-white shadow-sm"><img src={global.logo} alt="" className="h-24 object-contain"/></div>)}
                        </div>
                        <div>
                          <label className="block font-bold mb-2 flex items-center gap-2"><span>⬜</span><span>گردی قاب هدر</span></label>
                          <input type="range" min="12" max="36" value={global.headerRounded} onChange={e=>setGlobal(g=>({...g, headerRounded:+e.target.value}))} className="w-full"/>
                          <div className="text-center mt-2 text-sm font-bold">{toFaNum(global.headerRounded)}px</div>
                        </div>
                      </div>

                      {/* اطلاعات هدر */}
                      <h3 className="text-lg font-bold mb-3 flex items-center gap-2"><span>📋</span><span>اطلاعات هدر</span></h3>
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <input className="px-4 py-3 border-2 rounded-xl font-bold focus:border-purple-500 focus:outline-none transition-all" placeholder="نام آزمون (الزامی) *" value={info.examName} onChange={e=>setInfo({...info, examName:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="نام مدرسه" value={info.schoolName} onChange={e=>setInfo({...info, schoolName:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="عنوان امتحان" value={info.examTitle} onChange={e=>setInfo({...info, examTitle:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="نام معلم" value={info.teacherName} onChange={e=>setInfo({...info, teacherName:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="پایه" value={info.grade} onChange={e=>setInfo({...info, grade:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="درس" value={info.subject} onChange={e=>setInfo({...info, subject:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="مدت (دقیقه)" value={info.duration} onChange={e=>setInfo({...info, duration:e.target.value})}/>
                        <input className="px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="نمره کل" value={info.totalScore} onChange={e=>setInfo({...info, totalScore:e.target.value})}/>
                      </div>

                      {/* چک باکس‌های نمایش فیلدها در سربرگ */}
                      <div className="p-4 bg-yellow-50 border-2 border-yellow-200 rounded-xl mb-6">
                        <h4 className="font-bold mb-3 flex items-center gap-2"><span>☑️</span><span>انتخاب فیلدهای سربرگ (کدام قسمت‌ها نمایش داده شود)</span></h4>
                        <div className="grid md:grid-cols-3 gap-3">
                          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-yellow-100 rounded-lg transition-all"><input type="checkbox" checked={info.showName} onChange={e=>setInfo({...info, showName:e.target.checked})} className="w-5 h-5 cursor-pointer"/><span className="font-medium">نام و نام خانوادگی</span></label>
                          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-yellow-100 rounded-lg transition-all"><input type="checkbox" checked={info.showClass} onChange={e=>setInfo({...info, showClass:e.target.checked})} className="w-5 h-5 cursor-pointer"/><span className="font-medium">کلاس</span></label>
                          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-yellow-100 rounded-lg transition-all"><input type="checkbox" checked={info.showTeacher} onChange={e=>setInfo({...info, showTeacher:e.target.checked})} className="w-5 h-5 cursor-pointer"/><span className="font-medium">نام معلم</span></label>
                          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-yellow-100 rounded-lg transition-all"><input type="checkbox" checked={info.showDate} onChange={e=>setInfo({...info, showDate:e.target.checked})} className="w-5 h-5 cursor-pointer"/><span className="font-medium">تاریخ</span></label>
                          <label className="flex items-center gap-2 cursor-pointer p-2 hover:bg-yellow-100 rounded-lg transition-all"><input type="checkbox" checked={info.showScore} onChange={e=>setInfo({...info, showScore:e.target.checked})} className="w-5 h-5 cursor-pointer"/><span className="font-medium">نمره</span></label>
                        </div>
                      </div>

                      {/* ظاهر و رنگ‌ها */}
                      <h3 className="text-lg font-bold mb-3 flex items-center gap-2"><span>🎨</span><span>ظاهر و رنگ‌ها</span></h3>
                      <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
                        <div><div className="font-bold mb-2 text-sm">تم هدر</div><select className="w-full px-3 py-2 border-2 rounded-xl focus:border-purple-500 focus:outline-none" value={style.theme} onChange={e=>setStyle({...style, theme:e.target.value})}>{Object.entries(THEMES).map(([k,v])=><option key={k} value={k}>{v.name}</option>)}</select></div>
                        <div><div className="font-bold mb-2 text-sm">رنگ متن هدر</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.headerTextColor} onChange={e=>setStyle({...style, headerTextColor:e.target.value})}/></div>
                        <div><div className="font-bold mb-2 text-sm">پس‌زمینه صفحه</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.pageBg} onChange={e=>setStyle({...style, pageBg:e.target.value})}/></div>
                        <div><div className="font-bold mb-2 text-sm">رنگ خط فیلدها</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.fieldLine} onChange={e=>setStyle({...style, fieldLine:e.target.value})}/></div>
                        <div><div className="font-bold mb-2 text-sm">فونت کلی پیش‌فرض</div><select className="w-full px-3 py-2 border-2 rounded-xl focus:border-purple-500 focus:outline-none" value={style.fontFamily} onChange={e=>setStyle({...style, fontFamily:e.target.value})}>{Object.entries(FONTS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
                        <div><div className="font-bold mb-2 text-sm">سایز فونت پیش‌فرض</div><select className="w-full px-3 py-2 border-2 rounded-xl focus:border-purple-500 focus:outline-none" value={style.fontSize} onChange={e=>setStyle({...style, fontSize:e.target.value})}>{Object.keys(FONT_SIZES).map(size => <option key={size} value={size}>{size} نقطه</option>)}</select></div>
                        <div><div className="font-bold mb-2 text-sm">تراکم صفحه</div><select className="w-full px-3 py-2 border-2 rounded-xl focus:border-purple-500 focus:outline-none" value={style.density} onChange={e=>setStyle({...style, density:e.target.value})}>{Object.entries(DENSITY).map(([k,v])=><option key={k} value={k}>{v.name} ({toFaNum(v.perPage)} سوال)</option>)}</select></div>
                        <div><div className="font-bold mb-2 text-sm">نوع کادر صفحه</div><select className="w-full px-3 py-2 border-2 rounded-xl focus:border-purple-500 focus:outline-none" value={style.borderStyle} onChange={e=>setStyle({...style, borderStyle:e.target.value})}>{Object.entries(BORDER_STYLES).map(([k,v])=><option key={k} value={k}>{v.name}</option>)}</select></div>
                        <div><div className="font-bold mb-2 text-sm">رنگ کادر باکس‌ها</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.boxBorder} onChange={e=>setStyle({...style, boxBorder:e.target.value})}/></div>
                        <div><div className="font-bold mb-2 text-sm">پس‌زمینه باکس‌ها</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.boxBg} onChange={e=>setStyle({...style, boxBg:e.target.value})}/></div>
                        <div><div className="font-bold mb-2 text-sm">رنگ متن باکس‌ها</div><input type="color" className="w-full h-10 border-2 rounded-xl cursor-pointer" value={style.boxText} onChange={e=>setStyle({...style, boxText:e.target.value})}/></div>
                      </div>
                    </div>
                  )}

                  {/* بخش سوالات */}
                  {!preview ? (
                    <div className="space-y-6">
                      {sections.map((s, si)=>(
                        <div key={s.id} className="bg-white border-2 border-purple-200 rounded-2xl p-6 shadow-lg question-card">
                          <div className="flex items-center justify-between mb-5">
                            <input className="flex-1 text-xl font-bold px-4 py-3 border-2 rounded-xl focus:border-purple-500 focus:outline-none transition-all" placeholder="عنوان بخش" value={s.title} onChange={e=>{ const arr=[...sections]; arr[si].title=e.target.value; setSections(arr); }}/>
                            <div className="flex items-center gap-2 mr-3">
                              {sections.length>1 && (<button onClick={()=>delSection(s.id)} className="toolbar-btn px-4 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700">🗑️ حذف بخش</button>)}
                            </div>
                          </div>

                          {/* تنظیمات بخش */}
                          <div className="grid sm:grid-cols-3 gap-3 mb-5 p-3 bg-gray-50 rounded-xl">
                            <div><div className="text-sm font-bold mb-1">فونت هدر بخش</div><select className="w-full px-3 py-2 border rounded-xl focus:border-purple-500 focus:outline-none" value={s.titleFont} onChange={e=>{ const arr=[...sections]; arr[si].titleFont=e.target.value; setSections(arr); }}>{Object.entries(FONTS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}</select></div>
                            <div><div className="text-sm font-bold mb-1">رنگ متن هدر بخش</div><input type="color" className="w-full h-10 border rounded-xl cursor-pointer" value={s.titleColor} onChange={e=>{ const arr=[...sections]; arr[si].titleColor=e.target.value; setSections(arr); }}/></div>
                            <div><div className="text-sm font-bold mb-1">پس‌زمینه هدر بخش</div><input type="color" className="w-full h-10 border rounded-xl cursor-pointer" value={s.titleBg} onChange={e=>{ const arr=[...sections]; arr[si].titleBg=e.target.value; setSections(arr); }}/></div>
                          </div>

                          {/* لیست سوالات */}
                          <div className="space-y-4">
                            {s.questions.map((q, qi)=>(
                              <div key={q.id} className="p-5 bg-purple-50 rounded-xl border-2 border-purple-200 question-card">
                                <div className="flex items-start gap-3">
                                  <span className="font-bold text-lg mt-2 bg-purple-600 text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">{toFaNum(qi+1)}</span>
                                  <div className="flex-1">
                                    {/* ویرایشگر متن RTL با فونت و سایز اختصاصی */}
                                    <div className="mb-3">
                                      <RichTextEditor 
                                        sectionId={s.id} 
                                        questionId={q.id} 
                                        value={q.text} 
                                        onChange={(newText) => updQ(s.id, q.id, "text", newText)} 
                                        questionFontSize={q.questionFontSize || style.fontSize}
                                        questionFontFamily={q.questionFontFamily || style.fontFamily}
                                        onFontSizeChange={(newSize) => updQ(s.id, q.id, "questionFontSize", newSize)}
                                        onFontFamilyChange={(newFont) => updQ(s.id, q.id, "questionFontFamily", newFont)}
                                      />
                                    </div>

                                    {/* دکمه‌های کنترل */}
                                    <div className="flex gap-3 flex-wrap items-center mb-3">
                                      <select value={q.type} onChange={e=>updQ(s.id,q.id,"type",e.target.value)} className="px-4 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none"><option value="multiple">☑️ چهارگزینه‌ای</option><option value="truefalse">✅ درست/غلط</option><option value="descriptive">📝 تشریحی</option></select>
                                      <input type="number" min="0" step="0.5" className="w-28 px-3 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none" value={q.score} onChange={e=>updQ(s.id,q.id,"score",e.target.value)} placeholder="نمره"/>
                                      {q.type==="descriptive" && (<input type="number" min="1" max="10" className="w-32 px-3 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none" value={q.answerLines||3} onChange={e=>updQ(s.id,q.id,"answerLines",+e.target.value)} placeholder="تعداد خط"/>)}
                                      
                                      <div className="flex items-center gap-2">
                                        <input id={`img-${q.id}`} type="file" accept="image/*" multiple className="hidden" onChange={e=>uploadImg(s.id,q.id,e)}/>
                                        <label htmlFor={`img-${q.id}`} className="toolbar-btn px-4 py-2 bg-blue-600 text-white rounded-lg cursor-pointer inline-block">🖼️ افزودن عکس</label>
                                        <input type="number" min="50" max="800" value={parseInt(q.nextImageWidth) || 150} onChange={e=>updQ(s.id,q.id,"nextImageWidth", e.target.value + 'px')} className="w-24 px-2 py-2 border-2 rounded-lg text-sm" placeholder="عرض"/>
                                        <select value={q.imageUploadMode || 'custom'} onChange={e=>updQ(s.id,q.id,"imageUploadMode", e.target.value)} className="px-2 py-2 border-2 rounded-lg text-sm">
                                            <option value="custom">سایز سفارشی</option>
                                            <option value="double">دو برابر</option>
                                            <option value="actual">سایز واقعی</option>
                                        </select>
                                      </div>
                                      
                                      <button onClick={()=>window.openMathModal(s.id, q.id, '', (formula)=>{ const currentText = q.text || ''; updQ(s.id, q.id, "text", currentText + ' ' + formula); })} className="toolbar-btn px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">🧮 افزودن فرمول</button>
                                      
                                      {q.images?.length>0 && (<><select value={q.imageLayout||"horizontal"} onChange={e=>updQ(s.id,q.id,"imageLayout",e.target.value)} className="px-4 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none"><option value="horizontal">↔️ کنارهم</option><option value="vertical">↕️ زیرهم</option></select>{q.imageLayout!=="vertical" && (<select value={q.imageAlignment||"center"} onChange={e=>updQ(s.id,q.id,"imageAlignment",e.target.value)} className="px-4 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none"><option value="flex-start">⫸ راست‌چین</option><option value="center">↔ وسط‌چین</option><option value="flex-end">⫷ چپ‌چین</option></select>)}</>)}
                                    </div>

                                    {/* نمایش تصاویر با کنترل اندازه */}
                                    {q.images?.length>0 && (<div className="mb-3 flex flex-wrap gap-3">{q.images.map((img,ix)=>(<div key={ix} className="relative group"><img src={img.src} className="max-w-[400px] max-h-48 rounded-lg border-2 border-purple-200" style={{width: img.width || '150px'}}/><div className="absolute top-2 right-2 bg-red-600 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center cursor-pointer opacity-0 group-hover:opacity-100 transition-all shadow-lg" onClick={()=>rmImg(s.id,q.id,ix)}>✕</div><div className="image-size-control"><div className="flex items-center gap-2"><span className="text-xs">عرض:</span><input type="range" min="50" max="400" value={parseInt(img.width) || 150} onChange={(e)=>updateImageWidth(s.id, q.id, ix, e.target.value + 'px')} className="w-24" style={{cursor: 'ew-resize'}}/><span className="text-xs font-bold">{parseInt(img.width) || 150}px</span></div></div></div>))}</div>)}

                                    {/* گزینه‌های چهارگزینه‌ای */}
                                    {q.type==="multiple" && (<div className="grid grid-cols-2 gap-3">{["الف","ب","ج","د"].map((lb,i)=>(<div key={i} className="flex items-center gap-2"><span className="font-bold bg-purple-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm flex-shrink-0">{lb}</span><input className="flex-1 px-3 py-2 border-2 rounded-lg focus:border-purple-500 focus:outline-none" value={q.options[i]} onChange={e=>{ const opts=[...q.options]; opts[i]=e.target.value; updQ(s.id,q.id,"options",opts); }} placeholder={`گزینه ${lb}`} dir="rtl"/></div>))}</div>)}
                                  </div>
                                  <button onClick={()=>delQ(s.id,q.id)} className="toolbar-btn px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex-shrink-0">🗑️</button>
                                </div>
                              </div>
                            ))}
                            
                            {/* دکمه افزودن سوال در پایین هر بخش */}
                            <div className="relative mt-4">
                              <button 
                                onClick={()=>setMenuFor(menuFor===s.id?null:s.id)} 
                                className="toolbar-btn w-full py-4 border-3 border-dashed border-purple-300 rounded-xl font-bold text-lg hover:border-purple-500 hover:bg-purple-50 transition-all flex items-center justify-center gap-2"
                              >
                                <span className="text-2xl">➕</span>
                                <span>افزودن سوال جدید</span>
                              </button>
                              {menuFor===s.id && (
                                <div className="dropdown-menu absolute left-1/2 transform -translate-x-1/2 top-full mt-2 bg-white rounded-xl p-2 z-10 min-w-[220px] border-2 border-purple-200 shadow-xl">
                                  <button onClick={()=>addQ(s.id,"multiple")} className="w-full text-right px-4 py-3 hover:bg-purple-50 rounded-lg transition-all flex items-center gap-2">
                                    <span>☑️</span><span>چهارگزینه‌ای</span>
                                  </button>
                                  <button onClick={()=>addQ(s.id,"truefalse")} className="w-full text-right px-4 py-3 hover:bg-purple-50 rounded-lg transition-all flex items-center gap-2">
                                    <span>✅</span><span>درست/غلط</span>
                                  </button>
                                  <button onClick={()=>addQ(s.id,"descriptive")} className="w-full text-right px-4 py-3 hover:bg-purple-50 rounded-lg transition-all flex items-center gap-2">
                                    <span>📝</span><span>تشریحی</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      <button onClick={addSection} className="toolbar-btn w-full py-6 border-4 border-dashed border-purple-300 rounded-2xl font-bold text-lg hover:border-purple-500 hover:bg-purple-50 transition-all">➕ افزودن بخش جدید</button>
                    </div>
                  ) : (
                    <div id="print-area" className="bg-gray-200 p-4 rounded-2xl overflow-auto">
                      <div id="print-content" className="mx-auto" style={{width:"210mm"}} dangerouslySetInnerHTML={{__html: buildHTML()}} />
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </>
      );
    }

    ReactDOM.render(<App/>, document.getElementById("root"));
  </script>
  
</body>
</html>
