<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// Check if user is admin
if (!isAdmin()) {
    header('Location: index.php');
    exit();
}

$studentId = intval($_GET['id'] ?? 0);
if (!$studentId) {
    header('Location: index.php?section=admin');
    exit();
}

// Get student data
$stmt = $conn->prepare("
    SELECT u.*, s.total_score, s.weekly_stars 
    FROM users u 
    LEFT JOIN students s ON u.id = s.user_id 
    WHERE u.id = ? AND u.user_type = 'student'
");
$stmt->execute([$studentId]);
$student = $stmt->fetch();

if (!$student) {
    header('Location: index.php?section=admin');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'first_name' => sanitize($_POST['first_name'] ?? ''),
        'last_name' => sanitize($_POST['last_name'] ?? ''),
        'email' => sanitize($_POST['email'] ?? ''),
        'national_id' => sanitize($_POST['national_id'] ?? ''),
        'birth_date' => sanitize($_POST['birth_date'] ?? ''),
        'address' => sanitize($_POST['address'] ?? ''),
        'father_name' => sanitize($_POST['father_name'] ?? ''),
        'father_phone' => sanitize($_POST['father_phone'] ?? ''),
        'mother_name' => sanitize($_POST['mother_name'] ?? ''),
        'mother_phone' => sanitize($_POST['mother_phone'] ?? ''),
        'is_active' => isset($_POST['is_active']) ? 1 : 0
    ];
    
    try {
        $sql = "UPDATE users SET 
                first_name = ?, last_name = ?, email = ?, national_id = ?,
                birth_date = ?, address = ?, father_name = ?, father_phone = ?,
                mother_name = ?, mother_phone = ?, is_active = ?
                WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $data['first_name'], $data['last_name'], $data['email'], $data['national_id'],
            $data['birth_date'], $data['address'], $data['father_name'], $data['father_phone'],
            $data['mother_name'], $data['mother_phone'], $data['is_active'], $studentId
        ]);
        
        // Update scores if provided
        if (isset($_POST['total_score']) || isset($_POST['weekly_stars'])) {
            $stmt = $conn->prepare("
                UPDATE students SET 
                total_score = COALESCE(?, total_score),
                weekly_stars = COALESCE(?, weekly_stars)
                WHERE user_id = ?
            ");
            $stmt->execute([
                $_POST['total_score'] ?? null,
                $_POST['weekly_stars'] ?? null,
                $studentId
            ]);
        }
        
        $_SESSION['success'] = 'اطلاعات دانش‌آموز با موفقیت بروزرسانی شد';
        header('Location: index.php?section=admin');
        exit();
        
    } catch(PDOException $e) {
        $error = 'خطا در بروزرسانی اطلاعات';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش دانش‌آموز - ستاره ماه</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(135deg, #87CEEB 0%, #FFF8DC 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        
        .edit-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .header h1 {
            color: #FF7F50;
            margin: 0;
        }
        
        .back-btn {
            background: #87CEEB;
            color: white;
            border: none;
            padding: 0.7rem 1.5rem;
            border-radius: 25px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        
        .back-btn:hover {
            background: #6BB6D8;
            transform: translateY(-2px);
        }
        
        .form-section {
            margin-bottom: 2rem;
        }
        
        .form-section h3 {
            color: #333;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-family: inherit;
            transition: all 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #87CEEB;
            outline: none;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: auto;
        }
        
        .score-inputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            background: #f8f8f8;
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        
        .submit-btn {
            background: linear-gradient(135deg, #32CD32, #98FB98);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 25px;
            font-weight: 500;
            cursor: pointer;
            width: 100%;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(50, 205, 50, 0.3);
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <div class="header">
            <h1>ویرایش اطلاعات دانش‌آموز</h1>
            <a href="index.php?section=admin" class="back-btn">بازگشت به پنل</a>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-section">
                <h3>اطلاعات شخصی</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label>نام:</label>
                        <input type="text" name="first_name" value="<?php echo htmlspecialchars($student['first_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>نام خانوادگی:</label>
                        <input type="text" name="last_name" value="<?php echo htmlspecialchars($student['last_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>کد ملی:</label>
                        <input type="text" name="national_id" value="<?php echo htmlspecialchars($student['national_id']); ?>" pattern="[0-9]{10}" required>
                    </div>
                    <div class="form-group">
                        <label>تاریخ تولد:</label>
                        <input type="text" name="birth_date" value="<?php echo htmlspecialchars($student['birth_date']); ?>" placeholder="1394/01/01">
                    </div>
                </div>
                <div class="form-group">
                    <label>آدرس:</label>
                    <textarea name="address" rows="2"><?php echo htmlspecialchars($student['address']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>ایمیل:</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>">
                </div>
            </div>
            
            <div class="form-section">
                <h3>اطلاعات والدین</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label>نام پدر:</label>
                        <input type="text" name="father_name" value="<?php echo htmlspecialchars($student['father_name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>تلفن پدر:</label>
                        <input type="tel" name="father_phone" value="<?php echo htmlspecialchars($student['father_phone']); ?>">
                    </div>
                    <div class="form-group">
                        <label>نام مادر:</label>
                        <input type="text" name="mother_name" value="<?php echo htmlspecialchars($student['mother_name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>تلفن مادر:</label>
                        <input type="tel" name="mother_phone" value="<?php echo htmlspecialchars($student['mother_phone']); ?>">
                    </div>
                </div>
            </div>
            
            <div class="form-section">
                <h3>وضعیت و امتیازات</h3>
                <div class="checkbox-group">
                    <input type="checkbox" id="is_active" name="is_active" <?php echo $student['is_active'] ? 'checked' : ''; ?>>
                    <label for="is_active">حساب کاربری فعال</label>
                </div>
                
                <div class="score-inputs">
                    <div class="form-group">
                        <label>امتیاز کل:</label>
                        <input type="number" name="total_score" value="<?php echo $student['total_score'] ?? 0; ?>" min="0">
                    </div>
                    <div class="form-group">
                        <label>ستاره‌های هفته:</label>
                        <input type="number" name="weekly_stars" value="<?php echo $student['weekly_stars'] ?? 0; ?>" min="0">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="submit-btn">ذخیره تغییرات</button>
        </form>
    </div>
</body>
</html>