<?php
/**
 * Admin Helper Functions
 * توابع کمکی برای پنل مدیریت
 */

/**
 * Get admin statistics
 * دریافت آمار پنل مدیریت
 */
function getAdminStats($conn) {
    try {
        $stats = [
            'totalStudents' => 0,
            'newFeedbacks' => 0,
            'totalContent' => 0,
            'todayVisits' => 0
        ];
        
        // تعداد کل دانش‌آموزان
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE user_type = 'student'");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['totalStudents'] = $result['count'] ?? 0;
        
        // بازخوردهای جدید (اگر جدول feedbacks وجود داشت)
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM feedbacks WHERE is_read = 0");
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['newFeedbacks'] = $result['count'] ?? 0;
        } catch (Exception $e) {
            $stats['newFeedbacks'] = 0;
        }
        
        // محتوای آپلود شده (اگر جدول content وجود داشت)
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM content");
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['totalContent'] = $result['count'] ?? 0;
        } catch (Exception $e) {
            $stats['totalContent'] = 0;
        }
        
        // بازدید امروز (اگر جدول visits وجود داشت)
        try {
            $today = date('Y-m-d');
            $stmt = $conn->prepare("SELECT COUNT(DISTINCT user_id) as count FROM user_visits WHERE DATE(visit_date) = ?");
            $stmt->execute([$today]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['todayVisits'] = $result['count'] ?? 0;
        } catch (Exception $e) {
            // اگر جدول وجود نداشت، تعداد دانش‌آموزان فعال را نشان دهیم
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE user_type = 'student' AND is_active = 1");
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $stats['todayVisits'] = $result['count'] ?? 0;
        }
        
        return $stats;
        
    } catch (Exception $e) {
        error_log("Error getting admin stats: " . $e->getMessage());
        return [
            'totalStudents' => 0,
            'newFeedbacks' => 0,
            'totalContent' => 0,
            'todayVisits' => 0
        ];
    }
}

/**
 * Get about page settings
 * دریافت تنظیمات صفحه درباره ما
 */
function getAboutSettings($conn) {
    try {
        // بررسی وجود جدول settings
        $stmt = $conn->prepare("SHOW TABLES LIKE 'settings'");
        $stmt->execute();
        
        if (!$stmt->fetch()) {
            return ['content' => ''];
        }
        
        // دریافت محتوای صفحه درباره ما
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'about_content'");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return [
            'content' => $result['setting_value'] ?? ''
        ];
        
    } catch (Exception $e) {
        error_log("Error getting about settings: " . $e->getMessage());
        return ['content' => ''];
    }
}

/**
 * Check if user is admin
 * بررسی مجوز مدیریت کاربر
 */
function isAdmin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

/**
 * Get student details by ID
 * دریافت جزئیات دانش‌آموز با شناسه
 */
function getStudentById($conn, $student_id) {
    try {
        $stmt = $conn->prepare("
            SELECT u.*, s.total_score, s.weekly_stars, s.class_rank 
            FROM users u 
            LEFT JOIN students s ON u.id = s.user_id 
            WHERE u.id = ? AND u.user_type = 'student'
        ");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($student) {
            // حذف اطلاعات حساس
            unset($student['password']);
            
            // فرمت تاریخ برای نمایش
            if ($student['birth_date']) {
                $student['birth_date'] = date('Y-m-d', strtotime($student['birth_date']));
            }
            
            if ($student['created_at']) {
                $student['created_at'] = date('Y-m-d H:i', strtotime($student['created_at']));
            }
        }
        
        return $student;
        
    } catch (Exception $e) {
        error_log("Error getting student by ID: " . $e->getMessage());
        return null;
    }
}

/**
 * Validate national ID
 * اعتبارسنجی کد ملی
 */
function validateNationalId($nationalId) {
    // حذف کاراکترهای غیرعددی
    $nationalId = preg_replace('/[^0-9]/', '', $nationalId);
    
    // بررسی طول
    if (strlen($nationalId) !== 10) {
        return false;
    }
    
    // بررسی تکراری نبودن تمام ارقام
    if (preg_match('/^(\d)\1{9}$/', $nationalId)) {
        return false;
    }
    
    // محاسبه رقم کنترل
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += intval($nationalId[$i]) * (10 - $i);
    }
    
    $remainder = $sum % 11;
    $checkDigit = $remainder < 2 ? $remainder : 11 - $remainder;
    
    return intval($nationalId[9]) === $checkDigit;
}

/**
 * Log admin activity
 * ثبت فعالیت مدیر
 */
function logAdminActivity($conn, $action, $details = '') {
    try {
        $admin_id = $_SESSION['user_id'] ?? 0;
        $admin_username = $_SESSION['username'] ?? 'unknown';
        
        // اگر جدول logs وجود نداشت، آن را ایجاد کنیم
        $stmt = $conn->prepare("SHOW TABLES LIKE 'admin_logs'");
        $stmt->execute();
        
        if (!$stmt->fetch()) {
            $create_table_sql = "
                CREATE TABLE admin_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    admin_id INT,
                    admin_username VARCHAR(50),
                    action VARCHAR(100),
                    details TEXT,
                    ip_address VARCHAR(45),
                    user_agent TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ";
            $conn->exec($create_table_sql);
        }
        
        $stmt = $conn->prepare("
            INSERT INTO admin_logs (admin_id, admin_username, action, details, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        $stmt->execute([$admin_id, $admin_username, $action, $details, $ip_address, $user_agent]);
        
    } catch (Exception $e) {
        error_log("Error logging admin activity: " . $e->getMessage());
    }
}

/**
 * Create backup of student data before deletion
 * ایجاد نسخه پشتیبان از اطلاعات دانش‌آموز قبل از حذف
 */
function backupStudentData($conn, $student_id) {
    try {
        // اگر جدول deleted_students وجود نداشت، آن را ایجاد کنیم
        $stmt = $conn->prepare("SHOW TABLES LIKE 'deleted_students'");
        $stmt->execute();
        
        if (!$stmt->fetch()) {
            $create_table_sql = "
                CREATE TABLE deleted_students (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    original_id INT,
                    student_data JSON,
                    deleted_by INT,
                    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ";
            $conn->exec($create_table_sql);
        }
        
        // دریافت اطلاعات دانش‌آموز
        $student = getStudentById($conn, $student_id);
        
        if ($student) {
            $stmt = $conn->prepare("
                INSERT INTO deleted_students (original_id, student_data, deleted_by) 
                VALUES (?, ?, ?)
            ");
            
            $stmt->execute([
                $student_id,
                json_encode($student, JSON_UNESCAPED_UNICODE),
                $_SESSION['user_id'] ?? 0
            ]);
            
            return true;
        }
        
        return false;
        
    } catch (Exception $e) {
        error_log("Error backing up student data: " . $e->getMessage());
        return false;
    }
}
?>