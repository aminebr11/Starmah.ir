<?php
// ==========================
// Database configuration
// ==========================
define('DB_HOST', 'localhost');       // هاست دیتابیس
define('DB_PORT', '3306');             // پورت دیتابیس
define('DB_NAME', 'qwaepiuv_starmah_db'); 
define('DB_USER', 'qwaepiuv_aminebr'); 
define('DB_PASS', 'Test12345!@#');     

// ==========================
// AI API Keys & Models
// ==========================
define('AI_API_KEY', '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');
define('AI_MODEL', 'claude-3-haiku-20240307');

define('OPENAI_API_KEY', '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');
define('OPENAI_ENABLED', true); // یا false اگر نمی‌خواهید از OpenAI استفاده کنید

// ==========================
// Site configuration
// ==========================
define('SITE_URL', 'https://www.starmah.ir');
define('SITE_NAME', 'ستاره ماه');

// ==========================
// Error reporting
// ==========================
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ==========================
// Timezone
// ==========================
date_default_timezone_set('Asia/Tehran');

// ==========================
// Create database connection
// ==========================
try {
    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $conn = new PDO($dsn, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("DB Connection Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به دیتابیس']);
    exit;
}

// ==========================
// Start session if not already started
// ==========================
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// ثبت خودکار بازدید برای همه کاربران لاگین شده
if (isset($_SESSION['user_id']) && !isset($_SESSION['visit_recorded_today'])) {
    try {
        $current_user_id = $_SESSION['user_id'];
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $today = date('Y-m-d');
        
        // بررسی اینکه آیا امروز برای این کاربر بازدید ثبت شده یا نه
        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM visits WHERE user_id = ? AND DATE(visit_date) = ?");
        $check_stmt->execute([$current_user_id, $today]);
        $visit_exists = $check_stmt->fetchColumn() > 0;
        
        // اگر امروز بازدید ثبت نشده، ثبت کن
        if (!$visit_exists) {
            $visit_stmt = $conn->prepare("INSERT INTO visits (user_id, ip_address, user_agent, visit_date) VALUES (?, ?, ?, NOW())");
            $visit_stmt->execute([$current_user_id, $ip_address, $user_agent]);
            
            // بروزرسانی last_login
            $login_stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $login_stmt->execute([$current_user_id]);
        }
        
        // علامت‌گذاری که امروز بازدید ثبت شده
        $_SESSION['visit_recorded_today'] = $today;
        
    } catch (PDOException $e) {
        error_log("Auto visit recording error: " . $e->getMessage());
    }
}

// پاکسازی علامت روز قبل
if (isset($_SESSION['visit_recorded_today']) && $_SESSION['visit_recorded_today'] !== date('Y-m-d')) {
    unset($_SESSION['visit_recorded_today']);
}
// ثبت فعالیت مداوم کاربر برای real-time tracking
if (isset($_SESSION['user_id'])) {
    $current_time = time();
    $last_activity = $_SESSION['last_activity'] ?? 0;
    
    // اگر بیش از 2 دقیقه از آخرین فعالیت گذشته، رکورد جدید ثبت کن
    if ($current_time - $last_activity > 120) {
        try {
            $user_id = $_SESSION['user_id'];
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            
            $stmt = $conn->prepare("INSERT INTO visits (user_id, ip_address, user_agent, visit_date) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$user_id, $ip_address, $user_agent]);
            
            $_SESSION['last_activity'] = $current_time;
            
        } catch (PDOException $e) {
            error_log("Activity tracking error: " . $e->getMessage());
        }
    }
}

?>