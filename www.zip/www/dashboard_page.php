<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد موارد انضباطی</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .back-button {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid white;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
            font-weight: 600;
        }
        .back-button:hover {
            background: white;
            color: #667eea;
        }
    </style>
</head>
<body>
    <a href="index.php" class="back-button">← بازگشت به صفحه اصلی</a>
    
    <?php
    // شروع session
    session_start();
    
    // شامل کردن config
    include 'config.php';
    
    // شامل کردن داشبورد
    include 'sections/dashboard.php';
    ?>
</body>
</html>