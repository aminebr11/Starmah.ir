<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// Set JSON header
header('Content-Type: application/json; charset=utf-8');

// Function to send JSON response
function sendJsonResponse($success, $message, $data = []) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'روش درخواست نامعتبر است');
}

try {
    $national_id = sanitize($_POST['national_id'] ?? '');
    $father_name = sanitize($_POST['father_name'] ?? '');
    $mother_name = sanitize($_POST['mother_name'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($national_id) || empty($father_name) || empty($mother_name) || empty($new_password) || empty($confirm_password)) {
        sendJsonResponse(false, 'تمام فیلدها الزامی است');
    }
    
    // Validate national ID format
    if (!preg_match('/^[0-9]{10}$/', $national_id)) {
        sendJsonResponse(false, 'کد ملی باید دقیقاً 10 رقم باشد');
    }
    
    // Check if passwords match
    if ($new_password !== $confirm_password) {
        sendJsonResponse(false, 'رمز عبور جدید و تأیید آن مطابقت ندارند');
    }
    
    // Optional: Add password strength validation (e.g., minimum length)
    if (strlen($new_password) < 8) {
        sendJsonResponse(false, 'رمز عبور باید حداقل 8 کاراکتر باشد');
    }
    
    // Find user with matching credentials
    $stmt = $conn->prepare("SELECT * FROM users WHERE national_id = ? AND father_name = ? AND mother_name = ? AND user_type = 'student'");
    $stmt->execute([$national_id, $father_name, $mother_name]);
    $user = $stmt->fetch();
    
    if (!$user) {
        sendJsonResponse(false, 'اطلاعات وارد شده با هیچ حساب کاربری مطابقت ندارد. لطفاً اطلاعات را دقیق وارد کنید.');
    }
    
    // Hash the new password
    $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
    
    // Update password in database
    $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $result = $updateStmt->execute([$hashedPassword, $user['id']]);
    
    if (!$result) {
        sendJsonResponse(false, 'خطا در به‌روزرسانی رمز عبور. لطفاً دوباره تلاش کنید.');
    }
    
    $fullName = $user['first_name'] . ' ' . $user['last_name'];
    
    sendJsonResponse(true, "رمز عبور برای {$fullName} با موفقیت تغییر یافت. حالا می‌توانید با رمز جدید وارد شوید.");
    
} catch (PDOException $e) {
    error_log("Recovery Error: " . $e->getMessage());
    sendJsonResponse(false, 'خطا در پردازش درخواست بازیابی. لطفاً دوباره تلاش کنید.');
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage());
    sendJsonResponse(false, 'خطای عمومی در سیستم');
}
?>