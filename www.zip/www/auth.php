<?php
// Debug mode
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display, log them
ini_set('log_errors', 1);

session_start();
require_once 'config.php';
require_once 'functions.php';

// Set JSON header
header('Content-Type: application/json; charset=utf-8');

// Log request
error_log("=== AUTH.PHP REQUEST ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Action: " . ($_POST['action'] ?? 'NOT SET'));
error_log("POST data: " . print_r($_POST, true));
error_log("Session ID: " . session_id());
error_log("User ID in session: " . ($_SESSION['user_id'] ?? 'NOT SET'));

// Function to send JSON response
function sendJsonResponse($success, $message, $data = []) {
    $response = [
        'success' => $success,
        'message' => $message,
        'data' => $data
    ];
    
    error_log("Sending response: " . json_encode($response, JSON_UNESCAPED_UNICODE));
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// Function to send email confirmation
function sendConfirmationEmail($email, $fullName, $username) {
    if (empty($email)) return false;
    
    $subject = "تایید ثبت‌نام در سایت ستاره ماه";
    $message = "
   <html>
    <head>
        <meta charset='UTF-8'>
        <title>تایید ثبت‌نام</title>
    </head>
    <body dir='rtl' style='font-family: Tahoma, Arial, sans-serif;'>
        <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 15px; color: white;'>
            <h2 style='text-align: center;'>🌟 خوش آمدید به کلاس ستاره ماه! 🌙</h2>
            <p>سلام <strong>{$fullName}</strong> عزیز!</p>
            <p>ثبت‌نام شما در سایت آموزشی کلاس چهارم خانم نجمه محمودی با موفقیت انجام شد.</p>
            
            <div style='background: rgba(255,255,255,0.1); padding: 15px; border-radius: 10px; margin: 20px 0;'>
                <h3>📋 اطلاعات حساب کاربری شما:</h3>
                <p><strong>نام کاربری:</strong> {$username}</p>
                <p><strong>تاریخ ثبت‌نام:</strong> " . date('Y/m/d H:i') . "</p>
            </div>
            
            <p>🎓 حالا می‌توانید با استفاده از کد ملی خود به عنوان نام کاربری وارد سایت شوید.</p>
            
            <p style='text-align: center; margin-top: 30px;'>
                با آرزوی موفقیت<br>
                <strong>نجمه محمودی</strong><br>
                کلاس چهارم ستاره ماه
            </p>
        </div>
    </body>
    </html>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@starmah.ir" . "\r\n";
    
    return mail($email, $subject, $message, $headers);
}

// Function to convert Persian/Arabic digits to English
function normalize_digits($string) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    
    $string = str_replace($persian, $english, $string);
    $string = str_replace($arabic, $english, $string);
    
    return $string;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Invalid request method");
    sendJsonResponse(false, 'روش درخواست نامعتبر است');
}

$action = $_POST['action'] ?? '';
error_log("Processing action: " . $action);

try {
    if ($action === 'register') {
        error_log("Processing REGISTER");
        
        // Collect and validate data
        $first_name = sanitize($_POST['first_name'] ?? '');
        $last_name = sanitize($_POST['last_name'] ?? '');
        $national_id = normalize_digits(sanitize($_POST['national_id'] ?? ''));
        $birth_date = normalize_digits(sanitize($_POST['birth_date'] ?? ''));
        $address = sanitize($_POST['address'] ?? '');
        $father_name = sanitize($_POST['father_name'] ?? '');
        $father_phone = normalize_digits(sanitize($_POST['father_phone'] ?? ''));
        $mother_name = sanitize($_POST['mother_name'] ?? '');
        $mother_phone = normalize_digits(sanitize($_POST['mother_phone'] ?? ''));
        $email = sanitize($_POST['email'] ?? '');
        $username = normalize_digits(sanitize($_POST['username'] ?? ''));
        $password = $_POST['password'] ?? '';
        
        // Validate required fields
        if (empty($first_name) || empty($last_name) || empty($national_id) || empty($birth_date) ||
            empty($address) || empty($father_name) || empty($father_phone) ||
            empty($mother_name) || empty($mother_phone) || empty($username) || empty($password)) {
            sendJsonResponse(false, 'لطفاً تمام فیلدهای ضروری را پر کنید');
        }
        
        // Validate national ID
        if (!preg_match('/^[0-9]{10}$/', $national_id)) {
            sendJsonResponse(false, 'کد ملی باید دقیقاً 10 رقم باشد');
        }
        
        // Ensure username equals national_id
        if ($username !== $national_id) {
            sendJsonResponse(false, 'نام کاربری باید همان کد ملی باشد');
        }
        
        // Check if user already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR national_id = ?");
        $stmt->execute([$username, $national_id]);
        
        if ($stmt->fetch()) {
            sendJsonResponse(false, 'این کد ملی قبلاً ثبت شده است');
        }
        
        // Validate birth date format (for Jalali/Shamsi)
        if (!empty($birth_date)) {
            $parts = explode('/', $birth_date);
            if (count($parts) !== 3 || !is_numeric(trim($parts[0])) || !is_numeric(trim($parts[1])) || !is_numeric(trim($parts[2]))) {
                sendJsonResponse(false, 'فرمت تاریخ تولد نامعتبر است (باید به صورت YYYY/MM/DD باشد)');
            }
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $conn->prepare("
            INSERT INTO users (username, password, user_type, first_name, last_name, national_id, 
                             birth_date, address, father_name, father_phone, mother_name, mother_phone, email, created_at) 
            VALUES (?, ?, 'student', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $result = $stmt->execute([
            $username, $hashedPassword, $first_name, $last_name, $national_id,
            $birth_date, $address, $father_name, $father_phone, $mother_name, $mother_phone, $email
        ]);
        
        if ($result) {
            $emailSent = false;
            
            // Send confirmation email if email provided
            if (!empty($email)) {
                $fullName = $first_name . ' ' . $last_name;
                $emailSent = sendConfirmationEmail($email, $fullName, $username);
            }
            
            sendJsonResponse(true, 'ثبت نام با موفقیت انجام شد!', [
                'email_sent' => $emailSent
            ]);
        } else {
            sendJsonResponse(false, 'خطا در ذخیره اطلاعات: ' . print_r($stmt->errorInfo(), true));
        }
        
    } elseif ($action === 'login') {
        error_log("Processing LOGIN");
        
        $username = normalize_digits(sanitize($_POST['username'] ?? ''));
        $password = $_POST['password'] ?? '';
        $user_type = $_POST['user_type'] ?? 'student';
        
        if (empty($username) || empty($password)) {
            sendJsonResponse(false, 'نام کاربری و رمز عبور الزامی است');
        }
        
        // Find user
        if ($user_type === 'admin' || $username === 'admin') {
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND user_type = 'admin'");
        } else {
            // Validate national ID format for students
            if (!preg_match('/^[0-9]{10}$/', $username)) {
                sendJsonResponse(false, 'کد ملی باید 10 رقم باشد');
            }
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND user_type = 'student'");
        }
        
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if (!$user) {
            if ($user_type === 'admin') {
                sendJsonResponse(false, 'نام کاربری یا رمز عبور ادمین اشتباه است');
            } else {
                sendJsonResponse(false, 'کد ملی وارد شده در سیستم موجود نیست');
            }
        }
        
        // Verify password
        if (!password_verify($password, $user['password'])) {
            sendJsonResponse(false, 'رمز عبور اشتباه است');
        }
        
        // Check if user is active
        if (isset($user['is_active']) && $user['is_active'] == 0) {
            sendJsonResponse(false, 'حساب کاربری شما غیرفعال است');
        }
        
        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['user_type'] = $user['user_type'];
        $_SESSION['username'] = $user['username'];
        
        // Update last login
        $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $updateStmt->execute([$user['id']]);
        
        sendJsonResponse(true, 'ورود موفقیت‌آمیز', [
            'user_type' => $user['user_type'],
            'user_name' => $_SESSION['user_name']
        ]);
        
    } elseif ($action === 'edit_profile') {
        error_log("Processing EDIT_PROFILE");
        
        // بررسی ورود کاربر
        if (!isset($_SESSION['user_id'])) {
            error_log("User not logged in - session user_id not set");
            sendJsonResponse(false, '⚠️ لطفاً ابتدا وارد شوید');
        }
        
        $userId = $_SESSION['user_id'];
        error_log("Editing profile for user ID: " . $userId);
        
        // دریافت و تمیز کردن داده‌ها
        $first_name = sanitize($_POST['first_name'] ?? '');
        $last_name = sanitize($_POST['last_name'] ?? '');
        $birth_date = normalize_digits(sanitize($_POST['birth_date'] ?? ''));
        $address = sanitize($_POST['address'] ?? '');
        $father_name = sanitize($_POST['father_name'] ?? '');
        $father_phone = normalize_digits(sanitize($_POST['father_phone'] ?? ''));
        $mother_name = sanitize($_POST['mother_name'] ?? '');
        $mother_phone = normalize_digits(sanitize($_POST['mother_phone'] ?? ''));
        $email = sanitize($_POST['email'] ?? '');
        
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        error_log("First name: " . $first_name);
        error_log("Last name: " . $last_name);
        
        // اعتبارسنجی فیلدهای اجباری
        if (empty($first_name) || empty($last_name)) {
            error_log("Validation failed: empty first or last name");
            sendJsonResponse(false, '❌ نام و نام خانوادگی الزامی است');
        }
        
        // اعتبارسنجی فرمت تاریخ تولد
        if (!empty($birth_date)) {
            $parts = explode('/', $birth_date);
            if (count($parts) !== 3 || !is_numeric(trim($parts[0])) || !is_numeric(trim($parts[1])) || !is_numeric(trim($parts[2]))) {
                error_log("Invalid birth date format: " . $birth_date);
                sendJsonResponse(false, '❌ فرمت تاریخ تولد نامعتبر است (باید به صورت YYYY/MM/DD باشد)');
            }
        }
        
        try {
            error_log("Starting database transaction");
            
            // شروع تراکنش
            $conn->beginTransaction();
            
            // ساخت query بروزرسانی
            $updateQuery = "UPDATE users SET 
                            first_name = :first_name,
                            last_name = :last_name,
                            birth_date = :birth_date,
                            address = :address,
                            father_name = :father_name,
                            father_phone = :father_phone,
                            mother_name = :mother_name,
                            mother_phone = :mother_phone,
                            email = :email";
            
            $params = [
                ':first_name' => $first_name,
                ':last_name' => $last_name,
                ':birth_date' => $birth_date ?: null,
                ':address' => $address,
                ':father_name' => $father_name,
                ':father_phone' => $father_phone,
                ':mother_name' => $mother_name,
                ':mother_phone' => $mother_phone,
                ':email' => $email ?: null,
                ':user_id' => $userId
            ];
            
            // بررسی درخواست تغییر رمز عبور
            // trim کردن و چک کردن خالی بودن واقعی
            $current_password = trim($current_password);
            $new_password = trim($new_password);
            $confirm_password = trim($confirm_password);
            
            error_log("Password fields after trim:");
            error_log("  current_password length: " . strlen($current_password));
            error_log("  new_password length: " . strlen($new_password));
            error_log("  confirm_password length: " . strlen($confirm_password));
            
            // چک می‌کنیم آیا کاربر واقعاً می‌خواهد رمز عبور را تغییر دهد
            // اگر هر سه فیلد خالی باشند، یعنی نمی‌خواهد رمز عبور را تغییر دهد
            $wantsPasswordChange = (strlen($current_password) > 0) || (strlen($new_password) > 0) || (strlen($confirm_password) > 0);
            
            if ($wantsPasswordChange) {
                error_log("Password change requested - validating...");
                
                // اگر می‌خواهد رمز عبور تغییر کند، هر سه فیلد باید پر شوند
                if (strlen($current_password) === 0) {
                    $conn->rollBack();
                    error_log("Validation failed: Current password empty");
                    sendJsonResponse(false, '❌ برای تغییر رمز عبور، باید رمز فعلی را وارد کنید');
                }
                
                if (strlen($new_password) === 0) {
                    $conn->rollBack();
                    error_log("Validation failed: New password empty");
                    sendJsonResponse(false, '❌ لطفاً رمز عبور جدید را وارد کنید');
                }
                
                if (strlen($confirm_password) === 0) {
                    $conn->rollBack();
                    error_log("Validation failed: Confirm password empty");
                    sendJsonResponse(false, '❌ لطفاً تأیید رمز عبور جدید را وارد کنید');
                }
                
                // بررسی تطابق رمز جدید و تأیید آن
                if ($new_password !== $confirm_password) {
                    $conn->rollBack();
                    error_log("Validation failed: Password mismatch");
                    sendJsonResponse(false, '❌ رمز عبور جدید و تأیید آن یکسان نیستند');
                }
                
                // بررسی طول رمز عبور
                if (strlen($new_password) < 8) {
                    $conn->rollBack();
                    error_log("Validation failed: Password too short (" . strlen($new_password) . " chars)");
                    sendJsonResponse(false, '❌ رمز عبور باید حداقل ۸ کاراکتر باشد');
                }
                
                // بررسی صحت رمز عبور فعلی
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$user || !password_verify($current_password, $user['password'])) {
                    $conn->rollBack();
                    error_log("Validation failed: Current password incorrect");
                    sendJsonResponse(false, '❌ رمز عبور فعلی اشتباه است');
                }
                
                // اضافه کردن رمز عبور جدید به query
                $updateQuery .= ", password = :password";
                $params[':password'] = password_hash($new_password, PASSWORD_DEFAULT);
                error_log("Password validation passed - password will be updated");
            } else {
                error_log("No password change requested - all password fields are empty");
            }
            
            $updateQuery .= " WHERE id = :user_id";
            
            error_log("Executing update query: " . $updateQuery);
            error_log("With params: " . print_r(array_diff_key($params, [':password' => '']), true));
            
            // اجرای query بروزرسانی
            $stmt = $conn->prepare($updateQuery);
            $result = $stmt->execute($params);
            
            if (!$result) {
                $conn->rollBack();
                $errorInfo = $stmt->errorInfo();
                error_log("Database error: " . print_r($errorInfo, true));
                sendJsonResponse(false, '❌ خطا در ذخیره اطلاعات: ' . print_r($errorInfo, true));
            }
            
            error_log("Update successful, affected rows: " . $stmt->rowCount());
            
            // بروزرسانی نام در session
            $_SESSION['user_name'] = $first_name . ' ' . $last_name;
            error_log("Session updated");
            
            // تایید تراکنش
            $conn->commit();
            error_log("Transaction committed");
            
            // ارسال ایمیل اطلاع‌رسانی (اختیاری)
            if (!empty($email)) {
                $subject = "بروزرسانی اطلاعات حساب کاربری";
                $message = "
                <html>
                <head>
                    <meta charset='UTF-8'>
                    <title>بروزرسانی اطلاعات</title>
                </head>
                <body dir='rtl' style='font-family: Tahoma, Arial, sans-serif;'>
                    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 15px; color: white;'>
                        <h2 style='text-align: center;'>✅ بروزرسانی موفق</h2>
                        <p>سلام <strong>{$first_name} {$last_name}</strong> عزیز!</p>
                        <p>اطلاعات حساب کاربری شما با موفقیت بروزرسانی شد.</p>
                        <p><strong>تاریخ بروزرسانی:</strong> " . date('Y/m/d H:i') . "</p>
                        <p style='margin-top: 20px;'>اگر این تغییر توسط شما انجام نشده، لطفاً فوراً با ما تماس بگیرید.</p>
                        <p style='text-align: center; margin-top: 30px;'>
                            با آرزوی موفقیت<br>
                            <strong>کلاس ستاره ماه</strong>
                        </p>
                    </div>
                </body>
                </html>";
                
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= "From: no-reply@starmah.ir" . "\r\n";
                
                @mail($email, $subject, $message, $headers);
            }
            
            sendJsonResponse(true, '✅ اطلاعات شما با موفقیت بروزرسانی شد!', [
                'user_name' => $_SESSION['user_name']
            ]);
            
        } catch (PDOException $e) {
            $conn->rollBack();
            error_log("PDO Exception in edit_profile: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            sendJsonResponse(false, '❌ خطا در بروزرسانی اطلاعات: ' . $e->getMessage());
        }
        
    } else {
        error_log("Unknown action: " . $action);
        sendJsonResponse(false, 'عملیات نامعتبر: ' . $action);
    }
    
} catch (PDOException $e) {
    error_log("PDO Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    sendJsonResponse(false, 'خطا در پردازش درخواست: ' . $e->getMessage());
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    sendJsonResponse(false, 'خطای عمومی در سیستم: ' . $e->getMessage());
}

// اگر تا اینجا رسید، یعنی هیچ action ای match نشده
error_log("No action matched - end of file reached");
sendJsonResponse(false, 'هیچ عملیاتی انجام نشد');
?>