<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit();
}

try {
    // دریافت تمام نتایج
    $stmt = $conn->prepare("
        SELECT 
            u.first_name,
            u.last_name,
            u.national_id,
            g.title as game_title,
            gr.score,
            gr.time_spent,
            gr.accuracy,
            gr.completed_at
        FROM game_results gr
        JOIN users u ON gr.student_id = u.id
        JOIN games g ON gr.game_id = g.id
        ORDER BY u.first_name, u.last_name, gr.completed_at DESC
    ");
    
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تنظیم header برای دانلود فایل
    $filename = 'game_results_' . date('Y-m-d_H-i-s') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // BOM برای نمایش صحیح فارسی در اکسل
    fwrite($output, "\xEF\xBB\xBF");
    
    // عنوان‌های ستون
    fputcsv($output, ['نام', 'نام خانوادگی', 'کد ملی', 'نام بازی', 'امتیاز', 'زمان (ثانیه)', 'دقت (%)', 'تاریخ بازی']);
    
    // داده‌ها
    foreach ($results as $result) {
        fputcsv($output, [
            $result['first_name'],
            $result['last_name'],
            $result['national_id'],
            $result['game_title'],
            $result['score'],
            $result['time_spent'],
            $result['accuracy'],
            date('Y/m/d H:i', strtotime($result['completed_at']))
        ]);
    }
    
    fclose($output);
    
} catch (Exception $e) {
    echo 'خطا در تولید گزارش: ' . $e->getMessage();
}
?>