<?php
/**
 * فایل: ajax/delete_student_result.php
 * حذف یک نتیجه خاص از دانش‌آموز
 */
session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$result_id = (int)($input['result_id'] ?? 0);

if ($result_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه نامعتبر']);
    exit;
}

try {
    $stmt = $conn->prepare("DELETE FROM game_results WHERE id = :id");
    $success = $stmt->execute([':id' => $result_id]);
    
    echo json_encode([
        'success' => $success,
        'message' => $success ? 'نتیجه با موفقیت حذف شد' : 'خطا در حذف'
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطای سرور']);
}
?>