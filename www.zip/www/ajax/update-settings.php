<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Collect settings data
$settings = [
    'school_name' => sanitize($_POST['school_name'] ?? 'دبستان ستاره ماه'),
    'academic_year' => sanitize($_POST['academic_year'] ?? '1403-1404'),
    'welcome_message' => sanitize($_POST['welcome_message'] ?? ''),
    'max_upload_size' => intval($_POST['max_upload_size'] ?? 20),
    'email_notifications' => isset($_POST['email_notifications']) ? 1 : 0,
    'homework_notifications' => isset($_POST['homework_notifications']) ? 1 : 0,
    'weekly_report' => isset($_POST['weekly_report']) ? 1 : 0,
    'site_status' => sanitize($_POST['site_status'] ?? 'active')
];

try {
    // Check if settings table exists, if not create it
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS site_settings (
            id INT PRIMARY KEY AUTO_INCREMENT,
            setting_key VARCHAR(100) UNIQUE,
            setting_value TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $stmt->execute();
    
    // Update each setting
    foreach ($settings as $key => $value) {
        $stmt = $conn->prepare("
            INSERT INTO site_settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()
        ");
        $stmt->execute([$key, $value, $value]);
    }
    
    // Update PHP configuration if possible
    if ($settings['max_upload_size'] > 0) {
        $maxSize = $settings['max_upload_size'] . 'M';
        @ini_set('upload_max_filesize', $maxSize);
        @ini_set('post_max_size', $maxSize);
    }
    
    // Create/Update .htaccess for upload settings
    $htaccessContent = "
# PHP Settings
<IfModule mod_php7.c>
    php_value upload_max_filesize {$settings['max_upload_size']}M
    php_value post_max_size {$settings['max_upload_size']}M
    php_value max_execution_time 300
    php_value max_input_time 300
</IfModule>
";
    
    $htaccessPath = dirname(__DIR__) . '/.htaccess';
    if (file_exists($htaccessPath)) {
        $currentContent = file_get_contents($htaccessPath);
        // Remove old PHP settings
        $currentContent = preg_replace('/# PHP Settings.*?<\/IfModule>/s', '', $currentContent);
        // Add new settings
        file_put_contents($htaccessPath, $currentContent . "\n" . $htaccessContent);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'تنظیمات با موفقیت ذخیره شد',
        'settings' => $settings
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ذخیره تنظیمات: ' . $e->getMessage()
    ]);
}
?>