# سایت آموزشی ستاره ماه

## مراحل نصب و راه‌اندازی

### 1. آپلود فایل‌ها
تمام فایل‌های زیر را در پوشه public_html هاست خود آپلود کنید:

#### فایل‌های اصلی:
- index.php
- config.php
- functions.php
- auth.php
- logout.php
- style.css
- script.js
- database.sql
- install.php
- edit-student.php
- .htaccess

#### فایل‌های sections/:
- about.php
- dashboard.php
- materials.php
- games.php
- podcast.php
- gallery.php
- feedback.php
- admin.php

#### فایل‌های ajax/:
- feedback.php
- save-score.php
- upload-podcast.php
- upload-gallery.php
- feedback-action.php
- get-student.php
- delete-student.php
- delete-material.php
- upload-material.php
- update-settings.php
- download-report.php
- backup-database.php
- clear-old-data.php
- reset-weekly-scores.php
- download-backup.php
- update-about.php
- get-settings.php

#### فایل‌های error/:
- 403.html
- 404.html
- 500.html

### 2. ایجاد پوشه‌های مورد نیاز
پوشه‌های زیر را در root سایت ایجاد کنید و دسترسی 755 بدهید:
```
/uploads
/uploads/materials
/uploads/podcasts
/uploads/gallery
/sections
/ajax
/backups
/temp
/error
```

### 3. راه‌اندازی دیتابیس
1. وارد phpMyAdmin شوید
2. دیتابیس qwaepiuv_starmah_db را انتخاب کنید
3. محتوای فایل database.sql را import کنید

### 4. ایجاد فایل‌های بخش‌ها
در پوشه sections فایل‌های زیر را ایجاد کنید:

#### sections/dashboard.php
```php
<section id="dashboard" class="section">
    <h2 style="text-align: center; color: #FF7F50; margin-bottom: 2rem;">داشبورد <?php echo htmlspecialchars($userName); ?></h2>
    <?php
    // Get student data
    $studentData = getStudentDashboardData($conn, $_SESSION['user_id']);
    ?>
    <div class="dashboard-stats">
        <div class="stat-card">
            <h4>امتیاز کل</h4>
            <span class="stat-number"><?php echo $studentData['total_score'] ?? 0; ?></span>
            <p>ستاره جمع‌آوری شده</p>
        </div>
        <div class="stat-card">
            <h4>رتبه در کلاس</h4>
            <span class="stat-number"><?php echo $studentData['class_rank'] ?? '-'; ?></span>
            <p>از 30 دانش‌آموز</p>
        </div>
    </div>
</section>
```

#### sections/materials.php
```php
<section id="materials" class="section">
    <h2 style="text-align: center; color: #FF7F50; margin-bottom: 2rem;">مطالب درسی</h2>
    <div class="subjects-grid">
        <?php
        $subjects = [
            'math' => ['icon' => '🔢', 'title' => 'ریاضی', 'desc' => 'ضرب و تقسیم'],
            'science' => ['icon' => '🔬', 'title' => 'علوم', 'desc' => 'جانداران و محیط زیست'],
            'persian' => ['icon' => '📖', 'title' => 'فارسی', 'desc' => 'خواندن و نوشتن'],
            'social' => ['icon' => '🗺️', 'title' => 'مطالعات اجتماعی', 'desc' => 'استان‌های ایران'],
            'religion' => ['icon' => '🕌', 'title' => 'دینی', 'desc' => 'داستان‌های قرآنی']
        ];
        
        foreach($subjects as $key => $subject):
        ?>
        <div class="subject-card" onclick="loadSubjectMaterials('<?php echo $key; ?>')">
            <div class="subject-icon"><?php echo $subject['icon']; ?></div>
            <h3><?php echo $subject['title']; ?></h3>
            <p><?php echo $subject['desc']; ?></p>
        </div>
        <?php endforeach; ?>
    </div>
</section>
```

#### sections/admin.php
```php
<section id="admin" class="section">
    <h2 style="text-align: center; color: #FF7F50; margin-bottom: 2rem;">پنل مدیریت</h2>
    <?php
    $adminStats = getAdminStats($conn);
    ?>
    <div class="dashboard-stats">
        <div class="stat-card" style="background: linear-gradient(135deg, #FFE4E1, #FFA07A);">
            <h4>تعداد دانش‌آموزان</h4>
            <span class="stat-number"><?php echo $adminStats['totalStudents']; ?></span>
            <p>فعال در سیستم</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #E0F2E9, #98FB98);">
            <h4>بازخوردهای جدید</h4>
            <span class="stat-number"><?php echo $adminStats['newFeedbacks']; ?></span>
            <p>در انتظار بررسی</p>
        </div>
    </div>
</section>
```

### 5. ایجاد فایل‌های AJAX
در پوشه ajax فایل‌های زیر را ایجاد کنید:

#### ajax/feedback.php
```php
<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$data = [
    'parent_name' => sanitize($_POST['parent_name'] ?? ''),
    'student_name' => sanitize($_POST['student_name'] ?? ''),
    'subject' => sanitize($_POST['subject'] ?? ''),
    'message' => sanitize($_POST['message'] ?? '')
];

if (saveFeedback($conn, $data)) {
    echo json_encode([
        'success' => true,
        'aiResponse' => 'با تشکر از بازخورد شما. پیام شما دریافت شد و در اسرع وقت بررسی خواهد شد.'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'خطا در ثبت بازخورد']);
}
?>
```

### 6. تنظیمات امنیتی
فایل .htaccess در root سایت:
```apache
# Security headers
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"

# Protect sensitive files
<FilesMatch "^(config\.php|database\.sql)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Enable HTTPS redirect
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 7. فایل‌های AJAX
در پوشه ajax فایل‌های زیر را آپلود کنید:
- feedback.php
- save-score.php
- upload-podcast.php
- upload-gallery.php
- feedback-action.php
- get-student.php
- delete-student.php
- delete-material.php
- upload-material.php
- update-settings.php
- download-report.php
- backup-database.php
- clear-old-data.php
- reset-weekly-scores.php
- download-backup.php
- update-about.php

### 7. اطلاعات ورود پیش‌فرض
- **مدیر سیستم**: 
  - نام کاربری: admin
  - رمز عبور: admin123
- **دانش‌آموز نمونه**:
  - نام کاربری: ali123
  - رمز عبور: admin123

### 8. نکات مهم
1. حتماً رمز عبور admin را بعد از اولین ورود تغییر دهید
2. مطمئن شوید که دسترسی پوشه uploads به 755 تنظیم شده باشد
3. برای امنیت بیشتر، فایل config.php را در پوشه‌ای خارج از public_html قرار دهید

### پشتیبانی
در صورت بروز مشکل، لطفاً بررسی کنید:
- نسخه PHP حداقل 7.4 باشد
- PDO MySQL فعال باشد
- دسترسی‌های پوشه‌ها صحیح باشد