<?php
header('Content-Type: application/json; charset=utf-8');

// Allow cross-origin requests if needed
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataFile = '../data/exams.json';
$dataDir = '../data/';

// Create data directory if not exists
if (!file_exists($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// Initialize data file if not exists
if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([]));
}

// Load exams from file
function loadExams() {
    global $dataFile;
    $content = file_get_contents($dataFile);
    return json_decode($content, true) ?: [];
}

// Save exams to file
function saveExams($exams) {
    global $dataFile;
    return file_put_contents($dataFile, json_encode($exams, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    switch ($action) {
        case 'save':
            if (isset($_POST['exam_data'])) {
                $examData = json_decode($_POST['exam_data'], true);
                
                if (!$examData || !isset($examData['name'])) {
                    echo json_encode(['success' => false, 'message' => 'داده‌های آزمون نامعتبر است.']);
                    exit;
                }
                
                $exams = loadExams();
                
                // Generate new ID
                $newId = time() . '_' . uniqid();
                
                // Check if exam with same name exists and update it
                $found = false;
                foreach ($exams as $key => $exam) {
                    if ($exam['name'] === $examData['name']) {
                        $exams[$key] = array_merge($examData, [
                            'id' => $exam['id'],
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                        $found = true;
                        break;
                    }
                }
                
                if (!$found) {
                    $examData['id'] = $newId;
                    $examData['created_at'] = date('Y-m-d H:i:s');
                    $examData['updated_at'] = date('Y-m-d H:i:s');
                    $exams[] = $examData;
                }
                
                if (saveExams($exams)) {
                    echo json_encode(['success' => true, 'message' => 'آزمون با موفقیت ذخیره شد.', 'id' => $found ? $exam['id'] : $newId]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'خطا در ذخیره فایل.']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'داده‌های آزمون ارسال نشده است.']);
            }
            break;
            
        case 'get_all':
            $exams = loadExams();
            $result = array_map(function($exam) {
                return [
                    'id' => $exam['id'],
                    'name' => $exam['name'],
                    'subject' => isset($exam['subject']) ? $exam['subject'] : '',
                    'created_at' => isset($exam['created_at']) ? $exam['created_at'] : '',
                    'updated_at' => isset($exam['updated_at']) ? $exam['updated_at'] : ''
                ];
            }, $exams);
            echo json_encode(['success' => true, 'data' => array_values($result)]);
            break;
            
        case 'get_one':
            if (isset($_POST['id'])) {
                $id = $_POST['id'];
                $exams = loadExams();
                
                $found = null;
                foreach ($exams as $exam) {
                    if ($exam['id'] === $id) {
                        $found = $exam;
                        break;
                    }
                }
                
                if ($found) {
                    echo json_encode(['success' => true, 'data' => $found]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'آزمون یافت نشد.']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'شناسه آزمون مشخص نشده است.']);
            }
            break;
            
        case 'delete':
            if (isset($_POST['id'])) {
                $id = $_POST['id'];
                $exams = loadExams();
                
                $newExams = array_filter($exams, function($exam) use ($id) {
                    return $exam['id'] !== $id;
                });
                
                if (count($newExams) < count($exams)) {
                    if (saveExams(array_values($newExams))) {
                        echo json_encode(['success' => true, 'message' => 'آزمون با موفقیت حذف شد.']);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'خطا در ذخیره تغییرات.']);
                    }
                } else {
                    echo json_encode(['success' => false, 'message' => 'آزمون یافت نشد.']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'شناسه آزمون مشخص نشده است.']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'عملیات نامعتبر است.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر است.']);
}
?>
