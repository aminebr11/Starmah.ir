<?php
session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'عدم دسترسی']);
    exit;
}

try {
    // دریافت پارامترها
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
    
    $offset = ($page - 1) * $limit;
    
    // ساخت کوئری پایه
    $where = "WHERE 1=1";
    $params = [];
    
    // فیلتر جستجو
    if (!empty($search)) {
        $where .= " AND (title LIKE ? OR id = ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $search;
    }
    
    // فیلتر وضعیت
    if ($status !== 'all') {
        $where .= " AND is_active = ?";
        $params[] = (int)$status;
    }
    
    // مرتب‌سازی
    $orderBy = "ORDER BY ";
    switch ($sort) {
        case 'date_asc':
            $orderBy .= "created_at ASC";
            break;
        case 'title_asc':
            $orderBy .= "title ASC";
            break;
        case 'questions_desc':
            $orderBy .= "questions_count DESC";
            break;
        default:
            $orderBy .= "created_at DESC";
    }
    
    // شمارش کل
    $countQuery = "SELECT COUNT(*) as total FROM quizzes $where";
    $stmt = $conn->prepare($countQuery);
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $totalResult = $stmt->get_result()->fetch_assoc();
    $totalItems = $totalResult['total'];
    
    // دریافت آزمون‌ها
    $query = "
        SELECT 
            q.*,
            (SELECT COUNT(*) FROM quiz_attempts WHERE quiz_id = q.id) as attempts_count,
            (SELECT AVG(score) FROM quiz_attempts WHERE quiz_id = q.id) as avg_score
        FROM quizzes q
        $where
        $orderBy
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $types = str_repeat('s', count($params) - 2) . 'ii';
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    $exams = [];
    while ($row = $result->fetch_assoc()) {
        // دریافت تعداد سوالات فعال
        $questionsStmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM quiz_questions 
            WHERE quiz_id = ? AND is_active = 1
        ");
        $questionsStmt->bind_param('i', $row['id']);
        $questionsStmt->execute();
        $questionsCount = $questionsStmt->get_result()->fetch_assoc()['count'];
        
        $exams[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'exam_date' => $row['exam_date'],
            'exam_time' => $row['exam_time'],
            'duration_minutes' => $row['duration_minutes'],
            'is_active' => $row['is_active'],
            'is_visible' => $row['is_visible'],
            'questions_count' => $questionsCount,
            'total_points' => $row['total_points'],
            'attempts_count' => (int)$row['attempts_count'],
            'avg_score' => round($row['avg_score'] ?? 0, 1),
            'created_at' => $row['created_at']
        ];
    }
    
    // آمار کلی
    $statsQuery = "
        SELECT 
            COUNT(*) as total_exams,
            SUM(is_active) as active_exams,
            SUM(questions_count) as total_questions
        FROM quizzes
    ";
    $statsResult = $conn->query($statsQuery)->fetch_assoc();
    
    $attemptsQuery = "SELECT COUNT(*) as total FROM quiz_attempts";
    $totalAttempts = $conn->query($attemptsQuery)->fetch_assoc()['total'];
    
    echo json_encode([
        'success' => true,
        'data' => $exams,
        'pagination' => [
            'current_page' => $page,
            'total_pages' => ceil($totalItems / $limit),
            'total_items' => $totalItems,
            'items_per_page' => $limit
        ],
        'stats' => [
            'total_exams' => (int)$statsResult['total_exams'],
            'active_exams' => (int)$statsResult['active_exams'],
            'total_questions' => (int)$statsResult['total_questions'],
            'total_attempts' => (int)$totalAttempts
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت لیست آزمون‌ها',
        'error' => $e->getMessage()
    ]);
}
?>