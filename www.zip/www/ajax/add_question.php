<?php
// ajax/add_question.php - اصلاح شده برای ساختار صحیح جداول
require_once '../config.php';
require_once '../functions.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    $raw_input = file_get_contents('php://input');
    error_log("Question raw input: " . $raw_input);
    
    $input = json_decode($raw_input, true);
    
    if (!$input) {
        throw new Exception('داده‌های ورودی نامعتبر: ' . json_last_error_msg());
    }
    
    error_log("Question input data: " . print_r($input, true));
    
    // استخراج داده‌ها مطابق با ساختار جدول quiz_questions
    $quiz_id = (int)($input['exam_id'] ?? 0);  // quiz_id در جدول
    $question_text = trim($input['question_text'] ?? '');
    $question_type = trim($input['question_type'] ?? ''); // enum('mcq','tf','short')
    $points = (int)($input['points'] ?? 1);
    
    // Validation
    if (!$quiz_id || !$question_text || !$question_type) {
        throw new Exception('فیلدهای ضروری کامل نیست');
    }
    
    if (!in_array($question_type, ['mcq', 'tf', 'short'])) {
        throw new Exception('نوع سوال نامعتبر - باید mcq، tf یا short باشد');
    }
    
    if ($points < 1 || $points > 10) {
        throw new Exception('امتیاز سوال باید بین 1 تا 10 باشد');
    }
    
    // Check if quiz exists in quizzes table
    $stmt = $conn->prepare("SELECT id FROM quizzes WHERE id = ?");
    $stmt->execute([$quiz_id]);
    if (!$stmt->fetch()) {
        throw new Exception('آزمون مورد نظر یافت نشد');
    }
    
    // Get next question_order
    $stmt = $conn->prepare("SELECT COALESCE(MAX(question_order), 0) + 1 as next_order FROM quiz_questions WHERE quiz_id = ?");
    $stmt->execute([$quiz_id]);
    $next_order = $stmt->fetchColumn();
    
    // Prepare question_data (JSON field) based on type
    $question_data = [];
    
    if ($question_type === 'mcq') {
        // Multiple choice
        $options = $input['options'] ?? [];
        
        if (empty($options) || count($options) < 2) {
            throw new Exception('حداقل 2 گزینه برای سوال چهارگزینه‌ای لازم است');
        }
        
        $valid_options = [];
        $correct_indices = [];
        
        foreach ($options as $index => $option) {
            if (!empty(trim($option['text']))) {
                $valid_options[] = [
                    'text' => trim($option['text']),
                    'is_correct' => (bool)($option['is_correct'] ?? false)
                ];
                
                if ($option['is_correct'] ?? false) {
                    $correct_indices[] = count($valid_options) - 1;
                }
            }
        }
        
        if (empty($correct_indices)) {
            throw new Exception('حداقل یک گزینه صحیح انتخاب کنید');
        }
        
        $question_data = [
            'options' => $valid_options,
            'correct_indices' => $correct_indices
        ];
        
    } elseif ($question_type === 'tf') {
        // True/False
        $correct_answer = $input['correct_answer'] ?? '';
        
        if (!in_array($correct_answer, ['true', 'false'])) {
            throw new Exception('برای سوال درست/نادرست، پاسخ صحیح را انتخاب کنید');
        }
        
        $question_data = [
            'correct_answer' => ($correct_answer === 'true')
        ];
        
    } elseif ($question_type === 'short') {
        // Short answer
        $expected_answer = trim($input['expected_answer'] ?? '');
        $question_data = [
            'expected_answer' => $expected_answer
        ];
    }
    
    // Start transaction
    $conn->beginTransaction();
    
    try {
        // Insert question into quiz_questions table - مطابق با ساختار واقعی
        $stmt = $conn->prepare("
            INSERT INTO quiz_questions (
                quiz_id, 
                question_text, 
                question_type, 
                question_data, 
                points, 
                question_order, 
                is_active
            ) VALUES (?, ?, ?, ?, ?, ?, 1)
        ");
        
        $result = $stmt->execute([
            $quiz_id,
            $question_text,
            $question_type,
            json_encode($question_data, JSON_UNESCAPED_UNICODE),
            $points,
            $next_order
        ]);
        
        if (!$result) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception('خطا در ذخیره سوال: ' . $errorInfo[2]);
        }
        
        $question_id = $conn->lastInsertId();
        
        // Update quiz questions_count and total_points in quizzes table
        $stmt = $conn->prepare("
            UPDATE quizzes 
            SET questions_count = (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = ? AND is_active = 1),
                total_points = (SELECT COALESCE(SUM(points), 0) FROM quiz_questions WHERE quiz_id = ? AND is_active = 1)
            WHERE id = ?
        ");
        $stmt->execute([$quiz_id, $quiz_id, $quiz_id]);
        
        // Commit transaction
        $conn->commit();
        
        error_log("Question added successfully with ID: $question_id");
        
        echo json_encode([
            'success' => true,
            'message' => 'سوال با موفقیت اضافه شد',
            'question_id' => (int)$question_id,
            'question_order' => (int)$next_order,
            'question_data' => $question_data
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Add Question Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    error_log("Add Question PDO Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>