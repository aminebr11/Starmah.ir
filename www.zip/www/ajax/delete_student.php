<?php
// ../ajax/delete_student.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once '../config.php';
require_once '../functions.php';

try {
    // فقط ادمین
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }

    // فقط درخواست Ajax/JSON
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر است']);
        exit;
    }

    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    $studentId = isset($data['student_id']) ? (int)$data['student_id'] : 0;

    if ($studentId <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'student_id نامعتبر است']);
        exit;
    }

    // شروع تراکنش
    $conn->beginTransaction();

    // قفل/بررسی وجود کاربر و اینکه دانش‌آموز است
    $stmt = $conn->prepare("SELECT id, user_type FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$studentId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    if ($user['user_type'] !== 'student') {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'فقط دانش‌آموز قابل حذف است (ادمین حذف نمی‌شود)']);
        exit;
    }

    // ترتیب حذف رکوردهای وابسته (فرزندها → والد)
    // نکته: xp_history ممکن است کلید خارجی به game_results داشته باشد،
    // بنابراین اول xp_history و سپس game_results حذف می‌شود.
    $deletions = [
        // جدول‌هایی که ستون student_id دارند
        ["DELETE FROM xp_history         WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM weekly_xp_summary  WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM student_xp        WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM activity_results   WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM discipline_records WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM feedbacks          WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM game_results       WHERE student_id = ?",        [$studentId]],
        ["DELETE FROM quiz_attempts      WHERE student_id = ?",        [$studentId]],
        // جدول visit با ستون user_id
        ["DELETE FROM visits             WHERE user_id    = ?",        [$studentId]],
        // در انتها خود کاربر
        ["DELETE FROM users              WHERE id = ? LIMIT 1",        [$studentId]],
    ];

    $totalAffected = 0;
    foreach ($deletions as [$sql, $params]) {
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $totalAffected += $stmt->rowCount();
    }

    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'دانش‌آموز و تمام سوابق وابسته با موفقیت حذف شد.',
        'affected_rows' => $totalAffected
    ]);
} catch (Throwable $e) {
    if ($conn && $conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در حذف کاربر: ' . $e->getMessage()
    ]);
}
