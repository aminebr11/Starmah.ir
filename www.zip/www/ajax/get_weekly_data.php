<?php
// جلوگیری از نمایش خطاها در خروجی
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);

require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// یک تابع برای ارسال پاسخ JSON و خروج
function send_json_response($success, $message = '', $data = null) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit();
}

try {
    if (!isset($_GET['week']) || empty(trim($_GET['week']))) {
        send_json_response(false, 'پارامتر هفته ارسال نشده است.');
    }

    list($year, $month, $weekNumber) = explode('-', $_GET['week']);

    // کوئری برای دریافت تمام دانش‌آموزان، حتی کسانی که امتیازی ندارند
    $sql = "
        SELECT 
            u.id, u.first_name, u.last_name,
            COALESCE(w.total_xp, 0) as total_xp,
            COALESCE(w.`rank`, 0) as rank
        FROM users u
        LEFT JOIN weekly_xp_summary w ON u.id = w.student_id 
            AND w.year = :year AND w.month = :month AND w.week_number = :weekNumber
        WHERE u.user_type = 'student'
        ORDER BY w.total_xp DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([':year' => $year, ':month' => $month, ':weekNumber' => $weekNumber]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // محاسبه رتبه برای دانش‌آموزانی که در جدول خلاصه نیستند (امتیاز صفر)
    $rank = 1;
    foreach ($students as &$student) {
        if ($student['rank'] == 0) {
            $student['rank'] = $rank++;
        } else {
            $rank = $student['rank'];
        }
    }

    send_json_response(true, 'داده‌ها با موفقیت بارگذاری شد.', $students);

} catch (Exception $e) {
    // لاگ کردن خطا برای بررسی‌های بعدی
    error_log("Error in get_weekly_data_all.php: " . $e->getMessage());
    
    // ارسال یک پاسخ خطای JSON به کاربر
    send_json_response(false, 'خطایی در سرور رخ داد. لطفاً بعداً تلاش کنید.');
}
?>