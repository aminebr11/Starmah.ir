<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// لاگ
file_put_contents('debug.log', date('Y-m-d H:i:s') . " - adjust-level.php called\n", FILE_APPEND);

try {
    // بررسی دسترسی
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // دریافت داده‌ها
    $rawInput = file_get_contents('php://input');
    file_put_contents('debug.log', "Level adjust raw input: " . $rawInput . "\n", FILE_APPEND);
    
    if (empty($rawInput)) {
        echo json_encode(['success' => false, 'message' => 'هیچ داده‌ای دریافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $input = json_decode($rawInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'خطا در پردازش JSON'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $studentId = $input['student_id'] ?? null;
    $newLevel = (int)($input['new_level'] ?? 0);
    $reason = trim($input['reason'] ?? '');

    file_put_contents('debug.log', "Level data: studentId=$studentId, newLevel=$newLevel, reason=$reason\n", FILE_APPEND);

    // اعتبارسنجی
    if (!$studentId || $newLevel < 1 || $newLevel > 5 || empty($reason)) {
        echo json_encode(['success' => false, 'message' => 'لطفاً همه فیلدها را صحیح پر کنید'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // بررسی وجود دانش‌آموز
    $checkStmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$studentId]);
    $student = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // دریافت سطح فعلی
    $xpStmt = $conn->prepare("SELECT level FROM student_xp WHERE student_id = ?");
    $xpStmt->execute([$studentId]);
    $currentLevel = $xpStmt->fetchColumn();

    if (!$currentLevel) {
        // ایجاد رکورد جدید اگر وجود ندارد
        $insertStmt = $conn->prepare("
            INSERT INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level) 
            VALUES (?, 0, 0, 0, 0, 0, 0, ?)
        ");
        $insertStmt->execute([$studentId, $newLevel]);
        $currentLevel = 1;
    } else {
        // بروزرسانی سطح
        $updateStmt = $conn->prepare("UPDATE student_xp SET level = ? WHERE student_id = ?");
        $updateStmt->execute([$newLevel, $studentId]);
    }

    // ثبت تاریخچه
    try {
        $historyStmt = $conn->prepare("
            INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) 
            VALUES (?, 'level_adjustment', ?, ?, ?, NOW())
        ");
        
        $levelChange = $newLevel - $currentLevel;
        $historyStmt->execute([$studentId, $levelChange, $reason, $_SESSION['user_id']]);
    } catch (Exception $e) {
        file_put_contents('debug.log', "Level history insert failed: " . $e->getMessage() . "\n", FILE_APPEND);
    }

    $response = [
        'success' => true,
        'message' => "سطح {$student['first_name']} {$student['last_name']} از {$currentLevel} به {$newLevel} تغییر کرد",
        'old_level' => $currentLevel,
        'new_level' => $newLevel,
        'student' => $student
    ];

    file_put_contents('debug.log', "Level adjust success: " . print_r($response, true) . "\n", FILE_APPEND);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    $errorResponse = [
        'success' => false,
        'message' => 'خطا در تغییر سطح: ' . $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ];
    
    file_put_contents('debug.log', "Level adjust error: " . print_r($errorResponse, true) . "\n", FILE_APPEND);
    echo json_encode($errorResponse, JSON_UNESCAPED_UNICODE);
}
?>