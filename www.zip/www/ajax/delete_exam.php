// ===============================
// فایل 4: ajax/delete_exam.php
// ===============================
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$config_paths = ['../config.php', '../../config.php'];
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفا وارد شوید']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $examName = $input['examName'] ?? '';
    
    if (empty($examName)) {
        throw new Exception('نام آزمون مشخص نشده است');
    }
    
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("DELETE FROM exam_questions WHERE exam_name = ? AND teacher_id = ?");
    $stmt->execute([$examName, $teacher_id]);
    
    $affected = $stmt->rowCount();
    
    echo json_encode([
        'success' => true,
        'message' => "$affected سوال حذف شد"
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>