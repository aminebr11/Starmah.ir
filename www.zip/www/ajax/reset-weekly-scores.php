<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $conn->beginTransaction();
    
    // Get current weekly scores before reset (for logging)
    $stmt = $conn->prepare("
        SELECT u.id, u.first_name, u.last_name, s.weekly_stars 
        FROM users u 
        JOIN students s ON u.id = s.user_id 
        WHERE s.weekly_stars > 0
    ");
    $stmt->execute();
    $studentsWithStars = $stmt->fetchAll();
    
    // Create weekly report before reset
    $reportData = [];
    foreach($studentsWithStars as $student) {
        $reportData[] = [
            'student_id' => $student['id'],
            'name' => $student['first_name'] . ' ' . $student['last_name'],
            'weekly_stars' => $student['weekly_stars']
        ];
    }
    
    // Save weekly report to a log table (create if not exists)
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS weekly_reports (
            id INT PRIMARY KEY AUTO_INCREMENT,
            week_ending DATE,
            report_data JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $stmt->execute();
    
    // Insert this week's report
    $stmt = $conn->prepare("
        INSERT INTO weekly_reports (week_ending, report_data) 
        VALUES (CURDATE(), ?)
    ");
    $stmt->execute([json_encode($reportData, JSON_UNESCAPED_UNICODE)]);
    
    // Reset all weekly stars to 0
    $stmt = $conn->prepare("UPDATE students SET weekly_stars = 0");
    $stmt->execute();
    $affectedStudents = $stmt->rowCount();
    
    // Update class ranks based on total scores
    $stmt = $conn->prepare("
        UPDATE students s1
        JOIN (
            SELECT user_id,
                   @rank := @rank + 1 as new_rank
            FROM students, (SELECT @rank := 0) r
            ORDER BY total_score DESC
        ) s2 ON s1.user_id = s2.user_id
        SET s1.class_rank = s2.new_rank
    ");
    $stmt->execute();
    
    // Send notification emails to parents if enabled
    $stmt = $conn->prepare("
        SELECT setting_value 
        FROM site_settings 
        WHERE setting_key = 'weekly_report'
    ");
    $stmt->execute();
    $sendReports = $stmt->fetchColumn();
    
    if ($sendReports == '1' && !empty($reportData)) {
        // Send weekly reports to parents
        sendWeeklyReports($conn, $reportData);
    }
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'امتیازات هفتگی با موفقیت ریست شد',
        'affected_students' => $affectedStudents,
        'report_saved' => true,
        'top_students' => array_slice($reportData, 0, 3) // Top 3 students
    ]);
    
} catch(Exception $e) {
    $conn->rollBack();
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ریست امتیازات: ' . $e->getMessage()
    ]);
}

// Send weekly reports to parents
function sendWeeklyReports($conn, $reportData) {
    foreach($reportData as $studentData) {
        // Get parent email
        $stmt = $conn->prepare("
            SELECT email, father_name, mother_name 
            FROM users 
            WHERE id = ? AND email IS NOT NULL
        ");
        $stmt->execute([$studentData['student_id']]);
        $parent = $stmt->fetch();
        
        if ($parent && $parent['email']) {
            $subject = "گزارش هفتگی - " . $studentData['name'];
            $message = "
            <html>
            <head>
                <title>گزارش هفتگی</title>
            </head>
            <body style='font-family: Tahoma, Arial; direction: rtl;'>
                <h2>گزارش هفتگی عملکرد</h2>
                <p>والدین گرامی {$parent['father_name']} و {$parent['mother_name']}</p>
                <p>عملکرد {$studentData['name']} در این هفته:</p>
                <div style='background: #f0f0f0; padding: 15px; border-radius: 10px;'>
                    <p><strong>تعداد ستاره‌های کسب شده:</strong> {$studentData['weekly_stars']} ⭐</p>
                </div>
                <p>برای مشاهده جزئیات بیشتر، به سایت مراجعه فرمایید.</p>
                <p>با آرزوی موفقیت</p>
                <p>کلاس چهارم - خانم نجمه محمودی</p>
            </body>
            </html>
            ";
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: no-reply@starmah.ir' . "\r\n";
            
            @mail($parent['email'], $subject, $message, $headers);
        }
    }
}
?>