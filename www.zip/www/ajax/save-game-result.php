<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');

// بررسی ورود کاربر
if (!isLoggedIn() || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'کاربر وارد سیستم نشده']);
    exit;
}

$student_id = (int)$_SESSION['user_id'];

// بررسی وجود کاربر
try {
    $stmt = $conn->prepare("SELECT id, user_type FROM users WHERE id = ? AND user_type = 'student' AND is_active = 1");
    $stmt->execute([$student_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'کاربر معتبر نیست یا غیرفعال است']);
        exit;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی کاربر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input && !empty($_POST)) {
    $input = $_POST;
}

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر']);
    exit;
}

$game_id = (int)($input['game_id'] ?? 0);
$score = (int)($input['score'] ?? 0);
$time_spent = (int)($input['time_spent'] ?? 0);
$accuracy = (float)($input['accuracy'] ?? 0);

if ($game_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر']);
    exit;
}

try {
    // گرفتن اطلاعات بازی
    $stmt = $conn->prepare("
        SELECT g.max_score, g.title, g.category_id
        FROM games g
        WHERE g.id = ? AND g.is_active = 1
    ");
    $stmt->execute([$game_id]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
        exit;
    }
    
    $max_possible_score = (int)($game['max_score'] ?? 100);
    $category_id = (int)$game['category_id'];
    $game_title = $game['title'];
    
    // بررسی وجود رکورد قبلی
    $stmt = $conn->prepare("SELECT id, score, attempts FROM game_results WHERE student_id = ? AND game_id = ?");
    $stmt->execute([$student_id, $game_id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $is_first_time = !$existing; // فقط اگر رکورد وجود نداشته باشد، اولین بار است
    $game_result_id = null; // متغیر برای نگهداری ID نتیجه بازی
    
    if ($existing) {
        $game_result_id = $existing['id']; // استفاده از ID موجود
        
        if ($score > $existing['score']) {
            $stmt = $conn->prepare("
                UPDATE game_results SET 
                    score = ?, 
                    max_possible_score = ?, 
                    accuracy = ?, 
                    time_spent = ?, 
                    attempts = attempts + 1,
                    completed_at = NOW()
                WHERE student_id = ? AND game_id = ?
            ");
            $stmt->execute([$score, $max_possible_score, $accuracy, $time_spent, $student_id, $game_id]);
            $action = 'updated';
        } else {
            $stmt = $conn->prepare("UPDATE game_results SET attempts = attempts + 1 WHERE student_id = ? AND game_id = ?");
            $stmt->execute([$student_id, $game_id]);
            $action = 'attempt_added';
        }
    } else {
        // ایجاد رکورد جدید
        $stmt = $conn->prepare("
            INSERT INTO game_results (student_id, game_id, score, max_possible_score, accuracy, time_spent, attempts, completed_at) 
            VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
        ");
        $stmt->execute([$student_id, $game_id, $score, $max_possible_score, $accuracy, $time_spent]);
        
        // دریافت ID رکورد جدید ایجاد شده
        $game_result_id = $conn->lastInsertId();
        $action = 'inserted';
    }
    
    // محاسبه XP
    $base_xp = 10;
    $score_bonus = ($score / $max_possible_score) * 20;
    $accuracy_bonus = ($accuracy / 100) * 10;
    $time_bonus = max(0, (300 - $time_spent) / 60);
    $xp_earned = (int)($base_xp + $score_bonus + $accuracy_bonus + $time_bonus);
    
    // ذخیره XP فقط در اولین بار
    if ($is_first_time && $game_result_id) {
        updateStudentXPSafe($conn, $student_id, $category_id, $xp_earned);

        // ذخیره در جدول xp_history با game_result_id
        $subject_text = "مربوط به بازی " . $game_title;
        $reason_text = "دریافت XP از بازی " . $game_title;
        $stmt = $conn->prepare("
            INSERT INTO xp_history (student_id, game_result_id, subject, amount, reason, admin_id, created_at)
            VALUES (?, ?, ?, ?, ?, 18, NOW())
        ");
        $stmt->execute([$student_id, $game_result_id, $subject_text, $xp_earned, $reason_text]);
    }
    
    // دریافت امتیاز کل جدید
    $stmt = $conn->prepare("SELECT total_xp FROM student_xp WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $total_xp = $stmt->fetchColumn() ?: 0;
    
    echo json_encode([
        'success' => true,
        'message' => 'نتیجه با موفقیت ذخیره شد',
        'action' => $action,
        'score' => $score,
        'max_score' => $max_possible_score,
        'accuracy' => $accuracy,
        'time_spent' => $time_spent,
        'xp_earned' => $is_first_time ? $xp_earned : 0,
        'total_xp' => $total_xp,
        'game_id' => $game_id,
        'game_result_id' => $game_result_id
    ]);
    
} catch (Exception $e) {
    error_log("Game result save error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ذخیره نتیجه',
        'error' => $e->getMessage()
    ]);
}

// تابع بروزرسانی XP
function updateStudentXPSafe($conn, $student_id, $category_id, $xp_amount) {
    $category_map = [
        1  => 'math_xp',
        13 => 'persian_xp',
        14 => 'science_xp',
        15 => 'social_xp',
        16 => 'religion_xp',
        17 => 'english_xp'
    ];
    
    $subject_field = $category_map[$category_id] ?? 'math_xp';
    
    try {
        $stmt = $conn->prepare("SELECT id FROM student_xp WHERE student_id = ?");
        $stmt->execute([$student_id]);
        
        if ($stmt->fetch()) {
            $stmt = $conn->prepare("
                UPDATE student_xp SET 
                    {$subject_field} = {$subject_field} + ?,
                    total_xp = total_xp + ?,
                    level = FLOOR((total_xp + ?) / 100) + 1
                WHERE student_id = ?
            ");
            $stmt->execute([$xp_amount, $xp_amount, $xp_amount, $student_id]);
        } else {
            $level = floor($xp_amount / 100) + 1;
            $stmt = $conn->prepare("
                INSERT INTO student_xp (student_id, {$subject_field}, total_xp, level) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$student_id, $xp_amount, $xp_amount, $level]);
        }
        return true;
    } catch (Exception $e) {
        error_log("UpdateStudentXP error: " . $e->getMessage());
        return false;
    }
}
?>