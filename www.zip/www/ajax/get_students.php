
<?php
// فایل اصلاح شده: ajax/get_students.php
require_once '../config.php';
require_once '../functions.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');

try {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    if (!isAdmin()) {
        echo json_encode([
            'success' => false, 
            'message' => 'دسترسی غیرمجاز'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // دریافت ورودی
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (!$input) {
        $input = $_POST;
    }
    
    $action = $input['action'] ?? $_GET['action'] ?? 'get_students_list';
    
    if (empty($action)) {
        $action = 'get_students_list';
    }
    
    if ($action === 'get_students_list') {
        $stmt = $conn->prepare("
            SELECT 
                id, 
                CONCAT(first_name, ' ', last_name) as name,
                email,
                is_active
            FROM users 
            WHERE user_type = 'student' AND is_active = 1
            ORDER BY first_name, last_name
        ");
        $stmt->execute();
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'students' => $students,
            'count' => count($students)
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'عملیات نامشخص: ' . $action
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    error_log("GET_STUDENTS ERROR: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>