<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

$config_loaded = false;
$functions_loaded = false;

$config_paths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$functions_paths = ['../functions.php', '../../functions.php', dirname(__DIR__) . '/functions.php'];

foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

foreach ($functions_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functions_loaded = true;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!$config_loaded || !$functions_loaded) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

try {
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("
        SELECT 
            subject,
            COUNT(*) as count,
            MAX(created_at) as updated_at
        FROM exam_questions 
        WHERE teacher_id = ?
        GROUP BY subject
        ORDER BY updated_at DESC
    ");
    
    $stmt->execute([$teacher_id]);
    $subjects = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $subjects[] = [
            'subject' => $row['subject'],
            'count' => (int)$row['count'],
            'updated_at' => $row['updated_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'data' => $subjects
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => []
    ]);
}
?>