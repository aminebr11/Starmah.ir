<?php
// شروع session برای بررسی دسترسی ادمین
session_start();

// فعال‌سازی نمایش خطاها (در محیط توسعه)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// تنظیم هدر JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // بررسی وجود فایل‌های ضروری
    $config_path = dirname(__DIR__) . '/config.php';
    $functions_path = dirname(__DIR__) . '/functions.php';
    
    if (!file_exists($config_path)) {
        throw new Exception('فایل config.php یافت نشد در مسیر: ' . $config_path);
    }
    
    if (!file_exists($functions_path)) {
        throw new Exception('فایل functions.php یافت نشد در مسیر: ' . $functions_path);
    }
    
    // include کردن فایل‌های ضروری
    require_once $config_path;
    require_once $functions_path;
    
    // بررسی اتصال به پایگاه داده
    if (!isset($conn) || $conn === null) {
        throw new Exception('اتصال به پایگاه داده برقرار نیست');
    }
    
    // بررسی دسترسی ادمین
    if (!isAdmin()) {
        throw new Exception('شما مجوز انجام این کار را ندارید');
    }
    
    // بررسی method درخواست
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method درخواست نامعتبر است');
    }
    
    // دریافت و validation داده‌ها
    $title = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $jalali_due_date = trim($_POST['due_date'] ?? '');
    
    // بررسی فیلدهای الزامی
    if (empty($title)) {
        throw new Exception('عنوان تکلیف الزامی است');
    }
    
    if (empty($subject)) {
        throw new Exception('انتخاب درس الزامی است');
    }
    
    if (empty($jalali_due_date)) {
        throw new Exception('تاریخ تحویل الزامی است');
    }
    
    // تبدیل تاریخ شمسی به میلادی
    $gregorian_due_date = jalali_to_gregorian($jalali_due_date);
    if (!$gregorian_due_date) {
        throw new Exception('فرمت تاریخ تحویل نامعتبر است. لطفا از فرمت yyyy/mm/dd استفاده کنید');
    }
    
    // مدیریت آپلود فایل
    $file_path = null;
    if (isset($_FILES['homework_file']) && $_FILES['homework_file']['error'] === UPLOAD_ERR_OK) {
        $upload_result = handleFileUpload($_FILES['homework_file']);
        if (!$upload_result['success']) {
            throw new Exception($upload_result['message']);
        }
        $file_path = $upload_result['path'];
    }
    
    // ثبت در پایگاه داده
    $sql = "INSERT INTO homework (title, description, subject, due_date, file_path, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception('خطا در آماده‌سازی کوئری: ' . $conn->errorInfo()[2]);
    }
    
    $success = $stmt->execute([
        $title,
        $description,
        $subject,
        $gregorian_due_date,
        $file_path
    ]);
    
    if (!$success) {
        throw new Exception('خطا در اجرای کوئری: ' . implode(', ', $stmt->errorInfo()));
    }
    
    // پاسخ موفق
    echo json_encode([
        'success' => true,
        'message' => 'تکلیف با موفقیت ثبت شد',
        'homework_id' => $conn->lastInsertId()
    ]);
    
} catch (Exception $e) {
    // لاگ کردن خطا
    error_log('Homework Upload Error: ' . $e->getMessage());
    
    // پاسخ خطا
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'debug_info' => [
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
            'post_data' => $_POST,
            'files_data' => array_map(function($file) {
                return [
                    'name' => $file['name'] ?? '',
                    'error' => $file['error'] ?? '',
                    'size' => $file['size'] ?? 0
                ];
            }, $_FILES)
        ]
    ]);
}

/**
 * تابع مدیریت آپلود فایل
 */
function handleFileUpload($file) {
    // بررسی خطاهای آپلود
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $upload_errors = [
            UPLOAD_ERR_INI_SIZE => 'فایل بزرگتر از حد مجاز است',
            UPLOAD_ERR_FORM_SIZE => 'فایل بزرگتر از حد مجاز فرم است',
            UPLOAD_ERR_PARTIAL => 'فایل به طور کامل آپلود نشد',
            UPLOAD_ERR_NO_FILE => 'هیچ فایلی انتخاب نشده',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت یافت نشد',
            UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل',
            UPLOAD_ERR_EXTENSION => 'آپلود فایل توسط افزونه متوقف شد'
        ];
        return [
            'success' => false,
            'message' => $upload_errors[$file['error']] ?? 'خطای نامشخص در آپلود'
        ];
    }
    
    // بررسی نوع فایل
    $allowed_types = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'txt'];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_types)) {
        return [
            'success' => false,
            'message' => 'نوع فایل مجاز نیست. فرمت‌های مجاز: ' . implode(', ', $allowed_types)
        ];
    }
    
    // بررسی سایز فایل (حداکثر 5MB)
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        return [
            'success' => false,
            'message' => 'سایز فایل نباید بیشتر از 5MB باشد'
        ];
    }
    
    // ایجاد پوشه آپلود
    $upload_dir = dirname(__DIR__) . '/uploads/homework/';
    if (!is_dir($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            return [
                'success' => false,
                'message' => 'خطا در ایجاد پوشه آپلود'
            ];
        }
    }
    
    // تولید نام فایل منحصر به فرد
    $safe_filename = date('Y-m-d_H-i-s') . '_' . uniqid() . '.' . $file_extension;
    $target_path = $upload_dir . $safe_filename;
    
    // انتقال فایل
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return [
            'success' => true,
            'path' => 'uploads/homework/' . $safe_filename,
            'filename' => $safe_filename
        ];
    } else {
        return [
            'success' => false,
            'message' => 'خطا در ذخیره فایل'
        ];
    }
}
?>