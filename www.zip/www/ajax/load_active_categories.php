<?php
// فایل: ajax/load_active_categories.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت دسته‌بندی‌های فعال برای استفاده در فرم‌ها
    $stmt = $conn->prepare("
        SELECT id, name, icon, color
        FROM game_categories 
        WHERE is_active = 1 
        ORDER BY name ASC
    ");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'categories' => $categories
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری دسته‌بندی‌ها: ' . $e->getMessage()
    ]);
}
?>