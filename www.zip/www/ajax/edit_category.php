<?php
// فایل: ajax/edit_category.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// بررسی روش درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت و اعتبارسنجی داده‌ها
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    $color = trim($_POST['color'] ?? '#4d9de0');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // بررسی فیلدهای الزامی
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'شناسه دسته‌بندی نامعتبر است']);
        exit();
    }
    
    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => 'نام دسته‌بندی الزامی است']);
        exit();
    }
    
    // بررسی طول نام
    if (strlen($name) > 100) {
        echo json_encode(['success' => false, 'message' => 'نام دسته‌بندی نباید بیش از 100 کاراکتر باشد']);
        exit();
    }
    
    // بررسی وجود دسته‌بندی
    $stmt = $conn->prepare("SELECT id FROM game_categories WHERE id = ?");
    $stmt->execute([$id]);
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی یافت نشد']);
        exit();
    }
    
    // بررسی تکراری نبودن نام (غیر از خود رکورد)
    $stmt = $conn->prepare("SELECT id FROM game_categories WHERE name = ? AND id != ?");
    $stmt->execute([$name, $id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی با این نام قبلاً وجود دارد']);
        exit();
    }
    
    // اعتبارسنجی رنگ
    if (!empty($color) && !preg_match('/^#[0-9A-Fa-f]{6}$/', $color)) {
        $color = '#4d9de0'; // رنگ پیش‌فرض
    }
    
    // اعتبارسنجی آیکون (حداکثر 50 کاراکتر)
    if (strlen($icon) > 50) {
        $icon = substr($icon, 0, 50);
    }
    
    // بروزرسانی دسته‌بندی
    $stmt = $conn->prepare("
        UPDATE game_categories 
        SET name = ?, icon = ?, color = ?, is_active = ?
        WHERE id = ?
    ");
    
    $result = $stmt->execute([$name, $icon, $color, $is_active, $id]);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'دسته‌بندی با موفقیت بروزرسانی شد'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی دسته‌بندی']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ویرایش دسته‌بندی: ' . $e->getMessage()
    ]);
}
?>