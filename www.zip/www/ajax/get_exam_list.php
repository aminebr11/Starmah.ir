<?php
// ajax/get_exam_list.php
require_once '../db_connect.php';
require_once '../functions.php';

// Check if user is admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $search = trim($input['search'] ?? '');
    $status = trim($input['status'] ?? 'all'); // all, active, inactive
    $date_filter = trim($input['date_filter'] ?? '');
    
    // Base query
    $sql = "
        SELECT 
            q.id,
            q.title,
            q.exam_date,
            q.exam_time,
            q.duration_minutes,
            q.is_active,
            q.is_visible,
            q.shuffle_questions,
            q.negative_marking,
            q.questions_count,
            q.created_at,
            COUNT(qa.id) as total_attempts,
            COALESCE(AVG(qa.score), 0) as avg_score
        FROM quizzes q
        LEFT JOIN quiz_attempts qa ON q.id = qa.quiz_id
        WHERE 1=1
    ";
    
    $params = [];
    
    // Apply filters
    if ($search) {
        $sql .= " AND q.title LIKE ?";
        $params[] = "%$search%";
    }
    
    if ($status === 'active') {
        $sql .= " AND q.is_active = 1";
    } elseif ($status === 'inactive') {
        $sql .= " AND q.is_active = 0";
    }
    
    if ($date_filter) {
        $sql .= " AND DATE(q.exam_date) = ?";
        $params[] = $date_filter;
    }
    
    $sql .= " GROUP BY q.id ORDER BY q.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format the data
    foreach ($exams as &$exam) {
        $exam['id'] = (int)$exam['id'];
        $exam['duration_minutes'] = (int)$exam['duration_minutes'];
        $exam['is_active'] = (bool)$exam['is_active'];
        $exam['is_visible'] = (bool)$exam['is_visible'];
        $exam['shuffle_questions'] = (bool)$exam['shuffle_questions'];
        $exam['negative_marking'] = (bool)$exam['negative_marking'];
        $exam['questions_count'] = (int)$exam['questions_count'];
        $exam['total_attempts'] = (int)$exam['total_attempts'];
        $exam['avg_score'] = round((float)$exam['avg_score'], 1);
        
        // Format dates for display
        if ($exam['exam_date']) {
            $exam['exam_date_persian'] = date('Y/m/d', strtotime($exam['exam_date']));
        }
        
        if ($exam['exam_time']) {
            $exam['exam_time_formatted'] = date('H:i', strtotime($exam['exam_time']));
        }
    }
    
    echo json_encode([
        'success' => true,
        'exams' => $exams,
        'total_count' => count($exams)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت لیست آزمون‌ها: ' . $e->getMessage()
    ]);
}
?>