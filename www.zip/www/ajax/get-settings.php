<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// This can be accessed by all logged in users
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'لطفا وارد شوید']);
    exit;
}

try {
    // Get site settings
    $settings = [];
    
    // Check if settings table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'site_settings'");
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $stmt = $conn->prepare("SELECT setting_key, setting_value FROM site_settings");
        $stmt->execute();
        
        while($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
    
    // Default values if not set
    $defaultSettings = [
        'school_name' => 'دبستان ستاره ماه',
        'academic_year' => '1403-1404',
        'welcome_message' => 'کلاس خانم نجمه محمودی - جایی که یادگیری با ستاره‌ها می‌درخشد',
        'max_upload_size' => '20',
        'email_notifications' => '1',
        'homework_notifications' => '1',
        'weekly_report' => '1',
        'site_status' => 'active'
    ];
    
    // Merge with defaults
    $settings = array_merge($defaultSettings, $settings);
    
    // Get additional info for admin
    if (isAdmin()) {
        // Get database size
        $stmt = $conn->prepare("
            SELECT 
                SUM(data_length + index_length) / 1024 / 1024 AS size_mb
            FROM information_schema.tables 
            WHERE table_schema = ?
        ");
        $stmt->execute([DB_NAME]);
        $dbSize = round($stmt->fetchColumn(), 2);
        
        // Get backup count
        $backupDir = '../backups';
        $backupCount = 0;
        if (file_exists($backupDir)) {
            $backupCount = count(glob($backupDir . '/*.sql'));
        }
        
        // Get upload directory size
        $uploadSize = 0;
        $uploadDir = '../uploads';
        if (file_exists($uploadDir)) {
            $uploadSize = getFolderSize($uploadDir);
        }
        
        $settings['admin_info'] = [
            'database_size' => $dbSize . ' MB',
            'backup_count' => $backupCount,
            'upload_size' => formatBytes($uploadSize),
            'php_version' => PHP_VERSION,
            'max_upload_size_server' => ini_get('upload_max_filesize'),
            'memory_limit' => ini_get('memory_limit')
        ];
    }
    
    echo json_encode([
        'success' => true,
        'settings' => $settings
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت تنظیمات'
    ]);
}

// Helper function to get folder size
function getFolderSize($dir) {
    $size = 0;
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    
    foreach ($files as $file) {
        if ($file->isFile()) {
            $size += $file->getSize();
        }
    }
    
    return $size;
}

// Format bytes
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>