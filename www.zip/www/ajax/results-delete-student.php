<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$student_id = (int)($_POST['student_id'] ?? 0);
if ($student_id <= 0) { echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit; }

try{
  $stmt = $conn->prepare("DELETE FROM game_results WHERE student_id=?");
  $ok = $stmt->execute([$student_id]);
  echo json_encode(['success'=>true,'deleted'=>$stmt->rowCount()]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
