<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// لاگ تمام درخواست‌ها
file_put_contents('debug.log', date('Y-m-d H:i:s') . " - add-xp.php called\n", FILE_APPEND);

session_start();
require_once '../config.php';

// تنظیم هدر JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // بررسی session
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز', 'session' => $_SESSION], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // بررسی روش درخواست
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // دریافت داده‌ها
    $rawInput = file_get_contents('php://input');
    file_put_contents('debug.log', "Raw input: " . $rawInput . "\n", FILE_APPEND);
    
    if (empty($rawInput)) {
        echo json_encode(['success' => false, 'message' => 'هیچ داده‌ای دریافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $input = json_decode($rawInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'خطا در پردازش JSON: ' . json_last_error_msg()], JSON_UNESCAPED_UNICODE);
        exit();
    }

    file_put_contents('debug.log', "Parsed input: " . print_r($input, true) . "\n", FILE_APPEND);

    // استخراج متغیرها
    $studentId = $input['student_id'] ?? null;
    $subject = $input['subject'] ?? null;
    $xpAmount = (int)($input['xp_amount'] ?? 0);
    $operation = $input['operation'] ?? 'add';
    $reason = trim($input['reason'] ?? '');

    // اعتبارسنجی
    if (!$studentId) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز مشخص نشده'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if (!$subject) {
        echo json_encode(['success' => false, 'message' => 'موضوع مشخص نشده'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($xpAmount <= 0) {
        echo json_encode(['success' => false, 'message' => 'مقدار امتیاز باید بیشتر از صفر باشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // بررسی اتصال دیتابیس
    if (!$conn) {
        echo json_encode(['success' => false, 'message' => 'اتصال به دیتابیس برقرار نیست'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // بررسی وجود دانش‌آموز
    $checkStmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$studentId]);
    $student = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        echo json_encode(['success' => false, 'message' => "دانش‌آموز با شناسه $studentId یافت نشد"], JSON_UNESCAPED_UNICODE);
        exit();
    }

    file_put_contents('debug.log', "Student found: " . print_r($student, true) . "\n", FILE_APPEND);

    // بررسی یا ایجاد رکورد XP
    $xpStmt = $conn->prepare("SELECT * FROM student_xp WHERE student_id = ?");
    $xpStmt->execute([$studentId]);
    $currentXP = $xpStmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentXP) {
        // ایجاد رکورد جدید
        $insertStmt = $conn->prepare("
            INSERT INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level) 
            VALUES (?, 0, 0, 0, 0, 0, 0, 1)
        ");
        $insertStmt->execute([$studentId]);
        
        // دریافت مجدد
        $xpStmt->execute([$studentId]);
        $currentXP = $xpStmt->fetch(PDO::FETCH_ASSOC);
    }

    // محاسبه مقدار جدید
    $validSubjects = ['total', 'math', 'science', 'persian', 'social', 'religion'];
    if (!in_array($subject, $validSubjects)) {
        echo json_encode(['success' => false, 'message' => "موضوع نامعتبر: $subject"], JSON_UNESCAPED_UNICODE);
        exit();
    }

    if ($subject === 'total') {
        $oldValue = $currentXP['total_xp'];
        $newValue = $oldValue + $xpAmount; // فقط افزودن برای سادگی
        
        $updateStmt = $conn->prepare("UPDATE student_xp SET total_xp = ? WHERE student_id = ?");
        $updateStmt->execute([$newValue, $studentId]);
    } else {
        $subjectColumn = $subject . '_xp';
        $oldValue = $currentXP[$subjectColumn];
        $newValue = $oldValue + $xpAmount;
        
        // بروزرسانی موضوع خاص
        $updateStmt = $conn->prepare("UPDATE student_xp SET `$subjectColumn` = ? WHERE student_id = ?");
        $updateStmt->execute([$newValue, $studentId]);
        
        // بروزرسانی کل امتیاز
        $totalStmt = $conn->prepare("
            UPDATE student_xp 
            SET total_xp = math_xp + science_xp + persian_xp + social_xp + religion_xp 
            WHERE student_id = ?
        ");
        $totalStmt->execute([$studentId]);
    }

    // ثبت تاریخچه (اگر جدول وجود داشت)
    try {
        $historyStmt = $conn->prepare("
            INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $historyStmt->execute([$studentId, $subject, $xpAmount, $reason, $_SESSION['user_id']]);
    } catch (Exception $e) {
        file_put_contents('debug.log', "History insert failed: " . $e->getMessage() . "\n", FILE_APPEND);
    }

    // پاسخ موفقیت‌آمیز
    $response = [
        'success' => true,
        'message' => "امتیاز {$subject} برای {$student['first_name']} {$student['last_name']} با موفقیت اضافه شد",
        'old_value' => $oldValue,
        'new_value' => $newValue,
        'student' => $student
    ];

    file_put_contents('debug.log', "Success response: " . print_r($response, true) . "\n", FILE_APPEND);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    $errorResponse = [
        'success' => false,
        'message' => 'خطای سیستم: ' . $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ];
    
    file_put_contents('debug.log', "Exception: " . print_r($errorResponse, true) . "\n", FILE_APPEND);
    echo json_encode($errorResponse, JSON_UNESCAPED_UNICODE);
}
?>