<?php
// فایل: ajax/add_category.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// بررسی روش درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت و اعتبارسنجی داده‌ها
    $name = trim($_POST['name'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    $color = trim($_POST['color'] ?? '#4d9de0');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // بررسی فیلدهای الزامی
    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => 'نام دسته‌بندی الزامی است']);
        exit();
    }
    
    // بررسی طول نام
    if (strlen($name) > 100) {
        echo json_encode(['success' => false, 'message' => 'نام دسته‌بندی نباید بیش از 100 کاراکتر باشد']);
        exit();
    }
    
    // بررسی تکراری نبودن نام
    $stmt = $conn->prepare("SELECT id FROM game_categories WHERE name = ?");
    $stmt->execute([$name]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی با این نام قبلاً وجود دارد']);
        exit();
    }
    
    // اعتبارسنجی رنگ
    if (!empty($color) && !preg_match('/^#[0-9A-Fa-f]{6}$/', $color)) {
        $color = '#4d9de0'; // رنگ پیش‌فرض
    }
    
    // اعتبارسنجی آیکون (حداکثر 50 کاراکتر)
    if (strlen($icon) > 50) {
        $icon = substr($icon, 0, 50);
    }
    
    // درج دسته‌بندی جدید
    $stmt = $conn->prepare("
        INSERT INTO game_categories (name, icon, color, is_active, created_at) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    
    $result = $stmt->execute([$name, $icon, $color, $is_active]);
    
    if ($result) {
        $categoryId = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'دسته‌بندی با موفقیت اضافه شد',
            'category_id' => $categoryId
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در ذخیره دسته‌بندی']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در افزودن دسته‌بندی: ' . $e->getMessage()
    ]);
}
?>