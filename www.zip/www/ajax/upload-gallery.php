<?php
// ajax/upload-gallery.php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !isAdmin()) { echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit; }

$title = trim($_POST['title'] ?? '');
$category = $_POST['category'] ?? '';
$description = trim($_POST['description'] ?? '');

$validCats = ['artwork','activities','events','achievements'];
if ($title==='' || !in_array($category,$validCats,true)) {
  echo json_encode(['success'=>false,'message'=>'ورودی نامعتبر']); exit;
}
if (!isset($_FILES['image_file']) || $_FILES['image_file']['error'] !== UPLOAD_ERR_OK) {
  echo json_encode(['success'=>false,'message'=>'فایل معتبر نیست']); exit;
}

$f = $_FILES['image_file'];
$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$allowed = ['jpg','jpeg','png','webp'];
if (!in_array($ext,$allowed,true)) { echo json_encode(['success'=>false,'message'=>'پسوند مجاز نیست']); exit; }
if ($f['size'] > 5*1024*1024) { echo json_encode(['success'=>false,'message'=>'سایز باید کمتر از 5MB باشد']); exit; }

$baseDir = __DIR__ . '/../uploads/gallery/';
$relDir  = date('Ym');
$dir = $baseDir . $relDir . '/';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

$filename = uniqid('gal_', true) . '.' . $ext;
$destAbs = $dir . $filename;
$destRel = 'uploads/gallery/' . $relDir . '/' . $filename;

if (!move_uploaded_file($f['tmp_name'], $destAbs)) {
  echo json_encode(['success'=>false,'message'=>'خطا در ذخیره فایل']); exit;
}

// ثبت در DB
try {
  $st = $conn->prepare("INSERT INTO gallery (title, description, category, file_path, created_at) VALUES (?,?,?,?,NOW())");
  $st->execute([$title, $description, $category, $destRel]);
  $id = (int)$conn->lastInsertId();
  echo json_encode(['success'=>true,'id'=>$id,'file_path'=>$destRel,'title'=>$title,'category'=>$category,'description'=>$description], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  @unlink($destAbs);
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
