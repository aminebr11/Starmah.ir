<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$record_id = $input['record_id'] ?? null;

if (!$record_id) {
    echo json_encode(['success' => false, 'message' => 'شناسه نامعتبر']);
    exit;
}

try {
    $conn->beginTransaction();
    
    // گرفتن اطلاعات رکورد قبل از حذف
    $stmt = $conn->prepare("SELECT student_id, score FROM discipline_records WHERE id = ?");
    $stmt->execute([$record_id]);
    $record = $stmt->fetch();
    
    if (!$record) {
        throw new Exception('رکورد یافت نشد');
    }
    
    // حذف رکورد
    $stmt = $conn->prepare("DELETE FROM discipline_records WHERE id = ?");
    $stmt->execute([$record_id]);
    
    // بازگرداندن امتیاز به دانش‌آموز
    $stmt = $conn->prepare("UPDATE students SET total_score = total_score - ? WHERE user_id = ?");
    $stmt->execute([$record['score'], $record['student_id']]);
    
    $conn->commit();
    
    echo json_encode(['success' => true, 'message' => 'مورد انضباطی حذف شد']);
} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(['success' => false, 'message' => 'خطا در حذف: ' . $e->getMessage()]);
}
?>