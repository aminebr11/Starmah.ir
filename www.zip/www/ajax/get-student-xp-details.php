<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// لاگ برای دیباگ
file_put_contents('debug-details.log', date('Y-m-d H:i:s') . " - get-student-xp-details.php called\n", FILE_APPEND);

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

$studentId = $_GET['student_id'] ?? null;

if (!$studentId) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز ارسال نشده']);
    exit();
}

file_put_contents('debug-details.log', "Student ID: $studentId\n", FILE_APPEND);

try {
    // دریافت اطلاعات کامل دانش‌آموز
    $studentStmt = $conn->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.national_id,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    
    $studentStmt->execute([$studentId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit();
    }
    
    file_put_contents('debug-details.log', "Student found: " . $student['first_name'] . " " . $student['last_name'] . "\n", FILE_APPEND);
    
    // دریافت تاریخچه امتیازات
    $history = [];
    try {
        $historyStmt = $conn->prepare("
            SELECT 
                h.subject,
                h.amount,
                h.reason,
                h.created_at,
                u_admin.first_name as admin_name
            FROM xp_history h
            LEFT JOIN users u_admin ON h.admin_id = u_admin.id
            WHERE h.student_id = ?
            ORDER BY h.created_at DESC
            LIMIT 20
        ");
        
        $historyStmt->execute([$studentId]);
        $history = $historyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        file_put_contents('debug-details.log', "History records: " . count($history) . "\n", FILE_APPEND);
    } catch (Exception $historyError) {
        file_put_contents('debug-details.log', "History query failed: " . $historyError->getMessage() . "\n", FILE_APPEND);
        // ادامه می‌دهیم حتی اگر تاریخچه کار نکند
    }
    
    // محاسبه رنک دانش‌آموز - اصلاح شده
    $studentRank = 1;
    try {
        // دریافت امتیاز فعلی دانش‌آموز
        $currentXPStmt = $conn->prepare("
            SELECT COALESCE(total_xp, 0) as current_xp
            FROM student_xp
            WHERE student_id = ?
        ");
        $currentXPStmt->execute([$studentId]);
        $currentXP = $currentXPStmt->fetchColumn() ?: 0;
        
        // شمارش تعداد دانش‌آموزانی که امتیاز بالاتری دارند
        $rankStmt = $conn->prepare("
            SELECT COUNT(*) as higher_count
            FROM student_xp sx
            JOIN users u ON sx.student_id = u.id
            WHERE u.user_type = 'student' AND sx.total_xp > ?
        ");
        $rankStmt->execute([$currentXP]);
        $higherCount = $rankStmt->fetchColumn();
        
        $studentRank = $higherCount + 1;
        
        file_put_contents('debug-details.log', "Rank calculated: $studentRank (current XP: $currentXP)\n", FILE_APPEND);
    } catch (Exception $rankError) {
        file_put_contents('debug-details.log', "Rank calculation failed: " . $rankError->getMessage() . "\n", FILE_APPEND);
        // اگر رنک محاسبه نشد، 1 باقی می‌ماند
    }
    
    // آماده‌سازی پاسخ
    $response = [
        'success' => true,
        'student' => $student,
        'history' => $history,
        'rank' => $studentRank
    ];
    
    file_put_contents('debug-details.log', "Response prepared successfully\n", FILE_APPEND);
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    $errorMsg = 'خطا در دریافت جزئیات: ' . $e->getMessage();
    file_put_contents('debug-details.log', "Main error: " . $errorMsg . "\n", FILE_APPEND);
    
    echo json_encode([
        'success' => false,
        'message' => $errorMsg,
        'debug' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'student_id' => $studentId
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>