<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // خاموش کردن نمایش خطاها در خروجی JSON

session_start();
require_once '../config.php';

// تنظیم header برای JSON response
header('Content-Type: application/json; charset=utf-8');

try {
    // بررسی اتصال به دیتابیس
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به دیتابیس');
    }
    
    // بررسی احراز هویت و دسترسی ادمین
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
        throw new Exception('دسترسی غیر مجاز. فقط ادمین‌ها می‌توانند موارد انضباطی ثبت کنند.');
    }
    
    // بررسی method درخواست
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('روش درخواست نامعتبر');
    }
    
    // خواندن داده‌های JSON
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!$data || json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('داده‌های JSON نامعتبر');
    }
    
    // اعتبارسنجی ورودی
    if (empty($data['students']) || !is_array($data['students'])) {
        throw new Exception('لیست دانش‌آموزان خالی است');
    }
    
    if (empty($data['disciplines']) || !is_array($data['disciplines'])) {
        throw new Exception('لیست موارد انضباطی خالی است');
    }
    
    if (empty($data['date'])) {
        throw new Exception('تاریخ وارد نشده است');
    }
    
    // اعتبارسنجی تاریخ
    if (!isValidPersianDate($data['date'])) {
        throw new Exception('فرمت تاریخ نادرست است');
    }
    
    $adminId = $_SESSION['user_id'];
    $persianDate = trim($data['date']);
    $description = trim($data['description'] ?? '');
    $gregorianDate = convertPersianToGregorian($persianDate);
    
    if (!$gregorianDate) {
        throw new Exception('خطا در تبدیل تاریخ شمسی به میلادی');
    }
    
    // شروع تراکنش
    $conn->beginTransaction();
    
    $successCount = 0;
    $totalRecords = 0;
    $xpHistoryCount = 0;
    $xpUpdateCount = 0;
    $errors = [];
    
    foreach ($data['students'] as $student) {
        // اعتبارسنجی داده‌های دانش‌آموز
        if (!isset($student['id']) || !is_numeric($student['id'])) {
            $errors[] = "شناسه دانش‌آموز نامعتبر";
            continue;
        }
        
        // بررسی وجود دانش‌آموز
        $checkStudentStmt = $conn->prepare("
            SELECT id, first_name, last_name 
            FROM users 
            WHERE id = ? AND user_type = 'student' AND is_active = 1
        ");
        $checkStudentStmt->execute([(int)$student['id']]);
        $studentData = $checkStudentStmt->fetch();
        
        if (!$studentData) {
            $errors[] = "دانش‌آموز با شناسه {$student['id']} یافت نشد";
            continue;
        }
        
        foreach ($data['disciplines'] as $discipline) {
            $totalRecords++;
            
            // اعتبارسنجی مورد انضباطی
            if (empty($discipline['title']) || !isset($discipline['score'])) {
                $errors[] = "اطلاعات مورد انضباطی ناقص است";
                continue;
            }
            
            $disciplineTitle = trim($discipline['title']);
            $disciplineScore = (int)$discipline['score'];
            
            if ($disciplineScore <= 0 || $disciplineScore > 100) {
                $errors[] = "امتیاز منفی باید بین 1 تا 100 باشد";
                continue;
            }
            
            try {
                // ثبت مورد انضباطی در جدول discipline_records
                $stmt = $conn->prepare("
                    INSERT INTO discipline_records 
                    (student_id, title, score, persian_date, gregorian_date, description, created_at, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)
                ");
                
                $result = $stmt->execute([
                    (int)$student['id'],
                    $disciplineTitle,
                    $disciplineScore,
                    $persianDate,
                    $gregorianDate,
                    $description,
                    $adminId
                ]);
                
                if ($result) {
                    $successCount++;
                    $disciplineRecordId = $conn->lastInsertId();
                    
                    // ثبت در تاریخچه امتیازات (xp_history) - امتیاز منفی برای موارد انضباطی
                    try {
                        $disciplineReason = "مورد انضباطی: " . $disciplineTitle;
                        if (!empty($description)) {
                            $disciplineReason .= " | توضیحات: " . $description;
                        }
                        $disciplineReason .= " | تاریخ: " . $persianDate;
                        
                        $xpHistoryStmt = $conn->prepare("
                            INSERT INTO xp_history 
                            (student_id, subject, amount, reason, admin_id, created_at) 
                            VALUES (?, ?, ?, ?, ?, NOW())
                        ");
                        
                        $xpHistoryResult = $xpHistoryStmt->execute([
                            (int)$student['id'],
                            'مورد انضباطی', // موضوع انضباطی
                            -$disciplineScore, // امتیاز منفی
                            $disciplineReason,
                            $adminId
                        ]);
                        
                        if ($xpHistoryResult) {
                            $xpHistoryCount++;
                        }
                    } catch (PDOException $e) {
                        // اگر جدول xp_history وجود ندارد، ادامه می‌دهیم
                        error_log("XP History insert failed: " . $e->getMessage());
                    }
                    
                    // بروزرسانی جدول امتیازات کلی (student_xp) - ذخیره منفی در dic_xp
                    try {
                        // بررسی وجود رکورد دانش‌آموز
                        $checkXpStmt = $conn->prepare("SELECT id, dic_xp FROM student_xp WHERE student_id = ?");
                        $checkXpStmt->execute([(int)$student['id']]);
                        $xpRecord = $checkXpStmt->fetch();
                        
                        if ($xpRecord) {
                            // بروزرسانی رکورد موجود - کم کردن از dic_xp (امتیاز منفی)
                            $updateXpStmt = $conn->prepare("
                                UPDATE student_xp 
                                SET dic_xp = dic_xp - ?,
                                    updated_at = CURRENT_TIMESTAMP
                                WHERE student_id = ?
                            ");
                            $xpUpdateResult = $updateXpStmt->execute([
                                $disciplineScore, 
                                (int)$student['id']
                            ]);
                        } else {
                            // ایجاد رکورد جدید با مقدار منفی dic_xp
                            $insertXpStmt = $conn->prepare("
                                INSERT INTO student_xp 
                                (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, dic_xp, level, created_at, updated_at) 
                                VALUES (?, 0, 0, 0, 0, 0, 0, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                            ");
                            $xpUpdateResult = $insertXpStmt->execute([
                                (int)$student['id'],
                                -$disciplineScore  // امتیاز منفی
                            ]);
                        }
                        
                        if ($xpUpdateResult) {
                            $xpUpdateCount++;
                        }
                    } catch (PDOException $e) {
                        // اگر جدول student_xp وجود ندارد، ادامه می‌دهیم
                        error_log("Student XP update failed: " . $e->getMessage());
                    }
                    
                    // بروزرسانی جدول students (اختیاری - اگر این جدول دارید)
                    try {
                        $updateStudentStmt = $conn->prepare("
                            UPDATE students 
                            SET total_score = GREATEST(0, total_score - ?) 
                            WHERE user_id = ?
                        ");
                        $updateStudentStmt->execute([$disciplineScore, (int)$student['id']]);
                    } catch (PDOException $e) {
                        // اگر جدول students وجود ندارد، خطا را نادیده می‌گیریم
                        error_log("Students table update failed: " . $e->getMessage());
                    }
                    
                    // لاگ فعالیت (اختیاری)
                    try {
                        $logMessage = "ثبت مورد انضباطی: {$disciplineTitle} (-{$disciplineScore} امتیاز) برای {$studentData['first_name']} {$studentData['last_name']}";
                        $logStmt = $conn->prepare("
                            INSERT INTO admin_logs (admin_id, action, description, created_at) 
                            VALUES (?, 'discipline_record', ?, NOW())
                        ");
                        $logStmt->execute([$adminId, $logMessage]);
                    } catch (PDOException $e) {
                        // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
                        error_log("Admin log failed: " . $e->getMessage());
                    }
                    
                } else {
                    $errors[] = "خطا در ثبت مورد انضباطی {$disciplineTitle} برای دانش‌آموز {$student['id']}";
                }
                
            } catch (PDOException $e) {
                $errors[] = "خطای دیتابیس در ثبت مورد {$disciplineTitle}: " . $e->getMessage();
                continue;
            }
        }
    }
    
    // بررسی نتایج
    if ($successCount === 0) {
        $conn->rollback();
        throw new Exception('هیچ رکوردی ثبت نشد. خطاها: ' . implode(', ', $errors));
    }
    
    // تایید تراکنش
    $conn->commit();
    
    // ارسال پاسخ موفقیت‌آمیز
    $response = [
        'success' => true,
        'message' => "موارد انضباطی با موفقیت ثبت شد",
        'details' => [
            'total_records' => $totalRecords,
            'success_count' => $successCount,
            'xp_history_count' => $xpHistoryCount,
            'xp_update_count' => $xpUpdateCount,
            'students_count' => count($data['students']),
            'disciplines_count' => count($data['disciplines']),
            'date' => $persianDate
        ]
    ];
    
    // اضافه کردن هشدارها در صورت وجود خطاهای جزئی
    if (!empty($errors) && $successCount < $totalRecords) {
        $response['partial'] = true;
        $response['message'] = "{$successCount} مورد از {$totalRecords} با موفقیت ثبت شد";
        $response['warnings'] = $errors;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    // بازگشت تراکنش در صورت خطای دیتابیس
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollback();
    }
    
    error_log("Database error in discipline submission: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage(),
        'error_code' => $e->getCode()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // بازگشت تراکنش در صورت خطای عمومی
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollback();
    }
    
    error_log("General error in discipline submission: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

// توابع کمکی
function isValidPersianDate($dateStr) {
    if (empty($dateStr)) return false;
    
    // تبدیل اعداد فارسی به انگلیسی
    $persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    $cleanDate = str_replace($persianNumbers, $englishNumbers, trim($dateStr));
    
    // بررسی فرمت
    if (preg_match('/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})$/', $cleanDate, $matches)) {
        $year = (int)$matches[1];
        $month = (int)$matches[2];
        $day = (int)$matches[3];
        
        // اعتبارسنجی محدوده‌ها
        if ($year < 1300 || $year > 1500) return false;
        if ($month < 1 || $month > 12) return false;
        if ($day < 1 || $day > 31) return false;
        
        // اعتبارسنجی روزهای ماه
        if ($month <= 6 && $day > 31) return false;
        if ($month > 6 && $month < 12 && $day > 30) return false;
        if ($month == 12 && $day > 29) return false;
        
        return true;
    }
    
    return false;
}

function convertPersianToGregorian($persianDate) {
    // تبدیل اعداد فارسی به انگلیسی
    $persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    $cleanDate = str_replace($persianNumbers, $englishNumbers, $persianDate);
    
    if (preg_match('/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/', $cleanDate, $matches)) {
        $jYear = (int)$matches[1];
        $jMonth = (int)$matches[2];
        $jDay = (int)$matches[3];
        
        // تبدیل ساده شمسی به میلادی (مطابق کد قبلی شما)
        $gYear = $jYear + 621;
        if ($jMonth <= 6) {
            $gMonth = $jMonth + 3;
            if ($gMonth > 12) {
                $gMonth -= 12;
                $gYear++;
            }
        } else {
            $gMonth = $jMonth - 9;
            $gYear++;
        }
        
        $gDay = $jDay;
        
        // تنظیم روزهای غیر معتبر
        if ($gMonth == 2 && $gDay > 28) $gDay = 28;
        if (in_array($gMonth, [4, 6, 9, 11]) && $gDay > 30) $gDay = 30;
        if ($gDay > 31) $gDay = 31;
        
        return sprintf('%04d-%02d-%02d', $gYear, $gMonth, $gDay);
    }
    
    return date('Y-m-d'); // fallback به تاریخ امروز
}
?>