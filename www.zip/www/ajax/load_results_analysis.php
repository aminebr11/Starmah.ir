<?php
// فایل: ajax/load_results_analysis.php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت فیلترها
    $filters = [
        'student_id' => $_GET['student_id'] ?? '',
        'game_id' => $_GET['game_id'] ?? '',
        'category_id' => $_GET['category_id'] ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'min_score' => $_GET['min_score'] ?? '',
        'max_score' => $_GET['max_score'] ?? '',
        'sort' => $_GET['sort'] ?? 'date_desc',
        'page' => (int)($_GET['page'] ?? 1),
        'limit' => (int)($_GET['limit'] ?? 25)
    ];

    // ساخت WHERE clause
    $whereConditions = ["1=1"];
    $params = [];

    if (!empty($filters['student_id'])) {
        $whereConditions[] = "gr.student_id = ?";
        $params[] = $filters['student_id'];
    }

    if (!empty($filters['game_id'])) {
        $whereConditions[] = "gr.game_id = ?";
        $params[] = $filters['game_id'];
    }

    if (!empty($filters['category_id'])) {
        $whereConditions[] = "g.category_id = ?";
        $params[] = $filters['category_id'];
    }

    if (!empty($filters['date_from'])) {
        $whereConditions[] = "DATE(gr.completed_at) >= ?";
        $params[] = $filters['date_from'];
    }

    if (!empty($filters['date_to'])) {
        $whereConditions[] = "DATE(gr.completed_at) <= ?";
        $params[] = $filters['date_to'];
    }

    if ($filters['min_score'] !== '') {
        $whereConditions[] = "gr.score >= ?";
        $params[] = $filters['min_score'];
    }

    if ($filters['max_score'] !== '') {
        $whereConditions[] = "gr.score <= ?";
        $params[] = $filters['max_score'];
    }

    $whereClause = implode(' AND ', $whereConditions);

    // آمار کلی
    $statsQuery = "
        SELECT 
            COUNT(*) as total_results,
            COUNT(DISTINCT gr.student_id) as total_students,
            COUNT(DISTINCT gr.game_id) as total_games,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            MIN(gr.score) as worst_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time,
            AVG(gr.attempts) as avg_attempts
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE $whereClause
    ";

    $stmt = $conn->prepare($statsQuery);
    $stmt->execute($params);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // آمار بر اساس دسته‌بندی
    $categoryStatsQuery = "
        SELECT 
            gc.name as category_name,
            gc.icon,
            gc.color,
            COUNT(gr.id) as plays_count,
            AVG(gr.score) as avg_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE $whereClause AND gc.id IS NOT NULL
        GROUP BY gc.id, gc.name, gc.icon, gc.color
        ORDER BY avg_score DESC
    ";

    $stmt = $conn->prepare($categoryStatsQuery);
    $stmt->execute($params);
    $categoryStats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // رنکینگ دانش‌آموزان
    $rankingQuery = "
        SELECT 
            u.id,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            u.avatar,
            COUNT(gr.id) as total_plays,
            AVG(gr.score) as avg_score,
            SUM(gr.score) as total_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time,
            MAX(gr.score) as best_score,
            COUNT(DISTINCT gr.game_id) as games_played,
            MAX(gr.completed_at) as last_play
        FROM users u
        LEFT JOIN game_results gr ON u.id = gr.student_id
        LEFT JOIN games g ON gr.game_id = g.id
        WHERE u.user_type = 'student' AND $whereClause
        GROUP BY u.id, u.first_name, u.last_name, u.avatar
        HAVING total_plays > 0
        ORDER BY avg_score DESC, total_plays DESC
        LIMIT 10
    ";

    $stmt = $conn->prepare($rankingQuery);
    $stmt->execute($params);
    $topStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // نتایج صفحه‌بندی شده
    $offset = ($filters['page'] - 1) * $filters['limit'];
    
    // تعیین ترتیب مرتب‌سازی
    $orderBy = "gr.completed_at DESC";
    switch ($filters['sort']) {
        case 'score_desc': $orderBy = "gr.score DESC"; break;
        case 'score_asc': $orderBy = "gr.score ASC"; break;
        case 'time_desc': $orderBy = "gr.time_spent DESC"; break;
        case 'time_asc': $orderBy = "gr.time_spent ASC"; break;
        case 'accuracy_desc': $orderBy = "gr.accuracy DESC"; break;
        case 'accuracy_asc': $orderBy = "gr.accuracy ASC"; break;
        case 'date_asc': $orderBy = "gr.completed_at ASC"; break;
        default: $orderBy = "gr.completed_at DESC";
    }

    $resultsQuery = "
        SELECT 
            gr.*,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            u.avatar,
            g.title as game_title,
            gc.name as category_name,
            gc.icon as category_icon,
            gc.color as category_color,
            g.difficulty,
            g.max_score as game_max_score
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE $whereClause
        ORDER BY $orderBy
        LIMIT $offset, {$filters['limit']}
    ";

    $stmt = $conn->prepare($resultsQuery);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // شمارش کل نتایج برای صفحه‌بندی
    $countQuery = "
        SELECT COUNT(*) 
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE $whereClause
    ";
    $stmt = $conn->prepare($countQuery);
    $stmt->execute($params);
    $totalResults = $stmt->fetchColumn();

    // داده‌های نمودار (آخرین 30 روز)
    $chartQuery = "
        SELECT 
            DATE(gr.completed_at) as play_date,
            COUNT(*) as plays_count,
            AVG(gr.score) as avg_score,
            COUNT(DISTINCT gr.student_id) as active_students
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE $whereClause AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(gr.completed_at)
        ORDER BY play_date DESC
        LIMIT 30
    ";

    $stmt = $conn->prepare($chartQuery);
    $stmt->execute($params);
    $chartData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'category_stats' => $categoryStats,
        'top_students' => $topStudents,
        'results' => $results,
        'chart_data' => array_reverse($chartData),
        'pagination' => [
            'current_page' => $filters['page'],
            'total_results' => (int)$totalResults,
            'total_pages' => ceil($totalResults / $filters['limit']),
            'per_page' => $filters['limit']
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری تحلیل نتایج: ' . $e->getMessage()
    ]);
}
?>