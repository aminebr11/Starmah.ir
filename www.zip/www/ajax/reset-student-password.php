<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Check if admin is logged in
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// Get input data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'خطا در پردازش JSON']);
    exit();
}

if (!isset($data['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز ارسال نشده است.']);
    exit();
}

$studentId = (int)$data['student_id'];

if ($studentId <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است.']);
    exit();
}

try {
    // Get student's national ID
    $stmt = $conn->prepare("SELECT national_id, first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $stmt->execute([$studentId]);
    $student = $stmt->fetch();
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد.']);
        exit();
    }
    
    // Hash the national ID as new password
    $newPassword = password_hash($student['national_id'], PASSWORD_DEFAULT);
    
    // Update password
    $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $result = $updateStmt->execute([$newPassword, $studentId]);
    
    if ($result) {
        // Log the password reset
        error_log("Password reset for student: ID=" . $studentId . ", Name=" . $student['first_name'] . " " . $student['last_name']);
        
        echo json_encode([
            'success' => true, 
            'message' => 'رمز عبور با موفقیت به کد ملی دانش‌آموز تغییر کرد.'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در تغییر رمز عبور.']);
    }
    
} catch (PDOException $e) {
    error_log("Database error in reset-student-password: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای پایگاه داده.']);
} catch (Exception $e) {
    error_log("General error in reset-student-password: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سیستم.']);
}
?>