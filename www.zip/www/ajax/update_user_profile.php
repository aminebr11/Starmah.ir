<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// فعال‌سازی error reporting برای debug
error_reporting(E_ALL);
ini_set('display_errors', 0); // در production باید 0 باشد
ini_set('log_errors', 1);

require_once '../config.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید']);
    exit();
}

try {
    $input = file_get_contents('php://input');
    error_log("Raw input: " . $input);
    
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('خطا در پردازش داده‌های ورودی: ' . json_last_error_msg());
    }
    
    error_log("Decoded data: " . print_r($data, true));
    
    $userId = $_SESSION['user_id'];
    
    // فیلدهای قابل بروزرسانی
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'first_name' => 'نام',
        'last_name' => 'نام خانوادگی',
        'birth_date' => 'تاریخ تولد',
        'father_name' => 'نام پدر',
        'father_phone' => 'تلفن پدر',
        'mother_name' => 'نام مادر',
        'mother_phone' => 'تلفن مادر',
        'address' => 'آدرس',
        'email' => 'ایمیل'
    ];
    
    foreach ($allowedFields as $field => $label) {
        if (isset($data[$field])) {
            $value = $data[$field];
            
            // مدیریت خاص برای تاریخ تولد
            if ($field === 'birth_date') {
                if ($value === null || $value === '' || $value === 'null') {
                    $updateFields[] = "birth_date = NULL";
                    error_log("Birth date set to NULL");
                } else {
                    // اعتبارسنجی فرمت تاریخ YYYY-MM-DD
                    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                        $updateFields[] = "birth_date = ?";
                        $params[] = $value;
                        error_log("Birth date set to: " . $value);
                    } else {
                        error_log("Invalid date format: " . $value);
                        throw new Exception('فرمت تاریخ نامعتبر است: ' . $value);
                    }
                }
            }
            // مدیریت فیلدهای دیگر
            else {
                $value = trim($value);
                if ($value === '' || $value === 'null') {
                    $updateFields[] = "$field = NULL";
                } else {
                    $updateFields[] = "$field = ?";
                    $params[] = $value;
                }
            }
        }
    }
    
    // بررسی و بروزرسانی رمز عبور
    if (isset($data['password']) && !empty(trim($data['password']))) {
        $newPassword = trim($data['password']);
        if (strlen($newPassword) >= 8) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateFields[] = "password = ?";
            $params[] = $hashedPassword;
            error_log("Password updated");
        } else {
            throw new Exception('رمز عبور باید حداقل 8 کاراکتر باشد');
        }
    }
    
    if (empty($updateFields)) {
        throw new Exception('هیچ فیلدی برای بروزرسانی ارسال نشده است');
    }
    
    // افزودن user_id به پارامترها
    $params[] = $userId;
    
    // ساخت و اجرای کوئری
    $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
    error_log("SQL: " . $sql);
    error_log("Params: " . print_r($params, true));
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception('خطا در آماده‌سازی کوئری: ' . $conn->error);
    }
    
    if ($stmt->execute($params)) {
        // بروزرسانی نام در session
        if (isset($data['first_name']) && !empty($data['first_name'])) {
            $_SESSION['user_name'] = $data['first_name'];
        }
        
        error_log("Update successful");
        echo json_encode([
            'success' => true,
            'message' => '✅ اطلاعات شما با موفقیت بروزرسانی شد!'
        ]);
    } else {
        throw new Exception('خطا در اجرای کوئری: ' . $stmt->error);
    }
    
} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای پایگاه داده'
    ]);
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>