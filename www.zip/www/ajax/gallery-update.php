<?php
// ajax/gallery-update.php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !isAdmin()) { echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
$title = trim($input['title'] ?? '');
$description = trim($input['description'] ?? '');
$category = $input['category'] ?? '';

$validCats = ['artwork','activities','events','achievements'];
if ($id<=0 || $title==='' || !in_array($category,$validCats,true)) { echo json_encode(['success'=>false,'message'=>'ورودی نامعتبر']); exit; }

try {
  $st = $conn->prepare("UPDATE gallery SET title=?, description=?, category=?, updated_at=NOW() WHERE id=?");
  $st->execute([$title, $description, $category, $id]);
  echo json_encode(['success'=>true]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
