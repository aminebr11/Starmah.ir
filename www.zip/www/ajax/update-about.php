<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Check if request is AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden access']);
    exit;
}

// Start session and include necessary files
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';

// Check if user is admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['content'])) {
    echo json_encode(['success' => false, 'message' => 'محتوا ارسال نشده است']);
    exit;
}

$content = trim($input['content']);

try {
    // Check if settings table exists and create if not
    $stmt = $conn->prepare("SHOW TABLES LIKE 'settings'");
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        // Create settings table
        $create_table_sql = "
            CREATE TABLE settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) UNIQUE NOT NULL,
                setting_value TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ";
        $conn->exec($create_table_sql);
    }
    
    // Check if about content setting exists
    $stmt = $conn->prepare("SELECT id FROM settings WHERE setting_key = 'about_content'");
    $stmt->execute();
    
    if ($stmt->fetch()) {
        // Update existing setting
        $stmt = $conn->prepare("UPDATE settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP WHERE setting_key = 'about_content'");
        $stmt->execute([$content]);
    } else {
        // Insert new setting
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('about_content', ?)");
        $stmt->execute([$content]);
    }
    
    // Log the update for audit purposes
    error_log("About content updated by admin user");
    
    echo json_encode([
        'success' => true, 
        'message' => 'محتوای صفحه درباره ما با موفقیت بروزرسانی شد'
    ]);
    
} catch (Exception $e) {
    error_log("Update about content error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در بروزرسانی محتوا: ' . $e->getMessage()
    ]);
}
?>