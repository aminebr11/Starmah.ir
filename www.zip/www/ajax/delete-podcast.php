<?php
// ajax/delete-podcast.php
if (session_status()===PHP_SESSION_NONE) @session_start();

header('Content-Type: application/json; charset=utf-8');

// مسیرها را مطلق کن تا include خراب نشود
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!function_exists('isAdmin') || !isAdmin()) {
  echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit;
}

// هم FormData هم JSON را پشتیبانی کن
$id = 0;
if (isset($_POST['id'])) {
  $id = (int)$_POST['id'];
} else {
  $raw = file_get_contents('php://input');
  if ($raw) {
    $j = json_decode($raw, true);
    if (isset($j['id'])) $id = (int)$j['id'];
  }
}

if ($id <= 0) {
  echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit;
}

try {
  // مسیر فایل
  $stmt = $conn->prepare("SELECT file_path FROM podcasts WHERE id=? LIMIT 1");
  $stmt->execute([$id]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) { echo json_encode(['success'=>false,'message'=>'یافت نشد']); exit; }

  // حذف رکورد
  $del = $conn->prepare("DELETE FROM podcasts WHERE id=? LIMIT 1");
  $ok  = $del->execute([$id]);
  if (!$ok) { echo json_encode(['success'=>false,'message'=>'خطای پایگاه داده']); exit; }

  // حذف فایل فیزیکی (اگر محلی است)
  $path = $row['file_path'];
  if ($path && !preg_match('~^https?://~',$path)) {
    // اگر مسیر وبی است مثل /uploads/podcasts/...
    if ($path[0] === '/') {
      $abs = rtrim($_SERVER['DOCUMENT_ROOT'],'/') . $path;
    } else {
      // اگر نسبی ذخیره شده
      $abs = realpath(__DIR__ . '/../' . $path);
      // اگر realpath ناموفق بود، fallback
      if ($abs === false) $abs = __DIR__ . '/../' . $path;
    }
    if ($abs && is_file($abs)) @unlink($abs);
  }

  echo json_encode(['success'=>true]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'خطای سرور']);
}
