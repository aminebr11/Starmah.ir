<?php
// فایل: ajax/get_student_details.php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    $studentId = (int)($_GET['student_id'] ?? 0);
    
    if ($studentId <= 0) {
        throw new Exception('شناسه دانش‌آموز نامعتبر است');
    }

    // اطلاعات دانش‌آموز
    $studentQuery = "
        SELECT 
            u.*,
            COUNT(gr.id) as total_plays,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            MIN(gr.score) as worst_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time,
            SUM(gr.score) as total_score,
            COUNT(DISTINCT gr.game_id) as unique_games,
            MAX(gr.completed_at) as last_play,
            MIN(gr.completed_at) as first_play
        FROM users u
        LEFT JOIN game_results gr ON u.id = gr.student_id
        WHERE u.id = ? AND u.user_type = 'student'
        GROUP BY u.id
    ";
    
    $stmt = $conn->prepare($studentQuery);
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        throw new Exception('دانش‌آموز یافت نشد');
    }

    // عملکرد بر اساس دسته‌بندی
    $categoryPerformanceQuery = "
        SELECT 
            gc.name as category_name,
            gc.icon,
            gc.color,
            COUNT(gr.id) as plays_count,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time,
            SUM(gr.score) as total_score
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE gr.student_id = ? AND gc.id IS NOT NULL
        GROUP BY gc.id, gc.name, gc.icon, gc.color
        ORDER BY avg_score DESC
    ";
    
    $stmt = $conn->prepare($categoryPerformanceQuery);
    $stmt->execute([$studentId]);
    $categoryPerformance = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // پیشرفت در طول زمان (آخرین 30 روز)
    $progressQuery = "
        SELECT 
            DATE(gr.completed_at) as play_date,
            COUNT(*) as plays_count,
            AVG(gr.score) as avg_score,
            AVG(gr.accuracy) as avg_accuracy,
            AVG(gr.time_spent) as avg_time
        FROM game_results gr
        WHERE gr.student_id = ? 
        AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(gr.completed_at)
        ORDER BY play_date ASC
    ";
    
    $stmt = $conn->prepare($progressQuery);
    $stmt->execute([$studentId]);
    $progressData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // آخرین بازی‌ها
    $recentGamesQuery = "
        SELECT 
            gr.*,
            g.title as game_title,
            gc.name as category_name,
            gc.icon as category_icon,
            gc.color as category_color,
            g.difficulty,
            g.max_score as game_max_score
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE gr.student_id = ?
        ORDER BY gr.completed_at DESC
        LIMIT 10
    ";
    
    $stmt = $conn->prepare($recentGamesQuery);
    $stmt->execute([$studentId]);
    $recentGames = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // بهترین عملکردها
    $bestPerformancesQuery = "
        SELECT 
            gr.*,
            g.title as game_title,
            gc.name as category_name,
            gc.icon as category_icon,
            gc.color as category_color,
            g.difficulty
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE gr.student_id = ?
        ORDER BY gr.score DESC, gr.accuracy DESC
        LIMIT 5
    ";
    
    $stmt = $conn->prepare($bestPerformancesQuery);
    $stmt->execute([$studentId]);
    $bestPerformances = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // رنکینگ در کلاس
    $rankingQuery = "
        SELECT 
            (@rank := @rank + 1) as rank,
            student_data.*
        FROM (
            SELECT 
                u.id,
                CONCAT(u.first_name, ' ', u.last_name) as student_name,
                AVG(gr.score) as avg_score
            FROM users u
            LEFT JOIN game_results gr ON u.id = gr.student_id
            WHERE u.user_type = 'student'
            GROUP BY u.id
            HAVING avg_score IS NOT NULL
            ORDER BY avg_score DESC
        ) as student_data
        CROSS JOIN (SELECT @rank := 0) as r
    ";
    
    $stmt = $conn->prepare($rankingQuery);
    $stmt->execute();
    $allRankings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $studentRank = null;
    foreach ($allRankings as $ranking) {
        if ($ranking['id'] == $studentId) {
            $studentRank = $ranking['rank'];
            break;
        }
    }

    // آمار مقایسه‌ای
    $comparisonQuery = "
        SELECT 
            AVG(gr.score) as class_avg_score,
            AVG(gr.accuracy) as class_avg_accuracy,
            AVG(gr.time_spent) as class_avg_time,
            COUNT(DISTINCT gr.student_id) as total_students
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE u.user_type = 'student'
    ";
    
    $stmt = $conn->prepare($comparisonQuery);
    $stmt->execute();
    $classStats = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'student' => $student,
        'category_performance' => $categoryPerformance,
        'progress_data' => $progressData,
        'recent_games' => $recentGames,
        'best_performances' => $bestPerformances,
        'student_rank' => $studentRank,
        'total_students' => count($allRankings),
        'class_stats' => $classStats
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری جزئیات دانش‌آموز: ' . $e->getMessage()
    ]);
}
?>