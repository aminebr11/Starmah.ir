<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    die('لطفا وارد شوید');
}

$materialId = intval($_GET['id'] ?? 0);

if (!$materialId) {
    die('شناسه محتوا نامعتبر');
}

try {
    // Get material information
    $stmt = $conn->prepare("
        SELECT id, title, file_path, file_type 
        FROM materials 
        WHERE id = ?
    ");
    $stmt->execute([$materialId]);
    $material = $stmt->fetch();
    
    if (!$material) {
        die('محتوا یافت نشد');
    }
    
    $filePath = '../' . $material['file_path'];
    
    // Check if file exists
    if (!file_exists($filePath)) {
        die('فایل یافت نشد');
    }
    
    // Set headers based on file type
    $fileExtension = pathinfo($material['file_path'], PATHINFO_EXTENSION);
    $fileName = $material['title'] . '.' . $fileExtension;
    
    // Clean filename for download
    $fileName = preg_replace('/[^a-zA-Z0-9\-\_\. آ-ی]/u', '_', $fileName);
    
    // Set appropriate headers
    header('Content-Type: ' . $material['file_type']);
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Clear output buffer
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    // Read and output file
    readfile($filePath);
    
    // Log successful download
    error_log("Material downloaded: {$material['title']} (ID: {$materialId}) by user {$_SESSION['user_id']}");
    
    exit();
    
} catch(Exception $e) {
    die('خطا در دانلود فایل');
}
?>