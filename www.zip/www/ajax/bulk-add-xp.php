<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $studentIds = $input['student_ids'] ?? [];
    $subject = $input['subject'] ?? null;
    $xpAmount = (int)($input['xp_amount'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if (empty($studentIds) || !$subject || $xpAmount <= 0) {
        echo json_encode(['success' => false, 'message' => 'اطلاعات ناکامل']);
        exit();
    }
    
    $conn->beginTransaction();
    
    $successCount = 0;
    foreach ($studentIds as $studentId) {
        try {
            // بررسی/ایجاد رکورد XP
            $xpStmt = $conn->prepare("SELECT * FROM student_xp WHERE student_id = ?");
            $xpStmt->execute([$studentId]);
            $currentXP = $xpStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$currentXP) {
                $insertStmt = $conn->prepare("
                    INSERT INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level) 
                    VALUES (?, 0, 0, 0, 0, 0, 0, 1)
                ");
                $insertStmt->execute([$studentId]);
                
                $currentXP = [
                    'total_xp' => 0, 'math_xp' => 0, 'science_xp' => 0,
                    'persian_xp' => 0, 'social_xp' => 0, 'religion_xp' => 0, 'level' => 1
                ];
            }
            
            if ($subject === 'total') {
                $updateStmt = $conn->prepare("UPDATE student_xp SET total_xp = total_xp + ? WHERE student_id = ?");
                $updateStmt->execute([$xpAmount, $studentId]);
            } else {
                $subjectColumn = $subject . '_xp';
                $updateStmt = $conn->prepare("UPDATE student_xp SET $subjectColumn = $subjectColumn + ? WHERE student_id = ?");
                $updateStmt->execute([$xpAmount, $studentId]);
                
                // بروزرسانی کل
                $totalStmt = $conn->prepare("
                    UPDATE student_xp 
                    SET total_xp = math_xp + science_xp + persian_xp + social_xp + religion_xp 
                    WHERE student_id = ?
                ");
                $totalStmt->execute([$studentId]);
            }
            
            // بروزرسانی سطح
            $totalXPStmt = $conn->prepare("SELECT total_xp FROM student_xp WHERE student_id = ?");
            $totalXPStmt->execute([$studentId]);
            $totalXP = $totalXPStmt->fetchColumn();
            $newLevel = calculateLevel($totalXP);
            
            $levelStmt = $conn->prepare("UPDATE student_xp SET level = ? WHERE student_id = ?");
            $levelStmt->execute([$newLevel, $studentId]);
            
            // ثبت تاریخچه
            $historyStmt = $conn->prepare("
                INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $historyStmt->execute([$studentId, $subject, $xpAmount, $reason, $_SESSION['user_id']]);
            
            $successCount++;
            
        } catch (Exception $e) {
            error_log("Error updating XP for student $studentId: " . $e->getMessage());
        }
    }
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => "امتیاز به $successCount دانش‌آموز اضافه شد",
        'updated_count' => $successCount
    ]);
    
} catch (Exception $e) {
    $conn->rollBack();
    error_log("Error in bulk-add-xp.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در افزودن امتیاز گروهی: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

function calculateLevel($totalXP) {
    if ($totalXP >= 10000) return 5;
    if ($totalXP >= 5000) return 4;
    if ($totalXP >= 2000) return 3;
    if ($totalXP >= 500) return 2;
    return 1;
}
?>