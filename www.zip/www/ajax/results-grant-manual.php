<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$student_id = (int)($_POST['student_id'] ?? 0);
$points = (int)($_POST['points'] ?? 0);
if ($student_id<=0 || $points<=0) { echo json_encode(['success'=>false,'message'=>'ورودی نامعتبر']); exit; }

$manual_game_id = 0; // ← اگر FK دارید، این را به id بازی "امتیاز دستی" تغییر دهید.

try{
  $stmt = $conn->prepare("INSERT INTO game_results (student_id, game_id, score, max_possible_score, accuracy, time_spent, attempts, completed_at) VALUES (?,?,?,?,?,?,?,NOW())");
  $ok = $stmt->execute([$student_id, $manual_game_id, $points, 100, 0, 0, 1]);
  echo json_encode(['success'=>true,'inserted'=>$ok?1:0]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
