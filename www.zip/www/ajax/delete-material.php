<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);
$materialId = intval($data['material_id'] ?? 0);

if (!$materialId) {
    echo json_encode(['success' => false, 'message' => 'شناسه محتوا نامعتبر']);
    exit;
}

try {
    // Get material info first
    $stmt = $conn->prepare("SELECT id, title, file_path FROM materials WHERE id = ?");
    $stmt->execute([$materialId]);
    $material = $stmt->fetch();
    
    if (!$material) {
        echo json_encode(['success' => false, 'message' => 'محتوا یافت نشد']);
        exit;
    }
    
    // Delete the file from server if exists
    if ($material['file_path'] && file_exists('../' . $material['file_path'])) {
        unlink('../' . $material['file_path']);
    }
    
    // Delete from database
    $stmt = $conn->prepare("DELETE FROM materials WHERE id = ?");
    $stmt->execute([$materialId]);
    
    echo json_encode([
        'success' => true,
        'message' => 'محتوا با موفقیت حذف شد',
        'deleted_material' => $material['title']
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در حذف محتوا'
    ]);
}
?>