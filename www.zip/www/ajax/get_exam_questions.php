<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$config_paths = ['../config.php', '../../config.php'];
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

try {
    $examName = $_GET['exam'] ?? '';
    
    if (empty($examName)) {
        throw new Exception('نام آزمون مشخص نشده است');
    }
    
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("
        SELECT 
            id,
            question_text,
            question_type,
            options_json,
            question_image,
            image_position,
            score,
            answer_lines,
            section_title,
            section_icon
        FROM exam_questions 
        WHERE exam_name = ? AND teacher_id = ?
        ORDER BY id ASC
    ");
    
    $stmt->execute([$examName, $teacher_id]);
    $questions = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $question = [
            'id' => $row['id'],
            'text' => $row['question_text'],
            'type' => $row['question_type'],
            'score' => (float)$row['score'],
            'section' => $row['section_title'],
            'icon' => $row['section_icon']
        ];
        
        if ($row['options_json']) {
            $question['options'] = json_decode($row['options_json'], true);
        }
        
        if ($row['question_image']) {
            $question['image'] = $row['question_image'];
            $question['imagePosition'] = $row['image_position'];
        }
        
        if ($row['answer_lines']) {
            $question['answerLines'] = (int)$row['answer_lines'];
        }
        
        $questions[] = $question;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $questions
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => []
    ]);
}
?>