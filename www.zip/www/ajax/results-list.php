<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

// اگر سشن مشکل داشت، موقتاً این را کامنت کن
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$game_id = isset($_GET['game_id']) ? (int)$_GET['game_id'] : 0;
$student_query = trim($_GET['student_query'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to   = $_GET['date_to']   ?? '';

$where = [];
$params = [];
if ($game_id > 0) { $where[] = "gr.game_id = ?"; $params[] = $game_id; }
if ($student_query !== '') {
  $q = "%$student_query%";
  $where[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR u.national_id LIKE ?)";
  array_push($params, $q, $q, $q);
}
if ($date_from !== '') { $where[] = "DATE(gr.completed_at) >= ?"; $params[] = $date_from; }
if ($date_to   !== '') { $where[] = "DATE(gr.completed_at) <= ?"; $params[] = $date_to; }
$wsql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

try {
  // مجموع امتیاز هر دانش‌آموز برای رتبه کلی
  $totalsSql = "SELECT gr.student_id, SUM(gr.score) AS total_score FROM game_results gr GROUP BY gr.student_id";
  $totalsArr = $conn->query($totalsSql)->fetchAll(PDO::FETCH_ASSOC);
  $totals = [];
  foreach($totalsArr as $t){ $totals[(int)$t['student_id']] = (int)$t['total_score']; }

  // لیست نتایج
  $sql = "
    SELECT 
      gr.id, gr.student_id, gr.game_id, gr.score, gr.accuracy, gr.time_spent, gr.completed_at,
      u.first_name, u.last_name, u.national_id,
      g.title AS game_title,
      COALESCE(gc.name, g.subject) AS subject_name
    FROM game_results gr
    JOIN users u ON u.id = gr.student_id
    JOIN games g ON g.id = gr.game_id
    LEFT JOIN game_categories gc ON g.subject = gc.name
    $wsql
    ORDER BY gr.completed_at DESC
    LIMIT 500
  ";
  $stmt = $conn->prepare($sql);
  $stmt->execute($params);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  if (!$rows) {
    echo json_encode(['success'=>true,'items'=>[], 'stats'=>['total'=>0,'avg_score'=>0,'avg_accuracy'=>0,'avg_time'=>0]]);
    exit;
  }

  // رتبه در همان بازی (بدون window functions)
  $rankStmt = $conn->prepare("
    SELECT COUNT(*) AS better
    FROM game_results x
    WHERE x.game_id = ?
      AND (
        x.score > ? OR
        (x.score = ? AND COALESCE(x.time_spent, 999999) < COALESCE(?, 999999)) OR
        (x.score = ? AND COALESCE(x.time_spent, 999999) = COALESCE(?, 999999) AND x.completed_at < ?)
      )
  ");

  // ساخت خروجی با rank ها
  $items = [];
  foreach ($rows as $r) {
    // rank_in_game
    $rankStmt->execute([
      $r['game_id'],
      $r['score'], $r['score'],
      $r['time_spent'],
      $r['score'], $r['time_spent'],
      $r['completed_at']
    ]);
    $better = (int)$rankStmt->fetchColumn();
    $r['rank_in_game'] = $better + 1;

    // overall rank
    $studentId = (int)$r['student_id'];
    $totalScore = isset($totals[$studentId]) ? $totals[$studentId] : 0;
    $r['student_total_score'] = $totalScore;

    $higher = 0;
    foreach ($totals as $sid => $ts) if ($ts > $totalScore) $higher++;
    $r['overall_rank'] = $totalScore > 0 ? ($higher + 1) : null;

    $items[] = $r;
  }

  // آمار
  $stmt2 = $conn->prepare("
  SELECT 
  COUNT(*)                           AS total,
  CAST(AVG(score) AS DECIMAL(10,2))  AS avg_score,
  CAST(AVG(accuracy) AS DECIMAL(10,2)) AS avg_accuracy,
  CAST(AVG(COALESCE(time_spent,0)) AS DECIMAL(10,2)) AS avg_time
FROM game_results gr
JOIN users u ON u.id = gr.student_id
$wsql

  ");
  $stmt2->execute($params);
  $stats = $stmt2->fetch(PDO::FETCH_ASSOC) ?: ['total'=>0,'avg_score'=>0,'avg_accuracy'=>0,'avg_time'=>0];

  echo json_encode(['success'=>true, 'items'=>$items, 'stats'=>$stats]);

} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
