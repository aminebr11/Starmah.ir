<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

try {
    $sql = "SELECT id, name, icon, color, is_active, created_at FROM game_categories ORDER BY id DESC";
    $stmt = $conn->query($sql);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success'=>true,'items'=>$items]);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
