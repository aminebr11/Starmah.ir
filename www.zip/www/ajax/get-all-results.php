<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت خلاصه نتایج هر دانش‌آموز
    $stmt = $conn->prepare("
        SELECT 
            u.id as user_id,
            u.first_name,
            u.last_name,
            u.national_id,
            COUNT(gr.id) as games_count,
            SUM(gr.score) as total_score,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            AVG(gr.accuracy) as avg_accuracy,
            MAX(gr.completed_at) as last_play
        FROM users u
        LEFT JOIN game_results gr ON u.id = gr.student_id
        WHERE u.user_type = 'student'
        GROUP BY u.id
        HAVING games_count > 0
        ORDER BY total_score DESC, avg_score DESC
    ");
    
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // محاسبه آمار کلی
    $stats = [
        'total_students' => count($results),
        'total_games' => 0,
        'total_plays' => 0,
        'avg_score' => 0
    ];
    
    if (!empty($results)) {
        $stats['total_plays'] = array_sum(array_column($results, 'games_count'));
        $stats['avg_score'] = array_sum(array_column($results, 'avg_score')) / count($results);
    }
    
    // دریافت تعداد کل بازی‌ها
    $gameCountStmt = $conn->prepare("SELECT COUNT(*) as game_count FROM games WHERE is_active = 1");
    $gameCountStmt->execute();
    $gameCount = $gameCountStmt->fetch(PDO::FETCH_ASSOC);
    $stats['total_games'] = $gameCount['game_count'];
    
    // تبدیل مقادیر null به صفر و فرمت کردن
    foreach ($results as &$result) {
        $result['total_score'] = (int)($result['total_score'] ?? 0);
        $result['avg_score'] = (float)($result['avg_score'] ?? 0);
        $result['best_score'] = (int)($result['best_score'] ?? 0);
        $result['avg_accuracy'] = (float)($result['avg_accuracy'] ?? 0);
        $result['games_count'] = (int)($result['games_count'] ?? 0);
    }
    
    echo json_encode([
        'success' => true,
        'results' => $results,
        'stats' => $stats
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("Error in get-all-results.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت نتایج: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>