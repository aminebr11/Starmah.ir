<?php
session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر']);
    exit();
}

try {
    // اعتبارسنجی داده‌های ورودی
    $required_fields = ['game_id', 'title', 'category_id', 'game_code'];
    $missing_fields = [];
    
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $missing_fields[] = $field;
        }
    }
    
    if (!empty($missing_fields)) {
        echo json_encode([
            'success' => false,
            'message' => 'فیلدهای الزامی خالی هستند: ' . implode(', ', $missing_fields)
        ]);
        exit();
    }
    
    // پاکسازی و اعتبارسنجی داده‌ها
    $game_id = (int)$_POST['game_id'];
    $title = trim($_POST['title']);
    $category_id = (int)$_POST['category_id'];
    $topic = trim($_POST['topic'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $instructions = trim($_POST['instructions'] ?? '');
    $estimated_time = (int)($_POST['estimated_time'] ?? 5);
    $game_code = trim($_POST['game_code']);
    
    // اعتبارسنجی اضافی
    if ($game_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر است']);
        exit();
    }
    
    if (strlen($title) < 3) {
        echo json_encode(['success' => false, 'message' => 'عنوان بازی باید حداقل ۳ کاراکتر باشد']);
        exit();
    }
    
    if ($category_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'درس انتخاب‌شده نامعتبر است']);
        exit();
    }
    
    if ($estimated_time < 1 || $estimated_time > 60) {
        echo json_encode(['success' => false, 'message' => 'زمان تقریبی باید بین ۱ تا ۶۰ دقیقه باشد']);
        exit();
    }
    
    if (strlen($game_code) < 50) {
        echo json_encode(['success' => false, 'message' => 'کد بازی بیش از حد کوتاه است']);
        exit();
    }
    
    // بررسی وجود بازی
    $stmt = $conn->prepare("SELECT id, title FROM games WHERE id = :id");
    $stmt->execute([':id' => $game_id]);
    $existing_game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$existing_game) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
        exit();
    }
    
    // بررسی وجود دسته‌بندی
    $stmt = $conn->prepare("SELECT id, name FROM game_categories WHERE id = :id AND is_active = 1");
    $stmt->execute([':id' => $category_id]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی انتخاب‌شده یافت نشد']);
        exit();
    }
    
    // بررسی تکراری نبودن عنوان (جز خود بازی)
    $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE title = :title AND id != :id");
    $stmt->execute([':title' => $title, ':id' => $game_id]);
    
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'بازی دیگری با این عنوان وجود دارد']);
        exit();
    }
    
    // بروزرسانی بازی
    $sql = "
        UPDATE games SET 
            title = :title,
            description = :description,
            category_id = :category_id,
            subject = :subject,
            topic = :topic,
            estimated_time = :estimated_time,
            game_code = :game_code,
            instructions = :instructions
        WHERE id = :id
    ";
    
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([
        ':title' => $title,
        ':description' => $description,
        ':category_id' => $category_id,
        ':subject' => $category['name'],
        ':topic' => $topic,
        ':estimated_time' => $estimated_time,
        ':game_code' => $game_code,
        ':instructions' => $instructions,
        ':id' => $game_id
    ]);
    
    if ($result) {
        // ثبت لاگ
        error_log("Admin {$_SESSION['user_id']} updated game: {$game_id} - '{$title}'");
        
        echo json_encode([
            'success' => true,
            'message' => 'بازی با موفقیت بروزرسانی شد',
            'game_id' => $game_id,
            'game_title' => $title
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی بازی']);
    }
    
} catch (PDOException $e) {
    error_log("خطا در ویرایش بازی: " . $e->getMessage());
    
    // بررسی خطای کلید تکراری
    if ($e->getCode() == 23000) {
        echo json_encode([
            'success' => false,
            'message' => 'بازی با این مشخصات قبلاً ثبت شده است'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'خطا در اتصال به پایگاه داده'
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    error_log("خطای عمومی در ویرایش بازی: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای نامشخص رخ داد'
    ], JSON_UNESCAPED_UNICODE);
}
?>