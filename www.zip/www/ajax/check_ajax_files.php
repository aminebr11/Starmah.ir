<?php
// فایل: check_ajax_files.php - در پوشه ajax قرار دهید

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html lang='fa' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <title>بررسی فایل‌های AJAX</title>
    <style>
        body { font-family: Tahoma; margin: 20px; }
        .exists { color: green; background: #d4edda; padding: 10px; margin: 5px; border-radius: 5px; }
        .missing { color: red; background: #f8d7da; padding: 10px; margin: 5px; border-radius: 5px; }
        .info { background: #cce5ff; padding: 15px; margin: 10px 0; border-radius: 5px; }
    </style>
</head>
<body>";

echo "<h1>🔍 بررسی فایل‌های AJAX</h1>";

// لیست فایل‌های مورد نیاز
$required_files = [
    'load_games.php',
    'add_game.php', 
    'edit_game.php',
    'get_game.php',
    'toggle_game_status.php',
    'delete_game.php',
    'get_game_results.php',
    'test.php'
];

echo "<div class='info'>";
echo "<h3>📂 اطلاعات پوشه فعلی:</h3>";
echo "<p><strong>مسیر:</strong> " . __DIR__ . "</p>";
echo "<p><strong>فایل‌های موجود:</strong></p>";

$existing_files = scandir('.');
echo "<ul>";
foreach ($existing_files as $file) {
    if ($file !== '.' && $file !== '..') {
        echo "<li>$file</li>";
    }
}
echo "</ul>";
echo "</div>";

echo "<h2>📋 بررسی فایل‌های الزامی:</h2>";

foreach ($required_files as $file) {
    if (file_exists($file)) {
        $size = filesize($file);
        echo "<div class='exists'>✅ <strong>$file</strong> - وجود دارد (حجم: $size بایت)</div>";
        
        // بررسی محتوای فایل
        if ($size > 0) {
            $content = file_get_contents($file, false, null, 0, 200);
            if (strpos($content, '<?php') !== false) {
                echo "<small style='margin-left: 20px;'>✅ فایل PHP معتبر</small><br>";
            } else {
                echo "<small style='margin-left: 20px; color: orange;'>⚠️ ممکن است فایل PHP نباشد</small><br>";
            }
        }
    } else {
        echo "<div class='missing'>❌ <strong>$file</strong> - وجود ندارد</div>";
    }
}

// تست اجرای فایل‌ها
echo "<h2>🔧 تست اجرای فایل‌ها:</h2>";

foreach (['toggle_game_status.php', 'delete_game.php'] as $file) {
    if (file_exists($file)) {
        echo "<h3>تست $file:</h3>";
        echo "<button onclick=\"testFile('$file')\">تست اجرا</button>";
        echo "<div id='result_$file'></div>";
    }
}

echo "
<script>
function testFile(filename) {
    const resultDiv = document.getElementById('result_' + filename);
    resultDiv.innerHTML = 'در حال تست...';
    
    // تست GET
    fetch(filename)
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML = `
                <div style='background: #e7f3ff; padding: 10px; margin: 5px; border-radius: 5px;'>
                    <strong>GET Test:</strong> ${data.substring(0, 200)}...
                </div>
            `;
            
            // تست POST
            return fetch(filename, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({test: true})
            });
        })
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML += `
                <div style='background: #f0f8e7; padding: 10px; margin: 5px; border-radius: 5px;'>
                    <strong>POST Test:</strong> ${data.substring(0, 200)}...
                </div>
            `;
        })
        .catch(error => {
            resultDiv.innerHTML += `
                <div style='background: #ffe7e7; padding: 10px; margin: 5px; border-radius: 5px;'>
                    <strong>Error:</strong> ${error.message}
                </div>
            `;
        });
}
</script>

</body>
</html>";
?>