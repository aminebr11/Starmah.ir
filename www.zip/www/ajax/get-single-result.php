<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

$resultId = $_GET['id'] ?? null;

if (!$resultId) {
    echo json_encode(['success' => false, 'message' => 'شناسه نتیجه ارسال نشده']);
    exit();
}

try {
    $stmt = $conn->prepare("
        SELECT id, score, time_spent, accuracy, completed_at
        FROM game_results 
        WHERE id = ?
    ");
    
    $stmt->execute([$resultId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'نتیجه یافت نشد']);
        exit();
    }
    
    echo json_encode([
        'success' => true,
        'result' => $result
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت نتیجه: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>