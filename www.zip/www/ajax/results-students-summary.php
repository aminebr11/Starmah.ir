<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$q = trim($_GET['q'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to   = $_GET['date_to']   ?? '';

$where = [];
$params = [];
if ($q !== '') {
  $like = "%$q%";
  $where[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR u.national_id LIKE ?)";
  array_push($params, $like, $like, $like);
}
if ($date_from !== '') { $where[] = "DATE(gr.completed_at) >= ?"; $params[] = $date_from; }
if ($date_to   !== '') { $where[] = "DATE(gr.completed_at) <= ?"; $params[] = $date_to; }
$wsql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

try {
  $sql = "
    WITH filtered AS (
      SELECT gr.student_id, gr.score, gr.accuracy, COALESCE(gr.time_spent,0) AS time_spent
      FROM game_results gr
      JOIN users u ON u.id = gr.student_id
      $wsql
    ),
    agg AS (
      SELECT 
        student_id,
        COUNT(*) AS plays,
        SUM(score) AS total_score,
        AVG(score) AS avg_score,
        AVG(accuracy) AS avg_accuracy,
        SUM(time_spent) AS total_time
      FROM filtered
      GROUP BY student_id
    ),
    ranked AS (
      SELECT 
        a.*,
        DENSE_RANK() OVER (ORDER BY a.total_score DESC) AS overall_rank
      FROM agg a
    )
    SELECT 
      r.student_id, r.plays, r.total_score, r.avg_score, r.avg_accuracy, r.total_time, r.overall_rank,
      u.first_name, u.last_name, u.national_id
    FROM ranked r
    JOIN users u ON u.id = r.student_id
    ORDER BY r.total_score DESC
    LIMIT 1000
  ";
  $stmt = $conn->prepare($sql);
  $stmt->execute($params);
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // آمار کلی
  $sql2 = "
    SELECT 
      COUNT(DISTINCT gr.student_id) AS students,
      COUNT(*) AS plays,
      AVG(gr.score) AS avg_score,
      AVG(gr.accuracy) AS avg_accuracy,
      AVG(COALESCE(gr.time_spent,0)) AS avg_time
    FROM game_results gr
    JOIN users u ON u.id = gr.student_id
    $wsql
  ";
  $stmt2 = $conn->prepare($sql2);
  $stmt2->execute($params);
  $stats = $stmt2->fetch(PDO::FETCH_ASSOC) ?: ['students'=>0,'plays'=>0,'avg_score'=>0,'avg_accuracy'=>0,'avg_time'=>0];

  echo json_encode(['success'=>true,'items'=>$items,'stats'=>$stats]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
