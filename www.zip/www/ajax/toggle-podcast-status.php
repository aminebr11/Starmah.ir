<?php
// ajax/toggle-podcast-status.php

// 1. ابتدا فایل کانفیگ را برای اتصال به دیتابیس لود می‌کنیم
require_once '../config.php'; 

// 2. سپس فایل توابع را لود می‌کنیم تا به تابع isAdmin دسترسی داشته باشیم
require_once '../functions.php'; 

header('Content-Type: application/json');

// فقط ادمین بتواند این کار را انجام دهد
if (!isAdmin()) {
    http_response_code(403); // Forbidden
    echo json_encode(['success' => false, 'message' => 'Unauthorized: Admin access required.']);
    exit();
}

// دریافت داده‌های ارسالی
 $data = json_decode(file_get_contents('php://input'), true);
 $podcast_id = $data['id'] ?? null;
 $is_active = $data['is_active'] ?? null;

if (!$podcast_id || $is_active === null) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Invalid data provided.']);
    exit();
}

try {
    // استفاده از PDO برای آماده‌سازی و اجرای کوئری
    $sql = "UPDATE podcasts SET is_active = :is_active WHERE id = :id";
    $stmt = $conn->prepare($sql);
    
    // اتصال مقادیر به پارامترهای نام‌گذاری شده
    $stmt->bindParam(':is_active', $is_active, PDO::PARAM_INT);
    $stmt->bindParam(':id', $podcast_id, PDO::PARAM_INT);
    
    // اجرای کوئری
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database update failed.']);
    }
    
    $stmt = null;

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

?>