<?php
// فایل ajax/get_exam_results.php - نسخه تصحیح شده

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// فعال‌سازی نمایش خطاها برای debug
error_reporting(E_ALL);
ini_set('display_errors', 0); // خطاها را در لاگ ذخیره می‌کند، نه نمایش

// تابع debug برای نمایش خطاهای دقیق
function debugResponse($message, $error = null, $data = null) {
    $response = [
        'success' => false,
        'message' => $message,
        'debug' => true,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    if ($error) {
        $response['error_details'] = $error;
    }
    
    if ($data) {
        $response['debug_data'] = $data;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// بررسی method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    debugResponse('Method not allowed', 'Only POST method is accepted');
}

// شروع session
session_start();

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    debugResponse('User ID not set in session', null, ['session_keys' => array_keys($_SESSION)]);
}

if (!isset($_SESSION['user_type'])) {
    debugResponse('User type not set in session', null, ['session_keys' => array_keys($_SESSION)]);
}

if ($_SESSION['user_type'] !== 'student') {
    debugResponse('Invalid user type', null, ['user_type' => $_SESSION['user_type']]);
}

// بارگذاری config
$configPaths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$configLoaded = false;
$configPath = '';

foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $configLoaded = true;
        $configPath = $path;
        break;
    }
}

if (!$configLoaded) {
    debugResponse('Config file not found', null, [
        'tested_paths' => $configPaths,
        'current_dir' => __DIR__
    ]);
}

if (!isset($conn)) {
    debugResponse('Database connection variable not found', null, [
        'config_path' => $configPath,
        'defined_vars' => array_keys(get_defined_vars())
    ]);
}

// تست اتصال پایگاه داده
try {
    $testStmt = $conn->prepare("SELECT 1");
    $testStmt->execute();
} catch (Exception $e) {
    debugResponse('Database connection test failed', $e->getMessage());
}

// خواندن داده ورودی
$rawInput = file_get_contents('php://input');
if (empty($rawInput)) {
    debugResponse('No input data received', null, [
        'method' => $_SERVER['REQUEST_METHOD'],
        'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'not set'
    ]);
}

$input = json_decode($rawInput, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    debugResponse('Invalid JSON input', json_last_error_msg(), [
        'raw_input' => substr($rawInput, 0, 200)
    ]);
}

if (!isset($input['exam_id'])) {
    debugResponse('Exam ID not provided', null, ['input' => $input]);
}

$examId = (int)$input['exam_id'];
$userId = $_SESSION['user_id'];

if ($examId <= 0) {
    debugResponse('Invalid exam ID', null, [
        'exam_id' => $examId,
        'original_value' => $input['exam_id']
    ]);
}

try {
    // ابتدا بررسی کنیم که آیا جدول quiz_attempts وجود دارد
    $stmt = $conn->prepare("SHOW TABLES LIKE 'quiz_attempts'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        debugResponse('Table quiz_attempts does not exist');
    }
    
    // ابتدا بررسی کنیم که آیا جدول quizzes وجود دارد  
    $stmt = $conn->prepare("SHOW TABLES LIKE 'quizzes'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        debugResponse('Table quizzes does not exist');
    }
    
    // بررسی وجود رکورد در quiz_attempts
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?");
    $stmt->execute([$examId, $userId]);
    $attemptExists = $stmt->fetch()['count'];
    
    if ($attemptExists == 0) {
        debugResponse('No attempt found for this quiz', null, [
            'exam_id' => $examId,
            'user_id' => $userId,
            'note' => 'Student has not attempted this quiz yet'
        ]);
    }
    
    // دریافت نتیجه آزمون با کوئری ساده‌تر
    $stmt = $conn->prepare("
        SELECT qa.id, qa.quiz_id, qa.student_id, qa.score, qa.total_score, 
               qa.time_taken, qa.submitted_at, q.title as quiz_title 
        FROM quiz_attempts qa 
        LEFT JOIN quizzes q ON qa.quiz_id = q.id 
        WHERE qa.quiz_id = ? AND qa.student_id = ?
        ORDER BY qa.submitted_at DESC
        LIMIT 1
    ");
    $stmt->execute([$examId, $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$result) {
        debugResponse('No result found despite attempt existing', null, [
            'exam_id' => $examId,
            'user_id' => $userId
        ]);
    }
    
    // محاسبه درصد
    $percentage = 0;
    if ($result['total_score'] > 0) {
        $percentage = round(($result['score'] / $result['total_score']) * 100, 1);
    }
    
    // دریافت رتبه (ساده‌تر)
    $rank = 1;
    $totalParticipants = 1;
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM quiz_attempts WHERE quiz_id = ?");
        $stmt->execute([$examId]);
        $totalParticipants = $stmt->fetch()['total'];
        
        $stmt = $conn->prepare("SELECT COUNT(*) + 1 as rank FROM quiz_attempts WHERE quiz_id = ? AND score > ?");
        $stmt->execute([$examId, $result['score']]);
        $rank = $stmt->fetch()['rank'];
    } catch (Exception $e) {
        // اگر محاسبه رتبه خطا داد، مقادیر پیش‌فرض را نگه می‌داریم
        error_log("Rank calculation error: " . $e->getMessage());
    }
    
    // پاسخ موفق
    echo json_encode([
        'success' => true,
        'message' => 'Results retrieved successfully',
        'result' => [
            'quiz_title' => $result['quiz_title'] ?: 'نامشخص',
            'score' => (int)$result['score'],
            'total_score' => (int)$result['total_score'],
            'percentage' => $percentage,
            'time_taken' => (int)$result['time_taken'],
            'submitted_at' => $result['submitted_at'],
            'rank' => $rank,
            'total_participants' => $totalParticipants
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    debugResponse('Database PDO error', $e->getMessage(), [
        'error_code' => $e->getCode(),
        'sql_state' => $e->errorInfo[0] ?? 'unknown'
    ]);
} catch (Exception $e) {
    debugResponse('General error', $e->getMessage(), [
        'error_type' => get_class($e),
        'line' => $e->getLine(),
        'file' => basename($e->getFile())
    ]);
}
?>