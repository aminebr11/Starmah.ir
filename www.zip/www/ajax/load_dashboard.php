<?php
// ajax/load_dashboard.php - فایل AJAX برای لود کردن صفحه داشبورد

// تنظیم header
header('Content-Type: text/html; charset=utf-8');

// شروع session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// بررسی درخواست AJAX
$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
          strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

try {
    // مسیر فایل داشبورد
    $dashboard_file = '../sections/dashboard.php';
    
    // بررسی وجود فایل
    if (!file_exists($dashboard_file)) {
        throw new Exception('فایل داشبورد یافت نشد در مسیر: ' . $dashboard_file);
    }
    
    // شامل کردن فایل config اگر نیاز است
    $config_files = [
        '../config.php',
        '../includes/config.php',
        '../db_config.php'
    ];
    
    foreach ($config_files as $config_file) {
        if (file_exists($config_file)) {
            include_once $config_file;
            break;
        }
    }
    
    // تنظیم متغیرهای مورد نیاز اگر وجود ندارند
    if (!isset($userType)) {
        $userType = $_SESSION['user_type'] ?? $_SESSION['userType'] ?? 'student';
    }
    
    // شروع output buffering
    ob_start();
    
    // لود کردن صفحه داشبورد
    include $dashboard_file;
    
    // گرفتن محتوا
    $content = ob_get_clean();
    
    // بررسی اینکه محتوایی تولید شده یا نه
    if (empty(trim($content))) {
        throw new Exception('صفحه داشبورد محتوایی تولید نکرد');
    }
    
    // ارسال پاسخ
    if ($isAjax) {
        // پاسخ JSON برای درخواست AJAX
        echo json_encode([
            'success' => true,
            'content' => $content,
            'message' => 'داشبورد با موفقیت لود شد'
        ]);
    } else {
        // پاسخ مستقیم HTML
        echo $content;
    }
    
} catch (Exception $e) {
    // مدیریت خطا
    $error_message = $e->getMessage();
    
    if ($isAjax) {
        echo json_encode([
            'success' => false,
            'error' => true,
            'message' => $error_message
        ]);
    } else {
        echo '<div style="color: red; text-align: center; padding: 2rem; background: #ffe6e6; border: 2px solid #ff6b6b; border-radius: 10px; margin: 20px;">
                <h3>⚠️ خطا در بارگذاری داشبورد</h3>
                <p>' . htmlspecialchars($error_message) . '</p>
                <button onclick="location.reload()" style="background: #ff6b6b; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; margin-top: 15px;">🔄 تلاش مجدد</button>
              </div>';
    }
}
?>