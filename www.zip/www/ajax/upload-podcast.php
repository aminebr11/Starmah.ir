<?php
// Error reporting برای debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// شروع session
session_start();

// اضافه کردن timeout برای عملیات طولانی
set_time_limit(300); // 5 دقیقه
ini_set('max_execution_time', 300);

// بررسی مسیر فایل config
$config_paths = [
    '../config.php',
    '../../config.php',
    dirname(__DIR__) . '/config.php'
];

$functions_paths = [
    '../functions.php', 
    '../../functions.php',
    dirname(__DIR__) . '/functions.php'
];

$config_loaded = false;
$functions_loaded = false;

foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

foreach ($functions_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functions_loaded = true;
        break;
    }
}

// تنظیم header برای JSON response
header('Content-Type: application/json; charset=utf-8');

// logging function برای debug
function debug_log($message) {
    error_log("[Upload Debug] " . $message);
}

debug_log("Upload request started");

if (!$config_loaded) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در بارگذاری تنظیمات (config.php not found)',
        'debug' => 'config file paths checked: ' . implode(', ', $config_paths)
    ]);
    exit;
}

if (!$functions_loaded) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در بارگذاری توابع (functions.php not found)',
        'debug' => 'functions file paths checked: ' . implode(', ', $functions_paths)
    ]);
    exit;
}

// بررسی وجود تابع isAdmin
if (!function_exists('isAdmin')) {
    echo json_encode([
        'success' => false, 
        'message' => 'تابع isAdmin تعریف نشده',
        'debug' => 'isAdmin function not found in functions.php'
    ]);
    exit;
}

// Check if user is admin
if (!isAdmin()) {
    debug_log("User is not admin");
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

debug_log("User is admin - continuing");

// بررسی محدودیت‌های PHP
$max_filesize = ini_get('upload_max_filesize');
$max_post_size = ini_get('post_max_size');
$max_execution_time = ini_get('max_execution_time');

debug_log("PHP limits - upload_max_filesize: $max_filesize, post_max_size: $max_post_size, max_execution_time: $max_execution_time");

// Check if file was uploaded
if (!isset($_FILES['audio_file'])) {
    debug_log("No file uploaded - FILES array: " . print_r($_FILES, true));
    echo json_encode([
        'success' => false, 
        'message' => 'هیچ فایلی انتخاب نشده',
        'debug' => 'No audio_file in $_FILES'
    ]);
    exit;
}

$file = $_FILES['audio_file'];
debug_log("File upload error code: " . $file['error']);

// بررسی خطاهای آپلود
if ($file['error'] !== UPLOAD_ERR_OK) {
    $errors = [
        UPLOAD_ERR_INI_SIZE => "فایل از حداکثر حجم مجاز PHP بیشتر است (max: $max_filesize)",
        UPLOAD_ERR_FORM_SIZE => 'فایل از حداکثر حجم مجاز فرم بیشتر است',
        UPLOAD_ERR_PARTIAL => 'فایل به طور ناقص آپلود شده است',
        UPLOAD_ERR_NO_FILE => 'هیچ فایلی انتخاب نشده',
        UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت موجود نیست', 
        UPLOAD_ERR_CANT_WRITE => 'امکان نوشتن فایل وجود ندارد',
        UPLOAD_ERR_EXTENSION => 'آپلود فایل توسط افزونه متوقف شده است'
    ];
    
    $error_msg = $errors[$file['error']] ?? 'خطای نامشخص در آپلود';
    debug_log("Upload error: " . $error_msg);
    
    echo json_encode([
        'success' => false, 
        'message' => $error_msg,
        'debug' => 'Upload error code: ' . $file['error']
    ]);
    exit;
}

// Get form data
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$duration = trim($_POST['duration'] ?? '');

debug_log("Form data - Title: '$title', Description: '$description', Duration: '$duration'");

if (empty($title)) {
    echo json_encode(['success' => false, 'message' => 'عنوان الزامی است']);
    exit;
}

// بررسی حجم فایل (500MB = 524288000 bytes)
$max_size = 524288000; // 500MB
if ($file['size'] > $max_size) {
    $max_mb = round($max_size / 1024 / 1024, 1);
    echo json_encode([
        'success' => false, 
        'message' => "حجم فایل نباید از {$max_mb} مگابایت بیشتر باشد",
        'debug' => 'File size: ' . round($file['size'] / 1024 / 1024, 1) . 'MB'
    ]);
    exit;
}

// Extended file types - both audio and video formats
$allowedExtensions = [
    // Audio formats
    'mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'wma', 'amr', 'opus',
    // Video formats  
    'mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', '3gp', 'm4v', 'ogv'
];

// بررسی نوع فایل
$fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
debug_log("File extension: $fileExtension");

if (!in_array($fileExtension, $allowedExtensions)) {
    echo json_encode([
        'success' => false, 
        'message' => 'نوع فایل مجاز نیست. انواع مجاز: ' . implode(', ', $allowedExtensions),
        'debug' => 'File extension not allowed: ' . $fileExtension
    ]);
    exit;
}

// ایجاد پوشه uploads اگر وجود ندارد
$uploadDir = '../uploads/podcasts/';
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true)) {
        debug_log("Failed to create directory: $uploadDir");
        echo json_encode([
            'success' => false, 
            'message' => 'امکان ایجاد پوشه آپلود وجود ندارد',
            'debug' => 'mkdir failed for: ' . $uploadDir
        ]);
        exit;
    }
    debug_log("Created directory: $uploadDir");
}

// بررسی مجوز نوشتن
if (!is_writable($uploadDir)) {
    debug_log("Directory not writable: $uploadDir");
    echo json_encode([
        'success' => false,
        'message' => 'پوشه آپلود قابل نوشتن نیست. مجوزها را بررسی کنید',
        'debug' => 'Directory not writable: ' . $uploadDir
    ]);
    exit;
}

// تولید نام یکتا برای فایل
$fileName = date('Y_m_d_H_i_s') . '_' . uniqid() . '.' . $fileExtension;
$filePath = $uploadDir . $fileName;
$relativePath = 'uploads/podcasts/' . $fileName;

debug_log("Target file path: $filePath");

// انتقال فایل
if (!move_uploaded_file($file['tmp_name'], $filePath)) {
    debug_log("Failed to move uploaded file from {$file['tmp_name']} to $filePath");
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ذخیره فایل',
        'debug' => 'move_uploaded_file failed'
    ]);
    exit;
}

debug_log("File moved successfully to: $filePath");

try {
    // Get file type for database
    $videoFormats = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', '3gp', 'm4v', 'ogv'];
    $fileType = in_array($fileExtension, $videoFormats) ? 'video' : 'audio';
    
    debug_log("File type determined: $fileType");
    
    // Check database connection
    if (!isset($conn)) {
        throw new Exception('Database connection not available');
    }
    
    // Save to database
    $stmt = $conn->prepare("
        INSERT INTO podcasts (title, description, file_path, duration, file_type, created_by, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $result = $stmt->execute([
        $title,
        $description, 
        $relativePath,
        $duration,
        $fileType,
        $_SESSION['user_id']
    ]);
    
    if (!$result) {
        throw new Exception('Database insert failed');
    }
    
    $podcast_id = $conn->lastInsertId();
    debug_log("Podcast inserted successfully with ID: $podcast_id");
    
    echo json_encode([
        'success' => true,
        'message' => 'پادکست با موفقیت آپلود شد',
        'file_type' => $fileType,
        'file_size' => round($file['size'] / 1024 / 1024, 1) . ' MB',
        'podcast_id' => $podcast_id
    ]);
    
} catch(PDOException $e) {
    // Delete uploaded file on database error
    if (file_exists($filePath)) {
        unlink($filePath);
        debug_log("Deleted file due to database error: $filePath");
    }
    
    $error_message = $e->getMessage();
    debug_log("PDO Exception: $error_message");
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ذخیره اطلاعات در پایگاه داده',
        'debug' => 'PDO Error: ' . $error_message
    ]);
} catch(Exception $e) {
    // Delete uploaded file on general error
    if (file_exists($filePath)) {
        unlink($filePath);
        debug_log("Deleted file due to general error: $filePath");
    }
    
    $error_message = $e->getMessage();
    debug_log("General Exception: $error_message");
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پردازش درخواست',
        'debug' => 'Error: ' . $error_message
    ]);
}

debug_log("Upload process completed");
?>