<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت داده‌ها
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('داده‌ای دریافت نشد');
    }
    
    // اعتبارسنجی فیلدهای الزامی
    if (empty($input['game_id'])) {
        throw new Exception('شناسه بازی الزامی است');
    }
    
    if (empty($input['title'])) {
        throw new Exception('عنوان بازی الزامی است');
    }
    
    if (empty($input['category_id'])) {
        throw new Exception('انتخاب درس الزامی است');
    }
    
    if (empty($input['game_code'])) {
        throw new Exception('کد بازی الزامی است');
    }
    
    // پردازش داده‌ها
    $game_id = intval($input['game_id']);
    $title = trim($input['title']);
    $category_id = intval($input['category_id']);
    $estimated_time = intval($input['estimated_time'] ?? 5);
    $topic = trim($input['topic'] ?? '');
    $description = trim($input['description'] ?? '');
    $instructions = trim($input['instructions'] ?? '');
    $game_code = trim($input['game_code']);
    $difficulty = $input['difficulty'] ?? 'medium';
    
    // بررسی وجود بازی
    $check_stmt = $conn->prepare("SELECT id FROM games WHERE id = ?");
    $check_stmt->execute([$game_id]);
    if (!$check_stmt->fetch()) {
        throw new Exception('بازی مورد نظر یافت نشد');
    }
    
    // دریافت نام درس از جدول game_categories
    $cat_stmt = $conn->prepare("SELECT name FROM game_categories WHERE id = ? AND is_active = 1");
    $cat_stmt->execute([$category_id]);
    $category = $cat_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        throw new Exception('دسته‌بندی انتخاب شده نامعتبر است');
    }
    
    $subject = $category['name'];
    
    // بررسی ساختار جدول
    $columns_stmt = $conn->query("DESCRIBE games");
    $columns = $columns_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $hasCategory = in_array('category_id', $columns);
    $hasDifficulty = in_array('difficulty', $columns);
    $hasUpdatedAt = in_array('updated_at', $columns);
    
    // ساخت query برای بروزرسانی
    $update_fields = [
        'title = ?',
        'subject = ?',
        'estimated_time = ?',
        'topic = ?',
        'description = ?',
        'instructions = ?',
        'game_code = ?'
    ];
    
    $values = [
        $title,
        $subject,
        $estimated_time,
        $topic,
        $description,
        $instructions,
        $game_code
    ];
    
    // افزودن ستون category_id اگر وجود دارد
    if ($hasCategory) {
        $update_fields[] = 'category_id = ?';
        $values[] = $category_id;
    }
    
    // افزودن ستون difficulty اگر وجود دارد
    if ($hasDifficulty) {
        $update_fields[] = 'difficulty = ?';
        $values[] = $difficulty;
    }
    
    // افزودن ستون updated_at اگر وجود دارد
    if ($hasUpdatedAt) {
        $update_fields[] = 'updated_at = NOW()';
    }
    
    // افزودن game_id برای WHERE
    $values[] = $game_id;
    
    // ساخت query نهایی
    $sql = "UPDATE games SET " . implode(', ', $update_fields) . " WHERE id = ?";
    
    // اجرای query
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute($values);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'بازی با موفقیت بروزرسانی شد',
            'game_id' => $game_id,
            'category_id' => $category_id,
            'subject' => $subject,
            'debug_info' => [
                'sql' => $sql,
                'affected_rows' => $stmt->rowCount()
            ]
        ]);
    } else {
        throw new Exception('خطا در بروزرسانی بازی در دیتابیس');
    }
    
} catch (PDOException $e) {
    error_log("Database Error in update-game: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in update-game: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ]);
}
?>