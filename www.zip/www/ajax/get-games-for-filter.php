<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    $stmt = $conn->prepare("
        SELECT id, title 
        FROM games 
        WHERE is_active = 1 
        ORDER BY title
    ");
    
    $stmt->execute();
    $games = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'games' => $games
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت بازی‌ها: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>