<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// Debug mode - حذف کنید بعد از حل مشکل
error_reporting(E_ALL);
ini_set('display_errors', 0); // خطاها را لاگ می‌کند اما نمایش نمی‌دهد

header('Content-Type: application/json; charset=utf-8');

try {
    // Check if user is admin - بررسی دقیق‌تر
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید']);
        exit;
    }

    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'فقط ادمین می‌تواند فایل آپلود کند']);
        exit;
    }

    // Check if file was uploaded
    if (!isset($_FILES['material_file'])) {
        echo json_encode(['success' => false, 'message' => 'فایلی انتخاب نشده است']);
        exit;
    }

    $file = $_FILES['material_file'];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'فایل بزرگتر از حد مجاز سرور است',
            UPLOAD_ERR_FORM_SIZE => 'فایل بزرگتر از حد مجاز فرم است', 
            UPLOAD_ERR_PARTIAL => 'فایل به صورت ناقص آپلود شد',
            UPLOAD_ERR_NO_FILE => 'هیچ فایلی انتخاب نشده است',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت موجود نیست',
            UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل',
            UPLOAD_ERR_EXTENSION => 'آپلود فایل توسط افزونه متوقف شد'
        ];
        
        $message = $errorMessages[$file['error']] ?? 'خطای ناشناخته در آپلود';
        echo json_encode(['success' => false, 'message' => $message]);
        exit;
    }

    // Get and sanitize form data
    $title = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $description = trim($_POST['content'] ?? ''); // اصلاح شده به content

    // Validation
    if (empty($title)) {
        $title = pathinfo($file['name'], PATHINFO_FILENAME);
    }
    
    if (empty($subject)) {
        echo json_encode(['success' => false, 'message' => 'لطفاً موضوع را انتخاب کنید']);
        exit;
    }

    // Auto-detect subject if needed
    if ($subject === 'auto') {
        $filename = strtolower($file['name']);
        if (strpos($filename, 'ریاضی') !== false || strpos($filename, 'math') !== false) {
            $subject = 'math';
        } elseif (strpos($filename, 'علوم') !== false || strpos($filename, 'science') !== false) {
            $subject = 'science';
        } elseif (strpos($filename, 'فارسی') !== false || strpos($filename, 'persian') !== false) {
            $subject = 'persian';
        } elseif (strpos($filename, 'اجتماعی') !== false || strpos($filename, 'social') !== false) {
            $subject = 'social';
        } elseif (strpos($filename, 'دینی') !== false || strpos($filename, 'religion') !== false) {
            $subject = 'religion';
        } else {
            $subject = 'math'; // Default
        }
    }

    // بررسی حجم فایل (100 مگابایت)
    $maxSize = 100 * 1024 * 1024; // 100MB
    if ($file['size'] > $maxSize) {
        echo json_encode(['success' => false, 'message' => 'حجم فایل نباید بیش از 100 مگابایت باشد']);
        exit;
    }

    // Create upload directory
    $uploadDir = '../uploads/materials/';
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            echo json_encode(['success' => false, 'message' => 'خطا در ایجاد پوشه آپلود']);
            exit;
        }
    }

    // Generate unique filename
    $fileInfo = pathinfo($file['name']);
    $extension = isset($fileInfo['extension']) ? '.' . strtolower($fileInfo['extension']) : '';
    $fileName = 'material_' . uniqid() . '_' . time() . $extension;
    $targetPath = $uploadDir . $fileName;
    $relativePath = 'uploads/materials/' . $fileName;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        echo json_encode(['success' => false, 'message' => 'خطا در انتقال فایل آپلود شده']);
        exit;
    }

    // Determine file type
    $fileType = $file['type'] ?? 'application/octet-stream';
    
    if (empty($fileType) || $fileType === 'application/octet-stream') {
        $ext = strtolower($fileInfo['extension'] ?? '');
        $mimeTypes = [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'ppt' => 'application/vnd.ms-powerpoint',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'txt' => 'text/plain',
            'rtf' => 'application/rtf',
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            '7z' => 'application/x-7z-compressed',
            'tar' => 'application/x-tar',
            'gz' => 'application/gzip',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'bmp' => 'image/bmp',
            'tiff' => 'image/tiff',
            'svg' => 'image/svg+xml',
            'ico' => 'image/x-icon',
            'mp3' => 'audio/mpeg',
            'wav' => 'audio/wav',
            'flac' => 'audio/flac',
            'aac' => 'audio/aac',
            'ogg' => 'audio/ogg',
            'wma' => 'audio/x-ms-wma',
            'mp4' => 'video/mp4',
            'avi' => 'video/x-msvideo',
            'mov' => 'video/quicktime',
            'wmv' => 'video/x-ms-wmv',
            'flv' => 'video/x-flv',
            'mkv' => 'video/x-matroska',
            'webm' => 'video/webm',
            'ogv' => 'video/ogg'
        ];
        $fileType = $mimeTypes[$ext] ?? 'application/octet-stream';
    }
    
    // Save to database
    $stmt = $conn->prepare("
        INSERT INTO materials (title, subject, content, file_path, file_type, created_by, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $result = $stmt->execute([
        htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
        $subject,
        htmlspecialchars($description, ENT_QUOTES, 'UTF-8'),
        $relativePath,
        $fileType,
        $_SESSION['user_id']
    ]);
    
    if ($result) {
        $materialId = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'فایل با موفقیت آپلود شد',
            'material_id' => $materialId,
            'title' => $title,
            'subject' => $subject,
            'file_path' => $relativePath,
            'file_type' => $fileType,
            'original_name' => $file['name']
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        // حذف فایل در صورت خطای دیتابیس
        if (file_exists($targetPath)) {
            unlink($targetPath);
        }
        echo json_encode(['success' => false, 'message' => 'خطا در ذخیره در پایگاه داده'], JSON_UNESCAPED_UNICODE);
    }
    
} catch(PDOException $e) {
    // حذف فایل در صورت خطای دیتابیس
    if (isset($targetPath) && file_exists($targetPath)) {
        unlink($targetPath);
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پایگاه داده: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    
} catch(Exception $e) {
    // حذف فایل در صورت هر خطای دیگر
    if (isset($targetPath) && file_exists($targetPath)) {
        unlink($targetPath);
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پردازش: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>