<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// Check if admin is logged in
if (!isAdmin()) {
    header('Location: index.php');
    exit();
}

$studentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$student = null;
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'first_name' => trim($_POST['first_name'] ?? ''),
        'last_name' => trim($_POST['last_name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'national_id' => trim($_POST['national_id'] ?? ''),
        'birth_date' => trim($_POST['birth_date'] ?? ''),
        'address' => trim($_POST['address'] ?? ''),
        'father_name' => trim($_POST['father_name'] ?? ''),
        'father_phone' => trim($_POST['father_phone'] ?? ''),
        'mother_name' => trim($_POST['mother_name'] ?? ''),
        'mother_phone' => trim($_POST['mother_phone'] ?? ''),
        'is_active' => isset($_POST['is_active']) ? 1 : 0
    ];
    
    // Validate required fields
    if (empty($data['first_name']) || empty($data['last_name']) || empty($data['national_id'])) {
        $error = 'فیلدهای نام، نام خانوادگی و کد ملی الزامی هستند.';
    } else {
        try {
            // Check if national ID is unique (excluding current student)
            $checkStmt = $conn->prepare("SELECT id FROM users WHERE national_id = ? AND id != ?");
            $checkStmt->execute([$data['national_id'], $studentId]);
            
            if ($checkStmt->fetch()) {
                $error = 'این کد ملی قبلاً ثبت شده است.';
            } else {
                // Update user data
                $updateStmt = $conn->prepare("
                    UPDATE users SET 
                        first_name = ?, last_name = ?, email = ?, national_id = ?, 
                        birth_date = ?, address = ?, father_name = ?, father_phone = ?, 
                        mother_name = ?, mother_phone = ?, is_active = ?
                    WHERE id = ? AND user_type = 'student'
                ");
                
                $result = $updateStmt->execute([
                    $data['first_name'], $data['last_name'], $data['email'], $data['national_id'],
                    $data['birth_date'], $data['address'], $data['father_name'], $data['father_phone'],
                    $data['mother_name'], $data['mother_phone'], $data['is_active'], $studentId
                ]);
                
                if ($result) {
                    $success = 'اطلاعات دانش‌آموز با موفقیت بروزرسانی شد.';
                    // Refresh student data
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND user_type = 'student'");
                    $stmt->execute([$studentId]);
                    $student = $stmt->fetch();
                } else {
                    $error = 'خطا در بروزرسانی اطلاعات.';
                }
            }
        } catch (PDOException $e) {
            $error = 'خطای پایگاه داده: ' . $e->getMessage();
        }
    }
}

// Get student data
if ($studentId > 0) {
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND user_type = 'student'");
        $stmt->execute([$studentId]);
        $student = $stmt->fetch();
        
        if (!$student) {
            $error = 'دانش‌آموز یافت نشد.';
        }
    } catch (PDOException $e) {
        $error = 'خطا در دریافت اطلاعات دانش‌آموز.';
    }
} else {
    $error = 'شناسه دانش‌آموز نامعتبر است.';
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش دانش‌آموز - ستاره ماه</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #002b5c, #004080);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .header h1 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }
        
        .form-container {
            padding: 2rem;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            transition: border-color 0.3s ease;
        }
        
        .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: #002b5c;
            box-shadow: 0 0 0 2px rgba(0, 43, 92, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: auto;
        }
        
        .btn-group {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }
        
        .btn {
            padding: 1rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            font-family: Tahoma, Arial, sans-serif;
        }
        
        .btn-primary {
            background: #28a745;
            color: white;
        }
        
        .btn-primary:hover {
            background: #218838;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 10px;
                border-radius: 10px;
            }
            
            .form-container {
                padding: 1rem;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .btn-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ویرایش اطلاعات دانش‌آموز</h1>
            <p>ستاره ماه - کلاس چهارم</p>
        </div>
        
        <div class="form-container">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($student): ?>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">نام *</label>
                            <input type="text" id="first_name" name="first_name" 
                                   value="<?php echo htmlspecialchars($student['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">نام خانوادگی *</label>
                            <input type="text" id="last_name" name="last_name" 
                                   value="<?php echo htmlspecialchars($student['last_name']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="national_id">کد ملی *</label>
                            <input type="text" id="national_id" name="national_id" 
                                   value="<?php echo htmlspecialchars($student['national_id']); ?>" 
                                   pattern="[0-9]{10}" maxlength="10" required>
                        </div>
                        <div class="form-group">
                            <label for="birth_date">تاریخ تولد</label>
                            <input type="date" id="birth_date" name="birth_date" 
                                   value="<?php echo htmlspecialchars($student['birth_date'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">ایمیل</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo htmlspecialchars($student['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="father_name">نام پدر</label>
                            <input type="text" id="father_name" name="father_name" 
                                   value="<?php echo htmlspecialchars($student['father_name'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="father_phone">تلفن پدر</label>
                            <input type="tel" id="father_phone" name="father_phone" 
                                   value="<?php echo htmlspecialchars($student['father_phone'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="mother_name">نام مادر</label>
                            <input type="text" id="mother_name" name="mother_name" 
                                   value="<?php echo htmlspecialchars($student['mother_name'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="mother_phone">تلفن مادر</label>
                            <input type="tel" id="mother_phone" name="mother_phone" 
                                   value="<?php echo htmlspecialchars($student['mother_phone'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">آدرس</label>
                        <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($student['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="is_active" name="is_active" 
                                   <?php echo $student['is_active'] ? 'checked' : ''; ?>>
                            <label for="is_active">کاربر فعال است</label>
                        </div>
                    </div>
                    
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary">💾 ذخیره تغییرات</button>
                        <a href="index.php?section=admin" class="btn btn-secondary">🔙 بازگشت</a>
                        <button type="button" class="btn btn-danger" onclick="resetPassword()">🔑 تغییر رمز عبور</button>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-error">
                    اطلاعات دانش‌آموز یافت نشد.
                </div>
                <div class="btn-group">
                    <a href="index.php?section=admin" class="btn btn-secondary">🔙 بازگشت</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function resetPassword() {
            if (confirm('آیا می‌خواهید رمز عبور این دانش‌آموز را به کد ملی او تغییر دهید؟')) {
                const studentId = <?php echo $studentId; ?>;
                
                fetch('ajax/reset-student-password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({ student_id: studentId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('رمز عبور با موفقیت به کد ملی دانش‌آموز تغییر کرد.');
                    } else {
                        alert(data.message || 'خطا در تغییر رمز عبور.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('خطای ارتباط با سرور.');
                });
            }
        }
    </script>
</body>
</html>