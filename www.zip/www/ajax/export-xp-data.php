<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

// بررسی دسترسی
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    die('<h2>دسترسی غیرمجاز</h2><p>فقط مدیران می‌توانند این صفحه را مشاهده کنند.</p>');
}

try {
    // دریافت داده‌ها از دیتابیس
    $stmt = $conn->prepare("
        SELECT 
            u.first_name,
            u.last_name,
            u.national_id,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.user_type = 'student'
        ORDER BY sx.total_xp DESC, u.first_name ASC
    ");
    
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($data)) {
        die('<h2>داده‌ای یافت نشد</h2><p>هیچ دانش‌آموزی در سیستم ثبت نشده است.</p>');
    }
    
    // تنظیم هدرها برای دانلود Excel
    $filename = 'student-xp-report-' . date('Y-m-d-H-i') . '.xls';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // شروع فایل Excel با UTF-8 BOM
    echo "\xEF\xBB\xBF";
    
    // شروع جدول HTML (Excel می‌تواند HTML table را بخواند)
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    
    // هدر جدول
    echo '<tr style="background-color: #4472C4; color: white; font-weight: bold; text-align: center;">';
    echo '<th>رنک</th>';
    echo '<th>نام</th>';
    echo '<th>نام خانوادگی</th>';
    echo '<th>کد ملی</th>';
    echo '<th>کل امتیاز XP</th>';
    echo '<th>ریاضی</th>';
    echo '<th>علوم</th>';
    echo '<th>فارسی</th>';
    echo '<th>اجتماعی</th>';
    echo '<th>دینی</th>';
    echo '<th>سطح</th>';
    echo '<th>آخرین بروزرسانی</th>';
    echo '</tr>';
    
    // داده‌ها
    foreach ($data as $index => $row) {
        $rank = $index + 1;
        $updatedDate = $row['updated_at'] ? 
            date('Y/m/d H:i', strtotime($row['updated_at'])) : 
            'هرگز';
        
        // رنگ‌بندی بر اساس رنک
        $rowColor = '';
        if ($rank == 1) $rowColor = 'background-color: #FFD700;'; // طلایی
        elseif ($rank == 2) $rowColor = 'background-color: #C0C0C0;'; // نقره‌ای
        elseif ($rank == 3) $rowColor = 'background-color: #CD7F32;'; // برنزی
        elseif ($rank <= 10) $rowColor = 'background-color: #E8F4FD;'; // آبی روشن
        
        echo '<tr style="' . $rowColor . '">';
        echo '<td style="text-align: center; font-weight: bold;">' . $rank . '</td>';
        echo '<td>' . htmlspecialchars($row['first_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['last_name']) . '</td>';
        echo '<td style="text-align: center;">' . htmlspecialchars($row['national_id']) . '</td>';
        echo '<td style="text-align: center; font-weight: bold;">' . number_format($row['total_xp']) . '</td>';
        echo '<td style="text-align: center;">' . number_format($row['math_xp']) . '</td>';
        echo '<td style="text-align: center;">' . number_format($row['science_xp']) . '</td>';
        echo '<td style="text-align: center;">' . number_format($row['persian_xp']) . '</td>';
        echo '<td style="text-align: center;">' . number_format($row['social_xp']) . '</td>';
        echo '<td style="text-align: center;">' . number_format($row['religion_xp']) . '</td>';
        echo '<td style="text-align: center; font-weight: bold;">' . $row['level'] . '</td>';
        echo '<td style="text-align: center;">' . $updatedDate . '</td>';
        echo '</tr>';
    }
    
    echo '</table>';
    
    // آمار کلی
    $totalXP = array_sum(array_column($data, 'total_xp'));
    $avgXP = count($data) > 0 ? $totalXP / count($data) : 0;
    $highestXP = count($data) > 0 ? max(array_column($data, 'total_xp')) : 0;
    $playersWithXP = count(array_filter($data, function($row) { return $row['total_xp'] > 0; }));
    
    // آمار موضوعات
    $mathTotal = array_sum(array_column($data, 'math_xp'));
    $scienceTotal = array_sum(array_column($data, 'science_xp'));
    $persianTotal = array_sum(array_column($data, 'persian_xp'));
    $socialTotal = array_sum(array_column($data, 'social_xp'));
    $religionTotal = array_sum(array_column($data, 'religion_xp'));
    
    echo '<br><br>';
    
    // جدول آمار کلی
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr style="background-color: #70AD47; color: white; font-weight: bold;"><th colspan="2">📊 آمار کلی سیستم</th></tr>';
    echo '<tr><td><b>📚 تعداد کل دانش‌آموزان</b></td><td style="text-align: center;">' . count($data) . ' نفر</td></tr>';
    echo '<tr><td><b>🎯 دانش‌آموزان با امتیاز</b></td><td style="text-align: center;">' . $playersWithXP . ' نفر</td></tr>';
    echo '<tr><td><b>🏆 کل امتیازات سیستم</b></td><td style="text-align: center;">' . number_format($totalXP) . ' XP</td></tr>';
    echo '<tr><td><b>📈 میانگین امتیاز</b></td><td style="text-align: center;">' . number_format($avgXP, 0) . ' XP</td></tr>';
    echo '<tr><td><b>🥇 بالاترین امتیاز</b></td><td style="text-align: center;">' . number_format($highestXP) . ' XP</td></tr>';
    echo '<tr><td><b>📅 تاریخ گزارش</b></td><td style="text-align: center;">' . date('Y/m/d H:i') . '</td></tr>';
    echo '</table>';
    
    echo '<br>';
    
    // جدول آمار موضوعات
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr style="background-color: #E67E22; color: white; font-weight: bold;"><th colspan="2">📋 آمار موضوعات</th></tr>';
    echo '<tr><td><b>🔢 ریاضی</b></td><td style="text-align: center;">' . number_format($mathTotal) . ' XP</td></tr>';
    echo '<tr><td><b>🔬 علوم</b></td><td style="text-align: center;">' . number_format($scienceTotal) . ' XP</td></tr>';
    echo '<tr><td><b>📖 فارسی</b></td><td style="text-align: center;">' . number_format($persianTotal) . ' XP</td></tr>';
    echo '<tr><td><b>🌍 اجتماعی</b></td><td style="text-align: center;">' . number_format($socialTotal) . ' XP</td></tr>';
    echo '<tr><td><b>📿 دینی</b></td><td style="text-align: center;">' . number_format($religionTotal) . ' XP</td></tr>';
    echo '</table>';
    
    echo '<br>';
    
    // جدول آمار سطوح
    $levelStats = [];
    for ($i = 1; $i <= 5; $i++) {
        $levelStats[$i] = count(array_filter($data, function($row) use ($i) { 
            return $row['level'] == $i; 
        }));
    }
    
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr style="background-color: #8E44AD; color: white; font-weight: bold;"><th colspan="2">⭐ توزیع سطوح</th></tr>';
    echo '<tr><td><b>سطح 1 (مبتدی)</b></td><td style="text-align: center;">' . $levelStats[1] . ' نفر</td></tr>';
    echo '<tr><td><b>سطح 2 (متوسط)</b></td><td style="text-align: center;">' . $levelStats[2] . ' نفر</td></tr>';
    echo '<tr><td><b>سطح 3 (پیشرفته)</b></td><td style="text-align: center;">' . $levelStats[3] . ' نفر</td></tr>';
    echo '<tr><td><b>سطح 4 (حرفه‌ای)</b></td><td style="text-align: center;">' . $levelStats[4] . ' نفر</td></tr>';
    echo '<tr><td><b>سطح 5 (استاد)</b></td><td style="text-align: center;">' . $levelStats[5] . ' نفر</td></tr>';
    echo '</table>';
    
    // اطلاعات تکمیلی
    echo '<br><p style="text-align: center; color: #666; font-size: 12px;">';
    echo 'گزارش تولید شده توسط سیستم مدیریت آموزشی ستاره‌ی ماه<br>';
    echo 'تاریخ تولید: ' . date('Y/m/d H:i:s') . '<br>';
    echo 'مدیر سیستم: ' . ($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '');
    echo '</p>';
    
} catch (Exception $e) {
    error_log("Error in export-xp-data.php: " . $e->getMessage());
    die('<h2>خطا در تولید گزارش</h2><p>خطا: ' . htmlspecialchars($e->getMessage()) . '</p>');
}
?>