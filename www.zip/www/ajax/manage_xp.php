<?php
// شروع بافر خروجی
ob_start();

// شروع session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

// بررسی دسترسی
if (!isset($_SESSION['user_id'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد سیستم شوید'], JSON_UNESCAPED_UNICODE);
    ob_end_flush();
    exit;
}

$user_type = $_SESSION['user_type'] ?? $_SESSION['role'] ?? '';
if ($user_type !== 'admin') {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false, 
        'message' => 'دسترسی غیرمجاز - فقط ادمین'
    ], JSON_UNESCAPED_UNICODE);
    ob_end_flush();
    exit;
}

header('Content-Type: application/json; charset=utf-8');

$admin_id = $_SESSION['user_id'];

try {
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (!$input && !empty($_POST)) {
        $input = $_POST;
    }
    
    if (!$input) {
        throw new Exception('داده‌ای دریافت نشد');
    }
    
    $action = $input['action'] ?? '';
    
    if (!function_exists('sanitize')) {
        function sanitize($str) {
            return htmlspecialchars(trim($str ?? ''), ENT_QUOTES, 'UTF-8');
        }
    }
    
    switch ($action) {
        
        case 'add_xp':
            $student_id = (int)($input['student_id'] ?? 0);
            $subject = sanitize($input['subject'] ?? '');
            $xp_amount = (int)($input['xp_amount'] ?? 0);
            $operation = sanitize($input['operation'] ?? 'add');
            $reason = sanitize($input['reason'] ?? 'تغییر دستی');
            
            if ($student_id <= 0 || $xp_amount <= 0) {
                throw new Exception('داده‌های ورودی نامعتبر');
            }
            
            // اطمینان از وجود رکورد - شامل exam_xp
            $stmt = $conn->prepare("SELECT id FROM student_xp WHERE student_id = ?");
            $stmt->execute([$student_id]);
            
            if (!$stmt->fetch()) {
                $stmt = $conn->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, exam_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
                $stmt->execute([$student_id]);
            }
            
            // محاسبه مقدار نهایی
            if ($operation === 'subtract') {
                $finalAmount = -$xp_amount;
            } elseif ($operation === 'set') {
                $finalAmount = $xp_amount;
            } else {
                $finalAmount = $xp_amount;
            }
            
            if ($subject === 'total') {
                if ($operation === 'set') {
                    // حذف تمام تاریخچه قبلی
                    $stmt = $conn->prepare("DELETE FROM xp_history WHERE student_id = ?");
                    $stmt->execute([$student_id]);
                    
                    // ریست کامل و تنظیم مقدار جدید در other_xp
                    $stmt = $conn->prepare("UPDATE student_xp SET 
                        math_xp = 0,
                        science_xp = 0,
                        persian_xp = 0,
                        social_xp = 0,
                        religion_xp = 0,
                        podcast_xp = 0,
                        dic_xp = 0,
                        exam_xp = 0,
                        other_xp = ?
                        WHERE student_id = ?");
                    $stmt->execute([$xp_amount, $student_id]);
                    
                    $finalAmount = $xp_amount;
                } else {
                    // اضافه یا کم کردن از other_xp
                    $stmt = $conn->prepare("UPDATE student_xp SET 
                        other_xp = other_xp + ?
                        WHERE student_id = ?");
                    $stmt->execute([$finalAmount, $student_id]);
                }
            } else {
                // موضوعات خاص - اضافه کردن exam به لیست
               $allowed = ['math', 'science', 'persian', 'social', 'religion', 'podcast', 'dic', 'exam', 'other'];
                if (!in_array($subject, $allowed)) {
                    throw new Exception('موضوع نامعتبر');
                }
                
                $field = $subject . '_xp';
                
                if ($operation === 'set') {
                    // حذف تاریخچه مربوط به این موضوع
                    $stmt = $conn->prepare("DELETE FROM xp_history WHERE student_id = ? AND subject = ?");
                    $stmt->execute([$student_id, $subject]);
                    
                    // تنظیم مقدار جدید
                    $stmt = $conn->prepare("UPDATE student_xp SET $field = ? WHERE student_id = ?");
                    $stmt->execute([$xp_amount, $student_id]);
                    
                    $finalAmount = $xp_amount;
                } else {
                    // اضافه یا کم کردن
                    $stmt = $conn->prepare("UPDATE student_xp SET $field = COALESCE($field, 0) + ? WHERE student_id = ?");
                    $stmt->execute([$finalAmount, $student_id]);
                }
            }
            
            // ثبت در تاریخچه
            $stmt = $conn->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$student_id, $subject, $finalAmount, $reason, $admin_id]);
            
            $opText = $operation === 'subtract' ? 'کم شد' : ($operation === 'set' ? 'تنظیم شد' : 'اضافه شد');
            $result = ['success' => true, 'message' => "امتیاز با موفقیت $opText"];
            break;
        
        case 'bulk_add_xp':
            $student_ids = $input['student_ids'] ?? [];
            $subject = sanitize($input['subject'] ?? '');
            $xp_amount = (int)($input['xp_amount'] ?? 0);
            $reason = sanitize($input['reason'] ?? 'افزودن گروهی');
            
            if (empty($student_ids) || $xp_amount <= 0) {
                throw new Exception('داده‌های نامعتبر');
            }
            
            $count = 0;
            foreach ($student_ids as $sid) {
                $sid = (int)$sid;
                if ($sid <= 0) continue;
                
                $stmt = $conn->prepare("SELECT id FROM student_xp WHERE student_id = ?");
                $stmt->execute([$sid]);
                if (!$stmt->fetch()) {
                    $stmt = $conn->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, exam_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
                    $stmt->execute([$sid]);
                }
                
                if ($subject === 'total') {
                    $stmt = $conn->prepare("UPDATE student_xp SET 
                        other_xp = other_xp + ?
                        WHERE student_id = ?");
                    $stmt->execute([$xp_amount, $sid]);
                } else {
                    $field = $subject . '_xp';
                    $stmt = $conn->prepare("UPDATE student_xp SET $field = COALESCE($field, 0) + ? WHERE student_id = ?");
                    $stmt->execute([$xp_amount, $sid]);
                }
                
                $stmt = $conn->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$sid, $subject, $xp_amount, $reason, $admin_id]);
                $count++;
            }
            
            $result = ['success' => true, 'message' => "امتیاز به $count نفر اضافه شد"];
            break;
        
        case 'adjust_level':
            $student_id = (int)($input['student_id'] ?? 0);
            $new_level = (int)($input['new_level'] ?? 1);
            $reason = sanitize($input['reason'] ?? 'تغییر سطح');
            
            if ($student_id <= 0 || $new_level < 1) {
                throw new Exception('داده‌های نامعتبر');
            }
            
            // محاسبه XP مورد نیاز برای سطح جدید
            $required_xp = match($new_level) {
                1 => 50,
                2 => 300,
                3 => 1000,
                4 => 2250,
                default => 3500,
            };
            
            // دریافت سطح و XP فعلی - شامل exam_xp
            $stmt = $conn->prepare("SELECT level, (math_xp + science_xp + persian_xp + social_xp + religion_xp + podcast_xp + dic_xp + exam_xp + other_xp) as current_total_xp FROM student_xp WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $current = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$current) {
                $stmt = $conn->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, exam_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, ?)");
                $stmt->execute([$student_id, $required_xp]);
                $old_level = 1;
                $xp_bonus = $required_xp;
            } else {
                $old_level = $current['level'];
                $current_xp = (int)$current['current_total_xp'];
                
                $xp_bonus = $required_xp - $current_xp;
                
                $stmt = $conn->prepare("UPDATE student_xp SET other_xp = other_xp + ? WHERE student_id = ?");
                $stmt->execute([$xp_bonus, $student_id]);
            }
            
            $history_reason = $reason . " (از سطح $old_level به $new_level) - تنظیم XP: " . ($xp_bonus >= 0 ? '+' : '') . $xp_bonus;
            
            $stmt = $conn->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) VALUES (?, 'level_change', ?, ?, ?, NOW())");
            $stmt->execute([$student_id, $xp_bonus, $history_reason, $admin_id]);
            
            $result = ['success' => true, 'message' => "سطح با موفقیت تغییر کرد (XP تنظیم شد: " . ($xp_bonus >= 0 ? '+' : '') . "$xp_bonus)"];
            break;
        
        case 'delete_history':
            $history_id = (int)($input['history_id'] ?? 0);
            if ($history_id <= 0) throw new Exception('شناسه نامعتبر');
            
            // دریافت اطلاعات تاریخچه قبل از حذف
            $stmt = $conn->prepare("SELECT student_id, subject, amount FROM xp_history WHERE id = ?");
            $stmt->execute([$history_id]);
            $history = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($history) {
                // حذف از تاریخچه
                $stmt = $conn->prepare("DELETE FROM xp_history WHERE id = ?");
                $stmt->execute([$history_id]);
                
                // کسر از student_xp
                $subject = $history['subject'];
                $amount = (int)$history['amount'];
                $student_id = (int)$history['student_id'];
                
                if ($subject === 'level_change') {
                    $stmt = $conn->prepare("UPDATE student_xp SET other_xp = other_xp - ? WHERE student_id = ?");
                    $stmt->execute([$amount, $student_id]);
                } elseif ($subject === 'total') {
                    $stmt = $conn->prepare("UPDATE student_xp SET other_xp = other_xp - ? WHERE student_id = ?");
                    $stmt->execute([$amount, $student_id]);
                } elseif ($subject !== 'reset_all' && $subject !== 'delete_all_history') {
                    // اطمینان از اینکه subject معتبر است
                   $allowed = ['math', 'science', 'persian', 'social', 'religion', 'podcast', 'dic', 'exam', 'other'];
                    if (in_array($subject, $allowed)) {
                        $field = $subject . '_xp';
                        $stmt = $conn->prepare("UPDATE student_xp SET $field = $field - ? WHERE student_id = ?");
                        $stmt->execute([$amount, $student_id]);
                    }
                }
            }
            
            $result = ['success' => true, 'message' => 'تاریخچه حذف و امتیاز کسر شد'];
            break;
            
        case 'delete_all_history':
            $student_id = (int)($input['student_id'] ?? 0);
            if ($student_id <= 0) throw new Exception('شناسه نامعتبر');
            
            // ابتدا تمام تاریخچه‌ها را حذف می‌کنیم
            $stmt = $conn->prepare("DELETE FROM xp_history WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $deleted = $stmt->rowCount();
            
            // یک رکورد در تاریخچه ثبت می‌کنیم که نشان دهد تاریخچه حذف شده
            $stmt = $conn->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) VALUES (?, 'delete_all_history', 0, 'حذف کامل تاریخچه توسط ادمین', ?, NOW())");
            $stmt->execute([$student_id, $admin_id]);
            
            $result = ['success' => true, 'message' => "تمام تاریخچه حذف شد ($deleted رکورد) - امتیازات دانش‌آموز تغییری نکرد"];
            break;
        
        case 'delete_student_completely':
            $student_id = (int)($input['student_id'] ?? 0);
            if ($student_id <= 0) throw new Exception('شناسه نامعتبر');
            
            $conn->beginTransaction();
            
            try {
                // حذف کامل تمام تاریخچه‌ها
                $stmt = $conn->prepare("DELETE FROM xp_history WHERE student_id = ?");
                $stmt->execute([$student_id]);
                $history_deleted = $stmt->rowCount();
                
                // حذف کامل رکورد امتیازات
                $stmt = $conn->prepare("DELETE FROM student_xp WHERE student_id = ?");
                $stmt->execute([$student_id]);
                $xp_deleted = $stmt->rowCount();
                
                $conn->commit();
                
                $result = ['success' => true, 'message' => "حذف کامل انجام شد: $history_deleted تاریخچه و $xp_deleted رکورد امتیاز حذف شد"];
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        case 'reset_student_xp':
        case 'reset_student_xp_complete':
            $student_id = (int)($input['student_id'] ?? 0);
            if ($student_id <= 0) throw new Exception('شناسه نامعتبر');
            
            // ریست کردن تمام امتیازات به صفر - شامل exam_xp
            $stmt = $conn->prepare("UPDATE student_xp SET 
                math_xp = 0, 
                science_xp = 0, 
                persian_xp = 0, 
                social_xp = 0, 
                religion_xp = 0, 
                podcast_xp = 0,
                dic_xp = 0,
                exam_xp = 0,
                other_xp = 0
                WHERE student_id = ?");
            $stmt->execute([$student_id]);
            
            if ($stmt->rowCount() === 0) {
                // اگر رکورد وجود نداشت، ایجاد می‌کنیم
                $stmt = $conn->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, exam_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
                $stmt->execute([$student_id]);
            }
            
            // ثبت عملیات در تاریخچه
            $stmt = $conn->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) VALUES (?, 'reset_all', 0, 'ریست کامل امتیازات توسط ادمین', ?, NOW())");
            $stmt->execute([$student_id, $admin_id]);
            
            $result = ['success' => true, 'message' => 'تمام امتیازات با موفقیت ریست شد (سطح به 1 بازگشت)'];
            break;
        
        case 'reset_student_xp_with_history':
            $student_id = (int)($input['student_id'] ?? 0);
            if ($student_id <= 0) throw new Exception('شناسه نامعتبر');
            
            $conn->beginTransaction();
            
            try {
                // حذف کامل تاریخچه
                $stmt = $conn->prepare("DELETE FROM xp_history WHERE student_id = ?");
                $stmt->execute([$student_id]);
                $deleted = $stmt->rowCount();
                
                // ریست کردن تمام امتیازات - شامل exam_xp
                $stmt = $conn->prepare("UPDATE student_xp SET 
                    math_xp = 0, 
                    science_xp = 0, 
                    persian_xp = 0, 
                    social_xp = 0, 
                    religion_xp = 0, 
                    podcast_xp = 0,
                    dic_xp = 0,
                    exam_xp = 0,
                    other_xp = 0
                    WHERE student_id = ?");
                $stmt->execute([$student_id]);
                
                if ($stmt->rowCount() === 0) {
                    // اگر رکورد وجود نداشت، ایجاد می‌کنیم
                    $stmt = $conn->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, exam_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0)");
                    $stmt->execute([$student_id]);
                }
                
                $conn->commit();
                
                $result = ['success' => true, 'message' => "ریست کامل انجام شد: $deleted رکورد تاریخچه حذف و تمام امتیازات صفر شد (سطح به 1 بازگشت)"];
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
        
        default:
            throw new Exception('عملیات نامعتبر: ' . $action);
    }
    
    ob_clean();
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

ob_end_flush();
?>