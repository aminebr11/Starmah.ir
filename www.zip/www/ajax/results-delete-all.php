<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

try{
  $stmt = $conn->prepare("TRUNCATE TABLE game_results");
  $stmt->execute();
  echo json_encode(['success'=>true]);
}catch(Throwable $e){
  // اگر TRUNCATE محدودیت دارد، از DELETE استفاده کن
  try{
    $stmt = $conn->prepare("DELETE FROM game_results");
    $stmt->execute();
    echo json_encode(['success'=>true,'deleted'=>$stmt->rowCount()]);
  } catch(Throwable $e2) {
    echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e2->getMessage()]);
  }
}
