<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if admin is logged in
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

$studentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($studentId <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است.']);
    exit();
}

try {
    $stmt = $conn->prepare("
        SELECT u.*, s.total_score, s.weekly_stars, s.class_rank 
        FROM users u 
        LEFT JOIN students s ON u.id = s.user_id 
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    $stmt->execute([$studentId]);
    
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد.']);
        exit();
    }
    
    echo json_encode([
        'success' => true, 
        'student' => [
            'id' => $student['id'],
            'username' => $student['username'],
            'first_name' => $student['first_name'],
            'last_name' => $student['last_name'],
            'email' => $student['email'] ?? '',
            'national_id' => $student['national_id'],
            'birth_date' => $student['birth_date'] ?? '',
            'address' => $student['address'] ?? '',
            'father_name' => $student['father_name'] ?? '',
            'father_phone' => $student['father_phone'] ?? '',
            'mother_name' => $student['mother_name'] ?? '',
            'mother_phone' => $student['mother_phone'] ?? '',
            'is_active' => (bool)$student['is_active'],
            'total_score' => $student['total_score'] ?? 0,
            'weekly_stars' => $student['weekly_stars'] ?? 0,
            'class_rank' => $student['class_rank'] ?? 0
        ]
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطای پایگاه داده.']);
}
?>