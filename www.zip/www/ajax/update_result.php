<?php
// File: ../ajax/update_result.php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// 1. بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// 2. بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر است']);
    exit();
}

try {
    // 3. دریافت داده‌ها
    $result_id = isset($_POST['result_id']) ? intval($_POST['result_id']) : 0;
    $score = isset($_POST['score']) ? intval($_POST['score']) : 0;
    $accuracy = isset($_POST['accuracy']) ? floatval($_POST['accuracy']) : 0;
    $time_spent = isset($_POST['time_spent']) ? intval($_POST['time_spent']) : 0;
    $attempts = isset($_POST['attempts']) ? intval($_POST['attempts']) : 1;
    
    // دریافت تاریخ (اختیاری - اگر در فرم وجود دارد)
    $completed_at = isset($_POST['completed_at']) ? $_POST['completed_at'] : null;

    if ($result_id <= 0) {
        throw new Exception('شناسه نامعتبر است');
    }

    // 4. آماده‌سازی کوئری آپدیت
    $sql = "UPDATE game_results SET 
            score = :score, 
            accuracy = :accuracy, 
            time_spent = :time_spent, 
            attempts = :attempts";
    
    // اگر تاریخ ارسال شده بود، آن را هم آپدیت کن
    if ($completed_at) {
        // تبدیل فرمت T به فاصله (برای datetime در MySQL)
        $completed_at = str_replace('T', ' ', $completed_at);
        $sql .= ", completed_at = :completed_at";
    }

    $sql .= " WHERE id = :id";

    $stmt = $conn->prepare($sql);
    
    // بایند کردن پارامترها
    $stmt->bindParam(':score', $score, PDO::PARAM_INT);
    $stmt->bindParam(':accuracy', $accuracy); // برای اعشاری پیش‌فرض string مناسب است یا PARAM_STR
    $stmt->bindParam(':time_spent', $time_spent, PDO::PARAM_INT);
    $stmt->bindParam(':attempts', $attempts, PDO::PARAM_INT);
    $stmt->bindParam(':id', $result_id, PDO::PARAM_INT);
    
    if ($completed_at) {
        $stmt->bindParam(':completed_at', $completed_at);
    }

    // 5. اجرای کوئری
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'تغییرات با موفقیت ذخیره شد']);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در ذخیره سازی در دیتابیس']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطای سرور: ' . $e->getMessage()]);
}
?>