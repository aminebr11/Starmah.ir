<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$gameId = intval($input['game_id'] ?? 0);
$newStatus = intval($input['status'] ?? 0);

if (!$gameId) {
    echo json_encode(['success' => false, 'message' => 'ID بازی نامعتبر']);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE games SET is_active = ? WHERE id = ?");
    $result = $stmt->execute([$newStatus, $gameId]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'وضعیت بازی تغییر کرد']);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در تغییر وضعیت']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا: ' . $e->getMessage()]);
}
?>