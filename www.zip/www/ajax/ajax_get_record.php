<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$db = $conn;

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'شناسه رکورد الزامی است']);
    exit;
}

$result_id = (int)$_GET['id'];

try {
    $stmt = $db->prepare("
        SELECT 
            ar.id AS result_id,
            ar.activity_id,
            ar.student_id,
            ar.score,
            ar.status,
            ar.feedback,
            a.date,
            a.lesson,
            a.topic,
            a.title AS activity_title,
            a.score_type,
            u.first_name,
            u.last_name
        FROM activity_results ar
        JOIN activities a ON ar.activity_id = a.id
        JOIN users u ON ar.student_id = u.id
        WHERE ar.id = ?
    ");
    
    $stmt->execute([$result_id]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$record) {
        echo json_encode(['success' => false, 'message' => 'رکورد یافت نشد']);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'record' => $record
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت اطلاعات: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>