<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

function norm($s){ return trim($s ?? ''); }

$id        = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$name      = norm($_POST['name'] ?? '');
$icon      = norm($_POST['icon'] ?? '');
$color     = norm($_POST['color'] ?? '#4d9de0');
$is_active = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;

if ($name === '') { echo json_encode(['success'=>false,'message'=>'نام اجباری است']); exit; }
if ($color === '') $color = '#4d9de0';

try {
    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE game_categories SET name=?, icon=?, color=?, is_active=? WHERE id=?");
        $ok = $stmt->execute([$name, $icon ?: null, $color, $is_active, $id]);
    } else {
        $stmt = $conn->prepare("INSERT INTO game_categories (name, icon, color, is_active) VALUES (?,?,?,?)");
        $ok = $stmt->execute([$name, $icon ?: null, $color, $is_active]);
        $id = $ok ? (int)$conn->lastInsertId() : 0;
    }
    echo json_encode(['success'=>true,'id'=>$id]);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>'خطای پایگاه‌داده','error'=>$e->getMessage()]);
}
