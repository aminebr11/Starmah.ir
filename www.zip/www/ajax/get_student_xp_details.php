<?php
// فایل جدید: ajax/get_student_xp_details.php
require_once '../config.php';
require_once '../functions.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');

try {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    if (!isAdmin()) {
        echo json_encode([
            'success' => false, 
            'message' => 'دسترسی غیرمجاز'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (!$input) {
        $input = $_POST;
    }
    
    $student_id = (int)($input['student_id'] ?? 0);
    
    if ($student_id <= 0) {
        throw new Exception('شناسه دانش‌آموز نامعتبر');
    }
    
    // دریافت اطلاعات دانش‌آموز
    $stmt = $conn->prepare("
        SELECT 
            u.id, 
            CONCAT(u.first_name, ' ', u.last_name) as name,
            u.email,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.podcast_xp, 0) as podcast_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.id = ? AND u.user_type = 'student' AND u.is_active = 1
    ");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        throw new Exception('دانش‌آموز یافت نشد');
    }
    
    // دریافت تاریخچه
    $stmt = $conn->prepare("
        SELECT 
            xh.*,
            CASE 
                WHEN xh.admin_id IS NOT NULL THEN (
                    SELECT CONCAT(first_name, ' ', last_name) 
                    FROM users 
                    WHERE id = xh.admin_id
                )
                ELSE 'سیستم'
            END as admin_name
        FROM xp_history xh
        WHERE xh.student_id = ?
        ORDER BY xh.created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$student_id]);
    $xp_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'student' => $student,
        'xp_history' => $xp_history
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("GET_STUDENT_XP_DETAILS ERROR: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>