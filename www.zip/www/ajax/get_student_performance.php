<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if (!isset($_GET['student_id']) || !is_numeric($_GET['student_id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است.']);
        exit;
    }

    $studentId = (int)$_GET['student_id'];

    // عملکرد 12 هفته اخیر دانش‌آموز را می‌گیریم
    $sql = "
        SELECT year, month, week_number, total_xp
        FROM weekly_xp_summary
        WHERE student_id = :studentId
        ORDER BY year DESC, month DESC, week_number DESC
        LIMIT 12
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([':studentId' => $studentId]);
    $performance = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // چون داده‌ها به ترتیب نزول هستند، برای نمودار باید معکوش کنیم
    echo json_encode(['success' => true, 'data' => array_reverse($performance)]);

} catch (PDOException $e) {
    error_log("PDO Error in get_student_performance: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به پایگاه داده.']);
}
?>