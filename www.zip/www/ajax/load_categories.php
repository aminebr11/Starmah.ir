<?php
// فایل: ajax/load_categories.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت لیست دسته‌بندی‌ها با تعداد بازی‌های هر دسته
    $stmt = $conn->prepare("
        SELECT 
            gc.*,
            COUNT(g.id) as games_count
        FROM game_categories gc
        LEFT JOIN games g ON gc.id = g.category_id
        GROUP BY gc.id
        ORDER BY gc.created_at DESC
    ");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // محاسبه آمار کلی
    $totalCategories = count($categories);
    $activeCategories = 0;
    $inactiveCategories = 0;
    $totalGames = 0;
    
    foreach ($categories as $category) {
        if ($category['is_active']) {
            $activeCategories++;
        } else {
            $inactiveCategories++;
        }
        $totalGames += (int)$category['games_count'];
    }
    
    $stats = [
        'total' => $totalCategories,
        'active' => $activeCategories,
        'inactive' => $inactiveCategories,
        'total_games' => $totalGames
    ];
    
    echo json_encode([
        'success' => true,
        'categories' => $categories,
        'stats' => $stats
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری دسته‌بندی‌ها: ' . $e->getMessage()
    ]);
}
?>