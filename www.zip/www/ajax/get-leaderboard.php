<?php
// ajax/get-leaderboard.php - دریافت جدول امتیازات
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

try {
    $period = $_GET['period'] ?? 'all'; // all, weekly, monthly
    
    $date_condition = '';
    if ($period === 'weekly') {
        $date_condition = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
    } elseif ($period === 'monthly') {
        $date_condition = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
    }
    
    $stmt = $conn->prepare("
        SELECT u.first_name, sx.total_xp, sx.level,
               ROW_NUMBER() OVER (ORDER BY sx.total_xp DESC) as rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student'
        ORDER BY sx.total_xp DESC
        LIMIT 20
    ");
    $stmt->execute();
    $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'leaderboard' => $leaderboard]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت جدول امتیازات']);
}
?>

