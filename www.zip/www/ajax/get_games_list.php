<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت ID بازی
    $game_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if (!$game_id) {
        throw new Exception('شناسه بازی نامعتبر است');
    }
    
    // کوئری برای دریافت اطلاعات بازی
    $sql = "
        SELECT g.*, 
               gc.name as category_name,
               gc.icon as category_icon
        FROM games g
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE g.id = ?
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([$game_id]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        throw new Exception('بازی مورد نظر یافت نشد');
    }
    
    // پردازش اطلاعات بازی
    $processed_game = [
        'id' => intval($game['id']),
        'title' => $game['title'],
        'subject' => $game['subject'],
        'category_id' => $game['category_id'],
        'category_name' => $game['category_name'] ?: $game['subject'],
        'category_icon' => $game['category_icon'] ?: '📚',
        'difficulty' => $game['difficulty'] ?? 'medium',
        'estimated_time' => intval($game['estimated_time']),
        'topic' => $game['topic'],
        'description' => $game['description'],
        'instructions' => $game['instructions'],
        'game_code' => $game['game_code'],
        'is_active' => intval($game['is_active']),
        'created_at' => $game['created_at'],
        'updated_at' => $game['updated_at'] ?? null
    ];
    
    echo json_encode([
        'success' => true,
        'game' => $processed_game,
        'message' => 'اطلاعات بازی با موفقیت دریافت شد'
    ]);
    
} catch (PDOException $e) {
    error_log("Database Error in get-game: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in get-game: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ]);
}
?>