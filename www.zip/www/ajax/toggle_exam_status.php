<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'عدم دسترسی']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$exam_id = isset($data['exam_id']) ? (int)$data['exam_id'] : 0;
$new_status = isset($data['status']) ? (int)$data['status'] : 0;

if (!$exam_id) {
    echo json_encode(['success' => false, 'message' => 'شناسه آزمون نامعتبر است']);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE quizzes SET is_active = ? WHERE id = ?");
    $stmt->bind_param('ii', $new_status, $exam_id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => $new_status ? 'آزمون فعال شد' : 'آزمون غیرفعال شد'
        ]);
    } else {
        throw new Exception('خطا در بروزرسانی');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در تغییر وضعیت آزمون'
    ]);
}
?>