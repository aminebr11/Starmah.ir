<?php
/**
 * فایل: ajax/get_game_result.php
 * وظیفه: دریافت نتایج و آمار یک بازی خاص برای نمایش در مودال ادمین.
 */

session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$game_id = (int)($_GET['game_id'] ?? 0);

if ($game_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر است']);
    exit;
}

try {
    // بخش ۱: دریافت لیست نتایج دانش‌آموزان
       // بخش ۱: دریافت لیست نتایج دانش‌آموزان
    $resultsQuery = "
        SELECT 
            gr.id, /* **ستون جدید که نیاز بود** */
            COALESCE(
                NULLIF(TRIM(CONCAT(u.first_name, ' ', u.last_name)), ''), 
                u.username, 
                CONCAT('کاربر ', gr.student_id)
            ) as student_name,
            gr.score, 
            gr.accuracy, 
            gr.time_spent, 
            gr.completed_at
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        WHERE gr.game_id = :game_id
        ORDER BY gr.score DESC, gr.time_spent ASC
    ";
    
    // ... ادامه کد ...
    
    $stmt_results = $conn->prepare($resultsQuery);
    $stmt_results->execute([':game_id' => $game_id]);
    // مهم: مطمئن شوید که ستون‌ها دقیقاً با نام‌های زیر واکشی می‌شوند
    $results = $stmt_results->fetchAll(PDO::FETCH_ASSOC);

    // بخش ۲: محاسبه آمار کلی برای بازی
    $statsQuery = "
        SELECT 
            COUNT(id) as total_plays,
            ROUND(AVG(score), 1) as avg_score,
            ROUND(AVG(time_spent), 0) as avg_time,
            ROUND(AVG(accuracy), 1) as avg_accuracy
        FROM game_results
        WHERE game_id = :game_id
    ";
    $stmt_stats = $conn->prepare($statsQuery);
    $stmt_stats->execute([':game_id' => $game_id]);
    $stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
    
    $stats_formatted = [
        'total_plays' => (int)($stats['total_plays'] ?? 0),
        'avg_score' => (float)($stats['avg_score'] ?? 0),
        'avg_time' => (int)($stats['avg_time'] ?? 0),
        'avg_accuracy' => (float)($stats['avg_accuracy'] ?? 0)
    ];

    // بخش ۳: ارسال خروجی نهایی
    echo json_encode([
        'success' => true, 
        'results' => $results,
        'stats' => $stats_formatted
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    error_log("Database Error in get_game_result.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای داخلی سرور رخ داده است.']);
}
?>