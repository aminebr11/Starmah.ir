<?php
// فایل ajax/get_exam_details.php - نسخه Debug و اصلاح‌شده

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// جلوگیری از نمایش خطاها در خروجی JSON
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Log شروع درخواست
error_log("=== GET_EXAM_DETAILS DEBUG START ===");
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);
error_log("Content type: " . ($_SERVER['CONTENT_TYPE'] ?? 'not set'));

// بررسی method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// شروع session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_log("Session started");
error_log("Session data: " . json_encode($_SESSION));

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'کاربر وارد نشده - session خالی'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!isset($_SESSION['user_type'])) {
    echo json_encode(['success' => false, 'message' => 'نوع کاربر تعریف نشده'], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SESSION['user_type'] !== 'student') {
    echo json_encode(['success' => false, 'message' => 'فقط دانش‌آموزان مجاز هستند - نوع کاربر: ' . $_SESSION['user_type']], JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = $_SESSION['user_id'];

// بارگذاری config
$configPaths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$configLoaded = false;
foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $configLoaded = true;
        break;
    }
}
if (!$configLoaded || !isset($conn)) {
    echo json_encode(['success' => false, 'message' => 'اتصال به دیتابیس برقرار نشد یا فایل تنظیمات یافت نشد'], JSON_UNESCAPED_UNICODE);
    exit;
}

// خواندن داده ورودی
$rawInput = file_get_contents('php://input');
if (empty($rawInput)) {
    echo json_encode(['success' => false, 'message' => 'هیچ داده‌ای دریافت نشد'], JSON_UNESCAPED_UNICODE);
    exit;
}
$input = json_decode($rawInput, true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر - JSON خراب'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!isset($input['exam_id'])) {
    echo json_encode(['success' => false, 'message' => 'شناسه آزمون ارسال نشده'], JSON_UNESCAPED_UNICODE);
    exit;
}

$examId = (int)$input['exam_id'];

try {
    // تست اتصال دیتابیس
    $testQuery = $conn->query("SELECT 1");
    if (!$testQuery) {
        throw new Exception("Database connection test failed");
    }

    // دریافت اطلاعات آزمون
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ?");
    $stmt->execute([$examId]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$exam) {
        echo json_encode(['success' => false, 'message' => "آزمون با شناسه $examId یافت نشد"], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // دریافت تلاش کاربر
    $stmt = $conn->prepare("SELECT * FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?");
    $stmt->execute([$examId, $userId]);
    $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$attempt) {
        echo json_encode(['success' => false, 'message' => 'شما در این آزمون شرکت نکرده‌اید'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // دریافت سوالات آزمون
    $stmt = $conn->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? AND is_active = 1 ORDER BY id");
    $stmt->execute([$examId]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($questions)) {
        echo json_encode(['success' => false, 'message' => 'سوالی برای این آزمون یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // پارس پاسخ‌های کاربر
    $userAnswers = [];
    if (!empty($attempt['answers'])) {
        $userAnswers = json_decode($attempt['answers'], true) ?? [];
    }

    // آماده‌سازی جزئیات سوالات
    $questionDetails = [];
    foreach ($questions as $question) {
        $questionId = (string)$question['id'];
        $detail = [
            'id' => $question['id'],
            'question_text' => $question['question_text'],
            'question_type' => $question['question_type'],
            'points' => (int)$question['points'],
            'user_answer' => '',
            'correct_answer' => '',
            'is_correct' => false,
            'options' => [],
            'points_earned' => 0
        ];

        // پاسخ کاربر
        if (isset($userAnswers[$questionId])) {
            $detail['user_answer'] = $userAnswers[$questionId]['student_answer'] ?? '';
            $detail['is_correct'] = $userAnswers[$questionId]['is_correct'] ?? false;
            $detail['points_earned'] = $userAnswers[$questionId]['points_earned'] ?? 0;
        }

        // پردازش question_data
        if (!empty($question['question_data'])) {
            $questionData = json_decode($question['question_data'], true);
        } else {
            $questionData = [];
        }

        if ($question['question_type'] === 'mcq' && isset($questionData['options'])) {
            foreach ($questionData['options'] as $option) {
                if (is_array($option) && isset($option['text'])) {
                    $detail['options'][] = $option['text'];
                    if (!empty($option['correct'])) {
                        $detail['correct_answer'] = $option['text'];
                    }
                }
            }
        } elseif ($question['question_type'] === 'tf') {
            $detail['correct_answer'] = $questionData['correct_answer'] ?? '';
            $detail['options'] = ['true' => 'درست', 'false' => 'نادرست'];
        } elseif ($question['question_type'] === 'short') {
            $detail['correct_answer'] = $questionData['correct_answer'] ?? '';
        }

        $questionDetails[] = $detail;
    }

    // محاسبه آمار کلی
    $totalQuestions = count($questions);
    $correctAnswers = 0;
    $totalPointsEarned = 0;
    foreach ($questionDetails as $detail) {
        if ($detail['is_correct']) {
            $correctAnswers++;
        }
        $totalPointsEarned += $detail['points_earned'];
    }
    $accuracy = $totalQuestions > 0 ? round(($correctAnswers / $totalQuestions) * 100, 1) : 0;
    $percentage = $attempt['total_score'] > 0 ? round(($attempt['score'] / $attempt['total_score']) * 100, 1) : 0;

    // پاسخ نهایی
    $response = [
        'success' => true,
        'exam' => [
            'id' => $exam['id'],
            'title' => $exam['title'],
            'description' => $exam['description'] ?? '',
            'duration_minutes' => (int)$exam['duration_minutes']
        ],
        'attempt' => [
            'score' => (int)$attempt['score'],
            'total_score' => (int)$attempt['total_score'],
            'percentage' => $percentage,
            'time_taken' => (int)$attempt['time_taken'],
            'submitted_at' => $attempt['submitted_at']
        ],
        'statistics' => [
            'total_questions' => $totalQuestions,
            'correct_answers' => $correctAnswers,
            'wrong_answers' => $totalQuestions - $correctAnswers,
            'accuracy' => $accuracy,
            'total_points_earned' => $totalPointsEarned
        ],
        'questions' => $questionDetails
    ];

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    error_log("=== DATABASE ERROR ===");
    error_log("PDO Error: " . $e->getMessage());
    error_log("Error Code: " . $e->getCode());

    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    error_log("=== GENERAL ERROR ===");
    error_log("Error: " . $e->getMessage());
    error_log("File: " . $e->getFile());
    error_log("Line: " . $e->getLine());

    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>