<?php
session_start();
require_once 'config.php';

header('Content-Type: application/json');

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_profile') {
    
    $userId = $_SESSION['user_id'];
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $birthDate = trim($_POST['birth_date'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $fatherName = trim($_POST['father_name'] ?? '');
    $fatherPhone = trim($_POST['father_phone'] ?? '');
    $motherName = trim($_POST['mother_name'] ?? '');
    $motherPhone = trim($_POST['mother_phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    $currentPassword = trim($_POST['current_password'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');
    $confirmPassword = trim($_POST['confirm_password'] ?? '');
    
    // اعتبارسنجی داده‌ها
    if (empty($firstName) || empty($lastName)) {
        echo json_encode(['success' => false, 'message' => 'نام و نام خانوادگی الزامی است']);
        exit;
    }
    
    try {
        // شروع تراکنش
        $conn->beginTransaction();
        
        // بروزرسانی اطلاعات پایه
        $updateQuery = "UPDATE users SET 
                        first_name = :first_name,
                        last_name = :last_name,
                        birth_date = :birth_date,
                        address = :address,
                        father_name = :father_name,
                        father_phone = :father_phone,
                        mother_name = :mother_name,
                        mother_phone = :mother_phone,
                        email = :email";
        
        $params = [
            ':first_name' => $firstName,
            ':last_name' => $lastName,
            ':birth_date' => $birthDate ?: null,
            ':address' => $address,
            ':father_name' => $fatherName,
            ':father_phone' => $fatherPhone,
            ':mother_name' => $motherName,
            ':mother_phone' => $motherPhone,
            ':email' => $email ?: null,
            ':user_id' => $userId
        ];
        
        // بررسی تغییر رمز عبور
        if (!empty($currentPassword) && !empty($newPassword)) {
            // بررسی تطابق رمز جدید و تأیید آن
            if ($newPassword !== $confirmPassword) {
                $conn->rollBack();
                echo json_encode(['success' => false, 'message' => 'رمز عبور جدید و تأیید آن یکسان نیستند']);
                exit;
            }
            
            // بررسی طول رمز عبور
            if (strlen($newPassword) < 8) {
                $conn->rollBack();
                echo json_encode(['success' => false, 'message' => 'رمز عبور باید حداقل ۸ کاراکتر باشد']);
                exit;
            }
            
            // بررسی رمز عبور فعلی
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($currentPassword, $user['password'])) {
                $conn->rollBack();
                echo json_encode(['success' => false, 'message' => 'رمز عبور فعلی اشتباه است']);
                exit;
            }
            
            // اضافه کردن رمز عبور جدید به query
            $updateQuery .= ", password = :password";
            $params[':password'] = password_hash($newPassword, PASSWORD_DEFAULT);
        }
        
        $updateQuery .= " WHERE id = :user_id";
        
        // اجرای query
        $stmt = $conn->prepare($updateQuery);
        $stmt->execute($params);
        
        // بروزرسانی نام در session
        $_SESSION['user_name'] = $firstName . ' ' . $lastName;
        
        // تایید تراکنش
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => '✅ اطلاعات شما با موفقیت بروزرسانی شد!'
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Edit profile error: " . $e->getMessage());
        echo json_encode([
            'success' => false, 
            'message' => 'خطا در بروزرسانی اطلاعات: ' . $e->getMessage()
        ]);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر']);
}
?>