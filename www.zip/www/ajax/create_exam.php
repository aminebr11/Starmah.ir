<?php
// ajax/create_exam.php - اصلاح شده
require_once '../config.php';
require_once '../functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode([
        'success' => false, 
        'message' => 'دسترسی غیرمجاز'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Set proper headers
header('Content-Type: application/json; charset=utf-8');

try {
    // Get raw input
    $raw_input = file_get_contents('php://input');
    error_log("Create exam raw input: " . $raw_input);
    
    if (empty($raw_input)) {
        throw new Exception('داده‌های ورودی خالی است');
    }
    
    // Decode JSON
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('فرمت JSON نامعتبر: ' . json_last_error_msg());
    }
    
    if (!$input) {
        throw new Exception('داده‌های ورودی نامعتبر');
    }
    
    error_log("Create exam input data: " . print_r($input, true));
    
    // Extract and validate data
    $title = trim($input['title'] ?? '');
    $exam_date = trim($input['exam_date'] ?? '');
    $exam_time = trim($input['exam_time'] ?? '');
    $duration_minutes = (int)($input['duration_minutes'] ?? 30);
    $shuffle_questions = (bool)($input['shuffle_questions'] ?? false);
    $negative_marking = (bool)($input['negative_marking'] ?? false);
    $is_visible = (bool)($input['is_visible'] ?? true);
    
    // Validation
    if (empty($title)) {
        throw new Exception('عنوان آزمون الزامی است');
    }
    
    if (strlen($title) < 3) {
        throw new Exception('عنوان آزمون باید حداقل ۳ کاراکتر باشد');
    }
    
    if ($duration_minutes < 5 || $duration_minutes > 180) {
        throw new Exception('مدت آزمون باید بین ۵ تا ۱۸۰ دقیقه باشد');
    }
    
    // Validate date format if provided
    if (!empty($exam_date) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exam_date)) {
        throw new Exception('فرمت تاریخ نامعتبر است (YYYY-MM-DD)');
    }
    
    // Validate time format if provided
    if (!empty($exam_time) && !preg_match('/^\d{2}:\d{2}$/', $exam_time)) {
        throw new Exception('فرمت زمان نامعتبر است (HH:MM)');
    }
    
    // Start transaction
    $conn->beginTransaction();
    
    try {
        // Insert into quizzes table
        $stmt = $conn->prepare("
            INSERT INTO quizzes (
                title, 
                exam_date, 
                exam_time, 
                duration_minutes, 
                shuffle_questions, 
                negative_marking, 
                is_visible, 
                is_active,
                questions_count,
                total_points,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0, NOW())
        ");
        
        $result = $stmt->execute([
            $title,
            empty($exam_date) ? null : $exam_date,
            empty($exam_time) ? null : $exam_time,
            $duration_minutes,
            $shuffle_questions ? 1 : 0,
            $negative_marking ? 1 : 0,
            $is_visible ? 1 : 0
        ]);
        
        if (!$result) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception('خطا در ایجاد آزمون: ' . ($errorInfo[2] ?? 'نامشخص'));
        }
        
        $exam_id = $conn->lastInsertId();
        
        if (!$exam_id) {
            throw new Exception('خطا در دریافت شناسه آزمون');
        }
        
        // Commit transaction
        $conn->commit();
        
        error_log("Exam created successfully with ID: $exam_id");
        
        // Return success response
        $response = [
            'success' => true,
            'message' => 'آزمون با موفقیت ایجاد شد',
            'exam_id' => (int)$exam_id,
            'title' => $title,
            'exam_date' => $exam_date,
            'exam_time' => $exam_time,
            'duration_minutes' => $duration_minutes
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Create Exam Error: " . $e->getMessage());
    
    $response = [
        'success' => false,
        'message' => $e->getMessage()
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log("Create Exam PDO Error: " . $e->getMessage());
    
    $response = [
        'success' => false,
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}
?>