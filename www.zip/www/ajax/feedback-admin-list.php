<?php
// ajax/feedback-admin-list.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!isAdmin()) {
  echo json_encode(['success'=>false,'message'=>'Forbidden']); exit;
}

try {
  $sql = "
    SELECT
      f.id, f.student_id, f.parent_name, f.parent_phone,
      f.subject, f.subject_text, f.message,
      f.status, f.created_at, f.updated_at,
      u.first_name, u.last_name
    FROM feedbacks f
    JOIN users u ON u.id = f.student_id
    ORDER BY f.created_at DESC
  ";
  $stmt = $conn->query($sql);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // خروجی هم‌خوان با فرانت‌اند شما
  $items = array_map(function($r){
    return [
      'id'            => (int)$r['id'],
      'student_id'    => (int)$r['student_id'],
      'student_name'  => trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '')),
      'parent_name'   => $r['parent_name'],
      'parent_phone'  => $r['parent_phone'],
      'subject'       => $r['subject'],
      'subject_text'  => $r['subject_text'],
      'message'       => $r['message'],
      'status'        => strtolower($r['status'] ?? 'pending'), // ⬅️ کلید اصلی شمارش
      'created_at'    => $r['created_at'],
      'updated_at'    => $r['updated_at'],
    ];
  }, $rows);

  echo json_encode(['success'=>true, 'items'=>$items]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false, 'message'=>'DB Error', 'error'=>$e->getMessage()]);
}
