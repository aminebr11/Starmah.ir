<?php
session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر']);
    exit();
}

try {
    // بررسی وجود پارامتر id
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر']);
        exit();
    }
    
    $gameId = (int)$_GET['id'];
    
    // دریافت اطلاعات بازی
    $stmt = $conn->prepare("
        SELECT 
            g.*,
            gc.name as category_name,
            COUNT(gr.id) as play_count,
            AVG(gr.score) as avg_score
        FROM games g
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        LEFT JOIN game_results gr ON g.id = gr.game_id
        WHERE g.id = :id
        GROUP BY g.id
    ");
    
    $stmt->execute([':id' => $gameId]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
        exit();
    }
    
    // تبدیل داده‌ها به فرمت مناسب
    $gameData = [
        'id' => (int)$game['id'],
        'title' => $game['title'],
        'category_id' => $game['category_id'],
        'category_name' => $game['category_name'],
        'subject' => $game['subject'],
        'topic' => $game['topic'],
        'description' => $game['description'],
        'instructions' => $game['instructions'],
        'estimated_time' => (int)$game['estimated_time'],
        'game_code' => $game['game_code'],
        'is_active' => (bool)$game['is_active'],
        'play_count' => (int)($game['play_count'] ?? 0),
        'avg_score' => $game['avg_score'] ? round((float)$game['avg_score'], 1) : 0,
        'created_at' => $game['created_at'],
        'updated_at' => $game['updated_at']
    ];
    
    echo json_encode([
        'success' => true,
        'game' => $gameData
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log("خطا در دریافت اطلاعات بازی: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در اتصال به پایگاه داده'
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("خطای عمومی در دریافت اطلاعات بازی: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای نامشخص رخ داد'
    ], JSON_UNESCAPED_UNICODE);
}
?>