<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$gameId = intval($_GET['id'] ?? 0);

if (!$gameId) {
    echo json_encode(['success' => false, 'message' => 'ID بازی نامعتبر']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM games WHERE id = ?");
    $stmt->execute([$gameId]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($game) {
        echo json_encode(['success' => true, 'game' => $game]);
    } else {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا: ' . $e->getMessage()]);
}
?>