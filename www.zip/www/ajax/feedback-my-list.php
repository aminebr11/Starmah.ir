<?php
session_start(); 
require_once '../config.php'; 
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) { 
    echo json_encode(['success'=>false]); 
    exit; 
}

$student_id = (int)($_SESSION['user_id'] ?? 0);

try {
    // Query اصلاح شده برای دریافت همه اطلاعات مورد نیاز
    $sql = "
        SELECT 
            f.id, 
            f.subject,
            f.subject_text,
            f.status, 
            f.created_at,
            f.message as original_message,
            -- دریافت پیام والدین از جدول feedback_messages
            (SELECT body FROM feedback_messages 
             WHERE feedback_id = f.id AND sender_role = 'parent' 
             ORDER BY created_at ASC LIMIT 1) AS parent_message,
            -- دریافت پاسخ AI
            (SELECT body FROM feedback_messages 
             WHERE feedback_id = f.id AND sender_role = 'ai' 
             ORDER BY created_at ASC LIMIT 1) AS ai_reply,
            -- دریافت پاسخ معلم
            (SELECT body FROM feedback_messages 
             WHERE feedback_id = f.id AND sender_role = 'teacher' 
             ORDER BY created_at DESC LIMIT 1) AS teacher_reply,
            -- تعداد پاسخ‌های خوانده نشده معلم
            (SELECT COUNT(*) FROM feedback_messages 
             WHERE feedback_id = f.id AND sender_role = 'teacher' 
             AND seen_by_student = 0) AS unread_count
        FROM feedbacks f
        WHERE f.student_id = ?
        ORDER BY f.created_at DESC
    ";
    
    $st = $conn->prepare($sql); 
    $st->execute([$student_id]); 
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    
    // مپ فارسی موضوعات
    $subjectMap = [
        'academic' => 'پیشرفت تحصیلی',
        'homework' => 'تکالیف و برنامه‌ریزی',
        'attention' => 'تمرکز/توجه',
        'behavior' => 'رفتار و اخلاق',
        'bullying' => 'تنمر/همسالان',
        'motivation' => 'انگیزه و اعتمادبه‌نفس',
        'schedule' => 'زمان‌بندی/حضور',
        'health' => 'سلامت/خواب/تغذیه',
        'special' => 'نیازهای ویژه',
        'suggestion' => 'پیشنهاد',
        'complaint' => 'شکایت/نگرانی',
        'technical' => 'مشکل فنی',
        'other' => 'موضوع دلخواه'
    ];
    
    $statusMap = [
        'pending' => 'در انتظار پاسخ',
        'responded' => 'پاسخ داده شده',
        'archived' => 'آرشیو'
    ];
    
    $items = array_map(function($r) use($subjectMap, $statusMap) {
        // تعیین متن پیام (اولویت با جدول feedback_messages)
        $message = !empty($r['parent_message']) ? $r['parent_message'] : $r['original_message'];
        
        // تعیین موضوع فارسی
        $subject_fa = '';
        if (!empty($r['subject'])) {
            if ($r['subject'] === 'other' && !empty($r['subject_text'])) {
                $subject_fa = $r['subject_text'];
            } else {
                $subject_fa = $subjectMap[$r['subject']] ?? $r['subject'];
            }
        } else {
            $subject_fa = 'نامشخص';
        }
        
        // تعیین وضعیت واقعی بر اساس پاسخ معلم
        $hasTeacherReply = !empty($r['teacher_reply']);
        $status = $hasTeacherReply ? 'responded' : ($r['status'] ?? 'pending');
        
        return [
            'id' => (int)$r['id'],
            'subject' => $r['subject'],
            'subject_fa' => $subject_fa,
            'subject_text' => $r['subject_text'],
            'message' => $message, // پیام کامل والدین
            'status' => $status,
            'status_fa' => $statusMap[$status] ?? $status,
            'created_at' => $r['created_at'],
            'ai_reply' => $r['ai_reply'],
            'teacher_reply' => $r['teacher_reply'],
            'has_ai_reply' => !empty($r['ai_reply']),
            'has_teacher_reply' => $hasTeacherReply,
            'unread_count' => (int)$r['unread_count']
        ];
    }, $rows);
    
    echo json_encode(['success' => true, 'items' => $items], JSON_UNESCAPED_UNICODE);
    
} catch(Throwable $e) { 
    error_log("Feedback list error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت اطلاعات']); 
}


?>