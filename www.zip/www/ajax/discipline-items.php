<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

session_start();
require_once '../config.php';

// تنظیم header برای JSON response
header('Content-Type: application/json; charset=utf-8');

// بررسی احراز هویت و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'دسترسی غیر مجاز'
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

$admin_id = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        
        case 'get_all':
            // دریافت همه موارد انضباطی
            $stmt = $conn->prepare("
                SELECT id, title, score, created_at 
                FROM discipline_items 
                ORDER BY title
            ");
            $stmt->execute();
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'items' => $items,
                'count' => count($items)
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'add':
            // افزودن مورد انضباطی جدید
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('درخواست نامعتبر');
            }
            
            $title = trim($_POST['title'] ?? '');
            $score = intval($_POST['score'] ?? 0);
            
            // اعتبارسنجی
            if (empty($title)) {
                throw new Exception('عنوان مورد انضباطی ضروری است');
            }
            
            if ($score < 1 || $score > 100) {
                throw new Exception('نمره منفی باید بین 1 تا 100 باشد');
            }
            
            // بررسی تکرار
            $stmt = $conn->prepare("SELECT id FROM discipline_items WHERE title = ?");
            $stmt->execute([$title]);
            if ($stmt->fetch()) {
                throw new Exception('این مورد انضباطی قبلاً ثبت شده است');
            }
            
            // افزودن به دیتابیس
            $stmt = $conn->prepare("
                INSERT INTO discipline_items (title, score, created_at) 
                VALUES (?, ?, NOW())
            ");
            $stmt->execute([$title, $score]);
            
            $new_id = $conn->lastInsertId();
            
            // لاگ فعالیت (اختیاری)
            try {
                $logStmt = $conn->prepare("
                    INSERT INTO admin_logs (admin_id, action, description, created_at) 
                    VALUES (?, 'add_discipline_item', ?, NOW())
                ");
                $logStmt->execute([$admin_id, "افزودن مورد انضباطی: {$title}"]);
            } catch (PDOException $e) {
                // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'مورد انضباطی با موفقیت افزوده شد',
                'id' => $new_id
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'edit':
            // ویرایش مورد انضباطی
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('درخواست نامعتبر');
            }
            
            $id = intval($_POST['id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $score = intval($_POST['score'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception('شناسه نامعتبر');
            }
            
            if (empty($title)) {
                throw new Exception('عنوان مورد انضباطی ضروری است');
            }
            
            if ($score < 1 || $score > 100) {
                throw new Exception('نمره منفی باید بین 1 تا 100 باشد');
            }
            
            // بررسی وجود رکورد
            $stmt = $conn->prepare("SELECT title FROM discipline_items WHERE id = ?");
            $stmt->execute([$id]);
            $old_record = $stmt->fetch();
            
            if (!$old_record) {
                throw new Exception('مورد انضباطی یافت نشد');
            }
            
            // بررسی تکرار عنوان (به جز رکورد جاری)
            $stmt = $conn->prepare("SELECT id FROM discipline_items WHERE title = ? AND id != ?");
            $stmt->execute([$title, $id]);
            if ($stmt->fetch()) {
                throw new Exception('این عنوان قبلاً استفاده شده است');
            }
            
            // بروزرسانی
            $stmt = $conn->prepare("
                UPDATE discipline_items 
                SET title = ?, score = ? 
                WHERE id = ?
            ");
            $stmt->execute([$title, $score, $id]);
            
            // لاگ فعالیت
            try {
                $logStmt = $conn->prepare("
                    INSERT INTO admin_logs (admin_id, action, description, created_at) 
                    VALUES (?, 'edit_discipline_item', ?, NOW())
                ");
                $logStmt->execute([$admin_id, "ویرایش مورد انضباطی: {$old_record['title']} → {$title}"]);
            } catch (PDOException $e) {
                // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'مورد انضباطی با موفقیت ویرایش شد'
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'delete':
            // حذف مورد انضباطی
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('درخواست نامعتبر');
            }
            
            $id = intval($_POST['id'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception('شناسه نامعتبر');
            }
            
            // بررسی وجود رکورد
            $stmt = $conn->prepare("SELECT title FROM discipline_items WHERE id = ?");
            $stmt->execute([$id]);
            $record = $stmt->fetch();
            
            if (!$record) {
                throw new Exception('مورد انضباطی یافت نشد');
            }
            
            // بررسی استفاده در رکوردهای انضباطی
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM discipline_records WHERE title = ?");
            $stmt->execute([$record['title']]);
            $usage_count = $stmt->fetch()['count'];
            
            if ($usage_count > 0) {
                throw new Exception("این مورد انضباطی در {$usage_count} رکورد استفاده شده و قابل حذف نیست");
            }
            
            // حذف کامل
            $stmt = $conn->prepare("DELETE FROM discipline_items WHERE id = ?");
            $stmt->execute([$id]);
            
            // لاگ فعالیت
            try {
                $logStmt = $conn->prepare("
                    INSERT INTO admin_logs (admin_id, action, description, created_at) 
                    VALUES (?, 'delete_discipline_item', ?, NOW())
                ");
                $logStmt->execute([$admin_id, "حذف مورد انضباطی: {$record['title']}"]);
            } catch (PDOException $e) {
                // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'مورد انضباطی با موفقیت حذف شد'
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'get_usage_stats':
            // آمار استفاده از موارد انضباطی
            $stmt = $conn->prepare("
                SELECT 
                    di.title,
                    di.score,
                    COUNT(dr.id) as usage_count,
                    SUM(dr.score) as total_negative_score
                FROM discipline_items di
                LEFT JOIN discipline_records dr ON di.title = dr.title
                GROUP BY di.id, di.title, di.score
                ORDER BY usage_count DESC, di.title
            ");
            $stmt->execute();
            $stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'stats' => $stats
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        default:
            throw new Exception('عملیات نامعتبر');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>