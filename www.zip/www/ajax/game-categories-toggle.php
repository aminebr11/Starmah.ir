<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$val = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 0;
if ($id <= 0) { echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit; }

try {
    $stmt = $conn->prepare("UPDATE game_categories SET is_active=? WHERE id=?");
    $ok = $stmt->execute([$val, $id]);
    echo json_encode(['success'=>true,'updated'=>$ok?1:0]);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
