<?php
// سیستم XP برای پادکست بر اساس تکمیل یکباره (امتیاز ثابت ۵۰)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// تابع برای ثبت لاگ (همانند کد قبلی شما)
function xp_log($message) {
    $timestamp = date('Y-m-d H:i:s');
    error_log("[$timestamp] [XP System] $message");
}

xp_log("XP completion request started");

// تلاش برای بارگذاری فایل‌های مورد نیاز (همانند کد قبلی شما)
 $config_loaded = false;
 $functions_loaded = false;

 $config_paths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
 $functions_paths = ['../functions.php', '../../functions.php', dirname(__DIR__) . '/functions.php'];

foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        xp_log("Config loaded from: $path");
        break;
    }
}

foreach ($functions_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functions_loaded = true;
        xp_log("Functions loaded from: $path");
        break;
    }
}

// تنظیم هدر خروجی به JSON
header('Content-Type: application/json; charset=utf-8');

// بررسی بارگذاری فایل‌ها
if (!$config_loaded || !$functions_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری فایل‌های سیستمی.']);
    exit;
}

// بررسی ورود کاربر
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفا ابتدا وارد شوید.']);
    exit;
}

 $student_id = $_SESSION['user_id'];
xp_log("User ID: $student_id");

// دریافت و اعتبارسنجی داده‌های ورودی از جاوااسکریپت
 $input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'فرمت داده ارسالی نامعتبر است.']);
    exit;
}

 $podcast_id = intval($input['podcast_id'] ?? 0);
 $action = $input['action'] ?? '';

xp_log("Parsed data - Podcast ID: $podcast_id, Action: $action");

// اعتبارسنجی اولیه: اکشن باید 'completion' و آیدی پادکست معتبر باشد
if ($podcast_id <= 0 || $action !== 'completion') {
    echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر است.']);
    exit;
}

// بررسی اتصال پایگاه داده
if (!isset($conn) || !$conn) {
    xp_log("Database connection not available");
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به پایگاه داده.']);
    exit;
}

try {
    // ۱. دریافت اطلاعات پادکست برای اعتبارسنجی و ساخت دلیل لاگ
    $stmt = $conn->prepare("SELECT id, title FROM podcasts WHERE id = ?");
    $stmt->execute([$podcast_id]);
    $podcast = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$podcast) {
        xp_log("Podcast not found with ID: $podcast_id");
        echo json_encode(['success' => false, 'message' => 'پادکست مورد نظر یافت نشد.']);
        exit;
    }
    
    xp_log("Podcast found: " . $podcast['title']);

    // ۲. مکانیزم اصلی: بررسی اینکه آیا کاربر قبلاً برای این پادکست امتیاز گرفته است یا خیر
    // ما در جدول xp_history می‌گردیم تا رکوردی با این کاربر و عنوان پادکست پیدا کنیم
    $reason_pattern = "%پادکست: " . $podcast['title'] . "%";
    $check_stmt = $conn->prepare("
        SELECT COUNT(*) FROM xp_history 
        WHERE student_id = ? 
        AND subject = 'گوش دادن به پادکست' 
        AND reason LIKE ?
    ");
    $check_stmt->execute([$student_id, $reason_pattern]);
    $already_awarded = $check_stmt->fetchColumn();
    
    xp_log("Check if XP already awarded for this podcast: " . ($already_awarded > 0 ? 'Yes' : 'No'));
    
    if ($already_awarded > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'شما قبلاً برای این پادکست امتیاز دریافت کرده‌اید.'
        ]);
        exit;
    }
    
    // ۳. تعریف امتیاز ثابت
    $xp_to_award = 50;
    $reason = "تکمیل گوش دادن به پادکست: " . $podcast['title'];
    
    xp_log("Awarding $xp_to_award XP for completion.");
    
    // ۴. شروع تراکنش برای ثبت امن در دیتابیس
    $conn->beginTransaction();
    
    // ثبت در تاریخچه XP
    $insert_stmt = $conn->prepare("
        INSERT INTO xp_history (student_id, subject, amount, reason, created_at) 
        VALUES (?, 'گوش دادن به پادکست', ?, ?, NOW())
    ");
    $insert_stmt->execute([$student_id, $xp_to_award, $reason]);
    
    // به‌روزرسانی امتیاز فقط برای ستون podcast_xp در جدول student_xp
    $update_stmt = $conn->prepare("
        INSERT INTO student_xp (student_id, podcast_xp, updated_at) 
        VALUES (?, ?, NOW()) 
        ON DUPLICATE KEY UPDATE 
            podcast_xp = COALESCE(podcast_xp, 0) + VALUES(podcast_xp),
            updated_at = NOW()
    ");
    $update_stmt->execute([$student_id, $xp_to_award]);
    
    // تایید تراکنش
    $conn->commit();
    
    xp_log("Transaction committed successfully for user $student_id");
    
    // ارسال پاسخ موفقیت‌آمیز
    echo json_encode([
        'success' => true,
        'message' => 'تبریک! شما ۵۰ امتیاز برای تکمیل این پادکست دریافت کردید!',
        'xp_earned' => $xp_to_award,
    ]);

} catch (Exception $e) {
    // بازگردانی تغییرات در صورت بروز هرگونه خطا
    if ($conn->inTransaction()) {
        $conn->rollback();
    }
    
    $error_msg = $e->getMessage();
    xp_log("Exception: $error_msg");
    
    echo json_encode([
        'success' => false,
        'message' => 'خطایی در سرور رخ داد. لطفا دوباره تلاش کنید.'
    ]);
}

xp_log("XP completion process completed");
?>