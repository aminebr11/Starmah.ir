<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

session_start();
require_once '../config.php';

// تنظیم header برای JSON response
header('Content-Type: application/json; charset=utf-8');

// بررسی احراز هویت و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'دسترسی غیر مجاز'
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

$admin_id = $_SESSION['user_id'];
$action = $_GET['action'] ?? 'get_history';

try {
    switch ($action) {
        
        case 'get_history':
            // پارامترهای فیلتر و صفحه‌بندی
            $student_filter = $_GET['student'] ?? '';
            $discipline_filter = $_GET['discipline_type'] ?? '';
            $from_date = $_GET['from_date'] ?? '';
            $to_date = $_GET['to_date'] ?? '';
            $page = max(1, intval($_GET['page'] ?? 1));
            $limit = max(10, min(100, intval($_GET['limit'] ?? 20)));
            $offset = ($page - 1) * $limit;
            
            // ساخت WHERE clause
            $where_conditions = ['1=1']; // شرط همیشه درست برای شروع
            $params = [];
            
            if (!empty($student_filter)) {
                $where_conditions[] = '(u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name, " ", u.last_name) LIKE ?)';
                $params[] = '%' . $student_filter . '%';
                $params[] = '%' . $student_filter . '%';
                $params[] = '%' . $student_filter . '%';
            }
            
            if (!empty($discipline_filter)) {
                $where_conditions[] = 'dr.title LIKE ?';
                $params[] = '%' . $discipline_filter . '%';
            }
            
            if (!empty($from_date)) {
                $where_conditions[] = 'dr.persian_date >= ?';
                $params[] = $from_date;
            }
            
            if (!empty($to_date)) {
                $where_conditions[] = 'dr.persian_date <= ?';
                $params[] = $to_date;
            }
            
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
            
            // شمارش کل رکوردها
            $count_sql = "
                SELECT COUNT(*) as total 
                FROM discipline_records dr 
                LEFT JOIN users u ON dr.student_id = u.id 
                LEFT JOIN users admin ON dr.created_by = admin.id 
                {$where_clause}
            ";
            
            $stmt = $conn->prepare($count_sql);
            $stmt->execute($params);
            $total_records = $stmt->fetch()['total'];
            
            // دریافت رکوردها
            $sql = "
                SELECT 
                    dr.id,
                    dr.student_id,
                    CONCAT(u.first_name, ' ', u.last_name) as student_name,
                    u.national_id as student_national_id,
                    dr.title as discipline_title,
                    dr.score as negative_score,
                    dr.persian_date,
                    dr.gregorian_date,
                    dr.description,
                    dr.created_by as admin_id,
                    CONCAT(admin.first_name, ' ', admin.last_name) as created_by,
                    dr.created_at
                FROM discipline_records dr
                LEFT JOIN users u ON dr.student_id = u.id
                LEFT JOIN users admin ON dr.created_by = admin.id
                {$where_clause}
                ORDER BY dr.gregorian_date DESC, dr.created_at DESC
                LIMIT {$limit} OFFSET {$offset}
            ";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // افزودن کلاس دانش‌آموز (اختیاری)
            foreach ($records as &$record) {
                $record['id'] = intval($record['id']);
                $record['student_id'] = intval($record['student_id']);
                $record['negative_score'] = intval($record['negative_score']);
                $record['admin_id'] = intval($record['admin_id']);
                $record['created_by'] = $record['created_by'] ?: 'نامشخص';
                
                // تلاش برای دریافت کلاس دانش‌آموز
                try {
                    $class_stmt = $conn->prepare("
                        SELECT class_name 
                        FROM student_classes 
                        WHERE student_id = ? 
                        ORDER BY created_at DESC 
                        LIMIT 1
                    ");
                    $class_stmt->execute([$record['student_id']]);
                    $class_info = $class_stmt->fetch();
                    $record['student_class'] = $class_info ? $class_info['class_name'] : 'نامشخص';
                } catch (PDOException $e) {
                    $record['student_class'] = 'نامشخص';
                }
            }
            
            // آمار کلی
            $stats_sql = "
                SELECT 
                    COUNT(DISTINCT dr.id) as total_records,
                    COUNT(DISTINCT dr.student_id) as violated_students,
                    SUM(dr.score) as total_score,
                    COUNT(CASE WHEN dr.persian_date >= ? THEN 1 END) as this_week_records
                FROM discipline_records dr 
            ";
            
            // محاسبه تاریخ هفته جاری (تقریبی)
            $current_persian_date = convertGregorianToPersian(date('Y-m-d'));
            $week_start = getWeekStart($current_persian_date);
            
            $stmt = $conn->prepare($stats_sql);
            $stmt->execute([$week_start]);
            $stats = $stmt->fetch();
            
            echo json_encode([
                'success' => true,
                'history' => $records,
                'stats' => [
                    'total_records' => intval($stats['total_records']),
                    'violated_students' => intval($stats['violated_students']),
                    'total_score' => intval($stats['total_score']),
                    'this_week_records' => intval($stats['this_week_records'])
                ],
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => ceil($total_records / $limit),
                    'total_records' => intval($total_records),
                    'per_page' => $limit
                ]
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'get_filters':
            // دریافت گزینه‌های فیلتر
            
            // لیست دانش‌آموزان دارای مورد انضباطی
            $students_sql = "
                SELECT DISTINCT CONCAT(u.first_name, ' ', u.last_name) as student_name
                FROM discipline_records dr
                LEFT JOIN users u ON dr.student_id = u.id
                WHERE u.first_name IS NOT NULL
                ORDER BY student_name
            ";
            $stmt = $conn->prepare($students_sql);
            $stmt->execute();
            $students = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // لیست موارد انضباطی
            $disciplines_sql = "
                SELECT DISTINCT title 
                FROM discipline_records 
                ORDER BY title
            ";
            $stmt = $conn->prepare($disciplines_sql);
            $stmt->execute();
            $disciplines = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            echo json_encode([
                'success' => true,
                'students' => $students,
                'disciplines' => $disciplines
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        case 'edit_record':
            // ویرایش رکورد انضباطی
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('درخواست نامعتبر');
            }
            
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);
            
            if (!$data || json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('داده‌های JSON نامعتبر');
            }
            
            $record_id = intval($data['id'] ?? 0);
            $title = trim($data['title'] ?? '');
            $score = intval($data['score'] ?? 0);
            $date = trim($data['date'] ?? '');
            $description = trim($data['description'] ?? '');
            
            if ($record_id <= 0) {
                throw new Exception('شناسه رکورد نامعتبر');
            }
            
            if (empty($title)) {
                throw new Exception('عنوان مورد انضباطی ضروری است');
            }
            
            if ($score < 1 || $score > 100) {
                throw new Exception('نمره منفی باید بین 1 تا 100 باشد');
            }
            
            if (empty($date) || !isValidPersianDate($date)) {
                throw new Exception('تاریخ نامعتبر است');
            }
            
            // بررسی وجود رکورد
            $stmt = $conn->prepare("
                SELECT dr.*, CONCAT(u.first_name, ' ', u.last_name) as student_name
                FROM discipline_records dr
                LEFT JOIN users u ON dr.student_id = u.id
                WHERE dr.id = ?
            ");
            $stmt->execute([$record_id]);
            $existing = $stmt->fetch();
            
            if (!$existing) {
                throw new Exception('رکورد یافت نشد');
            }
            
            // تبدیل تاریخ
            $gregorian_date = convertPersianToGregorian($date);
            if (!$gregorian_date) {
                throw new Exception('خطا در تبدیل تاریخ');
            }
            
            // شروع تراکنش برای بروزرسانی چند جدوله
            $conn->beginTransaction();
            
            try {
                // بروزرسانی رکورد اصلی
                $stmt = $conn->prepare("
                    UPDATE discipline_records 
                    SET title = ?, score = ?, persian_date = ?, gregorian_date = ?, description = ? 
                    WHERE id = ?
                ");
                $stmt->execute([$title, $score, $date, $gregorian_date, $description, $record_id]);
                
                // بروزرسانی تاریخچه XP و dic_xp (اگر تغییر امتیاز داشته باشیم)
                if ($existing['score'] != $score) {
                    try {
                        $old_score = $existing['score'];
                        $new_score = $score;
                        $score_diff = $new_score - $old_score; // مثبت = افزایش جریمه، منفی = کاهش جریمه
                        
                        // اضافه کردن رکورد جدید به تاریخچه XP
                        $xp_reason = "تصحیح مورد انضباطی: {$title} (تغییر از -{$old_score} به -{$new_score})";
                        $xp_stmt = $conn->prepare("
                            INSERT INTO xp_history 
                            (student_id, subject, amount, reason, admin_id, created_at) 
                            VALUES (?, ?, ?, ?, ?, NOW())
                        ");
                        
                        // اگر امتیاز افزایش یافته (جریمه بیشتر شده) -> منفی بیشتر
                        // اگر امتیاز کاهش یافته (جریمه کمتر شده) -> مثبت (جبران)
                        $xp_stmt->execute([
                            $existing['student_id'],
                            'تصحیح انضباطی',
                            -$score_diff, // اگر score_diff = 5، یعنی -5 (منفی بیشتر)
                            $xp_reason,
                            $admin_id
                        ]);
                        
                        // بروزرسانی dic_xp دانش‌آموز
                        // اگر جریمه افزایش یافت -> dic_xp باید منفی‌تر شود
                        // اگر جریمه کاهش یافت -> dic_xp باید کمتر منفی شود
                        $update_xp_stmt = $conn->prepare("
                            UPDATE student_xp 
                            SET dic_xp = dic_xp - ?,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE student_id = ?
                        ");
                        $update_xp_stmt->execute([$score_diff, $existing['student_id']]);
                        
                    } catch (PDOException $e) {
                        // اگر جداول XP وجود ندارد، ادامه می‌دهیم
                        error_log("XP update failed: " . $e->getMessage());
                    }
                }
                
                // لاگ فعالیت
                try {
                    $log_message = "ویرایش رکورد انضباطی {$existing['student_name']}: {$existing['title']} → {$title}";
                    $log_stmt = $conn->prepare("
                        INSERT INTO admin_logs (admin_id, action, description, created_at) 
                        VALUES (?, 'edit_discipline_record', ?, NOW())
                    ");
                    $log_stmt->execute([$admin_id, $log_message]);
                } catch (PDOException $e) {
                    // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
                }
                
                $conn->commit();
                
                echo json_encode([
                    'success' => true,
                    'message' => 'رکورد با موفقیت ویرایش شد'
                ], JSON_UNESCAPED_UNICODE);
                
            } catch (Exception $e) {
                $conn->rollback();
                throw $e;
            }
            break;
            
        case 'delete_record':
            // حذف رکورد انضباطی
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('درخواست نامعتبر');
            }
            
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);
            
            if (!$data || json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('داده‌های JSON نامعتبر');
            }
            
            $record_id = intval($data['id'] ?? 0);
            
            if ($record_id <= 0) {
                throw new Exception('شناسه رکورد نامعتبر');
            }
            
            // بررسی وجود رکورد
            $stmt = $conn->prepare("
                SELECT dr.*, CONCAT(u.first_name, ' ', u.last_name) as student_name 
                FROM discipline_records dr
                LEFT JOIN users u ON dr.student_id = u.id
                WHERE dr.id = ?
            ");
            $stmt->execute([$record_id]);
            $record = $stmt->fetch();
            
            if (!$record) {
                throw new Exception('رکورد یافت نشد');
            }
            
            // شروع تراکنش
            $conn->beginTransaction();
            
            try {
                // حذف رکورد اصلی
                $stmt = $conn->prepare("DELETE FROM discipline_records WHERE id = ?");
                $stmt->execute([$record_id]);
                
                // بازگرداندن امتیاز به دانش‌آموز در سیستم XP (dic_xp)
                try {
                    // اضافه کردن رکورد جبرانی به تاریخچه XP
                    $xp_reason = "بازگردانی امتیاز از حذف مورد انضباطی: {$record['title']} (+{$record['score']} امتیاز)";
                    $xp_stmt = $conn->prepare("
                        INSERT INTO xp_history 
                        (student_id, subject, amount, reason, admin_id, created_at) 
                        VALUES (?, ?, ?, ?, ?, NOW())
                    ");
                    $xp_stmt->execute([
                        $record['student_id'],
                        'بازگردانی انضباطی',
                        $record['score'], // امتیاز مثبت برای جبران
                        $xp_reason,
                        $admin_id
                    ]);
                    
                    // بازگردانی امتیاز در dic_xp (کم کردن از منفی = مثبت کردن)
                    $update_xp_stmt = $conn->prepare("
                        UPDATE student_xp 
                        SET dic_xp = dic_xp + ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE student_id = ?
                    ");
                    $update_xp_stmt->execute([$record['score'], $record['student_id']]);
                    
                } catch (PDOException $e) {
                    // اگر جداول XP وجود ندارد، ادامه می‌دهیم
                    error_log("XP restoration failed: " . $e->getMessage());
                }
                
                // لاگ فعالیت
                try {
                    $log_message = "حذف رکورد انضباطی {$record['student_name']}: {$record['title']} (-{$record['score']} امتیاز بازگردانده شد)";
                    $log_stmt = $conn->prepare("
                        INSERT INTO admin_logs (admin_id, action, description, created_at) 
                        VALUES (?, 'delete_discipline_record', ?, NOW())
                    ");
                    $log_stmt->execute([$admin_id, $log_message]);
                } catch (PDOException $e) {
                    // اگر جدول admin_logs وجود ندارد، ادامه می‌دهیم
                }
                
                $conn->commit();
                
                echo json_encode([
                    'success' => true,
                    'message' => 'رکورد با موفقیت حذف و امتیاز بازگردانده شد'
                ], JSON_UNESCAPED_UNICODE);
                
            } catch (Exception $e) {
                $conn->rollback();
                throw $e;
            }
            break;
            
        case 'export_excel':
            // خروجی اکسل (ساده)
            $student_filter = $_GET['student'] ?? '';
            $discipline_filter = $_GET['discipline_type'] ?? '';
            $from_date = $_GET['from_date'] ?? '';
            $to_date = $_GET['to_date'] ?? '';
            
            $where_conditions = ['1=1'];
            $params = [];
            
            if (!empty($student_filter)) {
                $where_conditions[] = '(u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name, " ", u.last_name) LIKE ?)';
                $params[] = '%' . $student_filter . '%';
                $params[] = '%' . $student_filter . '%';
                $params[] = '%' . $student_filter . '%';
            }
            
            if (!empty($discipline_filter)) {
                $where_conditions[] = 'dr.title LIKE ?';
                $params[] = '%' . $discipline_filter . '%';
            }
            
            if (!empty($from_date)) {
                $where_conditions[] = 'dr.persian_date >= ?';
                $params[] = $from_date;
            }
            
            if (!empty($to_date)) {
                $where_conditions[] = 'dr.persian_date <= ?';
                $params[] = $to_date;
            }
            
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
            
            $sql = "
                SELECT 
                    CONCAT(u.first_name, ' ', u.last_name) as 'نام دانش‌آموز',
                    dr.title as 'مورد انضباطی',
                    dr.score as 'امتیاز منفی',
                    dr.persian_date as 'تاریخ',
                    dr.description as 'توضیحات',
                    CONCAT(admin.first_name, ' ', admin.last_name) as 'ثبت کننده'
                FROM discipline_records dr
                LEFT JOIN users u ON dr.student_id = u.id
                LEFT JOIN users admin ON dr.created_by = admin.id
                {$where_clause}
                ORDER BY dr.gregorian_date DESC
            ";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'data' => $records,
                'filename' => 'discipline_records_' . date('Y-m-d_H-i-s') . '.csv'
            ], JSON_UNESCAPED_UNICODE);
            break;
            
        default:
            throw new Exception('عملیات نامعتبر');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

// توابع کمکی
function isValidPersianDate($dateStr) {
    if (empty($dateStr)) return false;
    
    $persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    $cleanDate = str_replace($persianNumbers, $englishNumbers, trim($dateStr));
    
    if (preg_match('/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})$/', $cleanDate, $matches)) {
        $year = (int)$matches[1];
        $month = (int)$matches[2];
        $day = (int)$matches[3];
        
        if ($year < 1300 || $year > 1500) return false;
        if ($month < 1 || $month > 12) return false;
        if ($day < 1 || $day > 31) return false;
        
        if ($month <= 6 && $day > 31) return false;
        if ($month > 6 && $month < 12 && $day > 30) return false;
        if ($month == 12 && $day > 29) return false;
        
        return true;
    }
    
    return false;
}

function convertPersianToGregorian($persianDate) {
    $persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    $cleanDate = str_replace($persianNumbers, $englishNumbers, $persianDate);
    
    if (preg_match('/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/', $cleanDate, $matches)) {
        $jYear = (int)$matches[1];
        $jMonth = (int)$matches[2];
        $jDay = (int)$matches[3];
        
        $gYear = $jYear + 621;
        if ($jMonth <= 6) {
            $gMonth = $jMonth + 3;
            if ($gMonth > 12) {
                $gMonth -= 12;
                $gYear++;
            }
        } else {
            $gMonth = $jMonth - 9;
            $gYear++;
        }
        
        $gDay = $jDay;
        
        if ($gMonth == 2 && $gDay > 28) $gDay = 28;
        if (in_array($gMonth, [4, 6, 9, 11]) && $gDay > 30) $gDay = 30;
        if ($gDay > 31) $gDay = 31;
        
        return sprintf('%04d-%02d-%02d', $gYear, $gMonth, $gDay);
    }
    
    return null;
}

function convertGregorianToPersian($gregorianDate) {
    try {
        $date = new DateTime($gregorianDate);
        $gy = (int)$date->format('Y');
        $gm = (int)$date->format('m');
        $gd = (int)$date->format('d');
        
        $jy = $gy - 621;
        if ($gm >= 4 && $gm <= 9) {
            $jm = $gm - 3;
        } else {
            if ($gm >= 10) {
                $jm = $gm - 3;
            } else {
                $jm = $gm + 9;
                $jy--;
            }
        }
        $jd = $gd;
        
        return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    } catch (Exception $e) {
        return date('Y/m/d');
    }
}

function getWeekStart($persianDate) {
    if (preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $persianDate, $matches)) {
        $year = (int)$matches[1];
        $month = (int)$matches[2];
        $day = max(1, (int)$matches[3] - 7);
        
        return sprintf('%04d/%02d/%02d', $year, $month, $day);
    }
    
    return $persianDate;
}
?>