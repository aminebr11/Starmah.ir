<?php
// ajax/manage-badges.php - مدیریت نشان‌ها
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'create':
        $name = sanitize($_POST['name'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $icon = sanitize($_POST['icon'] ?? '🏆');
        $condition_type = sanitize($_POST['condition_type'] ?? '');
        $condition_value = (int)($_POST['condition_value'] ?? 0);
        $subject = sanitize($_POST['subject'] ?? '');
        
        if (empty($name) || empty($condition_type)) {
            echo json_encode(['success' => false, 'message' => 'نام و نوع شرط الزامی است']);
            exit;
        }
        
        try {
            $stmt = $conn->prepare("
                INSERT INTO badges (name, description, icon, condition_type, condition_value, subject) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $description, $icon, $condition_type, $condition_value, $subject]);
            
            echo json_encode(['success' => true, 'message' => 'نشان ایجاد شد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در ایجاد نشان']);
        }
        break;
        
    case 'award':
        $badge_id = (int)($_POST['badge_id'] ?? 0);
        $student_id = (int)($_POST['student_id'] ?? 0);
        
        if ($badge_id <= 0 || $student_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'اطلاعات نامعتبر']);
            exit;
        }
        
        try {
            $stmt = $conn->prepare("
                INSERT IGNORE INTO student_badges (student_id, badge_id) 
                VALUES (?, ?)
            ");
            $stmt->execute([$student_id, $badge_id]);
            
            echo json_encode(['success' => true, 'message' => 'نشان به دانش‌آموز اعطا شد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در اعطای نشان']);
        }
        break;
        
    case 'revoke':
        $badge_id = (int)($_POST['badge_id'] ?? 0);
        $student_id = (int)($_POST['student_id'] ?? 0);
        
        try {
            $stmt = $conn->prepare("DELETE FROM student_badges WHERE student_id = ? AND badge_id = ?");
            $stmt->execute([$student_id, $badge_id]);
            
            echo json_encode(['success' => true, 'message' => 'نشان از دانش‌آموز گرفته شد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در گرفتن نشان']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'عملیات نامعتبر']);
}
?>
