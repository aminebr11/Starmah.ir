<?php
// شروع session برای بررسی دسترسی
session_start();

// فعال‌سازی نمایش خطاها (در محیط توسعه)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// تنظیم هدر JSON
header('Content-Type: application/json; charset=utf-8');

try {
    // بررسی وجود فایل‌های ضروری
    $config_path = dirname(__DIR__) . '/config.php';
    $functions_path = dirname(__DIR__) . '/functions.php';
    
    if (!file_exists($config_path)) {
        throw new Exception('فایل config.php یافت نشد');
    }
    
    if (!file_exists($functions_path)) {
        throw new Exception('فایل functions.php یافت نشد');
    }
    
    // include کردن فایل‌های ضروری
    require_once $config_path;
    require_once $functions_path;
    
    // بررسی اتصال به پایگاه داده
    if (!isset($conn) || $conn === null) {
        throw new Exception('اتصال به پایگاه داده برقرار نیست');
    }
    
    // بررسی دسترسی ادمین
    if (!isAdmin()) {
        throw new Exception('شما مجوز انجام این کار را ندارید');
    }
    
    // بررسی method درخواست
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method درخواست نامعتبر است');
    }
    
    // دریافت JSON input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('داده‌های JSON نامعتبر است');
    }
    
    // بررسی homework_id
    if (!isset($data['homework_id']) || !is_numeric($data['homework_id'])) {
        throw new Exception('شناسه تکلیف نامعتبر است');
    }
    
    $homework_id = intval($data['homework_id']);
    
    // بررسی وجود تکلیف
    $stmt = $conn->prepare("SELECT * FROM homework WHERE id = ?");
    $stmt->execute([$homework_id]);
    $homework = $stmt->fetch();
    
    if (!$homework) {
        throw new Exception('تکلیف مورد نظر یافت نشد');
    }
    
    // حذف فایل مرتبط در صورت وجود
    if (!empty($homework['file_path'])) {
        $file_full_path = dirname(__DIR__) . '/' . $homework['file_path'];
        if (file_exists($file_full_path)) {
            if (!unlink($file_full_path)) {
                // لاگ کردن خطا اما ادامه حذف از دیتابیس
                error_log("Could not delete file: " . $file_full_path);
            }
        }
    }
    
    // حذف از پایگاه داده
    $stmt = $conn->prepare("DELETE FROM homework WHERE id = ?");
    $success = $stmt->execute([$homework_id]);
    
    if (!$success) {
        throw new Exception('خطا در حذف تکلیف از پایگاه داده');
    }
    
    // بررسی تعداد ردیف‌های حذف شده
    if ($stmt->rowCount() === 0) {
        throw new Exception('هیچ تکلیفی حذف نشد. ممکن است قبلاً حذف شده باشد.');
    }
    
    // پاسخ موفق
    echo json_encode([
        'success' => true,
        'message' => 'تکلیف با موفقیت حذف شد',
        'deleted_id' => $homework_id
    ]);
    
} catch (Exception $e) {
    // لاگ کردن خطا
    error_log('Homework Delete Error: ' . $e->getMessage());
    
    // پاسخ خطا
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'debug_info' => [
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
            'input_data' => $input ?? '',
            'parsed_data' => $data ?? null
        ]
    ]);
}
?>