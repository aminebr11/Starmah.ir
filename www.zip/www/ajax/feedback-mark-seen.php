<?php
// ajax/feedback-mark-seen.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!isLoggedIn()) {
  echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit;
}

$studentId = (int)($_SESSION['user_id'] ?? 0);
if ($studentId <= 0) {
  echo json_encode(['success'=>false,'message'=>'Invalid user']); exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$feedbackId = (int)($input['feedback_id'] ?? 0);
if ($feedbackId <= 0) {
  echo json_encode(['success'=>false,'message'=>'Invalid feedback_id']); exit;
}

try {
  // مالکیت گفتگو برای همین دانش‌آموز
  $chk = $conn->prepare("SELECT COUNT(*) FROM feedbacks WHERE id=? AND student_id=?");
  $chk->execute([$feedbackId, $studentId]);
  if ((int)$chk->fetchColumn() === 0) {
    echo json_encode(['success'=>false,'message'=>'Forbidden']); exit;
  }

  // همه‌ی پیام‌های «معلم» این گفتگو را خوانده‌شده کن
  $upd = $conn->prepare("
    UPDATE feedback_messages
    SET seen_by_student = 1
    WHERE feedback_id = ? AND sender_role = 'teacher' AND seen_by_student = 0
  ");
  $upd->execute([$feedbackId]);

  echo json_encode(['success'=>true, 'updated'=>$upd->rowCount()]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
