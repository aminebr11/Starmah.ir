<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'داده‌ای دریافت نشد']);
        exit();
    }
    
    // اعتبارسنجی
    $requiredFields = ['student_id', 'game_id', 'score', 'time_spent', 'accuracy', 'completed_at'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            echo json_encode(['success' => false, 'message' => "فیلد $field الزامی است"]);
            exit();
        }
    }
    
    // اعتبارسنجی مقادیر
    $score = (int)$input['score'];
    $timeSpent = (int)$input['time_spent'];
    $accuracy = (int)$input['accuracy'];
    
    if ($score < 0 || $score > 100) {
        echo json_encode(['success' => false, 'message' => 'امتیاز باید بین 0 تا 100 باشد']);
        exit();
    }
    
    if ($timeSpent < 1) {
        echo json_encode(['success' => false, 'message' => 'زمان باید بیشتر از صفر باشد']);
        exit();
    }
    
    if ($accuracy < 0 || $accuracy > 100) {
        echo json_encode(['success' => false, 'message' => 'دقت باید بین 0 تا 100 باشد']);
        exit();
    }
    
    // بررسی وجود دانش‌آموز و بازی
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$input['student_id']]);
    if ($checkStmt->fetchColumn() == 0) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit();
    }
    
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE id = ?");
    $checkStmt->execute([$input['game_id']]);
    if ($checkStmt->fetchColumn() == 0) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
        exit();
    }
    
    // درج نتیجه جدید
    $stmt = $conn->prepare("
        INSERT INTO game_results (student_id, game_id, score, time_spent, accuracy, completed_at) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $result = $stmt->execute([
        $input['student_id'],
        $input['game_id'],
        $score,
        $timeSpent,
        $accuracy,
        $input['completed_at']
    ]);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'نتیجه با موفقیت اضافه شد',
            'result_id' => $conn->lastInsertId()
        ]);
    } else {
        throw new Exception('خطا در درج نتیجه');
    }
    
} catch (Exception $e) {
    error_log("Error in add-manual-result.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در افزودن نتیجه: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>