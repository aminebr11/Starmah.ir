<?php
// ajax/feedback-action.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'Forbidden']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$id     = (int)($input['id'] ?? 0);

if ($id<=0 || $action==='') { echo json_encode(['success'=>false,'message'=>'Invalid input']); exit; }

try {
  switch ($action) {
    case 'archive':
      $stmt = $conn->prepare("UPDATE feedbacks SET status='archived', updated_at=NOW() WHERE id=?");
      $stmt->execute([$id]);
      break;

    case 'delete':
      // حذف امن: اول پیام‌ها بعد گفتگو
      $conn->beginTransaction();
      $conn->prepare("DELETE FROM feedback_messages WHERE feedback_id=?")->execute([$id]);
      $conn->prepare("DELETE FROM feedbacks WHERE id=?")->execute([$id]);
      $conn->commit();
      break;

    case 'mark_responded':
      $stmt = $conn->prepare("UPDATE feedbacks SET status='responded', updated_at=NOW() WHERE id=?");
      $stmt->execute([$id]);
      break;

    case 'mark_pending':
      $stmt = $conn->prepare("UPDATE feedbacks SET status='pending', updated_at=NOW() WHERE id=?");
      $stmt->execute([$id]);
      break;

    default:
      echo json_encode(['success'=>false,'message'=>'Unknown action']); exit;
  }

  echo json_encode(['success'=>true]);
} catch (Throwable $e) {
  if ($conn->inTransaction()) $conn->rollBack();
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
