<?php
// ajax/delete_question.php
require_once '../config.php';
require_once '../functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// بررسی دسترسی ادمین
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    $raw_input = file_get_contents('php://input');
    error_log("Delete question raw input: " . $raw_input);
    
    $input = json_decode($raw_input, true);
    
    if (!$input) {
        throw new Exception('داده‌های ورودی نامعتبر: ' . json_last_error_msg());
    }
    
    $question_id = (int)($input['question_id'] ?? 0);
    $exam_id = (int)($input['exam_id'] ?? 0);
    
    if (!$question_id) {
        throw new Exception('شناسه سوال نامعتبر است');
    }
    
    // بررسی وجود سوال
    $stmt = $conn->prepare("SELECT id, quiz_id FROM quiz_questions WHERE id = ?");
    $stmt->execute([$question_id]);
    $question = $stmt->fetch();
    
    if (!$question) {
        throw new Exception('سوال یافت نشد');
    }
    
    // شروع تراکنش
    $conn->beginTransaction();
    
    try {
        // حذف سوال
        $stmt = $conn->prepare("DELETE FROM quiz_questions WHERE id = ?");
        $result = $stmt->execute([$question_id]);
        
        if (!$result) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception('خطا در حذف سوال: ' . $errorInfo[2]);
        }
        
        // بروزرسانی شمارش سوالات و امتیازات در جدول آزمون‌ها
        $stmt = $conn->prepare("
            UPDATE quizzes 
            SET questions_count = (
                SELECT COUNT(*) FROM quiz_questions 
                WHERE quiz_id = ? AND is_active = 1
            ),
            total_points = (
                SELECT COALESCE(SUM(points), 0) FROM quiz_questions 
                WHERE quiz_id = ? AND is_active = 1
            )
            WHERE id = ?
        ");
        $stmt->execute([$question['quiz_id'], $question['quiz_id'], $question['quiz_id']]);
        
        $conn->commit();
        
        error_log("Question $question_id deleted successfully from quiz {$question['quiz_id']}");
        
        echo json_encode([
            'success' => true,
            'message' => 'سوال با موفقیت حذف شد',
            'question_id' => $question_id,
            'quiz_id' => $question['quiz_id']
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Delete Question Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    error_log("Delete Question PDO Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>