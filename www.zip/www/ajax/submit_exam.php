<?php
// فایل ajax/submit_exam.php - اصلاح شده برای ذخیره صحیح XP

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// بررسی method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// شروع session
session_start();

// بررسی ورود کاربر
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    echo json_encode(['success' => false, 'message' => 'کاربر وارد نشده است'], JSON_UNESCAPED_UNICODE);
    exit;
}

// بارگذاری config
$configPaths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$configLoaded = false;

foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $configLoaded = true;
        break;
    }
}

if (!$configLoaded || !isset($conn)) {
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به دیتابیس'], JSON_UNESCAPED_UNICODE);
    exit;
}

// خواندن داده ورودی
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['exam_id'])) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit;
}

$examId = (int)$input['exam_id'];
$userId = $_SESSION['user_id'];
$answers = $input['answers'] ?? [];
$timeTaken = (int)($input['time_taken'] ?? 0);
$isForceExit = isset($input['force_exit']) && $input['force_exit'];
$isAutoSubmit = isset($input['auto_submit']) && $input['auto_submit'];

// Debug: لاگ کردن داده‌های دریافتی
error_log("=== EXAM SUBMISSION START ===");
error_log("Exam ID: $examId, User ID: $userId, Answers: " . json_encode($answers));

try {
    // بررسی وجود آزمون
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ? AND is_active = 1 AND is_visible = 1");
    $stmt->execute([$examId]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        echo json_encode(['success' => false, 'message' => 'آزمون یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // بررسی تلاش قبلی
    $stmt = $conn->prepare("SELECT id FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?");
    $stmt->execute([$examId, $userId]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما قبلاً در این آزمون شرکت کرده‌اید'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // دریافت سوالات
    $stmt = $conn->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? AND is_active = 1");
    $stmt->execute([$examId]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($questions)) {
        echo json_encode(['success' => false, 'message' => 'سوالی برای این آزمون یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // محاسبه نمره
    $score = 0;
    $totalScore = 0;
    $detailedAnswers = [];
    $correctAnswers = 0;
    
    foreach ($questions as $question) {
        $questionId = (string)$question['id'];
        $questionPoints = (int)$question['points'];
        $totalScore += $questionPoints;
        
        // دریافت پاسخ دانش‌آموز
        $studentAnswer = '';
        if (isset($answers[$questionId])) {
            $studentAnswer = $answers[$questionId];
        } elseif (isset($answers[(int)$questionId])) {
            $studentAnswer = $answers[(int)$questionId];
        }
        
        $studentAnswer = trim($studentAnswer);
        $isCorrect = false;
        
        // بررسی صحت پاسخ (فقط اگر خروج اجباری نباشد)
        if (!empty($studentAnswer) && !$isForceExit) {
            if ($question['question_type'] === 'mcq') {
                $questionData = json_decode($question['question_data'], true);
                if ($questionData && isset($questionData['options']) && is_array($questionData['options'])) {
                    foreach ($questionData['options'] as $option) {
                        if (is_array($option) && isset($option['correct']) && $option['correct'] && isset($option['text'])) {
                            $correctAnswer = trim($option['text']);
                            $isCorrect = (strcasecmp($studentAnswer, $correctAnswer) === 0);
                            break;
                        }
                    }
                }
                
            } elseif ($question['question_type'] === 'tf') {
                $questionData = json_decode($question['question_data'], true);
                if ($questionData && isset($questionData['correct_answer'])) {
                    $correctAnswer = trim($questionData['correct_answer']);
                    $isCorrect = (strcasecmp($studentAnswer, $correctAnswer) === 0);
                }
                
            } elseif ($question['question_type'] === 'short') {
                $questionData = json_decode($question['question_data'], true);
                if ($questionData && isset($questionData['correct_answer'])) {
                    $correctAnswer = trim(strtolower($questionData['correct_answer']));
                    $studentAnswerLower = trim(strtolower($studentAnswer));
                    
                    if ($studentAnswerLower === $correctAnswer) {
                        $isCorrect = true;
                    } elseif (strlen($correctAnswer) > 3 && strpos($studentAnswerLower, $correctAnswer) !== false) {
                        $isCorrect = true;
                    }
                }
            }
        }
        
        if ($isCorrect) {
            $score += $questionPoints;
            $correctAnswers++;
        }
        
        $detailedAnswers[$questionId] = [
            'student_answer' => $studentAnswer,
            'is_correct' => $isCorrect,
            'points_earned' => $isCorrect ? $questionPoints : 0,
            'question_type' => $question['question_type']
        ];
    }
    
    // اگر خروج اجباری است، نمره صفر
    if ($isForceExit) {
        $score = 0;
        $correctAnswers = 0;
    }
    
    // محاسبه درصد دقت
    $accuracy = count($questions) > 0 ? round(($correctAnswers / count($questions)) * 100, 1) : 0;
    $percentage = $totalScore > 0 ? round(($score / $totalScore) * 100, 1) : 0;
    
    error_log("Score calculation: $score/$totalScore ($percentage%), Correct: $correctAnswers/" . count($questions));
    
    // شروع تراکنش دیتابیس
    $conn->beginTransaction();
    
    try {
        // ذخیره نتیجه آزمون
        $stmt = $conn->prepare("
            INSERT INTO quiz_attempts (quiz_id, student_id, score, total_score, time_taken, answers, submitted_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $answersJson = json_encode($detailedAnswers, JSON_UNESCAPED_UNICODE);
        $stmt->execute([$examId, $userId, $score, $totalScore, $timeTaken, $answersJson]);
        
        error_log("Quiz attempt saved successfully");
        
        // محاسبه XP بر اساس عملکرد
        $earnedXP = calculateExamXP($score, $totalScore, $percentage, $timeTaken, $exam['duration_minutes'], $isForceExit);
        
        error_log("Calculated XP: $earnedXP");
        
        // به‌روزرسانی XP دانش‌آموز (فقط اگر XP > 0)
        if ($earnedXP > 0) {
            // بررسی وجود رکورد student_xp
            $stmt = $conn->prepare("SELECT id, exam_xp FROM student_xp WHERE student_id = ?");
            $stmt->execute([$userId]);
            $currentXP = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($currentXP) {
                // به‌روزرسانی exam_xp (total_xp و level خودکار توسط MySQL محاسبه می‌شوند)
                $newExamXP = $currentXP['exam_xp'] + $earnedXP;
                
                $stmt = $conn->prepare("
                    UPDATE student_xp 
                    SET exam_xp = ?, updated_at = NOW() 
                    WHERE student_id = ?
                ");
                $stmt->execute([$newExamXP, $userId]);
                
                // دریافت مقادیر جدید که MySQL محاسبه کرده (total_xp و level)
                $stmt = $conn->prepare("SELECT total_xp, level FROM student_xp WHERE student_id = ?");
                $stmt->execute([$userId]);
                $newData = $stmt->fetch(PDO::FETCH_ASSOC);
                $newTotalXP = $newData['total_xp'];
                $newLevel = $newData['level'];
                
                error_log("Updated student XP: User=$userId, OldExamXP={$currentXP['exam_xp']}, NewExamXP=$newExamXP, TotalXP=$newTotalXP, Level=$newLevel");
            } else {
                // ایجاد رکورد جدید XP (total_xp و level خودکار توسط MySQL محاسبه می‌شوند)
                $stmt = $conn->prepare("
                    INSERT INTO student_xp (student_id, exam_xp, updated_at) 
                    VALUES (?, ?, NOW())
                ");
                $stmt->execute([$userId, $earnedXP]);
                
                // دریافت مقادیر محاسبه شده توسط MySQL
                $stmt = $conn->prepare("SELECT total_xp, level FROM student_xp WHERE student_id = ?");
                $stmt->execute([$userId]);
                $newData = $stmt->fetch(PDO::FETCH_ASSOC);
                $newTotalXP = $newData['total_xp'];
                $newLevel = $newData['level'];
                
                error_log("Created new student XP: User=$userId, ExamXP=$earnedXP, TotalXP=$newTotalXP, Level=$newLevel");
            }
            
            // ثبت تاریخچه XP
            $xpSubject = "آزمون";
            $xpReason = "کسب $earnedXP امتیاز از آزمون «{$exam['title']}» با نمره $score از $totalScore ($percentage%)";
            
            $stmt = $conn->prepare("
                INSERT INTO xp_history (student_id, amount, subject, reason, admin_id, created_at) 
                VALUES (?, ?, ?, ?, NULL, NOW())
            ");
            $stmt->execute([$userId, $earnedXP, $xpSubject, $xpReason]);
            
            error_log("XP history recorded: User=$userId, Amount=$earnedXP, Subject='$xpSubject'");
        }
        
        // تایید تراکنش
        $conn->commit();
        
        error_log("=== EXAM SUBMISSION SUCCESS ===");
        
        // پاسخ موفق
        echo json_encode([
            'success' => true,
            'message' => 'آزمون با موفقیت ارسال شد',
            'score' => $score,
            'total_score' => $totalScore,
            'percentage' => $percentage,
            'accuracy' => $accuracy,
            'correct_answers' => $correctAnswers,
            'total_questions' => count($questions),
            'time_taken' => $timeTaken,
            'xp_earned' => $earnedXP,
            'is_force_exit' => $isForceExit,
            'is_auto_submit' => $isAutoSubmit
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        // برگرداندن تراکنش در صورت خطا
        $conn->rollBack();
        error_log("Transaction rolled back: " . $e->getMessage());
        throw $e;
    }
    
} catch (PDOException $e) {
    error_log("=== DATABASE ERROR ===");
    error_log("Error Message: " . $e->getMessage());
    error_log("Error Code: " . $e->getCode());
    
    echo json_encode([
        'success' => false, 
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("=== GENERAL ERROR ===");
    error_log("Error: " . $e->getMessage());
    error_log("File: " . $e->getFile());
    error_log("Line: " . $e->getLine());
    
    echo json_encode([
        'success' => false, 
        'message' => 'خطا: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

/**
 * محاسبه XP بر اساس عملکرد در آزمون
 */
function calculateExamXP($score, $totalScore, $percentage, $timeTaken, $examDuration, $isForceExit) {
    // اگر خروج اجباری یا نمره صفر، XP = 0
    if ($isForceExit || $score <= 0 || $totalScore <= 0) {
        return 0;
    }
    
    // XP پایه بر اساس نمره (هر امتیاز = 10 XP)
    $baseXP = $score * 10;
    
    // بونوس بر اساس درصد نمره
    $performanceBonus = 0;
    if ($percentage >= 95) {
        $performanceBonus = $baseXP * 0.75;  // 75% بونوس برای عملکرد عالی
    } elseif ($percentage >= 90) {
        $performanceBonus = $baseXP * 0.50;  // 50% بونوس برای عملکرد خیلی خوب
    } elseif ($percentage >= 80) {
        $performanceBonus = $baseXP * 0.30;  // 30% بونوس برای عملکرد خوب
    } elseif ($percentage >= 70) {
        $performanceBonus = $baseXP * 0.15;  // 15% بونوس برای عملکرد قابل قبول
    }
    
    // بونوس زمان (اگر کمتر از 75% زمان آزمون صرف شده)
    $timeBonus = 0;
    if ($examDuration > 0) {
        $timeUsedPercentage = ($timeTaken / ($examDuration * 60)) * 100;  // تبدیل دقیقه به ثانیه
        if ($timeUsedPercentage <= 50) {
            $timeBonus = $baseXP * 0.25;  // 25% بونوس برای سرعت بالا
        } elseif ($timeUsedPercentage <= 75) {
            $timeBonus = $baseXP * 0.10;  // 10% بونوس برای سرعت متوسط
        }
    }
    
    // محاسبه XP نهایی
    $totalXP = $baseXP + $performanceBonus + $timeBonus;
    
    // حداقل XP برای شرکت در آزمون
    if ($totalXP < 5) {
        $totalXP = 5;
    }
    
    return round($totalXP);
}

?>