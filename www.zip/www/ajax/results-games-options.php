<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

try{
  $stmt = $conn->query("SELECT id, title FROM games WHERE is_active=1 ORDER BY created_at DESC");
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode(['success'=>true,'items'=>$items]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
