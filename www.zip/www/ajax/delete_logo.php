<?php
header('Content-Type: application/json; charset=utf-8');

// Allow cross-origin requests if needed
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$uploadDir = '../uploads/logos/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        // Try to get from POST data
        $input = $_POST;
    }
    
    if (isset($input['fileName']) && !empty($input['fileName'])) {
        $fileName = basename($input['fileName']); // Sanitize filename
        $filePath = $uploadDir . $fileName;
        
        // Security check - ensure file is in the logos directory
        $realPath = realpath($filePath);
        $realUploadDir = realpath($uploadDir);
        
        if ($realPath && strpos($realPath, $realUploadDir) === 0) {
            if (file_exists($filePath)) {
                if (unlink($filePath)) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'لوگو با موفقیت حذف شد.'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'خطا در حذف فایل.'
                    ]);
                }
            } else {
                // File doesn't exist, consider it as success
                echo json_encode([
                    'success' => true,
                    'message' => 'فایل قبلاً حذف شده است.'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'مسیر فایل نامعتبر است.'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'نام فایل مشخص نشده است.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'روش درخواست نامعتبر است.'
    ]);
}
?>
