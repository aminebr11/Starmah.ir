require_once __DIR__ . '/../config.php';


if (!isset($conn)) {
    echo json_encode(['success' => false, 'message' => 'اتصال به دیتابیس برقرار نشد']);
    exit;
}