<?php
/**
 * فایل: ajax/delete_all_game_results.php
 * وظیفه: حذف تمام نتایج بازی مرتبط با یک game_id مشخص از پایگاه داده.
 */

session_start();
require_once '../config.php';
require_once '../functions.php'; // اگر تابعی نیاز است

header('Content-Type: application/json; charset=utf-8');

// ۱. بررسی مجوز و سطح دسترسی
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}

// ۲. بررسی متد و دریافت داده
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد مجاز نیست'], JSON_UNESCAPED_UNICODE);
    exit;
}

// دریافت JSON ورودی
$data = json_decode(file_get_contents("php://input"), true);
$game_id = (int)($data['game_id'] ?? 0);

if ($game_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر است'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // ابتدا تعداد سوابق برای نمایش به کاربر را می‌شماریم (اختیاری)
    $countStmt = $conn->prepare("SELECT COUNT(*) FROM game_results WHERE game_id = :game_id");
    $countStmt->bindParam(':game_id', $game_id, PDO::PARAM_INT);
    $countStmt->execute();
    $deleted_count = $countStmt->fetchColumn();

    // ۳. اجرای کوئری حذف
    $deleteQuery = "DELETE FROM game_results WHERE game_id = :game_id";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_INT);
    $stmt->execute();
    
    // در این حالت همیشه true فرض می‌شود مگر اینکه خطایی در دیتابیس باشد
    echo json_encode([
        'success' => true, 
        'message' => 'تمام نتایج بازی با موفقیت حذف شدند',
        'deleted_count' => (int)$deleted_count
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    // خطای دیتابیس
    http_response_code(500);
    error_log("Database Error in delete_all_game_results.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای داخلی سرور هنگام حذف گروهی.'], JSON_UNESCAPED_UNICODE);
}
?>