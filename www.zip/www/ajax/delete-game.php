<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$gameId = intval($input['game_id'] ?? 0);

if (!$gameId) {
    echo json_encode(['success' => false, 'message' => 'ID بازی نامعتبر']);
    exit;
}

try {
    $conn->beginTransaction();
    
    // حذف نتایج بازی
    $stmt = $conn->prepare("DELETE FROM game_results WHERE game_id = ?");
    $stmt->execute([$gameId]);
    
    // حذف بازی
    $stmt = $conn->prepare("DELETE FROM games WHERE id = ?");
    $result = $stmt->execute([$gameId]);
    
    if ($result) {
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'بازی با موفقیت حذف شد']);
    } else {
        throw new Exception('خطا در حذف بازی');
    }
} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(['success' => false, 'message' => 'خطا: ' . $e->getMessage()]);
}
?>