<?php
ob_start();
session_start();
ob_clean();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    require_once '../config.php';
    
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (!isset($input['result_ids']) || !is_array($input['result_ids'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه‌های نتایج نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $resultIds = array_filter($input['result_ids'], 'is_numeric');
    $resultIds = array_map('intval', $resultIds);
    
    if (empty($resultIds)) {
        echo json_encode(['success' => false, 'message' => 'هیچ شناسه معتبری ارسال نشده'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (count($resultIds) > 1000) {
        echo json_encode(['success' => false, 'message' => 'تعداد نتایج انتخابی بیش از حد مجاز است'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // شروع تراکنش
    $conn->beginTransaction();
    
    try {
        // دریافت اطلاعات نتایج قبل از حذف (برای لاگ)
        $placeholders = str_repeat('?,', count($resultIds) - 1) . '?';
        $stmt = $conn->prepare("
            SELECT gr.id, u.username, g.title 
            FROM game_results gr
            LEFT JOIN users u ON gr.student_id = u.id
            LEFT JOIN games g ON gr.game_id = g.id
            WHERE gr.id IN ($placeholders)
        ");
        $stmt->execute($resultIds);
        $existingResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($existingResults)) {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'هیچ نتیجه‌ای برای حذف یافت نشد'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        
        // حذف نتایج
        $stmt = $conn->prepare("DELETE FROM game_results WHERE id IN ($placeholders)");
        $stmt->execute($resultIds);
        $deletedCount = $stmt->rowCount();
        
        // تایید تراکنش
        $conn->commit();
        
        // ثبت لاگ
        $resultTitles = array_map(function($r) { 
            return "ID:{$r['id']} User:{$r['username']} Game:{$r['title']}"; 
        }, $existingResults);
        
        error_log("Admin {$_SESSION['user_id']} bulk deleted {$deletedCount} results: " . implode(', ', $resultTitles));
        
        echo json_encode([
            'success' => true,
            'message' => "{$deletedCount} نتیجه با موفقیت حذف شد",
            'deleted_count' => $deletedCount,
            'requested_count' => count($resultIds)
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Error in bulk_delete_results.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سرور در حذف گروهی'], JSON_UNESCAPED_UNICODE);
}
?>