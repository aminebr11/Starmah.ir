<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$q = trim($_GET['q'] ?? '');
if ($q === '') { echo json_encode(['success'=>true,'items'=>[]]); exit; }

try{
  $stmt = $conn->prepare("
    SELECT id, first_name, last_name, national_id
    FROM users
    WHERE user_type='student' AND (
      first_name LIKE ? OR last_name LIKE ? OR national_id LIKE ?
    )
    ORDER BY first_name, last_name
    LIMIT 50
  ");
  $like = "%$q%";
  $stmt->execute([$like,$like,$like]);
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode(['success'=>true,'items'=>$items]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
