<?php
// جلوگیری از خروجی اضافی
ob_start();

session_start();

// پاک کردن هر خروجی اضافی
ob_clean();

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit();
}

// تنظیم header
header('Content-Type: application/json; charset=utf-8');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    // بارگذاری config
    require_once '../config.php';
    
    // دریافت داده‌های JSON
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (!isset($input['game_id']) || !is_numeric($input['game_id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $gameId = (int)$input['game_id'];
    
    // بررسی وجود بازی
    $stmt = $conn->prepare("SELECT id, title FROM games WHERE id = ?");
    $stmt->execute([$gameId]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // شروع تراکنش برای حذف ایمن
    $conn->beginTransaction();
    
    try {
        // ابتدا نتایج مربوط به بازی را حذف کنیم
        $stmt = $conn->prepare("DELETE FROM game_results WHERE game_id = ?");
        $stmt->execute([$gameId]);
        $deleted_results = $stmt->rowCount();
        
        // سپس خود بازی را حذف کنیم
        $stmt = $conn->prepare("DELETE FROM games WHERE id = ?");
        $stmt->execute([$gameId]);
        $deleted_game = $stmt->rowCount();
        
        if ($deleted_game > 0) {
            // تائید تراکنش
            $conn->commit();
            
            echo json_encode([
                'success' => true,
                'message' => "بازی \"{$game['title']}\" و {$deleted_results} نتیجه مربوط به آن با موفقیت حذف شد",
                'deleted_game_id' => $gameId,
                'deleted_results_count' => $deleted_results
            ], JSON_UNESCAPED_UNICODE);
            
        } else {
            // برگشت تراکنش
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'بازی حذف نشد'], JSON_UNESCAPED_UNICODE);
        }
        
    } catch (Exception $e) {
        // برگشت تراکنش در صورت خطا
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطای سرور: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

// پایان
exit();
?>