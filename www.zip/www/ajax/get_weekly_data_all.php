<?php
session_start();
require_once '../config.php';

// تنظیم هدر JSON
header('Content-Type: application/json; charset=utf-8');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit;
}

$monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
               'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

try {
    // ===== حالت دریافت لیست ماه‌ها =====
    if (isset($_GET['mode']) && $_GET['mode'] === 'get_months') {
        $year = (int)($_GET['year'] ?? 0);
        
        if ($year === 0) {
            throw new Exception("سال نامعتبر است.");
        }
        
        $stmt = $conn->prepare("
            SELECT DISTINCT month 
            FROM weekly_xp_summary 
            WHERE year = ? 
            ORDER BY month ASC
        ");
        $stmt->execute([$year]);
        $months = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $result = [];
        foreach ($months as $m) {
            $monthIndex = (int)$m;
            if ($monthIndex >= 1 && $monthIndex <= 12) {
                $result[] = [
                    'value' => $monthIndex, 
                    'label' => $monthNames[$monthIndex]
                ];
            }
        }
        
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // ===== حالت دریافت لیست هفته‌ها =====
    if (isset($_GET['mode']) && $_GET['mode'] === 'get_weeks') {
        $year = (int)($_GET['year'] ?? 0);
        $month = (int)($_GET['month'] ?? 0);
        
        if ($year === 0 || $month === 0) {
            throw new Exception("پارامترهای نامعتبر.");
        }
        
        $stmt = $conn->prepare("
            SELECT DISTINCT week_number, week_start_date 
            FROM weekly_xp_summary 
            WHERE year = ? AND month = ? 
            GROUP BY week_number, week_start_date
            ORDER BY week_number DESC
        ");
        $stmt->execute([$year, $month]);
        $weeks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $result = [];
        foreach ($weeks as $w) {
            $result[] = [
                'value' => "{$year}-{$month}-{$w['week_number']}", 
                'label' => "هفته {$w['week_number']}"
            ];
        }
        
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // ===== حالت اصلی دریافت داده‌های تحلیل =====
    $type = $_GET['type'] ?? 'weekly';
    
    // ساخت کوئری بر اساس نوع فیلتر
    $params = [];
    $sql = "";
    
    switch ($type) {
        case 'overall':
            // برای نمایش کلی، تمام امتیازات دانش‌آموز را جمع می‌زنیم
            $sql = "
                SELECT 
                    u.id as student_id, 
                    u.first_name, 
                    u.last_name, 
                    COALESCE(SUM(w.total_xp), 0) AS total_xp
                FROM users u
                LEFT JOIN weekly_xp_summary w ON u.id = w.student_id
                WHERE u.user_type = 'student' AND u.is_active = 1
                GROUP BY u.id, u.first_name, u.last_name
                ORDER BY total_xp DESC
            ";
            break;
            
        case 'yearly':
            $year = (int)($_GET['year'] ?? 0);
            
            if ($year === 0) {
                throw new Exception("سال برای فیلتر سالانه الزامی است.");
            }
            
            $sql = "
                SELECT 
                    u.id as student_id, 
                    u.first_name, 
                    u.last_name, 
                    COALESCE(SUM(w.total_xp), 0) AS total_xp
                FROM users u
                LEFT JOIN weekly_xp_summary w ON u.id = w.student_id AND w.year = :year
                WHERE u.user_type = 'student' AND u.is_active = 1
                GROUP BY u.id, u.first_name, u.last_name
                ORDER BY total_xp DESC
            ";
            $params[':year'] = $year;
            break;
            
        case 'monthly':
            $year = (int)($_GET['year'] ?? 0);
            $month = (int)($_GET['month'] ?? 0);
            
            if ($year === 0 || $month === 0) {
                throw new Exception("سال و ماه برای فیلتر ماهانه الزامی است.");
            }
            
            $sql = "
                SELECT 
                    u.id as student_id, 
                    u.first_name, 
                    u.last_name, 
                    COALESCE(SUM(w.total_xp), 0) AS total_xp
                FROM users u
                LEFT JOIN weekly_xp_summary w ON u.id = w.student_id 
                    AND w.year = :year AND w.month = :month
                WHERE u.user_type = 'student' AND u.is_active = 1
                GROUP BY u.id, u.first_name, u.last_name
                ORDER BY total_xp DESC
            ";
            $params[':year'] = $year;
            $params[':month'] = $month;
            break;
            
        case 'weekly':
            $weekValue = $_GET['week'] ?? '';
            
            if (empty($weekValue)) {
                throw new Exception("هفته انتخاب نشده است.");
            }
            
            if (!preg_match('/^(\d+)-(\d+)-(\d+)$/', $weekValue, $matches)) {
                throw new Exception("فرمت هفته نامعتبر است: {$weekValue}");
            }
            
            $year = (int)$matches[1];
            $month = (int)$matches[2];
            $week = (int)$matches[3];
            
            $sql = "
                SELECT 
                    u.id as student_id, 
                    u.first_name, 
                    u.last_name, 
                    COALESCE(w.total_xp, 0) AS total_xp,
                    w.`rank`
                FROM users u
                LEFT JOIN weekly_xp_summary w ON u.id = w.student_id 
                    AND w.year = :year AND w.month = :month AND w.week_number = :week
                WHERE u.user_type = 'student' AND u.is_active = 1
                ORDER BY total_xp DESC
            ";
            $params[':year'] = $year;
            $params[':month'] = $month;
            $params[':week'] = $week;
            break;
            
        default:
            throw new Exception("نوع فیلتر نامعتبر است: {$type}");
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل مقادیر عددی به رشته برای JSON
    foreach ($students as &$student) {
        $student['total_xp'] = (string)$student['total_xp'];
        if (isset($student['rank'])) {
            $student['rank'] = (string)$student['rank'];
        }
    }
    
    echo json_encode([
        'success' => true, 
        'data' => $students,
        'count' => count($students),
        'type' => $type,
        'params' => $_GET
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage(),
        'params' => $_GET
    ], JSON_UNESCAPED_UNICODE);
}
?>