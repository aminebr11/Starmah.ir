<?php
ob_start();
session_start();
ob_clean();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    require_once '../config.php';
    
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (!isset($input['result_id']) || !is_numeric($input['result_id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه نتیجه نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $resultId = (int)$input['result_id'];
    
    // بررسی وجود نتیجه
    $stmt = $conn->prepare("
        SELECT gr.id, u.username, g.title 
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        LEFT JOIN games g ON gr.game_id = g.id
        WHERE gr.id = ?
    ");
    $stmt->execute([$resultId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'نتیجه یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // حذف نتیجه
    $stmt = $conn->prepare("DELETE FROM game_results WHERE id = ?");
    $success = $stmt->execute([$resultId]);
    
    if ($success && $stmt->rowCount() > 0) {
        // ثبت لاگ
        error_log("Admin {$_SESSION['user_id']} deleted result {$resultId} - User: {$result['username']}, Game: {$result['title']}");
        
        echo json_encode([
            'success' => true,
            'message' => 'نتیجه با موفقیت حذف شد',
            'deleted_result_id' => $resultId
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در حذف نتیجه'], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    error_log("Error in delete_result.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سرور'], JSON_UNESCAPED_UNICODE);
}
?>