<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Check if admin is logged in
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // Get all students with complete details
    $stmt = $conn->prepare("
        SELECT u.*, s.total_score, s.weekly_stars, s.class_rank 
        FROM users u 
        LEFT JOIN students s ON u.id = s.user_id 
        WHERE u.user_type = 'student' 
        ORDER BY s.class_rank ASC, s.total_score DESC, u.first_name ASC
    ");
    $stmt->execute();
    
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($students) {
        // Format data for printing
        $formattedStudents = [];
        foreach ($students as $student) {
            $formattedStudents[] = [
                'id' => $student['id'],
                'username' => $student['username'],
                'first_name' => $student['first_name'],
                'last_name' => $student['last_name'],
                'email' => $student['email'] ?? '',
                'national_id' => $student['national_id'],
                'birth_date' => $student['birth_date'] ?? '',
                'address' => $student['address'] ?? '',
                'father_name' => $student['father_name'] ?? '',
                'father_phone' => $student['father_phone'] ?? '',
                'mother_name' => $student['mother_name'] ?? '',
                'mother_phone' => $student['mother_phone'] ?? '',
                'is_active' => (bool)$student['is_active'],
                'total_score' => $student['total_score'] ?? 0,
                'weekly_stars' => $student['weekly_stars'] ?? 0,
                'class_rank' => $student['class_rank'] ?? 0,
                'created_at' => $student['created_at'] ?? '',
                'last_login' => $student['last_login'] ?? ''
            ];
        }
        
        echo json_encode([
            'success' => true, 
            'students' => $formattedStudents,
            'total_count' => count($formattedStudents)
        ]);
    } else {
        echo json_encode([
            'success' => true, 
            'students' => [],
            'total_count' => 0
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Database error in get-all-students: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای پایگاه داده.']);
} catch (Exception $e) {
    error_log("General error in get-all-students: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سیستم.']);
}
?>