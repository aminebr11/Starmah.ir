<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$idsJson = $_POST['ids'] ?? '[]';
$ids = json_decode($idsJson, true);
if (!is_array($ids) || empty($ids)) { echo json_encode(['success'=>false,'message'=>'لیست خالی']); exit; }

$ids = array_values(array_filter(array_map('intval',$ids)));
if (empty($ids)) { echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit; }

try{
  $in = implode(',', array_fill(0, count($ids), '?'));
  $stmt = $conn->prepare("DELETE FROM game_results WHERE id IN ($in)");
  $ok = $stmt->execute($ids);
  echo json_encode(['success'=>true,'deleted'=>$stmt->rowCount()]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
