<?php
// ajax/feedback-respond.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'Forbidden']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$feedbackId = (int)($input['id'] ?? 0);
$body       = trim($input['body'] ?? '');

if ($feedbackId<=0 || $body==='') {
  echo json_encode(['success'=>false,'message'=>'Invalid input']); exit;
}

try {
  $conn->beginTransaction();

  // درج پیام معلم
  $ins = $conn->prepare("
    INSERT INTO feedback_messages (feedback_id, sender_role, body, seen_by_student, created_at)
    VALUES (?, 'teacher', ?, 0, NOW())
  ");
  $ins->execute([$feedbackId, $body]);

  // تغییر وضعیت گفتگو به پاسخ‌داده‌شده
  $upd = $conn->prepare("UPDATE feedbacks SET status='responded', updated_at=NOW() WHERE id=?");
  $upd->execute([$feedbackId]);

  $conn->commit();
  echo json_encode(['success'=>true]);
} catch (Throwable $e) {
  if ($conn->inTransaction()) $conn->rollBack();
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
