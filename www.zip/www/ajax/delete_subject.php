<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

$config_loaded = false;
$functions_loaded = false;

$config_paths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$functions_paths = ['../functions.php', '../../functions.php', dirname(__DIR__) . '/functions.php'];

foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

foreach ($functions_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functions_loaded = true;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!$config_loaded || !$functions_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری فایل‌های سیستمی']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفا ابتدا وارد شوید']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $subject = $input['subject'] ?? '';
    
    if (empty($subject)) {
        throw new Exception('نام درس مشخص نشده است');
    }
    
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("DELETE FROM exam_questions WHERE subject = ? AND teacher_id = ?");
    $stmt->execute([$subject, $teacher_id]);
    
    $affected = $stmt->rowCount();
    
    echo json_encode([
        'success' => true,
        'message' => "$affected سوال حذف شد"
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
