<?php
// جلوگیری از خروجی اضافی
ob_start();

session_start();

// پاک کردن هر خروجی اضافی
ob_clean();

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز'], JSON_UNESCAPED_UNICODE);
    exit();
}

// تنظیم header
header('Content-Type: application/json; charset=utf-8');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    // بارگذاری config
    require_once '../config.php';
    
    // دریافت داده‌های JSON
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (!isset($input['game_id']) || !is_numeric($input['game_id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه بازی نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    $gameId = (int)$input['game_id'];
    
    // بررسی وجود بازی
    $stmt = $conn->prepare("SELECT id, is_active, title FROM games WHERE id = ?");
    $stmt->execute([$gameId]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // تغییر وضعیت
    $newStatus = $game['is_active'] ? 0 : 1;
    
    $stmt = $conn->prepare("UPDATE games SET is_active = ? WHERE id = ?");
    $result = $stmt->execute([$newStatus, $gameId]);
    
    if ($result) {
        $statusText = $newStatus ? 'فعال' : 'غیرفعال';
        echo json_encode([
            'success' => true,
            'message' => "وضعیت بازی با موفقیت به {$statusText} تغییر کرد",
            'new_status' => (bool)$newStatus,
            'game_id' => $gameId
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی وضعیت'], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطای سرور: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

// پایان
exit();
?>