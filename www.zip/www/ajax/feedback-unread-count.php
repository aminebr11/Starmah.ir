<?php
// ajax/feedback-unread-count.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (!isLoggedIn()) {
  echo json_encode(['success' => false, 'message' => 'Unauthorized']); exit;
}

$studentId = (int)($_SESSION['user_id'] ?? 0);
if ($studentId <= 0) {
  echo json_encode(['success' => false, 'message' => 'Invalid user']); exit;
}

try {
  // اطمینان از وجود ستون (فقط یکبار اضافه می‌شود)
  $check = $conn->prepare("
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
      AND table_name = 'feedback_messages'
      AND column_name = 'seen_by_student'
  ");
  $check->execute();
  $exists = (int)$check->fetchColumn() > 0;

  if (!$exists) {
    $conn->exec("
      ALTER TABLE feedback_messages
        ADD COLUMN seen_by_student TINYINT(1) NOT NULL DEFAULT 0,
        ADD INDEX idx_seen_by_student (seen_by_student)
    ");
  }

  // شمارش پیام‌های «معلم» که هنوز توسط همین دانش‌آموز دیده نشده
  $stmt = $conn->prepare("
    SELECT COUNT(*)
    FROM feedback_messages fm
    JOIN feedbacks f ON f.id = fm.feedback_id
    WHERE f.student_id = ?
      AND fm.sender_role = 'teacher'
      AND fm.seen_by_student = 0
  ");
  $stmt->execute([$studentId]);
  $count = (int)$stmt->fetchColumn();

  echo json_encode(['success' => true, 'count' => $count]);
} catch (Throwable $e) {
  echo json_encode(['success' => false, 'message' => 'DB Error', 'error' => $e->getMessage()]);
}
