<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once '../config.php';
require_once '../functions.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode([
        'success' => false, 
        'message' => 'دسترسی غیرمجاز'
    ]);
    exit();
}

try {
    // دریافت داده‌های JSON
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('خطا در پردازش داده‌های ورودی');
    }
    
    if (!isset($data['student_id']) || empty($data['student_id'])) {
        throw new Exception('شناسه دانش‌آموز ارسال نشده است');
    }
    
    $studentId = intval($data['student_id']);
    
    // بررسی وجود دانش‌آموز
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$studentId]);
    
    if (!$checkStmt->fetch()) {
        throw new Exception('دانش‌آموز مورد نظر یافت نشد');
    }
    
    // ساخت کوئری به صورت پویا
    $updateFields = [];
    $params = [];
    
    // فیلدهای قابل بروزرسانی (بدون رمز عبور)
    $allowedFields = [
        'username' => 'نام کاربری',
        'first_name' => 'نام',
        'last_name' => 'نام خانوادگی',
        'national_id' => 'کد ملی',
        'birth_date' => 'تاریخ تولد',
        'father_name' => 'نام پدر',
        'father_phone' => 'تلفن پدر',
        'mother_name' => 'نام مادر',
        'mother_phone' => 'تلفن مادر',
        'address' => 'آدرس',
        'is_active' => 'وضعیت'
    ];
    
    foreach ($allowedFields as $field => $label) {
        if (isset($data[$field])) {
            $value = trim($data[$field]);
            
            // مدیریت فیلدهای خالی
            if ($value === '' && in_array($field, ['birth_date', 'father_name', 'father_phone', 'mother_name', 'mother_phone', 'address'])) {
                $updateFields[] = "$field = NULL";
            } else if ($value !== '') {
                $updateFields[] = "$field = ?";
                $params[] = $value;
            }
        }
    }
    
    // بررسی و بروزرسانی رمز عبور (بدون محدودیت طول)
    if (isset($data['password']) && !empty(trim($data['password']))) {
        $newPassword = trim($data['password']);
        
        // هش کردن رمز عبور
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        $updateFields[] = "password = ?";
        $params[] = $hashedPassword;
    }
    
    if (empty($updateFields)) {
        throw new Exception('هیچ فیلدی برای بروزرسانی ارسال نشده است');
    }
    
    // افزودن ID به پارامترها
    $params[] = $studentId;
    
    // ساخت و اجرای کوئری
    $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    
    if ($stmt->execute($params)) {
        // بررسی تعداد ردیف‌های تغییر یافته
        if ($stmt->rowCount() > 0) {
            echo json_encode([
                'success' => true, 
                'message' => '✅ اطلاعات دانش‌آموز با موفقیت بروزرسانی شد'
            ]);
        } else {
            echo json_encode([
                'success' => true, 
                'message' => 'ℹ️ هیچ تغییری در اطلاعات ایجاد نشد (داده‌ها یکسان بودند)'
            ]);
        }
    } else {
        throw new Exception('خطا در اجرای کوئری بروزرسانی');
    }
    
} catch (PDOException $e) {
    error_log("Database Error in update_student.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in update_student.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>