<?php
header('Content-Type: application/json; charset=utf-8'); 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Check if request is AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden access']);
    exit;
}

// Start session and include necessary files
session_start();

// Try different paths for config files
$config_paths = [
    '../config/database.php',
    '../config.php',
    'config/database.php',
    'config.php'
];

$auth_paths = [
    '../includes/auth.php',
    '../functions.php',
    'includes/auth.php',
    'functions.php'
];

$conn = null;
$config_loaded = false;

// Load database config
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

if (!$config_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری تنظیمات پایگاه داده']);
    exit;
}

// Load auth functions
$auth_loaded = false;
foreach ($auth_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $auth_loaded = true;
        break;
    }
}

if (!$auth_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری تنظیمات احراز هویت']);
    exit;
}

// Check if user is admin
if (!function_exists('isAdmin') || !isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['student_id']) || !is_numeric($input['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است']);
    exit;
}

$student_id = intval($input['student_id']);

try {
    // Get student information
    $stmt = $conn->prepare("
        SELECT u.*, s.total_score, s.weekly_stars, s.class_rank 
        FROM users u 
        LEFT JOIN students s ON u.id = s.user_id 
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit;
    }
    
    // Remove sensitive information
    unset($student['password']);
    
    // Format date for display
    if ($student['birth_date']) {
        $student['birth_date'] = date('Y-m-d', strtotime($student['birth_date']));
    }
    
    if ($student['created_at']) {
        $student['created_at'] = date('Y-m-d H:i', strtotime($student['created_at']));
    }
    
    echo json_encode([
        'success' => true, 
        'student' => $student,
        'message' => 'اطلاعات دانش‌آموز با موفقیت دریافت شد'
    ]);
    
} catch (Exception $e) {
    error_log("Get student error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطای سرور در دریافت اطلاعات'
    ]);
}
?>