<?php
// ajax/gallery-delete.php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn() || !isAdmin()) { echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$id = (int)($input['id'] ?? 0);
if ($id<=0) { echo json_encode(['success'=>false,'message'=>'Invalid id']); exit; }

try {
  $st = $conn->prepare("SELECT file_path FROM gallery WHERE id=?");
  $st->execute([$id]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if (!$row) { echo json_encode(['success'=>false,'message'=>'Not found']); exit; }

  $conn->beginTransaction();
  $conn->prepare("DELETE FROM gallery WHERE id=?")->execute([$id]);
  $conn->commit();

  // حذف فایل (اختیاری ولی توصیه می‌شود)
  if (!empty($row['file_path'])) {
    $abs = realpath(__DIR__ . '/../' . $row['file_path']);
    if ($abs && is_file($abs)) { @unlink($abs); }
  }

  echo json_encode(['success'=>true]);
} catch (Throwable $e) {
  if ($conn->inTransaction()) $conn->rollBack();
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
