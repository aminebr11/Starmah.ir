<?php
// ajax/student-progress.php - گزارش پیشرفت دانش‌آموز
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn() || $userType !== 'student') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$student_id = $_SESSION['user_id'];

try {
    // دریافت آمار کلی
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_games_played,
            AVG(score) as avg_score,
            SUM(CASE WHEN score >= 80 THEN 1 ELSE 0 END) as high_scores,
            AVG(accuracy) as avg_accuracy,
            AVG(time_spent) as avg_time
        FROM game_results 
        WHERE student_id = ?
    ");
    $stmt->execute([$student_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // دریافت آمار به تفکیک درس
    $stmt = $conn->prepare("
        SELECT 
            g.subject,
            COUNT(gr.id) as games_played,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        GROUP BY g.subject
    ");
    $stmt->execute([$student_id]);
    $by_subject = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // دریافت بازی‌های اخیر
    $stmt = $conn->prepare("
        SELECT g.title, gr.score, gr.accuracy, gr.completed_at
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        ORDER BY gr.completed_at DESC
        LIMIT 10
    ");
    $stmt->execute([$student_id]);
    $recent_games = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // دریافت نشان‌ها
    $stmt = $conn->prepare("
        SELECT b.name, b.description, b.icon, sb.earned_at
        FROM badges b
        JOIN student_badges sb ON b.id = sb.badge_id
        WHERE sb.student_id = ?
        ORDER BY sb.earned_at DESC
    ");
    $stmt->execute([$student_id]);
    $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'by_subject' => $by_subject,
        'recent_games' => $recent_games,
        'badges' => $badges
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت اطلاعات']);
}
?>