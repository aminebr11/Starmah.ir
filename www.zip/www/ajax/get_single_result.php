<?php
// File: ../ajax/get_single_result.php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

$result_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($result_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه نتیجه نامعتبر است']);
    exit();
}

try {
    // **کوئری نهایی و اصلاح شده بر اساس ساختار جدول users**
    // 1. به جدول `users` متصل می‌شویم.
    // 2. ستون‌های `first_name` و `last_name` را با یک فاصله به هم می‌چسبانیم.
    // 3. از COALESCE برای حالت‌های خاص که ممکن است کاربر حذف شده باشد، استفاده می‌کنیم.
    $stmt = $conn->prepare("
        SELECT 
            r.*, 
            COALESCE(TRIM(CONCAT(u.first_name, ' ', u.last_name)), CONCAT('کاربر ', r.student_id)) as student_name 
        FROM game_results r
        LEFT JOIN users u ON r.student_id = u.id
        WHERE r.id = :id
    ");
    $stmt->bindParam(':id', $result_id, PDO::PARAM_INT);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        // اطمینان از اینکه مقادیر null به درستی مدیریت می‌شوند
        $result['time_spent'] = $result['time_spent'] ?? 0;
        $result['attempts'] = $result['attempts'] ?? 1;

        echo json_encode(['success' => true, 'result' => $result]);
    } else {
        echo json_encode(['success' => false, 'message' => 'نتیجه یافت نشد']);
    }
    
} catch (Exception $e) {
    // برای دیباگ، می‌توانید خطای واقعی را در لاگ سرور ذخیره کنید
    // error_log("Error in get_single_result.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای داخلی سرور رخ داد.']);
}
?>