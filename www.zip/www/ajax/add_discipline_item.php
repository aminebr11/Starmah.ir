<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['title'], $input['score'])) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ناقص']);
    exit;
}

$title = trim($input['title']);
$score = intval($input['score']);

if (empty($title) || $score < 1 || $score > 50) {
    echo json_encode(['success' => false, 'message' => 'داده‌های نامعتبر']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO discipline_items (title, score, created_by, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$title, $score, $_SESSION['user_id']]);
    
    $newId = $conn->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'message' => 'مورد انضباطی با موفقیت اضافه شد',
        'id' => $newId
    ]);
    
} catch (Exception $e) {
    error_log("Add discipline item error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در ذخیره اطلاعات']);
}
?>