<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $conn->beginTransaction();
    
    $deletedCount = 0;
    $oldDate = date('Y-m-d', strtotime('-6 months'));
    
    // Clear old visits (older than 6 months)
    $stmt = $conn->prepare("DELETE FROM visits WHERE visit_date < ?");
    $stmt->execute([$oldDate]);
    $deletedCount += $stmt->rowCount();
    
    // Clear old games data (older than 6 months)
    $stmt = $conn->prepare("DELETE FROM games_played WHERE played_at < ?");
    $stmt->execute([$oldDate]);
    $deletedCount += $stmt->rowCount();
    
    // Clear old exercises (older than 6 months)
    $stmt = $conn->prepare("DELETE FROM exercises_completed WHERE completed_at < ?");
    $stmt->execute([$oldDate]);
    $deletedCount += $stmt->rowCount();
    
    // Clear archived feedbacks (older than 6 months)
    $stmt = $conn->prepare("DELETE FROM feedback WHERE status = 'archived' AND created_at < ?");
    $stmt->execute([$oldDate]);
    $deletedCount += $stmt->rowCount();
    
    // Clear old temporary files
    $tempDir = '../temp';
    if (file_exists($tempDir)) {
        $files = glob($tempDir . '/*');
        foreach($files as $file) {
            if(is_file($file) && filemtime($file) < strtotime('-1 day')) {
                unlink($file);
                $deletedCount++;
            }
        }
    }
    
    // Clear old backup files (keep last 10)
    $backupDir = '../backups';
    if (file_exists($backupDir)) {
        $files = glob($backupDir . '/*.sql');
        rsort($files); // Sort by newest first
        
        // Delete all but the last 10 backups
        for($i = 10; $i < count($files); $i++) {
            unlink($files[$i]);
            $deletedCount++;
        }
    }
    
    // Optimize tables
    $tables = ['visits', 'games_played', 'exercises_completed', 'feedback'];
    foreach($tables as $table) {
        $conn->exec("OPTIMIZE TABLE $table");
    }
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'داده‌های قدیمی با موفقیت پاکسازی شد',
        'deleted_count' => $deletedCount,
        'details' => [
            'cutoff_date' => convertToJalali($oldDate),
            'tables_optimized' => count($tables)
        ]
    ]);
    
} catch(Exception $e) {
    $conn->rollBack();
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پاکسازی: ' . $e->getMessage()
    ]);
}
?>