<?php
/**
 * ajax/feedback-create.php
 * - ذخیره بازخورد والدین
 * - موضوع‌ها با وایت‌لیست کامل
 * - subject_fa برای عنوان فارسی
 * - پاسخ اولیه (AI یا تمپلیت)
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
  echo json_encode(['success'=>false,'message'=>'Unauthorized']); 
  exit;
}

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  echo json_encode(['success'=>false,'message'=>'Method not allowed']); 
  exit;
}

/* ---- دریافت ورودی‌ها ---- */
$student_id      = (int)($_SESSION['user_id'] ?? 0);
$parent_relation = $_POST['parent_relation'] ?? '';
$parent_name     = trim($_POST['parent_name'] ?? '');
$parent_phone    = trim($_POST['parent_phone'] ?? '');
$subject         = $_POST['subject'] ?? '';
$subject_text    = trim($_POST['subject_text'] ?? '');
$message         = trim($_POST['message'] ?? '');

// لاگ برای دیباگ
error_log("Feedback Create - Subject: $subject, Subject_text: $subject_text");

$valid_subjects = ['academic','homework','attention','behavior','bullying','motivation','schedule','health','special','suggestion','complaint','technical','other'];
$valid_rel      = ['father','mother','guardian'];

// اعتبارسنجی
if ($student_id <= 0 ||
    !in_array($parent_relation, $valid_rel, true) ||
    $parent_name === '' ||
    !preg_match('/^0\d{10}$/', $parent_phone) ||
    $message === '' ||
    !in_array($subject, $valid_subjects, true)) {
  echo json_encode(['success'=>false,'message'=>'ورودی نامعتبر - لطفا همه فیلدها را پر کنید']); 
  exit;
}

// اگر موضوع other است و متن خالی است
if ($subject === 'other' && $subject_text === '') {
  $subject_text = 'موضوع دلخواه';
}

/* ---- مپ فارسی موضوعات ---- */
$subjectFaMap = [
  'academic'   => 'پیشرفت تحصیلی',
  'homework'   => 'تکالیف و برنامه‌ریزی',
  'attention'  => 'تمرکز/توجه',
  'behavior'   => 'رفتار و اخلاق',
  'bullying'   => 'تنمر/همسالان',
  'motivation' => 'انگیزه و اعتمادبه‌نفس',
  'schedule'   => 'زمان‌بندی/حضور',
  'health'     => 'سلامت/خواب/تغذیه',
  'special'    => 'نیازهای ویژه',
  'suggestion' => 'پیشنهاد',
  'complaint'  => 'شکایت/نگرانی',
  'technical'  => 'مشکل فنی',
  'other'      => 'موضوع دلخواه'
];

// تعیین متن فارسی موضوع
$subject_fa = ($subject === 'other')
  ? ($subject_text !== '' ? $subject_text : 'موضوع دلخواه')
  : ($subjectFaMap[$subject] ?? $subject);

/* ---- نام دانش‌آموز ---- */
$displayName = '';
if (!empty($_SESSION['first_name']) || !empty($_SESSION['last_name'])) {
  $displayName = trim(($_SESSION['first_name'] ?? '').' '.($_SESSION['last_name'] ?? ''));
} elseif (!empty($_SESSION['username'])) {
  $displayName = (string)$_SESSION['username'];
}

if ($displayName === '' && $student_id > 0) {
  try {
    $stmt = $conn->prepare("SELECT COALESCE(NULLIF(CONCAT(TRIM(first_name),' ',TRIM(last_name)),''), username) FROM users WHERE id=? LIMIT 1");
    $stmt->execute([$student_id]);
    $displayName = (string)($stmt->fetchColumn() ?: '');
  } catch (Throwable $e) { /* ignore */ }
}

/* ---- جلوگیری از ثبت تکراری نزدیک به هم ---- */
try {
  $chk = $conn->prepare("
    SELECT f.id
    FROM feedbacks f
    WHERE f.student_id=? AND f.parent_name=? AND f.parent_phone=? AND f.subject=? AND
          IFNULL(f.subject_text,'') = ? AND f.message=? AND f.created_at >= (NOW() - INTERVAL 2 MINUTE)
    ORDER BY f.id DESC LIMIT 1
  ");
  $chk->execute([$student_id, $parent_name, $parent_phone, $subject, $subject_text, $message]);
  $existId = (int)$chk->fetchColumn();
  
  if ($existId > 0) {
    $ms = $conn->prepare("SELECT body FROM feedback_messages WHERE feedback_id=? AND sender_role='ai' ORDER BY id ASC LIMIT 1");
    $ms->execute([$existId]);
    $prevAi = (string)$ms->fetchColumn();
    echo json_encode([
      'success' => true, 
      'ai_reply' => $prevAi, 
      'id' => $existId, 
      'subject_fa' => $subject_fa,
      'dedup' => true
    ], JSON_UNESCAPED_UNICODE); 
    exit;
  }
} catch (Throwable $e) { /* continue */ }

/* ---- توابع AI ---- */

// تمپلیت پاسخ پیش‌فرض
function template_reply_once(string $subject, string $parent_name): string {
  $bodyMap = [
    'academic'   => "موضوع پیشرفت تحصیلی دانش‌آموز بررسی می‌شود و بر اساس نقاط قوت و نیاز، برنامه تقویتی پیشنهاد خواهد شد.",
    'homework'   => "وضعیت تکالیف و تناسب حجم تمرین‌ها بررسی می‌شود تا توازن بین یادگیری و استراحت حفظ شود.",
    'attention'  => "برای بهبود تمرکز، راهکارهای عملی تنظیم و نتایج پیگیری می‌شود.",
    'behavior'   => "مسائل رفتاری بررسی و در صورت نیاز، برنامه حمایتی طراحی می‌شود.",
    'bullying'   => "موضوع تعامل با همسالان در اولویت بررسی است و با رعایت محرمانگی پیگیری می‌شود.",
    'motivation' => "عوامل انگیزشی دانش‌آموز شناسایی و راهکارهایی برای افزایش مشارکت ارائه می‌شود.",
    'schedule'   => "حضور و زمان‌بندی کلاس‌ها بررسی و اقدامات اصلاحی انجام خواهد شد.",
    'health'     => "با توجه به اهمیت سلامت در یادگیری، توصیه‌های لازم ارائه و پیگیری می‌شود.",
    'special'    => "نیازهای ویژه با دقت بررسی و برنامه آموزشی مناسب تدوین می‌گردد.",
    'suggestion' => "پیشنهاد شما ثبت شد و در جلسه آتی مطرح می‌شود.",
    'complaint'  => "نگرانی شما با اولویت بررسی و پاسخ مناسب ارائه می‌شود.",
    'technical'  => "مشکل فنی ثبت شد و با تیم پشتیبانی هماهنگ می‌شود.",
    'other'      => "پیام شما ثبت شد و پس از بررسی، پاسخ مناسب ارائه می‌شود."
  ];
  $body = $bodyMap[$subject] ?? $bodyMap['other'];
  return "ولی محترم {$parent_name}، از همراهی و اعتمادتان سپاسگزارم.\n{$body}\nنتیجه بررسی حداکثر تا 48 ساعت آینده اطلاع‌رسانی می‌شود.\n\n---\nنجمه محمودی | معلم و مشاور تحصیلی";
}

// تولید پاسخ با OpenAI (اختیاری)
function openai_teacher_reply_once(
  int $student_id, string $student_display, string $parent_relation, string $parent_name,
  string $parent_phone, string $subject_fa, string $message
) {
  if (!defined('OPENAI_API_KEY') || !OPENAI_API_KEY) return false;

  $system = "شما «نجمه محمودی»، معلم و مشاور تحصیلی باتجربه هستید. فقط به فارسی پاسخ بده.
- دقیقاً یک پاسخ کوتاه و حرفه‌ای (5 تا 7 جمله) بنویس.
- ساختار: تشکر از ولی محترم (با نام)، خلاصه موضوع، همدلی، 1-2 اقدام عملی، زمان پیگیری، امضا.";

  $user = "اطلاعات:
- دانش‌آموز: {$student_display}
- ولی: {$parent_name} ({$parent_relation})
- موضوع: {$subject_fa}
- پیام: {$message}";

  $payload = json_encode([
    'model' => 'gpt-4o-mini',
    'messages' => [
      ['role' => 'system', 'content' => $system],
      ['role' => 'user', 'content' => $user]
    ],
    'temperature' => 0.3,
    'max_tokens' => 320
  ], JSON_UNESCAPED_UNICODE);

  $ch = curl_init('https://api.openai.com/v1/chat/completions');
  curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json',
      'Authorization: Bearer ' . OPENAI_API_KEY
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 25,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload
  ]);
  
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($res === false || $code >= 400) return false;
  
  $j = json_decode($res, true);
  $txt = trim($j['choices'][0]['message']['content'] ?? '');
  return $txt ?: false;
}

// اعتبارسنجی پاسخ AI
function ai_is_valid(string $txt): bool {
  $txt = trim($txt);
  if ($txt === '') return false;
  if (!preg_match('/[\x{0600}-\x{06FF}]/u', $txt)) return false; // باید فارسی باشد
  if (mb_strlen($txt, 'UTF-8') < 40) return false;
  return true;
}

/* ---- ثبت در دیتابیس ---- */
try {
  $conn->beginTransaction();

  // 1) ثبت بازخورد (subject_text فقط برای other پر می‌شود)
  $sql = "INSERT INTO feedbacks (
    student_id, parent_name, parent_phone, parent_relation,
    subject, subject_text, message, status, created_at, updated_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())";
  
  $stmt = $conn->prepare($sql);
  $stmt->execute([
    $student_id, 
    $parent_name, 
    $parent_phone, 
    $parent_relation,
    $subject,
    ($subject === 'other' ? $subject_text : null),
    $message
  ]);
  
  $fid = (int)$conn->lastInsertId();
  
  // 1.1) آپدیت subject_fa (اگر ستون وجود دارد)
  try {
    $updateSql = "UPDATE feedbacks SET subject_fa = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->execute([$subject_fa, $fid]);
  } catch (Throwable $e) {
    error_log("Column subject_fa may not exist: ".$e->getMessage());
  }

  // 2) ثبت پیام «والد»
  $stmtMsg = $conn->prepare("INSERT INTO feedback_messages (feedback_id, sender_role, body, created_at) VALUES (?, 'parent', ?, NOW())");
  $stmtMsg->execute([$fid, $message]);

  // 3) پاسخ اولیه (AI یا تمپلیت)
  $ai = openai_teacher_reply_once(
    $student_id, ($displayName ?: 'دانش‌آموز'),
    $parent_relation, $parent_name, $parent_phone,
    $subject_fa, $message
  );
  if ($ai === false || !ai_is_valid($ai)) {
    $ai = template_reply_once($subject, $parent_name);
  }
  $stmtMsgAI = $conn->prepare("INSERT INTO feedback_messages (feedback_id, sender_role, body, seen_by_student, created_at) VALUES (?, 'ai', ?, 0, NOW())");
  $stmtMsgAI->execute([$fid, $ai]);

  $conn->commit();

  // (اختیاری) ایمیل اطلاع‌رسانی
  try {
    $q = $conn->prepare("SELECT email FROM users WHERE id=? LIMIT 1");
    $q->execute([$student_id]);
    $u = $q->fetch(PDO::FETCH_ASSOC);
    if ($u && !empty($u['email'])) {
      $to  = $u['email'];
      $sub = "بازخورد جدید ثبت شد";
      $html = "<div dir='rtl' style='font-family:Vazirmatn,Tahoma,Arial'>
        <h3>بازخورد جدید</h3>
        <p><strong>والد:</strong> {$parent_name}</p>
        <p><strong>موضوع:</strong> {$subject_fa}</p>
        <p><strong>پیام:</strong><br>".nl2br(htmlspecialchars($message))."</p>
        <hr>
        <p><strong>پاسخ اولیه:</strong><br>".nl2br(htmlspecialchars($ai))."</p>
      </div>";
      @mail(
        $to,
        "=?UTF-8?B?".base64_encode($sub)."?=",
        $html,
        "MIME-Version: 1.0\r\nContent-type:text/html; charset=UTF-8\r\n"
      );
    }
  } catch (Throwable $e) { /* optional */ }

  echo json_encode([
    'success'    => true,
    'ai_reply'   => $ai,
    'id'         => $fid,
    'subject'    => $subject,
    'subject_fa' => $subject_fa,
    'message'    => 'پیام شما با موفقیت ثبت شد'
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  if ($conn->inTransaction()) $conn->rollBack();
  error_log("Feedback create error: " . $e->getMessage());
  echo json_encode([
    'success' => false,
    'message' => 'خطا در ثبت پیام',
    'error'   => $e->getMessage()
  ], JSON_UNESCAPED_UNICODE);
}
