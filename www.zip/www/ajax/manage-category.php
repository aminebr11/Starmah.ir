<?php
// ajax/manage-category.php - مدیریت دسته‌بندی‌ها
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'create':
        $name = sanitize($_POST['name'] ?? '');
        $icon = sanitize($_POST['icon'] ?? '🎮');
        $color = sanitize($_POST['color'] ?? '#4d9de0');
        
        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'نام دسته‌بندی الزامی است']);
            exit;
        }
        
        try {
            $stmt = $conn->prepare("INSERT INTO game_categories (name, icon, color) VALUES (?, ?, ?)");
            $stmt->execute([$name, $icon, $color]);
            
            echo json_encode(['success' => true, 'message' => 'دسته‌بندی ایجاد شد', 'id' => $conn->lastInsertId()]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در ایجاد دسته‌بندی']);
        }
        break;
        
    case 'update':
        $id = (int)($_POST['id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $icon = sanitize($_POST['icon'] ?? '');
        $color = sanitize($_POST['color'] ?? '');
        
        if ($id <= 0 || empty($name)) {
            echo json_encode(['success' => false, 'message' => 'اطلاعات نامعتبر']);
            exit;
        }
        
        try {
            $stmt = $conn->prepare("UPDATE game_categories SET name = ?, icon = ?, color = ? WHERE id = ?");
            $stmt->execute([$name, $icon, $color, $id]);
            
            echo json_encode(['success' => true, 'message' => 'دسته‌بندی بروزرسانی شد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی']);
        }
        break;
        
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'شناسه نامعتبر']);
            exit;
        }
        
        try {
            // بررسی وجود بازی در این دسته‌بندی
            $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE category_id = ?");
            $stmt->execute([$id]);
            $game_count = $stmt->fetchColumn();
            
            if ($game_count > 0) {
                echo json_encode(['success' => false, 'message' => 'نمی‌توان دسته‌بندی حاوی بازی را حذف کرد']);
                exit;
            }
            
            $stmt = $conn->prepare("DELETE FROM game_categories WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'دسته‌بندی حذف شد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در حذف']);
        }
        break;
        
    case 'toggle':
        $id = (int)($_POST['id'] ?? 0);
        $status = (bool)($_POST['status'] ?? false);
        
        try {
            $stmt = $conn->prepare("UPDATE game_categories SET is_active = ? WHERE id = ?");
            $stmt->execute([$status ? 1 : 0, $id]);
            
            echo json_encode(['success' => true, 'message' => 'وضعیت تغییر کرد']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطا در تغییر وضعیت']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'عملیات نامعتبر']);
}
?>


