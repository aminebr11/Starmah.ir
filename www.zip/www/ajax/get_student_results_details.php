<?php
/**
 * فایل: ajax/get_student_results_details.php
 * دریافت تمام نتایج و آمار یک دانش‌آموز خاص
 */
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$student_id = (int)($_GET['student_id'] ?? 0);

if ($student_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است']);
    exit;
}

try {
    // اطلاعات پایه دانش‌آموز
    $studentQuery = "
        SELECT 
            id,
            COALESCE(
                NULLIF(TRIM(CONCAT(first_name, ' ', last_name)), ''), 
                username, 
                CONCAT('کاربر ', id)
            ) as full_name,
            username,
            national_id,
            class,
            created_at
        FROM users
        WHERE id = :student_id AND user_type = 'student'
    ";
    
    $stmt = $conn->prepare($studentQuery);
    $stmt->execute([':student_id' => $student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit;
    }
    
    // آمار کلی دانش‌آموز
    $statsQuery = "
        SELECT 
            COUNT(id) as total_games,
            ROUND(AVG(score), 1) as avg_score,
            MAX(score) as best_score,
            MIN(score) as worst_score,
            ROUND(AVG(accuracy), 1) as avg_accuracy,
            ROUND(AVG(time_spent), 0) as avg_time,
            SUM(attempts) as total_attempts
        FROM game_results
        WHERE student_id = :student_id
    ";
    
    $stmt_stats = $conn->prepare($statsQuery);
    $stmt_stats->execute([':student_id' => $student_id]);
    $stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
    
    // لیست تمام نتایج با جزئیات بازی
    $resultsQuery = "
        SELECT 
            gr.id,
            gr.game_id,
            g.title as game_title,
            gc.name as category_name,
            gc.color as category_color,
            gc.icon as category_icon,
            gr.score,
            gr.max_possible_score,
            gr.accuracy,
            gr.time_spent,
            gr.attempts,
            gr.completed_at
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE gr.student_id = :student_id
        ORDER BY gr.completed_at DESC
    ";
    
    $stmt_results = $conn->prepare($resultsQuery);
    $stmt_results->execute([':student_id' => $student_id]);
    $results = $stmt_results->fetchAll(PDO::FETCH_ASSOC);
    
    // آمار بر اساس دسته‌بندی
    $categoryStatsQuery = "
        SELECT 
            gc.name as category_name,
            gc.color as category_color,
            gc.icon as category_icon,
            COUNT(gr.id) as games_count,
            ROUND(AVG(gr.score), 1) as avg_score,
            ROUND(AVG(gr.accuracy), 1) as avg_accuracy
        FROM game_results gr
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE gr.student_id = :student_id
        GROUP BY gc.id, gc.name, gc.color, gc.icon
        ORDER BY games_count DESC
    ";
    
    $stmt_cat = $conn->prepare($categoryStatsQuery);
    $stmt_cat->execute([':student_id' => $student_id]);
    $categoryStats = $stmt_cat->fetchAll(PDO::FETCH_ASSOC);
    
    // پاسخ نهایی
    echo json_encode([
        'success' => true,
        'student' => $student,
        'stats' => $stats,
        'results' => $results,
        'categoryStats' => $categoryStats
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    error_log("Error in get_student_results_details.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سرور']);
}
?>