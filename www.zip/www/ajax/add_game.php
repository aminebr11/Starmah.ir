<?php
session_start();
require_once '../config.php';

// فعال‌سازی لاگ خطا برای دیباگ
error_reporting(E_ALL);
ini_set('log_errors', 1);

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

// بررسی متد درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد درخواست نامعتبر']);
    exit();
}

try {
    // لاگ داده‌های دریافتی
    error_log("Add Game Request - POST data: " . print_r($_POST, true));
    
    // اعتبارسنجی داده‌های ورودی
    $required_fields = ['title', 'category_id', 'game_code'];
    $missing_fields = [];
    
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $missing_fields[] = $field;
        }
    }
    
    if (!empty($missing_fields)) {
        echo json_encode([
            'success' => false,
            'message' => 'فیلدهای الزامی خالی هستند: ' . implode(', ', $missing_fields)
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // پاکسازی و اعتبارسنجی داده‌ها
    $title = trim($_POST['title']);
    $category_id = (int)$_POST['category_id'];
    $topic = trim($_POST['topic'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $instructions = trim($_POST['instructions'] ?? '');
    $estimated_time = (int)($_POST['estimated_time'] ?? 5);
    $game_code = trim($_POST['game_code']);
    
    // اعتبارسنجی اضافی
    if (strlen($title) < 3) {
        echo json_encode(['success' => false, 'message' => 'عنوان بازی باید حداقل ۳ کاراکتر باشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if ($category_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'درس انتخاب‌شده نامعتبر است'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if ($estimated_time < 1 || $estimated_time > 60) {
        echo json_encode(['success' => false, 'message' => 'زمان تقریبی باید بین ۱ تا ۶۰ دقیقه باشد'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    if (strlen($game_code) < 20) {
        echo json_encode(['success' => false, 'message' => 'کد بازی بیش از حد کوتاه است'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // بررسی وجود دسته‌بندی
    $stmt = $conn->prepare("SELECT id, name FROM game_categories WHERE id = :id AND is_active = 1");
    $stmt->execute([':id' => $category_id]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی انتخاب‌شده یافت نشد یا غیرفعال است'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // بررسی تکراری نبودن عنوان
    $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE title = :title");
    $stmt->execute([':title' => $title]);
    
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'بازی با این عنوان قبلاً ثبت شده است'], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    // درج بازی جدید - مطابق با ساختار جدول شما
    $sql = "
        INSERT INTO games (
            title, 
            description, 
            category_id, 
            subject, 
            difficulty, 
            topic, 
            estimated_time, 
            max_score, 
            game_code, 
            instructions, 
            is_active, 
            created_by
        ) VALUES (
            :title, 
            :description, 
            :category_id, 
            :subject, 
            :difficulty, 
            :topic, 
            :estimated_time, 
            :max_score, 
            :game_code, 
            :instructions, 
            1, 
            :created_by
        )
    ";
    
    $stmt = $conn->prepare($sql);
    
    $params = [
        ':title' => $title,
        ':description' => $description,
        ':category_id' => $category_id,
        ':subject' => $category['name'],
        ':difficulty' => 'medium', // مقدار پیش‌فرض
        ':topic' => $topic,
        ':estimated_time' => $estimated_time,
        ':max_score' => 100, // مقدار پیش‌فرض
        ':game_code' => $game_code,
        ':instructions' => $instructions,
        ':created_by' => $_SESSION['user_id']
    ];
    
    // لاگ پارامترها برای دیباگ
    error_log("Add Game SQL params: " . print_r($params, true));
    
    $result = $stmt->execute($params);
    
    if ($result) {
        $game_id = $conn->lastInsertId();
        
        // ثبت لاگ موفقیت
        error_log("Game added successfully by admin {$_SESSION['user_id']}: {$game_id} - '{$title}'");
        
        echo json_encode([
            'success' => true,
            'message' => 'بازی با موفقیت اضافه شد',
            'game_id' => $game_id,
            'game_title' => $title
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        // دریافت اطلاعات خطا
        $errorInfo = $stmt->errorInfo();
        error_log("SQL Error in add_game: " . print_r($errorInfo, true));
        
        echo json_encode([
            'success' => false, 
            'message' => 'خطا در ذخیره بازی در دیتابیس'
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (PDOException $e) {
    error_log("PDO Error in add_game: " . $e->getMessage());
    
    // بررسی خطای کلید تکراری
    if ($e->getCode() == 23000) {
        echo json_encode([
            'success' => false,
            'message' => 'بازی با این مشخصات قبلاً ثبت شده است'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'خطا در اتصال به پایگاه داده: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    error_log("General Error in add_game: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطای نامشخص رخ داد: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>