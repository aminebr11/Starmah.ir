<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تست مشکل صفحه آزمون</title>
    <style>
        body { font-family: Tahoma; padding: 20px; }
        .test-box { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { background: #d4edda; border-color: #c3e6cb; }
        .error { background: #f8d7da; border-color: #f5c6cb; }
        button { padding: 10px 20px; margin: 5px; background: #007bff; color: white; border: none; border-radius: 3px; cursor: pointer; }
        button:hover { background: #0056b3; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 300px; }
        .loading { color: #007bff; }
        .exam-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; display: none; }
        .exam-container { background: white; margin: 50px; padding: 20px; border-radius: 10px; }
        #console { background: #000; color: #0f0; font-family: monospace; padding: 10px; height: 200px; overflow-y: auto; }
    </style>
</head>
<body>

<h1>🔍 تست مشکل صفحه آزمون</h1>

<div class="test-box">
    <h3>📋 کنسول Debug</h3>
    <div id="console"></div>
    <button onclick="clearConsole()">پاک کردن کنسول</button>
</div>

<div class="test-box">
    <h3>1️⃣ تست بارگذاری آزمون</h3>
    <label>شناسه آزمون: <input type="number" id="examId" value="123" min="1"></label>
    <button onclick="testLoadExamDetailed()">تست بارگذاری مفصل</button>
    <div id="loadResult"></div>
</div>

<div class="test-box">
    <h3>2️⃣ تست نمایش Modal</h3>
    <button onclick="testShowModal()">تست نمایش صفحه آزمون</button>
    <button onclick="hideModal()">مخفی کردن صفحه آزمون</button>
    <div id="modalResult"></div>
</div>

<div class="test-box">
    <h3>3️⃣ تست عناصر DOM</h3>
    <button onclick="checkDOMElements()">بررسی عناصر صفحه</button>
    <div id="domResult"></div>
</div>

<div class="test-box">
    <h3>4️⃣ شبیه‌سازی کامل آزمون</h3>
    <button onclick="simulateExamStart()">شبیه‌سازی شروع آزمون</button>
    <div id="simulationResult"></div>
</div>

<!-- Modal صفحه آزمون برای تست -->
<div id="examInterface" class="exam-modal">
    <div class="exam-container">
        <h3 id="examTitle">عنوان آزمون تست</h3>
        <div>زمان باقی‌مانده: <span id="examTimer">15:00</span></div>
        <div>
            <span id="questionProgress">سوال 1 از 5</span>
            <div style="background: #ddd; height: 10px; border-radius: 5px;">
                <div id="examProgressBar" style="background: #007bff; height: 100%; width: 20%; border-radius: 5px;"></div>
            </div>
        </div>
        <div>
            <h4 id="currentQuestion">این یک سوال تست است؟</h4>
            <div id="questionOptions">
                <button class="option-btn">الف) گزینه اول</button>
                <button class="option-btn">ب) گزینه دوم</button>
                <button class="option-btn">ج) گزینه سوم</button>
            </div>
        </div>
        <div>
            <button onclick="hideModal()">❌ خروج</button>
        </div>
    </div>
</div>

<script>
// Console logger
function log(message) {
    const console = document.getElementById('console');
    const time = new Date().toLocaleTimeString();
    console.innerHTML += `[${time}] ${message}\n`;
    console.scrollTop = console.scrollHeight;
    console.log(message); // Also log to browser console
}

function clearConsole() {
    document.getElementById('console').innerHTML = '';
}

// Helper functions
function displayResult(elementId, success, message, data = null) {
    const element = document.getElementById(elementId);
    const className = success ? 'success' : 'error';
    const icon = success ? '✅' : '❌';
    
    let html = `<div class="${className}">
        <h4>${icon} ${message}</h4>
    `;
    
    if (data) {
        html += `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }
    
    html += '</div>';
    element.innerHTML = html;
}

function setLoading(elementId) {
    document.getElementById(elementId).innerHTML = '<div class="loading">⏳ در حال پردازش...</div>';
}

// تست 1: بارگذاری آزمون مفصل
function testLoadExamDetailed() {
    const examId = document.getElementById('examId').value;
    log(`🚀 شروع تست بارگذاری آزمون ${examId}`);
    setLoading('loadResult');
    
    fetch('/ajax/load_exam.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ exam_id: parseInt(examId) })
    })
    .then(response => {
        log(`📡 دریافت پاسخ HTTP: ${response.status}`);
        return response.text();
    })
    .then(text => {
        log(`📄 محتوای پاسخ (${text.length} کاراکتر): ${text.substring(0, 100)}...`);
        
        try {
            const data = JSON.parse(text);
            log(`✅ JSON پارس شد موفق`);
            
            if (data.success) {
                log(`🎉 آزمون بارگذاری شد: ${data.exam.title}`);
                log(`📚 تعداد سوالات: ${data.questions.length}`);
                
                if (data.questions.length > 0) {
                    log(`📝 نوع سوال اول: ${data.questions[0].question_type}`);
                    log(`💭 متن سوال اول: ${data.questions[0].question_text}`);
                }
                
                displayResult('loadResult', true, `آزمون "${data.exam.title}" بارگذاری شد`, {
                    exam_title: data.exam.title,
                    duration: data.exam.duration_minutes,
                    questions_count: data.questions.length,
                    first_question_type: data.questions[0]?.question_type || 'N/A'
                });
                
                // ذخیره در متغیر global برای تست‌های بعدی
                window.testExamData = data;
                
            } else {
                log(`❌ خطا در بارگذاری: ${data.message}`);
                displayResult('loadResult', false, 'خطا: ' + data.message, data);
            }
        } catch (e) {
            log(`💥 خطا در پارس JSON: ${e.message}`);
            displayResult('loadResult', false, 'خطا در پارس JSON: ' + e.message, {raw_response: text.substring(0, 500)});
        }
    })
    .catch(error => {
        log(`🔥 خطای شبکه: ${error.message}`);
        displayResult('loadResult', false, 'خطای شبکه: ' + error.message);
    });
}

// تست 2: نمایش Modal
function testShowModal() {
    log(`🖼️ تست نمایش Modal آزمون`);
    
    const modal = document.getElementById('examInterface');
    if (!modal) {
        log(`❌ Element با id 'examInterface' یافت نشد`);
        displayResult('modalResult', false, 'Modal element یافت نشد');
        return;
    }
    
    log(`✅ Modal element یافت شد`);
    modal.style.display = 'flex';
    log(`📺 Modal نمایش داده شد`);
    
    displayResult('modalResult', true, 'Modal با موفقیت نمایش داده شد');
}

function hideModal() {
    log(`🙈 مخفی کردن Modal`);
    const modal = document.getElementById('examInterface');
    if (modal) {
        modal.style.display = 'none';
        log(`✅ Modal مخفی شد`);
    }
}

// تست 3: بررسی عناصر DOM
function checkDOMElements() {
    log(`🔍 بررسی عناصر DOM آزمون`);
    
    const elements = [
        'examInterface',
        'examTitle', 
        'examTimer',
        'questionProgress',
        'examProgressBar',
        'currentQuestion',
        'questionOptions'
    ];
    
    let results = {};
    let allFound = true;
    
    elements.forEach(id => {
        const element = document.getElementById(id);
        const exists = element !== null;
        results[id] = exists;
        
        if (exists) {
            log(`✅ ${id}: موجود`);
        } else {
            log(`❌ ${id}: یافت نشد`);
            allFound = false;
        }
    });
    
    if (allFound) {
        displayResult('domResult', true, 'همه عناصر DOM موجود هستند', results);
    } else {
        displayResult('domResult', false, 'برخی عناصر DOM یافت نشدند', results);
    }
}

// تست 4: شبیه‌سازی کامل شروع آزمون
function simulateExamStart() {
    log(`🎭 شروع شبیه‌سازی کامل آزمون`);
    setLoading('simulationResult');
    
    // مرحله 1: بررسی وجود داده آزمون
    if (!window.testExamData) {
        log(`❌ داده آزمون موجود نیست - ابتدا تست بارگذاری را انجام دهید`);
        displayResult('simulationResult', false, 'ابتدا آزمون را بارگذاری کنید');
        return;
    }
    
    log(`✅ داده آزمون موجود است`);
    const exam = window.testExamData.exam;
    const questions = window.testExamData.questions;
    
    // مرحله 2: تنظیم اطلاعات آزمون
    try {
        document.getElementById('examTitle').textContent = exam.title;
        log(`✅ عنوان آزمون تنظیم شد: ${exam.title}`);
        
        // مرحله 3: تنظیم تایمر
        const timeLeft = exam.duration_minutes * 60;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        document.getElementById('examTimer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        log(`✅ تایمر تنظیم شد: ${minutes}:${seconds.toString().padStart(2, '0')}`);
        
        // مرحله 4: بارگذاری اولین سوال
        if (questions.length > 0) {
            const firstQuestion = questions[0];
            document.getElementById('currentQuestion').textContent = firstQuestion.question_text;
            log(`✅ سوال اول بارگذاری شد: ${firstQuestion.question_text.substring(0, 50)}...`);
            
            // بارگذاری گزینه‌ها
            const optionsContainer = document.getElementById('questionOptions');
            optionsContainer.innerHTML = '';
            
            if (firstQuestion.question_type === 'mcq') {
                const questionData = JSON.parse(firstQuestion.question_data || '{}');
                const options = questionData.options || [];
                
                options.forEach((option, index) => {
                    const btn = document.createElement('button');
                    btn.className = 'option-btn';
                    btn.textContent = `${String.fromCharCode(65 + index)}) ${option.text || option}`;
                    btn.style.display = 'block';
                    btn.style.width = '100%';
                    btn.style.margin = '5px 0';
                    btn.style.padding = '10px';
                    btn.style.textAlign = 'right';
                    optionsContainer.appendChild(btn);
                });
                
                log(`✅ ${options.length} گزینه بارگذاری شد`);
            } else if (firstQuestion.question_type === 'tf') {
                const trueBtn = document.createElement('button');
                trueBtn.textContent = '✅ درست';
                trueBtn.style.display = 'block';
                trueBtn.style.width = '100%';
                trueBtn.style.margin = '5px 0';
                trueBtn.style.padding = '10px';
                
                const falseBtn = document.createElement('button');
                falseBtn.textContent = '❌ نادرست';
                falseBtn.style.display = 'block';
                falseBtn.style.width = '100%';
                falseBtn.style.margin = '5px 0';
                falseBtn.style.padding = '10px';
                
                optionsContainer.appendChild(trueBtn);
                optionsContainer.appendChild(falseBtn);
                
                log(`✅ گزینه‌های درست/نادرست بارگذاری شد`);
            }
        }
        
        // مرحله 5: نمایش Modal
        document.getElementById('examInterface').style.display = 'flex';
        log(`✅ صفحه آزمون نمایش داده شد`);
        
        displayResult('simulationResult', true, '🎉 شبیه‌سازی کامل موفق!', {
            exam_title: exam.title,
            duration: exam.duration_minutes,
            questions_loaded: questions.length,
            modal_visible: true
        });
        
    } catch (error) {
        log(`💥 خطا در شبیه‌سازی: ${error.message}`);
        displayResult('simulationResult', false, 'خطا در شبیه‌سازی: ' + error.message);
    }
}

// Initialize
window.onload = function() {
    log(`🚀 صفحه تست مشکل آزمون آماده است`);
    log(`💡 برای تست کامل: 1) ابتدا آزمون را بارگذاری کنید 2) سپس شبیه‌سازی را اجرا کنید`);
};
</script>

</body>
</html>