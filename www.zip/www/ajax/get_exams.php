<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$config_paths = ['../config.php', '../../config.php'];
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

try {
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("
        SELECT 
            exam_name as name,
            subject,
            COUNT(*) as count,
            MAX(created_at) as updated_at
        FROM exam_questions 
        WHERE teacher_id = ?
        GROUP BY exam_name, subject
        ORDER BY updated_at DESC
    ");
    
    $stmt->execute([$teacher_id]);
    $exams = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $exams[] = [
            'name' => $row['name'],
            'subject' => $row['subject'],
            'count' => (int)$row['count'],
            'updated_at' => $row['updated_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'data' => $exams
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => []
    ]);
}
?>
