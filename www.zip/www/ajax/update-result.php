<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['result_id'])) {
        echo json_encode(['success' => false, 'message' => 'داده‌های الزامی ارسال نشده']);
        exit();
    }
    
    // اعتبارسنجی مقادیر
    $score = (int)$input['score'];
    $timeSpent = (int)$input['time_spent'];
    $accuracy = (int)$input['accuracy'];
    
    if ($score < 0 || $score > 100) {
        echo json_encode(['success' => false, 'message' => 'امتیاز باید بین 0 تا 100 باشد']);
        exit();
    }
    
    if ($timeSpent < 1) {
        echo json_encode(['success' => false, 'message' => 'زمان باید بیشتر از صفر باشد']);
        exit();
    }
    
    if ($accuracy < 0 || $accuracy > 100) {
        echo json_encode(['success' => false, 'message' => 'دقت باید بین 0 تا 100 باشد']);
        exit();
    }
    
    // بروزرسانی نتیجه
    $stmt = $conn->prepare("
        UPDATE game_results 
        SET score = ?, time_spent = ?, accuracy = ?, completed_at = ?
        WHERE id = ?
    ");
    
    $result = $stmt->execute([
        $score,
        $timeSpent,
        $accuracy,
        $input['completed_at'],
        $input['result_id']
    ]);
    
    if ($result && $stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'نتیجه با موفقیت بروزرسانی شد'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'نتیجه یافت نشد یا تغییری اعمال نشد'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Error in update-result.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بروزرسانی: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>