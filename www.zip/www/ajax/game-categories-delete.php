<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) { echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit; }

try {
    $stmt = $conn->prepare("DELETE FROM game_categories WHERE id=?");
    $ok = $stmt->execute([$id]);
    echo json_encode(['success'=>true,'deleted'=>$ok?1:0]);
} catch (Throwable $e) {
    // اگر محدودیت کلید خارجی دارید، اینجا پیام دوست‌دارانه بدهید
    echo json_encode(['success'=>false,'message'=>'امکان حذف وجود ندارد (ممکن است به بازی‌ها متصل باشد).','error'=>$e->getMessage()]);
}
