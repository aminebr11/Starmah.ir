<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'لطفا وارد شوید']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

$gameType = sanitize($data['game_type'] ?? '');
$score = intval($data['score'] ?? 0);
$userId = $_SESSION['user_id'];

if (empty($gameType) || $score < 0) {
    echo json_encode(['success' => false, 'message' => 'داده‌های نامعتبر']);
    exit;
}

try {
    // Record game play
    recordGamePlay($conn, $userId, $gameType, $score);
    
    // Calculate stars earned (1 star per 10 points)
    $starsEarned = floor($score / 10);
    
    if ($starsEarned > 0) {
        // Update student score
        updateStudentScore($conn, $userId, $starsEarned);
    }
    
    echo json_encode([
        'success' => true,
        'stars_earned' => $starsEarned,
        'message' => 'امتیاز با موفقیت ذخیره شد'
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ذخیره امتیاز'
    ]);
}
?>