<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$idsJson = $_POST['student_ids'] ?? '[]';
$ids = json_decode($idsJson, true);
$points = (int)($_POST['points'] ?? 0);
if (!is_array($ids) || empty($ids) || $points<=0) { echo json_encode(['success'=>false,'message'=>'ورودی نامعتبر']); exit; }

$manual_game_id = 0; // ← اگر FK دارید، این را به id بازی "امتیاز دستی" تغییر دهید.

try{
  $conn->beginTransaction();
  $stmt = $conn->prepare("INSERT INTO game_results (student_id, game_id, score, max_possible_score, accuracy, time_spent, attempts, completed_at) VALUES (?,?,?,?,?,?,?,NOW())");
  foreach ($ids as $sid) {
    $sid = (int)$sid; if ($sid<=0) continue;
    $stmt->execute([$sid, $manual_game_id, $points, 100, 0, 0, 1]);
  }
  $conn->commit();
  echo json_encode(['success'=>true]);
}catch(Throwable $e){
  $conn->rollBack();
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
