<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

$studentId = $_GET['student_id'] ?? null;

if (!$studentId) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز ارسال نشده']);
    exit();
}

try {
    $stmt = $conn->prepare("
        SELECT id as user_id, first_name, last_name, national_id 
        FROM users 
        WHERE id = ? AND user_type = 'student'
    ");
    
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit();
    }
    
    echo json_encode([
        'success' => true,
        'student' => $student
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت اطلاعات: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>