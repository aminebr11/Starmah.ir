<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// بررسی دسترسی
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$db = $conn;
$student_id = (int)($_GET['student_id'] ?? 0);

if ($student_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است']);
    exit;
}

// توابع کمکی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + floor(($gy2 + 3) / 4) - floor(($gy2 + 99) / 100) + floor(($gy2 + 399) / 400) + $gd;
    for ($i = 0; $i < $gm; $i++) $days += $g_d_m[$i];
    $jy = -1595 + (33 * floor($days / 12053));
    $days %= 12053;
    $jy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + floor($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $days -= 186;
        $jm = 7 + floor($days / 30);
        $jd = 1 + ($days % 30);
    }
    return [$jy, $jm, $jd];
}

function en_to_fa_digits($str) {
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, $str);
}

function dbdate_to_jalali_fa($dateStr) {
    $dateStr = trim((string)$dateStr);
    if ($dateStr === '') return '';
    $parts = preg_split('/[\-\/\.]/', $dateStr);
    if (count($parts) < 3) return $dateStr;
    $gy = (int)$parts[0]; $gm = (int)$parts[1]; $gd = (int)$parts[2];
    if ($gy <= 0 || $gm <= 0 || $gd <= 0) return $dateStr;
    [$jy, $jm, $jd] = gregorian_to_jalali($gy, $gm, $gd);
    return en_to_fa_digits(sprintf('%04d/%02d/%02d', $jy, $jm, $jd));
}

function extractMaxScoreFromTitle($title) {
    if (preg_match('/\(از\s*(\d+)\s*نمره\)/u', $title, $matches)) {
        return (int)$matches[1];
    }
    if (preg_match('/\((\d+)\s*نمره\)/u', $title, $matches)) {
        return (int)$matches[1];
    }
    if (preg_match('/\/(\d+)$/u', $title, $matches)) {
        return (int)$matches[1];
    }
    return 20;
}

function getDerivedStatus($record) {
    if (isset($record['status']) && $record['status'] === 'absent') {
        return ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'];
    }
    
    if (empty($record['score'])) {
        return ['text' => 'ثبت نشده', 'color' => '#a0aec0', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'descriptive') {
        $map = [
            'خیلی خوب' => ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'],
            'خوب' => ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'],
            'قابل قبول' => ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'],
            'نیاز به تلاش' => ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'homework') {
        $map = [
            'کامل' => ['text' => 'کامل', 'color' => '#22c55e', 'icon' => '✅'],
            'ناقص' => ['text' => 'ناقص', 'color' => '#f59e0b', 'icon' => '⚠️'],
            'انجام نداده' => ['text' => 'انجام نشده', 'color' => '#ef4444', 'icon' => '❌'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'numeric') {
        $numeric_score = (float)str_replace(',', '.', $record['score']);
        $maxScore = extractMaxScoreFromTitle($record['activity_title']);
        $percentage = $maxScore > 0 ? ($numeric_score / $maxScore) : 0;
        
        if ($percentage >= 0.9) return ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'];
        if ($percentage >= 0.75) return ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'];
        if ($percentage >= 0.5) return ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'];
        return ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'];
    }
    
    return ['text' => 'نامشخص', 'color' => '#9ca3af', 'icon' => ''];
}

try {
    // دریافت اطلاعات دانش‌آموز
    $stmt = $db->prepare("SELECT id, first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit;
    }
    
    // دریافت تمام نمرات دانش‌آموز
    $stmt = $db->prepare("
        SELECT 
            ar.id AS result_id,
            ar.activity_id,
            ar.score,
            ar.status,
            ar.feedback,
            a.date,
            a.lesson,
            a.topic,
            a.title AS activity_title,
            a.score_type
        FROM activity_results ar
        JOIN activities a ON ar.activity_id = a.id
        WHERE ar.student_id = ?
        ORDER BY a.date DESC, a.id DESC
    ");
    $stmt->execute([$student_id]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // پردازش رکوردها
    $processed_records = [];
    foreach ($records as $record) {
        $maxScore = extractMaxScoreFromTitle($record['activity_title']);
        $status = getDerivedStatus($record);
        
        // محاسبه نمایش نمره
        $score_display = '';
        if (!empty($record['score'])) {
            if ($record['score_type'] === 'numeric') {
                $score_display = en_to_fa_digits($record['score'] . '/' . $maxScore);
            } else {
                $score_display = $record['score'];
            }
        } else {
            $score_display = '-';
        }
        
        $processed_records[] = [
            'result_id' => $record['result_id'],
            'activity_id' => $record['activity_id'],
            'date_fa' => dbdate_to_jalali_fa($record['date']),
            'lesson' => $record['lesson'],
            'topic' => $record['topic'],
            'activity_title' => $record['activity_title'],
            'title' => $record['activity_title'], // برای سازگاری
            'score_type' => $record['score_type'],
            'score' => $record['score'],
            'score_display' => $score_display,
            'status' => $record['status'],
            'feedback' => $record['feedback'],
            'status_text' => $status['text'],
            'status_color' => $status['color'],
            'status_icon' => $status['icon'],
            'maxScore' => $maxScore,
            'first_name' => $student['first_name'],
            'last_name' => $student['last_name']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'student' => $student,
        'records' => $processed_records
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگذاری اطلاعات: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>