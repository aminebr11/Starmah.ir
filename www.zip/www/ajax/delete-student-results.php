<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['student_id'])) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز ارسال نشده']);
        exit();
    }
    
    $stmt = $conn->prepare("DELETE FROM game_results WHERE student_id = ?");
    $result = $stmt->execute([$input['student_id']]);
    
    if ($result) {
        $deletedCount = $stmt->rowCount();
        echo json_encode([
            'success' => true,
            'message' => "تعداد $deletedCount نتیجه حذف شد",
            'deleted_count' => $deletedCount
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'خطا در حذف نتایج'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Error in delete-student-results.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در حذف: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>