<?php
// فایل: ajax/delete_single_result.php
session_start();
header('Content-Type: application/json');

require_once '../config.php'; // مسیر فایل کانفیگ دیتابیس خود را چک کنید

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت داده‌های JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['result_id'])) {
        throw new Exception('شناسه نتیجه ارسال نشده است');
    }

    $resultId = intval($input['result_id']);

    // شروع تراکنش (چون احتمالا می‌خواهید XP را هم کم کنید)
    $conn->beginTransaction();

    // 1. دریافت اطلاعات برای کسر احتمالی امتیاز (اختیاری - بسته به ساختار دیتابیس شما)
    // $stmt = $conn->prepare("SELECT student_id, score FROM game_results WHERE id = ?");
    // $stmt->execute([$resultId]);
    // $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. حذف رکورد از جدول نتایج
    $stmt = $conn->prepare("DELETE FROM game_results WHERE id = ?");
    $stmt->execute([$resultId]);

    if ($stmt->rowCount() > 0) {
        // 3. حذف رکوردهای مربوطه از تاریخچه XP (اگر جدول xp_history دارید)
        // $conn->prepare("DELETE FROM xp_history WHERE related_result_id = ?")->execute([$resultId]);
        
        $conn->commit();
        echo json_encode([
            'success' => true, 
            'message' => 'نتیجه با موفقیت حذف شد'
        ]);
    } else {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'رکوردی با این شناسه یافت نشد']);
    }

} catch (Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    http_response_code(500); // ارسال کد خطا برای دریافت در JS
    echo json_encode(['success' => false, 'message' => 'خطای سرور: ' . $e->getMessage()]);
}
?>