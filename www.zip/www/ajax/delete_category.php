<?php
// فایل: ajax/delete_category.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// بررسی روش درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت داده‌ها
    $input = json_decode(file_get_contents('php://input'), true);
    $categoryId = intval($input['category_id'] ?? 0);
    
    // بررسی شناسه دسته‌بندی
    if ($categoryId <= 0) {
        echo json_encode(['success' => false, 'message' => 'شناسه دسته‌بندی نامعتبر است']);
        exit();
    }
    
    // بررسی وجود دسته‌بندی
    $stmt = $conn->prepare("SELECT name FROM game_categories WHERE id = ?");
    $stmt->execute([$categoryId]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی یافت نشد']);
        exit();
    }
    
    // بررسی وجود بازی در این دسته‌بندی
    $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE category_id = ?");
    $stmt->execute([$categoryId]);
    $gamesCount = $stmt->fetchColumn();
    
    if ($gamesCount > 0) {
        echo json_encode([
            'success' => false, 
            'message' => "نمی‌توان این دسته‌بندی را حذف کرد زیرا $gamesCount بازی در آن وجود دارد. ابتدا بازی‌ها را به دسته‌بندی دیگری منتقل کنید."
        ]);
        exit();
    }
    
    // حذف دسته‌بندی
    $stmt = $conn->prepare("DELETE FROM game_categories WHERE id = ?");
    $result = $stmt->execute([$categoryId]);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'دسته‌بندی "' . $category['name'] . '" با موفقیت حذف شد'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در حذف دسته‌بندی']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در حذف دسته‌بندی: ' . $e->getMessage()
    ]);
}
?>