<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'عدم دسترسی']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$exam_id = isset($data['exam_id']) ? (int)$data['exam_id'] : 0;

if (!$exam_id) {
    echo json_encode(['success' => false, 'message' => 'شناسه نامعتبر']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // دریافت اطلاعات آزمون اصلی
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ?");
    $stmt->bind_param('i', $exam_id);
    $stmt->execute();
    $original = $stmt->get_result()->fetch_assoc();
    
    if (!$original) {
        throw new Exception('آزمون یافت نشد');
    }
    
    // ایجاد کپی از آزمون
    $new_title = $original['title'] . ' (کپی)';
    $stmt = $conn->prepare("
        INSERT INTO quizzes (
            title, exam_date, exam_time, duration_minutes,
            is_active, is_visible, shuffle_questions, negative_marking,
            questions_count, total_points
        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        'sssiiiiii',
        $new_title,
        $original['exam_date'],
        $original['exam_time'],
        $original['duration_minutes'],
        $original['is_visible'],
        $original['shuffle_questions'],
        $original['negative_marking'],
        $original['questions_count'],
        $original['total_points']
    );
    $stmt->execute();
    $new_exam_id = $conn->insert_id;
    
    // کپی سوالات
    $stmt = $conn->prepare("
        SELECT * FROM quiz_questions 
        WHERE quiz_id = ? 
        ORDER BY question_order
    ");
    $stmt->bind_param('i', $exam_id);
    $stmt->execute();
    $questions = $stmt->get_result();
    
    $insertStmt = $conn->prepare("
        INSERT INTO quiz_questions (
            quiz_id, question_text, question_type, 
            question_data, points, question_order, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    while ($q = $questions->fetch_assoc()) {
        $insertStmt->bind_param(
            'isssiii',
            $new_exam_id,
            $q['question_text'],
            $q['question_type'],
            $q['question_data'],
            $q['points'],
            $q['question_order'],
            $q['is_active']
        );
        $insertStmt->execute();
    }
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'آزمون با موفقیت کپی شد',
        'new_exam_id' => $new_exam_id
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'خطا در کپی آزمون: ' . $e->getMessage()
    ]);
}
?>