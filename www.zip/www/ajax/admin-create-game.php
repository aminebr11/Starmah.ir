<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت داده‌ها
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('داده‌ای دریافت نشد');
    }
    
    // اعتبارسنجی فیلدهای الزامی
    if (empty($input['title'])) {
        throw new Exception('عنوان بازی الزامی است');
    }
    
    if (empty($input['category_id'])) {
        throw new Exception('انتخاب درس الزامی است');
    }
    
    if (empty($input['game_code'])) {
        throw new Exception('کد بازی الزامی است');
    }
    
    // پردازش داده‌ها
    $title = trim($input['title']);
    $category_id = intval($input['category_id']);
    $estimated_time = intval($input['estimated_time'] ?? 5);
    $topic = trim($input['topic'] ?? '');
    $description = trim($input['description'] ?? '');
    $instructions = trim($input['instructions'] ?? '');
    $game_code = trim($input['game_code']);
    
    // دریافت نام درس از جدول game_categories
    $stmt = $conn->prepare("SELECT name FROM game_categories WHERE id = ? AND is_active = 1");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        throw new Exception('دسته‌بندی انتخاب شده نامعتبر است');
    }
    
    $subject = $category['name'];
    
    // بررسی ساختار جدول برای ستون‌های اضافی
    $checkColumns = $conn->query("DESCRIBE games");
    $columns = $checkColumns->fetchAll(PDO::FETCH_COLUMN);
    
    $hasCategory = in_array('category_id', $columns);
    $hasDifficulty = in_array('difficulty', $columns);
    $hasCreatedAt = in_array('created_at', $columns);
    
    // ساخت query بر اساس ستون‌های موجود
    $fields = ['title', 'subject', 'estimated_time', 'topic', 'description', 'instructions', 'game_code', 'is_active'];
    $values = [$title, $subject, $estimated_time, $topic, $description, $instructions, $game_code, 1];
    $placeholders = array_fill(0, count($values), '?');
    
    // افزودن ستون category_id اگر وجود دارد
    if ($hasCategory) {
        $fields[] = 'category_id';
        $values[] = $category_id;
        $placeholders[] = '?';
    }
    
    // افزودن ستون difficulty اگر وجود دارد
    if ($hasDifficulty) {
        $difficulty = $input['difficulty'] ?? 'medium';
        $fields[] = 'difficulty';
        $values[] = $difficulty;
        $placeholders[] = '?';
    }
    
    // افزودن ستون created_at اگر وجود دارد
    if ($hasCreatedAt) {
        $fields[] = 'created_at';
        $values[] = date('Y-m-d H:i:s');
        $placeholders[] = '?';
    }
    
    // ساخت query نهایی
    $sql = "INSERT INTO games (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
    
    // اجرای query
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute($values);
    
    if ($result) {
        $gameId = $conn->lastInsertId();
        
        echo json_encode([
            'success' => true, 
            'message' => 'بازی با موفقیت ایجاد شد',
            'game_id' => $gameId,
            'category_id' => $category_id,
            'subject' => $subject,
            'debug_info' => [
                'sql' => $sql,
                'values_count' => count($values),
                'placeholders_count' => count($placeholders)
            ]
        ]);
    } else {
        throw new Exception('خطا در ذخیره بازی در دیتابیس');
    }
    
} catch (PDOException $e) {
    error_log("Database Error in admin-create-game: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطای دیتابیس: ' . $e->getMessage(),
        'error_code' => $e->getCode()
    ]);
} catch (Exception $e) {
    error_log("Error in admin-create-game: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطا: ' . $e->getMessage()
    ]);
}
?>