<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Check if request is AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden access']);
    exit;
}

// Start session and include necessary files
session_start();

// Try different paths for config files
$config_paths = [
    '../config/database.php',
    '../config.php',
    'config/database.php',
    'config.php'
];

$auth_paths = [
    '../includes/auth.php',
    '../functions.php',
    'includes/auth.php',
    'functions.php'
];

$conn = null;
$config_loaded = false;

// Load database config
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

if (!$config_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری تنظیمات پایگاه داده']);
    exit;
}

// Load auth functions
$auth_loaded = false;
foreach ($auth_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $auth_loaded = true;
        break;
    }
}

if (!$auth_loaded) {
    echo json_encode(['success' => false, 'message' => 'خطا در بارگذاری تنظیمات احراز هویت']);
    exit;
}

// Debug log
error_log("Toggle status called");

// Check if user is admin
if (!function_exists('isAdmin') || !isAdmin()) {
    error_log("Admin check failed");
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Debug log
error_log("Input data: " . $input);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'خطا در پردازش JSON: ' . json_last_error_msg()]);
    exit;
}

if (!isset($data['student_id']) || !isset($data['new_status'])) {
    echo json_encode(['success' => false, 'message' => 'اطلاعات ناقص ارسال شده است.']);
    exit;
}

$studentId = intval($data['student_id']);
$newStatus = intval($data['new_status']);

// Validation
if ($studentId <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر است.']);
    exit;
}

if (!in_array($newStatus, [0, 1])) {
    echo json_encode(['success' => false, 'message' => 'وضعیت نامعتبر است.']);
    exit;
}

try {
    // Check if student exists
    $checkStmt = $conn->prepare("SELECT id, is_active, first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$studentId]);
    $student = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد.']);
        exit;
    }
    
    // Update status
    $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $result = $stmt->execute([$newStatus, $studentId]);
    
    if ($result) {
        // Log the change
        $statusText = $newStatus ? 'فعال' : 'غیرفعال';
        error_log("Status updated successfully for user ID: " . $studentId . " (" . $student['first_name'] . " " . $student['last_name'] . ") to status: " . $statusText);
        
        echo json_encode([
            'success' => true, 
            'message' => 'وضعیت دانش‌آموز با موفقیت به ' . $statusText . ' تغییر کرد.',
            'new_status' => $newStatus,
            'student_name' => $student['first_name'] . ' ' . $student['last_name']
        ]);
    } else {
        error_log("Database update failed for student ID: " . $studentId);
        echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی پایگاه داده.']);
    }
    
} catch (PDOException $e) {
    error_log("Database error in toggle student status: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای پایگاه داده: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("General error in toggle student status: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای سیستم: ' . $e->getMessage()]);
}
?>