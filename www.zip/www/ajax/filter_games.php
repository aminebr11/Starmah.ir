<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت داده‌های فیلتر
    $input = json_decode(file_get_contents('php://input'), true);
    
    if ($input === null) {
        throw new Exception('داده‌ای دریافت نشد');
    }
    
    $subject_filter = isset($input['subject']) ? trim($input['subject']) : '';
    $status_filter = isset($input['status']) ? $input['status'] : '';
    
    // ساخت WHERE clause
    $where_conditions = [];
    $params = [];
    
    // فیلتر موضوع/درس
    if (!empty($subject_filter)) {
        // اگر عدد است، بر اساس category_id فیلتر کن
        if (is_numeric($subject_filter)) {
            $where_conditions[] = "g.category_id = ?";
            $params[] = intval($subject_filter);
        } else {
            // اگر متن است، بر اساس نام درس فیلتر کن
            $where_conditions[] = "(g.subject LIKE ? OR gc.name LIKE ?)";
            $params[] = "%{$subject_filter}%";
            $params[] = "%{$subject_filter}%";
        }
    }
    
    // فیلتر وضعیت
    if ($status_filter !== '') {
        $where_conditions[] = "g.is_active = ?";
        $params[] = intval($status_filter);
    }
    
    // کوئری اصلی
    $where_clause = '';
    if (!empty($where_conditions)) {
        $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
    }
    
    $sql = "
        SELECT g.*, 
               gc.name as category_name,
               gc.icon as category_icon,
               COUNT(gr.id) as play_count,
               AVG(gr.score) as avg_score
        FROM games g
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        LEFT JOIN game_results gr ON g.id = gr.game_id
        {$where_clause}
        GROUP BY g.id, gc.name, gc.icon
        ORDER BY g.created_at DESC
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $games = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // پردازش نتایج
    $processed_games = [];
    foreach ($games as $game) {
        $processed_game = [
            'id' => intval($game['id']),
            'title' => $game['title'],
            'subject' => $game['subject'],
            'category_id' => $game['category_id'],
            'category_name' => $game['category_name'] ?: $game['subject'],
            'category_icon' => $game['category_icon'] ?: '📚',
            'difficulty' => $game['difficulty'] ?? 'medium',
            'estimated_time' => intval($game['estimated_time']),
            'play_count' => intval($game['play_count']),
            'avg_score' => floatval($game['avg_score']),
            'is_active' => intval($game['is_active']),
            'topic' => $game['topic'],
            'description' => $game['description'],
            'instructions' => $game['instructions'],
            'game_code' => $game['game_code'],
            'created_at' => $game['created_at']
        ];
        $processed_games[] = $processed_game;
    }
    
    echo json_encode([
        'success' => true,
        'games' => $processed_games,
        'count' => count($processed_games),
        'filter_info' => [
            'subject' => $subject_filter,
            'status' => $status_filter,
            'sql' => $sql,
            'params' => $params
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Database Error in filter_games: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطای دیتابیس: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in filter_games: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطا: ' . $e->getMessage()
    ]);
}
?>