<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    echo json_encode(['success' => false, 'message' => 'کاربر وارد نشده']);
    exit;
}

try {
    $student_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("SELECT * FROM student_xp WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $xp_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$xp_data) {
        $xp_data = [
            'total_xp' => 0,
            'math_xp' => 0,
            'science_xp' => 0,
            'persian_xp' => 0,
            'social_xp' => 0,
            'religion_xp' => 0,
            'level' => 1
        ];
    }
    
    // محاسبه مجدد امتیاز کل
    $calculated_total = $xp_data['math_xp'] + $xp_data['science_xp'] + 
                       $xp_data['persian_xp'] + $xp_data['social_xp'] + 
                       $xp_data['religion_xp'];
    
    $xp_data['total_xp'] = max($xp_data['total_xp'], $calculated_total);
    
    echo json_encode([
        'success' => true,
        'total_xp' => $xp_data['total_xp'],
        'math_xp' => $xp_data['math_xp'],
        'science_xp' => $xp_data['science_xp'],
        'persian_xp' => $xp_data['persian_xp'],
        'social_xp' => $xp_data['social_xp'],
        'religion_xp' => $xp_data['religion_xp'],
        'level' => $xp_data['level']
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت امتیاز']);
}
?>