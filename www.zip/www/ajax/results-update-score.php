<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$id = (int)($_POST['id'] ?? 0);
$score = (int)($_POST['score'] ?? 0);
$accuracy = (float)($_POST['accuracy'] ?? 0);
$time_spent = (int)($_POST['time_spent'] ?? 0);

if ($id <= 0) { echo json_encode(['success'=>false,'message'=>'شناسه نامعتبر']); exit; }

try{
  $stmt = $conn->prepare("UPDATE game_results SET score=?, accuracy=?, time_spent=? WHERE id=?");
  $ok = $stmt->execute([$score, $accuracy, $time_spent, $id]);
  echo json_encode(['success'=>true, 'updated'=>$ok?1:0]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
