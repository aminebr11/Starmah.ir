<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

$config_loaded = false;
$functions_loaded = false;

$config_paths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$functions_paths = ['../functions.php', '../../functions.php', dirname(__DIR__) . '/functions.php'];

foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $config_loaded = true;
        break;
    }
}

foreach ($functions_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functions_loaded = true;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!$config_loaded || !$functions_loaded) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'data' => []]);
    exit;
}

try {
    $subject = $_GET['subject'] ?? '';
    
    if (empty($subject)) {
        throw new Exception('نام درس مشخص نشده است');
    }
    
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $teacher_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("
        SELECT 
            id,
            question_text,
            question_type,
            options_json,
            score,
            answer_lines,
            section_title,
            section_icon
        FROM exam_questions 
        WHERE subject = ? AND teacher_id = ?
        ORDER BY id ASC
    ");
    
    $stmt->execute([$subject, $teacher_id]);
    $questions = [];
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $question = [
            'id' => $row['id'],
            'text' => $row['question_text'],
            'type' => $row['question_type'],
            'score' => (float)$row['score'],
            'section' => $row['section_title'],
            'icon' => $row['section_icon']
        ];
        
        if ($row['options_json']) {
            $question['options'] = json_decode($row['options_json'], true);
        }
        
        if ($row['answer_lines']) {
            $question['answerLines'] = (int)$row['answer_lines'];
        }
        
        $questions[] = $question;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $questions
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => []
    ]);
}
?>