<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// Check if user is admin
if (!isAdmin()) {
    die('دسترسی غیرمجاز');
}

$type = $_GET['type'] ?? '';

switch($type) {
    case 'monthly':
        generateMonthlyReport();
        break;
    case 'students':
        generateStudentsReport();
        break;
    case 'visits':
        generateVisitsReport();
        break;
    default:
        die('نوع گزارش نامعتبر');
}

// Generate monthly Excel report
function generateMonthlyReport() {
    global $conn;
    
    // Set headers for Excel download
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="گزارش-ماهانه-' . date('Y-m') . '.xls"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Output BOM for UTF-8
    echo "\xEF\xBB\xBF";
    
    // Start HTML table
    echo '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
    echo '<head><meta charset="UTF-8"></head>';
    echo '<body>';
    echo '<table border="1">';
    
    // Report header
    echo '<tr><td colspan="6" style="text-align: center; font-weight: bold; font-size: 16px;">گزارش ماهانه کلاس چهارم - ' . convertToJalali(date('Y-m-d')) . '</td></tr>';
    echo '<tr><td colspan="6"></td></tr>';
    
    // Students summary
    echo '<tr style="background-color: #f0f0f0;"><th colspan="6">خلاصه وضعیت دانش‌آموزان</th></tr>';
    echo '<tr>';
    echo '<th>رتبه</th>';
    echo '<th>نام و نام خانوادگی</th>';
    echo '<th>امتیاز کل</th>';
    echo '<th>ستاره‌های این ماه</th>';
    echo '<th>تعداد بازی</th>';
    echo '<th>تعداد تمرین</th>';
    echo '</tr>';
    
    $stmt = $conn->prepare("
        SELECT u.first_name, u.last_name, s.total_score, s.weekly_stars,
               COUNT(DISTINCT g.id) as games_count,
               COUNT(DISTINCT e.id) as exercises_count
        FROM users u
        LEFT JOIN students s ON u.id = s.user_id
        LEFT JOIN games_played g ON u.id = g.student_id AND g.played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        LEFT JOIN exercises_completed e ON u.id = e.student_id AND e.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        WHERE u.user_type = 'student'
        GROUP BY u.id
        ORDER BY s.total_score DESC
    ");
    $stmt->execute();
    $students = $stmt->fetchAll();
    
    $rank = 1;
    foreach($students as $student) {
        echo '<tr>';
        echo '<td>' . $rank++ . '</td>';
        echo '<td>' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) . '</td>';
        echo '<td>' . ($student['total_score'] ?? 0) . '</td>';
        echo '<td>' . ($student['weekly_stars'] ?? 0) . '</td>';
        echo '<td>' . $student['games_count'] . '</td>';
        echo '<td>' . $student['exercises_count'] . '</td>';
        echo '</tr>';
    }
    
    // Activities summary
    echo '<tr><td colspan="6"></td></tr>';
    echo '<tr style="background-color: #f0f0f0;"><th colspan="6">خلاصه فعالیت‌ها</th></tr>';
    
    $stmt = $conn->prepare("
        SELECT 
            COUNT(DISTINCT g.id) as total_games,
            COUNT(DISTINCT e.id) as total_exercises,
            COUNT(DISTINCT g.student_id) as active_students_games,
            COUNT(DISTINCT e.student_id) as active_students_exercises
        FROM games_played g
        LEFT JOIN exercises_completed e ON 1=1
        WHERE g.played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
           OR e.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute();
    $summary = $stmt->fetch();
    
    echo '<tr><td>تعداد کل بازی‌های انجام شده:</td><td colspan="5">' . $summary['total_games'] . '</td></tr>';
    echo '<tr><td>تعداد کل تمرین‌های حل شده:</td><td colspan="5">' . $summary['total_exercises'] . '</td></tr>';
    echo '<tr><td>دانش‌آموزان فعال در بازی:</td><td colspan="5">' . $summary['active_students_games'] . '</td></tr>';
    echo '<tr><td>دانش‌آموزان فعال در تمرین:</td><td colspan="5">' . $summary['active_students_exercises'] . '</td></tr>';
    
    echo '</table>';
    echo '</body>';
    echo '</html>';
}

// Generate students PDF report
function generateStudentsReport() {
    global $conn;
    
    // For now, we'll create a simple HTML report that can be printed as PDF
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="کارنامه-دانش‌آموزان-' . date('Y-m-d') . '.html"');
    
    echo '<!DOCTYPE html>';
    echo '<html lang="fa" dir="rtl">';
    echo '<head>';
    echo '<meta charset="UTF-8">';
    echo '<title>کارنامه دانش‌آموزان</title>';
    echo '<style>';
    echo 'body { font-family: Tahoma, Arial; direction: rtl; }';
    echo 'table { width: 100%; border-collapse: collapse; margin: 20px 0; }';
    echo 'th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }';
    echo 'th { background-color: #f0f0f0; }';
    echo '.page-break { page-break-after: always; }';
    echo '@media print { .no-print { display: none; } }';
    echo '</style>';
    echo '</head>';
    echo '<body>';
    
    echo '<div class="no-print" style="background: #f0f0f0; padding: 10px; margin-bottom: 20px;">';
    echo 'برای ذخیره به صورت PDF، از منوی چاپ مرورگر استفاده کنید و گزینه "Save as PDF" را انتخاب نمایید.';
    echo '</div>';
    
    $stmt = $conn->prepare("
        SELECT u.*, s.total_score, s.weekly_stars
        FROM users u
        LEFT JOIN students s ON u.id = s.user_id
        WHERE u.user_type = 'student'
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute();
    $students = $stmt->fetchAll();
    
    foreach($students as $index => $student) {
        if ($index > 0) echo '<div class="page-break"></div>';
        
        echo '<div style="text-align: center; margin-bottom: 30px;">';
        echo '<h1>کارنامه دانش‌آموز</h1>';
        echo '<h2>' . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) . '</h2>';
        echo '</div>';
        
        echo '<table>';
        echo '<tr><th width="30%">مشخصات</th><th>اطلاعات</th></tr>';
        echo '<tr><td>کد ملی</td><td>' . htmlspecialchars($student['national_id']) . '</td></tr>';
        echo '<tr><td>تاریخ تولد</td><td>' . htmlspecialchars($student['birth_date']) . '</td></tr>';
        echo '<tr><td>امتیاز کل</td><td>' . ($student['total_score'] ?? 0) . ' ستاره</td></tr>';
        echo '<tr><td>ستاره‌های این هفته</td><td>' . ($student['weekly_stars'] ?? 0) . ' ستاره</td></tr>';
        echo '</table>';
        
        // Get subject progress
        $stmt2 = $conn->prepare("
            SELECT subject, COUNT(*) as completed
            FROM exercises_completed
            WHERE student_id = ?
            GROUP BY subject
        ");
        $stmt2->execute([$student['id']]);
        $progress = $stmt2->fetchAll();
        
        echo '<h3 style="margin-top: 30px;">پیشرفت در دروس</h3>';
        echo '<table>';
        echo '<tr><th>درس</th><th>تمرین‌های انجام شده</th></tr>';
        
        $subjects = [
            'math' => 'ریاضی',
            'science' => 'علوم',
            'persian' => 'فارسی',
            'social' => 'مطالعات اجتماعی',
            'religion' => 'دینی'
        ];
        
        foreach($subjects as $key => $name) {
            $completed = 0;
            foreach($progress as $p) {
                if ($p['subject'] == $key) {
                    $completed = $p['completed'];
                    break;
                }
            }
            echo '<tr><td>' . $name . '</td><td>' . $completed . '</td></tr>';
        }
        echo '</table>';
    }
    
    echo '</body>';
    echo '</html>';
}

// Generate visits CSV report
function generateVisitsReport() {
    global $conn;
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="آمار-بازدید-' . date('Y-m-d') . '.csv"');
    
    // Output BOM for UTF-8
    echo "\xEF\xBB\xBF";
    
    // Open output stream
    $output = fopen('php://output', 'w');
    
    // Write headers
    fputcsv($output, ['تاریخ', 'ساعت', 'نام کاربر', 'IP', 'مرورگر']);
    
    // Get visits data
    $stmt = $conn->prepare("
        SELECT v.*, u.first_name, u.last_name
        FROM visits v
        LEFT JOIN users u ON v.user_id = u.id
        WHERE v.visit_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY v.visit_date DESC
    ");
    $stmt->execute();
    
    while($row = $stmt->fetch()) {
        $date = date('Y/m/d', strtotime($row['visit_date']));
        $time = date('H:i:s', strtotime($row['visit_date']));
        $userName = $row['first_name'] ? $row['first_name'] . ' ' . $row['last_name'] : 'مهمان';
        $browser = getBrowserFromUserAgent($row['user_agent']);
        
        fputcsv($output, [
            $date,
            $time,
            $userName,
            $row['ip_address'],
            $browser
        ]);
    }
    
    fclose($output);
}

// Helper function to detect browser
function getBrowserFromUserAgent($userAgent) {
    if (strpos($userAgent, 'Firefox') !== false) return 'Firefox';
    if (strpos($userAgent, 'Chrome') !== false) return 'Chrome';
    if (strpos($userAgent, 'Safari') !== false) return 'Safari';
    if (strpos($userAgent, 'Edge') !== false) return 'Edge';
    if (strpos($userAgent, 'Opera') !== false) return 'Opera';
    return 'Other';
}
?>