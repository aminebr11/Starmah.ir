<?php
// ajax/publish_exam.php - اصلاح شده
require_once '../config.php';
require_once '../functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is admin
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode([
        'success' => false, 
        'message' => 'دسترسی غیرمجاز'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Set proper headers
header('Content-Type: application/json; charset=utf-8');

try {
    // Get raw input
    $raw_input = file_get_contents('php://input');
    error_log("Publish exam raw input: " . $raw_input);
    
    if (empty($raw_input)) {
        throw new Exception('داده‌های ورودی خالی است');
    }
    
    // Decode JSON
    $input = json_decode($raw_input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('فرمت JSON نامعتبر: ' . json_last_error_msg());
    }
    
    if (!$input || !isset($input['exam_id'])) {
        throw new Exception('شناسه آزمون ارسال نشده است');
    }
    
    $exam_id = (int)$input['exam_id'];
    
    if ($exam_id <= 0) {
        throw new Exception('شناسه آزمون نامعتبر است');
    }
    
    error_log("Publishing exam with ID: $exam_id");
    
    // Check if exam exists in quizzes table
    $stmt = $conn->prepare("
        SELECT id, title, questions_count, total_points 
        FROM quizzes 
        WHERE id = ?
    ");
    $stmt->execute([$exam_id]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        throw new Exception('آزمون با این شناسه یافت نشد');
    }
    
    // Check if exam has questions in quiz_questions table
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(points), 0) as total_points
        FROM quiz_questions 
        WHERE quiz_id = ? AND is_active = 1
    ");
    $stmt->execute([$exam_id]);
    $question_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$question_stats || $question_stats['count'] == 0) {
        throw new Exception('آزمون باید حداقل یک سوال داشته باشد');
    }
    
    // Start transaction
    $conn->beginTransaction();
    
    try {
        // Activate the exam and update counts in quizzes table
        $stmt = $conn->prepare("
            UPDATE quizzes 
            SET is_active = 1, 
                questions_count = ?,
                total_points = ?
            WHERE id = ?
        ");
        
        $result = $stmt->execute([
            $question_stats['count'], 
            $question_stats['total_points'], 
            $exam_id
        ]);
        
        if (!$result) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception('خطا در انتشار آزمون: ' . ($errorInfo[2] ?? 'نامشخص'));
        }
        
        // Commit transaction
        $conn->commit();
        
        error_log("Exam $exam_id published successfully with {$question_stats['count']} questions and {$question_stats['total_points']} total points");
        
        // Return success response
        $response = [
            'success' => true,
            'message' => 'آزمون با موفقیت منتشر شد',
            'exam_id' => $exam_id,
            'title' => $exam['title'],
            'questions_count' => $question_stats['count'],
            'total_points' => $question_stats['total_points']
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Publish Exam Error: " . $e->getMessage());
    
    $response = [
        'success' => false,
        'message' => $e->getMessage()
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log("Publish Exam PDO Error: " . $e->getMessage());
    
    $response = [
        'success' => false,
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
}
?>