 ===============================
// فایل 1: ajax/save_exam.php
// ===============================
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$config_paths = ['../config.php', '../../config.php'];
foreach ($config_paths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفا وارد شوید']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $examName = $input['examName'] ?? '';
    $subject = $input['subject'] ?? '';
    $questions = $input['questions'] ?? [];
    $teacher_id = $_SESSION['user_id'];
    
    if (empty($examName) || empty($subject) || empty($questions)) {
        throw new Exception('اطلاعات ناقص است');
    }
    
    if (!isset($conn) || !$conn) {
        throw new Exception('خطا در اتصال به پایگاه داده');
    }
    
    $conn->beginTransaction();
    
    // حذف سوالات قبلی این آزمون
    $stmt = $conn->prepare("DELETE FROM exam_questions WHERE exam_name = ? AND teacher_id = ?");
    $stmt->execute([$examName, $teacher_id]);
    
    // درج سوالات جدید
    $stmt = $conn->prepare("
        INSERT INTO exam_questions 
        (teacher_id, exam_name, subject, question_text, question_type, options_json, 
         question_image, image_position, score, answer_lines, section_title, section_icon) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($questions as $q) {
        $stmt->execute([
            $teacher_id,
            $examName,
            $subject,
            $q['text'],
            $q['type'],
            isset($q['options']) ? json_encode($q['options'], JSON_UNESCAPED_UNICODE) : null,
            $q['image'] ?? null,
            $q['imagePosition'] ?? 'center',
            $q['score'] ?? 1,
            $q['answerLines'] ?? null,
            $q['section'] ?? '',
            $q['icon'] ?? '📝'
        ]);
    }
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'آزمون با موفقیت ذخیره شد'
    ]);
    
} catch (Exception $e) {
    if ($conn && $conn->inTransaction()) {
        $conn->rollback();
    }
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
