<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$student_id = $_GET['student_id'] ?? null;

try {
    if ($student_id) {
        // گرفتن موارد انضباطی یک دانش‌آموز خاص
        $stmt = $conn->prepare("
            SELECT dr.*, u.first_name, u.last_name 
            FROM discipline_records dr 
            JOIN users u ON dr.student_id = u.id 
            WHERE dr.student_id = ? 
            ORDER BY dr.date DESC
        ");
        $stmt->execute([$student_id]);
    } else {
        // گرفتن تمام موارد انضباطی
        $stmt = $conn->prepare("
            SELECT dr.*, u.first_name, u.last_name 
            FROM discipline_records dr 
            JOIN users u ON dr.student_id = u.id 
            ORDER BY dr.date DESC
        ");
        $stmt->execute();
    }
    
    $records = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'records' => $records]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت اطلاعات: ' . $e->getMessage()]);
}
?>