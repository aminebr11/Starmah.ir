<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$db = $conn;

// توابع کمکی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + floor(($gy2 + 3) / 4) - floor(($gy2 + 99) / 100) + floor(($gy2 + 399) / 400) + $gd;
    for ($i = 0; $i < $gm; $i++) $days += $g_d_m[$i];
    $jy = -1595 + (33 * floor($days / 12053));
    $days %= 12053;
    $jy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + floor($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $days -= 186;
        $jm = 7 + floor($days / 30);
        $jd = 1 + ($days % 30);
    }
    return [$jy, $jm, $jd];
}

function en_to_fa_digits($str) {
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, $str);
}

function dbdate_to_jalali_fa($dateStr) {
    $dateStr = trim((string)$dateStr);
    if ($dateStr === '') return '';
    $dateStr = str_replace('.', '-', $dateStr);
    $parts = preg_split('/[\/\-]/', $dateStr);
    if (count($parts) < 3) return $dateStr;
    $gy = (int)$parts[0]; $gm = (int)$parts[1]; $gd = (int)$parts[2];
    if ($gy <= 0 || $gm <= 0 || $gd <= 0) return $dateStr;
    [$jy, $jm, $jd] = gregorian_to_jalali($gy, $gm, $gd);
    $out = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    return en_to_fa_digits($out);
}

function getMaxScoreFromTitle($title) {
    if (preg_match('/\((\d+)\s*نمره\)/', $title, $matches)) {
        return (int)$matches[1];
    }
    if (preg_match('/\/(\d+)$/', $title, $matches)) {
        return (int)$matches[1];
    }
    return 20;
}

function getDerivedStatus($record) {
    if (isset($record['status']) && $record['status'] === 'absent') {
        return ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'];
    }
    if (empty($record['score'])) {
        return ['text' => 'ثبت نشده', 'color' => '#a0aec0', 'icon' => ''];
    }
    if ($record['score_type'] === 'descriptive') {
        $status_map = [
            'خیلی خوب' => ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'],
            'خوب' => ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'],
            'قابل قبول' => ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'],
            'نیاز به تلاش' => ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $status_map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    if ($record['score_type'] === 'homework') {
        $status_map = [
            'کامل' => ['text' => 'کامل', 'color' => '#22c55e', 'icon' => '✅'],
            'ناقص' => ['text' => 'ناقص', 'color' => '#f59e0b', 'icon' => '⚠️'],
            'انجام نداده' => ['text' => 'انجام نشده', 'color' => '#ef4444', 'icon' => '❌'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $status_map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    if ($record['score_type'] === 'numeric') {
        $numeric_score = (float)str_replace(',', '.', $record['score']);
        $maxScore = getMaxScoreFromTitle($record['activity_title']);
        $percentage = $maxScore > 0 ? ($numeric_score / $maxScore) : 0;
        
        if ($percentage >= 0.9) return ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'];
        if ($percentage >= 0.75) return ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'];
        if ($percentage >= 0.5) return ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'];
        return ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'];
    }
    return ['text' => 'نامشخص', 'color' => '#9ca3af', 'icon' => ''];
}

try {
    // ساخت کوئری با فیلترها
    $query = "
        SELECT 
            ar.id AS result_id,
            ar.activity_id,
            ar.student_id,
            ar.score,
            ar.status,
            ar.feedback,
            a.date,
            a.lesson,
            a.topic,
            a.title AS activity_title,
            a.score_type,
            u.first_name,
            u.last_name
        FROM activity_results ar
        JOIN activities a ON ar.activity_id = a.id
        JOIN users u ON ar.student_id = u.id
        WHERE 1=1
    ";
    
    $params = [];
    
    // فیلتر دانش‌آموز
    if (!empty($_GET['student_id'])) {
        $query .= " AND ar.student_id = ?";
        $params[] = (int)$_GET['student_id'];
    }
    
    // فیلتر درس
    if (!empty($_GET['lesson'])) {
        $query .= " AND a.lesson = ?";
        $params[] = $_GET['lesson'];
    }
    
    // فیلتر تاریخ از
    if (!empty($_GET['date_from'])) {
        $query .= " AND a.date >= ?";
        $params[] = $_GET['date_from'];
    }
    
    // فیلتر تاریخ تا
    if (!empty($_GET['date_to'])) {
        $query .= " AND a.date <= ?";
        $params[] = $_GET['date_to'];
    }
    
    // فیلتر عنوان
    if (!empty($_GET['search_title'])) {
        $query .= " AND a.title LIKE ?";
        $params[] = '%' . $_GET['search_title'] . '%';
    }
    
    // فیلتر نوع نمره
    if (!empty($_GET['score_type'])) {
        $query .= " AND a.score_type = ?";
        $params[] = $_GET['score_type'];
    }
    
    // مرتب‌سازی
    $orderBy = $_GET['order_by'] ?? 'date_desc';
    switch ($orderBy) {
        case 'date_asc':
            $query .= " ORDER BY a.date ASC, a.id ASC";
            break;
        case 'student_name':
            $query .= " ORDER BY u.first_name ASC, u.last_name ASC";
            break;
        case 'lesson':
            $query .= " ORDER BY a.lesson ASC";
            break;
        case 'date_desc':
        default:
            $query .= " ORDER BY a.date DESC, a.id DESC";
            break;
    }
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // پردازش رکوردها
    $processed_records = [];
    $total_score = 0;
    $score_count = 0;
    $unique_students = [];
    
    foreach ($records as $record) {
        $status = getDerivedStatus($record);
        $maxScore = getMaxScoreFromTitle($record['activity_title']);
        
        // محاسبه نمایش نمره
        $score_display = '';
        if (!empty($record['score'])) {
            if ($record['score_type'] === 'numeric') {
                $score_display = $record['score'] . '/' . $maxScore;
                $numeric_score = (float)str_replace(',', '.', $record['score']);
                $total_score += $numeric_score;
                $score_count++;
            } else {
                $score_display = $record['score'];
            }
        } else {
            $score_display = '-';
        }
        
        $unique_students[$record['student_id']] = true;
        
        $processed_records[] = [
            'result_id' => $record['result_id'],
            'activity_id' => $record['activity_id'],
            'student_id' => $record['student_id'],
            'student_name' => $record['first_name'] . ' ' . $record['last_name'],
            'lesson' => $record['lesson'],
            'activity_title' => $record['activity_title'],
            'date_fa' => dbdate_to_jalali_fa($record['date']),
            'score' => $record['score'],
            'score_display' => $score_display,
            'status' => $record['status'],
            'feedback' => $record['feedback'],
            'score_type' => $record['score_type'],
            'status_text' => $status['text'],
            'status_color' => $status['color'],
            'status_icon' => $status['icon']
        ];
    }
    
    // محاسبه آمار
    $avg_score = $score_count > 0 ? round($total_score / $score_count, 1) : 0;
    
    $stats = [
        'total' => count($records),
        'avgScore' => en_to_fa_digits($avg_score),
        'students' => count($unique_students)
    ];
    
    echo json_encode([
        'success' => true,
        'records' => $processed_records,
        'stats' => $stats
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگذاری داده‌ها: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>