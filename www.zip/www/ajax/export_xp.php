
<?php
// فایل جدید: ajax/export_xp.php
require_once '../config.php';
require_once '../functions.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode([
            'success' => false, 
            'message' => 'دسترسی غیرمجاز'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // دریافت داده‌ها
    $stmt = $conn->prepare("
        SELECT 
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            u.email as student_email,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.podcast_xp, 0) as podcast_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.user_type = 'student' AND u.is_active = 1
        ORDER BY COALESCE(sx.total_xp, 0) DESC
    ");
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تولید CSV
    $csvContent = "\xEF\xBB\xBF"; // UTF-8 BOM
    $csvContent .= "نام دانش‌آموز,ایمیل,کل XP,ریاضی XP,علوم XP,فارسی XP,اجتماعی XP,دینی XP,پادکست XP,سطح,آخرین بروزرسانی\n";
    
    foreach ($data as $row) {
        $csvContent .= sprintf(
            '"%s","%s","%d","%d","%d","%d","%d","%d","%d","%d","%s"' . "\n",
            str_replace('"', '""', $row['student_name']),
            str_replace('"', '""', $row['student_email'] ?? ''),
            $row['total_xp'],
            $row['math_xp'],
            $row['science_xp'],
            $row['persian_xp'],
            $row['social_xp'],
            $row['religion_xp'],
            $row['podcast_xp'],
            $row['level'],
            $row['updated_at'] ?? ''
        );
    }
    
    // ارسال فایل
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="xp_report_' . date('Y-m-d_H-i-s') . '.csv"');
    header('Content-Length: ' . strlen($csvContent));
    
    echo $csvContent;
    
} catch (Exception $e) {
    error_log("EXPORT_XP ERROR: " . $e->getMessage());
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>