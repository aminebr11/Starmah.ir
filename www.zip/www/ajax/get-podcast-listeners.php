<?php
// اتصال به دیتابیس
require_once '../config.php';

// بررسی اینکه آیا کاربر ادمین است یا خیر
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// دریافت شناسه پادکست از درخواست
 $data = json_decode(file_get_contents('php://input'), true);
 $podcastId = $data['podcast_id'] ?? 0;

if (empty($podcastId)) {
    echo json_encode(['success' => false, 'message' => 'شناسه پادکست نامعتبر است']);
    exit;
}

// دریافت اطلاعات بازدیدکنندگان پادکست
 $query = "
    SELECT 
        u.first_name,
        u.last_name,
        pl.listen_duration,
        pl.completion_percent,
        pl.listen_date
    FROM 
        podcast_listens pl
    JOIN 
        users u ON pl.student_id = u.id
    WHERE 
        pl.podcast_id = ?
    ORDER BY 
        pl.listen_date DESC
";

 $stmt = $conn->prepare($query);
 $stmt->bind_param("i", $podcastId);
 $stmt->execute();
 $result = $stmt->get_result();

 $listeners = [];
 $totalListeners = 0;
 $totalCompletion = 0;

while ($row = $result->fetch_assoc()) {
    $listeners[] = $row;
    $totalListeners++;
    $totalCompletion += $row['completion_percent'];
}

 $stmt->close();

// محاسبه میانگین درصد تکمیل
 $avgCompletion = $totalListeners > 0 ? round($totalCompletion / $totalListeners, 2) : 0;

// بازگرداندن نتایج در قالب JSON
echo json_encode([
    'success' => true,
    'listeners' => $listeners,
    'total_listeners' => $totalListeners,
    'avg_completion' => $avgCompletion
]);
?>