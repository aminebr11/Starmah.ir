<?php
// فایل: ajax/manage-lessons.php

session_start();
require_once '../config.php';

// بررسی لاگین و دسترسی ادمین
if (!isLoggedIn() || !isAdmin()) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'message' => 'دسترسی غیرمجاز'
    ]);
    exit();
}

// تنظیم هدر JSON
header('Content-Type: application/json; charset=utf-8');

// دریافت داده‌های JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['action'])) {
    echo json_encode([
        'success' => false,
        'message' => 'داده‌های ورودی نامعتبر'
    ]);
    exit();
}

$action = $input['action'];

try {
    switch ($action) {
        case 'add':
            $result = addLesson($conn, $input);
            break;
            
        case 'edit':
            $result = editLesson($conn, $input);
            break;
            
        case 'delete':
            $result = deleteLesson($conn, $input);
            break;
            
        default:
            throw new Exception('عملیات نامعتبر');
    }
    
    echo json_encode($result);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * افزودن درس جدید
 */
function addLesson($conn, $data) {
    if (!isset($data['name']) || empty(trim($data['name']))) {
        throw new Exception('نام درس الزامی است');
    }
    
    $name = trim($data['name']);
    
    // بررسی تکراری بودن نام درس
    $checkQuery = "SELECT id FROM lessons WHERE name = ?";
    $checkStmt = mysqli_prepare($conn, $checkQuery);
    
    if (!$checkStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری بررسی: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($checkStmt, "s", $name);
    mysqli_stmt_execute($checkStmt);
    $checkResult = mysqli_stmt_get_result($checkStmt);
    
    if (mysqli_num_rows($checkResult) > 0) {
        mysqli_stmt_close($checkStmt);
        throw new Exception('درس با این نام قبلاً وجود دارد');
    }
    
    mysqli_stmt_close($checkStmt);
    
    // افزودن درس جدید
    $insertQuery = "INSERT INTO lessons (name) VALUES (?)";
    $insertStmt = mysqli_prepare($conn, $insertQuery);
    
    if (!$insertStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری درج: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($insertStmt, "s", $name);
    $success = mysqli_stmt_execute($insertStmt);
    
    if (!$success) {
        mysqli_stmt_close($insertStmt);
        throw new Exception('خطا در درج درس جدید: ' . mysqli_error($conn));
    }
    
    $newId = mysqli_insert_id($conn);
    mysqli_stmt_close($insertStmt);
    
    return [
        'success' => true,
        'message' => 'درس جدید با موفقیت اضافه شد',
        'lesson_id' => $newId,
        'lesson_name' => $name
    ];
}

/**
 * ویرایش درس
 */
function editLesson($conn, $data) {
    if (!isset($data['id']) || !isset($data['name']) || empty(trim($data['name']))) {
        throw new Exception('شناسه و نام درس الزامی است');
    }
    
    $id = intval($data['id']);
    $name = trim($data['name']);
    
    if ($id <= 0) {
        throw new Exception('شناسه درس نامعتبر');
    }
    
    // بررسی وجود درس
    $checkQuery = "SELECT id FROM lessons WHERE id = ?";
    $checkStmt = mysqli_prepare($conn, $checkQuery);
    
    if (!$checkStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری بررسی: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($checkStmt, "i", $id);
    mysqli_stmt_execute($checkStmt);
    $checkResult = mysqli_stmt_get_result($checkStmt);
    
    if (mysqli_num_rows($checkResult) == 0) {
        mysqli_stmt_close($checkStmt);
        throw new Exception('درس مورد نظر یافت نشد');
    }
    
    mysqli_stmt_close($checkStmt);
    
    // بررسی تکراری بودن نام جدید (به جز درس جاری)
    $duplicateQuery = "SELECT id FROM lessons WHERE name = ? AND id != ?";
    $duplicateStmt = mysqli_prepare($conn, $duplicateQuery);
    
    if (!$duplicateStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری بررسی تکراری: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($duplicateStmt, "si", $name, $id);
    mysqli_stmt_execute($duplicateStmt);
    $duplicateResult = mysqli_stmt_get_result($duplicateStmt);
    
    if (mysqli_num_rows($duplicateResult) > 0) {
        mysqli_stmt_close($duplicateStmt);
        throw new Exception('درس دیگری با این نام وجود دارد');
    }
    
    mysqli_stmt_close($duplicateStmt);
    
    // بروزرسانی درس
    $updateQuery = "UPDATE lessons SET name = ? WHERE id = ?";
    $updateStmt = mysqli_prepare($conn, $updateQuery);
    
    if (!$updateStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری بروزرسانی: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($updateStmt, "si", $name, $id);
    $success = mysqli_stmt_execute($updateStmt);
    
    if (!$success) {
        mysqli_stmt_close($updateStmt);
        throw new Exception('خطا در بروزرسانی درس: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_close($updateStmt);
    
    return [
        'success' => true,
        'message' => 'درس با موفقیت ویرایش شد',
        'lesson_id' => $id,
        'lesson_name' => $name
    ];
}

/**
 * حذف درس
 */
function deleteLesson($conn, $data) {
    if (!isset($data['id'])) {
        throw new Exception('شناسه درس الزامی است');
    }
    
    $id = intval($data['id']);
    
    if ($id <= 0) {
        throw new Exception('شناسه درس نامعتبر');
    }
    
    // بررسی وجود درس
    $checkQuery = "SELECT id, name FROM lessons WHERE id = ?";
    $checkStmt = mysqli_prepare($conn, $checkQuery);
    
    if (!$checkStmt) {
        throw new Exception('خطا در آماده‌سازی کوئری بررسی: ' . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($checkStmt, "i", $id);
    mysqli_stmt_execute($checkStmt);
    $checkResult = mysqli_stmt_get_result($checkStmt);
    
    if (mysqli_num_rows($checkResult) == 0) {
        mysqli_stmt_close($checkStmt);
        throw new Exception('درس مورد نظر یافت نشد');
    }
    
    $lesson = mysqli_fetch_assoc($checkResult);
    mysqli_stmt_close($checkStmt);
    
    // شروع تراکنش
    mysqli_begin_transaction($conn);
    
    try {
        // حذف تکالیف مربوط به این درس
        $deleteHomeworkQuery = "DELETE FROM homeworks WHERE subject = ?";
        $deleteHomeworkStmt = mysqli_prepare($conn, $deleteHomeworkQuery);
        
        if (!$deleteHomeworkStmt) {
            throw new Exception('خطا در آماده‌سازی کوئری حذف تکالیف: ' . mysqli_error($conn));
        }
        
        mysqli_stmt_bind_param($deleteHomeworkStmt, "s", $id);
        mysqli_stmt_execute($deleteHomeworkStmt);
        mysqli_stmt_close($deleteHomeworkStmt);
        
        // حذف درس
        $deleteLessonQuery = "DELETE FROM lessons WHERE id = ?";
        $deleteLessonStmt = mysqli_prepare($conn, $deleteLessonQuery);
        
        if (!$deleteLessonStmt) {
            throw new Exception('خطا در آماده‌سازی کوئری حذف درس: ' . mysqli_error($conn));
        }
        
        mysqli_stmt_bind_param($deleteLessonStmt, "i", $id);
        $success = mysqli_stmt_execute($deleteLessonStmt);
        mysqli_stmt_close($deleteLessonStmt);
        
        if (!$success) {
            throw new Exception('خطا در حذف درس: ' . mysqli_error($conn));
        }
        
        // تأیید تراکنش
        mysqli_commit($conn);
        
        return [
            'success' => true,
            'message' => 'درس و تمام تکالیف مربوط به آن با موفقیت حذف شدند',
            'deleted_lesson' => $lesson['name']
        ];
        
    } catch (Exception $e) {
        // بازگردانی تراکنش در صورت خطا
        mysqli_rollback($conn);
        throw $e;
    }
}

/**
 * بررسی لاگین بودن کاربر
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * بررسی ادمین بودن کاربر
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}
?>