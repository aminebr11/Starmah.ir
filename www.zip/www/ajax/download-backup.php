<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// Check if user is admin
if (!isAdmin()) {
    die('دسترسی غیرمجاز');
}

// Get filename from request
$encodedFilename = $_GET['file'] ?? '';
$filename = base64_decode($encodedFilename);

// Validate filename
if (!preg_match('/^backup_[\d-_]+\.sql$/', $filename)) {
    die('نام فایل نامعتبر');
}

$filepath = '../backups/' . $filename;

// Check if file exists
if (!file_exists($filepath)) {
    die('فایل یافت نشد');
}

// Set headers for download
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filepath));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Read and output file
readfile($filepath);

// Log the download
error_log("Backup downloaded: $filename by admin {$_SESSION['user_id']}");

exit();
?>