<?php
// فایل تست برای دیباگ مشکل افزودن بازی
// این فایل را در پوشه ajax ذخیره کنید: ajax/debug_add_game.php

session_start();
require_once '../config.php';

// فعال‌سازی گزارش خطا
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');

echo "=== شروع دیباگ افزودن بازی ===\n";

// بررسی سشن
echo "1. بررسی سشن:\n";
if (!isset($_SESSION['user_id'])) {
    echo "   ❌ user_id موجود نیست\n";
    exit();
} else {
    echo "   ✅ user_id: " . $_SESSION['user_id'] . "\n";
}

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo "   ❌ user_type ادمین نیست: " . ($_SESSION['user_type'] ?? 'not set') . "\n";
    exit();
} else {
    echo "   ✅ user_type: admin\n";
}

// بررسی اتصال دیتابیس
echo "\n2. بررسی اتصال دیتابیس:\n";
try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM games");
    $stmt->execute();
    $count = $stmt->fetchColumn();
    echo "   ✅ اتصال موفق - تعداد بازی‌های موجود: $count\n";
} catch (Exception $e) {
    echo "   ❌ خطا در اتصال دیتابیس: " . $e->getMessage() . "\n";
    exit();
}

// بررسی ساختار جدول
echo "\n3. بررسی ساختار جدول games:\n";
try {
    $stmt = $conn->prepare("DESCRIBE games");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $required_columns = ['id', 'title', 'description', 'category_id', 'subject', 'game_code', 'created_by'];
    foreach ($required_columns as $col) {
        $found = false;
        foreach ($columns as $column) {
            if ($column['Field'] === $col) {
                echo "   ✅ $col\n";
                $found = true;
                break;
            }
        }
        if (!$found) {
            echo "   ❌ $col - ستون موجود نیست\n";
        }
    }
} catch (Exception $e) {
    echo "   ❌ خطا در بررسی ساختار جدول: " . $e->getMessage() . "\n";
}

// بررسی دسته‌بندی‌ها
echo "\n4. بررسی دسته‌بندی‌ها:\n";
try {
    $stmt = $conn->prepare("SELECT id, name FROM game_categories WHERE is_active = 1");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($categories)) {
        echo "   ❌ هیچ دسته‌بندی فعالی یافت نشد\n";
    } else {
        echo "   ✅ دسته‌بندی‌های موجود:\n";
        foreach ($categories as $cat) {
            echo "      - {$cat['id']}: {$cat['name']}\n";
        }
    }
} catch (Exception $e) {
    echo "   ❌ خطا در بررسی دسته‌بندی‌ها: " . $e->getMessage() . "\n";
}

// تست درج نمونه
echo "\n5. تست درج بازی نمونه:\n";
try {
    $test_title = "بازی تست " . date('Y-m-d H:i:s');
    $test_category_id = 1; // فرض می‌کنیم دسته‌بندی 1 وجود دارد
    
    // ابتدا بررسی کنیم دسته‌بندی 1 وجود دارد
    $stmt = $conn->prepare("SELECT name FROM game_categories WHERE id = 1 AND is_active = 1");
    $stmt->execute();
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        echo "   ❌ دسته‌بندی 1 یافت نشد\n";
    } else {
        $sql = "
            INSERT INTO games (
                title, description, category_id, subject, difficulty, 
                topic, estimated_time, max_score, game_code, 
                instructions, is_active, created_by
            ) VALUES (
                :title, :description, :category_id, :subject, :difficulty,
                :topic, :estimated_time, :max_score, :game_code,
                :instructions, 1, :created_by
            )
        ";
        
        $stmt = $conn->prepare($sql);
        $result = $stmt->execute([
            ':title' => $test_title,
            ':description' => 'توضیحات تست',
            ':category_id' => $test_category_id,
            ':subject' => $category['name'],
            ':difficulty' => 'medium',
            ':topic' => 'موضوع تست',
            ':estimated_time' => 5,
            ':max_score' => 100,
            ':game_code' => '<html><body>بازی تست</body></html>',
            ':instructions' => 'راهنمای تست',
            ':created_by' => $_SESSION['user_id']
        ]);
        
        if ($result) {
            $game_id = $conn->lastInsertId();
            echo "   ✅ درج موفق - ID بازی: $game_id\n";
            
            // حذف بازی تست
            $stmt = $conn->prepare("DELETE FROM games WHERE id = :id");
            $stmt->execute([':id' => $game_id]);
            echo "   ✅ بازی تست حذف شد\n";
        } else {
            echo "   ❌ درج ناموفق\n";
        }
    }
} catch (Exception $e) {
    echo "   ❌ خطا در تست درج: " . $e->getMessage() . "\n";
}

echo "\n=== پایان دیباگ ===\n";

// اگر تا اینجا رسیدیم، مشکل احتمالاً در JavaScript یا فرم HTML است
echo "\n6. پیشنهادات:\n";
echo "   - مشکل احتمالاً در ارسال فرم JavaScript است\n";
echo "   - F12 Developer Tools را باز کنید و Console را بررسی کنید\n";
echo "   - Network tab را برای دیدن درخواست‌های AJAX چک کنید\n";
echo "   - مسیر فایل‌های AJAX را بررسی کنید\n";
?>