<?php
session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

try {
    require_once '../config.php';
    
    // دریافت پارامترهای فیلتر
    $game_id = $_GET['game_id'] ?? '';
    $student = $_GET['student'] ?? '';
    $date_from = $_GET['date_from'] ?? '';
    $date_to = $_GET['date_to'] ?? '';
    $min_score = $_GET['min_score'] ?? '';
    $max_score = $_GET['max_score'] ?? '';
    $sort = $_GET['sort'] ?? 'date_desc';
    $page = (int)($_GET['page'] ?? 1);
    $per_page = (int)($_GET['per_page'] ?? 20);
    
    $page = max(1, $page);
    $per_page = min(100, max(10, $per_page));
    $offset = ($page - 1) * $per_page;
    
    // ساخت کوئری اصلی
    $baseQuery = "
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        LEFT JOIN games g ON gr.game_id = g.id
        WHERE 1=1
    ";
    
    $params = [];
    $whereConditions = [];
    
    // اعمال فیلترها
    if (!empty($game_id)) {
        $whereConditions[] = "gr.game_id = :game_id";
        $params[':game_id'] = $game_id;
    }
    
    if (!empty($student)) {
        $whereConditions[] = "(u.username LIKE :student OR u.first_name LIKE :student OR u.last_name LIKE :student OR gr.student_id = :student_id)";
        $params[':student'] = "%{$student}%";
        $params[':student_id'] = is_numeric($student) ? $student : 0;
    }
    
    if (!empty($date_from)) {
        $whereConditions[] = "DATE(gr.completed_at) >= :date_from";
        $params[':date_from'] = $date_from;
    }
    
    if (!empty($date_to)) {
        $whereConditions[] = "DATE(gr.completed_at) <= :date_to";
        $params[':date_to'] = $date_to;
    }
    
    if (!empty($min_score)) {
        $whereConditions[] = "gr.score >= :min_score";
        $params[':min_score'] = $min_score;
    }
    
    if (!empty($max_score)) {
        $whereConditions[] = "gr.score <= :max_score";
        $params[':max_score'] = $max_score;
    }
    
    if (!empty($whereConditions)) {
        $baseQuery .= " AND " . implode(" AND ", $whereConditions);
    }
    
    // مرتب‌سازی
    $orderBy = "ORDER BY ";
    switch ($sort) {
        case 'date_asc':
            $orderBy .= "gr.completed_at ASC";
            break;
        case 'score_desc':
            $orderBy .= "gr.score DESC";
            break;
        case 'score_asc':
            $orderBy .= "gr.score ASC";
            break;
        case 'time_desc':
            $orderBy .= "gr.time_spent DESC";
            break;
        case 'time_asc':
            $orderBy .= "gr.time_spent ASC";
            break;
        default:
            $orderBy .= "gr.completed_at DESC";
    }
    
    // شمارش کل رکوردها
    $countQuery = "SELECT COUNT(*) " . $baseQuery;
    $stmt = $conn->prepare($countQuery);
    $stmt->execute($params);
    $total_results = $stmt->fetchColumn();
    
    // محاسبه صفحه‌بندی
    $total_pages = ceil($total_results / $per_page);
    
    // دریافت نتایج صفحه فعلی
    $dataQuery = "
        SELECT 
            gr.*,
            COALESCE(u.username, CONCAT('کاربر ', gr.student_id)) as student_name,
            COALESCE(CONCAT(u.first_name, ' ', u.last_name), u.username) as student_full_name,
            g.title as game_title
        " . $baseQuery . " " . $orderBy . " LIMIT :limit OFFSET :offset";
    
    $stmt = $conn->prepare($dataQuery);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // فرمت کردن نتایج
    $formattedResults = [];
    foreach ($results as $result) {
        $studentName = !empty(trim($result['student_full_name'])) ? trim($result['student_full_name']) : $result['student_name'];
        
        $formattedResults[] = [
            'id' => (int)$result['id'],
            'student_id' => (int)$result['student_id'],
            'student_name' => $studentName,
            'game_id' => (int)$result['game_id'],
            'game_title' => $result['game_title'] ?: 'بازی حذف شده',
            'score' => (int)$result['score'],
            'max_possible_score' => (int)$result['max_possible_score'],
            'accuracy' => (float)$result['accuracy'],
            'time_spent' => $result['time_spent'] ? (int)$result['time_spent'] : null,
            'attempts' => (int)$result['attempts'],
            'completed_at' => $result['completed_at']
        ];
    }
    
    // محاسبه آمار کلی
    $statsQuery = "
        SELECT 
            COUNT(*) as total_results,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            AVG(gr.time_spent) as avg_time,
            COUNT(DISTINCT gr.student_id) as total_players,
            AVG(gr.accuracy) as avg_accuracy
        " . $baseQuery;
    
    $stmt = $conn->prepare($statsQuery);
    $stmt->execute($params);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // داده‌های نمودار توزیع امتیازات
    $scoreDistQuery = "
        SELECT 
            CASE 
                WHEN gr.score >= 90 THEN '90-100'
                WHEN gr.score >= 80 THEN '80-89'
                WHEN gr.score >= 70 THEN '70-79'
                WHEN gr.score >= 60 THEN '60-69'
                WHEN gr.score >= 50 THEN '50-59'
                ELSE '0-49'
            END as score_range,
            COUNT(*) as count
        " . $baseQuery . "
        GROUP BY score_range
        ORDER BY score_range DESC
    ";
    
    $stmt = $conn->prepare($scoreDistQuery);
    $stmt->execute($params);
    $scoreDistribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $scoreLabels = [];
    $scoreData = [];
    foreach ($scoreDistribution as $dist) {
        $scoreLabels[] = $dist['score_range'];
        $scoreData[] = (int)$dist['count'];
    }
    
    // داده‌های نمودار روند زمانی
    $timeSeriesQuery = "
        SELECT 
            DATE(gr.completed_at) as date,
            AVG(gr.score) as avg_score
        " . $baseQuery . "
        GROUP BY DATE(gr.completed_at)
        ORDER BY DATE(gr.completed_at) DESC
        LIMIT 30
    ";
    
    $stmt = $conn->prepare($timeSeriesQuery);
    $stmt->execute($params);
    $timeSeries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $timeLabels = [];
    $timeData = [];
    foreach (array_reverse($timeSeries) as $ts) {
        $timeLabels[] = date('j/n', strtotime($ts['date']));
        $timeData[] = round((float)$ts['avg_score'], 1);
    }
    
    echo json_encode([
        'success' => true,
        'results' => $formattedResults,
        'stats' => [
            'total_results' => (int)$stats['total_results'],
            'avg_score' => round((float)$stats['avg_score'], 1),
            'best_score' => (int)$stats['best_score'],
            'avg_time' => round((float)$stats['avg_time'], 1),
            'total_players' => (int)$stats['total_players'],
            'avg_accuracy' => round((float)$stats['avg_accuracy'], 1)
        ],
        'pagination' => [
            'current_page' => $page,
            'total_pages' => $total_pages,
            'per_page' => $per_page,
            'total_results' => $total_results
        ],
        'chart_data' => [
            'score_distribution' => [
                'labels' => $scoreLabels,
                'data' => $scoreData
            ],
            'time_series' => [
                'labels' => $timeLabels,
                'data' => $timeData
            ]
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("Error in load_results.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری نتایج'
    ], JSON_UNESCAPED_UNICODE);
}
?>