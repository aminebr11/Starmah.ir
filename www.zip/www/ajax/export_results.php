<?php
// فایل: ajax/export_results.php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // دریافت فیلترها
    $filters = [
        'student_id' => $_GET['student_id'] ?? '',
        'game_id' => $_GET['game_id'] ?? '',
        'category_id' => $_GET['category_id'] ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'min_score' => $_GET['min_score'] ?? '',
        'max_score' => $_GET['max_score'] ?? ''
    ];

    // ساخت WHERE clause
    $whereConditions = ["1=1"];
    $params = [];

    if (!empty($filters['student_id'])) {
        $whereConditions[] = "gr.student_id = ?";
        $params[] = $filters['student_id'];
    }

    if (!empty($filters['game_id'])) {
        $whereConditions[] = "gr.game_id = ?";
        $params[] = $filters['game_id'];
    }

    if (!empty($filters['category_id'])) {
        $whereConditions[] = "g.category_id = ?";
        $params[] = $filters['category_id'];
    }

    if (!empty($filters['date_from'])) {
        $whereConditions[] = "DATE(gr.completed_at) >= ?";
        $params[] = $filters['date_from'];
    }

    if (!empty($filters['date_to'])) {
        $whereConditions[] = "DATE(gr.completed_at) <= ?";
        $params[] = $filters['date_to'];
    }

    if ($filters['min_score'] !== '') {
        $whereConditions[] = "gr.score >= ?";
        $params[] = $filters['min_score'];
    }

    if ($filters['max_score'] !== '') {
        $whereConditions[] = "gr.score <= ?";
        $params[] = $filters['max_score'];
    }

    $whereClause = implode(' AND ', $whereConditions);

    // دریافت داده‌ها برای خروجی
    $query = "
        SELECT 
            gr.id as 'شناسه نتیجه',
            CONCAT(u.first_name, ' ', u.last_name) as 'نام دانش‌آموز',
            u.national_id as 'کد ملی',
            g.title as 'عنوان بازی',
            gc.name as 'دسته‌بندی',
            g.difficulty as 'سطح سختی',
            gr.score as 'امتیاز',
            gr.max_possible_score as 'حداکثر امتیاز',
            ROUND((gr.score / gr.max_possible_score) * 100, 2) as 'درصد امتیاز',
            gr.accuracy as 'دقت (%)',
            gr.time_spent as 'زمان صرف شده (ثانیه)',
            FLOOR(gr.time_spent / 60) as 'زمان (دقیقه)',
            gr.attempts as 'تعداد تلاش',
            DATE_FORMAT(gr.completed_at, '%Y/%m/%d') as 'تاریخ',
            TIME_FORMAT(gr.completed_at, '%H:%i:%s') as 'ساعت'
        FROM game_results gr
        LEFT JOIN users u ON gr.student_id = u.id
        LEFT JOIN games g ON gr.game_id = g.id
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        WHERE $whereClause
        ORDER BY gr.completed_at DESC
    ";

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // تنظیم headers برای دانلود
    $filename = 'game_results_' . date('Y-m-d_H-i-s') . '.csv';
    
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');

    // شروع output
    $output = fopen('php://output', 'w');
    
    // اضافه کردن BOM برای UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // اضافه کردن header
    if (!empty($results)) {
        fputcsv($output, array_keys($results[0]));
        
        // اضافه کردن داده‌ها
        foreach ($results as $row) {
            fputcsv($output, $row);
        }
    }

    fclose($output);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در خروجی Excel: ' . $e->getMessage()
    ]);
}
?>