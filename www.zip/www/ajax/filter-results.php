<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $whereConditions = [];
    $params = [];
    
    // فیلتر بر اساس دانش‌آموز
    if (!empty($input['student_id'])) {
        $whereConditions[] = "u.id = ?";
        $params[] = $input['student_id'];
    }
    
    // فیلتر بر اساس بازی
    if (!empty($input['game_id'])) {
        $whereConditions[] = "gr.game_id = ?";
        $params[] = $input['game_id'];
    }
    
    // فیلتر بر اساس تاریخ
    if (!empty($input['date_filter'])) {
        switch ($input['date_filter']) {
            case 'today':
                $whereConditions[] = "DATE(gr.completed_at) = CURDATE()";
                break;
            case 'week':
                $whereConditions[] = "gr.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $whereConditions[] = "gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
        }
    }
    
    $whereClause = empty($whereConditions) ? '' : 'WHERE u.user_type = \'student\' AND ' . implode(' AND ', $whereConditions);
    
    if (empty($whereConditions)) {
        $whereClause = 'WHERE u.user_type = \'student\'';
    }
    
    $stmt = $conn->prepare("
        SELECT 
            u.id as user_id,
            u.first_name,
            u.last_name,
            u.national_id,
            COALESCE(COUNT(gr.id), 0) as games_count,
            COALESCE(SUM(gr.score), 0) as total_score,
            COALESCE(AVG(gr.score), 0) as avg_score,
            COALESCE(MAX(gr.score), 0) as best_score,
            COALESCE(AVG(gr.accuracy), 0) as avg_accuracy,
            MAX(gr.completed_at) as last_play
        FROM users u
        LEFT JOIN game_results gr ON u.id = gr.student_id
        $whereClause
        GROUP BY u.id, u.first_name, u.last_name, u.national_id
        HAVING games_count > 0 OR u.id IN (SELECT DISTINCT student_id FROM game_results)
        ORDER BY total_score DESC, avg_score DESC
    ");
    
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // فرمت کردن داده‌ها
    foreach ($results as &$result) {
        $result['total_score'] = (int)($result['total_score'] ?? 0);
        $result['avg_score'] = (float)($result['avg_score'] ?? 0);
        $result['best_score'] = (int)($result['best_score'] ?? 0);
        $result['avg_accuracy'] = (float)($result['avg_accuracy'] ?? 0);
        $result['games_count'] = (int)($result['games_count'] ?? 0);
        
        if ($result['games_count'] == 0) {
            $result['last_play'] = null;
        }
    }
    
    echo json_encode([
        'success' => true,
        'results' => $results,
        'count' => count($results),
        'filters_applied' => $input
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("Error in filter-results.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در فیلتر: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>