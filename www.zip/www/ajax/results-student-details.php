<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');
if (!isAdmin()) { echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit; }

$student_id = (int)($_GET['student_id'] ?? 0);
if ($student_id <= 0) { echo json_encode(['success'=>false,'message'=>'شناسه دانش‌آموز نامعتبر']); exit; }

try{
  $sql = "
    WITH ranked AS (
      SELECT
        gr.id, gr.student_id, gr.game_id, gr.score, gr.accuracy, COALESCE(gr.time_spent,0) AS time_spent, gr.completed_at,
        DENSE_RANK() OVER (PARTITION BY gr.game_id ORDER BY gr.score DESC, COALESCE(gr.time_spent,999999) ASC, gr.completed_at ASC) AS rank_in_game
      FROM game_results gr
      WHERE gr.student_id = ?
    )
    SELECT 
      r.id, r.student_id, r.game_id, r.score, r.accuracy, r.time_spent, r.completed_at, r.rank_in_game,
      g.title AS game_title,
      COALESCE(gc.name, g.subject) AS subject_name
    FROM ranked r
    JOIN games g ON g.id = r.game_id
    LEFT JOIN game_categories gc ON g.subject = gc.name
    ORDER BY r.completed_at DESC
    LIMIT 1000
  ";
  $stmt = $conn->prepare($sql);
  $stmt->execute([$student_id]);
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode(['success'=>true,'items'=>$items]);
}catch(Throwable $e){
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
