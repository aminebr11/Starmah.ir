<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

$response = ['success' => false, 'message' => ''];

try {
    // بررسی درخواست POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('فقط درخواست POST مجاز است.');
    }
    
    // بررسی فایل
    if (!isset($_FILES['logo'])) {
        throw new Exception('فایلی ارسال نشده است.');
    }
    
    $file = $_FILES['logo'];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('خطا در دریافت فایل. کد: ' . $file['error']);
    }
    
    // پوشه مقصد
    $uploadDir = dirname(__FILE__) . '/../uploads/logos/';
    
    // ایجاد پوشه
    if (!file_exists($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            throw new Exception('خطا در ایجاد پوشه.');
        }
    }
    
    // بررسی پسوند فایل
    $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowedExt)) {
        throw new Exception('فرمت فایل مجاز نیست.');
    }
    
    // بررسی حجم (حداکثر 5MB)
    if ($file['size'] > 5242880) {
        throw new Exception('حجم فایل بیش از 5 مگابایت است.');
    }
    
    // نام جدید فایل
    $newFileName = 'logo_' . time() . '_' . mt_rand(1000, 9999) . '.' . $extension;
    $targetPath = $uploadDir . $newFileName;
    
    // انتقال فایل
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception('خطا در ذخیره فایل.');
    }
    
    $response['success'] = true;
    $response['filePath'] = 'uploads/logos/' . $newFileName;
    $response['message'] = 'لوگو با موفقیت آپلود شد.';
    
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
