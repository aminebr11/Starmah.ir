<?php
// فایل اصلاح شده: ajax/get_badges.php
require_once '../config.php';
require_once '../functions.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
try {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    if (!isAdmin()) {
        echo json_encode([
            'success' => false, 
            'message' => 'دسترسی غیرمجاز'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // دریافت ورودی با حالت‌های مختلف
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    // اگر JSON decode نشد، از POST استفاده کن
    if (!$input) {
        $input = $_POST;
    }
    
    $action = $input['action'] ?? $_GET['action'] ?? 'load_badges';
    
    error_log("GET_BADGES: Action received = '$action'");
    
    // اگر action خالی است، پیش‌فرض load_badges
    if (empty($action)) {
        $action = 'load_badges';
    }
    
    if ($action === 'load_badges') {
        // استفاده از کوئری مستقیم با تمام فیلدها شامل dic_xp, exam_xp, other_xp
        $stmt = $conn->prepare("
            SELECT 
                u.id as user_id,
                u.id as student_id,
                CONCAT(u.first_name, ' ', u.last_name) as student_name,
                u.email as student_email,
                COALESCE(sx.math_xp, 0) as math_xp,
                COALESCE(sx.science_xp, 0) as science_xp,
                COALESCE(sx.persian_xp, 0) as persian_xp,
                COALESCE(sx.social_xp, 0) as social_xp,
                COALESCE(sx.religion_xp, 0) as religion_xp,
                COALESCE(sx.podcast_xp, 0) as podcast_xp,
                COALESCE(sx.dic_xp, 0) as dic_xp,
                COALESCE(sx.exam_xp, 0) as exam_xp,
                COALESCE(sx.other_xp, 0) as other_xp,
                (COALESCE(sx.math_xp, 0) + COALESCE(sx.science_xp, 0) + COALESCE(sx.persian_xp, 0) + 
                 COALESCE(sx.social_xp, 0) + COALESCE(sx.religion_xp, 0) + COALESCE(sx.podcast_xp, 0) + 
                 COALESCE(sx.dic_xp, 0) + COALESCE(sx.exam_xp, 0) + COALESCE(sx.other_xp, 0)) as total_xp,
                COALESCE(sx.level, 1) as level,
                sx.updated_at
            FROM users u
            LEFT JOIN student_xp sx ON u.id = sx.student_id
            WHERE u.user_type = 'student' AND u.is_active = 1
            ORDER BY total_xp DESC
        ");
        
        $stmt->execute();
        $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // تبدیل به integer برای اطمینان
        foreach ($badges as &$badge) {
            $badge['math_xp'] = (int)$badge['math_xp'];
            $badge['science_xp'] = (int)$badge['science_xp'];
            $badge['persian_xp'] = (int)$badge['persian_xp'];
            $badge['social_xp'] = (int)$badge['social_xp'];
            $badge['religion_xp'] = (int)$badge['religion_xp'];
            $badge['podcast_xp'] = (int)$badge['podcast_xp'];
            $badge['dic_xp'] = (int)$badge['dic_xp'];
            $badge['exam_xp'] = (int)$badge['exam_xp'];
            $badge['other_xp'] = (int)$badge['other_xp'];
            $badge['total_xp'] = (int)$badge['total_xp'];
            $badge['level'] = (int)$badge['level'];
        }
        
        error_log("GET_BADGES: Found " . count($badges) . " records");
        
        echo json_encode([
            'success' => true,
            'badges' => $badges,
            'count' => count($badges),
            'debug' => [
                'action' => $action,
                'sample_record' => isset($badges[0]) ? $badges[0] : null
            ]
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'عملیات نامشخص: ' . $action,
            'debug' => [
                'received_action' => $action,
                'raw_input' => $raw_input
            ]
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    error_log("GET_BADGES ERROR: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا: ' . $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ], JSON_UNESCAPED_UNICODE);
}
?>