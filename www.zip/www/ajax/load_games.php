<?php
session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

try {
    // ساخت کوئری اصلی
    $sql = "
        SELECT 
            g.*,
            gc.name as category_name,
            COUNT(gr.id) as play_count,
            AVG(gr.score) as avg_score
        FROM games g
        LEFT JOIN game_categories gc ON g.category_id = gc.id
        LEFT JOIN game_results gr ON g.id = gr.game_id
    ";
    
    $params = [];
    $whereConditions = [];
    
    // فیلتر بر اساس درس
    if (isset($_GET['subject']) && !empty($_GET['subject'])) {
        $whereConditions[] = "g.category_id = :category_id";
        $params[':category_id'] = $_GET['subject'];
    }
    
    // فیلتر بر اساس وضعیت
    if (isset($_GET['status']) && $_GET['status'] !== '') {
        $whereConditions[] = "g.is_active = :is_active";
        $params[':is_active'] = (int)$_GET['status'];
    }
    
    // اضافه کردن شرایط WHERE در صورت وجود
    if (!empty($whereConditions)) {
        $sql .= " WHERE " . implode(" AND ", $whereConditions);
    }
    
    // گروه‌بندی و مرتب‌سازی
    $sql .= " GROUP BY g.id ORDER BY g.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $games = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل داده‌ها به فرمت مناسب
    $formattedGames = [];
    foreach ($games as $game) {
        $formattedGames[] = [
            'id' => (int)$game['id'],
            'title' => $game['title'],
            'subject' => $game['subject'], // برای سازگاری با کد قدیمی
            'category_name' => $game['category_name'],
            'category_id' => $game['category_id'],
            'topic' => $game['topic'],
            'description' => $game['description'],
            'instructions' => $game['instructions'],
            'estimated_time' => (int)$game['estimated_time'],
            'is_active' => (bool)$game['is_active'],
            'play_count' => (int)($game['play_count'] ?? 0),
            'avg_score' => $game['avg_score'] ? round((float)$game['avg_score'], 1) : 0,
            'created_at' => $game['created_at'],
            'updated_at' => $game['updated_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'games' => $formattedGames,
        'total' => count($formattedGames)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("خطا در بارگیری بازی‌ها: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در بارگیری اطلاعات: ' . $e->getMessage(),
        'games' => []
    ], JSON_UNESCAPED_UNICODE);
}
?>