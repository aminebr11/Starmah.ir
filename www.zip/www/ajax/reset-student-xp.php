<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $studentId = $input['student_id'] ?? null;
    
    if (!$studentId) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز ارسال نشده']);
        exit();
    }
    
    // بررسی وجود دانش‌آموز
    $checkStmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ? AND user_type = 'student'");
    $checkStmt->execute([$studentId]);
    $student = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        exit();
    }
    
    $conn->beginTransaction();
    
    try {
        // ریست کردن تمام امتیازات
        $resetStmt = $conn->prepare("
            UPDATE student_xp 
            SET total_xp = 0, math_xp = 0, science_xp = 0, persian_xp = 0, social_xp = 0, religion_xp = 0, level = 1 
            WHERE student_id = ?
        ");
        $resetStmt->execute([$studentId]);
        
        // اگر رکورد وجود نداشت، ایجاد کن
        if ($resetStmt->rowCount() == 0) {
            $insertStmt = $conn->prepare("
                INSERT INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level) 
                VALUES (?, 0, 0, 0, 0, 0, 0, 1)
            ");
            $insertStmt->execute([$studentId]);
        }
        
        // ثبت تاریخچه
        $historyStmt = $conn->prepare("
            INSERT INTO xp_history (student_id, subject, amount, reason, admin_id, created_at) 
            VALUES (?, 'reset', 0, 'ریست کامل امتیازات توسط ادمین', ?, NOW())
        ");
        $historyStmt->execute([$studentId, $_SESSION['user_id']]);
        
        $conn->commit();
        
        echo json_encode([
            'success' => true,
            'message' => "تمام امتیازات {$student['first_name']} {$student['last_name']} ریست شد"
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ریست امتیازات: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>