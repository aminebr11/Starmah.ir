<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
  echo json_encode(['success'=>false,'message'=>'دسترسی غیرمجاز']); exit;
}

$id    = (int)($_POST['id'] ?? 0);
$title = sanitize($_POST['title'] ?? '');
$desc  = sanitize($_POST['description'] ?? '');
$dur   = sanitize($_POST['duration'] ?? '');

if ($id <= 0 || $title === '') {
  echo json_encode(['success'=>false,'message'=>'شناسه/عنوان نامعتبر']); exit;
}

try {
  // مسیر قبلی
  $stmt = $conn->prepare("SELECT file_path FROM podcasts WHERE id=? LIMIT 1");
  $stmt->execute([$id]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) { echo json_encode(['success'=>false,'message'=>'رکورد یافت نشد']); exit; }
  $oldPath = $row['file_path'];

  $newPath = $oldPath;

  // اگر فایل جدید آمد
  if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] === UPLOAD_ERR_OK) {
    $up = uploadFile($_FILES['audio_file'], 'podcasts', ['mp3','wav','ogg','m4a']);
    if (!$up['success']) { echo json_encode($up); exit; }
    $newPath = $up['path'];
  }

  // به‌روزرسانی
  $upd = $conn->prepare("UPDATE podcasts SET title=?, description=?, duration=?, file_path=? WHERE id=?");
  $ok  = $upd->execute([$title, $desc, $dur, $newPath, $id]);

  if (!$ok) {
    // اگر آپلود جدید داشتیم، فایل جدید را پاک کنیم
    if ($newPath !== $oldPath && is_file($newPath)) @unlink($newPath);
    echo json_encode(['success'=>false,'message'=>'خطای پایگاه داده']); exit;
  }

  // اگر فایل جدید ثبت شد، قدیمی را حذف کن
  if ($newPath !== $oldPath && $oldPath && is_file($oldPath)) {
    @unlink($oldPath);
  }

  echo json_encode(['success'=>true,'message'=>'ویرایش انجام شد','file_path'=>$newPath]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'خطای سرور']);
}
