<?php
// File: ../ajax/update_single_result.php (نسخه دیباگ)
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// ایجاد فایل لاگ برای دیباگ
$log_file = __DIR__ . '/debug_log.txt';
$log_data = "--- New Request at " . date('Y-m-d H:i:s') . " ---\n";
$log_data .= "POST data: " . print_r($_POST, true) . "\n";
file_put_contents($log_file, $log_data, FILE_APPEND);


if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر']);
    exit();
}

// دریافت و اعتبارسنجی داده‌ها
// ما همچنان از intval استفاده می‌کنیم اما لاگ بالا به ما نشان می‌دهد که آیا اصلا چیزی دریافت شده یا نه
$result_id = isset($_POST['result_id']) ? intval($_POST['result_id']) : 0;
$score = isset($_POST['score']) ? intval($_POST['score']) : 0;
$accuracy = isset($_POST['accuracy']) ? floatval($_POST['accuracy']) : 0.0;
$time_spent = isset($_POST['time_spent']) ? intval($_POST['time_spent']) : 0;
$attempts = isset($_POST['attempts']) ? intval($_POST['attempts']) : 1;
$completed_at = isset($_POST['completed_at']) ? $_POST['completed_at'] : null;

if ($result_id <= 0) {
    // اینجا جایی است که خطا رخ می‌دهد. لاگ به ما می‌گوید چرا.
    echo json_encode(['success' => false, 'message' => 'شناسه نتیجه نامعتبر است']);
    exit();
}

// ... بقیه کد بدون تغییر باقی می‌ماند ...
if ($completed_at) {
    try {
        $date = new DateTime($completed_at);
        $completed_at_db = $date->format('Y-m-d H:i:s');
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'فرمت تاریخ نامعتبر است.']);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'تاریخ الزامی است.']);
    exit();
}

try {
    $stmt = $conn->prepare("
        UPDATE game_results 
        SET 
            score = :score, 
            accuracy = :accuracy, 
            time_spent = :time_spent, 
            attempts = :attempts, 
            completed_at = :completed_at
        WHERE id = :id
    ");
    
    $stmt->bindParam(':score', $score, PDO::PARAM_INT);
    $stmt->bindParam(':accuracy', $accuracy, PDO::PARAM_STR);
    $stmt->bindParam(':time_spent', $time_spent, PDO::PARAM_INT);
    $stmt->bindParam(':attempts', $attempts, PDO::PARAM_INT);
    $stmt->bindParam(':completed_at', $completed_at_db, PDO::PARAM_STR);
    $stmt->bindParam(':id', $result_id, PDO::PARAM_INT);
    
    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => true, 'message' => 'تغییری برای ذخیره وجود نداشت.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در اجرای کوئری.']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطای دیتابیس: ' . $e->getMessage()]);
}
?>