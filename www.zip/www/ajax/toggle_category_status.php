<?php
// فایل: ajax/toggle_category_status.php
session_start();
require_once '../config.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

// بررسی روش درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'روش درخواست نامعتبر']);
    exit();
}

try {
    // دریافت داده‌ها
    $input = json_decode(file_get_contents('php://input'), true);
    $categoryId = intval($input['category_id'] ?? 0);
    
    // بررسی شناسه دسته‌بندی
    if ($categoryId <= 0) {
        echo json_encode(['success' => false, 'message' => 'شناسه دسته‌بندی نامعتبر است']);
        exit();
    }
    
    // دریافت وضعیت فعلی دسته‌بندی
    $stmt = $conn->prepare("SELECT name, is_active FROM game_categories WHERE id = ?");
    $stmt->execute([$categoryId]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        echo json_encode(['success' => false, 'message' => 'دسته‌بندی یافت نشد']);
        exit();
    }
    
    // تغییر وضعیت
    $newStatus = $category['is_active'] ? 0 : 1;
    $statusText = $newStatus ? 'فعال' : 'غیرفعال';
    
    // بررسی اینکه اگر می‌خواهیم غیرفعال کنیم، آیا بازی‌ای در این دسته وجود دارد؟
    if ($newStatus == 0) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE category_id = ? AND is_active = 1");
        $stmt->execute([$categoryId]);
        $activeGamesCount = $stmt->fetchColumn();
        
        if ($activeGamesCount > 0) {
            echo json_encode([
                'success' => false, 
                'message' => "نمی‌توان این دسته‌بندی را غیرفعال کرد زیرا $activeGamesCount بازی فعال در آن وجود دارد. ابتدا بازی‌ها را غیرفعال یا منتقل کنید."
            ]);
            exit();
        }
    }
    
    // بروزرسانی وضعیت
    $stmt = $conn->prepare("UPDATE game_categories SET is_active = ? WHERE id = ?");
    $result = $stmt->execute([$newStatus, $categoryId]);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'دسته‌بندی "' . $category['name'] . '" با موفقیت ' . $statusText . ' شد',
            'new_status' => $newStatus
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'خطا در تغییر وضعیت دسته‌بندی']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطا در تغییر وضعیت دسته‌بندی: ' . $e->getMessage()
    ]);
}
?>