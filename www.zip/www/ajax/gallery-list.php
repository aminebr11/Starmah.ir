<?php
// ajax/gallery-list.php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) { echo json_encode(['success'=>false,'message'=>'Unauthorized']); exit; }

try {
  // اگر تابع آماده دارید:
  if (function_exists('getGalleryItems')) {
    $items = getGalleryItems($conn);
  } else {
    $st = $conn->query("SELECT id,title,description,category,file_path,created_at FROM gallery ORDER BY id DESC");
    $items = $st->fetchAll(PDO::FETCH_ASSOC);
  }
  echo json_encode(['success'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
