<?php
// ajax/get-game-results.php - گزارش نتایج بازی‌ها برای ادمین
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

$game_id = (int)($_GET['game_id'] ?? 0);
$period = $_GET['period'] ?? 'all'; // all, week, month

try {
    // فیلتر زمانی
    $date_filter = '';
    switch ($period) {
        case 'week':
            $date_filter = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
            break;
        case 'month':
            $date_filter = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
            break;
    }
    
    if ($game_id > 0) {
        // نتایج یک بازی خاص
        $stmt = $conn->prepare("
            SELECT u.first_name, u.last_name, gr.score, gr.accuracy, 
                   gr.time_spent, gr.completed_at,
                   ROW_NUMBER() OVER (ORDER BY gr.score DESC) as rank
            FROM game_results gr
            JOIN users u ON gr.student_id = u.id
            WHERE gr.game_id = ? {$date_filter}
            ORDER BY gr.score DESC, gr.time_spent ASC
        ");
        $stmt->execute([$game_id]);
    } else {
        // آمار کلی همه بازی‌ها
        $stmt = $conn->prepare("
            SELECT g.title, 
                   COUNT(gr.id) as play_count,
                   AVG(gr.score) as avg_score,
                   MAX(gr.score) as max_score,
                   MIN(gr.score) as min_score,
                   AVG(gr.accuracy) as avg_accuracy,
                   AVG(gr.time_spent) as avg_time
            FROM games g
            LEFT JOIN game_results gr ON g.id = gr.game_id
            WHERE g.is_active = 1 {$date_filter}
            GROUP BY g.id, g.title
            ORDER BY play_count DESC
        ");
        $stmt->execute();
    }
    
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'results' => $results]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در دریافت گزارش']);
}
?>

