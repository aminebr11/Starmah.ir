<?php
// ajax/feedback-thread.php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) { echo json_encode(['success'=>false]); exit; }

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { echo json_encode(['success'=>false]); exit; }

try {
  $st = $conn->prepare("
    SELECT f.*, u.first_name, u.last_name
    FROM feedbacks f
    JOIN users u ON u.id = f.student_id
    WHERE f.id = ?
    LIMIT 1
  ");
  $st->execute([$id]);
  $fb = $st->fetch(PDO::FETCH_ASSOC);
  if (!$fb) { echo json_encode(['success'=>false]); exit; }

  // اجازه دسترسی: ادمین یا همان دانش‌آموز
  if (!isAdmin() && (int)$fb['student_id'] !== (int)($_SESSION['user_id'] ?? 0)) {
    echo json_encode(['success'=>false,'message'=>'Forbidden']); exit;
  }

  // عنوان نهایی: ترجیح با subject_fa، وگرنه subject_text، بعد subject
  $subjectTitle = (!empty($fb['subject_fa'])) 
                    ? $fb['subject_fa']
                    : ((!empty($fb['subject_text'])) ? $fb['subject_text'] : $fb['subject']);

  $fbOut = [
    'id'            => (int)$fb['id'],
    'student_id'    => (int)$fb['student_id'],
    'student_name'  => trim(($fb['first_name'] ?? '').' '.($fb['last_name'] ?? '')),
    'parent_name'   => $fb['parent_name'],
    'parent_phone'  => $fb['parent_phone'],
    'subject'       => $fb['subject'],       // کلید خام
    'subject_fa'    => $subjectTitle,        // عنوان برای نمایش
    'status'        => $fb['status'],
    'created_at'    => $fb['created_at'],
    'updated_at'    => $fb['updated_at'],
  ];

  $ms = $conn->prepare("
    SELECT id, sender_role, body, created_at, 
           IFNULL(seen_by_student, 0) AS seen_by_student
    FROM feedback_messages
    WHERE feedback_id = ?
    ORDER BY id ASC
  ");
  $ms->execute([$id]);
  $msgs = $ms->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode(['success'=>true,'feedback'=>$fbOut,'messages'=>$msgs], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  echo json_encode(['success'=>false,'message'=>'DB Error','error'=>$e->getMessage()]);
}
