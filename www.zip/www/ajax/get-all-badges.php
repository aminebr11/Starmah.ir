<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

// لاگ برای دیباگ
error_log("get-all-badges.php called by user: " . ($_SESSION['user_id'] ?? 'unknown'));

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // بررسی اتصال دیتابیس
    if (!isset($conn)) {
        throw new Exception('اتصال به دیتابیس برقرار نیست');
    }
    
    // تست وجود جدول student_xp
    $testTable = $conn->query("SHOW TABLES LIKE 'student_xp'");
    if ($testTable->rowCount() == 0) {
        // ایجاد جدول اگر وجود ندارد
        $createTable = "
            CREATE TABLE `student_xp` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `student_id` int(11) NOT NULL,
              `total_xp` int(11) DEFAULT 0,
              `math_xp` int(11) DEFAULT 0,
              `science_xp` int(11) DEFAULT 0,
              `persian_xp` int(11) DEFAULT 0,
              `social_xp` int(11) DEFAULT 0,
              `religion_xp` int(11) DEFAULT 0,
              `level` int(11) DEFAULT 1,
              `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              UNIQUE KEY `student_id` (`student_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci
        ";
        
        $conn->exec($createTable);
        error_log("student_xp table created");
        
        // اضافه کردن داده‌های اولیه برای دانش‌آموزان
        $insertInitial = $conn->prepare("
            INSERT IGNORE INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level)
            SELECT id, 0, 0, 0, 0, 0, 0, 1 FROM users WHERE user_type = 'student'
        ");
        $insertInitial->execute();
        error_log("Initial XP records created");
    }
    
    // دریافت تمام امتیازات XP دانش‌آموزان
    $stmt = $conn->prepare("
        SELECT 
            sx.student_id,
            u.first_name,
            u.last_name,
            u.national_id,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.user_type = 'student'
        ORDER BY sx.total_xp DESC, sx.level DESC, u.first_name ASC
    ");
    
    if (!$stmt->execute()) {
        throw new Exception('خطا در اجرای کوئری: ' . implode(', ', $stmt->errorInfo()));
    }
    
    $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log("Badges loaded: " . count($badges));
    
    // اگر هیچ داده‌ای نداریم، داده‌های نمونه بسازیم
    if (empty($badges)) {
        error_log("No badges found, creating sample data...");
        
        // بررسی وجود دانش‌آموز
        $studentCheck = $conn->query("SELECT COUNT(*) FROM users WHERE user_type = 'student'");
        $studentCount = $studentCheck->fetchColumn();
        
        if ($studentCount == 0) {
            echo json_encode([
                'success' => true,
                'badges' => [],
                'stats' => [
                    'total_xp' => 0,
                    'avg_xp' => 0,
                    'highest_xp' => 0,
                    'student_count' => 0
                ],
                'subject_totals' => [
                    'math_total' => 0,
                    'science_total' => 0,
                    'persian_total' => 0,
                    'social_total' => 0,
                    'religion_total' => 0
                ],
                'message' => 'هیچ دانش‌آموزی در سیستم وجود ندارد'
            ]);
            exit();
        }
        
        // ایجاد داده‌های نمونه
        $createSample = $conn->prepare("
            INSERT INTO student_xp (student_id, total_xp, math_xp, science_xp, persian_xp, social_xp, religion_xp, level)
            SELECT 
                id,
                FLOOR(RAND() * 3000) + 200 as total_xp,
                FLOOR(RAND() * 600) + 100 as math_xp,
                FLOOR(RAND() * 600) + 100 as science_xp,
                FLOOR(RAND() * 600) + 100 as persian_xp,
                FLOOR(RAND() * 600) + 100 as social_xp,
                FLOOR(RAND() * 600) + 100 as religion_xp,
                FLOOR(RAND() * 3) + 1 as level
            FROM users 
            WHERE user_type = 'student'
            ON DUPLICATE KEY UPDATE
                total_xp = VALUES(total_xp),
                math_xp = VALUES(math_xp),
                science_xp = VALUES(science_xp),
                persian_xp = VALUES(persian_xp),
                social_xp = VALUES(social_xp),
                religion_xp = VALUES(religion_xp)
        ");
        
        if ($createSample->execute()) {
            error_log("Sample XP data created successfully");
            
            // بروزرسانی کل امتیازات
            $updateTotal = $conn->query("
                UPDATE student_xp 
                SET total_xp = math_xp + science_xp + persian_xp + social_xp + religion_xp
            ");
            
            // بروزرسانی سطح
            $updateLevel = $conn->query("
                UPDATE student_xp SET 
                    level = CASE 
                        WHEN total_xp >= 5000 THEN 5
                        WHEN total_xp >= 3000 THEN 4
                        WHEN total_xp >= 2000 THEN 3
                        WHEN total_xp >= 1000 THEN 2
                        ELSE 1
                    END
            ");
            
            // دوباره داده‌ها را بگیریم
            $stmt->execute();
            $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("Sample badges created and loaded: " . count($badges));
        }
    }
    
    // محاسبه آمار کلی
    $totalXP = array_sum(array_column($badges, 'total_xp'));
    $avgXP = count($badges) > 0 ? $totalXP / count($badges) : 0;
    $highestXP = count($badges) > 0 ? max(array_column($badges, 'total_xp')) : 0;
    
    $stats = [
        'total_xp' => $totalXP,
        'avg_xp' => round($avgXP, 0),
        'highest_xp' => $highestXP,
        'student_count' => count($badges)
    ];
    
    // محاسبه مجموع هر موضوع
    $subjectTotals = [
        'math_total' => array_sum(array_column($badges, 'math_xp')),
        'science_total' => array_sum(array_column($badges, 'science_xp')),
        'persian_total' => array_sum(array_column($badges, 'persian_xp')),
        'social_total' => array_sum(array_column($badges, 'social_xp')),
        'religion_total' => array_sum(array_column($badges, 'religion_xp'))
    ];
    
    error_log("Stats calculated - Total XP: $totalXP, Students: " . count($badges));
    
    echo json_encode([
        'success' => true,
        'badges' => $badges,
        'stats' => $stats,
        'subject_totals' => $subjectTotals,
        'debug' => [
            'query_executed' => true,
            'badges_count' => count($badges),
            'sample_badge' => count($badges) > 0 ? $badges[0] : null
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("Error in get-all-badges.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت نشان‌ها: ' . $e->getMessage(),
        'debug' => [
            'session' => $_SESSION ?? 'no session',
            'connection' => isset($conn) ? 'OK' : 'FAILED',
            'error_details' => $e->getTrace()
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>