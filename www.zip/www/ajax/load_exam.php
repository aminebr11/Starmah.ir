<?php
// فایل ajax/load_exam.php - نسخه تصحیح شده برای ساختار واقعی

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// بررسی method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// شروع session
session_start();

// بررسی ورود کاربر
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    echo json_encode(['success' => false, 'message' => 'کاربر وارد نشده است'], JSON_UNESCAPED_UNICODE);
    exit;
}

// بارگذاری config
$configPaths = ['../config.php', '../../config.php', dirname(__DIR__) . '/config.php'];
$configLoaded = false;

foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $configLoaded = true;
        break;
    }
}

if (!$configLoaded || !isset($conn)) {
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به دیتابیس'], JSON_UNESCAPED_UNICODE);
    exit;
}

// خواندن داده ورودی
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['exam_id'])) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر'], JSON_UNESCAPED_UNICODE);
    exit;
}

$examId = (int)$input['exam_id'];
$userId = $_SESSION['user_id'];

// لاگ برای debug
error_log("Loading exam ID: $examId for user: $userId");

try {
    // بررسی وجود آزمون
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ? AND is_active = 1 AND is_visible = 1");
    $stmt->execute([$examId]);
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exam) {
        error_log("Exam not found: $examId");
        echo json_encode(['success' => false, 'message' => 'آزمون یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // بررسی تلاش قبلی
    $stmt = $conn->prepare("SELECT id FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?");
    $stmt->execute([$examId, $userId]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما قبلاً در این آزمون شرکت کرده‌اید'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // دریافت سوالات
    $stmt = $conn->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? AND is_active = 1 ORDER BY id");
    $stmt->execute([$examId]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($questions)) {
        error_log("No questions found for exam: $examId");
        echo json_encode(['success' => false, 'message' => 'سوالی برای این آزمون یافت نشد'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // آماده‌سازی سوالات برای ارسال
    $examQuestions = [];
    foreach ($questions as $question) {
        error_log("Processing question ID: " . $question['id'] . ", Type: " . $question['question_type']);
        error_log("Raw question_data: " . $question['question_data']);
        
        $questionData = [
            'id' => $question['id'],
            'question_text' => $question['question_text'],
            'question_type' => $question['question_type'],
            'points' => (int)$question['points']
        ];
        
        // پردازش question_data
        $rawData = $question['question_data'];
        $parsedData = null;
        
        // تلاش برای پارس JSON
        if (!empty($rawData)) {
            if (is_string($rawData)) {
                $parsedData = json_decode($rawData, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log("JSON decode error for question " . $question['id'] . ": " . json_last_error_msg());
                    $parsedData = null;
                }
            } else {
                $parsedData = $rawData;
            }
        }
        
        // تنظیم داده‌های سوال بر اساس نوع
        if ($question['question_type'] === 'mcq') {
            // سوال چندگزینه‌ای - پردازش ساختار واقعی
            $options = [];
            
            if ($parsedData && isset($parsedData['options']) && is_array($parsedData['options'])) {
                // پردازش ساختار {"text": "گزینه", "correct": true/false}
                foreach ($parsedData['options'] as $option) {
                    if (is_array($option) && isset($option['text'])) {
                        // ساختار object
                        $options[] = $option['text'];
                    } elseif (is_string($option)) {
                        // ساختار string ساده
                        $options[] = $option;
                    }
                }
            } elseif ($parsedData && is_array($parsedData)) {
                // خود parsedData یک array از گزینه‌ها است
                foreach ($parsedData as $option) {
                    if (is_array($option) && isset($option['text'])) {
                        $options[] = $option['text'];
                    } elseif (is_string($option)) {
                        $options[] = $option;
                    }
                }
            }
            
            // اگر گزینه‌ای نداریم، گزینه‌های پیش‌فرض بسازیم
            if (empty($options)) {
                $options = ['گزینه اول', 'گزینه دوم', 'گزینه سوم', 'گزینه چهارم'];
                error_log("No options found for MCQ question " . $question['id'] . ", using defaults");
            }
            
            $questionData['question_data'] = [
                'options' => $options
            ];
            
            error_log("MCQ question " . $question['id'] . " processed with options: " . json_encode($options));
            
        } elseif ($question['question_type'] === 'tf') {
            // سوال درست/نادرست
            $questionData['question_data'] = [
                'type' => 'true_false'
            ];
            
            error_log("T/F question " . $question['id'] . " processed");
            
        } elseif ($question['question_type'] === 'short') {
            // سوال تشریحی
            $questionData['question_data'] = [
                'type' => 'short_answer'
            ];
            
            error_log("Short answer question " . $question['id'] . " processed");
        }
        
        $examQuestions[] = $questionData;
    }
    
    // لاگ نهایی
    error_log("Prepared " . count($examQuestions) . " questions for exam $examId");
    
    // پاسخ موفق
    $response = [
        'success' => true,
        'exam' => [
            'id' => (int)$exam['id'],
            'title' => $exam['title'],
            'duration_minutes' => (int)$exam['duration_minutes'],
            'total_questions' => count($examQuestions)
        ],
        'questions' => $examQuestions
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log("Database error in load_exam.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطای دیتابیس رخ داد'], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    error_log("General error in load_exam.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطایی رخ داد'], JSON_UNESCAPED_UNICODE);
}
?>