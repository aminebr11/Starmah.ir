<?php
// ajax/admin_ajax.php - فایل Ajax برای مدیریت دانش‌آموزان
// این فایل در پوشه ajax است

// شامل کردن فایل‌های config و functions از روت
if (file_exists('../config.php')) {
    require_once '../config.php';
} else {
    die(json_encode(['success' => false, 'message' => 'فایل config.php یافت نشد']));
}

if (file_exists('../functions.php')) {
    require_once '../functions.php';
}

// تنظیم هدر برای JSON
header('Content-Type: application/json');

// لاگ برای دیباگ
error_log('admin_ajax.php called with action: ' . ($_POST['action'] ?? 'none'));

$action = $_POST['action'] ?? '';

switch($action) {
    case 'test':
        echo json_encode(['success' => true, 'message' => 'Ajax کار می‌کند!', 'path' => __FILE__]);
        break;
        
    case 'get_student_data':
        getStudentData();
        break;
        
    case 'update_student':
        updateStudent();
        break;
        
    case 'toggle_student_status':
        toggleStudentStatus();
        break;
        
    case 'delete_student':
        deleteStudent();
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'اکشن نامعتبر: ' . $action]);
        break;
}

function getStudentData() {
    global $conn;
    
    $student_id = $_POST['student_id'] ?? 0;
    
    if (!$student_id) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("
            SELECT u.*, 
                   IFNULL(sx.total_xp, 0) as total_xp,
                   IFNULL(sx.level, 1) as level
            FROM users u 
            LEFT JOIN student_xp sx ON u.id = sx.student_id 
            WHERE u.id = ? AND u.user_type = 'student'
        ");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($student) {
            echo json_encode(['success' => true, 'student' => $student]);
        } else {
            echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'خطا در دریافت اطلاعات: ' . $e->getMessage()]);
    }
}

function updateStudent() {
    global $conn;
    
    $student_id = $_POST['student_id'] ?? 0;
    $username = trim($_POST['username'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $national_id = trim($_POST['national_id'] ?? '');
    $birth_date = $_POST['birth_date'] ?? null;
    $father_name = trim($_POST['father_name'] ?? '');
    $father_phone = trim($_POST['father_phone'] ?? '');
    $mother_name = trim($_POST['mother_name'] ?? '');
    $mother_phone = trim($_POST['mother_phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $is_active = $_POST['is_active'] ?? 1;
    
    if (!$student_id || !$username || !$first_name || !$last_name || !$national_id) {
        echo json_encode(['success' => false, 'message' => 'لطفاً فیلدهای ضروری را پر کنید']);
        return;
    }
    
    try {
        $conn->beginTransaction();
        
        // چک کردن تکراری نبودن نام کاربری و کد ملی
        $stmt = $conn->prepare("SELECT id FROM users WHERE (username = ? OR national_id = ?) AND id != ? AND user_type = 'student'");
        $stmt->execute([$username, $national_id, $student_id]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'نام کاربری یا کد ملی تکراری است']);
            $conn->rollBack();
            return;
        }
        
        // آماده‌سازی کوئری بروزرسانی
        $updateQuery = "
            UPDATE users SET 
                username = ?, 
                first_name = ?, 
                last_name = ?, 
                national_id = ?, 
                birth_date = ?, 
                father_name = ?, 
                father_phone = ?, 
                mother_name = ?, 
                mother_phone = ?, 
                address = ?, 
                is_active = ?";
        
        $params = [
            $username, $first_name, $last_name, $national_id, 
            $birth_date, $father_name, $father_phone, 
            $mother_name, $mother_phone, $address, $is_active
        ];
        
        // اگر رمز عبور جدید وارد شده باشد
        if (!empty($password)) {
            if (strlen($password) < 6) {
                echo json_encode(['success' => false, 'message' => 'رمز عبور باید حداقل 6 کاراکتر باشد']);
                $conn->rollBack();
                return;
            }
            $updateQuery .= ", password = ?";
            $params[] = password_hash($password, PASSWORD_DEFAULT);
        }
        
        $updateQuery .= " WHERE id = ? AND user_type = 'student'";
        $params[] = $student_id;
        
        $stmt = $conn->prepare($updateQuery);
        $stmt->execute($params);
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'اطلاعات دانش‌آموز با موفقیت بروزرسانی شد']);
        
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'خطا در بروزرسانی: ' . $e->getMessage()]);
    }
}

function toggleStudentStatus() {
    global $conn;
    
    $student_id = $_POST['student_id'] ?? 0;
    $current_status = $_POST['current_status'] ?? 0;
    $new_status = $current_status ? 0 : 1;
    
    if (!$student_id) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE id = ? AND user_type = 'student'");
        $stmt->execute([$new_status, $student_id]);
        
        $status_text = $new_status ? 'فعال' : 'غیرفعال';
        echo json_encode(['success' => true, 'new_status' => $new_status, 'status_text' => $status_text]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'خطا در تغییر وضعیت: ' . $e->getMessage()]);
    }
}

function deleteStudent() {
    global $conn;
    
    $student_id = $_POST['student_id'] ?? 0;
    
    if (!$student_id) {
        echo json_encode(['success' => false, 'message' => 'شناسه دانش‌آموز نامعتبر']);
        return;
    }
    
    try {
        $conn->beginTransaction();
        
        // حذف از جدول student_xp
        $stmt = $conn->prepare("DELETE FROM student_xp WHERE student_id = ?");
        $stmt->execute([$student_id]);
        
        // حذف از جدول users
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND user_type = 'student'");
        $stmt->execute([$student_id]);
        
        if ($stmt->rowCount() > 0) {
            $conn->commit();
            echo json_encode(['success' => true, 'message' => 'دانش‌آموز با موفقیت حذف شد']);
        } else {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'دانش‌آموز یافت نشد']);
        }
        
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'خطا در حذف دانش‌آموز: ' . $e->getMessage()]);
    }
}
?>