<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'لطفا وارد شوید']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);
$materialId = intval($data['material_id'] ?? 0);

if (!$materialId) {
    echo json_encode(['success' => false, 'message' => 'شناسه محتوا نامعتبر']);
    exit;
}

try {
    // Check if material exists
    $stmt = $conn->prepare("SELECT id FROM materials WHERE id = ?");
    $stmt->execute([$materialId]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'محتوا یافت نشد']);
        exit;
    }
    
    // Record download
    $stmt = $conn->prepare("
        INSERT INTO material_downloads (material_id, user_id, downloaded_at, ip_address) 
        VALUES (?, ?, NOW(), ?)
    ");
    
    $stmt->execute([
        $materialId,
        $_SESSION['user_id'],
        $_SERVER['REMOTE_ADDR'] ?? ''
    ]);
    
    // Update student activity (give 1 star for downloading educational content)
    if ($_SESSION['user_type'] === 'student') {
        updateStudentScore($conn, $_SESSION['user_id'], 1);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'دانلود ثبت شد'
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ثبت دانلود'
    ]);
}
?>