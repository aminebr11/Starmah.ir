<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json');

// Check if user is admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

try {
    // Create backup directory if not exists
    $backupDir = '../backups';
    if (!file_exists($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    // Protect backup directory with .htaccess
    $htaccessContent = "Order deny,allow\nDeny from all";
    file_put_contents($backupDir . '/.htaccess', $htaccessContent);
    
    // Generate filename
    $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $filepath = $backupDir . '/' . $filename;
    
    // Get all tables
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    while ($row = $result->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }
    
    // Start backup content
    $backup = "-- Database Backup\n";
    $backup .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $backup .= "-- Database: " . DB_NAME . "\n\n";
    $backup .= "SET NAMES utf8mb4;\n";
    $backup .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";
    
    // Process each table
    foreach ($tables as $table) {
        // Get table structure
        $result = $conn->query("SHOW CREATE TABLE `$table`");
        $row = $result->fetch(PDO::FETCH_NUM);
        
        $backup .= "-- Table structure for `$table`\n";
        $backup .= "DROP TABLE IF EXISTS `$table`;\n";
        $backup .= $row[1] . ";\n\n";
        
        // Get table data
        $result = $conn->query("SELECT * FROM `$table`");
        $numFields = $result->columnCount();
        
        if ($result->rowCount() > 0) {
            $backup .= "-- Data for table `$table`\n";
            
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $backup .= "INSERT INTO `$table` VALUES(";
                
                for ($i = 0; $i < $numFields; $i++) {
                    if ($row[$i] === null) {
                        $backup .= "NULL";
                    } else {
                        $backup .= $conn->quote($row[$i]);
                    }
                    
                    if ($i < ($numFields - 1)) {
                        $backup .= ',';
                    }
                }
                
                $backup .= ");\n";
            }
            
            $backup .= "\n";
        }
    }
    
    $backup .= "SET FOREIGN_KEY_CHECKS = 1;\n";
    
    // Save backup file
    if (file_put_contents($filepath, $backup)) {
        // Create a temporary download file
        $tempDir = '../temp';
        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        
        $tempFile = $tempDir . '/' . $filename;
        copy($filepath, $tempFile);
        
        // Generate download URL
        $downloadUrl = 'download-backup.php?file=' . base64_encode($filename);
        
        echo json_encode([
            'success' => true,
            'message' => 'نسخه پشتیبان با موفقیت ایجاد شد',
            'filename' => $filename,
            'size' => formatBytes(filesize($filepath)),
            'download_url' => $downloadUrl
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'خطا در ایجاد فایل پشتیبان'
        ]);
    }
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پشتیبان‌گیری: ' . $e->getMessage()
    ]);
}

// Format bytes to human readable
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>