<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

// لاگ برای دیباگ
error_log("get-students-for-filter.php called");

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    error_log("Access denied - user type: " . ($_SESSION['user_type'] ?? 'not set'));
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit();
}

try {
    // تست اتصال دیتابیس
    if (!isset($conn)) {
        throw new Exception('اتصال به دیتابیس برقرار نیست');
    }
    
    // کوئری ساده برای دریافت دانش‌آموزان
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, national_id 
        FROM users 
        WHERE user_type = 'student' 
        ORDER BY first_name, last_name
    ");
    
    if (!$stmt->execute()) {
        throw new Exception('خطا در اجرای کوئری: ' . implode(', ', $stmt->errorInfo()));
    }
    
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log("Students loaded: " . count($students));
    
    // اگر دانش‌آموزی نداریم
    if (empty($students)) {
        echo json_encode([
            'success' => true,
            'students' => [],
            'message' => 'هیچ دانش‌آموزی در سیستم ثبت نشده'
        ]);
        exit();
    }
    
    // لاگ اولین دانش‌آموز برای تست
    if (!empty($students)) {
        error_log("First student: " . json_encode($students[0]));
    }
    
    echo json_encode([
        'success' => true,
        'students' => $students,
        'count' => count($students)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log("Error in get-students-for-filter.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'خطا در دریافت دانش‌آموزان: ' . $e->getMessage(),
        'debug' => [
            'session' => $_SESSION ?? 'no session',
            'connection' => isset($conn) ? 'OK' : 'FAILED'
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>