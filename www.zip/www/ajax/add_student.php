<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once '../config.php';
require_once '../functions.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode([
        'success' => false, 
        'message' => 'دسترسی غیرمجاز'
    ]);
    exit();
}

try {
    // دریافت داده‌های JSON
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('خطا در پردازش داده‌های ورودی');
    }
    
    // بررسی فیلدهای اجباری
    $requiredFields = ['first_name', 'last_name', 'national_id', 'password'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty(trim($data[$field]))) {
            throw new Exception('لطفاً تمام فیلدهای اجباری را پر کنید');
        }
    }
    
    $firstName = trim($data['first_name']);
    $lastName = trim($data['last_name']);
    $nationalId = trim($data['national_id']);
    $password = trim($data['password']);
    
    // اعتبارسنجی کد ملی
    if (strlen($nationalId) !== 10 || !ctype_digit($nationalId)) {
        throw new Exception('کد ملی باید دقیقاً 10 رقم باشد');
    }
    
    // بررسی تکراری نبودن کد ملی
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE national_id = ?");
    $checkStmt->execute([$nationalId]);
    
    if ($checkStmt->fetch()) {
        throw new Exception('این کد ملی قبلاً در سیستم ثبت شده است');
    }
    
    // اعتبارسنجی رمز عبور
    if (strlen($password) < 3) {
        throw new Exception('رمز عبور باید حداقل 3 کاراکتر باشد');
    }
    
    // هش کردن رمز عبور
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // شروع تراکنش
    $conn->beginTransaction();
    
    try {
        // درج دانش‌آموز جدید
        $insertStmt = $conn->prepare("
            INSERT INTO users (
                username, 
                password, 
                first_name, 
                last_name, 
                national_id, 
                user_type,
                is_active,
                created_at
            ) VALUES (?, ?, ?, ?, ?, 'student', 1, NOW())
        ");
        
        $insertStmt->execute([
            $nationalId,        // نام کاربری = کد ملی
            $hashedPassword,
            $firstName,
            $lastName,
            $nationalId
        ]);
        
        $newStudentId = $conn->lastInsertId();
        
        // ایجاد رکورد در جدول student_xp
        // total_xp و level خودکار محاسبه می‌شوند (STORED GENERATED)
        $xpStmt = $conn->prepare("
            INSERT INTO student_xp (
                student_id,
                math_xp,
                science_xp,
                persian_xp,
                social_xp,
                religion_xp,
                podcast_xp,
                dic_xp,
                other_xp,
                exam_xp
            ) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        ");
        
        $xpStmt->execute([$newStudentId]);
        
        // اتمام تراکنش
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => "✅ دانش‌آموز $firstName $lastName با موفقیت ثبت شد\n🔑 نام کاربری: $nationalId",
            'student_id' => $newStudentId
        ]);
        
    } catch (Exception $e) {
        // برگشت تراکنش در صورت خطا
        $conn->rollBack();
        throw $e;
    }
    
} catch (PDOException $e) {
    error_log("Database Error in add_student.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'خطای پایگاه داده: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in add_student.php: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>