<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
  echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']); exit;
}

try {
  // فقط دانش‌آموزانی که حداقل یک نتیجه دارند
  $sql = "
    SELECT DISTINCT
      u.id,
      u.first_name,
      u.last_name,
      u.national_id
    FROM users u
    JOIN game_results gr ON gr.student_id = u.id
    WHERE u.user_type = 'student'
    ORDER BY u.last_name ASC, u.first_name ASC
  ";
  $stmt = $conn->query($sql);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // تبدیل به آرایه ساده برای فرانت
  $items = array_map(function($r){
    return [
      'id' => (int)$r['id'],
      'full_name' => trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
      'national_id' => $r['national_id'] ?? ''
    ];
  }, $rows);

  echo json_encode(['success'=>true, 'items'=>$items]);
} catch (Throwable $e) {
  echo json_encode(['success'=>false, 'message'=>'DB Error', 'error'=>$e->getMessage()]);
}
