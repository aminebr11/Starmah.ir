<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// بررسی ورود کاربر
if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

 $game_id = (int)($_GET['game_id'] ?? 0);

if (!$game_id) {
    die('شناسه بازی نامعتبر است');
}

// دریافت اطلاعات بازی
try {
    $stmt = $conn->prepare("SELECT * FROM games WHERE id = ? AND is_active = 1");
    $stmt->execute([$game_id]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        die('بازی یافت نشد');
    }
} catch (Exception $e) {
    die('خطا در دریافت اطلاعات بازی');
}

// دریافت اطلاعات کاربر
 $user_id = $_SESSION['user_id'];
 $username = $_SESSION['username'] ?? 'کاربر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($game['title']); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', sans-serif;
            background: #f0f0f0;
            overflow-x: hidden;
        }
        
        .game-wrapper {
            position: relative;
            width: 100%;
            min-height: 100vh;
        }
        
        .game-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 10px 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 50px;
        }
        
        .game-title {
            font-size: 1rem;
            font-weight: bold;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 60%;
        }
        
        .close-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 6px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-family: inherit;
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        
        .close-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .game-content {
            margin-top: 50px;
            min-height: calc(100vh - 50px);
            position: relative;
        }
        
        .result-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            padding: 20px;
        }
        
        .result-content {
            background: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            max-width: 400px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .result-title {
            color: #28a745;
            margin-bottom: 15px;
            font-size: 1.3rem;
        }
        
        .result-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin: 15px 0;
        }
        
        .stat-item {
            background: #f8f9fa;
            padding: 12px 8px;
            border-radius: 10px;
        }
        
        .stat-value {
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.8rem;
            color: #666;
        }
        
        .xp-message {
            background: #fff3cd;
            color: #856404;
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
            display: none;
            font-weight: bold;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-family: inherit;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .btn-primary {
            background: #007bff;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        /* موبایل */
        @media (max-width: 768px) {
            .game-header { padding: 8px 10px; height: 45px; }
            .game-title { font-size: 0.9rem; max-width: 70%; }
            .close-btn { padding: 5px 10px; font-size: 0.8rem; }
            .game-content { margin-top: 45px; min-height: calc(100vh - 45px); }
            .result-content { padding: 15px; margin: 10px; }
            .result-title { font-size: 1.1rem; }
            .result-stats { gap: 8px; }
            .stat-item { padding: 10px 6px; }
            .stat-value { font-size: 1rem; }
            .stat-label { font-size: 0.7rem; }
            .action-buttons { flex-direction: column; gap: 8px; }
            .btn { padding: 10px; font-size: 0.85rem; }
        }
    </style>
</head>
<body>
    <div class="game-wrapper">
        <div class="game-header">
            <div class="game-title"><?php echo htmlspecialchars($game['title']); ?></div>
            <button class="close-btn" onclick="closeGame()">بستن</button>
        </div>
        
        <div class="game-content">
            <?php echo $game['game_code']; ?>
        </div>
    </div>

    <!-- نتایج بازی -->
    <div id="resultOverlay" class="result-overlay">
        <div class="result-content">
            <h2 class="result-title" id="resultTitle">🎉 بازی تمام شد!</h2>
            <div class="result-stats">
                <div class="stat-item">
                    <div class="stat-value" id="finalScore">0</div>
                    <div class="stat-label">امتیاز</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" id="finalTime">0:00</div>
                    <div class="stat-label">زمان</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" id="finalAccuracy">0%</div>
                    <div class="stat-label">دقت</div>
                </div>
            </div>
            <div id="xpMessage" class="xp-message">
                <span id="xpText"></span>
            </div>
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="playAgain()">🔄 بازی مجدد</button>
                <button class="btn btn-secondary" onclick="closeGame()">✅ بستن</button>
            </div>
        </div>
    </div>

    <script>
        // متغیرهای سراسری
        window.GAME_ID = <?php echo $game_id; ?>;
        window.USER_ID = <?php echo $user_id; ?>;
        
        console.log('🎮 بازی بارگذاری شد. شناسه بازی:', window.GAME_ID);

        // ============= تابع اصلی ذخیره نتیجه بازی (اصلاح شده) =============
        window.saveGameResult = function(data) {
            console.log('🔧 [پوسته بازی] تابع saveGameResult فراخوانی شد.');
            console.log('📦 شیء دریافتی از بازی:', data);

            // === بررسی امنیتی برای جلوگیری از خطای undefined ===
            if (!data || typeof data !== 'object') {
                console.error('❌ [پوسته بازی] داده نامعتبر یا undefined دریافت شد. تلاش برای بازیابی از gameState...');
                
                // تلاش برای بازیابی اطلاعات از متغیر gameState بازی
                if (typeof window.gameState !== 'undefined') {
                    data = {
                        game_id: window.GAME_ID,
                        score: window.gameState.score || 0,
                        time_spent: window.gameState.timeElapsed || 0,
                        accuracy: window.gameState.totalQuestions > 0 
                            ? Math.round((window.gameState.correctAnswers / window.gameState.totalQuestions) * 100) 
                            : 0
                    };
                    console.log('✅ [پوسته بازی] داده‌ها با موفقیت از gameState بازیابی شد:', data);
                } else {
                    console.error('❌ [پوسته بازی] gameState نیز یافت نشد. نمی‌توان نتیجه را ذخیره کرد.');
                    alert('خطایی در ثبت نتیجه بازی رخ داد. لطفاً صفحه را رفرش کنید.');
                    return; // توقف اجرای تابع
                }
            }

            // استخراج مقادیر از شیء ورودی
            const gameId = data.game_id || window.GAME_ID;
            const score = data.score || 0;
            const timeSpent = data.time_spent || 0;
            const accuracy = data.accuracy || 0;
            
            console.log('✅ [پوسته بازی] مقادیر نهایی استخراج شده:', {gameId, score, timeSpent, accuracy});

            // نمایش نتیجه در مودال
            showGameResult(score, timeSpent, accuracy);
            
            // آماده‌سازی داده‌ها برای ارسال به سرور
            const payload = {
                game_id: gameId,
                score: score,
                time_spent: timeSpent,
                accuracy: accuracy
            };
            
            console.log('📤 [پوسته بازی] ارسال به سرور:', payload);
            
            fetch('./ajax/save-game-result.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(payload)
            })
            .then(response => {
                console.log('📥 وضعیت پاسخ سرور:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(result => {
                console.log('✅ نتیجه ذخیره:', result);
                
                if (result.success) {
                    if (result.xp_earned && result.xp_earned > 0) {
                        document.getElementById('xpMessage').style.display = 'block';
                        document.getElementById('xpText').textContent = `🌟 ${result.xp_earned} امتیاز تجربه کسب کردید!`;
                    }
                } else {
                    console.error('❌ خطا در ذخیره:', result.message);
                    alert('خطا در ذخیره نتیجه: ' + result.message);
                }
            })
            .catch(error => {
                console.error('❌ خطا در ارسال:', error);
                alert('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید.');
            });
        };

        // ایجاد نام‌های مستعار برای سازگاری با بازی‌های مختلف
        window.onGameComplete = window.saveGameResult;
        window.endGame = window.saveGameResult;
        window.gameFinished = window.saveGameResult;
        window.submitScore = window.saveGameResult;
        window.gameComplete = window.saveGameResult;
        window.finishGame = window.saveGameResult;

        // نمایش نتایج در مودال
        function showGameResult(score, timeSpent, accuracy) {
            console.log('🎨 نمایش نتایج:', {score, timeSpent, accuracy});
            
            const timeMinutes = Math.floor(timeSpent / 60);
            const timeSeconds = timeSpent % 60;
            const timeString = timeMinutes + ':' + timeSeconds.toString().padStart(2, '0');
            
            document.getElementById('finalScore').textContent = score;
            document.getElementById('finalTime').textContent = timeString;
            document.getElementById('finalAccuracy').textContent = accuracy + '%';
            document.getElementById('resultOverlay').style.display = 'flex';
        }
        
        // بازی مجدد
        function playAgain() {
            document.getElementById('resultOverlay').style.display = 'none';
            location.reload();
        }
        
        // بستن بازی
        function closeGame() {
            if (window.opener) {
                try {
                    window.opener.location.reload();
                } catch (e) {
                    console.log('نمی‌توان صفحه اصلی را بروزرسانی کرد');
                }
            }
            window.close();
        }
        
        // جلوگیری از بستن تصادفی
        window.addEventListener('beforeunload', function(e) {
            if (document.getElementById('resultOverlay').style.display === 'flex') {
                return;
            }
            e.preventDefault();
            e.returnValue = '';
        });
        
        console.log('✅ توابع بازی آماده هستند');
    </script>
</body>
</html>