<?php
require_once 'config.php'; // اتصال به دیتابیس
$newPassword = 'ebrAmin30011'; // رمز جدید دلخواه
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = 'admin' AND user_type = 'admin'");
$stmt->execute([$hashedPassword]);
echo "رمز جدید هَش‌شده ذخیره شد: " . $hashedPassword;
?>