<?php
require_once 'config.php'; // یا فایل اتصال به دیتابیس

class QuizModel {
    private $db;

    public function __construct() {
        global $conn; // چون در index.php اتصال با $conn انجام شده
        $this->db = $conn;
    }

    public function getQuiz($quiz_id) {
        $stmt = $this->db->prepare("SELECT id AS quiz_id, title, description, duration_minutes FROM quizzes WHERE id = ?");
        $stmt->execute([$quiz_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getQuestions($quiz_id) {
        $stmt = $this->db->prepare("SELECT id, text FROM questions WHERE quiz_id = ? ORDER BY id");
        $stmt->execute([$quiz_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getChoicesForQuestions($question_ids) {
        $in = implode(',', array_fill(0, count($question_ids), '?'));
        $stmt = $this->db->prepare("SELECT id AS choice_id, question_id, text FROM choices WHERE question_id IN ($in) ORDER BY question_id, id");
        $stmt->execute($question_ids);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}