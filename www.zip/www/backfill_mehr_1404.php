<?php
require_once 'config.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تست داده‌های هفتگی</title>
    <style>
        body { font-family: Tahoma; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        h2 { color: #667eea; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: right; border: 1px solid #ddd; }
        th { background: #667eea; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔍 تست داده‌های هفتگی</h1>

    <?php
    try {
        // 1. بررسی ساختار جدول
        echo "<h2>1️⃣ ساختار جدول weekly_xp_summary</h2>";
        $stmt = $conn->query("DESCRIBE weekly_xp_summary");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table><tr><th>ستون</th><th>نوع</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // 2. تعداد کل رکوردها
        echo "<h2>2️⃣ تعداد کل رکوردها</h2>";
        $count = $conn->query("SELECT COUNT(*) as total FROM weekly_xp_summary")->fetch();
        echo "<div class='success'>تعداد کل رکوردها: <strong>{$count['total']}</strong></div>";
        
        // 3. سال‌های موجود
        echo "<h2>3️⃣ سال‌های موجود</h2>";
        $years = $conn->query("SELECT DISTINCT year FROM weekly_xp_summary ORDER BY year DESC")->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='success'>سال‌ها: " . implode(', ', $years) . "</div>";
        
        // 4. ماه‌های موجود برای هر سال
        echo "<h2>4️⃣ ماه‌های موجود</h2>";
        foreach ($years as $year) {
            $months = $conn->query("SELECT DISTINCT month FROM weekly_xp_summary WHERE year = {$year} ORDER BY month")->fetchAll(PDO::FETCH_COLUMN);
            echo "<div class='success'>سال {$year}: ماه‌های " . implode(', ', $months) . "</div>";
        }
        
        // 5. هفته‌های موجود
        echo "<h2>5️⃣ هفته‌های موجود (10 مورد اخیر)</h2>";
        $stmt = $conn->query("
            SELECT DISTINCT year, month, week_number, week_start_date, COUNT(*) as student_count
            FROM weekly_xp_summary
            GROUP BY year, month, week_number, week_start_date
            ORDER BY year DESC, month DESC, week_number DESC
            LIMIT 10
        ");
        $weeks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table><tr><th>سال</th><th>ماه</th><th>هفته</th><th>تاریخ شروع</th><th>تعداد دانش‌آموزان</th></tr>";
        foreach ($weeks as $week) {
            echo "<tr>";
            echo "<td>{$week['year']}</td>";
            echo "<td>{$week['month']}</td>";
            echo "<td>{$week['week_number']}</td>";
            echo "<td>{$week['week_start_date']}</td>";
            echo "<td>{$week['student_count']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // 6. تست کوئری AJAX برای دریافت ماه‌ها
        echo "<h2>6️⃣ تست دریافت ماه‌ها (برای سال اول)</h2>";
        if (!empty($years)) {
            $testYear = $years[0];
            $stmt = $conn->prepare("SELECT DISTINCT month FROM weekly_xp_summary WHERE year = ? ORDER BY month ASC");
            $stmt->execute([$testYear]);
            $months = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
                           'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
            
            echo "<pre>";
            echo "سال: {$testYear}\n";
            echo "تعداد ماه‌ها: " . count($months) . "\n";
            echo "JSON خروجی:\n";
            $result = [];
            foreach ($months as $m) {
                $result[] = ['value' => $m, 'label' => $monthNames[$m]];
            }
            echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            echo "</pre>";
        }
        
        // 7. تست کوئری AJAX برای دریافت هفته‌ها
        echo "<h2>7️⃣ تست دریافت هفته‌ها</h2>";
        if (!empty($years) && !empty($months)) {
            $testYear = $years[0];
            $testMonth = $months[0];
            
            $stmt = $conn->prepare("
                SELECT DISTINCT week_number, week_start_date 
                FROM weekly_xp_summary 
                WHERE year = ? AND month = ? 
                GROUP BY week_number, week_start_date
                ORDER BY week_number DESC
            ");
            $stmt->execute([$testYear, $testMonth]);
            $weeksData = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<pre>";
            echo "سال: {$testYear}, ماه: {$testMonth}\n";
            echo "تعداد هفته‌ها: " . count($weeksData) . "\n";
            echo "JSON خروجی:\n";
            $result = [];
            foreach ($weeksData as $w) {
                $result[] = [
                    'value' => "{$testYear}-{$testMonth}-{$w['week_number']}", 
                    'label' => "هفته {$w['week_number']}"
                ];
            }
            echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            echo "</pre>";
        }
        
        // 8. تست کوئری اصلی برای یک هفته
        echo "<h2>8️⃣ تست دریافت داده‌های یک هفته</h2>";
        if (!empty($weeksData)) {
            $testWeek = $weeksData[0]['week_number'];
            
            $sql = "
                SELECT 
                    u.id as student_id, 
                    u.first_name, 
                    u.last_name, 
                    COALESCE(w.total_xp, 0) AS total_xp
                FROM users u
                LEFT JOIN weekly_xp_summary w ON u.id = w.student_id 
                    AND w.year = :year AND w.month = :month AND w.week_number = :week
                WHERE u.user_type = 'student' AND u.is_active = 1
                ORDER BY total_xp DESC
                LIMIT 10
            ";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':year' => $testYear,
                ':month' => $testMonth,
                ':week' => $testWeek
            ]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<pre>";
            echo "سال: {$testYear}, ماه: {$testMonth}, هفته: {$testWeek}\n";
            echo "تعداد دانش‌آموزان: " . count($students) . "\n";
            echo "JSON خروجی:\n";
            echo json_encode(['success' => true, 'data' => $students], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            echo "</pre>";
            
            echo "<table><tr><th>ID</th><th>نام</th><th>نام خانوادگی</th><th>امتیاز</th></tr>";
            foreach ($students as $s) {
                echo "<tr>";
                echo "<td>{$s['student_id']}</td>";
                echo "<td>{$s['first_name']}</td>";
                echo "<td>{$s['last_name']}</td>";
                echo "<td>{$s['total_xp']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // 9. بررسی مسیر فایل AJAX
        echo "<h2>9️⃣ بررسی فایل‌های مورد نیاز</h2>";
        $files = [
            'ajax/get_weekly_data_all.php',
            '../ajax/get_weekly_data_all.php',
            'admin/weekly_analysis.php'
        ];
        
        foreach ($files as $file) {
            if (file_exists($file)) {
                echo "<div class='success'>✅ فایل موجود است: {$file}</div>";
            } else {
                echo "<div class='error'>❌ فایل یافت نشد: {$file}</div>";
            }
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>";
        echo "<h3>❌ خطا رخ داد:</h3>";
        echo "<p>{$e->getMessage()}</p>";
        echo "<pre>{$e->getTraceAsString()}</pre>";
        echo "</div>";
    }
    ?>
    
    <hr>
    <a href="admin/weekly_analysis.php" style="display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 10px 0;">
        🎯 رفتن به داشبورد تحلیل
    </a>
</div>
</body>
</html>