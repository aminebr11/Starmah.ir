<?php
// quiz_api.php
session_start();
require_once 'config.php';
require_once 'functions.php';

header('Content-Type: application/json; charset=utf-8');

function respond($ok, $payload = [], $code = 200) {
    http_response_code($code);
    echo json_encode(array_merge(['success'=>$ok], $payload), JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    respond(false, ['message'=>'نیاز به ورود دارید.'], 401);
}

$userId = (int)$_SESSION['user_id'];
$userType = $_SESSION['user_type'] ?? 'student';
$isAdmin = ($userType === 'admin');
$action = $_GET['action'] ?? $_POST['action'] ?? null;

if (!$action) respond(false, ['message'=>'action نامعتبر است.'], 400);

// امنیت: فقط ادمین
function must_admin($isAdmin) {
    if (!$isAdmin) respond(false, ['message'=>'دسترسی غیرمجاز.'], 403);
}

try {

    if ($action === 'create_quiz') {
        must_admin($isAdmin);
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) respond(false, ['message'=>'داده نامعتبر.'], 400);

        $title = trim($data['title'] ?? '');
        $description = trim($data['description'] ?? '');
        $question_count = (int)($data['question_count'] ?? 0);
        $time_limit_min = (int)($data['time_limit_min'] ?? 0);
        $status = $data['status'] ?? 'draft';
        $start_at = $data['start_at'] ?? null;
        $end_at = $data['end_at'] ?? null;

        $show_explanations = $data['show_explanations'] ?? 'after_submit';
        $shuffle_questions = (int)($data['shuffle_questions'] ?? 1);
        $shuffle_options = (int)($data['shuffle_options'] ?? 0);
        $neg_enabled = (int)($data['negative_marking_enabled'] ?? 0);
        $neg_value = (float)($data['negative_per_wrong'] ?? 0);

        $allowedCounts = [5,10,15,20,25,30];
        if ($title==='' || !in_array($question_count, $allowedCounts, true) || $time_limit_min<1) {
            respond(false, ['message'=>'عنوان/تعداد سوال/زمان نامعتبر است.'], 400);
        }

        // محدودیت ۲۰ آزمون فعال
        if ($status==='active') {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM quizzes WHERE created_by=? AND status='active'");
            $stmt->execute([$userId]);
            $activeCount = (int)$stmt->fetchColumn();
            if ($activeCount >= 20) {
                respond(false, ['message'=>'حداکثر ۲۰ آزمون فعال مجاز است.'], 400);
            }
        }

        $time_limit_sec = $time_limit_min * 60;

        // ایجاد آزمون
        $stmt = $conn->prepare("INSERT INTO quizzes (title, description, question_count, time_limit_sec, status, start_at, end_at, created_by, show_explanations, shuffle_questions, shuffle_options, negative_marking_enabled, negative_per_wrong) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $ok = $stmt->execute([
            $title, $description, $question_count, $time_limit_sec, $status, $start_at, $end_at, $userId,
            $show_explanations, $shuffle_questions, $shuffle_options, $neg_enabled, $neg_value
        ]);
        if (!$ok) respond(false, ['message'=>'خطا در ایجاد آزمون.'], 500);
        $quizId = (int)$conn->lastInsertId();

        // دو حالت: سوال‌های دستی یا وارد کردن از بانک
        $questions = $data['questions'] ?? [];
        $fromBank = $data['random_from_bank'] ?? null; // {subject, grade, difficulty?, tags?, count}

        if ($fromBank && empty($questions)) {
            $subject = trim($fromBank['subject'] ?? '');
            $grade = trim($fromBank['grade'] ?? '');
            $difficulty = $fromBank['difficulty'] ?? null;
            $tags = $fromBank['tags'] ?? null;

            if ($subject==='' || $grade==='') {
                respond(false, ['message'=>'برای بانک سوال، درس و پایه الزامی است.'], 400);
            }

            // انتخاب تصادفی
            $sql = "SELECT * FROM question_bank WHERE subject=? AND grade=?";
            $params = [$subject, $grade];
            if (!empty($difficulty)) { $sql .= " AND difficulty=?"; $params[]=$difficulty; }
            if (!empty($tags)) {
                // فیلتر ساده: هر تگی در رشته tags وجود داشته باشد
                // مثلا tags = "جمع,اعداد"
                foreach (explode(',', $tags) as $tg) {
                    $sql .= " AND tags LIKE ?";
                    $params[] = '%'.trim($tg).'%';
                }
            }
            $sql .= " ORDER BY RAND() LIMIT ?";
            $params[] = $question_count;

            $stmt = $conn->prepare($sql);
            // PDO نمی‌پذیرد LIMIT با bind عادی روی بعضی نسخه‌ها؛ تبدیل آخرین به int
            $limit = array_pop($params);
            foreach ($params as $k=>$v) {
                $stmt->bindValue($k+1, $v);
            }
            $stmt->bindValue(count($params)+1, (int)$limit, PDO::PARAM_INT);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (count($rows) < $question_count) {
                respond(false, ['message'=>'تعداد سوال کافی در بانک وجود ندارد.'], 400);
            }
            $questions = array_map(function($r){
                return [
                    'question_text'=>$r['question_text'],
                    'option_a'=>$r['option_a'],
                    'option_b'=>$r['option_b'],
                    'option_c'=>$r['option_c'],
                    'option_d'=>$r['option_d'],
                    'correct_option'=>$r['correct_option'],
                    'explanation'=>$r['explanation'],
                    'points'=>(int)$r['points']
                ];
            }, $rows);
        }

        if (count($questions) !== $question_count) {
            respond(false, ['message'=>'تعداد سوال‌ها با انتخاب شما همخوانی ندارد.'], 400);
        }

        $qIns = $conn->prepare("INSERT INTO quiz_questions (quiz_id, order_index, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, points) VALUES (?,?,?,?,?,?,?,?,?,?)");
        foreach ($questions as $i=>$q) {
            $qt = trim($q['question_text'] ?? '');
            $a = trim($q['option_a'] ?? '');
            $b = trim($q['option_b'] ?? '');
            $c = trim($q['option_c'] ?? '');
            $d = trim($q['option_d'] ?? '');
            $co = $q['correct_option'] ?? '';
            $ex = trim($q['explanation'] ?? '');
            $pt = (int)($q['points'] ?? 1);
            if ($qt==='' || $a==='' || $b==='' || $c==='' || $d==='' || !in_array($co, ['A','B','C','D'], true)) {
                respond(false, ['message'=>'سوال/گزینه‌ها صحیح وارد نشده‌اند.'], 400);
            }
            $qIns->execute([$quizId, $i+1, $qt, $a, $b, $c, $d, $co, $ex, $pt]);
        }

        respond(true, ['message'=>'آزمون ایجاد شد.', 'quiz_id'=>$quizId]);
    }

    if ($action === 'get_quizzes') {
        $scopeAdmin = $isAdmin && (($_GET['scope'] ?? '')==='admin');
        if ($scopeAdmin) {
            $stmt = $conn->prepare("SELECT q.*, (SELECT COUNT(*) FROM quiz_attempts a WHERE a.quiz_id=q.id AND a.status='submitted') attempts_count FROM quizzes q WHERE q.created_by=? ORDER BY q.created_at DESC");
            $stmt->execute([$userId]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            respond(true, ['quizzes'=>$rows]);
        } else {
            $now = date('Y-m-d H:i:s');
            $stmt = $conn->prepare("SELECT * FROM quizzes WHERE status='active' AND (start_at IS NULL OR start_at<=?) AND (end_at IS NULL OR end_at>=?) ORDER BY created_at DESC");
            $stmt->execute([$now, $now]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            respond(true, ['quizzes'=>$rows]);
        }
    }

    if ($action === 'get_quiz') {
        $quizId = (int)($_GET['quiz_id'] ?? 0);
        if ($quizId<=0) respond(false, ['message'=>'quiz_id نامعتبر'], 400);

        $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id=?");
        $stmt->execute([$quizId]);
        $quiz = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$quiz) respond(false, ['message'=>'آزمون یافت نشد.'], 404);

        if (!$isAdmin) {
            $now = date('Y-m-d H:i:s');
            if ($quiz['status']!=='active' || ($quiz['start_at'] && $quiz['start_at']>$now) || ($quiz['end_at'] && $quiz['end_at']<$now)) {
                respond(false, ['message'=>'این آزمون در دسترس نیست.'], 403);
            }
        }

        $qStmt = $conn->prepare("SELECT id, order_index, question_text, option_a, option_b, option_c, option_d, points ".($isAdmin?", correct_option, explanation":"")." FROM quiz_questions WHERE quiz_id=? ORDER BY order_index ASC");
        $qStmt->execute([$quizId]);
        $questions = $qStmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$isAdmin) {
            // حذف پاسخ صحیح/توضیح برای دانش‌آموز
            foreach ($questions as &$q) { unset($q['correct_option'], $q['explanation']); }
            // تصادفی‌سازی سوال‌ها
            if ((int)$quiz['shuffle_questions']===1) shuffle($questions);
        }

        respond(true, ['quiz'=>$quiz, 'questions'=>$questions]);
    }

    if ($action === 'submit_attempt') {
        if ($isAdmin) respond(false, ['message'=>'ارسال پاسخ توسط دانش‌آموز انجام می‌شود.'], 403);
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) respond(false, ['message'=>'داده نامعتبر.'], 400);

        $quizId = (int)($data['quiz_id'] ?? 0);
        $answers = $data['answers'] ?? [];
        $duration_sec = (int)($data['duration_sec'] ?? 0);
        if ($quizId<=0 || empty($answers)) respond(false, ['message'=>'اطلاعات کافی نیست.'], 400);

        // کلید تصحیح
        $qStmt = $conn->prepare("SELECT qz.negative_marking_enabled, qz.negative_per_wrong, qq.id, qq.correct_option, qq.points 
                                 FROM quizzes qz JOIN quiz_questions qq ON qq.quiz_id=qz.id WHERE qz.id=?");
        $qStmt->execute([$quizId]);
        $rows = $qStmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) respond(false, ['message'=>'آزمون نامعتبر.'], 400);

        $negEnabled = (int)$rows[0]['negative_marking_enabled']===1;
        $negValue = (float)$rows[0]['negative_per_wrong'];
        $key = [];
        $maxScore = 0;
        foreach ($rows as $r) {
            $qid = (int)$r['id'];
            $key[$qid] = ['correct'=>$r['correct_option'], 'points'=>(int)$r['points']];
            $maxScore += (int)$r['points'];
        }

        // ایجاد تلاش و پاسخ‌ها
        $stmt = $conn->prepare("INSERT INTO quiz_attempts (quiz_id, student_id, submitted_at, duration_sec, score, max_score, status) VALUES (?,?,?,?,?,?, 'submitted')");
        $score = 0.0;

        $detail = [];
        foreach ($answers as $a) {
            $qid = (int)($a['question_id'] ?? 0);
            $sel = $a['selected_option'] ?? null;
            if (!$qid || !isset($key[$qid]) || !in_array($sel, ['A','B','C','D', null], true)) continue;

            $isCorrect = ($sel !== null && $sel === $key[$qid]['correct']) ? 1 : 0;
            if ($isCorrect) $score += $key[$qid]['points'];
            else if ($sel !== null && $negEnabled) $score -= $negValue; // نمره منفی برای پاسخ غلط

            $detail[] = [$qid, $sel, $isCorrect];
        }
        // حداقل صفر؟ اگر می‌خواهی فعال باشد، این خط را Uncomment کن:
        // if ($score < 0) $score = 0;

        $submittedAt = date('Y-m-d H:i:s');
        $stmt->execute([$quizId, $userId, $submittedAt, $duration_sec, $score, $maxScore]);
        $attemptId = (int)$conn->lastInsertId();

        $aIns = $conn->prepare("INSERT INTO quiz_attempt_answers (attempt_id, question_id, selected_option, is_correct) VALUES (?,?,?,?)");
        foreach ($detail as $d) $aIns->execute([$attemptId, $d[0], $d[1], $d[2]]);

        respond(true, ['message'=>'ارسال شد.', 'score'=>$score, 'max_score'=>$maxScore, 'attempt_id'=>$attemptId]);
    }

    if ($action === 'get_results') {
        must_admin($isAdmin);
        $quizId = (int)($_GET['quiz_id'] ?? 0);
        if ($quizId<=0) respond(false, ['message'=>'quiz_id نامعتبر.'], 400);

        // توجه: نام جدول users باید با دیتابیس شما یکی باشد
        $stmt = $conn->prepare("SELECT a.id, a.student_id, a.started_at, a.submitted_at, a.duration_sec, a.score, a.max_score,
                                       u.first_name, u.last_name, u.national_id
                                FROM quiz_attempts a
                                LEFT JOIN users u ON u.id=a.student_id
                                WHERE a.quiz_id=?
                                ORDER BY a.submitted_at DESC");
        $stmt->execute([$quizId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond(true, ['attempts'=>$rows]);
    }

    if ($action === 'delete_quiz') {
        must_admin($isAdmin);
        $quizId = (int)($_POST['quiz_id'] ?? 0);
        if ($quizId<=0) respond(false, ['message'=>'quiz_id نامعتبر.'], 400);

        $stmt = $conn->prepare("DELETE FROM quizzes WHERE id=? AND created_by=?");
        $stmt->execute([$quizId, $userId]);
        respond(true, ['message'=>'آزمون حذف شد.']);
    }

    if ($action === 'update_quiz_status') {
        must_admin($isAdmin);
        $quizId = (int)($_POST['quiz_id'] ?? 0);
        $newStatus = $_POST['status'] ?? 'draft';
        if (!in_array($newStatus, ['draft','active','archived'], true)) respond(false, ['message'=>'وضعیت نامعتبر.'], 400);

        if ($newStatus==='active') {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM quizzes WHERE created_by=? AND status='active' AND id<>?");
            $stmt->execute([$userId, $quizId]);
            $activeCount = (int)$stmt->fetchColumn();
            if ($activeCount >= 20) respond(false, ['message'=>'حداکثر ۲۰ آزمون فعال مجاز است.'], 400);
        }

        $stmt = $conn->prepare("UPDATE quizzes SET status=? WHERE id=? AND created_by=?");
        $stmt->execute([$newStatus, $quizId, $userId]);
        respond(true, ['message'=>'وضعیت بروزرسانی شد.']);
    }

    // مدیریت بانک سوال
    if ($action === 'create_bank_question') {
        must_admin($isAdmin);
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) respond(false, ['message'=>'داده نامعتبر.'], 400);

        $subject = trim($data['subject'] ?? '');
        $grade = trim($data['grade'] ?? '');
        $difficulty = $data['difficulty'] ?? 'easy';
        $tags = trim($data['tags'] ?? '');
        $qt = trim($data['question_text'] ?? '');
        $a = trim($data['option_a'] ?? '');
        $b = trim($data['option_b'] ?? '');
        $c = trim($data['option_c'] ?? '');
        $d = trim($data['option_d'] ?? '');
        $co = $data['correct_option'] ?? '';
        $ex = trim($data['explanation'] ?? '');
        $pt = (int)($data['points'] ?? 1);

        if ($subject==='' || $grade==='' || $qt==='' || $a==='' || $b==='' || $c==='' || $d==='' || !in_array($co,['A','B','C','D'],true)) {
            respond(false, ['message'=>'فیلدهای سوال ناقص است.'], 400);
        }

        $stmt = $conn->prepare("INSERT INTO question_bank (subject, grade, difficulty, tags, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, points, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$subject,$grade,$difficulty,$tags,$qt,$a,$b,$c,$d,$co,$ex,$pt,$userId]);
        respond(true, ['message'=>'سوال به بانک افزوده شد.','id'=>(int)$conn->lastInsertId()]);
    }

    if ($action === 'list_bank_questions') {
        must_admin($isAdmin);
        $subject = trim($_GET['subject'] ?? '');
        $grade = trim($_GET['grade'] ?? '');
        $difficulty = $_GET['difficulty'] ?? null;
        $tags = $_GET['tags'] ?? null;

        $sql = "SELECT * FROM question_bank WHERE 1=1";
        $params = [];
        if ($subject!==''){ $sql.=" AND subject=?"; $params[]=$subject; }
        if ($grade!==''){ $sql.=" AND grade=?"; $params[]=$grade; }
        if (!empty($difficulty)){ $sql.=" AND difficulty=?"; $params[]=$difficulty; }
        if (!empty($tags)) {
            foreach (explode(',', $tags) as $tg) {
                $sql.=" AND tags LIKE ?"; $params[]='%'.trim($tg).'%';
            }
        }
        $sql.=" ORDER BY created_at DESC LIMIT 200";

        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond(true, ['questions'=>$rows]);
    }

    respond(false, ['message'=>'عملیات ناشناخته.'], 400);

} catch (Exception $e) {
    error_log('QUIZ API ERROR: '.$e->getMessage());
    respond(false, ['message'=>'خطای سرور.'], 500);
}