<?php

// Security functions
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}


function generateHash($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Authentication functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}
// این کد را در فایل functions.php اضافه کنید
if (!function_exists('isAdmin')) {
    /**
     * بررسی می‌کند که آیا کاربر فعلی ادمین است یا خیر
     * @return bool
     */
    function isAdmin() {
        // **مهم:** این تابع فرض می‌کند که وقتی کاربر ادمین لاگین می‌کند،
        // در سشن او یک کلید به نام 'user_role' با مقدار 'admin' وجود دارد.
        // اگر از نام دیگری استفاده می‌کنید، لطفاً آن را در اینجا اصلاح کنید.
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
}
function isAdmin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit();
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header('Location: index.php');
        exit();
    }
}

// User functions
function getUserById($conn, $userId) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function createUser($conn, $data) {
    $sql = "INSERT INTO users (username, password, first_name, last_name, email, user_type, national_id, birth_date, address, father_name, father_phone, mother_name, mother_phone, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        $data['username'],
        generateHash($data['password']),
        $data['first_name'],
        $data['last_name'],
        $data['email'] ?? null,
        'student',
        $data['national_id'],
        $data['birth_date'],
        $data['address'],
        $data['father_name'],
        $data['father_phone'],
        $data['mother_name'],
        $data['mother_phone']
    ]);
}

// Statistics functions
// Statistics functions - اصلاح تابع getHomeStatistics
function getHomeStatistics($conn) {
    $stats = [];
    
    // Get top students
    $stmt = $conn->prepare("
        SELECT u.first_name, u.last_name, s.total_score 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        ORDER BY s.total_score DESC 
        LIMIT 3
    ");
    $stmt->execute();
    $topStudents = $stmt->fetchAll();
    
    $stats['topStudents'] = [];
    $ranks = ['🥇', '🥈', '🥉'];
    foreach($topStudents as $index => $student) {
        $stats['topStudents'][] = [
            'rank' => $ranks[$index],
            'name' => $student['first_name'] . ' ' . $student['last_name'],
            'score' => $student['total_score']
        ];
    }
    
    // Get weekly stats
    $stmt = $conn->prepare("
        SELECT 
            COUNT(DISTINCT e.id) as exercises,
            COUNT(DISTINCT g.id) as games,
            SUM(s.weekly_stars) as stars
        FROM students s
        LEFT JOIN exercises_completed e ON s.user_id = e.student_id AND e.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        LEFT JOIN games_played g ON s.user_id = g.student_id AND g.played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $weekStats = $stmt->fetch();
    
    $stats['exercisesCompleted'] = $weekStats['exercises'] ?? 0;
    $stats['gamesPlayed'] = $weekStats['games'] ?? 0;
    $stats['totalStars'] = $weekStats['stars'] ?? 0;
    
    // اصلاح: دریافت تکالیف امروز (تکالیف با تاریخ تحویل امروز یا آینده)
    try {
        $stmt = $conn->prepare("
     SELECT title, due_date, subject
     FROM homework 
     ORDER BY created_at DESC 
     LIMIT 3
     ");
        $stmt->execute();
        $homeworks = $stmt->fetchAll();
        
        $stats['todaysHomework'] = [];
        foreach($homeworks as $hw) {
            $stats['todaysHomework'][] = [
                'title' => $hw['title'],
                'due_date' => convertToJalali($hw['due_date']),
                'subject' => $hw['subject']
            ];
        }
    } catch (PDOException $e) {
        // در صورت خطا، آرایه خالی برگردان
        $stats['todaysHomework'] = [];
        error_log("Error getting today's homework: " . $e->getMessage());
    }
    
    // اگر تکلیف امروز نداریم، پیام مناسب نمایش دهیم
    if (empty($stats['todaysHomework'])) {
        $stats['todaysHomework'] = [
            ['title' => 'امروز تکلیف جدیدی نداریم! 🎉', 'due_date' => '', 'subject' => '']
        ];
    }
    
    return $stats;
}
// Content functions
function getMaterials($conn, $subject = null) {
    $sql = "SELECT * FROM materials";
    if ($subject) {
        $sql .= " WHERE subject = ?";
    }
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if ($subject) {
        $stmt->execute([$subject]);
    } else {
        $stmt->execute();
    }
    
    return $stmt->fetchAll();
}

/**
 * دریافت لیست پادکست‌ها
 * اگر کاربر ادمین باشد، همه پادکست‌ها را برمی‌گرداند
 * در غیر این صورت، فقط پادکست‌های فعال را برمی‌گرداند
 * @param PDO $conn اتصال به دیتابیس
 * @return array
 */
function getPodcasts($conn) {
    // کوئری پایه
    $sql = "SELECT * FROM podcasts";
    
    // اگر کاربر ادمین نباشد، فقط پادکست‌های فعال را انتخاب کن
    if (!function_exists('isAdmin')) {
        // اگر تابع isAdmin تعریف نشده بود، فرض کن کاربر عادی است
        $sql .= " WHERE is_active = 1";
    } elseif (!isAdmin()) {
        $sql .= " WHERE is_active = 1";
    }
    
    // مرتب‌سازی بر اساس جدیدترین
    $sql .= " ORDER BY created_at DESC";
    
    try {
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching podcasts: " . $e->getMessage());
        return []; // در صورت خطا، یک آرایه خالی برگردان
    }
}

function getGalleryItems($conn) {
    $stmt = $conn->prepare("SELECT * FROM gallery ORDER BY created_at DESC");
    $stmt->execute();
    return $stmt->fetchAll();
}

function getHomeworks($conn) {
    try {
        $stmt = $conn->prepare("SELECT * FROM homework ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}


// Feedback functions
function saveFeedback($conn, $data) {
    $sql = "INSERT INTO feedback (parent_name, student_name, subject, message, created_at) VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        $data['parent_name'],
        $data['student_name'],
        $data['subject'],
        $data['message']
    ]);
}

function getFeedbacks($conn, $status = null) {
    $sql = "SELECT * FROM feedback";
    if ($status) {
        $sql .= " WHERE status = ?";
    }
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $conn->prepare($sql);
    if ($status) {
        $stmt->execute([$status]);
    } else {
        $stmt->execute();
    }
    
    return $stmt->fetchAll();
}

// --- Date Conversion Functions ---

function convertToJalali($gregorianDate) {
    if (empty($gregorianDate) || $gregorianDate == '0000-00-00 00:00:00' || $gregorianDate == '0000-00-00') {
        return '';
    }
    $timestamp = strtotime($gregorianDate);
    if ($timestamp === false) {
        return '';
    }

    $g_y = date('Y', $timestamp);
    $g_m = date('m', $timestamp);
    $g_d = date('d', $timestamp);

    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;

    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);

    for ($i = 0; $i < $gm; ++$i)
        $g_day_no += $g_days_in_month[$i];
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
        $g_day_no++;
    $g_day_no += $gd;

    $j_day_no = $g_day_no - 79;
    $j_np = floor($j_day_no / 12053);
    $j_day_no = $j_day_no % 12053;

    $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += floor(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
        $j_day_no -= $j_days_in_month[$i];
    $jm = $i + 1;
    $jd = $j_day_no + 1;

    return "$jy/$jm/$jd";
}

function jalali_to_gregorian($jalali_date) {
    if(empty($jalali_date)) return null;
    $parts = explode('/', $jalali_date);
    if (count($parts) !== 3) return null;

    list($jy, $jm, $jd) = array_map('intval', $parts);

    $j_days_in_month = [0, 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];

    $jy += 1595;
    $days = -355668 + (365 * $jy) + (((int)($jy / 33)) * 8) + ((int)((($jy % 33) + 3) / 4)) + $jd;
    if ($jm > 1) {
        for ($i = 1; $i < $jm; ++$i) {
            $days += $j_days_in_month[$i];
        }
    }
    
    $gy = 400 * ((int)($days / 146097));
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * ((int)(--$days / 36524));
        $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $gy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    $gd = $days + 1;
    $g_days_in_month = [0, 31, (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for ($gm = 1; $gm < 13 && $gd > $g_days_in_month[$gm]; $gm++) {
        $gd -= $g_days_in_month[$gm];
    }

    return sprintf("%04d-%02d-%02d", $gy, $gm, $gd);
}


function uploadFile($file, $directory, $allowedTypes = []) {
    $uploadDir = '../uploads/' . $directory . '/';
    
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // اگر آرایه allowedTypes خالی است، همه فایل‌ها مجاز هستند
    if (!empty($allowedTypes) && !in_array($fileExtension, $allowedTypes)) {
        return ['success' => false, 'message' => 'نوع فایل مجاز نیست'];
    }
    
    $fileName = uniqid() . '_' . time() . '.' . $fileExtension;
    $filePath = $uploadDir . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        return ['success' => true, 'path' => 'uploads/' . $directory . '/' . $fileName, 'filename' => $fileName];
    }
    
    return ['success' => false, 'message' => 'خطا در آپلود فایل'];
}

// Admin statistics
function getAdminStats($conn) {
    $stats = [];
    
    // Total students
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE user_type = 'student'");
    $stmt->execute();
    $stats['totalStudents'] = $stmt->fetch()['count'];
    
    // New feedbacks
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM feedback WHERE status = 'pending'");
    $stmt->execute();
    $stats['newFeedbacks'] = $stmt->fetch()['count'];
    
    // Total content
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM materials");
    $stmt->execute();
    $stats['totalContent'] = $stmt->fetch()['count'];
    
    // Today's visits
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM visits WHERE DATE(visit_date) = CURDATE()");
    $stmt->execute();
    $stats['todayVisits'] = $stmt->fetch()['count'] ?? 0; // Add null check
    
    return $stats;
}

// Score management
function updateStudentScore($conn, $studentId, $points) {
    $stmt = $conn->prepare("UPDATE students SET total_score = total_score + ?, weekly_stars = weekly_stars + ? WHERE user_id = ?");
    return $stmt->execute([$points, $points, $studentId]);
}

// Game tracking
function recordGamePlay($conn, $studentId, $gameType, $score) {
    $stmt = $conn->prepare("INSERT INTO games_played (student_id, game_type, score, played_at) VALUES (?, ?, ?, NOW())");
    return $stmt->execute([$studentId, $gameType, $score]);
}

// Exercise tracking
function recordExerciseCompletion($conn, $studentId, $subject, $exerciseId) {
    $stmt = $conn->prepare("INSERT INTO exercises_completed (student_id, subject, exercise_id, completed_at) VALUES (?, ?, ?, NOW())");
    return $stmt->execute([$studentId, $subject, $exerciseId]);
}

// Student dashboard data
function getStudentDashboardData($conn, $userId) {
    $data = [];
    
    // Get student info
    $stmt = $conn->prepare("
        SELECT s.*, 
        (SELECT COUNT(*) + 1 FROM students s2 WHERE s2.total_score > s.total_score) as class_rank
        FROM students s 
        WHERE s.user_id = ?
    ");
    $stmt->execute([$userId]);
    $studentInfo = $stmt->fetch();
    
    if ($studentInfo) {
        $data['total_score'] = $studentInfo['total_score'];
        $data['weekly_stars'] = $studentInfo['weekly_stars'];
        $data['class_rank'] = $studentInfo['class_rank'];
    }
    
    // Get recent activities
    $stmt = $conn->prepare("
        SELECT COUNT(*) as homework_count 
        FROM exercises_completed 
        WHERE student_id = ? AND completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute([$userId]);
    $homework = $stmt->fetch();
    $data['homework_completed'] = $homework['homework_count'] ?? 0;
    
    // Get games played this month
    $stmt = $conn->prepare("
        SELECT COUNT(*) as games_count 
        FROM games_played 
        WHERE student_id = ? AND played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$userId]);
    $games = $stmt->fetch();
    $data['games_played'] = $games['games_count'] ?? 0;
    
    // Get subject progress
    $subjects = ['math', 'science', 'persian', 'social', 'religion'];
    $data['subject_progress'] = [];
    
    foreach($subjects as $subject) {
        $stmt = $conn->prepare("
            SELECT COUNT(*) as completed 
            FROM exercises_completed 
            WHERE student_id = ? AND subject = ?
        ");
        $stmt->execute([$userId, $subject]);
        $result = $stmt->fetch();
        
        $percentage = min(100, (($result['completed'] ?? 0) / 20) * 100);
        $data['subject_progress'][$subject] = round($percentage);
    }
    
    return $data;
}

// Create initial directories
function createRequiredDirectories() {
    $directories = [
        'uploads',
        'uploads/materials',
        'uploads/podcasts', 
        'uploads/gallery',
        'uploads/homework',
        'sections',
        'ajax'
    ];
    
    foreach($directories as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

// Get about page settings
function getAboutSettings($conn) {
    $stmt = $conn->prepare("SELECT * FROM about_settings LIMIT 1");
    $stmt->execute();
    $settings = $stmt->fetch();
    
    if (!$settings) {
        return [
            'teacher_name' => 'خانم نجمه محمودی',
            'teacher_title' => 'معلم پایه چهارم ابتدایی',
            'teacher_education' => 'کارشناسی ارشد آموزش ابتدایی',
            'teacher_experience' => '15 سال سابقه تدریس',
            'teacher_awards' => 'برنده جایزه معلم نمونه کشوری',
            'teacher_quote' => 'من معتقدم هر کودک مثل یک ستاره است که با آموزش و محبت می‌تواند بدرخشد.',
            'school_address' => 'تهران، منطقه 6، خیابان ولیعصر، دبستان ستاره ماه',
            'school_phone' => '021-88123456',
            'school_mobile' => '09121234567',
            'school_email' => 'info@starmah.ir',
            'response_hours' => 'شنبه تا چهارشنبه: 14-16، پنج‌شنبه: 10-12'
        ];
    }
    
    return $settings;
}

// Update about page settings
function updateAboutSettings($conn, $data) {
    $sql = "UPDATE about_settings SET 
            teacher_name = ?, teacher_title = ?, teacher_education = ?,
            teacher_experience = ?, teacher_awards = ?, teacher_quote = ?,
            school_address = ?, school_phone = ?, school_mobile = ?,
            school_email = ?, response_hours = ?
            WHERE id = 1";
    
    $stmt = $conn->prepare($sql);
    return $stmt->execute([
        $data['teacher_name'], $data['teacher_title'], $data['teacher_education'],
        $data['teacher_experience'], $data['teacher_awards'], $data['teacher_quote'],
        $data['school_address'], $data['school_phone'], $data['school_mobile'],
        $data['school_email'], $data['response_hours']
    ]);
}
// اضافه کردن این تابع به انتهای functions.php موجود

/**
 * Get user details for dropdown display
 */
function getUserDetails($conn, $user_id) {
    try {
        $stmt = $conn->prepare("SELECT first_name, last_name, national_id, birth_date, email, user_type, created_at FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting user details: " . $e->getMessage());
        return null;
    }
}
// Get unviewed discipline count for student
function getUnviewedDisciplineCount($conn, $studentId) {
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM discipline_records WHERE student_id = ? AND viewed = 0");
    $stmt->execute([$studentId]);
    return $stmt->fetch()['count'] ?? 0;
}

// Get discipline records for student
function getStudentDisciplineRecords($conn, $studentId) {
    $stmt = $conn->prepare("SELECT * FROM discipline_records WHERE student_id = ? ORDER BY date DESC");
    $stmt->execute([$studentId]);
    return $stmt->fetchAll();
}

// Mark disciplines as viewed
function markDisciplinesViewed($conn, $studentId) {
    $stmt = $conn->prepare("UPDATE discipline_records SET viewed = 1 WHERE student_id = ? AND viewed = 0");
    $stmt->execute([$studentId]);
}

// For admin: Get all discipline records
function getAllDisciplineRecords($conn) {
    $stmt = $conn->prepare("
        SELECT dr.*, u.first_name, u.last_name 
        FROM discipline_records dr 
        JOIN users u ON dr.student_id = u.id 
        ORDER BY dr.date DESC
    ");
    $stmt->execute();
    return $stmt->fetchAll();
}

// Update discipline record (for admin)
function updateDisciplineRecord($conn, $id, $title, $score, $description) {
    $stmt = $conn->prepare("UPDATE discipline_records SET title = ?, score = ?, description = ? WHERE id = ?");
    return $stmt->execute([$title, $score, $description, $id]);
}

// Delete discipline record (for admin)
function deleteDisciplineRecord($conn, $id) {
    $stmt = $conn->prepare("DELETE FROM discipline_records WHERE id = ?");
    return $stmt->execute([$id]);
}
?>
<?php
// توابع جدید برای اضافه کردن به فایل functions.php موجود

/**
 * دریافت اطلاعات بازی بر اساس شناسه
 */
function getGameById($conn, $game_id) {
    try {
        $stmt = $conn->prepare("
            SELECT g.*, gc.name as category_name, gc.icon as category_icon, gc.color as category_color 
            FROM games g 
            LEFT JOIN game_categories gc ON g.category_id = gc.id 
            WHERE g.id = ? AND g.is_active = 1
        ");
        $stmt->execute([$game_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting game: " . $e->getMessage());
        return false;
    }
}

/**
 * دریافت فهرست بازی‌ها با فیلتر
 */
function getGames($conn, $filters = []) {
    try {
        $where_conditions = ["g.is_active = 1"];
        $params = [];
        
        if (!empty($filters['category_id'])) {
            $where_conditions[] = "g.category_id = ?";
            $params[] = $filters['category_id'];
        }
        
        if (!empty($filters['subject'])) {
            $where_conditions[] = "g.subject = ?";
            $params[] = $filters['subject'];
        }
        
        if (!empty($filters['difficulty'])) {
            $where_conditions[] = "g.difficulty = ?";
            $params[] = $filters['difficulty'];
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $sql = "
            SELECT g.*, gc.name as category_name, gc.icon as category_icon, gc.color as category_color 
            FROM games g 
            LEFT JOIN game_categories gc ON g.category_id = gc.id 
            WHERE {$where_clause}
            ORDER BY g.created_at DESC
        ";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting games: " . $e->getMessage());
        return [];
    }
}

/**
 * دریافت دسته‌بندی‌های فعال
 */
function getGameCategories($conn) {
    try {
        $stmt = $conn->prepare("SELECT * FROM game_categories WHERE is_active = 1 ORDER BY name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting categories: " . $e->getMessage());
        return [];
    }
}

/**
 * ذخیره نتیجه بازی
 */
function saveGameResult($conn, $student_id, $game_id, $score, $accuracy, $time_spent) {
    try {
        $conn->beginTransaction();
        
        // دریافت اطلاعات بازی
        $game = getGameById($conn, $game_id);
        if (!$game) {
            throw new Exception('بازی یافت نشد');
        }
        
        // ذخیره نتیجه
        $stmt = $conn->prepare("
            INSERT INTO game_results (student_id, game_id, score, max_possible_score, accuracy, time_spent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$student_id, $game_id, $score, $game['max_score'], $accuracy, $time_spent]);
        
        // محاسبه XP
        $xp_earned = calculateXP($score, $game['max_score'], $accuracy, $time_spent);
        
        // بروزرسانی XP دانش‌آموز
        updateStudentXP($conn, $student_id, $game['subject'], $xp_earned);
        
        // بررسی نشان‌های جدید
        $new_badges = checkAndAwardBadges($conn, $student_id, $game_id);
        
        $conn->commit();
        
        return [
            'success' => true,
            'xp_earned' => $xp_earned,
            'new_badges' => $new_badges
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Error saving game result: " . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * محاسبه XP بر اساس عملکرد
 */
function calculateXP($score, $max_score, $accuracy, $time_spent) {
    $base_xp = 10; // XP پایه برای شرکت در بازی
    
    // بونوس امتیاز (حداکثر 20 XP)
    $score_bonus = round(($score / $max_score) * 20);
    
    // بونوس دقت (حداکثر 10 XP)
    $accuracy_bonus = round($accuracy / 10);
    
    // بونوس سرعت (5 XP اگر کمتر از 2 دقیقه)
    $speed_bonus = ($time_spent < 120) ? 5 : 0;
    
    // XP اضافی برای امتیاز کامل
    $perfect_bonus = ($score >= $max_score) ? 15 : 0;
    
    return $base_xp + $score_bonus + $accuracy_bonus + $speed_bonus + $perfect_bonus;
}

/**
 * بروزرسانی XP دانش‌آموز
 */
function updateStudentXP($conn, $student_id, $subject, $xp_amount) {
    try {
        // نام فیلد XP مربوط به درس
        $subject_xp_field = $subject . '_xp';
        
        // بروزرسانی یا ایجاد رکورد XP
        $stmt = $conn->prepare("
            INSERT INTO student_xp (student_id, total_xp, {$subject_xp_field}) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
                total_xp = total_xp + VALUES(total_xp),
                {$subject_xp_field} = {$subject_xp_field} + VALUES({$subject_xp_field})
        ");
        $stmt->execute([$student_id, $xp_amount, $xp_amount]);
        
        // محاسبه و بروزرسانی سطح
        $stmt = $conn->prepare("SELECT total_xp FROM student_xp WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $total_xp = $stmt->fetchColumn();
        
        $new_level = floor($total_xp / 100) + 1; // هر 100 XP یک سطح
        
        $stmt = $conn->prepare("UPDATE student_xp SET level = ? WHERE student_id = ?");
        $stmt->execute([$new_level, $student_id]);
        
        return true;
    } catch (Exception $e) {
        error_log("Error updating student XP: " . $e->getMessage());
        return false;
    }
}

/**
 * بررسی و اعطای نشان‌های جدید
 */
function checkAndAwardBadges($conn, $student_id, $game_id = null) {
    $new_badges = [];
    
    try {
        // دریافت تمام نشان‌های فعال
        $stmt = $conn->prepare("SELECT * FROM badges WHERE is_active = 1");
        $stmt->execute();
        $all_badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($all_badges as $badge) {
            // بررسی اینکه دانش‌آموز قبلاً این نشان را داشته یا نه
            $stmt = $conn->prepare("SELECT COUNT(*) FROM student_badges WHERE student_id = ? AND badge_id = ?");
            $stmt->execute([$student_id, $badge['id']]);
            $has_badge = $stmt->fetchColumn() > 0;
            
            if ($has_badge) continue;
            
            // بررسی شرایط کسب نشان
            $earned = false;
            
            switch ($badge['condition_type']) {
                case 'games_completed':
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM game_results WHERE student_id = ?");
                    $stmt->execute([$student_id]);
                    $count = $stmt->fetchColumn();
                    $earned = $count >= $badge['condition_value'];
                    break;
                    
                case 'perfect_score':
                    $stmt = $conn->prepare("
                        SELECT COUNT(*) 
                        FROM game_results gr 
                        JOIN games g ON gr.game_id = g.id 
                        WHERE gr.student_id = ? AND gr.score = g.max_score
                    ");
                    $stmt->execute([$student_id]);
                    $count = $stmt->fetchColumn();
                    $earned = $count >= $badge['condition_value'];
                    break;
                    
                case 'subject_games':
                    if ($badge['subject']) {
                        $stmt = $conn->prepare("
                            SELECT COUNT(*) 
                            FROM game_results gr 
                            JOIN games g ON gr.game_id = g.id 
                            WHERE gr.student_id = ? AND g.subject = ?
                        ");
                        $stmt->execute([$student_id, $badge['subject']]);
                        $count = $stmt->fetchColumn();
                        $earned = $count >= $badge['condition_value'];
                    }
                    break;
                    
                case 'speed_record':
                    $stmt = $conn->prepare("
                        SELECT COUNT(*) 
                        FROM game_results 
                        WHERE student_id = ? AND time_spent <= ?
                    ");
                    $stmt->execute([$student_id, $badge['condition_value']]);
                    $count = $stmt->fetchColumn();
                    $earned = $count >= 1;
                    break;
            }
            
            // اعطای نشان در صورت کسب شرایط
            if ($earned) {
                $stmt = $conn->prepare("INSERT INTO student_badges (student_id, badge_id) VALUES (?, ?)");
                if ($stmt->execute([$student_id, $badge['id']])) {
                    $new_badges[] = $badge;
                }
            }
        }
        
    } catch (Exception $e) {
        error_log("Error checking badges: " . $e->getMessage());
    }
    
    return $new_badges;
}

/**
 * دریافت جدول امتیازات
 */
function getLeaderboard($conn, $limit = 10, $period = 'all') {
    try {
        $date_condition = '';
        if ($period === 'weekly') {
            $date_condition = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } elseif ($period === 'monthly') {
            $date_condition = 'AND gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }
        
        $stmt = $conn->prepare("
            SELECT 
                u.first_name, 
                sx.total_xp, 
                sx.level,
                COUNT(gr.id) as games_played,
                ROW_NUMBER() OVER (ORDER BY sx.total_xp DESC) as rank
            FROM student_xp sx
            JOIN users u ON sx.student_id = u.id
            LEFT JOIN game_results gr ON u.id = gr.student_id {$date_condition}
            WHERE u.user_type = 'student'
            GROUP BY sx.student_id, u.first_name, sx.total_xp, sx.level
            ORDER BY sx.total_xp DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting leaderboard: " . $e->getMessage());
        return [];
    }
}

/**
 * دریافت نشان‌های دانش‌آموز
 */
function getStudentBadges($conn, $student_id) {
    try {
        $stmt = $conn->prepare("
            SELECT b.*, sb.earned_at 
            FROM badges b 
            JOIN student_badges sb ON b.id = sb.badge_id 
            WHERE sb.student_id = ? 
            ORDER BY sb.earned_at DESC
        ");
        $stmt->execute([$student_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting student badges: " . $e->getMessage());
        return [];
    }
}

/**
 * دریافت XP دانش‌آموز
 */
function getStudentXP($conn, $student_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM student_xp WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $xp = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$xp) {
            // ایجاد رکورد XP اولیه
            $stmt = $conn->prepare("INSERT INTO student_xp (student_id) VALUES (?)");
            $stmt->execute([$student_id]);
            return [
                'total_xp' => 0,
                'math_xp' => 0,
                'science_xp' => 0,
                'persian_xp' => 0,
                'social_xp' => 0,
                'religion_xp' => 0,
                'level' => 1
            ];
        }
        
        return $xp;
    } catch (Exception $e) {
        error_log("Error getting student XP: " . $e->getMessage());
        return null;
    }
}

/**
 * دریافت آمار بازی‌ها برای پنل ادمین
 */
function getGamesStatistics($conn) {
    $stats = [];
    
    try {
        // تعداد کل بازی‌ها
        $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE is_active = 1");
        $stmt->execute();
        $stats['total_games'] = $stmt->fetchColumn();
        
        // بازیکنان فعال ماهانه
        $stmt = $conn->prepare("
            SELECT COUNT(DISTINCT student_id) 
            FROM game_results 
            WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        $stmt->execute();
        $stats['active_players'] = $stmt->fetchColumn();
        
        // بازی‌های هفته
        $stmt = $conn->prepare("
            SELECT COUNT(*) 
            FROM game_results 
            WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ");
        $stmt->execute();
        $stats['weekly_plays'] = $stmt->fetchColumn();
        
        // میانگین امتیاز
        $stmt = $conn->prepare("
            SELECT AVG(score) 
            FROM game_results 
            WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        $stmt->execute();
        $stats['avg_score'] = $stmt->fetchColumn() ?: 0;
        
        // محبوب‌ترین بازی‌ها
        $stmt = $conn->prepare("
            SELECT g.title, COUNT(gr.id) as play_count
            FROM games g
            JOIN game_results gr ON g.id = gr.game_id
            WHERE gr.completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY g.id, g.title
            ORDER BY play_count DESC
            LIMIT 5
        ");
        $stmt->execute();
        $stats['popular_games'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("Error getting games statistics: " . $e->getMessage());
    }
    
    return $stats;
}

/**
 * ایجاد بازی جدید
 */
function createGame($conn, $data) {
    try {
        $stmt = $conn->prepare("
            INSERT INTO games (title, description, category_id, subject, topic, difficulty, 
                              estimated_time, max_score, game_code, instructions, created_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            sanitize($data['title']),
            sanitize($data['description'] ?? ''),
            (int)($data['category_id'] ?? 0),
            sanitize($data['subject']),
            sanitize($data['topic'] ?? ''),
            $data['difficulty'] ?? 'medium',
            (int)($data['estimated_time'] ?? 5),
            (int)($data['max_score'] ?? 100),
            $data['game_code'],
            sanitize($data['instructions'] ?? ''),
            $_SESSION['user_id']
        ]);
        
        return ['success' => true, 'game_id' => $conn->lastInsertId()];
    } catch (Exception $e) {
        error_log("Error creating game: " . $e->getMessage());
        return ['success' => false, 'message' => 'خطا در ایجاد بازی'];
    }
}

/**
 * تولید گزارش نتایج به فرمت CSV
 */
function exportGameResults($conn, $game_id = null, $student_id = null) {
    try {
        $where_conditions = [];
        $params = [];
        
        if ($game_id) {
            $where_conditions[] = "gr.game_id = ?";
            $params[] = $game_id;
        }
        
        if ($student_id) {
            $where_conditions[] = "gr.student_id = ?";
            $params[] = $student_id;
        }
        
        $where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        $stmt = $conn->prepare("
            SELECT 
                u.first_name, u.last_name, g.title as game_title,
                gr.score, gr.accuracy, gr.time_spent, gr.completed_at
            FROM game_results gr
            JOIN users u ON gr.student_id = u.id
            JOIN games g ON gr.game_id = g.id
            {$where_clause}
            ORDER BY gr.completed_at DESC
        ");
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error exporting results: " . $e->getMessage());
        return [];
    }
}

// ========== بررسی کنید این توابع از قبل وجود ندارند ==========

if (!function_exists('gregorian_to_jalali')) {
    /**
     * تبدیل تاریخ میلادی به شمسی (آرایه)
     */
    function gregorian_to_jalali($g_y, $g_m, $g_d) {
        $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
        
        $gy = $g_y - 1600;
        $gm = $g_m - 1;
        $gd = $g_d - 1;
        
        $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
        
        for ($i = 0; $i < $gm; ++$i)
            $g_day_no += $g_days_in_month[$i];
        if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
            $g_day_no++;
        $g_day_no += $gd;
        
        $j_day_no = $g_day_no - 79;
        
        $j_np = floor($j_day_no / 12053);
        $j_day_no %= 12053;
        
        $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
        $j_day_no %= 1461;
        
        if ($j_day_no >= 366) {
            $jy += floor(($j_day_no - 1) / 365);
            $j_day_no = ($j_day_no - 1) % 365;
        }
        
        for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
            $j_day_no -= $j_days_in_month[$i];
        }
        $jm = $i + 1;
        $jd = $j_day_no + 1;
        
        return [$jy, $jm, $jd];
    }
}

if (!function_exists('jdate')) {
    /**
     * فرمت کردن تاریخ شمسی (مشابه date در PHP)
     * @param string $format فرمت (Y, m, d, w, n, j)
     * @param int|null $timestamp تایم‌استمپ
     * @return string|int
     */
    function jdate($format, $timestamp = null) {
        if ($timestamp === null) {
            $timestamp = time();
        }
        
        $year = (int)date('Y', $timestamp);
        $month = (int)date('m', $timestamp);
        $day = (int)date('d', $timestamp);
        
        list($j_y, $j_m, $j_d) = gregorian_to_jalali($year, $month, $day);
        
        $weekday = (int)date('w', $timestamp);
        
        $output = '';
        $len = strlen($format);
        
        for ($i = 0; $i < $len; $i++) {
            switch ($format[$i]) {
                case 'Y':
                    $output .= $j_y;
                    break;
                case 'y':
                    $output .= substr($j_y, 2);
                    break;
                case 'm':
                    $output .= sprintf('%02d', $j_m);
                    break;
                case 'n':
                    $output .= $j_m;
                    break;
                case 'd':
                    $output .= sprintf('%02d', $j_d);
                    break;
                case 'j':
                    $output .= $j_d;
                    break;
                case 'w':
                    $output .= $weekday;
                    break;
                case '-':
                case '/':
                case ':':
                case ' ':
                    $output .= $format[$i];
                    break;
                default:
                    $output .= $format[$i];
                    break;
            }
        }
        
        return $output;
    }
}

if (!function_exists('get_persian_month_name')) {
    /**
     * دریافت نام ماه شمسی
     * @param int $month شماره ماه (1-12)
     * @return string نام ماه
     */
    function get_persian_month_name($month) {
        $months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
                   'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        return isset($months[$month]) ? $months[$month] : '';
    }
}

if (!function_exists('get_current_persian_week_info')) {
    /**
     * دریافت اطلاعات هفته جاری شمسی
     * @param int|null $timestamp
     * @return array ['year' => int, 'month' => int, 'week' => int, 'week_start' => string]
     */
    function get_current_persian_week_info($timestamp = null) {
        if ($timestamp === null) {
            $timestamp = time();
        }
        
        // محاسبه روز هفته (0=یکشنبه تا 6=شنبه)
        $currentWeekday = (int)date('w', $timestamp);
        
        // محاسبه تایم‌استمپ جمعه این هفته (پایان هفته)
        if ($currentWeekday == 5) { // امروز جمعه است
            $fridayTimestamp = $timestamp;
        } else {
            $daysToFriday = (5 - $currentWeekday + 7) % 7;
            if ($daysToFriday == 0) $daysToFriday = 7;
            $fridayTimestamp = $timestamp + ($daysToFriday * 86400);
        }
        
        // تبدیل به تاریخ شمسی
        list($year, $month, $day) = gregorian_to_jalali(
            (int)date('Y', $fridayTimestamp),
            (int)date('m', $fridayTimestamp),
            (int)date('d', $fridayTimestamp)
        );
        
        $weekNumber = (int)ceil($day / 7);
        
        // محاسبه تاریخ شنبه (شروع هفته)
        $saturdayTimestamp = $fridayTimestamp - (6 * 86400);
        list($sat_y, $sat_m, $sat_d) = gregorian_to_jalali(
            (int)date('Y', $saturdayTimestamp),
            (int)date('m', $saturdayTimestamp),
            (int)date('d', $saturdayTimestamp)
        );
        
        return [
            'year' => $year,
            'month' => $month,
            'week' => $weekNumber,
            'week_start' => sprintf('%04d-%02d-%02d', $sat_y, $sat_m, $sat_d),
            'week_start_timestamp' => $saturdayTimestamp,
            'week_end_timestamp' => $fridayTimestamp
        ];
    }
}
?>