<?php
require_once 'config.php';

// تنظیمات اولیه
set_time_limit(300); // 5 دقیقه برای اجرا
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<html lang='fa' dir='rtl'>";
echo "<head><meta charset='UTF-8'>";
echo "<style>
body { font-family: Tahoma, Arial; background: #f5f5f5; padding: 20px; }
.container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h1 { color: #333; border-bottom: 3px solid #667eea; padding-bottom: 10px; }
.success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; border-right: 4px solid #28a745; }
.error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; border-right: 4px solid #dc3545; }
.info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; border-right: 4px solid #17a2b8; }
.warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; border-right: 4px solid #ffc107; }
table { width: 100%; border-collapse: collapse; margin: 20px 0; }
table th, table td { padding: 12px; text-align: right; border: 1px solid #ddd; }
table th { background: #667eea; color: white; }
table tr:nth-child(even) { background: #f9f9f9; }
.btn { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
.btn:hover { background: #5568d3; }
.detail { font-size: 0.9em; color: #666; margin: 5px 0; }
</style></head><body><div class='container'>";

echo "<h1>🔄 انتقال داده‌های XP به جدول خلاصه هفتگی</h1>";

// تابع تبدیل تاریخ میلادی به شمسی (ساده)
function gregorianToJalali($g_y, $g_m, $g_d) {
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    
    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;
    
    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
    for ($i = 0; $i < $gm; ++$i) {
        $g_day_no += $g_days_in_month[$i];
    }
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) {
        $g_day_no++;
    }
    $g_day_no += $gd;
    
    $j_day_no = $g_day_no - 79;
    $j_np = floor($j_day_no / 12053);
    $j_day_no %= 12053;
    
    $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461;
    
    if ($j_day_no >= 366) {
        $jy += floor(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }
    
    $j_month = 0;
    while ($j_month < 12 && $j_day_no >= $j_days_in_month[$j_month]) {
        $j_day_no -= $j_days_in_month[$j_month];
        $j_month++;
    }
    
    return [$jy, $j_month + 1, $j_day_no + 1];
}

// تابع محاسبه شماره هفته در ماه
function getWeekOfMonth($day) {
    return ceil($day / 7);
}

// تابع محاسبه اولین روز هفته
function getWeekStartDate($year, $month, $week) {
    $day = (($week - 1) * 7) + 1;
    if ($day > 30) $day = 30; // حداکثر روز ماه
    return sprintf("%04d-%02d-%02d", $year, $month, $day);
}

try {
    $conn->beginTransaction();
    
    echo "<div class='info'><strong>مرحله 1:</strong> بررسی دانش‌آموزان معتبر...</div>";
    
    // دریافت لیست student_id های معتبر
    $validStudentsStmt = $conn->query("SELECT id FROM users WHERE user_type = 'student'");
    $validStudents = $validStudentsStmt->fetchAll(PDO::FETCH_COLUMN);
    $validStudentsCount = count($validStudents);
    
    echo "<div class='success'>✅ تعداد {$validStudentsCount} دانش‌آموز معتبر یافت شد.</div>";
    
    echo "<div class='info'><strong>مرحله 2:</strong> دریافت داده‌های XP از جدول xp_history...</div>";
    
    // دریافت تمام رکوردهای XP فقط برای دانش‌آموزان معتبر
    $placeholders = str_repeat('?,', count($validStudents) - 1) . '?';
    $stmt = $conn->prepare("
        SELECT 
            xh.student_id,
            xh.amount,
            xh.created_at,
            u.first_name,
            u.last_name
        FROM xp_history xh
        INNER JOIN users u ON xh.student_id = u.id
        WHERE xh.amount > 0 
          AND xh.student_id IN ($placeholders)
          AND u.user_type = 'student'
        ORDER BY xh.created_at ASC
    ");
    $stmt->execute($validStudents);
    
    $xpRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $totalRecords = count($xpRecords);
    
    echo "<div class='success'>✅ تعداد {$totalRecords} رکورد XP معتبر یافت شد.</div>";
    
    if ($totalRecords === 0) {
        echo "<div class='warning'>⚠️ هیچ رکورد XP برای انتقال یافت نشد!</div>";
        $conn->rollBack();
        echo "</div></body></html>";
        exit;
    }
    
    // بررسی رکوردهای نامعتبر
    $invalidRecordsStmt = $conn->query("
        SELECT COUNT(*) as invalid_count
        FROM xp_history xh
        LEFT JOIN users u ON xh.student_id = u.id
        WHERE u.id IS NULL AND xh.amount > 0
    ");
    $invalidCount = $invalidRecordsStmt->fetch(PDO::FETCH_ASSOC)['invalid_count'];
    
    if ($invalidCount > 0) {
        echo "<div class='warning'>⚠️ تعداد {$invalidCount} رکورد با student_id نامعتبر حذف شدند.</div>";
    }
    
    echo "<div class='info'><strong>مرحله 3:</strong> گروه‌بندی داده‌ها بر اساس دانش‌آموز، سال، ماه و هفته...</div>";
    
    // گروه‌بندی داده‌ها
    $weeklyData = [];
    $studentNames = [];
    
    foreach ($xpRecords as $record) {
        $studentId = $record['student_id'];
        $amount = $record['amount'];
        $timestamp = strtotime($record['created_at']);
        
        // ذخیره نام دانش‌آموز
        if (!isset($studentNames[$studentId])) {
            $studentNames[$studentId] = [
                'first_name' => $record['first_name'],
                'last_name' => $record['last_name']
            ];
        }
        
        // تبدیل به تاریخ شمسی
        $gDate = getdate($timestamp);
        list($jYear, $jMonth, $jDay) = gregorianToJalali($gDate['year'], $gDate['mon'], $gDate['mday']);
        
        // محاسبه شماره هفته
        $weekNumber = getWeekOfMonth($jDay);
        
        // ایجاد کلید یکتا
        $key = "{$studentId}_{$jYear}_{$jMonth}_{$weekNumber}";
        
        if (!isset($weeklyData[$key])) {
            $weeklyData[$key] = [
                'student_id' => $studentId,
                'year' => $jYear,
                'month' => $jMonth,
                'week_number' => $weekNumber,
                'total_xp' => 0,
                'week_start_date' => getWeekStartDate($jYear, $jMonth, $weekNumber)
            ];
        }
        
        $weeklyData[$key]['total_xp'] += $amount;
    }
    
    $totalWeeks = count($weeklyData);
    echo "<div class='success'>✅ تعداد {$totalWeeks} رکورد هفتگی منحصر به فرد ایجاد شد.</div>";
    
    echo "<div class='info'><strong>مرحله 4:</strong> پاک کردن داده‌های قبلی...</div>";
    
    // حذف داده‌های قبلی
    $conn->exec("DELETE FROM weekly_xp_summary");
    echo "<div class='info'>🗑️ داده‌های قبلی پاک شد.</div>";
    
    echo "<div class='info'><strong>مرحله 5:</strong> درج داده‌ها در جدول weekly_xp_summary...</div>";
    
    // آماده‌سازی کوئری درج
    $insertStmt = $conn->prepare("
        INSERT INTO weekly_xp_summary 
        (student_id, year, month, week_number, total_xp, week_start_date, created_at)
        VALUES 
        (:student_id, :year, :month, :week_number, :total_xp, :week_start_date, NOW())
    ");
    
    $inserted = 0;
    $errors = [];
    
    foreach ($weeklyData as $data) {
        try {
            $insertStmt->execute([
                ':student_id' => $data['student_id'],
                ':year' => $data['year'],
                ':month' => $data['month'],
                ':week_number' => $data['week_number'],
                ':total_xp' => $data['total_xp'],
                ':week_start_date' => $data['week_start_date']
            ]);
            $inserted++;
        } catch (Exception $e) {
            $studentName = isset($studentNames[$data['student_id']]) 
                ? $studentNames[$data['student_id']]['first_name'] . ' ' . $studentNames[$data['student_id']]['last_name']
                : 'نامشخص';
            
            $errors[] = [
                'student_id' => $data['student_id'],
                'student_name' => $studentName,
                'year' => $data['year'],
                'month' => $data['month'],
                'week' => $data['week_number'],
                'message' => $e->getMessage()
            ];
        }
    }
    
    echo "<div class='success'>✅ تعداد {$inserted} رکورد با موفقیت درج شد.</div>";
    
    if (count($errors) > 0) {
        echo "<div class='error'>❌ تعداد " . count($errors) . " خطا رخ داد:</div>";
        echo "<table><tr><th>ID</th><th>دانش‌آموز</th><th>سال/ماه/هفته</th><th>خطا</th></tr>";
        foreach ($errors as $error) {
            echo "<tr>";
            echo "<td>{$error['student_id']}</td>";
            echo "<td>{$error['student_name']}</td>";
            echo "<td>{$error['year']}/{$error['month']}/{$error['week']}</td>";
            echo "<td style='font-size:0.8em;'>" . substr($error['message'], 0, 100) . "...</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<div class='info'><strong>مرحله 6:</strong> محاسبه رتبه‌بندی...</div>";
    
    // محاسبه رتبه برای هر هفته با استفاده از ROW_NUMBER
    $rankStmt = $conn->query("
        SELECT DISTINCT year, month, week_number 
        FROM weekly_xp_summary 
        ORDER BY year DESC, month DESC, week_number DESC
    ");
    
    $weeks = $rankStmt->fetchAll(PDO::FETCH_ASSOC);
    $rankedWeeks = 0;
    
    foreach ($weeks as $week) {
        try {
            // دریافت لیست دانش‌آموزان مرتب شده
            $studentsStmt = $conn->prepare("
                SELECT id, total_xp
                FROM weekly_xp_summary
                WHERE year = :year 
                  AND month = :month 
                  AND week_number = :week
                ORDER BY total_xp DESC, id ASC
            ");
            $studentsStmt->execute([
                ':year' => $week['year'],
                ':month' => $week['month'],
                ':week' => $week['week_number']
            ]);
            $students = $studentsStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // به‌روزرسانی رتبه برای هر دانش‌آموز
            $updateRankStmt = $conn->prepare("
                UPDATE weekly_xp_summary 
                SET `rank` = :rank 
                WHERE id = :id
            ");
            
            $currentRank = 1;
            foreach ($students as $student) {
                $updateRankStmt->execute([
                    ':rank' => $currentRank,
                    ':id' => $student['id']
                ]);
                $currentRank++;
            }
            
            $rankedWeeks++;
        } catch (Exception $e) {
            echo "<div class='error'>خطا در محاسبه رتبه برای سال {$week['year']}, ماه {$week['month']}, هفته {$week['week_number']}: " . $e->getMessage() . "</div>";
        }
    }
    
    echo "<div class='success'>✅ رتبه‌بندی برای {$rankedWeeks} هفته محاسبه شد.</div>";
    
    $conn->commit();
    
    echo "<div class='info'><strong>مرحله 7:</strong> نمایش خلاصه نتایج...</div>";
    
    // نمایش آمار نهایی
    $statsStmt = $conn->query("
        SELECT 
            year,
            month,
            week_number,
            COUNT(*) as student_count,
            SUM(total_xp) as total_xp,
            AVG(total_xp) as avg_xp,
            MAX(total_xp) as max_xp
        FROM weekly_xp_summary
        GROUP BY year, month, week_number
        ORDER BY year DESC, month DESC, week_number DESC
        LIMIT 10
    ");
    
    $stats = $statsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    $monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
                   'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    
    echo "<h2>📊 خلاصه 10 هفته اخیر:</h2>";
    echo "<table>";
    echo "<tr><th>سال</th><th>ماه</th><th>هفته</th><th>تعداد دانش‌آموزان</th><th>کل امتیاز</th><th>میانگین</th><th>حداکثر</th></tr>";
    
    foreach ($stats as $stat) {
        echo "<tr>";
        echo "<td>{$stat['year']}</td>";
        echo "<td>{$monthNames[$stat['month']]}</td>";
        echo "<td>هفته {$stat['week_number']}</td>";
        echo "<td>{$stat['student_count']}</td>";
        echo "<td>" . number_format($stat['total_xp']) . "</td>";
        echo "<td>" . number_format($stat['avg_xp'], 0) . "</td>";
        echo "<td>" . number_format($stat['max_xp']) . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // نمایش برترین‌ها
    echo "<h2>🏆 برترین دانش‌آموزان هفته جاری:</h2>";
    
    $topStmt = $conn->query("
        SELECT 
            w.student_id,
            u.first_name,
            u.last_name,
            w.total_xp,
            w.`rank`
        FROM weekly_xp_summary w
        INNER JOIN users u ON w.student_id = u.id
        WHERE w.year = (SELECT MAX(year) FROM weekly_xp_summary)
          AND w.month = (SELECT MAX(month) FROM weekly_xp_summary WHERE year = (SELECT MAX(year) FROM weekly_xp_summary))
          AND w.week_number = (SELECT MAX(week_number) FROM weekly_xp_summary 
                               WHERE year = (SELECT MAX(year) FROM weekly_xp_summary)
                               AND month = (SELECT MAX(month) FROM weekly_xp_summary WHERE year = (SELECT MAX(year) FROM weekly_xp_summary)))
        ORDER BY w.`rank` ASC
        LIMIT 10
    ");
    
    $topStudents = $topStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($topStudents) > 0) {
        echo "<table>";
        echo "<tr><th>رتبه</th><th>نام</th><th>نام خانوادگی</th><th>امتیاز</th></tr>";
        
        foreach ($topStudents as $student) {
            $rankClass = '';
            if ($student['rank'] == 1) $rankClass = 'style="background: #ffd700;"';
            elseif ($student['rank'] == 2) $rankClass = 'style="background: #c0c0c0;"';
            elseif ($student['rank'] == 3) $rankClass = 'style="background: #cd7f32;"';
            
            echo "<tr {$rankClass}>";
            echo "<td>{$student['rank']}</td>";
            echo "<td>{$student['first_name']}</td>";
            echo "<td>{$student['last_name']}</td>";
            echo "<td>" . number_format($student['total_xp']) . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    echo "<div class='success'><h2>✅ عملیات با موفقیت به پایان رسید!</h2>";
    echo "<div class='detail'>تعداد رکوردهای پردازش شده: {$totalRecords}</div>";
    echo "<div class='detail'>تعداد هفته‌های ایجاد شده: {$totalWeeks}</div>";
    echo "<div class='detail'>تعداد رکوردهای درج شده: {$inserted}</div>";
    echo "<div class='detail'>تعداد خطاها: " . count($errors) . "</div>";
    echo "</div>";
    
    echo "<a href='admin/weekly_analysis.php' class='btn'>🎯 مشاهده داشبورد تحلیل</a>";
    echo "<a href='admin.php' class='btn'>🏠 بازگشت به پنل مدیریت</a>";
    
} catch (Exception $e) {
    $conn->rollBack();
    echo "<div class='error'><h2>❌ خطا در انتقال داده‌ها:</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p><strong>Stack Trace:</strong></p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    echo "</div>";
}

echo "</div></body></html>";
?>