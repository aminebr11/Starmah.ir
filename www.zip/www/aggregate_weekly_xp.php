<?php
require_once 'config.php';
require_once 'functions.php';

/**
 * محاسبه دقیق مرزهای زمانی هفته شمسی گذشته (شنبه تا جمعه)
 * این نسخه اصلاح‌شده با فرض 0=یکشنبه برای jdate('w') کار می‌کند.
 * @return array اطلاعات شروع، پایان و جزئیات هفته
 */
function getPreviousPersianWeekBounds() {
    // زمان فعلی با تایم‌زون ایران
    $now = new DateTime('now', new DateTimeZone('Asia/Tehran'));
    
    // پیدا کردن شنبه این هفته
    // jdate('w') روز هفته را برمی‌گرداند (0=یکشنبه تا 6=شنبه)
    $currentWeekday = (int)jdate('w', $now->getTimestamp());
    
    // محاسبه تعداد روزهایی که باید به عقب برگردیم تا به شنبه برسیم
    // این فرمول برای هر دو استاندارد (0=یکشنبه یا 0=شنبه) کار می‌کند
    $daysToSubtract = ($currentWeekday + 1) % 7;
    
    // محاسبه زمان شنبه این هفته
    $saturdayThisWeek = clone $now;
    $saturdayThisWeek->modify("-{$daysToSubtract} days");
    $saturdayThisWeek->setTime(0, 0, 0);

    // محاسبه زمان شنبه هفته قبل
    $saturdayLastWeek = clone $saturdayThisWeek;
    $saturdayLastWeek->modify("-7 days");

    // محاسبه زمان جمعه هفته قبل
    $fridayLastWeek = clone $saturdayLastWeek;
    $fridayLastWeek->modify("+6 days");
    $fridayLastWeek->setTime(23, 59, 59);

    // تبدیل تاریخ شروع هفته به شمسی برای محاسبه سال، ماه و شماره هفته
    $persianDate = jdate('Y-m-d', $saturdayLastWeek->getTimestamp());
    list($year, $month, $day) = explode('-', $persianDate);
    
    // شماره هفته بر اساس روز در ماه
    $weekNumber = ceil((int)$day / 7);

    return [
        'start' => $saturdayLastWeek->format('Y-m-d H:i:s'),
        'end' => $fridayLastWeek->format('Y-m-d H:i:s'),
        'year' => (int)$year,
        'month' => (int)$month,
        'week_number' => (int)$weekNumber,
        'week_start_date' => $saturdayLastWeek->format('Y-m-d')
    ];
}

try {
    // دریافت اطلاعات هفته گذشته
    $bounds = getPreviousPersianWeekBounds();

    // استفاده از Transaction برای اطمینان از صحت داده‌ها
    $conn->beginTransaction();

    // 1. حذف داده‌های قدیمی هفته برای جلوگیری از تکرار (در صورت اجرای مجدد اسکریپت)
    $deleteStmt = $conn->prepare("
        DELETE FROM weekly_xp_summary 
        WHERE year = :year AND month = :month AND week_number = :week_number
    ");
    $deleteStmt->execute([
        ':year' => $bounds['year'],
        ':month' => $bounds['month'],
        ':week_number' => $bounds['week_number']
    ]);

    // 2. درج امتیازات هفتگی برای تمام دانش‌آموزان (حتی کسانی که امتیاز صفر دارند)
    $insertSql = "
        INSERT INTO weekly_xp_summary (student_id, year, month, week_number, total_xp, week_start_date)
        SELECT 
            u.id as student_id,
            :year as year,
            :month as month,
            :week_number as week_number,
            COALESCE(SUM(h.amount), 0) as weekly_xp,
            :week_start_date as week_start_date
        FROM users u
        LEFT JOIN xp_history h ON u.id = h.student_id 
            AND h.created_at >= :week_start 
            AND h.created_at <= :week_end
        WHERE u.user_type = 'student'
        GROUP BY u.id
    ";

    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->execute([
        ':year' => $bounds['year'],
        ':month' => $bounds['month'],
        ':week_number' => $bounds['week_number'],
        ':week_start_date' => $bounds['week_start_date'],
        ':week_start' => $bounds['start'],
        ':week_end' => $bounds['end']
    ]);

    $affectedRows = $insertStmt->rowCount();

    // 3. به‌روزرسانی رتبه‌ها برای داده‌های جدید درج شده
    $updateRankSql = "
        UPDATE weekly_xp_summary w1
        JOIN (
            SELECT 
                student_id,
                ROW_NUMBER() OVER (ORDER BY total_xp DESC, student_id ASC) as calculated_rank
            FROM weekly_xp_summary
            WHERE year = :year AND month = :month AND week_number = :week_number
        ) w2 ON w1.student_id = w2.student_id
        SET w1.`rank` = w2.calculated_rank
        WHERE w1.year = :year AND w1.month = :month AND w1.week_number = :week_number
    ";
    
    $rankStmt = $conn->prepare($updateRankSql);
    $rankStmt->execute([
        ':year' => $bounds['year'],
        ':month' => $bounds['month'],
        ':week_number' => $bounds['week_number']
    ]);

    $conn->commit();

    // خروجی موفقیت‌آمیز
    echo "Success: Data for week {$bounds['week_number']} of {$bounds['month']}/{$bounds['year']} has been aggregated.\n";
    echo "Period: {$bounds['start']} to {$bounds['end']}\n";
    echo "Total student records processed: {$affectedRows}\n";

} catch (PDOException $e) {
    // بازگشت تغییرات در صورت بروز خطا
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    
    // ثبت خطا در لاگ سرور
    error_log("PDO Error in aggregate_weekly_xp: " . $e->getMessage());
    
    // نمایش خطای مناسب
    echo "Error: An error occurred during data aggregation. Details have been logged.\n";
    // در محیط توسعه می‌توانید خطا را نمایش دهید:
    // echo "Debug Info: " . $e->getMessage();
}
?>