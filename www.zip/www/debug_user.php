<?php
// debug_user.php - برای بررسی اطلاعات کاربر

session_start();

echo "<h2>اطلاعات Session کاربر:</h2>";

echo "<h3>تمام متغیرهای Session:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h3>بررسی user_type:</h3>";
$userType = $_SESSION['user_type'] ?? $_SESSION['userType'] ?? 'نامشخص';
echo "<p>نوع کاربر: <strong>$userType</strong></p>";

echo "<h3>بررسی user_id:</h3>";
$userId = $_SESSION['user_id'] ?? 'نامشخص';
echo "<p>شناسه کاربر: <strong>$userId</strong></p>";

echo "<h3>راه‌حل‌های موقت:</h3>";
echo "<p>1. تغییر موقت نوع کاربر به student:</p>";
echo "<button onclick='setUserType()'>تنظیم به عنوان Student</button>";

echo "<p>2. لاگین مجدد:</p>";
echo "<a href='login.php' style='padding: 10px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>لاگین مجدد</a>";

?>

<script>
function setUserType() {
    fetch('set_user_type.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=set_student'
    })
    .then(response => response.text())
    .then(data => {
        alert('نوع کاربر تغییر یافت');
        location.reload();
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
</script>