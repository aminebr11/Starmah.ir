<?php
ob_start();  // شروع بافرینگ - این باید اولین خط باشد
// خط اول - قبل از هر چیز
if (isset($_GET['api']) && $_GET['api'] === 'game') {
    header('Content-Type: application/json; charset=utf-8');
    
    session_start();
    require_once 'config.php';
    
    $game_id = (int)($_GET['id'] ?? 0);
    
    try {
        $stmt = $conn->prepare("SELECT * FROM games WHERE id = ? AND is_active = 1");
        $stmt->execute([$game_id]); // PDO syntax
        $game = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($game) {
            echo json_encode(['success' => true, 'game' => $game]);
        } else {
            echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'خطا در دیتابیس']);
    }
    exit;
}
// این سه خط را اضافه کنید
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// بقیه کدهای شما از اینجا شروع می‌شود

session_start();
require_once 'config.php';
require_once 'functions.php';

// مسیر API دریافت اطلاعات آزمون
if ($_SERVER['REQUEST_METHOD'] === 'GET' && preg_match('/^\/api\/quiz\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    require_once 'controllers/QuizController.php';
    $controller = new QuizController();
    $controller->getQuizDetails($matches[1]);
    exit;
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? '';
// توابع تاریخ شمسی
if (!function_exists('jdate')) {
    function jdate($format, $timestamp = null) {
        if ($timestamp === null) $timestamp = time();
        
        $T_sec = $timestamp;
        list($jy, $jm, $jd) = gregorian_to_jalali_full(date('Y', $T_sec), date('n', $T_sec), date('j', $T_sec));
        
        $doy = ($jm < 7) ? (($jm - 1) * 31) + $jd : (($jm - 7) * 30) + $jd + 186;
        $kab = (((($jy % 33) % 4) - 1) == (int)(($jy % 33) * 0.05)) ? 1 : 0;
        
        $str = '';
        for ($i = 0; $i < strlen($format); $i++) {
            $c = $format[$i];
            switch ($c) {
                case 'Y': $str .= $jy; break;
                case 'y': $str .= substr($jy, 2); break;
                case 'n': $str .= $jm; break;
                case 'j': $str .= $jd; break;
                case 'w': // روز هفته (0=شنبه)
                    $str .= (date('w', $timestamp) + 1) % 7;
                    break;
                default: $str .= $c;
            }
        }
        return $str;
    }
    
    function jmktime($h, $i, $s, $jm, $jd, $jy) {
        list($gy, $gm, $gd) = jalali_to_gregorian_full($jy, $jm, $jd);
        return mktime($h, $i, $s, $gm, $gd, $gy);
    }
    
    function gregorian_to_jalali_full($gy, $gm, $gd) {
        $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        $jm = ($days < 186) ? 1 + (int)($days / 31) : 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days < 186) ? ($days % 31) : (($days - 186) % 30));
        return array($jy, $jm, $jd);
    }
    
    function jalali_to_gregorian_full($jy, $jm, $jd) {
        $jy += 1595;
        $days = 365 * $jy + ((int)($jy / 33)) * 8 + (int)((($jy % 33) + 3) / 4) + 78 + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * ((int)($days / 146097));
        $days %= 146097;
        $flag = true;
        if ($days >= 36525) {
            $days--;
            $gy += 100 * ((int)($days / 36524));
            $days %= 36524;
            if ($days >= 365) $days++;
            else $flag = false;
        }
        if ($flag) {
            $gy += 4 * ((int)($days / 1461));
            $days %= 1461;
            if ($days >= 366) {
                $flag = false;
                $days--;
                $gy += (int)($days / 365);
                $days = ($days % 365);
            }
        }
        if ($flag) {
            $gm = 0;
        } else {
            $sal_a = array(0, 31, (($gy % 4 == 0 and $gy % 100 != 0) or ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
            $gm = 0;
            while ($gm < 13 and $days > $sal_a[$gm]) {
                $days -= $sal_a[$gm];
                $gm++;
            }
        }
        return array($gy, $gm, $days);
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>ستاره ماه - کلاس چهارم خانم محمودی</title>
    <meta name="description" content="سایت آموزشی کلاس چهارم خانم نجمه محمودی - یادگیری خلاقانه و سرگرم‌کننده برای دانش‌آموزان">
    <meta name="keywords" content="آموزش ابتدایی، کلاس چهارم، ریاضی، علوم، پادکست، بازی آموزشی">
    <meta name="theme-color" content="#ff6b6b">
    
   
    <!-- JQuery Library (FIX for jQuery is not defined error) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- اضافه کردن این خط -->
<script src="https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js"></script>

    <!-- Preload critical resources -->
    <link rel="preload" href="style.css" as="style">
    <link rel="preload" href="script.js" as="script">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">
    
    <!-- Persian Date Picker -->
    <link rel="stylesheet" href="https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css">
    <script src="https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
    
    <!-- Google Fonts for better Persian typography -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Additional CSS for enhanced styling -->
    <style>
        body {
            font-family: 'Vazir', 'Tahoma', 'Arial', sans-serif;
        }
          /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            direction: rtl;
        }

        /* Grid Container */
        .stats-grid {
            display: grid !important;
            grid-template-columns: repeat(3, 1fr) !important;
            gap: 1.5rem !important;
            max-width: 1200px;
            margin: 0 auto 3rem auto;
        }

        /* Card Base Styles */
        .animated-card {
            height: 320px !important;
            max-height: 320px !important;
            min-height: 320px !important;
            border-radius: 20px;
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .animated-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 45px rgba(0, 0, 0, 0.2);
        }

        /* Card Background Animations */
        .card-bg-animation {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            opacity: 0.1;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            animation: shine 3s infinite;
        }

        @keyframes shine {
            0% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
            100% { transform: translateX(100%); }
        }

        /* Card Gradients */
        .gradient-pink {
            background: linear-gradient(135deg, #ff6b6b, #feca57, #ff9ff3);
        }

        .gradient-green {
            background: linear-gradient(135deg, #00d2ff, #3a7bd5, #00d2ff);
        }

        .gradient-purple {
            background: linear-gradient(135deg, #667eea, #764ba2, #f093fb);
        }

        .glass-effect {
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* Card Headers */
        .animated-card h3 {
            color: white !important;
            font-size: 1.3rem !important;
            margin-bottom: 1rem !important;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            font-weight: bold;
            text-align: center;
        }

        /* Stats Content */
        .stats-content {
            height: calc(100% - 60px) !important;
            overflow: hidden !important;
            padding: 0.5rem !important;
            color: #333 !important;
        }

        /* Content Items */
        .stats-content p {
            margin: 0.4rem 0 !important;
            font-size: 0.95rem !important;
            line-height: 1.4 !important;
            background: rgba(255, 255, 255, 0.9) !important;
            padding: 8px 12px !important;
            border-radius: 8px !important;
            color: #333 !important;
            font-weight: 500;
            border-right: 3px solid #ffd93d;
            transition: all 0.3s ease;
        }

        .stats-content p:hover {
            background: rgba(255, 255, 255, 1) !important;
            transform: translateX(-3px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        /* Small Text */
        .stats-content small {
            color: #666 !important;
            font-size: 0.8rem !important;
        }

        /* Welcome Section */
        .welcome-section {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.25), rgba(255, 255, 255, 0.15));
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 25px;
            padding: 3rem;
            text-align: center;
            max-width: 800px;
            margin: 3rem auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }

        .welcome-section h2 {
            color: rgba(255, 255, 255, 0.95) !important;
            margin-bottom: 1.5rem !important;
            font-size: 2rem;
            text-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
            font-weight: bold;
        }

        .welcome-section p {
            color: rgba(255, 255, 255, 0.9) !important;
            font-size: 1.1rem !important;
            line-height: 1.8 !important;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        /* Countdown Timer Styling */
        #week-countdown {
            color: #cc0000 !important;
            font-weight: bold;
        }

        /* Mobile Responsive */
        @media screen and (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr !important;
                gap: 1rem !important;
            }

            .animated-card {
                height: 280px !important;
                max-height: 280px !important;
                min-height: 280px !important;
                padding: 1rem !important;
            }

            .animated-card h3 {
                font-size: 1.1rem !important;
            }

            .stats-content p {
                font-size: 0.9rem !important;
                padding: 6px 10px !important;
            }

            .welcome-section {
                padding: 2rem;
                margin: 2rem auto;
            }

            .welcome-section h2 {
                font-size: 1.5rem !important;
            }

            .welcome-section p {
                font-size: 1rem !important;
            }
        }

        /* Very Small Mobile */
        @media screen and (max-width: 480px) {
            body {
                padding: 10px;
            }

            .stats-grid {
                gap: 0.8rem !important;
            }

            .animated-card {
                height: 250px !important;
                max-height: 250px !important;
                min-height: 250px !important;
                padding: 0.8rem !important;
            }

            .animated-card h3 {
                font-size: 1rem !important;
                margin-bottom: 0.8rem !important;
            }

            .stats-content {
                padding: 0.3rem !important;
            }

            .stats-content p {
                font-size: 0.85rem !important;
                margin: 0.3rem 0 !important;
                padding: 5px 8px !important;
            }

            .welcome-section {
                padding: 1.5rem;
            }
        }
       
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        /* Accessibility improvements */
        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
        
        /* Enhanced hover effects for better interactivity */
        .interactive-element {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .interactive-element:hover {
            transform: translateY(-2px);
        }
        
        /* Better focus styles for accessibility */
        .focus-visible {
            outline: 3px solid #ffd93d;
            outline-offset: 2px;
        }

        /* بهبود نمایش تکالیف در صفحه اصلی */
        .stats-content p {
            line-height: 1.6;
            font-family: Tahoma, sans-serif;
        }

        .stats-content small {
            display: block;
            margin-top: 4px;
            font-style: italic;
        }

        /* انیمیشن برای تکالیف */
        .stats-content p {
            animation: fadeInUp 0.5s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Enhanced Registration Form Styles */
        .register-form-enhanced {
            background: linear-gradient(135deg, 
                rgba(255, 182, 193, 0.15), 
                rgba(144, 238, 144, 0.15),
                rgba(173, 216, 230, 0.15));
            border: 2px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }

        .register-form-enhanced::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: conic-gradient(from 0deg, 
                rgba(255, 107, 107, 0.1), 
                rgba(255, 217, 61, 0.1), 
                rgba(107, 207, 127, 0.1),
                rgba(77, 157, 224, 0.1),
                rgba(255, 107, 107, 0.1));
            animation: registerRotate 20s linear infinite;
            z-index: -1;
        }

        @keyframes registerRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .national-id-highlight {
            background: linear-gradient(45deg, #ffd93d, #ffec8c) !important;
            border: 2px solid #ffd93d !important;
            animation: highlightPulse 2s ease-in-out infinite !important;
        }

        @keyframes highlightPulse {
            0%, 100% { box-shadow: 0 0 10px rgba(255, 217, 61, 0.5); }
            50% { box-shadow: 0 0 20px rgba(255, 217, 61, 0.8); }
        }

        .username-info-box {
            background: linear-gradient(135deg, #ffd93d, #ffec8c);
            color: #333;
            padding: 1rem;
            border-radius: 15px;
            margin: 1rem 0;
            animation: infoBoxFloat 3s ease-in-out infinite;
            box-shadow: 0 5px 15px rgba(255, 217, 61, 0.4);
        }

        @keyframes infoBoxFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        .enhanced-login-form {
            background: linear-gradient(135deg, 
                rgba(77, 157, 224, 0.15), 
                rgba(255, 107, 107, 0.15),
                rgba(107, 207, 127, 0.15));
            position: relative;
        }

        .enhanced-login-form::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>') repeat;
            animation: sparkle 4s linear infinite;
            pointer-events: none;
        }

        @keyframes sparkle {
            0%, 100% { opacity: 0.3; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.1); }
        }

        .teacher-hint-box {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 1.2rem;
            border-radius: 15px;
            margin: 1rem 0;
            text-align: center;
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        /* Success and Error Messages */
        .message-overlay {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
            padding: 1rem 1.5rem;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            animation: slideInMessage 0.5s ease;
            font-weight: 600;
        }

        .message-success {
            background: linear-gradient(135deg, rgba(107, 207, 127, 0.9), rgba(60, 179, 113, 0.9));
            color: white;
            border-left: 4px solid #6bcf7f;
        }

        .message-error {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.9), rgba(220, 20, 60, 0.9));
            color: white;
            border-left: 4px solid #ff6b6b;
        }

        .message-info {
            background: linear-gradient(135deg, rgba(77, 157, 224, 0.9), rgba(30, 144, 255, 0.9));
            color: white;
            border-left: 4px solid #4d9de0;
        }

        @keyframes slideInMessage {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* User Dropdown Menu */
        .user-info {
            position: relative;
            cursor: pointer;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            min-width: 280px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            padding: 1.5rem;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
            color: #333;
        }

        .user-info:hover .user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown h4 {
            color: #4d9de0;
            margin-bottom: 1rem;
            font-size: 1.1rem;
            border-bottom: 2px solid #4d9de0;
            padding-bottom: 0.5rem;
        }

        .user-dropdown .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.8rem;
            padding: 0.5rem;
            background: rgba(255,255,255,0.5);
            border-radius: 8px;
        }

        .user-dropdown .info-label {
            font-weight: 600;
            color: #666;
        }

        .user-dropdown .info-value {
            color: #333;
            font-weight: 500;
        }

        /* Password Recovery Form */
        .recovery-form {
            background: linear-gradient(135deg, 
                rgba(255, 107, 107, 0.15), 
                rgba(255, 217, 61, 0.15),
                rgba(107, 207, 127, 0.15));
        }

        /* Date Picker Enhancement */
        .date-input-container {
            position: relative;
        }

        .date-picker-btn {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: linear-gradient(135deg, #ffd93d, #ffec8c);
            border: none;
            padding: 0.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }

        .date-picker-btn:hover {
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 5px 15px rgba(255, 217, 61, 0.4);
        }

        /* بهبود responsive برای موبایل */
        @media (max-width: 768px) {
            .stats-content p {
                font-size: 0.9rem;
                padding: 6px;
            }
            
            .stats-content small {
                font-size: 0.75rem;
            }

            .username-info-box {
                font-size: 0.9rem;
                padding: 0.8rem;
            }
        }
        button {
    font-family: 'Vazir', sans-serif !important;
}
input:placeholder {
    color: #000000;  /* یا #808080 برای خاکستری تیره‌تر */
    opacity: 1;   /* برای وضوح بیشتر رنگ */
}
  /* بهبود تقویم تاریخ تولد */
#birthDate {
    padding-left: 50px !important;
    font-family: Tahoma, sans-serif !important;
    direction: ltr;
    text-align: left;
}

.date-picker-btn {
    z-index: 100 !important;
    width: 40px !important;
    height: 40px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}

.date-picker-btn:active {
    transform: translateY(-50%) scale(0.95);
}

/* تنظیمات تقویم */
.persian-datepicker {
    z-index: 9999 !important;
    font-family: Tahoma, sans-serif !important;
} 
/* CSS بهبود یافته برای 5 ایتم */
.stats-grid .animated-card {
    width: 100% !important;
    height: 380px !important;
    max-height: 380px !important;
    min-height: 380px !important;
    box-sizing: border-box !important;
    flex: 0 0 auto !important;
}

.stats-grid {
    display: grid !important;
    grid-template-columns: 1fr 1fr 1fr !important;
    grid-gap: 1 rem !important;
    width: 100% !important;
}

/* محدود کردن محتوای داخلی */
.animated-card .stats-content {
    height: calc(100% - 60px) !important;
    overflow: hidden !important;
    padding: 0.5rem !important;
}

.animated-card h3 {
    height: 40px !important;
    margin-bottom: 0.5rem !important;
    overflow: hidden !important;
}

/* فورس کردن اندازه یکسان */
.animated-card.gradient-pink,
.animated-card.gradient-blue, 
.animated-card.gradient-green,
.animated-card.gradient-purple {
    height: 380px !important;
    min-height: 380px !important;
    max-height: 380px !important;
}

/* تنظیم فاصله ایتم‌ها */
.stats-content p {
    margin: 0.5rem 0 !important;
    font-size: 0.85rem !important;
    line-height: 1.2 !important;
    padding: 0.2rem 0 !important;
}
/* CSS اضافی برای کارت‌های لینک */
.link-card:hover {
    transform: translateY(-10px) !important;
    box-shadow: 0 15px 40px rgba(0,0,0,0.2) !important;
}

.link-card i {
    transition: transform 0.3s ease !important;
}

.link-card:hover i {
    transform: scale(1.2) !important;
}


/* ریسپانسیو */
@media (max-width: 1200px) {
    .quick-links {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 1rem !important;
    }
    
    .link-card {
        height: 320px !important;
        max-height: 320px !important;
        min-height: 320px !important;
    }
}

@media (max-width: 768px) {
    .quick-links {
        grid-template-columns: 1fr !important;
    }
    
    .link-card {
        height: 250px !important;
        max-height: 250px !important;
        min-height: 250px !important;
    }
}
/* CSS برای hover effects کارت‌ها */
.link-card:hover {
    transform: translateY(-10px) scale(1.02) !important;
    box-shadow: 0 20px 50px rgba(0,0,0,0.3) !important;
    background: rgba(255,255,255,0.25) !important;
}

.link-card i {
    transition: all 0.3s ease !important;
}

.link-card:hover i {
    transform: scale(1.3) rotate(10deg) !important;
}

.link-card h3 {
    transition: color 0.3s ease !important;
}

.link-card:hover h3 {
    color: #ffd700 !important;
    text-shadow: 0 2px 10px rgba(255,215,0,0.5) !important;
}

/* ریسپانسیو */
@media (max-width: 1200px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 1rem !important;
    }
    
    .link-card {
        height: 320px !important;
        max-height: 320px !important;
        min-height: 320px !important;
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr !important;
    }
    
    .link-card {
        height: 280px !important;
        max-height: 280px !important;
        min-height: 280px !important;
    }
}
    </style>
</head>
<body>
    
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Menu Overlay for Mobile -->
    <div class="menu-overlay" id="menuOverlay"></div>
    
    <!-- Loading Indicator -->
    <div class="loading" id="loading" aria-hidden="true">
        <div class="spinner"></div>
    </div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="showSection('home')" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="#" onclick="showSection('home')" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="#" onclick="showSection('about')" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="#" onclick="showSection('homework')" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="#" onclick="showSection('materials')" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="#" onclick="showSection('games')" role="menuitem" class="interactive-element">🎮 آزمون و بازی</a>
                    <a href="#" onclick="showSection('podcast')" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="#" onclick="showSection('gallery')" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="#" onclick="showSection('feedback')" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="#" onclick="showSection('admin')" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی ناوبری" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="#" onclick="showSection('home'); return false;" role="menuitem">🏠 خانه</a></li>
                        <li><a href="#" onclick="showSection('about'); return false;" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="#" onclick="showSection('homework'); return false;" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="#" onclick="showSection('materials'); return false;" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="#" onclick="showSection('games'); return false;" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="#" onclick="showSection('podcast'); return false;" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="#" onclick="showSection('gallery'); return false;" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="#" onclick="showSection('feedback'); return false;" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="#" onclick="showSection('admin'); return false;" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <div class="auth-section">
                <?php if($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <div class="user-dropdown">
                            <h4>📋 اطلاعات حساب کاربری</h4>
                            <?php 
                            // Get user details for dropdown
                            $userDetails = getUserDetails($conn, $_SESSION['user_id']);
                            if($userDetails): ?>
                                <div class="info-item">
                                    <span class="info-label">نام کامل:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($userDetails['first_name'] . ' ' . $userDetails['last_name']); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">کد ملی:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($userDetails['national_id']); ?></span>
                                </div>
                                <?php if($userDetails['birth_date']): ?>
                                <div class="info-item">
                                    <span class="info-label">تاریخ تولد:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($userDetails['birth_date']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if($userDetails['email']): ?>
                                <div class="info-item">
                                    <span class="info-label">ایمیل:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($userDetails['email']); ?></span>
                                </div>
                                <?php endif; ?>
                                <div class="info-item">
                                    <span class="info-label">نوع کاربر:</span>
                                    <span class="info-value"><?php echo $userType == 'admin' ? 'مدیر سیستم' : 'دانش‌آموز'; ?></span>
                                </div>
                                <button onclick="showSection('editProfile')" 
                style="width: 100%; 
                       margin-top: 15px; 
                       padding: 10px; 
                       background: linear-gradient(135deg, #4d9de0, #3a7bd5);
                       color: white; 
                       border: none; 
                       border-radius: 10px; 
                       cursor: pointer; 
                       font-weight: 600;
                       transition: all 0.3s ease;">
            ✏️ ویرایش اطلاعات من
        </button>
    <?php endif; ?>
</div>
                                                   <a href="logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="showSection('login')">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <!-- Main Content Container -->
    <main class="container" role="main">
        
        <!-- Home Section -->
        <section id="home" class="section active" aria-labelledby="homeTitle">
            <div class="hero glass-effect">
                <div class="floating-elements" aria-hidden="true">
                    <span style="position: absolute; top: 20px; right: 50px; font-size: 3rem; animation: float 4s ease-in-out infinite;">🌟</span>
                    <span style="position: absolute; bottom: 30px; left: 80px; font-size: 2.5rem; animation: float 5s ease-in-out infinite; animation-delay: 1s;">✨</span>
                    <span style="position: absolute; top: 40px; left: 150px; font-size: 2rem; animation: float 6s ease-in-out infinite; animation-delay: 2s;">🌙</span>
                    <span style="position: absolute; top: 60%; right: 20px; font-size: 2rem; animation: float 7s ease-in-out infinite; animation-delay: 3s;">⭐</span>
                    <span style="position: absolute; bottom: 60%; left: 30px; font-size: 1.5rem; animation: float 6s ease-in-out infinite; animation-delay: 4s;">💫</span>
               </div>
<h1 id="homeTitle">کلاس ستاره‌های درخشان ✨</h1>
<p>با خانم نجمه محمودی - کلاس چهارم پر از شگفتی و یادگیری! 🚀</p>
<div style="margin-top: 3rem;">
    <?php if(!$isLoggedIn): ?>
        <button class="cta-button interactive-element floating-action" onclick="showSection('register')">
            🎓 ثبت نام دانش‌آموز جدید
        </button>
        <button class="cta-button interactive-element floating-action" onclick="showSection('login')">
            🔑 ورود به دنیای یادگیری
        </button>
    <?php else: ?>
        <button class="cta-button interactive-element floating-action" onclick="window.location.href='sections/dashboard.php'">
            📊 موارد انضباطی
        </button>
        <button class="cta-button interactive-element floating-action" onclick="window.location.href='sections/classNotebook_user.php'">
            📔 دفتر کلاسی من
        </button>
        <!-- دکمه جدید -->
        <button class="cta-button interactive-element floating-action" onclick="window.location.href='sections/student-profile.php'">
            🏆 امتیازات من
        </button>
    <?php endif; ?>
</div>
</div>

<?php
// تابع محاسبه هفته شمسی - نسخه نهایی و صحیح شده
function getCurrentPersianWeek() {
    $now = time();
    
    // نام ماه‌های شمسی
    $monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
                   'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

    // 1. پیدا کردن شنبه و جمعه هفته جاری
    $currentWeekday = (int)jdate('w', $now); // 0=شنبه, 1=یکشنبه, ...
    $saturdayTimestamp = $now - ($currentWeekday * 86400);
    $fridayTimestamp = $saturdayTimestamp + (6 * 86400);

    // 2. تعیین ماه و سال هدف (بر اساس جمعه هفته)
    // این تضمین می‌کند که اگر هفته بین دو ماه تقسیم شود، ماه جدید در نظر گرفته شود.
    $targetYear = jdate('Y', $fridayTimestamp);
    $targetMonth = jdate('n', $fridayTimestamp);
    $fridayDay = jdate('j', $fridayTimestamp);

    // 3. محاسبه شماره هفته به روش ساده و صحیح
    // شماره هفته بر اساس روز جمعه محاسبه می‌شود (سق تقسیم روز بر 7)
    $weekNumber = ceil($fridayDay / 7);
    
    return [
        'week_number' => $weekNumber,
        'month_name' => $monthNames[$targetMonth],
        'year' => $targetYear
    ];
}

// تابع محاسبه شنبه و جمعه هفته جاری (این تابع صحیح است و نیازی به تغییر ندارد)
function getCurrentWeekBounds() {
    $now = time();
    
    // روز هفته فعلی (0=شنبه)
    $currentWeekday = (int)jdate('w', $now);
    
    // محاسبه شنبه این هفته
    $daysSinceSaturday = $currentWeekday;
    $saturdayTimestamp = $now - ($daysSinceSaturday * 86400);
    $saturdayDate = date('Y-m-d', $saturdayTimestamp);
    
    // محاسبه جمعه این هفته
    $fridayTimestamp = $saturdayTimestamp + (6 * 86400);
    $fridayDate = date('Y-m-d', $fridayTimestamp);
    
    return [
        'start' => $saturdayDate . ' 00:00:00',
        'end' => $fridayDate . ' 23:59:59'
    ];
}

// دریافت اطلاعات هفته جاری
 $persianWeek = getCurrentPersianWeek();
 $weekBounds = getCurrentWeekBounds();

// Query برتری‌های هفته
 $weeklyTopStudentsStmt = $conn->prepare("
    SELECT 
        u.first_name,
        u.last_name,
        u.id,
        COALESCE(SUM(CASE WHEN h.amount > 0 THEN h.amount ELSE 0 END), 0) as weekly_xp
    FROM users u
    LEFT JOIN xp_history h ON u.id = h.student_id 
        AND h.created_at >= :week_start
        AND h.created_at <= :week_end
    WHERE u.user_type = 'student'
    GROUP BY u.id, u.first_name, u.last_name
    HAVING weekly_xp > 0
    ORDER BY weekly_xp DESC
    LIMIT 5
");

 $weeklyTopStudentsStmt->execute([
    ':week_start' => $weekBounds['start'],
    ':week_end' => $weekBounds['end']
]);

 $stats['weeklyTopStudents'] = $weeklyTopStudentsStmt->fetchAll(PDO::FETCH_ASSOC);
 $stats['currentWeek'] = $persianWeek;
?>

<div class="stats-grid">
    
    <!-- ردیف اول -->
   <!-- کارت ستاره‌های هفته -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
   <h3 style="font-size: 1.1rem !important; line-height: 1.3 !important;">
    🏆 ستاره‌های 
    هفته <?php echo $stats['currentWeek']['week_number']; ?>م 
    <?php echo $stats['currentWeek']['month_name']; ?> 
    <?php echo $stats['currentWeek']['year']; ?>
</h3>
    
    <div class="stats-content">
        <?php if(!empty($stats['weeklyTopStudents'])): ?>
            <?php 
            $rankIcons = ['👑', '🥈', '🥉', '🏅', '⭐']; 
            $rankColors = ['#FFD700', '#C0C0C0', '#CD7F32', '#4169E1', '#9932CC'];
            ?>
            
            <?php foreach($stats['weeklyTopStudents'] as $index => $student): ?>
                <?php
                $icon = $rankIcons[$index];
                $color = $rankColors[$index];
                $weeklyXP = $student['weekly_xp'];
                $rank = $index + 1;
                ?>
                
                <div class="student-rank" style="
                    display: flex; 
                    align-items: center; 
                    justify-content: space-between;
                    padding: 8px 12px;
                    margin: 5px 0;
                    border-radius: 10px;
                    background: linear-gradient(135deg, <?php echo $color; ?>22, transparent);
                    border-left: 3px solid <?php echo $color; ?>;
                    transition: all 0.3s ease;
                ">
                    <div class="rank-info" style="display: flex; align-items: center; gap: 8px;">
                        <span class="rank-icon" style="font-size: 1.2rem;"><?php echo $icon; ?></span>
                        <span class="rank-number" style="
                            font-size: 0.8rem; 
                            color: <?php echo $color; ?>; 
                            font-weight: bold;
                            min-width: 15px;
                        ">#<?php echo $rank; ?></span>
                        <span class="student-name" style="font-weight: 600; font-size: 0.9rem;">
                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                        </span>
                    </div>
                    <div class="xp-badge" style="
                        background: <?php echo $color; ?>; 
                        color: white; 
                        padding: 4px 8px; 
                        border-radius: 15px; 
                        font-size: 0.75rem;
                        font-weight: bold;
                    ">
                        ✨ <?php echo number_format($weeklyXP); ?> XP
                    </div>
                </div>
            <?php endforeach; ?>
            
        <?php else: ?>
            <div style="text-align: center; padding: 20px;">
                <span style="font-size: 3rem;">🌟</span>
                <p style="margin: 10px 0;">هنوز کسی امتیازی کسب نکرده!</p>
                <p style="font-size: 0.85rem; color: #666;">
                    اولین ستاره این هفته باش! 💫
                </p>
            </div>
        <?php endif; ?>
        
        <div class="countdown-section" style="
            font-size: 0.75rem; 
            color: #666; 
            text-align: center; 
            margin-top: 1rem; 
            border-top: 1px dashed rgba(0,0,0,0.1); 
            padding-top: 0.8rem;
        ">
            ⏰ تا پایان هفته: <span id="week-countdown" style="color: #cc0000; font-weight: bold;">محاسبه...</span>
        </div>
    </div>
</div>
<style>

.student-rank:hover {
    transform: translateX(5px);
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.rank-icon {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

.xp-badge {
    animation: shine 3s ease-in-out infinite;
}

@keyframes shine {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}
.animated-emoji {
    font-size: 6rem;
    margin-bottom: 20px;
    display: block;
    transition: all 0.3s ease;
}

.stats-content h3 {
    font-size: 2rem !important;
    margin: 15px 0 !important;
    transition: all 0.3s ease;
}

.gallery-emoji {
    animation: camera-flash 3s infinite;
}

.message-emoji {
    animation: pulse 2s infinite;
}

.podcast-emoji {
    animation: rotate 4s linear infinite;
}

/* Hover Effects */
.animated-card:hover .animated-emoji {
    transform: scale(1.2);
}

.animated-card:hover .stats-content h3 {
    transform: scale(1.1);
    color: #ffeb3b;
    text-shadow: 0 0 20px rgba(255, 235, 59, 0.5);
}

.animated-card:hover .gallery-emoji {
    animation: camera-flash-fast 1s infinite;
}

.animated-card:hover .message-emoji {
    animation: pulse-fast 1s infinite;
}

.animated-card:hover .podcast-emoji {
    animation: rotate-fast 2s linear infinite;
}

@keyframes camera-flash {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.1); }
}

@keyframes camera-flash-fast {
    0%, 100% { opacity: 1; transform: scale(1.2); }
    50% { opacity: 0.5; transform: scale(1.4); }
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

@keyframes pulse-fast {
    0%, 100% { transform: scale(1.2); }
    50% { transform: scale(1.4); }
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

@keyframes rotate-fast {
    from { transform: rotate(0deg) scale(1.2); }
    to { transform: rotate(360deg) scale(1.2); }
}
</style>
   
    <!-- کارت ۲: فعالیت‌های هفته -->
    <!-- کارت ۲: آزمون‌های جدید -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
    <h3>📝 آزمون‌های جدید</h3>
    <div class="stats-content">
        <?php 
        if (!function_exists('gregorian_to_jalali')) {
            function gregorian_to_jalali($gy, $gm, $gd) {
                $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
                if ($gy <= 1600) { $jy = 0; $gy -= 621; } else { $jy = 979; $gy -= 1600; }
                $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
                $days = (365 * $gy) + intval(($gy2 + 3) / 4) + intval(($gy2 + 99) / 100) - intval(($gy2 + 399) / 400) - 80 + $gd + $g_d_m[$gm - 1];
                $jy += 33 * intval($days / 12053);
                $days %= 12053;
                $jy += 4 * intval($days / 1461);
                $days %= 1461;
                if ($days > 365) { $jy += intval(($days - 1) / 365); $days = ($days - 1) % 365; }
                if ($days < 186) { $jm = 1 + intval($days / 31); $jd = 1 + ($days % 31); }
                else { $jm = 7 + intval(($days - 186) / 30); $jd = 1 + (($days - 186) % 30); }
                return array($jy, $jm, $jd);
            }
        }

        if (!function_exists('format_persian_date')) {
            function format_persian_date($date) {
                $months = array('', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند');
                $timestamp = strtotime($date);
                list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('n', $timestamp), date('j', $timestamp));
                return $jd . ' ' . $months[$jm] . ' ' . $jy;
            }
        }

        try {
            $recentExamsStmt = $conn->prepare("
                SELECT 
                    q.id,
                    q.title,
                    q.exam_date,
                    q.created_at
                FROM quizzes q
                ORDER BY q.created_at DESC
                LIMIT 5
            ");
            $recentExamsStmt->execute();
            $recentExams = $recentExamsStmt->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($recentExams)): 
                foreach($recentExams as $exam): 
                    if (!empty($exam['title'])): 

                        $createdToday = false;
                        $blinkClass = '';
                        if (!empty($exam['created_at'])) {
                            $createdDate = date('Y-m-d', strtotime($exam['created_at']));
                            $today = date('Y-m-d');
                            if ($createdDate == $today) {
                                $createdToday = true;
                                $blinkClass = 'blink-today';
                            }
                        }

                        $urgencyIcon = '📄';
                        $urgencyColor = '#27ae60';
                        if (!empty($exam['exam_date'])) {
                            $examTime = strtotime($exam['exam_date']);
                            $todayTime = strtotime(date('Y-m-d'));
                            $daysLeft = ($examTime - $todayTime) / (60 * 60 * 24);

                            if ($daysLeft <= 0) {
                                $urgencyIcon = '🚨';
                                $urgencyColor = '#e74c3c';
                            } elseif ($daysLeft <= 2) {
                                $urgencyIcon = '⏰';
                                $urgencyColor = '#f39c12';
                            }
                        }

                        if ($createdToday) {
                            $urgencyIcon = '✨';
                            $urgencyColor = '#27ae60';
                        }
        ?>
                        <p onclick="showSection('myExams')" 
                           class="homework-compact" 
                           style="cursor: pointer; 
                                  padding: 8px 10px; 
                                  margin: 5px 0; 
                                  background: rgba(255,255,255,0.9); 
                                  border-radius: 8px; 
                                  border-left: 3px solid <?php echo $urgencyColor; ?>;
                                  transition: all 0.3s ease;"
                           onmouseover="this.style.background='rgba(255, 255, 255, 1)'; this.style.transform='translateX(-3px)'" 
                           onmouseout="this.style.background='rgba(255, 255, 255, 0.9)'; this.style.transform='translateX(0)'">

                            <span class="homework-icon <?php echo $blinkClass; ?>" 
                                  style="font-size: 1.1em; margin-left: 5px;"><?php echo $urgencyIcon; ?></span>
                            <strong><?php echo htmlspecialchars($exam['title']); ?></strong>

                            <?php if ($createdToday): ?>
                                <span class="new-badge">جدید</span>
                            <?php endif; ?>

                            <?php if (!empty($exam['exam_date'])): ?>
                                <br><small style="color: #666; font-size: 0.8em;">
                                    📅 <?php echo format_persian_date($exam['exam_date']); ?>
                                </small>
                            <?php endif; ?>
                        </p>
        <?php 
                    endif;
                endforeach;
            else: 
        ?>
                <p style="text-align: center; padding: 20px;">🎉 هنوز آزمونی اضافه نشده!</p>
                <p style="text-align: center;">📚 وقت مرور درس‌هاست</p>
        <?php 
            endif;
        } catch (Exception $e) {
            error_log("Error in homepage exams display: " . $e->getMessage());
        ?>
            <p style="text-align: center; color: #e74c3c;">
                ⚠️ خطا در بارگذاری آزمون‌ها
                <br><small>لطفاً دوباره تلاش کنید</small>
            </p>
        <?php 
        }
        ?>
    </div>
</div>
   <!-- کارت ۳: تکالیف جدید -->
<!-- کارت ۳: تکالیف جدید -->
<!-- کارت تکالیف جدید - نسخه فشرده -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
    <h3>📋 تکالیف جدید</h3>
    <div class="stats-content">
        <?php 
        // --- تابع استاندارد تبدیل میلادی به شمسی ---
        function gregorian_to_jalali($gy, $gm, $gd) {
            $g_d_m = array(0,31,59,90,120,151,181,212,243,273,304,334);
            $gy2 = ($gm > 2)? ($gy + 1) : $gy;
            $days = 355666 + (365 * $gy) + floor(($gy2 + 3) / 4) 
                    - floor(($gy2 + 99) / 100) + floor(($gy2 + 399) / 400) 
                    + $gd + $g_d_m[$gm - 1];
            $jy = -1595 + (33 * floor($days / 12053));
            $days %= 12053;
            $jy += 4 * floor($days / 1461);
            $days %= 1461;
            if ($days > 365) {
                $jy += floor(($days - 1) / 365);
                $days = ($days - 1) % 365;
            }
            if ($days < 186) {
                $jm = 1 + floor($days / 31);
                $jd = 1 + ($days % 31);
            } else {
                $jm = 7 + floor(($days - 186) / 30);
                $jd = 1 + (($days - 186) % 30);
            }
            return array($jy, $jm, $jd);
        }

        // --- تابع کمکی برای نمایش تاریخ شمسی ---
        function jalali_date($timestamp) {
            $persian_months = array('', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند');
            $gy = (int) date('Y', $timestamp);
            $gm = (int) date('n', $timestamp);
            $gd = (int) date('j', $timestamp);
            list($jy, $jm, $jd) = gregorian_to_jalali($gy, $gm, $gd);
            return $jd . ' ' . $persian_months[$jm] . ' ' . $jy;
        }

        try {
            $recentHomeworkStmt = $conn->prepare("
                SELECT title, due_date, created_at 
                FROM homework 
                ORDER BY created_at DESC 
                LIMIT 5
            ");
            $recentHomeworkStmt->execute();
            $recentHomework = $recentHomeworkStmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($recentHomework) && count($recentHomework) > 0): 
                $homeworkCount = 0;
                foreach($recentHomework as $hw): 
                    if ($homeworkCount >= 5) break;
                    if (!empty($hw['title'])): 
                        
                        // بررسی آیا امروز بارگذاری شده یا نه
                        $createdToday = false;
                        $blinkClass = '';
                        if (!empty($hw['created_at'])) {
                            $createdDate = date('Y-m-d', strtotime($hw['created_at']));
                            $today = date('Y-m-d');
                            if ($createdDate == $today) {
                                $createdToday = true;
                                $blinkClass = 'blink-today';
                            }
                        }
                        
                        // محاسبه روزهای باقی‌مانده
                        $urgencyIcon = '📝';
                        $urgencyColor = '#9b59b6';
                        if (!empty($hw['due_date'])) {
                            $dueDate = strtotime($hw['due_date']);
                            $todayTime = strtotime(date('Y-m-d'));
                            $daysLeft = ($dueDate - $todayTime) / (60 * 60 * 24);
                            
                            if ($daysLeft <= 0) {
                                $urgencyIcon = '🚨';
                                $urgencyColor = '#e74c3c';
                            } elseif ($daysLeft <= 2) {
                                $urgencyIcon = '⏰';
                                $urgencyColor = '#f39c12';
                            }
                        }
                        
                        // اگر امروز بارگذاری شده، آیکون جدید اضافه کن
                        if ($createdToday) {
                            $urgencyIcon = '✨';
                            $urgencyColor = '#27ae60';
                        }
        ?>
                        <p onclick="showSection('homework')" 
                           class="homework-compact" 
                           style="cursor: pointer; 
                                  padding: 8px 10px; 
                                  margin: 5px 0; 
                                  background: rgba(255,255,255,0.9); 
                                  border-radius: 8px; 
                                  border-left: 3px solid <?php echo $urgencyColor; ?>;
                                  transition: all 0.3s ease;"
                           onmouseover="this.style.background='rgba(255, 255, 255, 1)'; this.style.transform='translateX(-3px)'" 
                           onmouseout="this.style.background='rgba(255, 255, 255, 0.9)'; this.style.transform='translateX(0)'">
                            
                            <span class="homework-icon <?php echo $blinkClass; ?>" 
                                  style="font-size: 1.1em; margin-left: 5px;"><?php echo $urgencyIcon; ?></span>
                            <strong><?php echo htmlspecialchars($hw['title']); ?></strong>
                            
                            <?php if ($createdToday): ?>
                                <span class="new-badge">جدید</span>
                            <?php endif; ?>
                            
                            <?php if (!empty($hw['due_date'])): ?>
                                <br><small style="color: #666; font-size: 0.8em;">
                                    📅 <?php echo jalali_date(strtotime($hw['due_date'])); ?>
                                </small>
                            <?php endif; ?>
                        </p>
        <?php 
                        $homeworkCount++;
                    endif;
                endforeach;
            else: 
        ?>
                <p style="text-align: center; padding: 20px;">🎉 هنوز تکلیفی اضافه نشده!</p>
                <p style="text-align: center;">🌟 وقت بازی و مرور درس‌هاست</p>
        <?php 
            endif;
        } catch (Exception $e) {
            error_log("Error in homepage homework display: " . $e->getMessage());
        ?>
            <p style="text-align: center; color: #e74c3c;">
                ⚠️ خطا در بارگذاری تکالیف
                <br><small>لطفاً دوباره تلاش کنید</small>
            </p>
        <?php 
        }
        ?>
    </div>
</div>
<!-- FIX: تعریف سریع showSection قبل از بارگذاری script.js -->
<script>
// تعریف فوری showSection برای جلوگیری از خطا
window.showSection = function(sectionId) {
    // پنهان کردن همه بخش‌ها
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // نمایش بخش انتخاب شده
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        window.scrollTo(0, 0); // اسکرول به بالای صفحه
    }
};

// بستن منوی موبایل هنگام کلیک
const mobileBtn = document.getElementById('mobileMenuBtn');
const mobileDropdown = document.getElementById('mobileDropdown');
const menuOverlay = document.getElementById('menuOverlay');

mobileBtn.addEventListener('click', function(e) {
    e.stopPropagation(); // جلوگیری از بسته شدن بلافاصله توسط event global
    mobileDropdown.classList.toggle('show');
    menuOverlay?.classList.toggle('show');
});

// کد شما برای بستن منو وقتی بیرون کلیک شد
window.addEventListener('click', function(e) {
    if (mobileDropdown.classList.contains('show') && 
        !mobileBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
        mobileDropdown.classList.remove('show');
        menuOverlay?.classList.remove('show');
    }
});

</script>

<!-- JavaScript اصلی -->
<script src="script.js"></script>
<style>
.homework-compact:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* نشان "جدید" برای تکالیف امروز */
.new-badge {
    background: linear-gradient(135deg, #27ae60, #2ecc71);
    color: green;
    font-size: 0.7em;
    padding: 2px 6px;
    border-radius: 10px;
    margin-right: 5px;
    font-weight: bold;
    animation: newBadgePulse 2s ease-in-out infinite;
}

@keyframes newBadgePulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

/* انیمیشن چشمک‌زن برای تکالیف امروز */
.blink-today {
    animation: blinkToday 1.5s ease-in-out infinite;
    filter: drop-shadow(0 0 3px rgba(39, 174, 96, 0.6));
}

@keyframes blinkToday {
    0%, 100% { 
        opacity: 1; 
        transform: scale(1);
    }
    50% { 
        opacity: 0.4; 
        transform: scale(1.1);
    }
}

/* افکت درخشش برای تکالیف جدید */
.blink-today::before {
    content: '';
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: #27ae60;
    border-radius: 50%;
    animation: sparkle 2s ease-in-out infinite;
}

@keyframes sparkle {
    0%, 100% { opacity: 0; }
    50% { opacity: 1; }
}
</style>
    <!-- ردیف دوم -->
    <!-- کارت ۴: کتابخانه دروس -->
   <!-- کارت ۴: کتابخانه دروس -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
    <h3>📚 کتابخانه دروس</h3>
    <div class="stats-content">
        <?php
        // تابع تبدیل تاریخ میلادی به شمسی
        function gregorian_to_jalali_materials($gy, $gm, $gd) {
            $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
            if ($gy <= 1600) {
                $jy = 0; $gy -= 621;
            } else {
                $jy = 979; $gy -= 1600;
            }
            $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
            $days = (365 * $gy) + (intval(($gy2 + 3) / 4)) + (intval(($gy2 + 99) / 100)) - (intval(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];
            $jy += 33 * intval($days / 12053);
            $days %= 12053;
            $jy += 4 * intval($days / 1461);
            $days %= 1461;
            if ($days > 365) {
                $jy += intval(($days - 1) / 365);
                $days = ($days - 1) % 365;
            }
            if ($days < 186) {
                $jm = 1 + intval($days / 31);
                $jd = 1 + ($days % 31);
            } else {
                $jm = 7 + intval(($days - 186) / 30);
                $jd = 1 + (($days - 186) % 30);
            }
            return array($jy, $jm, $jd);
        }
        
        function format_persian_date_materials($date) {
            $months = array('', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند');
            $timestamp = strtotime($date);
            list($jy, $jm, $jd) = gregorian_to_jalali_materials(date('Y', $timestamp), date('n', $timestamp), date('j', $timestamp));
            return $jd . ' ' . $months[$jm] . ' ' . $jy;
        }
        
        try {
            // تغییر LIMIT از 3 به 5
            $stmtMaterials = $conn->prepare("
                SELECT title, subject, created_at
                FROM materials
                ORDER BY created_at DESC
                LIMIT 5
            ");
            $stmtMaterials->execute();
            $materials = $stmtMaterials->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($materials) && count($materials) > 0):
                $count = 0;
                foreach ($materials as $m):
                    if ($count >= 5) break; // تغییر از 3 به 5
                    if (!empty($m['title'])):
                        
                        // بررسی آیا امروز بارگذاری شده یا نه
                        $createdToday = false;
                        $blinkClass = '';
                        if (!empty($m['created_at'])) {
                            $createdDate = date('Y-m-d', strtotime($m['created_at']));
                            $today = date('Y-m-d');
                            if ($createdDate == $today) {
                                $createdToday = true;
                                $blinkClass = 'blink-today-materials';
                            }
                        }
                        
                        // تعیین آیکون و رنگ
                        $materialIcon = '📘';
                        $materialColor = '#9b59b6';
                        
                        // اگر امروز بارگذاری شده
                        if ($createdToday) {
                            $materialIcon = '✨';
                            $materialColor = '#27ae60';
                        }
                        
                        // آیکون موضوع
                        $subjectIcons = [
                            'ریاضی' => '🧮', 'فارسی' => '📖', 'انگلیسی' => '🇺🇸', 
                            'علوم' => '🔬', 'اجتماعی' => '🌍', 'تاریخ' => '🏛️',
                            'جغرافی' => '🗺️', 'هنر' => '🎨', 'کامپیوتر' => '💻'
                        ];
                        $subjectIcon = isset($subjectIcons[$m['subject']]) ? $subjectIcons[$m['subject']] : '📚';
        ?>
                        <p onclick="showSection('materials')" 
                           class="material-compact" 
                           style="cursor: pointer; 
                                  padding: 8px 10px; 
                                  margin: 5px 0; 
                                  background: rgba(255,255,255,0.9); 
                                  border-radius: 8px; 
                                  border-left: 3px solid <?php echo $materialColor; ?>;
                                  transition: all 0.3s ease;"
                           onmouseover="this.style.background='rgba(255, 255, 255, 1)'; this.style.transform='translateX(-3px)'" 
                           onmouseout="this.style.background='rgba(255, 255, 255, 0.9)'; this.style.transform='translateX(0)'">
                            
                            <span class="material-icon <?php echo $blinkClass; ?>" 
                                  style="font-size: 1.1em; margin-left: 5px;"><?php echo $materialIcon; ?></span>
                            <strong><?php echo htmlspecialchars($m['title']); ?></strong>
                            
                            <?php if ($createdToday): ?>
                                <span class="new-badge-materials">جدید</span>
                            <?php endif; ?>
                            
                            <?php if (!empty($m['subject'])): ?>
                                <br><small style="color: #666; font-size: 0.8em;">
                                    <?php echo $subjectIcon; ?> <?php echo htmlspecialchars($m['subject']); ?> 
                                    • 📅 <?php echo format_persian_date_materials($m['created_at']); ?>
                                </small>
                            <?php endif; ?>
                        </p>
        <?php
                        $count++;
                    endif;
                endforeach;
            else:
        ?>
                <p style="text-align: center; padding: 20px;">📚 هنوز مطلبی اضافه نشده!</p>
                <p style="text-align: center;">🌟 برای اضافه کردن مطلب از بخش مدیریت استفاده کنید</p>
        <?php
            endif;
        } catch (Exception $e) {
            error_log("Error loading materials: " . $e->getMessage());
        ?>
            <p style="text-align: center; color: #e74c3c;">
                ⚠️ خطا در بارگذاری مطالب
                <br><small>لطفاً دوباره تلاش کنید</small>
            </p>
        <?php
        }
        ?>
    </div>
</div>

<!-- کارت ۵: بازی‌های هوشمندانه -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
    <h3>🎮 بازی‌های هوشمندانه</h3>
    <div class="stats-content">
        <?php
        try {
            // تغییر LIMIT از 3 به 5
            $stmtGames = $conn->prepare("
                SELECT title, difficulty, created_at
                FROM games
                ORDER BY created_at DESC
                LIMIT 5
            ");
            $stmtGames->execute();
            $games = $stmtGames->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($games) && count($games) > 0):
                $gcount = 0;
                foreach ($games as $g):
                    if ($gcount >= 5) break; // تغییر از 3 به 5
                    if (!empty($g['title'])):
                        
                        // بررسی آیا امروز بارگذاری شده یا نه
                        $createdToday = false;
                        $blinkClass = '';
                        if (!empty($g['created_at'])) {
                            $createdDate = date('Y-m-d', strtotime($g['created_at']));
                            $today = date('Y-m-d');
                            if ($createdDate == $today) {
                                $createdToday = true;
                                $blinkClass = 'blink-today-games';
                            }
                        }
                        
                        // تعیین آیکون و رنگ بر اساس سختی
                        $gameIcon = '🧩';
                        $gameColor = '#9b59b6';
                        
                        // اگر امروز بارگذاری شده
                        if ($createdToday) {
                            $gameIcon = '✨';
                            $gameColor = '#27ae60';
                        } else {
                            // تعیین آیکون بر اساس سختی
                            switch(strtolower($g['difficulty'])) {
                                case 'آسان':
                                case 'easy':
                                    $gameIcon = '🟢';
                                    $gameColor = '#27ae60';
                                    break;
                                case 'متوسط':
                                case 'medium':
                                    $gameIcon = '🟡';
                                    $gameColor = '#f39c12';
                                    break;
                                case 'سخت':
                                case 'hard':
                                    $gameIcon = '🔴';
                                    $gameColor = '#e74c3c';
                                    break;
                                default:
                                    $gameIcon = '🧩';
                                    break;
                            }
                        }
        ?>
                        <p onclick="showSection('games')" 
                           class="game-compact" 
                           style="cursor: pointer; 
                                  padding: 8px 10px; 
                                  margin: 5px 0; 
                                  background: rgba(255,255,255,0.9); 
                                  border-radius: 8px; 
                                  border-left: 3px solid <?php echo $gameColor; ?>;
                                  transition: all 0.3s ease;"
                           onmouseover="this.style.background='rgba(255, 255, 255, 1)'; this.style.transform='translateX(-3px)'" 
                           onmouseout="this.style.background='rgba(255, 255, 255, 0.9)'; this.style.transform='translateX(0)'">
                            
                            <span class="game-icon <?php echo $blinkClass; ?>" 
                                  style="font-size: 1.1em; margin-left: 5px;"><?php echo $gameIcon; ?></span>
                            <strong><?php echo htmlspecialchars($g['title']); ?></strong>
                            
                            <?php if ($createdToday): ?>
                                <span class="new-badge-games">جدید</span>
                            <?php endif; ?>
                            
                            <?php if (!empty($g['difficulty'])): ?>
                                <br><small style="color: #666; font-size: 0.8em;">
                                    ⚙️ سطح: <?php echo htmlspecialchars($g['difficulty']); ?> 
                                    • 📅 <?php echo format_persian_date_materials($g['created_at']); ?>
                                </small>
                            <?php endif; ?>
                        </p>
        <?php
                        $gcount++;
                    endif;
                endforeach;
            else:
        ?>
                <p style="text-align: center; padding: 20px;">🎯 هیچ بازی‌ای اضافه نشده!</p>
                <p style="text-align: center;">🌟 برای شروع بازی‌ها به بخش سرگرمی مراجعه کنید</p>
        <?php
            endif;
        } catch (Exception $e) {
            error_log("Error loading games: " . $e->getMessage());
        ?>
            <p style="text-align: center; color: #e74c3c;">
                ⚠️ خطا در بارگذاری بازی‌ها
                <br><small>لطفاً دوباره تلاش کنید</small>
            </p>
        <?php
        }
        ?>
    </div>
</div>

<style>
/* استایل‌های مشترک */
.material-compact:hover, .game-compact:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* نشان "جدید" برای مطالب */
.new-badge-materials, .new-badge-games {
    background: linear-gradient(135deg, #27ae60, #2ecc71);
    color: white;
    font-size: 0.7em;
    padding: 2px 6px;
    border-radius: 10px;
    margin-right: 5px;
    font-weight: bold;
    animation: newBadgePulse 2s ease-in-out infinite;
}

@keyframes newBadgePulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

/* انیمیشن چشمک‌زن برای مطالب امروز */
.blink-today-materials, .blink-today-games {
    animation: blinkToday 1.5s ease-in-out infinite;
    filter: drop-shadow(0 0 3px rgba(39, 174, 96, 0.6));
}

@keyframes blinkToday {
    0%, 100% { 
        opacity: 1; 
        transform: scale(1);
    }
    50% { 
        opacity: 0.4; 
        transform: scale(1.1);
    }
}

/* افکت درخشش برای آیتم‌های جدید */
.blink-today-materials::before, .blink-today-games::before {
    content: '';
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: #27ae60;
    border-radius: 50%;
    animation: sparkle 2s ease-in-out infinite;
}

@keyframes sparkle {
    0%, 100% { opacity: 0; }
    50% { opacity: 1; }
}
.ai-emoji {
    animation: pulse 2s infinite;
}

.animated-card:hover .ai-emoji {
    animation: pulse-fast 1s infinite;
}
</style>
<!-- کارت ۹: داستان‌های جادویی -->
<!-- کارت داستان‌های جادویی - نسخه فهرست‌وار -->
<div class="animated-card gradient-purple glass-effect interactive-element">
    <div class="card-bg-animation"></div>
    <h3>🎧 داستان‌های جادویی</h3>
    <div class="stats-content">
        <?php 
        // تابع ساده تبدیل تاریخ - نسخه آزمایش شده
        function simple_jalali($timestamp) {
            $months = ['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
            
            // اول فقط تاریخ میلادی را نمایش دهیم تا مطمئن شویم
            $gregorian_date = date('Y-m-d', $timestamp);
            
            // محاسبه تاریخ شمسی با فرمول ساده
            $g_y = date('Y', $timestamp);
            $g_m = date('n', $timestamp);
            $g_d = date('j', $timestamp);
            
            // تبدیل ساده (این فقط تخمینی است)
            if ($g_y == 2025) {
                if ($g_m == 9 && $g_d >= 23) {
                    return ($g_d - 22) . ' مهر 1404';
                } elseif ($g_m == 9 && $g_d < 23) {
                    return (31 - (22 - $g_d)) . ' شهریور 1404';
                } elseif ($g_m == 8) {
                    return ($g_d + 9) . ' شهریور 1404';
                } elseif ($g_m == 7) {
                    return ($g_d + 9) . ' مرداد 1404';
                }
            }
            
            // در غیر این صورت فقط تاریخ میلادی نمایش بده
            return date('d/m/Y', $timestamp) . ' (میلادی)';
        }
        
        try {
            $recentPodcastStmt = $conn->prepare("
                SELECT title, description, duration, created_at 
                FROM podcasts 
                ORDER BY created_at DESC 
                LIMIT 5
            ");
            $recentPodcastStmt->execute();
            $recentPodcast = $recentPodcastStmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($recentPodcast) && count($recentPodcast) > 0): 
                $podcastCount = 0;
                foreach($recentPodcast as $pc): 
                    if ($podcastCount >= 5) break;
                    if (!empty($pc['title'])): 
                        
                        // بررسی آیا امروز بارگذاری شده یا نه
                        $createdToday = false;
                        $blinkClass = '';
                        if (!empty($pc['created_at'])) {
                            $createdDate = date('Y-m-d', strtotime($pc['created_at']));
                            $today = date('Y-m-d');
                            if ($createdDate == $today) {
                                $createdToday = true;
                                $blinkClass = 'blink-today-podcast';
                            }
                        }
                        
                        // تعیین آیکون و رنگ
                        $podcastIcon = '🎧';
                        $podcastColor = '#9b59b6';
                        
                        // آیکون‌های مختلف برای انواع مختلف پادکست
                        $podcastIcons = ['🎧', '📻', '🎙️', '🎵', '📖', '🎭', '✨', '🌟'];
                        $randomIcon = $podcastIcons[array_rand($podcastIcons)];
                        
                        // اگر امروز بارگذاری شده، آیکون جدید اضافه کن
                        if ($createdToday) {
                            $podcastIcon = '✨';
                            $podcastColor = '#27ae60';
                        } else {
                            $podcastIcon = $randomIcon;
                        }
        ?>
                        <p onclick="showSection('podcast')" 
                           class="podcast-compact" 
                           style="cursor: pointer; 
                                  padding: 8px 10px; 
                                  margin: 5px 0; 
                                  background: rgba(255,255,255,0.9); 
                                  border-radius: 8px; 
                                  border-left: 3px solid <?php echo $podcastColor; ?>;
                                  transition: all 0.3s ease;"
                           onmouseover="this.style.background='rgba(255, 255, 255, 1)'; this.style.transform='translateX(-3px)'" 
                           onmouseout="this.style.background='rgba(255, 255, 255, 0.9)'; this.style.transform='translateX(0)'">
                            
                            <span class="podcast-icon <?php echo $blinkClass; ?>" 
                                  style="font-size: 1.1em; margin-left: 5px;"><?php echo $podcastIcon; ?></span>
                            <strong><?php echo htmlspecialchars($pc['title']); ?></strong>
                            
                            <?php if ($createdToday): ?>
                                <span class="new-badge-podcast">جدید</span>
                            <?php endif; ?>
                            
                            <br><small style="color: #666; font-size: 0.8em;">
                                <?php if (!empty($pc['duration'])): ?>
                                    ⏱️ <?php echo htmlspecialchars($pc['duration']); ?> • 
                                <?php endif; ?>
                                📅 <?php echo simple_jalali(strtotime($pc['created_at'])); ?>
                            </small>
                            
                            <?php if (!empty($pc['description']) && strlen($pc['description']) > 0): ?>
                                <br><small style="color: #888; font-size: 0.75em;">
                                    💬 <?php echo htmlspecialchars(mb_substr($pc['description'], 0, 50)) . (mb_strlen($pc['description']) > 50 ? '...' : ''); ?>
                                </small>
                            <?php endif; ?>
                        </p>
        <?php 
                        $podcastCount++;
                    endif;
                endforeach;
            else: 
        ?>
                <p style="text-align: center; padding: 20px;">🎧 هنوز پادکستی اضافه نشده!</p>
                <p style="text-align: center;">🌟 به زودی داستان‌های جذاب خواهیم داشت</p>
        <?php 
            endif;
        } catch (Exception $e) {
            error_log("Error in homepage podcast display: " . $e->getMessage());
        ?>
            <p style="text-align: center; color: #e74c3c;">
                ⚠️ خطا در بارگذاری پادکست‌ها
                <br><small>لطفاً دوباره تلاش کنید</small>
            </p>
        <?php 
        }
        ?>
    </div>
</div>

<style>
.podcast-compact:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

/* نشان "جدید" برای پادکست‌های امروز */
.new-badge-podcast {
    background: linear-gradient(135deg, #27ae60, #2ecc71);
    color: white;
    font-size: 0.7em;
    padding: 2px 6px;
    border-radius: 10px;
    margin-right: 5px;
    font-weight: bold;
    animation: newBadgePulsePodcast 2s ease-in-out infinite;
}

@keyframes newBadgePulsePodcast {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

/* انیمیشن چشمک‌زن برای پادکست‌های امروز */
.blink-today-podcast {
    animation: blinkTodayPodcast 1.5s ease-in-out infinite;
    filter: drop-shadow(0 0 3px rgba(39, 174, 96, 0.6));
}

@keyframes blinkTodayPodcast {
    0%, 100% { 
        opacity: 1; 
        transform: scale(1);
    }
    50% { 
        opacity: 0.4; 
        transform: scale(1.1);
    }
}

/* افکت درخشش برای پادکست‌های جدید */
.blink-today-podcast::before {
    content: '';
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: #27ae60;
    border-radius: 50%;
    animation: sparklePodcast 2s ease-in-out infinite;
}

@keyframes sparklePodcast {
    0%, 100% { opacity: 0; }
    50% { opacity: 1; }
}
</style>

   <!-- ردیف سوم -->
<!-- کارت ۷: گالری خاطرات -->
<div class="animated-card gradient-purple glass-effect interactive-element" onclick="showSection('gallery')">
    <div class="card-bg-animation"></div>
    <div class="stats-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%;">
        <span class="animated-emoji gallery-emoji">📸</span>
        <h3>گالری خاطرات</h3>
    </div>
</div>

<!-- کارت ۸: ارتباط با معلم -->
<div class="animated-card gradient-purple glass-effect interactive-element" onclick="showSection('feedback')">
    <div class="card-bg-animation"></div>
    <div class="stats-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%;">
        <span class="animated-emoji message-emoji">💌</span>
        <h3>ارتباط با معلم</h3>
    </div>
</div>

<?php if($isLoggedIn): ?>
<div class="animated-card gradient-purple glass-effect interactive-element" 
     onclick="window.location.href='sections/online-classroom.php'" 
     style="cursor: pointer;">
    <div class="card-bg-animation"></div>
    <div class="stats-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%;">
        <span class="animated-emoji" style="font-size: 4rem;">🎥</span>
        <h3 style="margin-top: 15px; color: white;">کلاس آنلاین</h3>
        <p style="color: rgba(255,255,255,0.8); font-size: 0.9rem; margin-top: 10px;">
            ویدیو کنفرانس • چت • تخته سفید
        </p>
    </div>
</div>
<?php else: ?>
<div class="animated-card gradient-purple glass-effect interactive-element" 
     onclick="showSection('login')" style="cursor: pointer;">
    <div class="card-bg-animation"></div>
    <div class="stats-content" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; height: 100%;">
        <span class="animated-emoji" style="font-size: 4rem;">🎥</span>
        <h3 style="margin-top: 15px; color: white;">کلاس آنلاین</h3>
        <p style="color: rgba(255,255,255,0.8);">برای ورود ابتدا وارد شوید</p>
    </div>
</div>
<?php endif; ?>


<style>
.welcome-section {
    grid-column: span 3; /* عرض سه کارت */
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 25px;
    padding: 2rem 5rem; /* افزایش عرض */
    margin: 15px auto; /* وسط‌چین کردن */
    max-width: 1400px; /* حداکثر عرض */
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
    border: 1px solid rgba(255, 255, 255, 0.18);
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    display: grid;
    grid-template-columns: 1fr 1fr; /* دو ستون */
    gap: 3rem; /* فاصله بیشتر بین ستون‌ها */
    align-items: center;
    text-align: center;
    min-height: auto;
}

.welcome-section:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(31, 38, 135, 0.5);
}

.welcome-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
    transform: translateX(-100%);
    transition: transform 0.6s;
}

.welcome-section:hover::before {
    transform: translateX(100%);
}

.welcome-section h2 {
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
    margin-bottom: 1rem;
    font-size: 1.2rem;
    font-weight: bold;
    text-align: center;
    z-index: 1;
    position: relative;
    line-height: 1.3;
}

.welcome-section p {
    color: rgba(255, 255, 255, 0.6);
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.5;
    text-align: center;
    z-index: 1;
    position: relative;
}

/* تبلت */
@media (max-width: 1024px) and (min-width: 769px) {
    .welcome-section {
        padding: 2rem 3rem;
        gap: 2.5rem;
        max-width: 1200px;
    }
}

/* موبایل */
@media (max-width: 768px) {
    .welcome-section {
        grid-column: span 1;
        grid-template-columns: 1fr;
        gap: 1.5rem;
        padding: 2rem 2rem;
        margin: 10px auto;
        max-width: 100%;
    }
    
    .welcome-section h2 {
        font-size: 1.1rem;
        margin-bottom: 0.8rem;
    }
    
    .welcome-section p {
        font-size: 0.85rem;
    }
}

/* موبایل کوچک */
@media (max-width: 480px) {
    .welcome-section {
        padding: 1.5rem 1.5rem;
        gap: 1rem;
        margin: 10px;
    }
    
    .welcome-section h2 {
        font-size: 1rem;
        margin-bottom: 0.6rem;
    }
    
    .welcome-section p {
        font-size: 0.8rem;
    }
}
/* استایل ویژه برای فیلد غیرفعال کد ملی */
#editNationalId {
    background: linear-gradient(135deg, rgba(200, 200, 200, 0.2), rgba(150, 150, 150, 0.1)) !important;
    cursor: not-allowed !important;
    border: 2px dashed #999 !important;
}

#editNationalId:hover {
    transform: none !important;
}

/* انیمیشن ویژه کارت کلاس آنلاین */
.animated-card[onclick*="online-classroom"]:hover {
    transform: translateY(-10px) scale(1.02) !important;
    box-shadow: 0 20px 50px rgba(108, 92, 231, 0.4) !important;
}

.animated-card[onclick*="online-classroom"]:hover .animated-emoji {
    animation: videoCall 0.5s ease-in-out infinite;
}

@keyframes videoCall {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.2) rotate(5deg); }
}

/* پالس برای جلب توجه */
.animated-card[onclick*="online-classroom"]::after {
    content: '';
    position: absolute;
    top: 10px;
    right: 10px;
    width: 12px;
    height: 12px;
    background: #00B894;
    border-radius: 50%;
    animation: livePulse 2s infinite;
}

@keyframes livePulse {
    0% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 rgba(0, 184, 148, 0.7); }
    70% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 10px rgba(0, 184, 148, 0); }
    100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 rgba(0, 184, 148, 0); }
}
</style>

<!-- Welcome Message for New Users -->
<?php if(!$isLoggedIn): ?>
<div class="welcome-section">
    <h2>🌟 به دنیای شگفت‌انگیز یادگیری خوش آمدید!</h2>
    <p>
        در کلاس ستاره ماه، هر روز ماجراجویی جدیدی در انتظار شماست! 
        با بازی‌های آموزشی، داستان‌های جذاب و فعالیت‌های خلاقانه، 
        یادگیری را به یک تجربه فراموش‌نشدنی تبدیل می‌کنیم.
    </p>
</div>
<?php endif; ?>
        </section>
        <!-- Login Section - Enhanced -->
        <section id="login" class="section" aria-labelledby="loginTitle">
            <div class="form-container enhanced-login-form glass-effect">
                <h2 id="loginTitle">🔐 ورود به دنیای شگفت‌انگیز یادگیری</h2>
                
                <div class="login-type-selector">
                    <button class="login-type-btn active interactive-element" onclick="setLoginType('student')" id="studentLoginBtn">
                        🎓 دانش‌آموز عزیز
                    </button>
                    <button class="login-type-btn interactive-element" onclick="setLoginType('teacher')" id="teacherLoginBtn">
                        👩‍🏫 معلم گرامی
                    </button>
                </div>

                <!-- Student Login Instructions -->
                <div id="studentInstructions" class="username-info-box">
                    <strong>💡 راهنمای ورود دانش‌آموزان:</strong><br>
                    نام کاربری شما همان <strong>کد ملی</strong> شماست که هنگام ثبت‌نام وارد کرده‌اید.<br>
                    <strong>مثال:</strong> اگر کد ملی شما ۰۱۲۳۴۵۶۷۸۹ است، نام کاربری شما همین عدد خواهد بود.
                </div>

                <!-- Teacher Login Instructions -->
                <div id="teacherInstructions" class="teacher-hint-box" style="display: none;">
                    <strong>🌟 ورود ویژه معلم محترم</strong><br>
                    شما می‌توانید با دسترسی کامل به پنل مدیریت سایت وارد شوید و تمام اطلاعات دانش‌آموزان را مدیریت کنید.<br>
                    <strong>نام کاربری:</strong> admin
                </div>
                
<form id="loginForm" method="POST" novalidate>
                    <input type="hidden" name="action" value="login">
                    <input type="hidden" name="user_type" id="loginUserType" value="student">
                    
                    <div class="form-group">
                        <label for="loginUsername">نام کاربری:</label>
                        <input type="text" id="loginUsername" name="username" required autocomplete="username" 
                               placeholder="کد ملی خود را وارد کنید (برای دانش‌آموزان)">
                    </div>
                    
                    <div class="form-group">
                        <label for="loginPassword">رمز عبور:</label>
                        <input type="password" id="loginPassword" name="password" required autocomplete="current-password"
                               placeholder="رمز عبور خود را وارد کنید">
                    </div>
                    
                    <button type="submit" class="submit-btn interactive-element">
                        <span id="loginButtonText">🚀 ورود به کلاس</span>
                    </button>
                </form>
                
                <p class="form-footer">
                    رمز عبور خود را فراموش کرده‌اید؟ <a href="#" onclick="showSection('recovery')" class="interactive-element">🔑 بازیابی رمز عبور</a>
                </p>
            </div>
        </section>
        
        <!-- Password Recovery Section -->
        <section id="recovery" class="section" aria-labelledby="recoveryTitle">
            <h2 id="recoveryTitle">🔄 بازیابی رمز عبور فراموش‌شده</h2>

<div class="username-info-box">
    <strong>🔍 راهنمای بازیابی رمز عبور:</strong><br>
    برای بازیابی رمز عبور، کد ملی خود را وارد کرده و اطلاعات پدر و مادر خود را تایید کنید.<br>
    سپس رمز عبور جدید خود را دو بار وارد کنید.
</div>

<form id="recoveryForm" action="recovery.php" method="POST" novalidate>
   <div class="form-group">
    <label for="recoveryNationalId">کد ملی:</label>
    <input type="text" id="recoveryNationalId" name="national_id" pattern="[0-9]{10}" required 
           placeholder="کد ملی ۱۰ رقمی خود را وارد کنید" maxlength="10" class="national-id-highlight">
</div>

<div class="form-grid">  <!-- خط دوم: نام پدر و مادر -->
    <div class="form-group">
        <label for="recoveryFatherName">نام پدر:</label>
        <input type="text" id="recoveryFatherName" name="father_name" required 
               placeholder="نام پدر مطابق ثبت‌نام">
    </div>
    
    <div class="form-group">
        <label for="recoveryMotherName">نام مادر:</label>
        <input type="text" id="recoveryMotherName" name="mother_name" required 
               placeholder="نام مادر مطابق ثبت‌نام">
    </div>
</div>

<div class="form-grid">  <!-- خط سوم: رمز و تایید -->
    <div class="form-group">
        <label for="newPassword">رمز عبور جدید:</label>
        <input type="password" id="newPassword" name="new_password" required 
               placeholder="رمز عبور جدید (حداقل ۸ کاراکتر)" minlength="8">
    </div>
    
    <div class="form-group">
        <label for="confirmPassword">تأیید رمز عبور جدید:</label>
        <input type="password" id="confirmPassword" name="confirm_password" required 
               placeholder="رمز عبور جدید را دوباره وارد کنید" minlength="8">
    </div>
</div>

<button type="submit" class="submit-btn interactive-element">  <!-- خط چهارم: دکمه -->
    🔄 بازیابی رمز عبور
</button>
</form>

<p class="form-footer">
    رمز عبور خود را به یاد آوردید؟ <a href="#" onclick="showSection('login')" class="interactive-element">🔑 ورود به حساب</a>
</p>
        </section>
        
        <!-- Registration Section - Enhanced -->
        <section id="register" class="section" aria-labelledby="registerTitle">
            <div class="form-container wide register-form-enhanced glass-effect">
                <h2 id="registerTitle">🎓 ثبت نام در کلاس ستاره‌های درخشان</h2>
                <div class="register-icon">🌟</div>
                
                <!-- Important Notice about Username -->
                <div class="username-info-box">
                    <strong>⚠️ نکته مهم:</strong> کد ملی شما به عنوان <strong>نام کاربری</strong> شما استفاده خواهد شد.<br>
                    لطفاً کد ملی را دقیق وارد کنید چون برای ورود به سایت از آن استفاده خواهید کرد! 🔑
                </div>
                
                <form id="registerForm" action="auth.php" method="POST" novalidate>
                    <input type="hidden" name="action" value="register">
                    
                    <h3>📝 اطلاعات دانش‌آموز عزیز</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="firstName">نام:</label>
                            <input type="text" id="firstName" name="first_name" required 
                                   placeholder="نام دانش‌آموز">
                        </div>
                        <div class="form-group">
                            <label for="lastName">نام خانوادگی:</label>
                            <input type="text" id="lastName" name="last_name" required 
                                   placeholder="نام خانوادگی">
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="nationalId">کد ملی (نام کاربری شما):</label>
                            <input type="text" id="nationalId" name="national_id" pattern="[0-9]{10}" required 
                                   placeholder="0123456789" maxlength="10" class="national-id-highlight">
                            <small style="color: #ffd93d; font-weight: bold;">⭐ این کد ملی همان نام کاربری شما خواهد بود!</small>
                        </div>
                        <div class="form-group">
                            <label for="birthDate">تاریخ تولد:</label>
                            <div class="date-input-container">
                                <input type="text" id="birthDate" name="birth_date" required 
       placeholder="مثال: 1394/05/15" pattern="[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}">
<button type="button" class="date-picker-btn" onclick="showDateHelper()">📅</button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="address">آدرس منزل:</label>
                        <textarea id="address" name="address" rows="2" required 
                                  placeholder="آدرس کامل محل سکونت"></textarea>
                    </div>
                    
                    <h3>👨‍👩‍👧‍👦 اطلاعات والدین گرامی</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="fatherName">نام پدر:</label>
                            <input type="text" id="fatherName" name="father_name" required 
                                   placeholder="نام پدر">
                        </div>
                        <div class="form-group">
                            <label for="fatherPhone">شماره تلفن پدر:</label>
                            <input type="tel" id="fatherPhone" name="father_phone" required 
                                   placeholder="09123456789">
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="motherName">نام مادر:</label>
                            <input type="text" id="motherName" name="mother_name" required 
                                   placeholder="نام مادر">
                        </div>
                        <div class="form-group">
                            <label for="motherPhone">شماره تلفن مادر:</label>
                            <input type="tel" id="motherPhone" name="mother_phone" required 
                                   placeholder="09123456789">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email">ایمیل (اختیاری):</label>
                        <input type="email" id="email" name="email" 
                               placeholder="example@email.com">
                    </div>
                    
                    <h3>🔐 تنظیمات حساب کاربری</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username">نام کاربری (خودکار از کد ملی):</label>
                            <input type="text" id="username" name="username" required readonly
                                   placeholder="به صورت خودکار از کد ملی کپی می‌شود"
                                   style="background-color: rgba(255, 217, 61, 0.2);">
                        </div>
                        <div class="form-group">
                            <label for="password">رمز عبور:</label>
                            <input type="password" id="password" name="password" required 
                                   placeholder="رمز عبور قوی انتخاب کنید">
                        </div>
                    </div>
                    
                    <button type="submit" class="submit-btn gradient-green interactive-element">
                        🌟 ثبت نام و شروع ماجراجویی شگفت‌انگیز
                    </button>
                </form>
                
                <p class="form-footer">
                    قبلاً ثبت نام کرده‌اید؟ <a href="#" onclick="showSection('login')" class="interactive-element">🔑 ورود به حساب</a>
                </p>
            </div>
        </section>
        <!-- Edit Profile Section -->
<section id="editProfile" class="section" aria-labelledby="editProfileTitle">
    <div class="form-container wide register-form-enhanced glass-effect">
        <h2 id="editProfileTitle">✏️ ویرایش اطلاعات حساب کاربری</h2>
        <div class="register-icon">👤</div>
        
        <?php if($isLoggedIn && isset($_SESSION['user_id'])): ?>
            <?php
            // دریافت اطلاعات کاربر
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $userData = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if($userData):
            ?>
            
<form id="editProfileForm" novalidate onsubmit="return false;">
                <input type="hidden" name="action" value="edit_profile">
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
                
                <h3>📝 اطلاعات شخصی</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editFirstName">نام:</label>
                        <input type="text" 
                               id="editFirstName" 
                               name="first_name" 
                               value="<?php echo htmlspecialchars($userData['first_name']); ?>"
                               required 
                               placeholder="نام">
                    </div>
                    <div class="form-group">
                        <label for="editLastName">نام خانوادگی:</label>
                        <input type="text" 
                               id="editLastName" 
                               name="last_name" 
                               value="<?php echo htmlspecialchars($userData['last_name']); ?>"
                               required 
                               placeholder="نام خانوادگی">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editNationalId">کد ملی (غیرقابل تغییر):</label>
                        <input type="text" 
                               id="editNationalId" 
                               name="national_id" 
                               value="<?php echo htmlspecialchars($userData['national_id']); ?>"
                               readonly
                               style="background-color: rgba(200, 200, 200, 0.3); cursor: not-allowed;"
                               title="کد ملی قابل تغییر نیست">
                        <small style="color: #999; font-size: 0.8rem;">🔒 کد ملی شما قابل تغییر نیست</small>
                    </div>
                    <div class="form-group">
                        <label for="editBirthDate">تاریخ تولد:</label>
                        <div class="date-input-container">
                            <input type="text" 
                                   id="editBirthDate" 
                                   name="birth_date" 
                                   value="<?php echo htmlspecialchars($userData['birth_date'] ?? ''); ?>"
                                   required 
                                   placeholder="مثال: 1394/05/15" 
                                   pattern="[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}">
                            <button type="button" class="date-picker-btn" onclick="openEditDatePicker()">📅</button>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="editAddress">آدرس منزل:</label>
                    <textarea id="editAddress" 
                              name="address" 
                              rows="2" 
                              required 
                              placeholder="آدرس کامل محل سکونت"><?php echo htmlspecialchars($userData['address'] ?? ''); ?></textarea>
                </div>
                
                <h3>👨‍👩‍👧‍👦 اطلاعات والدین</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editFatherName">نام پدر:</label>
                        <input type="text" 
                               id="editFatherName" 
                               name="father_name" 
                               value="<?php echo htmlspecialchars($userData['father_name'] ?? ''); ?>"
                               required 
                               placeholder="نام پدر">
                    </div>
                    <div class="form-group">
                        <label for="editFatherPhone">شماره تلفن پدر:</label>
                        <input type="tel" 
                               id="editFatherPhone" 
                               name="father_phone" 
                               value="<?php echo htmlspecialchars($userData['father_phone'] ?? ''); ?>"
                               required 
                               placeholder="09123456789">
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editMotherName">نام مادر:</label>
                        <input type="text" 
                               id="editMotherName" 
                               name="mother_name" 
                               value="<?php echo htmlspecialchars($userData['mother_name'] ?? ''); ?>"
                               required 
                               placeholder="نام مادر">
                    </div>
                    <div class="form-group">
                        <label for="editMotherPhone">شماره تلفن مادر:</label>
                        <input type="tel" 
                               id="editMotherPhone" 
                               name="mother_phone" 
                               value="<?php echo htmlspecialchars($userData['mother_phone'] ?? ''); ?>"
                               required 
                               placeholder="09123456789">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="editEmail">ایمیل (اختیاری):</label>
                    <input type="email" 
                           id="editEmail" 
                           name="email" 
                           value="<?php echo htmlspecialchars($userData['email'] ?? ''); ?>"
                           placeholder="example@email.com">
                </div>
                
                <h3>🔐 تغییر رمز عبور (اختیاری)</h3>
<div class="username-info-box" style="background: linear-gradient(135deg, #3498db, #2980b9);">
    <strong>💡 نکته مهم:</strong> 
    <ul style="margin: 10px 0 0 20px; text-align: right;">
        <li>اگر می‌خواهید رمز عبور خود را تغییر دهید، هر سه فیلد زیر را پر کنید</li>
        <li>اگر نمی‌خواهید رمز عبور را تغییر دهید، این فیلدها را <strong>خالی بگذارید</strong></li>
        <li>با خالی گذاشتن فیلدهای رمز، فقط اطلاعات شخصی شما بروزرسانی می‌شود</li>
    </ul>
</div>
                <div class="form-group">
    <label for="editCurrentPassword">رمز عبور فعلی:</label>
    <input type="password" 
           id="editCurrentPassword"          
           name="current_password" 
           placeholder="خالی بگذارید اگر نمی‌خواهید تغییر دهید"
           autocomplete="current-password">
</div>

<div class="form-group">
    <label for="editNewPassword">رمز عبور جدید:</label>
    <input type="password" 
           id="editNewPassword"              
           name="new_password" 
           placeholder="خالی بگذارید اگر نمی‌خواهید تغییر دهید"
           minlength="8"
           autocomplete="new-password">
</div>

<div class="form-group">
    <label for="editConfirmPassword">تأیید رمز عبور جدید:</label>
    <input type="password" 
           id="editConfirmPassword"        
           name="confirm_password" 
           placeholder="خالی بگذارید اگر نمی‌خواهید تغییر دهید"
           minlength="8"
           autocomplete="new-password">
</div>

                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="button" onclick="handleEditProfileSubmit(event); return false;" 
        class="submit-btn gradient-green interactive-element">
    💾 ذخیره تغییرات
</button>
                    <button type="button" onclick="showSection('home')" class="submit-btn interactive-element" 
                            style="flex: 1; background: linear-gradient(135deg, #e74c3c, #c0392b);">
                        ❌ انصراف
                    </button>
                </div>
            </form>
            
            <?php else: ?>
                <p style="text-align: center; color: #e74c3c;">خطا در بارگذاری اطلاعات کاربر</p>
            <?php endif; ?>
            
        <?php else: ?>
            <p style="text-align: center;">لطفاً ابتدا وارد حساب کاربری خود شوید.</p>
        <?php endif; ?>
    </div>
</section>
        <?php if($isLoggedIn): ?>
            <?php include 'sections/homework.php'; ?>
            <?php include 'sections/materials.php'; ?>
            <?php include 'sections/games.php'; ?>
            <?php include 'sections/podcast.php'; ?>
            <?php include 'sections/gallery.php'; ?>
            <?php include 'sections/feedback.php'; ?>
            
            <?php if($userType == 'admin'): ?>
                <?php include 'sections/admin.php'; ?>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php include 'sections/about.php'; ?>
        
    </main>
    
    <!-- Footer -->
    <footer class="glass-effect" style="margin-top: 4rem; padding: 2rem; text-align: center; border-radius: 25px 25px 0 0;">
        <p style="color: rgba(255, 255, 255, 0.8); margin-bottom: 1rem;">
            🌟 ساخته شده با ❤️ برای دانش‌آموزان عزیز کلاس چهارم
        </p>
        <p style="color: rgba(255, 255, 255, 0.6); font-size: 0.9rem;">
            © 2024 کلاس ستاره ماه - خانم نجمه محمودی
        </p>
    </footer>
    
    <!-- JavaScript -->
    <script src="script.js"></script>
    
    <!-- Additional JavaScript for enhanced functionality -->
    <script>
    window.addEventListener('load', function() {
        setTimeout(function() {
            const loadingScreen = document.getElementById('loadingScreen');
            if (loadingScreen) {
                loadingScreen.classList.add('hide');
                
                // Remove from DOM after transition
                setTimeout(function() {
                    loadingScreen.style.display = 'none';
                }, 500);
            }
        }, 3000); // 3 seconds delay - adjust as needed
    });
        
        // Initialize Persian Date Picker
      // Initialize Persian Date Picker - اصلاح شده
// تنظیم ساده تقویم شمسی
$(document).ready(function() {
    console.log('Document ready - setting up date picker');
    
    setTimeout(function() {
        if ($("#birthDate").length > 0) {
            $("#birthDate").pDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true,
                initialValue: false
            });
            console.log('Persian date picker initialized');
        }
    }, 1000);
});

// تابع کلیک دکمه تقویم
function openDatePicker() {
    console.log('Button clicked');
    $("#birthDate").focus();
}
// شروع راه‌اندازی با چندین تلاش
let initAttempts = 0;
function tryInitDatePicker() {
    initAttempts++;
    if (initAttempts > 10) {
        console.log('Max attempts reached for date picker initialization');
        return;
    }
    
    if (initBirthDatePicker()) {
        console.log('Date picker initialized on attempt:', initAttempts);
    } else {
        setTimeout(tryInitDatePicker, 300);
    }
}

// شروع راه‌اندازی
$(document).ready(function() {
    setTimeout(tryInitDatePicker, 100);
});

window.addEventListener('load', function() {
    setTimeout(tryInitDatePicker, 500);
});

// راه‌اندازی با تاخیر مناسب
$(document).ready(function() {
    // تاخیر برای اطمینان از بارگذاری کامل
    setTimeout(initBirthDatePicker, 500);
});

// تلاش مجدد بعد از بارگذاری کامل صفحه
window.addEventListener('load', function() {
    setTimeout(initBirthDatePicker, 1000);
});

// Open Date Picker Button - فقط Persian Date Picker
function openDatePicker() {
    console.log('Opening Persian date picker...');
    
    // چک کردن وجود کتابخانه‌ها
    if (typeof $ === 'undefined') {
        console.log('jQuery not loaded!');
        return;
    }
    
    if (typeof $.fn.pDatepicker === 'undefined') {
        console.log('pDatepicker not loaded!');
        return;
    }
    
    // تلاش برای باز کردن تقویم
    const $input = $("#birthDate");
    if ($input.length > 0) {
        $input.focus();
        
        // اگر instance تقویم وجود دارد
        if (window.birthDatePickerInstance) {
            try {
                window.birthDatePickerInstance.show();
            } catch(e) {
                console.log('Error opening picker:', e);
            }
        }
    }
}
        // Auto-copy National ID to Username
        document.getElementById('nationalId').addEventListener('input', function() {
            const nationalId = this.value;
            const usernameField = document.getElementById('username');
            usernameField.value = nationalId;
            
            // Add visual feedback
            if (nationalId.length === 10) {
                usernameField.style.backgroundColor = 'rgba(107, 207, 127, 0.3)';
                usernameField.style.borderColor = '#6bcf7f';
            } else {
                usernameField.style.backgroundColor = 'rgba(255, 217, 61, 0.2)';
                usernameField.style.borderColor = '#ffd93d';
            }
        });

        // Enhanced Login Type Switching
        function setLoginType(type) {
            const studentBtn = document.getElementById('studentLoginBtn');
            const teacherBtn = document.getElementById('teacherLoginBtn');
            const studentInstructions = document.getElementById('studentInstructions');
            const teacherInstructions = document.getElementById('teacherInstructions');
            const usernameInput = document.getElementById('loginUsername');
            const loginButtonText = document.getElementById('loginButtonText');
            const userTypeInput = document.getElementById('loginUserType');

            // Reset button styles
            studentBtn.classList.remove('active');
            teacherBtn.classList.remove('active');

            if (type === 'student') {
                studentBtn.classList.add('active');
                studentInstructions.style.display = 'block';
                teacherInstructions.style.display = 'none';
                usernameInput.placeholder = 'کد ملی خود را وارد کنید';
                loginButtonText.textContent = '🚀 ورود به کلاس';
                userTypeInput.value = 'student';
            } else {
                teacherBtn.classList.add('active');
                studentInstructions.style.display = 'none';
                teacherInstructions.style.display = 'block';
                usernameInput.placeholder = 'نام کاربری: admin';
                loginButtonText.textContent = '👩‍🏫 ورود به پنل مدیریت';
                userTypeInput.value = 'admin';
            }
        }

        // Form validation for national ID
        document.getElementById('nationalId').addEventListener('keypress', function(e) {
            // Only allow numbers
            if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
                e.preventDefault();
            }
        });

        // Recovery form national ID validation
        if (document.getElementById('recoveryNationalId')) {
            document.getElementById('recoveryNationalId').addEventListener('keypress', function(e) {
                if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
                    e.preventDefault();
                }
            });
        }

        // Show Messages Function
        function showMessage(message, type = 'info', duration = 5000) {
            // Remove existing messages
            const existingMessages = document.querySelectorAll('.message-overlay');
            existingMessages.forEach(msg => msg.remove());

            // Create new message
            const messageDiv = document.createElement('div');
            messageDiv.className = `message-overlay message-${type}`;
            messageDiv.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5rem;">${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
                    <span>${message}</span>
                    <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; font-size: 1.2rem; cursor: pointer; margin-right: auto;">×</button>
                </div>
            `;

            document.body.appendChild(messageDiv);

            // Auto remove after duration
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, duration);
        }
// Client-side validation for password match in recovery form
document.getElementById('recoveryForm').addEventListener('submit', function(e) {
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;
    if (newPass !== confirmPass) {
        e.preventDefault();
        showMessage('❌ رمز عبور جدید و تأیید آن مطابقت ندارند', 'error');
        return;
    }
    // بقیه handler AJAX که قبلاً وجود دارد ادامه می‌یابد
});
        // Handle Login Form - نسخه اصلاح شده
(function() {
    console.log('🔧 Setting up login handler...');
    
    function attachLoginHandler() {
        const loginForm = document.getElementById('loginForm');
        
        if (!loginForm) {
            console.log('⏳ Login form not found, retrying...');
            setTimeout(attachLoginHandler, 200);
            return;
        }
        
        console.log('✅ Login form found!');
        
        // حذف event listener های قبلی
        loginForm.onsubmit = null;
        
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            
            console.log('📤 Login form submitted via AJAX');
            
            const formData = new FormData(this);
            formData.append('action', 'login'); // اضافه کردن action
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn ? submitBtn.innerHTML : '';
            
            // غیرفعال کردن دکمه
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '⏳ در حال ورود...';
            }

            fetch('auth.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                console.log('📥 Response received:', response.status);
                if (!response.ok) throw new Error('Network error');
                return response.json();
            })
            .then(data => {
                console.log('📊 Response data:', data);
                
                if (data.success) {
                    // نمایش پیام موفقیت
                    const messageDiv = document.createElement('div');
                    messageDiv.className = 'message-overlay message-success';
                    messageDiv.style.cssText = `
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        z-index: 99999;
                        background: linear-gradient(135deg, rgba(107, 207, 127, 0.95), rgba(60, 179, 113, 0.95));
                        color: white;
                        padding: 1rem 1.5rem;
                        border-radius: 15px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        animation: slideIn 0.5s ease;
                        font-weight: 600;
                        border-left: 4px solid #6bcf7f;
                    `;
                    messageDiv.innerHTML = `
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-size: 1.5rem;">✅</span>
                            <span>🎉 ورود موفقیت‌آمیز! در حال انتقال...</span>
                        </div>
                    `;
                    
                    document.body.appendChild(messageDiv);
                    
                    // هدایت به صفحه اصلی
                    setTimeout(() => {
                        window.location.href = 'index.php';
                    }, 1500);
                    
                } else {
                    // نمایش پیام خطا
                    const messageDiv = document.createElement('div');
                    messageDiv.className = 'message-overlay message-error';
                    messageDiv.style.cssText = `
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        z-index: 99999;
                        background: linear-gradient(135deg, rgba(255, 107, 107, 0.95), rgba(220, 20, 60, 0.95));
                        color: white;
                        padding: 1rem 1.5rem;
                        border-radius: 15px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        font-weight: 600;
                        border-left: 4px solid #ff6b6b;
                    `;
                    messageDiv.innerHTML = `
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-size: 1.5rem;">❌</span>
                            <span>${data.message || 'خطا در ورود'}</span>
                            <button onclick="this.parentElement.parentElement.remove()" 
                                    style="background: none; border: none; color: white; font-size: 1.2rem; cursor: pointer; margin-right: auto;">×</button>
                        </div>
                    `;
                    
                    document.body.appendChild(messageDiv);
                    
                    // فعال کردن مجدد دکمه
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    }
                    
                    // حذف خودکار پیام خطا
                    setTimeout(() => messageDiv.remove(), 5000);
                }
            })
            .catch(error => {
                console.error('❌ Login error:', error);
                
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message-overlay message-error';
                messageDiv.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 99999;
                    background: linear-gradient(135deg, rgba(255, 107, 107, 0.95), rgba(220, 20, 60, 0.95));
                    color: white;
                    padding: 1rem 1.5rem;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                    font-weight: 600;
                `;
                messageDiv.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.5rem;">❌</span>
                        <span>خطا در ارتباط با سرور</span>
                    </div>
                `;
                
                document.body.appendChild(messageDiv);
                
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
                
                setTimeout(() => messageDiv.remove(), 5000);
            });
            
            return false;
        });
        
        console.log('✅ Login handler attached successfully');
    }
    
    // شروع
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachLoginHandler);
    } else {
        attachLoginHandler();
    }
    
})();

// اضافه کردن animation
if (!document.getElementById('login-animations')) {
    const style = document.createElement('style');
    style.id = 'login-animations';
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
}

        // Check for URL parameters to show messages
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('message')) {
            const messageType = urlParams.get('type') || 'info';
            showMessage(decodeURIComponent(urlParams.get('message')), messageType);
            
            // Clean URL
            const url = new URL(window.location);
            url.searchParams.delete('message');
            url.searchParams.delete('type');
            window.history.replaceState({}, document.title, url);
        }

        console.log('🌟 سایت ستاره ماه با تمام تغییرات جدید بارگذاری شد!');
   function showDateHelper() {
    const input = document.getElementById('birthDate');
    const currentYear = new Date().getFullYear() - 621; // تقریبی سال شمسی فعلی
    
    const examples = [
        `${currentYear-10}/01/01`,
        `${currentYear-10}/06/31`, 
        `${currentYear-10}/12/29`
    ];
    
    const randomExample = examples[Math.floor(Math.random() * examples.length)];
    
    if (!input.value) {
        input.value = randomExample;
        input.select();
    }
    
    input.focus();
}
// تایمر تا پایان هفته - اضافه کردن به JavaScript موجود
function updateWeekCountdown() {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 = یکشنبه
    const daysUntilSunday = (7 - dayOfWeek) % 7;
    const nextSunday = new Date(now);
    nextSunday.setDate(now.getDate() + daysUntilSunday);
    nextSunday.setHours(23, 59, 59, 999);
    
    const timeDiff = nextSunday.getTime() - now.getTime();
    
    if (timeDiff > 0) {
        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        
        let countdown = '';
        if (days > 0) countdown += `${days} روز `;
        if (hours > 0) countdown += `${hours} ساعت `;
        countdown += `${minutes} دقیقه`;
        
        const countdownElement = document.getElementById('week-countdown');
        if (countdownElement) {
            countdownElement.textContent = countdown;
        }
    }
}

// بروزرسانی هر دقیقه
setInterval(updateWeekCountdown, 60000);
updateWeekCountdown(); // اجرای اولیه
   // اصلاح تابع toggleStudentSelection
function toggleStudentSelection(element, id, name, nationalId) {
    element.classList.toggle('selected');
    const indicator = element.querySelector('.selection-indicator .check-mark');
    if (indicator) {
        indicator.style.opacity = element.classList.contains('selected') ? '1' : '0';
    }
    
    const index = selectedStudents.findIndex(s => s.id === id);
    if (index === -1) {
        selectedStudents.push({id, name, nationalId});
    } else {
        selectedStudents.splice(index, 1);
    }
    
    updateStudentsCounter();
    updateSummary();
    checkSubmitButton(); // اضافه کردن این خط
}

// اصلاح تابع toggleDisciplineSelection
function toggleDisciplineSelection(element, title, score) {
    element.classList.toggle('selected');
    const indicator = element.querySelector('.selection-indicator .check-mark');
    if (indicator) {
        indicator.style.opacity = element.classList.contains('selected') ? '1' : '0';
    }
    
    const index = selectedDisciplines.findIndex(d => d.title === title);
    if (index === -1) {
        selectedDisciplines.push({title, score});
    } else {
        selectedDisciplines.splice(index, 1);
    }
    
    updateDisciplinesCounter();
    updateSummary();
    checkSubmitButton(); // اضافه کردن این خط
}

// تعریف تابع initBirthDatePicker اگر وجود ندارد
if (typeof initBirthDatePicker === 'undefined') {
    function initBirthDatePicker() {
        console.log('Date picker initialized (fallback)');
        // اگر کتابخانه date picker وجود دارد، آن را فراخوانی کنید
        if (typeof $.fn.persianDatepicker !== 'undefined') {
            $('.birth-date-input').persianDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true
            });
        }
    }
}
// Handle Registration Form - AJAX submission
document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    // غیرفعال کردن دکمه و نمایش پیام در حال پردازش
    submitBtn.disabled = true;
    submitBtn.innerHTML = '⏳ در حال ثبت‌نام...';
    
    fetch('auth.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) throw new Error('Network error');
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // نمایش پیام موفقیت
            showMessage(data.message || 'ثبت‌نام با موفقیت انجام شد!', 'success');
            
            // پس از چند ثانیه به صفحه ورود هدایت کن
            setTimeout(() => {
                showSection('login');
            }, 2000);
        } else {
            // نمایش پیام خطا
            showMessage(data.message || 'خطا در ثبت‌نام', 'error');
        }
    })
    .catch(error => {
        console.error('Registration error:', error);
        showMessage('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.', 'error');
    })
    .finally(() => {
        // فعال کردن مجدد دکمه
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    });
});
// تنظیم تقویم شمسی برای فرم ویرایش - بدون loop
let editDatePickerInitialized = false;

function initEditBirthDatePicker() {
    if (editDatePickerInitialized) {
        console.log('Edit date picker already initialized');
        return true;
    }
    
    if (typeof $.fn.pDatepicker !== 'undefined' && $("#editBirthDate").length > 0) {
        try {
            $("#editBirthDate").pDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true,
                initialValue: false
            });
            editDatePickerInitialized = true;
            console.log('✅ Edit profile date picker initialized');
            return true;
        } catch(e) {
            console.error('Error initializing edit date picker:', e);
            return false;
        }
    }
    return false;
}

// باز کردن تقویم برای فرم ویرایش
function openEditDatePicker() {
    const $input = $("#editBirthDate");
    if ($input.length > 0) {
        $input.focus();
    }
}

// راه‌اندازی تقویم فقط یک بار هنگام نمایش بخش ویرایش
let editSectionObserverAdded = false;

$(document).ready(function() {
    if (!editSectionObserverAdded) {
        editSectionObserverAdded = true;
        
        // نظارت بر تغییر section فقط یک بار
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                const editSection = document.getElementById('editProfile');
                if (editSection && editSection.classList.contains('active') && !editDatePickerInitialized) {
                    setTimeout(function() {
                        initEditBirthDatePicker();
                    }, 500);
                }
            });
        });
        
        observer.observe(document.body, {
            attributes: true,
            attributeFilter: ['class'],
            subtree: true
        });
    }
});

// Handle Edit Profile Form - با inline approach
function handleEditProfileSubmit(event) {
    // جلوگیری از submit معمولی
    if (event) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
    }
    
    console.log('🚀 handleEditProfileSubmit called');
    
    const form = document.getElementById('editProfileForm');
    if (!form) {
        console.error('Form not found!');
        return false;
    }
    
    // دریافت مقادیر
    const firstName = document.getElementById('editFirstName').value.trim();
    const lastName = document.getElementById('editLastName').value.trim();
    const currentPassword = document.getElementById('editCurrentPassword').value;
    const newPassword = document.getElementById('editNewPassword').value;
    const confirmPassword = document.getElementById('editConfirmPassword').value;
    
    console.log('Values:', {
        firstName: firstName,
        lastName: lastName,
        currentPassword: currentPassword ? 'filled' : 'empty',
        newPassword: newPassword ? 'filled' : 'empty',
        confirmPassword: confirmPassword ? 'filled' : 'empty'
    });
    
    // Validation اجباری
    if (!firstName || !lastName) {
        showMessage('❌ نام و نام خانوادگی الزامی است', 'error');
        return false;
    }
    
    // بررسی رمز عبور
    const hasAnyPassword = currentPassword || newPassword || confirmPassword;
    
    if (hasAnyPassword) {
        console.log('Password fields filled - validating...');
        
        if (!currentPassword) {
            showMessage('❌ برای تغییر رمز عبور، باید رمز فعلی را وارد کنید', 'error');
            return false;
        }
        if (!newPassword) {
            showMessage('❌ لطفاً رمز عبور جدید را وارد کنید', 'error');
            return false;
        }
        if (!confirmPassword) {
            showMessage('❌ لطفاً تأیید رمز عبور جدید را وارد کنید', 'error');
            return false;
        }
        if (newPassword !== confirmPassword) {
            showMessage('❌ رمز عبور جدید و تأیید آن یکسان نیستند', 'error');
            return false;
        }
        if (newPassword.length < 8) {
            showMessage('❌ رمز عبور باید حداقل ۸ کاراکتر باشد', 'error');
            return false;
        }
        
        console.log('✅ Password validation passed');
    } else {
        console.log('ℹ️ No password change - fields are empty');
    }
    
    // ارسال
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : '';
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ در حال ذخیره...';
    }
    
    console.log('📤 Sending to auth.php...');
    
    fetch('auth.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(function(response) {
        console.log('📥 Response:', response.status);
        return response.text();
    })
    .then(function(text) {
        console.log('📄 Text:', text.substring(0, 200));
        
        try {
            const data = JSON.parse(text);
            console.log('✅ Data:', data);
            
            if (data.success) {
                showMessage(data.message || '✅ اطلاعات ذخیره شد', 'success');
                setTimeout(function() {
                    location.reload();
                }, 1500);
            } else {
                showMessage(data.message || '❌ خطا', 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
            }
        } catch (e) {
            console.error('❌ Parse error:', e);
            showMessage('❌ خطا در پاسخ سرور', 'error');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    })
    .catch(function(error) {
        console.error('❌ Fetch error:', error);
        showMessage('❌ خطا در ارتباط', 'error');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
    
    return false;
}

// اتصال به فرم
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        const form = document.getElementById('editProfileForm');
        if (form) {
            // حذف تمام listeners قبلی
            form.onsubmit = null;
            
            // اضافه کردن listener جدید
            form.onsubmit = handleEditProfileSubmit;
            
            console.log('✅ Edit form handler attached via onsubmit');
        } else {
            console.log('⚠️ Edit form not found');
        }
    }, 1000);
});
    </script>
</body>
</html>