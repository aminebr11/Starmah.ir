<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// دریافت آمار کلی بازی‌ها
try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM games WHERE is_active = 1");
    $stmt->execute();
    $total_games = $stmt->fetchColumn();
    
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT student_id) FROM game_results WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute();
    $active_players = $stmt->fetchColumn();
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM game_results WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $stmt->execute();
    $weekly_plays = $stmt->fetchColumn();
    
    $stmt = $conn->prepare("SELECT AVG(score) FROM game_results WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute();
    $avg_score = $stmt->fetchColumn() ?: 0;
    
} catch (Exception $e) {
    $total_games = 0;
    $active_players = 0;
    $weekly_plays = 0;
    $avg_score = 0;
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت بازی‌ها</title>
    
    <style>
    /* اضافه کردن به بخش <style> */

/* تصحیح رنگ محتوای مدال */
.badge-modal-body { 
    padding: 2rem; 
    color: #000 !important;  /* تغییر از #333 به #000 */
    background: #fff;
}

.badge-modal-body * {
    color: #000 !important;  /* اطمینان از سیاه بودن همه متن‌ها */
}

/* استایل جداول تاریخچه با رنگ مشکی */
.history-table { 
    width: 100%; 
    border-collapse: collapse; 
    margin-top: 1rem;
    background: #fff;
}

.history-table th { 
    background: #f8f9fa !important;
    color: #000 !important;
    padding: 0.75rem; 
    text-align: right; 
    border-bottom: 2px solid #dee2e6;
    font-weight: 700;
}

.history-table td { 
    padding: 0.75rem; 
    border-bottom: 1px solid #dee2e6;
    color: #000 !important;  /* رنگ مشکی برای محتوا */
    background: #fff;
}

.history-table tbody tr:hover {
    background: #f8f9fa !important;
}

/* تصحیح رنگ فرم‌ها */
.form-group label {
    color: #000 !important;
    font-weight: 600;
}

.form-group input, 
.form-group select, 
.form-group textarea { 
    padding: 0.8rem; 
    border: 2px solid #ddd; 
    border-radius: 8px; 
    font-family: inherit;
    color: #000 !important;
    background: #fff !important;
}

.form-group select option {
    background: #fff;
    color: #000;
}

/* تصحیح small text */
.form-group small {
    color: #666 !important;
    font-size: 0.85rem;
}

/* آمار در مدال */
.badge-modal-body h4 {
    color: #000 !important;
    margin-bottom: 1rem;
    font-weight: 700;
}

/* دکمه‌های عملیات */
.history-actions {
    display: flex; 
    gap: 0.5rem; 
    justify-content: center;
}

.btn-delete, .btn-edit {
    font-family: inherit;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-delete:hover {
    background: #c82333;
    transform: translateY(-1px);
}

.btn-edit:hover {
    background: #e0a800;
    transform: translateY(-1px);
}
        /* استایل‌های کلی */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tahoma', 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
            direction: rtl;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }

        /* کارت‌های آمار با رنگ‌های جذاب‌تر */
        .games-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            padding: 1.5rem;
            text-align: center;
            border-radius: 20px;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.2);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--card-accent, #ff6b6b);
            border-radius: 20px 20px 0 0;
        }

        /* رنگ‌های متفاوت برای هر کارت */
        .games-stat {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.15), rgba(255, 182, 193, 0.15));
            --card-accent: #ff6b6b;
            color: #fff;
        }

        .players-stat {
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.15), rgba(144, 224, 239, 0.15));
            --card-accent: #4a90e2;
            color: #fff;
        }

        .plays-stat {
            background: linear-gradient(135deg, rgba(46, 213, 115, 0.15), rgba(123, 237, 159, 0.15));
            --card-accent: #2ed573;
            color: #fff;
        }

        .score-stat {
            background: linear-gradient(135deg, rgba(255, 159, 67, 0.15), rgba(255, 206, 84, 0.15));
            --card-accent: #ff9f43;
            color: #fff;
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            filter: drop-shadow(0 5px 10px rgba(0,0,0,0.3));
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 900;
            display: block;
            margin: 0.5rem 0;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }

        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
            margin: 0;
            font-weight: 600;
        }

        /* تب‌های مدیریت جدید */
        .admin-games-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            justify-content: center;
        }

        .games-tab-btn {
            background: rgba(255,255,255,0.1);
            border: 2px solid rgba(255,255,255,0.2);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: inherit;
            font-weight: 600;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
            position: relative;
            overflow: hidden;
        }

        .games-tab-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .games-tab-btn:hover::before {
            left: 100%;
        }

        .games-tab-btn:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }

        .games-tab-btn.active {
            background: linear-gradient(135deg, #28a745, #20c997);
            border-color: #28a745;
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.4);
            transform: translateY(-2px);
        }

        /* محتوای تب‌ها */
        .games-tab-content {
            display: none;
            animation: fadeInUp 0.4s ease;
        }

        .games-tab-content.active {
            display: block;
        }

        .glass-effect {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }

        /* صفحه مدیریت بازی‌ها */
        .management-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .management-header h3 {
            margin: 0;
            font-size: 2rem;
            font-weight: 800;
            color: white;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }

        .add-game-btn {
            background: linear-gradient(135deg, #ff6b6b, #ffd93d);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            font-family: inherit;
            box-shadow: 0 8px 20px rgba(255, 107, 107, 0.4);
        }

        .add-game-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(255, 107, 107, 0.6);
        }

        /* فیلتر بازی‌ها */
        .games-filter {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .games-filter select {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.75rem 1rem;
            border-radius: 15px;
            font-family: inherit;
            font-size: 1rem;
        }

        .games-filter select:focus {
            outline: none;
            border-color: #ffd93d;
            box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
        }

        .games-filter select option {
            background: #333;
            color: white;
        }

        /* جدول بازی‌ها */
        .games-table-container {
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            overflow: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .games-table {
            width: 100%;
            border-collapse: collapse;
        }

        .games-table th {
            background: rgba(0,0,0,0.3);
            color: white;
            padding: 1.5rem 1rem;
            text-align: right;
            font-weight: 700;
            font-size: 1.1rem;
            border-bottom: 2px solid rgba(255,255,255,0.2);
        }

        .games-table td {
            padding: 1.2rem 1rem;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            font-size: 1rem;
        }

        .games-table tbody tr {
            transition: all 0.3s ease;
        }

        .games-table tbody tr:hover {
            background: rgba(255,255,255,0.1);
            transform: scale(1.01);
        }

        /* نشان‌های وضعیت */
        .status-active {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .status-inactive {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* دکمه‌های عملیات */
        .game-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .game-actions button {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.5rem;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.2rem;
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .game-actions button:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .delete-btn:hover {
            background: rgba(220, 53, 69, 0.8) !important;
        }

        /* محتوای خالی برای تب‌های دیگر */
        .tab-placeholder {
            text-align: center;
            padding: 4rem 2rem;
            color: rgba(255,255,255,0.8);
        }

        .tab-placeholder h4 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #ffd93d;
        }

        .tab-placeholder p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        /* انیمیشن‌ها */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* استایل‌های مودال */
        .game-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.8);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            padding: 1rem;
            box-sizing: border-box;
        }

        .game-modal.show {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        .modal-backdrop {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }

        .modal-container {
            position: relative;
            background: white;
            border-radius: 20px;
            width: 100%;
            max-width: 900px;
            max-height: 90vh;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            animation: slideUp 0.3s ease;
        }

        .modal-container.large {
            max-width: 1200px;
        }

        .modal-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 700;
        }

        .modal-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }

        .modal-body {
            padding: 2rem;
            max-height: 60vh;
            overflow-y: auto;
            color: #333;
        }

        .modal-footer {
            background: #f8f9fa;
            padding: 1.5rem 2rem;
            border-top: 1px solid #eee;
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
        }

        /* فرم‌ها */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        .required {
            color: #dc3545;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-family: inherit;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-group textarea[name="game_code"] {
            font-family: 'Courier New', monospace;
            direction: ltr;
            text-align: left;
            font-size: 0.9rem;
            line-height: 1.6;
            min-height: 300px;
        }

        /* دکمه‌ها */
        .btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .btn-primary {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }

        /* آمار نتایج */
        .results-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-item {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 900;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        /* فیلترهای نتایج */
        .results-filters {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        .results-filters input,
        .results-filters select {
            padding: 0.6rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        /* جدول نتایج */
        .results-table-container {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
        }

        .results-table th {
            background: #f8f9fa;
            padding: 1rem;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid #ddd;
            position: sticky;
            top: 0;
        }

        .results-table td {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid #eee;
        }

        .results-table tbody tr:hover {
            background: #f8f9fa;
        }

        /* انیمیشن‌ها */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* لودینگ */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* استایل‌های صفحه مدیریت نتایج */
        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .results-header h3 {
            margin: 0;
            font-size: 2rem;
            font-weight: 800;
            color: white;
            text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }

        .results-actions {
            display: flex;
            gap: 1rem;
        }

        .export-btn, .refresh-btn {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 15px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .refresh-btn {
            background: linear-gradient(135deg, #17a2b8, #138496);
        }

        .export-btn:hover, .refresh-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        /* داشبورد آماری */
        .results-dashboard {
            margin-bottom: 2rem;
        }

        .stats-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-box {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 20px;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }

        .stat-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--accent-color, #28a745);
            border-radius: 20px 20px 0 0;
        }

        .total-results { --accent-color: #ff6b6b; }
        .avg-score { --accent-color: #4ecdc4; }
        .best-score { --accent-color: #ffd93d; }
        .avg-time { --accent-color: #6c5ce7; }
        .total-players { --accent-color: #fd79a8; }
        .avg-accuracy { --accent-color: #00b894; }

        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }

        .stat-content {
            flex: 1;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 900;
            color: white;
            line-height: 1;
            margin-bottom: 0.3rem;
        }

        .stat-label {
            font-size: 0.9rem;
            color: rgba(255,255,255,0.8);
            font-weight: 600;
        }

        /* نمودارها */
        .charts-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .chart-container {
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 1.5rem;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .chart-container h4 {
            color: white;
            margin-bottom: 1rem;
            font-weight: 700;
        }

        .chart-container canvas {
            max-height: 300px;
        }

        /* فیلترهای پیشرفته */
        .results-filters {
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .filter-section h4 {
            color: white;
            margin-bottom: 1rem;
            font-weight: 700;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            align-items: end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .filter-group label {
            color: rgba(255,255,255,0.9);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .filter-group input,
        .filter-group select {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.8rem;
            border-radius: 10px;
            font-family: inherit;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #ffd93d;
            box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
        }

        .filter-group input::placeholder {
            color: rgba(255,255,255,0.6);
        }

        .filter-group select option {
            background: #333;
            color: white;
        }

        .filter-actions {
            display: flex;
            gap: 0.5rem;
            flex-direction: column;
        }

        .apply-filters-btn, .clear-filters-btn {
            padding: 0.8rem 1rem;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .apply-filters-btn {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }

        .clear-filters-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid rgba(255,255,255,0.3);
        }

        .apply-filters-btn:hover, .clear-filters-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* جدول نتایج */
        .results-table-section {
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            padding: 1.5rem;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .table-header h4 {
            color: white;
            margin: 0;
            font-weight: 700;
        }

        .table-info {
            display: flex;
            gap: 2rem;
            align-items: center;
            color: rgba(255,255,255,0.8);
            font-size: 0.9rem;
        }

        .pagination-info {
            font-weight: 600;
        }

        .table-container {
            overflow: auto;
            border-radius: 15px;
            margin-bottom: 1rem;
            max-height: 600px;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
        }

        .results-table th {
            background: rgba(0,0,0,0.3);
            color: white;
            padding: 1rem;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid rgba(255,255,255,0.2);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .results-table td {
            padding: 1rem;
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .results-table tbody tr {
            transition: all 0.3s ease;
        }

        .results-table tbody tr:hover {
            background: rgba(255,255,255,0.1);
        }

        .results-table tbody tr.selected {
            background: rgba(255, 217, 61, 0.2);
        }

        /* نشان‌های امتیاز */
        .score-badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .score-excellent { background: linear-gradient(135deg, #00b894, #00cec9); color: white; }
        .score-good { background: linear-gradient(135deg, #fdcb6e, #e17055); color: white; }
        .score-average { background: linear-gradient(135deg, #fd79a8, #fdcb6e); color: white; }
        .score-poor { background: linear-gradient(135deg, #636e72, #2d3436); color: white; }

        .accuracy-badge {
            padding: 0.2rem 0.6rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .accuracy-high { background: #00b894; color: white; }
        .accuracy-medium { background: #fdcb6e; color: #333; }
        .accuracy-low { background: #e17055; color: white; }

        /* دکمه‌های عملیات */
        .result-actions {
            display: flex;
            gap: 0.5rem;
        }

        .result-actions button {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.4rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .result-actions button:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        .edit-result-btn:hover { background: rgba(255, 193, 7, 0.8) !important; }
        .delete-result-btn:hover { background: rgba(220, 53, 69, 0.8) !important; }

        /* صفحه‌بندی */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin: 1.5rem 0;
        }

        .page-btn {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.6rem 1rem;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .page-btn:hover:not(:disabled) {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        .page-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .page-numbers {
            display: flex;
            gap: 0.3rem;
        }

        .page-number {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.5rem 0.8rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 40px;
            text-align: center;
        }

        .page-number.active {
            background: linear-gradient(135deg, #ffd93d, #fdcb6e);
            color: #333;
            border-color: #ffd93d;
        }

        .page-number:hover:not(.active) {
            background: rgba(255,255,255,0.3);
        }

        /* عملیات گروهی */
        .bulk-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 217, 61, 0.2);
            border: 2px solid rgba(255, 217, 61, 0.5);
            border-radius: 15px;
            padding: 1rem;
            margin-top: 1rem;
        }

        .selected-count {
            color: white;
            font-weight: 600;
        }

        .bulk-delete-btn, .bulk-export-btn {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            padding: 0.6rem 1rem;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-left: 0.5rem;
        }

        .bulk-delete-btn:hover {
            background: rgba(220, 53, 69, 0.8);
        }

        .bulk-export-btn:hover {
            background: rgba(40, 167, 69, 0.8);
        }

        /* ریسپانسیو برای موبایل */
        @media (max-width: 768px) {
            .stats-overview {
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
            }

            .charts-section {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .filters-grid {
                grid-template-columns: 1fr;
            }

            .filter-actions {
                flex-direction: column;
            }

            .table-header {
                flex-direction: column;
                align-items: stretch;
            }

            .table-info {
                justify-content: space-between;
            }

            .results-table {
                font-size: 0.8rem;
            }

            .results-table th,
            .results-table td {
                padding: 0.5rem;
            }

            .bulk-actions {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .results-actions {
                flex-direction: column;
                width: 100%;
            }
        }

        /* ریسپانسیو برای موبایل */
        @media (max-width: 768px) {
            .games-stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
            }
            
            .admin-games-tabs {
                justify-content: flex-start;
                overflow-x: auto;
                padding-bottom: 10px;
                gap: 0.5rem;
            }
            
            .games-tab-btn {
                padding: 0.8rem 1rem;
                font-size: 0.9rem;
                white-space: nowrap;
                min-width: 140px;
                flex-shrink: 0;
            }
            
            .management-header {
                flex-direction: column;
                align-items: stretch;
                text-align: center;
            }
            
            .management-header h3 {
                font-size: 1.5rem;
                margin-bottom: 1rem;
            }
            
            .add-game-btn {
                width: 100%;
                max-width: 300px;
                margin: 0 auto;
            }

            .modal-container {
                margin: 1rem;
                max-height: 95vh;
            }

            .form-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .modal-header {
                padding: 1rem 1.5rem;
            }

            .modal-body {
                padding: 1.5rem;
            }

            .modal-footer {
                flex-direction: column;
                padding: 1rem 1.5rem;
            }

            .results-stats {
                grid-template-columns: 1fr 1fr;
            }

            .results-filters {
                flex-direction: column;
            }
        }
                /* اصلاح استایل‌های جدول نتایج درون مودال */
        #gameResultsModal .modal-container {
            /* در حالت نیاز به حداکثر پهنا برای مودال بزرگ */
            max-width: 1200px;
        }

        #gameResultsModal .results-table-container {
            /* حذف Border داخلی که قبلاً سفید بود */
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }

        #gameResultsModal .results-table {
            background: white; /* پس زمینه روشن جدول */
        }
        
        #gameResultsModal .results-table th {
            background: #e9ecef; /* سربرگ خاکستری روشن */
            color: #495057; /* رنگ متن تیره */
            font-weight: 700;
        }

        #gameResultsModal .results-table td {
            color: #333; /* رنگ متن تیره */
            border-bottom: 1px solid #f8f9fa;
        }

        #gameResultsModal .results-table tbody tr:hover {
            background: #f1f3f5; /* هاور روشن */
        }
        
        .modal-results-actions {
            display: flex;
            justify-content: flex-end; 
            align-items: center;
            margin-bottom: 1rem; 
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .delete-all-btn {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        .delete-all-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(220, 53, 69, 0.4);
        }

        /* بهبود ظاهر دکمه‌های عملگرهای داخل مودال */
        #gameResultsModal .result-actions button {
            background: #adb5bd; 
            color: white;
            border: none;
            padding: 0.5rem;
            border-radius: 6px;
            font-size: 0.8rem;
            width: 30px;
            height: 30px;
        }
        
        #gameResultsModal .result-actions button:hover {
            transform: translateY(-1px);
        }
        
        #gameResultsModal .edit-result-btn:hover { background: #ffc107 !important; color: #333 !important; }
        #gameResultsModal .delete-result-btn:hover { background: #dc3545 !important; }

        @media (max-width: 768px) {
            .modal-results-actions {
                 justify-content: center;
            }
        }
        
    /* =================== استایل‌های پرامپت‌ساز =================== */

/* هدر جادویی */
.prompt-wizard-header {
    text-align: center;
    padding: 2rem;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}

.wizard-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
    filter: drop-shadow(0 5px 15px rgba(0,0,0,0.3));
}

.prompt-wizard-header h3 {
    color: white;
    font-size: 2.5rem;
    font-weight: 900;
    margin: 1rem 0 0.5rem 0;
    text-shadow: 0 3px 15px rgba(0,0,0,0.4);
}

.prompt-wizard-header p {
    color: rgba(255,255,255,0.9);
    font-size: 1.2rem;
    margin-bottom: 1rem;
    font-weight: 500;
}

.wizard-sparkles {
    font-size: 1.5rem;
    letter-spacing: 1rem;
    animation: sparkle 2s ease-in-out infinite;
}

@keyframes sparkle {
    0%, 100% { opacity: 0.6; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.1); }
}

/* مرحله‌بندی */
.wizard-steps {
    display: flex;
    justify-content: center;
    gap: 3rem;
    margin-bottom: 3rem;
    position: relative;
}

.wizard-steps::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 20%;
    right: 20%;
    height: 3px;
    background: linear-gradient(90deg, #ffd93d, #667eea);
    border-radius: 2px;
    z-index: 1;
}

.step-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 2;
    transition: all 0.4s ease;
}

.step-number {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    border: 3px solid rgba(255,255,255,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: 900;
    color: white;
    margin-bottom: 0.5rem;
    transition: all 0.4s ease;
}

.step-title {
    color: rgba(255,255,255,0.8);
    font-weight: 600;
    font-size: 0.9rem;
    text-align: center;
}

.step-item.active .step-number {
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    border-color: #ffd93d;
    color: #333;
    transform: scale(1.1);
    box-shadow: 0 5px 20px rgba(255, 217, 61, 0.5);
}

.step-item.active .step-title {
    color: #ffd93d;
    font-weight: 700;
}

.step-item.completed .step-number {
    background: linear-gradient(135deg, #28a745, #20c997);
    border-color: #28a745;
    color: white;
}

.step-item.completed .step-title {
    color: #28a745;
}

/* کانتینر جادوگر */
.wizard-container {
    max-width: 900px;
    margin: 0 auto;
}

/* مراحل */
.wizard-step {
    display: none;
    animation: slideInFromRight 0.5s ease;
}

.wizard-step.active {
    display: block;
}

@keyframes slideInFromRight {
    from {
        opacity: 0;
        transform: translateX(50px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.step-header {
    text-align: center;
    margin-bottom: 2rem;
}

.step-header h4 {
    color: white;
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
}

.step-header p {
    color: rgba(255,255,255,0.8);
    font-size: 1.1rem;
}

/* گرید موضوعات */
.subject-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.subject-card {
    background: rgba(255,255,255,0.1);
    border: 3px solid rgba(255,255,255,0.2);
    border-radius: 20px;
    padding: 1.5rem 1rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.subject-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
    transition: left 0.5s;
}

.subject-card:hover::before {
    left: 100%;
}

.subject-card:hover {
    background: rgba(255,255,255,0.2);
    border-color: #ffd93d;
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
}

.subject-card.selected {
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    border-color: #ffd93d;
    color: #333;
    transform: scale(1.05);
    box-shadow: 0 10px 30px rgba(255, 217, 61, 0.4);
}

.subject-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    filter: drop-shadow(0 2px 8px rgba(0,0,0,0.3));
}

.subject-name {
    font-weight: 700;
    font-size: 1.1rem;
    color: white;
}

.subject-card.selected .subject-name {
    color: #333;
}

/* انتخابگر مقطع */
.grade-selector {
    margin-bottom: 2rem;
}

.grade-selector label {
    display: block;
    color: white;
    font-weight: 700;
    font-size: 1.2rem;
    margin-bottom: 1rem;
    text-align: center;
}

.grade-pills {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    justify-content: center;
}

.grade-pill {
    background: rgba(255,255,255,0.1);
    border: 2px solid rgba(255,255,255,0.2);
    color: white;
    padding: 0.8rem 1.5rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.grade-pill:hover {
    background: rgba(255,255,255,0.2);
    border-color: #ffd93d;
    transform: translateY(-2px);
}

.grade-pill.selected {
    background: linear-gradient(135deg, #28a745, #20c997);
    border-color: #28a745;
    color: white;
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
}

/* تنظیمات بازی */
.settings-grid {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.setting-group {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.setting-group label {
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
}

.setting-group input[type="text"], 
.setting-group textarea {
    background: rgba(255,255,255,0.1);
    border: 2px solid rgba(255,255,255,0.2);
    color: white;
    padding: 1rem;
    border-radius: 15px;
    font-family: inherit;
    font-size: 1rem;
    resize: vertical;
}

.setting-group input:focus, 
.setting-group textarea:focus {
    outline: none;
    border-color: #ffd93d;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
}

.setting-group input::placeholder, 
.setting-group textarea::placeholder {
    color: rgba(255,255,255,0.6);
}

/* گرید انواع بازی */
.game-type-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 1rem;
}

.game-type-card {
    background: rgba(255,255,255,0.1);
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.game-type-card:hover {
    background: rgba(255,255,255,0.2);
    border-color: #ffd93d;
    transform: translateY(-3px);
}

.game-type-card.selected {
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-color: #667eea;
    color: white;
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.type-icon {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}

.type-name {
    font-weight: 600;
    font-size: 0.9rem;
    color: white;
}

/* ردیف تنظیمات */
.setting-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

/* انتخابگر سختی */
.difficulty-selector {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.difficulty-option {
    background: rgba(255,255,255,0.1);
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    flex: 1;
}

.difficulty-option:hover {
    background: rgba(255,255,255,0.2);
    border-color: #ffd93d;
}

.difficulty-option.selected {
    background: linear-gradient(135deg, #ff6b6b, #ffd93d);
    border-color: #ff6b6b;
    color: white;
    box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
}

.diff-icon {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
}

.diff-text {
    font-weight: 600;
    color: white;
}

/* اسلایدر مدت زمان */
.duration-slider {
    text-align: center;
}

.duration-slider input[type="range"] {
    width: 100%;
    height: 8px;
    border-radius: 4px;
    background: rgba(255,255,255,0.2);
    outline: none;
    margin-bottom: 1rem;
}

.duration-slider input[type="range"]::-webkit-slider-thumb {
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.duration-display {
    color: white;
    font-weight: 700;
    font-size: 1.2rem;
}

.duration-display span {
    color: #ffd93d;
    font-size: 1.5rem;
}

/* ناوبری مراحل */
.step-navigation {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 3rem;
    padding-top: 2rem;
    border-top: 1px solid rgba(255,255,255,0.2);
}

.nav-btn {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 700;
    font-size: 1.1rem;
    transition: all 0.3s ease;
    font-family: inherit;
    position: relative;
    overflow: hidden;
}

.nav-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.nav-btn:hover::before {
    left: 100%;
}

.nav-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
}

.nav-btn:disabled {
    background: rgba(255,255,255,0.1);
    color: rgba(255,255,255,0.5);
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.prev-btn {
    background: linear-gradient(135deg, #6c757d, #495057);
}

.prev-btn:hover {
    box-shadow: 0 10px 25px rgba(108, 117, 125, 0.4);
}

.restart-btn {
    background: linear-gradient(135deg, #28a745, #20c997);
}

.restart-btn:hover {
    box-shadow: 0 10px 25px rgba(40, 167, 69, 0.4);
}

/* کانتینر نتیجه */
.result-container {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.result-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.summary-item {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1rem;
    text-align: center;
}

.summary-label {
    display: block;
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.summary-value {
    display: block;
    color: #ffd93d;
    font-weight: 700;
    font-size: 1.1rem;
}

/* خروجی پرامپت */
.prompt-output {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    overflow: hidden;
}

.output-header {
    background: rgba(0,0,0,0.2);
    padding: 1rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.output-header h5 {
    color: white;
    margin: 0;
    font-weight: 700;
}

.copy-btn {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.copy-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
}

#finalPromptText {
    width: 100%;
    min-height: 200px;
    background: transparent;
    border: none;
    color: white;
    padding: 1.5rem;
    font-family: 'Courier New', monospace;
    font-size: 0.9rem;
    line-height: 1.5;
    resize: vertical;
    direction: ltr;
    text-align: left;
}

#finalPromptText:focus {
    outline: none;
}

/* راهنمای استفاده */
.usage-guide h5 {
    color: white;
    margin-bottom: 1rem;
    font-weight: 700;
}

.guide-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.guide-step {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 10px;
    padding: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.guide-number {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    color: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    font-size: 0.9rem;
    flex-shrink: 0;
}

.guide-text {
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
}

/* ریسپانسیو */
@media (max-width: 768px) {
    .wizard-steps {
        gap: 1rem;
        flex-direction: column;
        align-items: center;
    }
    
    .wizard-steps::before {
        display: none;
    }
    
    .subject-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    
    .game-type-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .setting-row {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .difficulty-selector {
        flex-direction: column;
    }
    
    .grade-pills {
        gap: 0.5rem;
    }
    
    .grade-pill {
        padding: 0.6rem 1rem;
        font-size: 0.9rem;
    }
    
    .step-navigation {
        flex-direction: column;
        gap: 1rem;
    }
    
    .nav-btn {
        width: 100%;
        padding: 0.8rem 1.5rem;
    }
    
    .result-summary {
        grid-template-columns: 1fr 1fr;
    }
    
    .guide-steps {
        grid-template-columns: 1fr;
    }
}


/* =================== استایل‌های مدیریت دسته‌بندی‌ها =================== */

/* هدر دسته‌بندی‌ها */
.categories-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.header-content h3 {
    color: white;
    font-size: 2rem;
    font-weight: 800;
    margin: 0 0 0.5rem 0;
    text-shadow: 0 2px 10px rgba(0,0,0,0.3);
}

.header-content p {
    color: rgba(255,255,255,0.8);
    margin: 0;
    font-size: 1.1rem;
}

.add-category-btn {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 700;
    font-size: 1.1rem;
    transition: all 0.3s ease;
    font-family: inherit;
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
}

.add-category-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(40, 167, 69, 0.6);
}

/* آمار دسته‌بندی‌ها */
.categories-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.cat-stat-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 20px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.cat-stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
}

.cat-stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--accent-color, #28a745);
    border-radius: 20px 20px 0 0;
}

.cat-stat-card.total { --accent-color: #4d9de0; }
.cat-stat-card.active { --accent-color: #28a745; }
.cat-stat-card.inactive { --accent-color: #dc3545; }
.cat-stat-card.games { --accent-color: #ffc107; }

.cat-stat-card .stat-icon {
    font-size: 2.5rem;
    opacity: 0.8;
}

.cat-stat-card .stat-content {
    flex: 1;
}

.cat-stat-card .stat-number {
    font-size: 2rem;
    font-weight: 900;
    color: white;
    line-height: 1;
    margin-bottom: 0.3rem;
}

.cat-stat-card .stat-label {
    font-size: 0.9rem;
    color: rgba(255,255,255,0.8);
    font-weight: 600;
}

/* فیلترهای دسته‌بندی‌ها */
.categories-filters {
    background: rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(255,255,255,0.2);
}

.filter-row {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr auto;
    gap: 1rem;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.filter-group label {
    color: rgba(255,255,255,0.9);
    font-weight: 600;
    font-size: 0.9rem;
}

.filter-group input,
.filter-group select {
    background: rgba(255,255,255,0.2);
    border: 2px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.8rem;
    border-radius: 10px;
    font-family: inherit;
    font-size: 0.9rem;
}

.filter-group input:focus,
.filter-group select:focus {
    outline: none;
    border-color: #ffd93d;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
}

.filter-group input::placeholder {
    color: rgba(255,255,255,0.6);
}

.filter-group select option {
    background: #333;
    color: white;
}

.filter-actions {
    display: flex;
    align-items: end;
}

.btn-clear-filters {
    background: rgba(220, 53, 69, 0.8);
    color: white;
    border: none;
    padding: 0.8rem 1rem;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.btn-clear-filters:hover {
    background: rgba(220, 53, 69, 1);
    transform: translateY(-2px);
}

/* جدول دسته‌بندی‌ها */
.categories-table-section {
    background: rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 1.5rem;
    border: 1px solid rgba(255,255,255,0.2);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.table-header h4 {
    color: white;
    margin: 0;
    font-weight: 700;
}

.table-info {
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
    font-weight: 600;
}

.categories-table-container {
    overflow: auto;
    border-radius: 15px;
    margin-bottom: 1rem;
}

.categories-table {
    width: 100%;
    border-collapse: collapse;
    background: rgba(255,255,255,0.05);
    min-width: 800px;
}

.categories-table th {
    background: rgba(0,0,0,0.3);
    color: white;
    padding: 1rem;
    text-align: right;
    font-weight: 700;
    border-bottom: 2px solid rgba(255,255,255,0.2);
    position: sticky;
    top: 0;
    z-index: 10;
}

.categories-table td {
    padding: 1rem;
    color: white;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    vertical-align: middle;
}

.categories-table tbody tr {
    transition: all 0.3s ease;
}

.categories-table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* نمایش آیکون و رنگ */
.category-icon {
    font-size: 1.5rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: rgba(255,255,255,0.1);
}

.category-color {
    display: inline-block;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 2px solid rgba(255,255,255,0.3);
    position: relative;
}

.category-color::after {
    content: attr(data-color);
    position: absolute;
    bottom: -20px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 0.7rem;
    color: rgba(255,255,255,0.6);
    white-space: nowrap;
}

/* نشان‌های وضعیت دسته‌بندی */
.category-status-active {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    padding: 0.4rem 0.8rem;
    border-radius: 15px;
    font-weight: 600;
    font-size: 0.8rem;
}

.category-status-inactive {
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    padding: 0.4rem 0.8rem;
    border-radius: 15px;
    font-weight: 600;
    font-size: 0.8rem;
}

/* دکمه‌های عملیات دسته‌بندی */
.category-actions {
    display: flex;
    gap: 0.5rem;
}

.category-actions button {
    background: rgba(255,255,255,0.2);
    border: 2px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.4rem;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1rem;
    transition: all 0.3s ease;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.category-actions button:hover {
    background: rgba(255,255,255,0.3);
    transform: translateY(-2px);
}

.edit-category-btn:hover { background: rgba(255, 193, 7, 0.8) !important; }
.toggle-category-btn:hover { background: rgba(23, 162, 184, 0.8) !important; }
.delete-category-btn:hover { background: rgba(220, 53, 69, 0.8) !important; }

/* مودال‌های دسته‌بندی */
.category-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.8);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    padding: 1rem;
}

.category-modal.show {
    display: flex;
    animation: fadeIn 0.3s ease;
}

.category-modal .modal-container {
    background: white;
    border-radius: 20px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow: hidden;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
    animation: slideUp 0.3s ease;
}

.category-modal .modal-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 1.5rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.category-modal .modal-header h3 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
}

.category-modal .modal-close {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.5rem;
    transition: all 0.3s ease;
}

.category-modal .modal-close:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
}

.category-modal .modal-body {
    padding: 2rem;
    color: #333;
}

.category-modal .modal-footer {
    background: #f8f9fa;
    padding: 1.5rem 2rem;
    border-top: 1px solid #eee;
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
}

/* فرم‌های دسته‌بندی */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #333;
}

.required {
    color: #dc3545;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid #ddd;
    border-radius: 10px;
    font-family: inherit;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

/* انتخابگر آیکون */
.icon-selector {
    position: relative;
}

.icon-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 0.5rem;
    margin-top: 0.5rem;
}

.icon-option {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border: 2px solid #ddd;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1.2rem;
    transition: all 0.3s ease;
}

.icon-option:hover {
    border-color: #667eea;
    background: rgba(102, 126, 234, 0.1);
    transform: scale(1.1);
}

.icon-option.selected {
    border-color: #667eea;
    background: #667eea;
    color: white;
}

/* انتخابگر رنگ */
.color-selector {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.color-selector input[type="color"] {
    width: 50px;
    height: 40px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

.color-presets {
    display: flex;
    gap: 0.5rem;
}

.color-preset {
    display: block;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.3s ease;
}

.color-preset:hover {
    transform: scale(1.2);
    border-color: white;
}

/* چک‌باکس سفارشی */
.checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    gap: 0.5rem;
}

.checkbox-label input[type="checkbox"] {
    display: none;
}

.checkmark {
    width: 20px;
    height: 20px;
    border: 2px solid #ddd;
    border-radius: 4px;
    position: relative;
    transition: all 0.3s ease;
}

.checkbox-label input[type="checkbox"]:checked + .checkmark {
    background: #667eea;
    border-color: #667eea;
}

.checkbox-label input[type="checkbox"]:checked + .checkmark::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-weight: bold;
    font-size: 0.8rem;
}

/* دکمه‌های مودال */
.btn {
    padding: 0.8rem 1.5rem;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.btn-primary {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.btn-secondary:hover {
    background: #5a6268;
    transform: translateY(-2px);
}

/* نمایش کارتی برای موبایل */
.categories-cards-mobile {
    display: none;
}

.category-card-mobile {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1rem;
    color: white;
}

.category-card-mobile .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.category-card-mobile .category-name {
    font-size: 1.2rem;
    font-weight: 700;
    color: #ffd93d;
}

.category-card-mobile .card-info {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin-bottom: 1rem;
}

.category-card-mobile .info-item {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
}

.category-card-mobile .info-label {
    font-size: 0.8rem;
    opacity: 0.8;
}

.category-card-mobile .info-value {
    font-weight: 600;
}

.category-card-mobile .card-actions {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
    padding-top: 1rem;
    border-top: 1px solid rgba(255,255,255,0.2);
}

/* ریسپانسیو */
@media (max-width: 768px) {
    .categories-header {
        flex-direction: column;
        text-align: center;
    }
    
    .add-category-btn {
        width: 100%;
        max-width: 300px;
    }
    
    .categories-stats {
        grid-template-columns: 1fr 1fr;
    }
    
    .filter-row {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .categories-table-container {
        display: none;
    }
    
    .categories-cards-mobile {
        display: block;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
    
    .icon-grid {
        grid-template-columns: repeat(4, 1fr);
    }
    
    .category-modal .modal-container {
        margin: 1rem;
        max-height: 95vh;
    }
    
    .category-modal .modal-body {
        padding: 1.5rem;
    }
    
    .category-modal .modal-footer {
        flex-direction: column;
    }
}
/* =================== استایل‌های تحلیل نتایج =================== */

/* هدر تحلیل نتایج */
.results-analysis-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.results-analysis-header .header-content h3 {
    color: white;
    font-size: 2.2rem;
    font-weight: 900;
    margin: 0 0 0.5rem 0;
    text-shadow: 0 3px 15px rgba(0,0,0,0.4);
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.results-analysis-header .header-content p {
    color: rgba(255,255,255,0.9);
    margin: 0;
    font-size: 1.1rem;
    font-weight: 500;
}

.header-actions {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.action-btn {
    background: rgba(255,255,255,0.15);
    border: 2px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.8rem 1.5rem;
    border-radius: 15px;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.action-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.action-btn:hover::before {
    left: 100%;
}

.action-btn:hover {
    background: rgba(255,255,255,0.25);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}

.refresh-btn:hover { border-color: #17a2b8; background: rgba(23, 162, 184, 0.3); }
.export-btn:hover { border-color: #28a745; background: rgba(40, 167, 69, 0.3); }
.print-btn:hover { border-color: #6f42c1; background: rgba(111, 66, 193, 0.3); }

/* داشبورد آماری */
.analytics-dashboard {
    margin-bottom: 2rem;
}

.dashboard-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.analytics-card {
    background: rgba(255,255,255,0.12);
    backdrop-filter: blur(25px);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 25px;
    padding: 2rem;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;
    cursor: pointer;
}

.analytics-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: var(--card-gradient, linear-gradient(135deg, #667eea, #764ba2));
    border-radius: 25px 25px 0 0;
}

.analytics-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
    background: rgba(255,255,255,0.18);
}

.analytics-card .card-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
    filter: drop-shadow(0 4px 12px rgba(0,0,0,0.3));
}

.analytics-card .card-number {
    font-size: 2.5rem;
    font-weight: 900;
    color: white;
    line-height: 1;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.analytics-card .card-label {
    font-size: 1rem;
    color: rgba(255,255,255,0.8);
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.analytics-card .card-trend {
    font-size: 0.9rem;
    padding: 0.3rem 0.8rem;
    border-radius: 15px;
    font-weight: 600;
    background: rgba(255,255,255,0.1);
    display: inline-block;
}

.analytics-card.total-results { --card-gradient: linear-gradient(135deg, #667eea, #764ba2); }
.analytics-card.active-students { --card-gradient: linear-gradient(135deg, #f093fb, #f5576c); }
.analytics-card.avg-performance { --card-gradient: linear-gradient(135deg, #4facfe, #00f2fe); }
.analytics-card.best-score { --card-gradient: linear-gradient(135deg, #43e97b, #38f9d7); }
.analytics-card.avg-accuracy { --card-gradient: linear-gradient(135deg, #fa709a, #fee140); }
.analytics-card.avg-time { --card-gradient: linear-gradient(135deg, #a8edea, #fed6e3); }

/* نمودارهای تحلیلی */
.analytics-charts {
    margin-bottom: 2rem;
}

.charts-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

.chart-container {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 20px;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
}

.chart-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #ffd93d, #667eea, #764ba2);
    border-radius: 20px 20px 0 0;
}

.chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.chart-header h4 {
    color: white;
    margin: 0;
    font-weight: 700;
    font-size: 1.1rem;
}

.chart-controls select,
.chart-controls button {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.chart-controls select:hover,
.chart-controls button:hover {
    background: rgba(255,255,255,0.3);
}

.half-width {
    flex: 1;
}

/* رنکینگ برترین دانش‌آموزان */
.top-students-section {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 20px;
    padding: 2rem;
    margin-bottom: 2rem;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.section-header h4 {
    color: white;
    margin: 0;
    font-weight: 700;
    font-size: 1.3rem;
}

.ranking-controls select {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.6rem 1rem;
    border-radius: 10px;
    font-size: 0.9rem;
}

.top-students-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1rem;
}

.student-rank-card {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1.5rem;
    position: relative;
    transition: all 0.3s ease;
    cursor: pointer;
}

.student-rank-card:hover {
    background: rgba(255,255,255,0.15);
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.student-rank-card .rank-number {
    position: absolute;
    top: -10px;
    right: 15px;
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    color: #333;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    font-size: 0.9rem;
    box-shadow: 0 4px 12px rgba(255, 217, 61, 0.4);
}

.student-rank-card .student-info {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
}

.student-rank-card .student-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.student-rank-card .student-name {
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
}

.student-rank-card .student-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.5rem;
}

.student-rank-card .stat-item {
    color: rgba(255,255,255,0.8);
    font-size: 0.85rem;
}

.student-rank-card .stat-value {
    color: #ffd93d;
    font-weight: 600;
}

/* فیلترهای پیشرفته */
.advanced-filters {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 20px;
    margin-bottom: 2rem;
    overflow: hidden;
}

.filters-header {
    background: rgba(0,0,0,0.2);
    padding: 1rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
}

.filters-header h4 {
    color: white;
    margin: 0;
    font-weight: 700;
}

.filters-toggle {
    background: none;
    border: none;
    color: rgba(255,255,255,0.8);
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 600;
    transition: all 0.3s ease;
}

.filters-toggle:hover {
    color: white;
}

.toggle-icon {
    transition: transform 0.3s ease;
}

.filters-toggle.expanded .toggle-icon {
    transform: rotate(180deg);
}

.filters-content {
    padding: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
}

.filters-content.expanded {
    padding: 1.5rem;
    max-height: 500px;
}

.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.filter-group label {
    color: rgba(255,255,255,0.9);
    font-weight: 600;
    font-size: 0.9rem;
}

.filter-group input,
.filter-group select {
    background: rgba(255,255,255,0.15);
    border: 2px solid rgba(255,255,255,0.2);
    color: white;
    padding: 0.8rem;
    border-radius: 10px;
    font-family: inherit;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.filter-group input:focus,
.filter-group select:focus {
    outline: none;
    border-color: #ffd93d;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
    background: rgba(255,255,255,0.2);
}

.filter-group input::placeholder {
    color: rgba(255,255,255,0.6);
}

.filter-group select option {
    background: #333;
    color: white;
}

.filters-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.btn-primary {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    border: none;
    padding: 0.8rem 1.5rem;
    border-radius: 12px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-secondary {
    background: rgba(108, 117, 125, 0.8);
    color: white;
    border: none;
    padding: 0.8rem 1.5rem;
    border-radius: 12px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-export {
    background: linear-gradient(135deg, #fd7e14, #ff9f43);
    color: white;
    border: none;
    padding: 0.8rem 1.5rem;
    border-radius: 12px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-primary:hover,
.btn-secondary:hover,
.btn-export:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}

/* جدول نتایج */
.results-table-section {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 20px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.table-header h4 {
    color: white;
    margin: 0;
    font-weight: 700;
    font-size: 1.2rem;
}

.table-info {
    display: flex;
    gap: 2rem;
    align-items: center;
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
}

.pagination-info {
    font-weight: 600;
    color: #ffd93d;
}

.table-container {
    overflow: auto;
    border-radius: 15px;
    margin-bottom: 1rem;
    max-height: 600px;
    border: 1px solid rgba(255,255,255,0.1);
}

.results-table {
    width: 100%;
    border-collapse: collapse;
    background: rgba(255,255,255,0.05);
    min-width: 1000px;
}

.results-table th {
    background: rgba(0,0,0,0.4);
    color: white;
    padding: 1rem;
    text-align: right;
    font-weight: 700;
    border-bottom: 2px solid rgba(255,255,255,0.2);
    position: sticky;
    top: 0;
    z-index: 10;
    cursor: pointer;
    transition: all 0.3s ease;
}

.results-table th:hover {
    background: rgba(0,0,0,0.6);
}

.results-table th.sortable::after {
    content: ' ↕️';
    font-size: 0.8rem;
    opacity: 0.5;
}

.results-table th.sorted-asc::after {
    content: ' ↑';
    color: #ffd93d;
    opacity: 1;
}

.results-table th.sorted-desc::after {
    content: ' ↓';
    color: #ffd93d;
    opacity: 1;
}

.results-table td {
    padding: 1rem;
    color: white;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    vertical-align: middle;
}

.results-table tbody tr {
    transition: all 0.3s ease;
}

.results-table tbody tr:hover {
    background: rgba(255,255,255,0.1);
    transform: scale(1.01);
}

/* نشان‌های امتیاز و دقت */
.score-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.4rem 0.8rem;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.9rem;
    gap: 0.3rem;
}

.score-excellent { background: linear-gradient(135deg, #28a745, #20c997); color: white; }
.score-good { background: linear-gradient(135deg, #17a2b8, #138496); color: white; }
.score-average { background: linear-gradient(135deg, #ffc107, #ffb300); color: #333; }
.score-poor { background: linear-gradient(135deg, #dc3545, #c82333); color: white; }

.accuracy-badge {
    padding: 0.3rem 0.6rem;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
}

.accuracy-high { background: #28a745; color: white; }
.accuracy-medium { background: #ffc107; color: #333; }
.accuracy-low { background: #dc3545; color: white; }

.time-badge {
    background: rgba(255,255,255,0.1);
    color: white;
    padding: 0.3rem 0.6rem;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
}

.category-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    padding: 0.3rem 0.8rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 600;
    background: rgba(255,255,255,0.1);
    color: white;
}

/* دکمه‌های عملیات */
.result-actions {
    display: flex;
    gap: 0.5rem;
}

.result-actions button {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.5rem;
    border-radius: 8px;
    cursor: pointer;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.result-actions button:hover {
    background: rgba(255,255,255,0.3);
    transform: translateY(-2px);
}

.view-details-btn:hover { background: rgba(23, 162, 184, 0.8) !important; }
.edit-result-btn:hover { background: rgba(255, 193, 7, 0.8) !important; }
.delete-result-btn:hover { background: rgba(220, 53, 69, 0.8) !important; }

/* صفحه‌بندی */
.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    margin: 1.5rem 0;
}

.page-btn {
    background: rgba(255,255,255,0.2);
    border: 2px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.6rem 1rem;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.page-btn:hover:not(:disabled) {
    background: rgba(255,255,255,0.3);
    transform: translateY(-2px);
}

.page-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.page-numbers {
    display: flex;
    gap: 0.3rem;
}

.page-number {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.5rem 0.8rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    min-width: 40px;
    text-align: center;
    font-weight: 600;
}

.page-number.active {
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    color: #333;
    border-color: #ffd93d;
    box-shadow: 0 4px 12px rgba(255, 217, 61, 0.4);
}

.page-number:hover:not(.active) {
    background: rgba(255,255,255,0.3);
}

/* مودال جزئیات دانش‌آموز */
.analysis-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.85);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    padding: 1rem;
}

.analysis-modal.show {
    display: flex;
    animation: fadeIn 0.4s ease;
}

.analysis-modal .modal-container {
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 25px;
    width: 100%;
    max-width: 1200px;
    max-height: 95vh;
    overflow: hidden;
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.4);
    animation: slideUp 0.4s ease;
}

.analysis-modal .modal-header {
    background: rgba(0,0,0,0.3);
    color: white;
    padding: 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.analysis-modal .modal-header h3 {
    margin: 0;
    font-size: 1.8rem;
    font-weight: 800;
    text-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.analysis-modal .modal-close {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.8rem;
    transition: all 0.3s ease;
}

.analysis-modal .modal-close:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
}

.analysis-modal .modal-body {
    padding: 2rem;
    max-height: 70vh;
    overflow-y: auto;
    background: rgba(255,255,255,0.1);
}

.analysis-modal .modal-footer {
    background: rgba(0,0,0,0.2);
    padding: 1.5rem 2rem;
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
}

/* اطلاعات دانش‌آموز */
.student-info-section {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
    background: rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 2rem;
    border: 1px solid rgba(255,255,255,0.2);
}

.student-avatar {
    position: relative;
}

.student-avatar img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid rgba(255,255,255,0.3);
    object-fit: cover;
}

.student-rank {
    position: absolute;
    top: -10px;
    right: -10px;
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    color: #333;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    font-size: 1.1rem;
    box-shadow: 0 4px 15px rgba(255, 217, 61, 0.5);
}

.student-details h4 {
    color: white;
    font-size: 1.8rem;
    font-weight: 800;
    margin: 0 0 1rem 0;
    text-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.student-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.student-stats .stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.8rem;
    background: rgba(255,255,255,0.1);
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.2);
}

.student-stats .stat-label {
    color: rgba(255,255,255,0.8);
    font-weight: 600;
}

.student-stats .stat-value {
    color: #ffd93d;
    font-weight: 700;
    font-size: 1.1rem;
}

/* نمودار پیشرفت */
.progress-chart-section {
    background: rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 2rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(255,255,255,0.15);
}

.progress-chart-section h5 {
    color: white;
    font-weight: 700;
    margin-bottom: 1rem;
    font-size: 1.2rem;
}

/* عملکرد دسته‌بندی */
.category-performance-section {
    background: rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 2rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(255,255,255,0.15);
}

.category-performance-section h5 {
    color: white;
    font-weight: 700;
    margin-bottom: 1.5rem;
    font-size: 1.2rem;
}

.category-performance-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}

.category-performance-card {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 15px;
    padding: 1.5rem;
    transition: all 0.3s ease;
}

.category-performance-card:hover {
    background: rgba(255,255,255,0.15);
    transform: translateY(-3px);
}

/* لیست بازی‌های اخیر */
.recent-games-section,
.best-performances-section {
    background: rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 2rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(255,255,255,0.15);
}

.recent-games-section h5,
.best-performances-section h5 {
    color: white;
    font-weight: 700;
    margin-bottom: 1.5rem;
    font-size: 1.2rem;
}

.recent-games-list,
.best-performances-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.game-item {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 12px;
    padding: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.3s ease;
}

.game-item:hover {
    background: rgba(255,255,255,0.15);
}

.game-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.game-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: white;
}

.game-details h6 {
    color: white;
    margin: 0 0 0.3rem 0;
    font-weight: 600;
}

.game-details p {
    color: rgba(255,255,255,0.7);
    margin: 0;
    font-size: 0.9rem;
}

.game-stats {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.game-stat {
    text-align: center;
}

.game-stat .stat-number {
    color: #ffd93d;
    font-weight: 700;
    font-size: 1.1rem;
    display: block;
}

.game-stat .stat-label {
    color: rgba(255,255,255,0.7);
    font-size: 0.8rem;
}

/* ریسپانسیو */
@media (max-width: 1200px) {
    .charts-row {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
}

@media (max-width: 768px) {
    .results-analysis-header {
        flex-direction: column;
        text-align: center;
    }
    
    .header-actions {
        width: 100%;
        justify-content: center;
    }
    
    .dashboard-cards {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    
    .analytics-card {
        padding: 1.5rem;
    }
    
    .analytics-card .card-number {
        font-size: 2rem;
    }
    
    .top-students-grid {
        grid-template-columns: 1fr;
    }
    
    .filters-grid {
        grid-template-columns: 1fr;
    }
    
    .filters-actions {
        flex-direction: column;
    }
    
    .table-container {
        max-height: 400px;
    }
    
    .results-table {
        font-size: 0.8rem;
        min-width: 800px;
    }
    
    .results-table th,
    .results-table td {
        padding: 0.8rem 0.5rem;
    }
    
    .student-info-section {
        flex-direction: column;
        text-align: center;
    }
    
    .student-stats {
        grid-template-columns: 1fr;
    }
    
    .category-performance-grid {
        grid-template-columns: 1fr;
    }
    
    .analysis-modal .modal-container {
        margin: 0.5rem;
        max-height: 98vh;
    }
    
    .analysis-modal .modal-header {
        padding: 1.5rem;
    }
    
    .analysis-modal .modal-body {
        padding: 1.5rem;
    }
}

@media (max-width: 480px) {
    .dashboard-cards {
        grid-template-columns: 1fr;
    }
    
    .analytics-card .card-number {
        font-size: 1.8rem;
    }
    
    .results-table th,
    .results-table td {
        padding: 0.6rem 0.3rem;
        font-size: 0.75rem;
    }
    
    .page-btn,
    .page-number {
        padding: 0.5rem;
        font-size: 0.8rem;
    }
}
/* اصلاح استایل‌های select در مدال‌ها */
.badge-modal-body .form-group select {
    padding: 0.8rem;
    border: 2px solid #333 !important;  /* حاشیه مشکی */
    border-radius: 8px;
    font-family: inherit;
    color: #000 !important;  /* متن مشکی */
    background: #fff !important;  /* پس‌زمینه سفید */
}

/* استایل option ها */
.badge-modal-body .form-group select option {
    background: #fff;
    color: #000;
    padding: 0.5rem;
}

/* هنگام فوکوس */
.badge-modal-body .form-group select:focus {
    border-color: #667eea !important;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

/* متن راهنما (placeholder) برای select */
.badge-modal-body .form-group select option[value=""] {
    color: #666 !important;  /* رنگ خاکستری برای placeholder */
}

/* input ها هم */
.badge-modal-body .form-group input {
    padding: 0.8rem;
    border: 2px solid #333 !important;
    border-radius: 8px;
    font-family: inherit;
    color: #000 !important;
    background: #fff !important;
}

.badge-modal-body .form-group input:focus {
    border-color: #667eea !important;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

/* textarea ها */
.badge-modal-body .form-group textarea {
    padding: 0.8rem;
    border: 2px solid #333 !important;
    border-radius: 8px;
    font-family: inherit;
    color: #000 !important;
    background: #fff !important;
    resize: vertical;
}

.badge-modal-body .form-group textarea:focus {
    border-color: #667eea !important;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

/* placeholder برای input و textarea */
.badge-modal-body .form-group input::placeholder,
.badge-modal-body .form-group textarea::placeholder {
    color: #999 !important;
    opacity: 1;
}

/* label ها */
.badge-modal-body .form-group label {
    color: #000 !important;
    font-weight: 600;
    margin-bottom: 0.5rem;
    display: block;
}

/* متن کمکی (small) */
.badge-modal-body .form-group small {
    color: #666 !important;
    font-size: 0.85rem;
    display: block;
    margin-top: 0.25rem;
}
/* استایل دکمه حذف همه در مدال */
.btn-delete {
    background: #dc3545;
    color: white;
    border: none;
    padding: 0.3rem 0.6rem;
    border-radius: 5px;
    cursor: pointer;
    font-size: 0.8rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.btn-delete:hover {
    background: #c82333;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(220, 53, 69, 0.3);
}

.btn-delete:active {
    transform: translateY(0);
}
    </style>
</head>
<body>
    <div class="container">
        <!-- دکمه برگشت -->
        <a href="<?php echo SITE_URL; ?>" class="back-btn">← بازگشت به صفحه اصلی</a>
        
        
        <div id="admin-games-section" class="admin-section">
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: -2rem; padding: 2rem; border-radius: 15px;">
                
                <!-- آمار کلی با رنگ‌های جذاب -->
                <div class="games-stats-grid">
                    <div class="stat-card games-stat">
                        <div class="stat-icon">🎮</div>
                        <div class="stat-number"><?php echo number_format($total_games); ?></div>
                        <div class="stat-label">کل بازی‌ها</div>
                    </div>
                    <div class="stat-card players-stat">
                        <div class="stat-icon">👥</div>
                        <div class="stat-number"><?php echo number_format($active_players); ?></div>
                        <div class="stat-label">بازیکنان فعال (ماهانه)</div>
                    </div>
                    <div class="stat-card plays-stat">
                        <div class="stat-icon">🎯</div>
                        <div class="stat-number"><?php echo number_format($weekly_plays); ?></div>
                        <div class="stat-label">بازی‌های هفته</div>
                    </div>
                    <div class="stat-card score-stat">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-number"><?php echo number_format($avg_score, 1); ?></div>
                        <div class="stat-label">میانگین امتیاز</div>
                    </div>
                </div>

                <!-- پنج تب مدیریت -->
                <div class="admin-games-tabs">
                    <button class="games-tab-btn active" onclick="showGameTab('games-list')">
                        🎮 مدیریت بازی‌ها
                    </button>
                    <button class="games-tab-btn" onclick="showGameTab('prompt-generator')">
                        🤖 پرامپت‌ساز
                    </button>
                    <button class="games-tab-btn" onclick="showGameTab('categories')">
                        📁 دسته‌بندی‌ها
                    </button>
                    <button class="games-tab-btn" onclick="showGameTab('results-management')">
                        📊 مدیریت نتایج
                    </button>
                    <button class="games-tab-btn" onclick="showGameTab('badges-management')">
                        🏆 مدیریت نشان‌ها
                    </button>
                </div>

                <!-- ۱: مدیریت بازی‌ها -->
                <div id="games-list" class="games-tab-content active">
                    <div class="games-management glass-effect">
                        <div class="management-header">
                            <h3>🎮 مدیریت بازی‌ها</h3>
                            <button class="add-game-btn" onclick="showAddGameModal()">
                                + افزودن بازی جدید
                            </button>
                        </div>

                        <!-- فیلتر بازی‌ها -->
                        <div class="games-filter">
                            <select id="filterGameSubject" onchange="filterGamesList()">
    <option value="">همه دروس</option>
    <!-- گزینه‌ها با JavaScript پر می‌شوند -->
</select>
                            <select id="filterGameStatus" onchange="filterGamesList()">
                                <option value="">همه وضعیت‌ها</option>
                                <option value="1">فعال</option>
                                <option value="0">غیرفعال</option>
                            </select>
                            
                            <button type="button" onclick="resetFilters()" style="background: rgba(255,255,255,0.2); border: 2px solid rgba(255,255,255,0.3); color: white; padding: 0.75rem 1rem; border-radius: 15px; cursor: pointer;">
                                🔄 حذف فیلترها
                            </button>
                        </div>

                        <!-- نمایش تعداد نتایج -->
                        <div id="resultsInfo" style="color: rgba(255,255,255,0.8); margin-bottom: 1rem; text-align: center;"></div>

                        <!-- لیست بازی‌ها -->
                        <div class="games-table-container">
                            <table class="games-table" id="gamesTable">
                                <thead>
                                    <tr>
                                        <th>عنوان بازی</th>
                                        <th>درس</th>
                                        <th>تعداد بازی</th>
                                        <th>میانگین امتیاز</th>
                                        <th>وضعیت</th>
                                        <th style="text-align: center;">عملیات</th>
                                    </tr>
                                </thead>
                                <tbody id="gamesTableBody">
                                    <!-- محتوا با ../ajax/ بارگذاری می‌شود -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

               <!-- ۲: پرامپت‌ساز -->
<div id="prompt-generator" class="games-tab-content">
    <div class="glass-effect">
        <!-- Header جذاب -->
        <div class="prompt-wizard-header">
            <div class="wizard-icon">🧙‍♂️</div>
            <h3>پرامپت‌ساز جادویی بازی‌های آموزشی</h3>
            <p>با هوش مصنوعی، بازی‌های فوق‌العاده برای دانش‌آموزان بسازید</p>
            <div class="wizard-sparkles">✨ ⭐ 🌟 ✨</div>
        </div>

        <!-- مرحله‌بندی بصری -->
        <div class="wizard-steps">
            <div class="step-item active" data-step="1">
                <div class="step-number">1</div>
                <div class="step-title">انتخاب درس</div>
            </div>
            <div class="step-item" data-step="2">
                <div class="step-number">2</div>
                <div class="step-title">تنظیمات بازی</div>
            </div>
            <div class="step-item" data-step="3">
                <div class="step-number">3</div>
                <div class="step-title">پرامپت نهایی</div>
            </div>
        </div>

        <!-- فرم چند مرحله‌ای -->
        <div class="wizard-container">
            <form id="promptWizardForm">
                
                <!-- مرحله 1: انتخاب درس -->
                <div class="wizard-step active" data-step="1">
                    <div class="step-header">
                        <h4>📚 انتخاب درس و مقطع</h4>
                        <p>ابتدا درس و مقطع تحصیلی را انتخاب کنید</p>
                    </div>
                    
                    <div class="subject-grid">
    <!-- کارت‌های انتخاب درس با JavaScript پر می‌شوند -->
</div>

                    <div class="grade-selector">
                        <label>مقطع تحصیلی:</label>
                        <div class="grade-pills">
                            <div class="grade-pill" data-grade="پیش‌دبستانی">پیش‌دبستانی</div>
                            <div class="grade-pill" data-grade="پایه اول">پایه اول</div>
                            <div class="grade-pill" data-grade="پایه دوم">پایه دوم</div>
                            <div class="grade-pill" data-grade="پایه سوم">پایه سوم</div>
                            <div class="grade-pill" data-grade="پایه چهارم">پایه چهارم</div>
                            <div class="grade-pill" data-grade="پایه پنجم">پایه پنجم</div>
                            <div class="grade-pill" data-grade="پایه ششم">پایه ششم</div>
                        </div>
                    </div>

                    <div class="step-navigation">
                        <button type="button" class="nav-btn next-btn" onclick="nextStep()" disabled>بعدی →</button>
                    </div>
                </div>

                <!-- مرحله 2: تنظیمات بازی -->
                <div class="wizard-step" data-step="2">
                    <div class="step-header">
                        <h4>⚙️ تنظیمات پیشرفته بازی</h4>
                        <p>جزئیات بازی خود را تنظیم کنید</p>
                    </div>

                    <div class="settings-grid">
                        <div class="setting-group">
                            <label>موضوع درس:</label>
                            <input type="text" id="promptTopic" name="topic" 
                                   placeholder="مثال: کسر و مقایسه، جمع و تفریق، املا و نگارش" required>
                        </div>

                        <div class="setting-group">
                            <label>نوع بازی:</label>
                            <div class="game-type-grid">
                                <div class="game-type-card" data-type="سؤال و جواب">
                                    <div class="type-icon">❓</div>
                                    <div class="type-name">سؤال و جواب</div>
                                </div>
                                <div class="game-type-card" data-type="تطبیق و جورچین">
                                    <div class="type-icon">🧩</div>
                                    <div class="type-name">تطبیق و جورچین</div>
                                </div>
                                <div class="game-type-card" data-type="انتخاب چندگانه">
                                    <div class="type-icon">☑️</div>
                                    <div class="type-name">انتخاب چندگانه</div>
                                </div>
                                <div class="game-type-card" data-type="درست یا نادرست">
                                    <div class="type-icon">✅</div>
                                    <div class="type-name">درست/نادرست</div>
                                </div>
                                <div class="game-type-card" data-type="پازل و بازی">
                                    <div class="type-icon">🎮</div>
                                    <div class="type-name">پازل و بازی</div>
                                </div>
                                <div class="game-type-card" data-type="جایگذاری و رنگ">
                                    <div class="type-icon">🎨</div>
                                    <div class="type-name">جایگذاری و رنگ</div>
                                </div>
                            </div>
                        </div>

                        <div class="setting-row">
                            <div class="setting-group">
                                <label>سطح سختی:</label>
                                <div class="difficulty-selector">
                                    <div class="difficulty-option" data-difficulty="آسان">
                                        <div class="diff-icon">😊</div>
                                        <div class="diff-text">آسان</div>
                                    </div>
                                    <div class="difficulty-option" data-difficulty="متوسط">
                                        <div class="diff-icon">🤔</div>
                                        <div class="diff-text">متوسط</div>
                                    </div>
                                    <div class="difficulty-option" data-difficulty="سخت">
                                        <div class="diff-icon">🧠</div>
                                        <div class="diff-text">سخت</div>
                                    </div>
                                </div>
                            </div>

                            <div class="setting-group">
                                <label>مدت بازی:</label>
                                <div class="duration-slider">
                                    <input type="range" id="durationSlider" min="30" max="300" value="120" step="30">
                                    <div class="duration-display">
                                        <span id="durationValue">2</span> دقیقه
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="setting-group">
                            <label>توضیحات اضافی (اختیاری):</label>
                            <textarea id="promptNotes" rows="3" 
                                      placeholder="هر نکته یا خواسته خاصی که دارید، مثل: استفاده از صداهای مختلف، انیمیشن خاص، یا چالش‌های اضافی..."></textarea>
                        </div>
                    </div>

                    <div class="step-navigation">
                        <button type="button" class="nav-btn prev-btn" onclick="prevStep()">← قبلی</button>
                        <button type="button" class="nav-btn next-btn" onclick="nextStep()" disabled>تولید پرامپت →</button>
                    </div>
                </div>

                <!-- مرحله 3: نتیجه -->
                <div class="wizard-step" data-step="3">
                    <div class="step-header">
                        <h4>🎉 پرامپت آماده است!</h4>
                        <p>پرامپت شما با موفقیت تولید شد</p>
                    </div>

                    <div class="result-container">
                        <div class="result-summary">
                            <div class="summary-item">
                                <span class="summary-label">درس:</span>
                                <span class="summary-value" id="summarySubject">-</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">مقطع:</span>
                                <span class="summary-value" id="summaryGrade">-</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">نوع بازی:</span>
                                <span class="summary-value" id="summaryGameType">-</span>
                            </div>
                            <div class="summary-item">
                                <span class="summary-label">سختی:</span>
                                <span class="summary-value" id="summaryDifficulty">-</span>
                            </div>
                        </div>

                        <div class="prompt-output">
                            <div class="output-header">
                                <h5>📋 پرامپت نهایی</h5>
                                <button type="button" class="copy-btn" onclick="copyAdvancedPrompt()">
                                    <span class="copy-icon">📋</span>
                                    <span class="copy-text">کپی</span>
                                </button>
                            </div>
                            <textarea id="finalPromptText" readonly></textarea>
                        </div>

                        <div class="usage-guide">
                            <h5>🚀 مراحل استفاده</h5>
                            <div class="guide-steps">
                                <div class="guide-step">
                                    <div class="guide-number">1</div>
                                    <div class="guide-text">پرامپت را کپی کنید</div>
                                </div>
                                <div class="guide-step">
                                    <div class="guide-number">2</div>
                                    <div class="guide-text">وارد ChatGPT یا Claude شوید</div>
                                </div>
                                <div class="guide-step">
                                    <div class="guide-number">3</div>
                                    <div class="guide-text">پرامپت را پیست کرده و ارسال کنید</div>
                                </div>
                                <div class="guide-step">
                                    <div class="guide-number">4</div>
                                    <div class="guide-text">کد HTML تولیدی را در بخش "ایجاد بازی" قرار دهید</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="step-navigation">
                        <button type="button" class="nav-btn prev-btn" onclick="prevStep()">← ویرایش</button>
                        <button type="button" class="nav-btn restart-btn" onclick="restartWizard()">🔄 شروع مجدد</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

               <!-- ۳: مدیریت دسته‌بندی‌ها -->
<div id="categories" class="games-tab-content">
    <div class="glass-effect">
        <!-- هدر بخش دسته‌بندی‌ها -->
        <div class="categories-header">
            <div class="header-content">
                <h3>📁 مدیریت دسته‌بندی‌ها</h3>
                <p>افزودن، ویرایش و مدیریت دسته‌بندی‌های بازی‌ها</p>
            </div>
            <button class="add-category-btn" onclick="showAddCategoryModal()">
                ➕ افزودن دسته‌بندی جدید
            </button>
        </div>

        <!-- آمار کلی دسته‌بندی‌ها -->
        <div class="categories-stats">
            <div class="cat-stat-card total">
                <div class="stat-icon">📚</div>
                <div class="stat-content">
                    <div class="stat-number" id="totalCategories">0</div>
                    <div class="stat-label">کل دسته‌بندی‌ها</div>
                </div>
            </div>
            <div class="cat-stat-card active">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <div class="stat-number" id="activeCategories">0</div>
                    <div class="stat-label">فعال</div>
                </div>
            </div>
            <div class="cat-stat-card inactive">
                <div class="stat-icon">❌</div>
                <div class="stat-content">
                    <div class="stat-number" id="inactiveCategories">0</div>
                    <div class="stat-label">غیرفعال</div>
                </div>
            </div>
            <div class="cat-stat-card games">
                <div class="stat-icon">🎮</div>
                <div class="stat-content">
                    <div class="stat-number" id="totalGamesInCategories">0</div>
                    <div class="stat-label">کل بازی‌ها</div>
                </div>
            </div>
        </div>

        <!-- فیلتر و جستجوی دسته‌بندی‌ها -->
        <div class="categories-filters">
            <div class="filter-row">
                <div class="filter-group">
                    <label>جستجو:</label>
                    <input type="text" id="categorySearch" placeholder="جستجو در نام دسته‌بندی..." onkeyup="filterCategories()">
                </div>
                <div class="filter-group">
                    <label>وضعیت:</label>
                    <select id="categoryStatusFilter" onchange="filterCategories()">
                        <option value="">همه</option>
                        <option value="1">فعال</option>
                        <option value="0">غیرفعال</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>مرتب‌سازی:</label>
                    <select id="categorySortFilter" onchange="sortCategories()">
                        <option value="name_asc">نام (الفبا)</option>
                        <option value="name_desc">نام (معکوس)</option>
                        <option value="created_desc">جدیدترین</option>
                        <option value="created_asc">قدیمی‌ترین</option>
                        <option value="games_desc">بیشترین بازی</option>
                    </select>
                </div>
                <div class="filter-actions">
                    <button class="btn-clear-filters" onclick="clearCategoryFilters()">
                        🗑️ پاک کردن فیلترها
                    </button>
                </div>
            </div>
        </div>

        <!-- جدول دسته‌بندی‌ها -->
        <div class="categories-table-section">
            <div class="table-header">
                <h4>📋 جدول دسته‌بندی‌ها</h4>
                <div class="table-info">
                    <span id="categoriesCount">0 دسته‌بندی</span>
                </div>
            </div>
            
            <div class="categories-table-container">
                <table class="categories-table" id="categoriesTable">
                    <thead>
                        <tr>
                            <th>شناسه</th>
                            <th>نام دسته‌بندی</th>
                            <th>آیکون</th>
                            <th>رنگ</th>
                            <th>تعداد بازی</th>
                            <th>وضعیت</th>
                            <th>تاریخ ایجاد</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody id="categoriesTableBody">
                        <!-- داده‌ها با JavaScript پر می‌شود -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- نمایش کارتی برای موبایل -->
        <div class="categories-cards-mobile" id="categoriesCards" style="display: none;">
            <!-- کارت‌ها با JavaScript پر می‌شود -->
        </div>
    </div>
</div>

<!-- مودال افزودن دسته‌بندی -->
<div id="addCategoryModal" class="category-modal">
    <div class="modal-backdrop" onclick="closeAddCategoryModal()"></div>
    <div class="modal-container">
        <div class="modal-header">
            <h3>➕ افزودن دسته‌بندی جدید</h3>
            <button class="modal-close" onclick="closeAddCategoryModal()">×</button>
        </div>
        <div class="modal-body">
            <form id="addCategoryForm">
                <div class="form-group">
                    <label>نام دسته‌بندی <span class="required">*</span></label>
                    <input type="text" name="name" required placeholder="مثال: ریاضی، علوم، فارسی">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>آیکون</label>
                        <div class="icon-selector">
                            <input type="text" name="icon" id="categoryIcon" placeholder="انتخاب کنید یا تایپ کنید">
                            <div class="icon-grid">
                                <span class="icon-option" onclick="selectIcon('🔢')">🔢</span>
                                <span class="icon-option" onclick="selectIcon('📖')">📖</span>
                                <span class="icon-option" onclick="selectIcon('🔬')">🔬</span>
                                <span class="icon-option" onclick="selectIcon('🌍')">🌍</span>
                                <span class="icon-option" onclick="selectIcon('☪️')">☪️</span>
                                <span class="icon-option" onclick="selectIcon('🇬🇧')">🇬🇧</span>
                                <span class="icon-option" onclick="selectIcon('🎨')">🎨</span>
                                <span class="icon-option" onclick="selectIcon('🎵')">🎵</span>
                                <span class="icon-option" onclick="selectIcon('⚽')">⚽</span>
                                <span class="icon-option" onclick="selectIcon('💻')">💻</span>
                                <span class="icon-option" onclick="selectIcon('🏛️')">🏛️</span>
                                <span class="icon-option" onclick="selectIcon('🧮')">🧮</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>رنگ</label>
                        <div class="color-selector">
                            <input type="color" name="color" value="#4d9de0">
                            <div class="color-presets">
                                <span class="color-preset" style="background: #4d9de0" onclick="selectColor('#4d9de0')"></span>
                                <span class="color-preset" style="background: #28a745" onclick="selectColor('#28a745')"></span>
                                <span class="color-preset" style="background: #dc3545" onclick="selectColor('#dc3545')"></span>
                                <span class="color-preset" style="background: #ffc107" onclick="selectColor('#ffc107')"></span>
                                <span class="color-preset" style="background: #6f42c1" onclick="selectColor('#6f42c1')"></span>
                                <span class="color-preset" style="background: #fd7e14" onclick="selectColor('#fd7e14')"></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_active" checked>
                        <span class="checkmark"></span>
                        فعال
                    </label>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeAddCategoryModal()">لغو</button>
            <button type="submit" form="addCategoryForm" class="btn btn-primary">💾 ذخیره</button>
        </div>
    </div>
</div>

<!-- مودال ویرایش دسته‌بندی -->
<div id="editCategoryModal" class="category-modal">
    <div class="modal-backdrop" onclick="closeEditCategoryModal()"></div>
    <div class="modal-container">
        <div class="modal-header">
            <h3>✏️ ویرایش دسته‌بندی</h3>
            <button class="modal-close" onclick="closeEditCategoryModal()">×</button>
        </div>
        <div class="modal-body">
            <form id="editCategoryForm">
                <input type="hidden" name="id" id="editCategoryId">
                
                <div class="form-group">
                    <label>نام دسته‌بندی <span class="required">*</span></label>
                    <input type="text" name="name" id="editCategoryName" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>آیکون</label>
                        <div class="icon-selector">
                            <input type="text" name="icon" id="editCategoryIcon" placeholder="انتخاب کنید یا تایپ کنید">
                            <div class="icon-grid">
                                <span class="icon-option" onclick="selectEditIcon('🔢')">🔢</span>
                                <span class="icon-option" onclick="selectEditIcon('📖')">📖</span>
                                <span class="icon-option" onclick="selectEditIcon('🔬')">🔬</span>
                                <span class="icon-option" onclick="selectEditIcon('🌍')">🌍</span>
                                <span class="icon-option" onclick="selectEditIcon('☪️')">☪️</span>
                                <span class="icon-option" onclick="selectEditIcon('🇬🇧')">🇬🇧</span>
                                <span class="icon-option" onclick="selectEditIcon('🎨')">🎨</span>
                                <span class="icon-option" onclick="selectEditIcon('🎵')">🎵</span>
                                <span class="icon-option" onclick="selectEditIcon('⚽')">⚽</span>
                                <span class="icon-option" onclick="selectEditIcon('💻')">💻</span>
                                <span class="icon-option" onclick="selectEditIcon('🏛️')">🏛️</span>
                                <span class="icon-option" onclick="selectEditIcon('🧮')">🧮</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>رنگ</label>
                        <div class="color-selector">
                            <input type="color" name="color" id="editCategoryColor">
                            <div class="color-presets">
                                <span class="color-preset" style="background: #4d9de0" onclick="selectEditColor('#4d9de0')"></span>
                                <span class="color-preset" style="background: #28a745" onclick="selectEditColor('#28a745')"></span>
                                <span class="color-preset" style="background: #dc3545" onclick="selectEditColor('#dc3545')"></span>
                                <span class="color-preset" style="background: #ffc107" onclick="selectEditColor('#ffc107')"></span>
                                <span class="color-preset" style="background: #6f42c1" onclick="selectEditColor('#6f42c1')"></span>
                                <span class="color-preset" style="background: #fd7e14" onclick="selectEditColor('#fd7e14')"></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_active" id="editCategoryActive">
                        <span class="checkmark"></span>
                        فعال
                    </label>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeEditCategoryModal()">لغو</button>
            <button type="submit" form="editCategoryForm" class="btn btn-primary">💾 بروزرسانی</button>
        </div>
    </div>
</div>

               <!-- ۴: مدیریت و تحلیل نتایج -->
<div id="results-management" class="games-tab-content">
    <div class="glass-effect">
        <!-- هدر تحلیل نتایج -->
        <div class="results-analysis-header">
            <div class="header-content">
                <h3>📊 تحلیل و مدیریت نتایج</h3>
                <p>تحلیل جامع عملکرد دانش‌آموزان و ارزیابی پیشرفت</p>
            </div>
            <div class="header-actions">
                <button class="action-btn refresh-btn" onclick="refreshResultsAnalysis()">
                    🔄 بروزرسانی
                </button>
                <button class="action-btn export-btn" onclick="exportAllResults()">
                    📊 خروجی Excel
                </button>
                <button class="action-btn print-btn" onclick="printAnalysisReport()">
                    🖨️ چاپ گزارش
                </button>
            </div>
        </div>

        <!-- آمار کلی (Dashboard Cards) -->
        <div class="analytics-dashboard">
            <div class="dashboard-cards">
                <div class="analytics-card total-results">
                    <div class="card-icon">📈</div>
                    <div class="card-content">
                        <div class="card-number" id="totalResults">0</div>
                        <div class="card-label">کل نتایج</div>
                        <div class="card-trend" id="resultsTrend">--</div>
                    </div>
                </div>
                
                <div class="analytics-card active-students">
                    <div class="card-icon">👥</div>
                    <div class="card-content">
                        <div class="card-number" id="activeStudents">0</div>
                        <div class="card-label">دانش‌آموزان فعال</div>
                        <div class="card-trend" id="studentsTrend">--</div>
                    </div>
                </div>
                
                <div class="analytics-card avg-performance">
                    <div class="card-icon">⭐</div>
                    <div class="card-content">
                        <div class="card-number" id="avgPerformance">0</div>
                        <div class="card-label">میانگین عملکرد</div>
                        <div class="card-trend" id="performanceTrend">--</div>
                    </div>
                </div>
                
                <div class="analytics-card best-score">
                    <div class="card-icon">🏆</div>
                    <div class="card-content">
                        <div class="card-number" id="bestScore">0</div>
                        <div class="card-label">بهترین امتیاز</div>
                        <div class="card-trend" id="scoreTrend">--</div>
                    </div>
                </div>
                
                <div class="analytics-card avg-accuracy">
                    <div class="card-icon">🎯</div>
                    <div class="card-content">
                        <div class="card-number" id="avgAccuracy">0%</div>
                        <div class="card-label">میانگین دقت</div>
                        <div class="card-trend" id="accuracyTrend">--</div>
                    </div>
                </div>
                
                <div class="analytics-card avg-time">
                    <div class="card-icon">⏱️</div>
                    <div class="card-content">
                        <div class="card-number" id="avgTime">0</div>
                        <div class="card-label">میانگین زمان</div>
                        <div class="card-trend" id="timeTrend">--</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- نمودارهای تحلیلی -->
        <div class="analytics-charts">
            <div class="charts-row">
                <div class="chart-container half-width">
                    <div class="chart-header">
                        <h4>📈 روند عملکرد (30 روز اخیر)</h4>
                        <div class="chart-controls">
                            <!-- در بخش نمودارها -->
<select id="chartPeriod" onchange="ResultsAnalysis.updateChart()">
    <option value="7">7 روز اخیر</option>
    <option value="30" selected>30 روز اخیر</option>
    <option value="90">3 ماه اخیر</option>
</select>
                        </div>
                    </div>
                    <canvas id="performanceChart" width="400" height="200"></canvas>
                </div>
                
                <div class="chart-container half-width">
                    <div class="chart-header">
                        <h4>🎯 عملکرد بر اساس دسته‌بندی</h4>
                        <div class="chart-controls">
                            <button class="chart-toggle" onclick="toggleChartType('categoryChart')">
                                📊 تغییر نمودار
                            </button>
                        </div>
                    </div>
                    <canvas id="categoryChart" width="400" height="200"></canvas>
                </div>
            </div>
        </div>

        <!-- رنکینگ برترین دانش‌آموزان -->
        <div class="top-students-section">
            <div class="section-header">
                <h4>🏆 رنکینگ برترین دانش‌آموزان</h4>
                <div class="ranking-controls">
                   <!-- در بخش رنکینگ -->
<select id="rankingCriteria" onchange="ResultsAnalysis.updateRanking()">
    <option value="avg_score" selected>میانگین امتیاز</option>
    <option value="total_score">کل امتیاز</option>
    <option value="accuracy">دقت</option>
    <option value="total_plays">تعداد بازی</option>
</select>
                </div>
            </div>
            <div class="top-students-grid" id="topStudentsGrid">
                <!-- با JavaScript پر می‌شود -->
            </div>
        </div>

        <!-- فیلترهای پیشرفته -->
        <div class="advanced-filters">
            <div class="filters-header">
                <h4>🔍 فیلترهای پیشرفته</h4>
                <button class="filters-toggle" onclick="toggleFilters()">
                    <span class="toggle-icon">▼</span>
                    <span class="toggle-text">نمایش فیلترها</span>
                </button>
            </div>
            
            <div class="filters-content" id="filtersContent">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label>دانش‌آموز:</label>
                        <select id="filterStudent">
                            <option value="">همه دانش‌آموزان</option>
                            <!-- با JavaScript پر می‌شود -->
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>بازی:</label>
                        <select id="filterGame">
                            <option value="">همه بازی‌ها</option>
                            <!-- با JavaScript پر می‌شود -->
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>دسته‌بندی:</label>
                        <select id="filterCategory">
                            <option value="">همه دسته‌بندی‌ها</option>
                            <!-- با JavaScript پر می‌شود -->
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>از تاریخ:</label>
                        <input type="date" id="filterDateFrom">
                    </div>
                    
                    <div class="filter-group">
                        <label>تا تاریخ:</label>
                        <input type="date" id="filterDateTo">
                    </div>
                    
                    <div class="filter-group">
                        <label>حداقل امتیاز:</label>
                        <input type="number" id="filterMinScore" min="0" max="100" placeholder="0">
                    </div>
                    
                    <div class="filter-group">
                        <label>حداکثر امتیاز:</label>
                        <input type="number" id="filterMaxScore" min="0" max="100" placeholder="100">
                    </div>
                    
                    <div class="filter-group">
                        <label>مرتب‌سازی:</label>
                        <select id="filterSort">
                            <option value="date_desc">جدیدترین</option>
                            <option value="date_asc">قدیمی‌ترین</option>
                            <option value="score_desc">بالاترین امتیاز</option>
                            <option value="score_asc">پایین‌ترین امتیاز</option>
                            <option value="accuracy_desc">بالاترین دقت</option>
                            <option value="time_asc">کمترین زمان</option>
                        </select>
                    </div>
                </div>
                
                <div class="filters-actions">
                    <button class="btn-primary" onclick="applyFilters()">🔍 اعمال فیلترها</button>
                    <button class="btn-secondary" onclick="clearFilters()">🗑️ پاک کردن</button>
                    <button class="btn-export" onclick="exportFilteredResults()">📥 خروجی فیلتر شده</button>
                </div>
            </div>
        </div>

        <!-- جدول نتایج -->
        <div class="results-table-section">
            <div class="table-header">
                <h4>📋 جدول تفصیلی نتایج</h4>
                <div class="table-info">
                    <span id="resultsInfo">0 نتیجه</span>
                    <div class="pagination-info">
                        صفحه <span id="currentPage">1</span> از <span id="totalPages">1</span>
                    </div>
                </div>
            </div>
            
            <div class="table-container">
                <table class="results-table" id="resultsTable">
                    <thead>
                        <tr>
                            <th class="sortable" data-sort="student_name">دانش‌آموز</th>
                            <th class="sortable" data-sort="game_title">بازی</th>
                            <th class="sortable" data-sort="category_name">دسته‌بندی</th>
                            <th class="sortable" data-sort="score">امتیاز</th>
                            <th class="sortable" data-sort="accuracy">دقت</th>
                            <th class="sortable" data-sort="time_spent">زمان</th>
                            <th class="sortable" data-sort="attempts">تلاش‌ها</th>
                            <th class="sortable" data-sort="completed_at">تاریخ</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody id="resultsTableBody">
                        <!-- داده‌ها با JavaScript پر می‌شود -->
                    </tbody>
                </table>
            </div>

            <!-- صفحه‌بندی -->
            <div class="pagination" id="resultsPagination">
                <button class="page-btn" onclick="changePage('prev')" id="prevPageBtn">‹ قبلی</button>
                <div class="page-numbers" id="pageNumbers"></div>
                <button class="page-btn" onclick="changePage('next')" id="nextPageBtn">بعدی ›</button>
            </div>
        </div>

        <!-- نمایش کارتی (موبایل) -->
        <div class="results-cards-mobile" id="resultsCards" style="display: none;">
            <!-- کارت‌ها با JavaScript پر می‌شود -->
        </div>
    </div>
</div>

<!-- مودال جزئیات دانش‌آموز -->
<div id="studentDetailsModal" class="analysis-modal">
    <div class="modal-backdrop" onclick="closeStudentDetailsModal()"></div>
    <div class="modal-container large">
        <div class="modal-header">
            <h3>📊 تحلیل جامع عملکرد دانش‌آموز</h3>
            <button class="modal-close" onclick="closeStudentDetailsModal()">×</button>
        </div>
        <div class="modal-body">
            <!-- اطلاعات دانش‌آموز -->
            <div class="student-info-section">
                <div class="student-avatar">
                    <img id="studentAvatar" src="default-avatar.png" alt="تصویر دانش‌آموز">
                    <div class="student-rank" id="studentRank">#1</div>
                </div>
                <div class="student-details">
                    <h4 id="studentName">نام دانش‌آموز</h4>
                    <div class="student-stats">
                        <div class="stat-item">
                            <span class="stat-label">کد ملی:</span>
                            <span class="stat-value" id="studentNationalId">--</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">کل بازی‌ها:</span>
                            <span class="stat-value" id="studentTotalPlays">--</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">میانگین امتیاز:</span>
                            <span class="stat-value" id="studentAvgScore">--</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">بهترین امتیاز:</span>
                            <span class="stat-value" id="studentBestScore">--</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- نمودار پیشرفت -->
            <div class="progress-chart-section">
                <h5>📈 روند پیشرفت (30 روز اخیر)</h5>
                <canvas id="studentProgressChart" width="800" height="300"></canvas>
            </div>

            <!-- عملکرد بر اساس دسته‌بندی -->
            <div class="category-performance-section">
                <h5>🎯 عملکرد بر اساس دسته‌بندی</h5>
                <div class="category-performance-grid" id="categoryPerformanceGrid">
                    <!-- با JavaScript پر می‌شود -->
                </div>
            </div>

            <!-- آخرین بازی‌ها -->
            <div class="recent-games-section">
                <h5>🕒 آخرین بازی‌ها</h5>
                <div class="recent-games-list" id="recentGamesList">
                    <!-- با JavaScript پر می‌شود -->
                </div>
            </div>

            <!-- بهترین عملکردها -->
            <div class="best-performances-section">
                <h5>🏆 بهترین عملکردها</h5>
                <div class="best-performances-list" id="bestPerformancesList">
                    <!-- با JavaScript پر می‌شود -->
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeStudentDetailsModal()">بستن</button>
            <button class="btn btn-primary" onclick="exportStudentReport()">📄 گزارش دانش‌آموز</button>
        </div>
    </div>
</div>

                <!-- تب ۵: مدیریت نشان‌ها -->
    <div id="badges-management" class="games-tab-content" >
    <div class="glass-effect">
        <div class="badges-header">

            <h3>مدیریت نشان‌ها و امتیازات XP</h3>
            <p>مدیریت کامل امتیازات دانش‌آموزان در موضوعات مختلف</p>
        </div>

        <!-- فیلترها -->
        <div class="badges-filters">
            <div class="filter-row">
                <div class="filter-group">
                    <label>انتخاب دانش‌آموز:</label>
                    <select id="badgeStudentSearch" onchange="filterBadges()">
                        <option value="">همه دانش‌آموزان</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>فیلتر موضوع:</label>
                    <select id="subjectFilter" onchange="filterBadges()">
                        <option value="">همه موضوعات</option>
                        <option value="math">ریاضی</option>
                        <option value="science">علوم</option>
                        <option value="persian">فارسی</option>
                        <option value="social">اجتماعی</option>
                        <option value="religion">دینی</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>فیلتر سطح:</label>
                    <select id="levelFilter" onchange="filterBadges()">
                        <option value="">همه سطوح</option>
                        <option value="1">مبتدی (سطح 1)</option>
                        <option value="2">متوسط (سطح 2)</option>
                        <option value="3">پیشرفته (سطح 3)</option>
                        <option value="4">حرفه‌ای (سطح 4)</option>
                        <option value="5">استاد (سطح 5+)</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>مرتب‌سازی:</label>
                    <select id="badgeSort" onchange="sortBadges()">
                        <option value="total_desc">کل XP (نزولی)</option>
                        <option value="total_asc">کل XP (صعودی)</option>
                        <option value="level_desc">سطح (نزولی)</option>
                        <option value="name_asc">نام (الفبا)</option>
                    </select>
                </div>
            </div>
            
            <div class="badge-actions-row">
                <button type="button" class="btn-action btn-primary" onclick="showAddXPModalFunc()">
                    افزودن XP دستی
                </button>
                <button type="button" class="btn-action btn-success" onclick="showBulkXPModalFunc()">
                    افزودن گروهی
                </button>
                <button type="button" class="btn-action btn-warning" onclick="showLevelAdjustModalFunc()">
                    تنظیم سطح
                </button>
                <button type="button" class="btn-action btn-export" onclick="exportXPData()">
                    خروجی Excel
                </button>
                <button type="button" class="btn-action btn-refresh" onclick="refreshBadges()">
                    بروزرسانی
                </button>
            </div>
        </div>

        <!-- آمار -->
        <div class="xp-stats-grid">
            <div class="xp-stat-card total">
                <div class="stat-icon">🏆</div>
                <div class="stat-content">
                    <div class="stat-number" id="totalXPPoints">0</div>
                    <div class="stat-label">کل امتیازات XP</div>
                </div>
            </div>
            <div class="xp-stat-card average">
                <div class="stat-icon">📊</div>
                <div class="stat-content">
                    <div class="stat-number" id="avgXPPoints">0</div>
                    <div class="stat-label">میانگین XP</div>
                </div>
            </div>
            <div class="xp-stat-card highest">
                <div class="stat-icon">🥇</div>
                <div class="stat-content">
                    <div class="stat-number" id="highestXP">0</div>
                    <div class="stat-label">بالاترین XP</div>
                </div>
            </div>
            <div class="xp-stat-card subjects">
                <div class="stat-icon">📚</div>
                <div class="stat-content">
                    <div class="stat-number" id="activeSubjects">5</div>
                    <div class="stat-label">موضوعات فعال</div>
                </div>
            </div>
        </div>

        <!-- نمودار پیشرفت -->
        <div class="subjects-progress">
            <h4>📈 پیشرفت موضوعات</h4>
            <div class="progress-bars">
                <div class="progress-item">
                    <div class="progress-info">
                        <span class="subject-name">🔢 ریاضی</span>
                        <span class="progress-value" id="mathProgress">0 XP</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill math" id="mathProgressBar"></div>
                    </div>
                </div>
                <div class="progress-item">
                    <div class="progress-info">
                        <span class="subject-name">🔬 علوم</span>
                        <span class="progress-value" id="scienceProgress">0 XP</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill science" id="scienceProgressBar"></div>
                    </div>
                </div>
                <div class="progress-item">
                    <div class="progress-info">
                        <span class="subject-name">📖 فارسی</span>
                        <span class="progress-value" id="persianProgress">0 XP</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill persian" id="persianProgressBar"></div>
                    </div>
                </div>
                <div class="progress-item">
                    <div class="progress-info">
                        <span class="subject-name">🌍 اجتماعی</span>
                        <span class="progress-value" id="socialProgress">0 XP</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill social" id="socialProgressBar"></div>
                    </div>
                </div>
                <div class="progress-item">
                    <div class="progress-info">
                        <span class="subject-name">📿 دینی</span>
                        <span class="progress-value" id="religionProgress">0 XP</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill religion" id="religionProgressBar"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- جدول -->
        <div class="badges-main-table">
            <div class="table-header">
                <h4>🎖️ جدول امتیازات دانش‌آموزان</h4>
                <div class="table-actions">
                    <button type="button" class="btn-toggle desktop-only" onclick="toggleBadgeViewMode()" id="badgeViewModeBtn">
                        📱 نمایش کارتی
                    </button>
                </div>
            </div>
            
            <!-- نمایش جدولی -->
            <div id="badgeTableView" class="badges-table-container desktop-view">
                <table class="badges-table" id="badgesMainTable">
    <thead>
        <tr>
            <th>رنک</th>
            <th>نام</th>
            <th>سطح</th>
            <th>کل</th>
            <th>ریاضی</th>
            <th>علوم</th>
            <th>فارسی</th>
            <th>اجتماعی</th>
            <th>دینی</th>
            <th>پادکست</th>
            <th>موارد انضباطی</th>
            <th>آزمون</th>
            <th>سایر</th>
            <th>عملیات</th>
        </tr>
    </thead>
    <tbody id="badgesTableBody"></tbody>
</table>
            </div>

            <!-- نمایش کارتی -->
            <div id="badgeCardView" class="badges-cards-container mobile-view"></div>
        </div>
    </div>
</div>

<!-- مودال افزودن XP -->
<div id="addXPModal" class="badge-modal">
    <div class="badge-modal-content">
        <div class="badge-modal-header">
            <h3>افزودن امتیاز XP دستی</h3>
            <button type="button" class="close-btn" onclick="closeAddXPModalFunc()">✕</button>
        </div>
        <div class="badge-modal-body">
            <form id="addXPForm" onsubmit="handleAddXPSubmit(event)">
                <div class="form-row">
                    <div class="form-group">
                        <label>دانش‌آموز:</label>
                        <select id="xpStudentSelect" name="student_id" required>
                            <option value="">انتخاب کنید</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>موضوع:</label>
                       <select name="subject" required>
    <option value="">انتخاب کنید</option>
    <option value="total">کل امتیاز</option>
    <option value="math">ریاضی</option>
    <option value="science">علوم</option>
    <option value="persian">فارسی</option>
    <option value="social">اجتماعی</option>
    <option value="religion">دینی</option>
    <option value="podcast">پادکست</option>
    <option value="dic">موارد انضباطی</option>
    <option value="exam">آزمون‌ها</option>
    <option value="other">سایر</option>
</select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>مقدار XP:</label>
                        <input type="number" name="xp_amount" min="1" max="10000" placeholder="مثال: 100" required>
                    </div>
                    <div class="form-group">
                        <label>نوع عملیات:</label>
                        <select name="operation" required>
                            <option value="add">افزودن</option>
                            <option value="subtract">کم کردن</option>
                            <option value="set">تنظیم مستقیم</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>دلیل تغییر:</label>
                    <textarea name="reason" placeholder="دلیل اعطای یا کم کردن امتیاز..." rows="3"></textarea>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">💾 اعمال تغییرات</button>
                    <button type="button" class="btn-secondary" onclick="closeAddXPModalFunc()">❌ لغو</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- مودال افزودن گروهی -->
<div id="bulkXPModal" class="badge-modal">
    <div class="badge-modal-content">
        <div class="badge-modal-header">
            <h3>افزودن امتیاز گروهی</h3>
            <button type="button" class="close-btn" onclick="closeBulkXPModalFunc()">✕</button>
        </div>
        <div class="badge-modal-body">
            <form id="bulkXPForm" onsubmit="handleBulkXPSubmit(event)">
                <div class="form-row">
                    <div class="form-group">
                        <label>انتخاب دانش‌آموزان:</label>
                        <select id="bulkStudentSelect" name="student_ids[]" multiple size="8" required></select>
                        <small>برای انتخاب چند نفر، Ctrl را نگه دارید</small>
                    </div>
                    <div class="form-group">
                        <label>موضوع:</label>
                        <select name="subject" required>
                            <option value="total">کل امتیاز</option>
                            <option value="math">ریاضی</option>
                            <option value="science">علوم</option>
                            <option value="persian">فارسی</option>
                            <option value="social">اجتماعی</option>
                            <option value="religion">دینی</option>
                        </select>
                        <label>مقدار XP:</label>
                        <input type="number" name="xp_amount" min="1" max="1000" placeholder="مثال: 50" required>
                        <label>دلیل:</label>
                        <textarea name="reason" placeholder="دلیل اعطای امتیاز گروهی..." rows="2" required></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">🎁 اعطای امتیاز به همه</button>
                    <button type="button" class="btn-secondary" onclick="closeBulkXPModalFunc()">❌ لغو</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- مودال تنظیم سطح -->
<div id="levelAdjustModal" class="badge-modal">
    <div class="badge-modal-content">
        <div class="badge-modal-header">
            <h3>تنظیم سطح دانش‌آموز</h3>
            <button type="button" class="close-btn" onclick="closeLevelAdjustModalFunc()">✕</button>
        </div>
        <div class="badge-modal-body">
            <form id="levelAdjustForm" onsubmit="handleLevelAdjustSubmit(event)">
                <div class="form-row">
                    <div class="form-group">
                        <label>دانش‌آموز:</label>
                        <select id="levelStudentSelect" name="student_id" required>
                            <option value="">انتخاب کنید</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>سطح جدید:</label>
                        <select name="new_level" required>
                            <option value="">انتخاب کنید</option>
                            <option value="1">سطح 1 - مبتدی</option>
                            <option value="2">سطح 2 - متوسط</option>
                            <option value="3">سطح 3 - پیشرفته</option>
                            <option value="4">سطح 4 - حرفه‌ای</option>
                            <option value="5">سطح 5 - استاد</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>دلیل تغییر سطح:</label>
                    <textarea name="reason" placeholder="دلیل تغییر سطح..." rows="3" required></textarea>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn-primary">⚡ تغییر سطح</button>
                    <button type="button" class="btn-secondary" onclick="closeLevelAdjustModalFunc()">❌ لغو</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- مودال جزئیات بهبود یافته -->
<div id="detailsModal" class="badge-modal">
    <div class="badge-modal-content large-modal">
        <div class="badge-modal-header">
            <h3 id="detailsModalTitle">جزئیات امتیازات</h3>
            <button type="button" class="close-btn" onclick="closeDetailsModal()">✕</button>
        </div>
        <div class="badge-modal-body">
            <div id="detailsModalContent"></div>
        </div>
    </div>
</div>

<style>
.badges-main-table h4 {
    color: #000 !important;
    text-shadow: none !important;
}
/* اصلاح رنگ فونت در نمایش کارتی */
.badge-card {
    background: white !important;
    border-radius: 15px;
    padding: 1.5rem;
    border: 2px solid #e0e0e0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    color: #000 !important;
}

.badge-card * {
    color: #000 !important; /* تمام المان‌های داخل مشکی */
}

.badge-card .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #f0f0f0;
}

.badge-card .student-name {
    font-size: 1.2rem;
    font-weight: 700;
    color: #000 !important;
}

.badge-card .card-info {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin-bottom: 1rem;
}

.badge-card .info-item {
    background: #f8f9fa;
    padding: 0.8rem;
    border-radius: 8px;
}

.badge-card .info-label {
    font-size: 0.8rem;
    color: #666 !important;
    font-weight: 600;
    margin-bottom: 0.3rem;
}

.badge-card .info-value {
    font-weight: 700;
    color: #000 !important;
    font-size: 1rem;
}

.badge-card .card-actions {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
    padding-top: 1rem;
    border-top: 2px solid #f0f0f0;
}

/* نمایش کارتی موبایل - همه فونت‌ها مشکی */
.badges-cards-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1rem;
    background: transparent;
}

/* اطمینان از مشکی بودن تمام متن‌ها */
.badge-card h1, .badge-card h2, .badge-card h3, 
.badge-card h4, .badge-card h5, .badge-card h6,
.badge-card p, .badge-card span, .badge-card div,
.badge-card strong, .badge-card label {
    color: #000 !important;
}

/* level badge در کارت */
.badge-card .level-badge {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white !important; /* فقط badge ها سفید */
    padding: 0.3rem 0.8rem;
    border-radius: 15px;
    font-weight: 600;
}

/* دکمه‌های عملیات در کارت */
.badge-card .btn-action.btn-sm {
    background: rgba(102, 126, 234, 0.1);
    color: #667eea !important;
    border: 2px solid #667eea;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.badge-card .btn-action.btn-sm:hover {
    background: #667eea;
    color: white !important;
}

/* container اصلی نمایش کارتی */
#badgeCardView {
    background: transparent !important;
}

.glass-effect { background: rgba(255,255,255,0.15); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.2); border-radius: 20px; padding: 2rem; color: white; }
.badges-header { text-align: center; margin-bottom: 2rem; }
.badges-header h3 { font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem; }
.badges-filters { background: rgba(255,255,255,0.1); border-radius: 15px; padding: 1.5rem; margin-bottom: 2rem; }
.filter-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1rem; }
.filter-group { display: flex; flex-direction: column; gap: 0.5rem; }
.filter-group label { font-weight: 600; font-size: 0.9rem; }
.filter-group select { background: rgba(255,255,255,0.2); border: 2px solid rgba(255,255,255,0.3); color: white; padding: 0.75rem; border-radius: 10px; font-family: inherit; }
.filter-group select option { background: #333; color: white; }
.badge-actions-row { display: flex; gap: 1rem; flex-wrap: wrap; justify-content: center; }
.btn-action { background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; padding: 0.8rem 1.5rem; border-radius: 10px; cursor: pointer; font-weight: 600; transition: all 0.3s ease; }
.btn-action:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
.btn-action.btn-primary { background: linear-gradient(135deg, #28a745, #20c997); }
.btn-action.btn-success { background: linear-gradient(135deg, #17a2b8, #138496); }
.btn-action.btn-warning { background: linear-gradient(135deg, #ffc107, #e0a800); }
.btn-action.btn-export { background: linear-gradient(135deg, #6f42c1, #5a32a3); }
.btn-action.btn-refresh { background: linear-gradient(135deg, #fd7e14, #e8681e); }
.xp-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
.xp-stat-card { background: rgba(255,255,255,0.1); border-radius: 15px; padding: 1.5rem; display: flex; align-items: center; gap: 1rem; }
.stat-icon { font-size: 2.5rem; }
.stat-number { font-size: 2rem; font-weight: 800; }
.stat-label { font-size: 0.9rem; opacity: 0.8; }
.total .stat-number { color: #ffd700; }
.average .stat-number { color: #28a745; }
.highest .stat-number { color: #ff6b6b; }
.subjects-progress { background: rgba(255,255,255,0.1); border-radius: 15px; padding: 1.5rem; margin-bottom: 2rem; }
.progress-bars { display: flex; flex-direction: column; gap: 1rem; }
.progress-item { display: flex; flex-direction: column; gap: 0.5rem; }
.progress-info { display: flex; justify-content: space-between; }
.progress-bar { background: rgba(255,255,255,0.2); border-radius: 10px; height: 12px; overflow: hidden; }
.progress-fill { height: 100%; border-radius: 10px; transition: width 0.5s ease; }
.progress-fill.math { background: linear-gradient(90deg, #ff6b6b, #ff8e8e); }
.progress-fill.science { background: linear-gradient(90deg, #28a745, #20c997); }
.progress-fill.persian { background: linear-gradient(90deg, #17a2b8, #20c0dd); }
.progress-fill.social { background: linear-gradient(90deg, #ffc107, #ffed4e); }
.progress-fill.religion { background: linear-gradient(90deg, #6f42c1, #8e5adc); }
.badges-main-table { background: rgba(255,255,255,0.1); border-radius: 15px; padding: 1.5rem; }
.table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 1rem; }
.badges-table-container { overflow-x: auto; background: rgba(255,255,255,0.05); border-radius: 10px; }
.badges-table { width: 100%; border-collapse: collapse; min-width: 800px; }
.badges-table th { background: rgba(0,0,0,0.3); color: white; padding: 1rem; text-align: right; font-weight: 700; border-bottom: 2px solid rgba(255,255,255,0.2); }
.badges-table td { padding: 0.8rem; color: white; border-bottom: 1px solid rgba(255,255,255,0.1); }
.badges-table tbody tr:hover { background: rgba(255,255,255,0.1); }
.level-badge { padding: 0.3rem 0.8rem; border-radius: 15px; font-size: 0.8rem; font-weight: 600; }
.level-1 { background: linear-gradient(135deg, #28a745, #20c997); color: white; }
.level-2 { background: linear-gradient(135deg, #17a2b8, #138496); color: white; }
.level-3 { background: linear-gradient(135deg, #ffc107, #e0a800); color: #333; }
.level-4 { background: linear-gradient(135deg, #fd7e14, #e8681e); color: white; }
.level-5 { background: linear-gradient(135deg, #6f42c1, #5a32a3); color: white; }
.actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
.btn-action.btn-sm { padding: 0.4rem 0.6rem; font-size: 0.8rem; min-width: 30px; height: 30px; }
.badge-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: none; justify-content: center; align-items: center; z-index: 10000; padding: 1rem; }
.badge-modal.show { display: flex !important; }
.badge-modal-content { background: white; border-radius: 20px; max-width: 600px; width: 100%; max-height: 80vh; overflow-y: auto; }
.badge-modal-content.large-modal { max-width: 900px; }
.badge-modal-header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 1.5rem; border-radius: 20px 20px 0 0; display: flex; justify-content: space-between; align-items: center; }
.close-btn { background: rgba(255,255,255,0.2); color: white; border: none; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; font-size: 1.2rem; }
.badge-modal-body { padding: 2rem; color: #333; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem; }
.form-group { display: flex; flex-direction: column; gap: 0.5rem; }
.form-group input, .form-group select, .form-group textarea { padding: 0.8rem; border: 2px solid #ddd; border-radius: 8px; font-family: inherit; }
.form-actions { display: flex; gap: 1rem; justify-content: center; margin-top: 2rem; }
.btn-primary { background: linear-gradient(135deg, #28a745, #20c997); color: white; border: none; padding: 0.8rem 2rem; border-radius: 10px; cursor: pointer; font-weight: 600; }
.btn-secondary { background: #6c757d; color: white; border: none; padding: 0.8rem 2rem; border-radius: 10px; cursor: pointer; font-weight: 600; }
.badges-cards-container { display: none; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }
.badge-card { background: rgba(255,255,255,0.1); border-radius: 15px; padding: 1.5rem; }
.history-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
.history-table th { background: #f8f9fa; padding: 0.75rem; text-align: right; border-bottom: 2px solid #dee2e6; }
.history-table td { padding: 0.75rem; border-bottom: 1px solid #dee2e6; }
.history-actions { display: flex; gap: 0.5rem; justify-content: center; }
.btn-delete { background: #dc3545; color: white; border: none; padding: 0.3rem 0.6rem; border-radius: 5px; cursor: pointer; font-size: 0.8rem; }
.btn-edit { background: #ffc107; color: #333; border: none; padding: 0.3rem 0.6rem; border-radius: 5px; cursor: pointer; font-size: 0.8rem; }
@media (max-width: 768px) {
    .filter-row { grid-template-columns: 1fr; }
    .badge-actions-row { flex-direction: column; }
    .xp-stats-grid { grid-template-columns: 1fr 1fr; }
    .form-row { grid-template-columns: 1fr; }
    .desktop-view { display: none !important; }
    .mobile-view { display: grid !important; }
    .desktop-only { display: none !important; }
    .badge-modal-content { max-width: 95%; }
}
@media (min-width: 769px) {
    .mobile-view { display: none !important; }
    .desktop-view { display: block !important; }
}
.back-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            color: white;
            cursor: pointer;
            margin-bottom: 20px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-5px);
        }
</style>

<script>
let allBadges = [], filteredBadges = [], studentsData = [];
let currentViewMode = 'table';
let xpStats = { total: 0, average: 0, highest: 0, subjects: { math: 0, science: 0, persian: 0, social: 0, religion: 0 } };

function loadBadgesData() {
    showLoading();
    fetch('../ajax/get_badges.php?action=load_badges')
    .then(r => r.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            allBadges = data.badges || [];
            filteredBadges = [...allBadges];
            updateXPStats();
            updateProgressBars();
            renderBadgesTable();
            showAlert('داده‌ها بارگیری شد (' + allBadges.length + ' رکورد)', 'success');
        }
    })
    .catch(e => { hideLoading(); showAlert('خطا: ' + e.message, 'error'); });
}

function loadStudentsForSelect() {
    fetch('../ajax/get_students.php?action=get_students_list')
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            studentsData = data.students || [];
            populateStudentSelects();
        }
    });
}

function populateStudentSelects() {
    ['badgeStudentSearch', 'xpStudentSelect', 'levelStudentSelect'].forEach(id => {
        const sel = document.getElementById(id);
        if (sel) {
            const first = sel.options[0];
            sel.innerHTML = '';
            sel.appendChild(first);
            studentsData.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id;
                opt.textContent = s.name;
                sel.appendChild(opt);
            });
        }
    });
    const bulk = document.getElementById('bulkStudentSelect');
    if (bulk) {
        bulk.innerHTML = '';
        studentsData.forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.id;
            opt.textContent = s.name;
            bulk.appendChild(opt);
        });
    }
}

function updateXPStats() {
    if (!allBadges.length) return;
    let total = 0, highest = 0;
    let subjects = { math: 0, science: 0, persian: 0, social: 0, religion: 0 };
    allBadges.forEach(b => {
        const t = parseInt(b.total_xp || 0);
        total += t;
        if (t > highest) highest = t;
        Object.keys(subjects).forEach(s => subjects[s] += parseInt(b[s + '_xp'] || 0));
    });
    const avg = Math.round(total / allBadges.length);
    document.getElementById('totalXPPoints').textContent = formatNumber(total);
    document.getElementById('avgXPPoints').textContent = formatNumber(avg);
    document.getElementById('highestXP').textContent = formatNumber(highest);
    xpStats = { total, average: avg, highest, subjects };
}

function updateProgressBars() {
    const max = Math.max(...Object.values(xpStats.subjects));
    Object.keys(xpStats.subjects).forEach(s => {
        const xp = xpStats.subjects[s];
        const pct = max > 0 ? (xp / max) * 100 : 0;
        const bar = document.getElementById(s + 'ProgressBar');
        const txt = document.getElementById(s + 'Progress');
        if (bar) bar.style.width = pct + '%';
        if (txt) txt.textContent = formatNumber(xp) + ' XP';
    });
}


  function renderBadgesTable() {
    const tbody = document.getElementById('badgesTableBody');
    const cards = document.getElementById('badgeCardView');
    if (!tbody) return;
    
    if (!filteredBadges.length) {
        tbody.innerHTML = '<tr><td colspan="14" style="text-align:center;padding:2rem;">داده‌ای یافت نشد</td></tr>';
        if (cards) cards.innerHTML = '<p style="text-align:center;">داده‌ای یافت نشد</p>';
        return;
    }
    
    let html = '';
    let cardHtml = '';
    
    filteredBadges.forEach((b, i) => {
        const rank = i + 1;
        const level = b.level || calculateLevel(b.total_xp);
        const levelText = getLevelText(level);
        
        // جدول - نمایش تمام فیلدها
        html += `<tr>
            <td><strong>#${rank}</strong></td>
            <td><strong>${b.student_name}</strong></td>
            <td><span class="level-badge level-${level}">${levelText}</span></td>
            <td><strong>${formatNumber(b.total_xp || 0)}</strong></td>
            <td>${formatNumber(b.math_xp || 0)}</td>
            <td>${formatNumber(b.science_xp || 0)}</td>
            <td>${formatNumber(b.persian_xp || 0)}</td>
            <td>${formatNumber(b.social_xp || 0)}</td>
            <td>${formatNumber(b.religion_xp || 0)}</td>
            <td>${formatNumber(b.podcast_xp || 0)}</td>
            <td>${formatNumber(b.dic_xp || 0)}</td>
            <td>${formatNumber(b.exam_xp || 0)}</td>
            <td>${formatNumber(b.other_xp || 0)}</td>
            <td class="actions">
                <button type="button" onclick="viewStudentXPDetails(${b.student_id || b.user_id})" title="جزئیات" class="btn-action btn-sm">👁️</button>
                <button type="button" onclick="editStudentXP(${b.student_id || b.user_id})" title="ویرایش" class="btn-action btn-sm">✏️</button>
                <button type="button" onclick="resetStudentXP(${b.student_id || b.user_id})" title="ریست" class="btn-action btn-sm">🔄</button>
            </td>
        </tr>`;
        
        // کارت موبایل - نمایش تمام فیلدها
        cardHtml += `<div class="badge-card">
            <div style="display:flex;justify-content:space-between;margin-bottom:1rem;">
                <strong style="font-size:1.2rem;">#${rank} ${b.student_name}</strong>
                <span class="level-badge level-${level}">${levelText}</span>
            </div>
            <div style="font-size:1.5rem;font-weight:800;color:#ffd700;margin-bottom:1rem;">
                کل: ${formatNumber(b.total_xp || 0)} XP
            </div>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:0.5rem;margin-bottom:1rem;font-size:0.85rem;">
                <div>🔢 ریاضی: ${formatNumber(b.math_xp || 0)}</div>
                <div>🔬 علوم: ${formatNumber(b.science_xp || 0)}</div>
                <div>📖 فارسی: ${formatNumber(b.persian_xp || 0)}</div>
                <div>🌍 اجتماعی: ${formatNumber(b.social_xp || 0)}</div>
                <div>📿 دینی: ${formatNumber(b.religion_xp || 0)}</div>
                <div>🎧 پادکست: ${formatNumber(b.podcast_xp || 0)}</div>
                <div>⚖️ انضباطی: ${formatNumber(b.dic_xp || 0)}</div>
                <div>📝 آزمون: ${formatNumber(b.exam_xp || 0)}</div>
                <div>⭐ سایر: ${formatNumber(b.other_xp || 0)}</div>
            </div>
            <div class="actions" style="justify-content:space-around;">
                <button type="button" onclick="viewStudentXPDetails(${b.student_id || b.user_id})" class="btn-action btn-sm">👁️</button>
                <button type="button" onclick="editStudentXP(${b.student_id || b.user_id})" class="btn-action btn-sm">✏️</button>
                <button type="button" onclick="resetStudentXP(${b.student_id || b.user_id})" class="btn-action btn-sm">🔄</button>
            </div>
        </div>`;
    });
    
    tbody.innerHTML = html;
    if (cards) cards.innerHTML = cardHtml;
}

function calculateLevel(xp) {
    if (xp < 100) return 1;
    if (xp < 500) return 2;
    if (xp < 1500) return 3;
    if (xp < 3000) return 4;
    return 5;
}

function getLevelText(l) {
    return { 1: 'مبتدی', 2: 'متوسط', 3: 'پیشرفته', 4: 'حرفه‌ای', 5: 'استاد' }[l] || 'نامشخص';
}

function filterBadges() {
    const studentF = document.getElementById('badgeStudentSearch').value;
    const subjectF = document.getElementById('subjectFilter').value;
    const levelF = document.getElementById('levelFilter').value;
    filteredBadges = allBadges.filter(b => {
        if (studentF && (b.student_id != studentF && b.user_id != studentF)) return false;
        if (levelF && (b.level || calculateLevel(b.total_xp)) != levelF) return false;
        if (subjectF && (b[subjectF + '_xp'] || 0) <= 0) return false;
        return true;
    });
    renderBadgesTable();
}

function sortBadges() {
    const sort = document.getElementById('badgeSort').value;
    filteredBadges.sort((a, b) => {
        if (sort === 'total_desc') return (b.total_xp || 0) - (a.total_xp || 0);
        if (sort === 'total_asc') return (a.total_xp || 0) - (b.total_xp || 0);
        if (sort === 'level_desc') return (b.level || calculateLevel(b.total_xp)) - (a.level || calculateLevel(a.total_xp));
        if (sort === 'name_asc') return a.student_name.localeCompare(b.student_name);
        return 0;
    });
    renderBadgesTable();
}

function toggleBadgeViewMode() {
    const table = document.getElementById('badgeTableView');
    const cards = document.getElementById('badgeCardView');
    const btn = document.getElementById('badgeViewModeBtn');
    if (currentViewMode === 'table') {
        table.style.display = 'none';
        cards.style.display = 'grid';
        btn.textContent = '📊 نمایش جدولی';
        currentViewMode = 'card';
    } else {
        table.style.display = 'block';
        cards.style.display = 'none';
        btn.textContent = '📱 نمایش کارتی';
        currentViewMode = 'table';
    }
}

// مودال‌ها - اصلاح شده
function showAddXPModalFunc() {
    document.getElementById('addXPModal').classList.add('show');
    document.getElementById('addXPForm').reset();
}

function closeAddXPModalFunc() {
    document.getElementById('addXPModal').classList.remove('show');
}

function showBulkXPModalFunc() {
    document.getElementById('bulkXPModal').classList.add('show');
    document.getElementById('bulkXPForm').reset();
}

function closeBulkXPModalFunc() {
    document.getElementById('bulkXPModal').classList.remove('show');
}

function showLevelAdjustModalFunc() {
    document.getElementById('levelAdjustModal').classList.add('show');
    document.getElementById('levelAdjustForm').reset();
}

function closeLevelAdjustModalFunc() {
    document.getElementById('levelAdjustModal').classList.remove('show');
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.remove('show');
}

// جزئیات بهبود یافته
function viewStudentXPDetails(sid) {
    showLoading();
    fetch('../ajax/get_student_xp_details.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student_id: sid })
    })
    .then(r => r.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showDetailedModal(data.student, data.xp_history);
        } else {
            showAlert('خطا: ' + data.message, 'error');
        }
    })
    .catch(e => { hideLoading(); showAlert('خطا: ' + e.message, 'error'); });
}

function showDetailedModal(student, history) {
    const modal = document.getElementById('detailsModal');
    document.getElementById('detailsModalTitle').textContent = 'جزئیات امتیازات - ' + student.name;
    
    let html = `<div style="background:#f8f9fa;padding:1rem;border-radius:10px;margin-bottom:1rem;">
        <h4>آمار فعلی:</h4>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-top:0.5rem;">
            <div><strong>کل XP:</strong> ${formatNumber(student.total_xp || 0)}</div>
            <div><strong>سطح:</strong> ${getLevelText(student.level || calculateLevel(student.total_xp))}</div>
            <div><strong>ریاضی:</strong> ${formatNumber(student.math_xp || 0)} XP</div>
            <div><strong>علوم:</strong> ${formatNumber(student.science_xp || 0)} XP</div>
            <div><strong>فارسی:</strong> ${formatNumber(student.persian_xp || 0)} XP</div>
            <div><strong>اجتماعی:</strong> ${formatNumber(student.social_xp || 0)} XP</div>
        </div>
    </div>`;
    
    if (history && history.length) {
        html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">';
        html += '<h4 style="margin:0;">تاریخچه تغییرات:</h4>';
        html += `<button type="button" class="btn-delete" onclick="deleteAllHistory(${student.id})" style="padding:0.5rem 1rem;font-size:0.9rem;">
            🗑️ حذف همه تاریخچه
        </button>`;
        html += '</div>';
        
        html += '<table class="history-table"><thead><tr><th>تاریخ</th><th>موضوع</th><th>مقدار</th><th>دلیل</th><th>عملیات</th></tr></thead><tbody>';
        history.forEach(h => {
            const color = h.amount >= 0 ? '#28a745' : '#dc3545';
            html += `<tr>
                <td style="font-size:0.85rem;">${formatDate(h.created_at)}</td>
                <td>${getSubjectName(h.subject)}</td>
                <td style="color:${color};font-weight:bold;">${h.amount >= 0 ? '+' : ''}${h.amount} XP</td>
                <td style="font-size:0.85rem;">${h.reason || '-'}</td>
                <td class="history-actions">
                    <button type="button" class="btn-delete" onclick="deleteHistoryRecord(${h.id}, ${student.id})">حذف</button>
                </td>
            </tr>`;
        });
        html += '</tbody></table>';
    } else {
        html += '<p>هیچ تاریخچه‌ای یافت نشد</p>';
    }
    
    document.getElementById('detailsModalContent').innerHTML = html;
    modal.classList.add('show');
}

// تصحیح تابع حذف رکورد تاریخچه
function deleteHistoryRecord(historyId, studentId) {
    if (!confirm('این رکورد از تاریخچه حذف شود؟')) return;
    showLoading();
    fetch('../ajax/manage_xp.php', {  // اطمینان از مسیر صحیح
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete_history', history_id: historyId })
    })
    .then(r => {
        // بررسی پاسخ قبل از parse کردن
        if (!r.ok) throw new Error('پاسخ سرور معتبر نیست');
        return r.json();
    })
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('رکورد حذف شد', 'success');
            viewStudentXPDetails(studentId);
            loadBadgesData(); // رفرش لیست
        } else {
            showAlert('خطا: ' + result.message, 'error');
        }
    })
    .catch(e => { 
        hideLoading(); 
        console.error('خطا در حذف:', e);
        showAlert('خطا: ' + e.message, 'error'); 
    });
}


function editStudentXP(sid) {
    showAddXPModalFunc();
    document.getElementById('xpStudentSelect').value = sid;
}


// تصحیح تابع ریست کامل
function resetStudentXP(sid) {
    if (!confirm('⚠️ توجه: تمام امتیازات و تاریخچه این دانش‌آموز برای همیشه حذف می‌شود.\n\nآیا مطمئن هستید؟')) return;
    
    showLoading();
    fetch('../ajax/manage_xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            action: 'reset_student_xp_complete', 
            student_id: sid 
        })
    })
    .then(r => {
        if (!r.ok) throw new Error('پاسخ سرور معتبر نیست');
        return r.json();
    })
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('✅ تمام داده‌های دانش‌آموز با موفقیت حذف شد', 'success');
            loadBadgesData();
        } else {
            showAlert('❌ خطا: ' + (result.message || 'خطای نامشخص'), 'error');
        }
    })
    .catch(e => { 
        hideLoading(); 
        console.error('خطا در ریست:', e);
        showAlert('خطا در ارتباط با سرور: ' + e.message, 'error'); 
    });
}
function deleteAllHistory(studentId) {
    if (!confirm('⚠️ هشدار:\n\nتمام تاریخچه این دانش‌آموز برای همیشه حذف می‌شود.\n\nآیا مطمئن هستید؟')) {
        return;
    }
    
    if (!confirm('⚠️ تایید نهایی:\n\nاین عملیات غیرقابل بازگشت است!\n\nآیا ادامه می‌دهید؟')) {
        return;
    }
    
    showLoading();
    fetch('../ajax/manage_xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            action: 'delete_all_history', 
            student_id: studentId 
        })
    })
    .then(r => {
        if (!r.ok) throw new Error('پاسخ سرور معتبر نیست');
        return r.json();
    })
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('✅ ' + result.message, 'success');
            closeDetailsModal();
            loadBadgesData();
        } else {
            showAlert('❌ خطا: ' + result.message, 'error');
        }
    })
    .catch(e => { 
        hideLoading(); 
        console.error('خطا:', e);
        showAlert('خطا: ' + e.message, 'error'); 
    });
}
function refreshBadges() {
    loadBadgesData();
    loadStudentsForSelect();
}

// خروجی Excel با فونت فارسی
function exportXPData() {
    showLoading();
    window.location.href = '../ajax/export_xp.php?format=excel';
    setTimeout(hideLoading, 2000);
}

// فرم‌ها
function handleAddXPSubmit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd.entries());
    data.action = 'add_xp';
    showLoading();
    fetch('../ajax/manage_xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('امتیاز تغییر کرد', 'success');
            closeAddXPModalFunc();
            loadBadgesData();
        } else {
            showAlert('خطا: ' + result.message, 'error');
        }
    })
    .catch(e => { hideLoading(); showAlert('خطا: ' + e.message, 'error'); });
}

function handleBulkXPSubmit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const sel = Array.from(document.getElementById('bulkStudentSelect').selectedOptions).map(o => o.value);
    if (!sel.length) { showAlert('لطفاً حداقل یک دانش‌آموز انتخاب کنید', 'warning'); return; }
    const data = { action: 'bulk_add_xp', student_ids: sel, subject: fd.get('subject'), xp_amount: fd.get('xp_amount'), reason: fd.get('reason') };
    showLoading();
    fetch('../ajax/manage_xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('امتیاز به ' + sel.length + ' نفر اضافه شد', 'success');
            closeBulkXPModalFunc();
            loadBadgesData();
        } else {
            showAlert('خطا: ' + result.message, 'error');
        }
    })
    .catch(e => { hideLoading(); showAlert('خطا: ' + e.message, 'error'); });
}

function handleLevelAdjustSubmit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd.entries());
    data.action = 'adjust_level';
    showLoading();
    fetch('../ajax/manage_xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(result => {
        hideLoading();
        if (result.success) {
            showAlert('سطح تغییر کرد', 'success');
            closeLevelAdjustModalFunc();
            loadBadgesData();
        } else {
            showAlert('خطا: ' + result.message, 'error');
        }
    })
    .catch(e => { hideLoading(); showAlert('خطا: ' + e.message, 'error'); });
}

function formatNumber(n) { return new Intl.NumberFormat('fa-IR').format(n || 0); }
function formatDate(d) {
    if (!d) return 'نامشخص';
    return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
}
function getSubjectName(s) {
    return { 
        'math': 'ریاضی', 
        'science': 'علوم', 
        'persian': 'فارسی', 
        'social': 'اجتماعی', 
        'religion': 'دینی', 
        'podcast': 'پادکست',
        'dic': 'موارد انضباطی',
        'exam': 'آزمون‌ها',
        'other': 'سایر',
        'total': 'کل امتیاز', 
        'level_change': 'تغییر سطح', 
        'reset_all': 'ریست کامل',
        'delete_all_history': 'حذف تاریخچه'
    }[s] || s;
}
function showLoading() {
    let load = document.getElementById('loadingOverlay');
    if (!load) {
        load = document.createElement('div');
        load.id = 'loadingOverlay';
        load.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);display:flex;justify-content:center;align-items:center;z-index:20000;';
        load.innerHTML = '<div style="width:60px;height:60px;border:6px solid rgba(255,255,255,0.3);border-top:6px solid #fff;border-radius:50%;animation:spin 1s linear infinite;"></div>';
        document.body.appendChild(load);
        const style = document.createElement('style');
        style.textContent = '@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}';
        document.head.appendChild(style);
    } else {
        load.style.display = 'flex';
    }
}
function hideLoading() {
    const load = document.getElementById('loadingOverlay');
    if (load) load.style.display = 'none';
}
function showAlert(msg, type) {
    const div = document.createElement('div');
    const bg = type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : type === 'warning' ? '#ffc107' : '#17a2b8';
    div.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;"><span style="flex:1;">' + msg + '</span><button onclick="this.parentElement.parentElement.remove()" style="background:rgba(255,255,255,0.2);border:none;color:white;width:25px;height:25px;border-radius:50%;cursor:pointer;">✕</button></div>';
    div.style.cssText = 'position:fixed;top:20px;right:20px;background:' + bg + ';color:white;padding:1rem 1.5rem;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.3);z-index:20001;animation:slideIn 0.3s ease;max-width:600px;font-family:inherit;direction:rtl;';
    const style = document.createElement('style');
    style.textContent = '@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}';
    document.head.appendChild(style);
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 5000);
}

// بارگیری اولیه
setTimeout(() => {
    if (document.getElementById('badges-management').style.display !== 'none') {
        loadBadgesData();
        loadStudentsForSelect();
    }
}, 500);
// اضافه کردن به انتهای کد JavaScript
function fixModalStyles() {
    const modals = document.querySelectorAll('.badge-modal');
    modals.forEach(modal => {
        const selects = modal.querySelectorAll('select');
        const inputs = modal.querySelectorAll('input');
        const textareas = modal.querySelectorAll('textarea');
        
        [...selects, ...inputs, ...textareas].forEach(el => {
            el.style.border = '2px solid #333';
            el.style.color = '#000';
            el.style.backgroundColor = '#fff';
        });
    });
}

// فراخوانی هنگام باز شدن مدال‌ها
function showAddXPModalFunc() {
    document.getElementById('addXPModal').classList.add('show');
    document.getElementById('addXPForm').reset();
    fixModalStyles();
}

function showBulkXPModalFunc() {
    document.getElementById('bulkXPModal').classList.add('show');
    document.getElementById('bulkXPForm').reset();
    fixModalStyles();
}

function showLevelAdjustModalFunc() {
    document.getElementById('levelAdjustModal').classList.add('show');
    document.getElementById('levelAdjustForm').reset();
    fixModalStyles();
}
</script>

        <!-- مودال افزودن بازی جدید -->
        <div id="addGameModal" class="game-modal">
            <div class="modal-backdrop" onclick="closeAddGameModal()"></div>
            <div class="modal-container">
                <div class="modal-header">
                    <h3>🎮 افزودن بازی جدید</h3>
                    <button class="modal-close" onclick="closeAddGameModal()">×</button>
                </div>
                <div class="modal-body">
                    <form id="addGameForm">
                        <div class="form-grid">
                            <div class="form-group">
                                <label>عنوان بازی <span class="required">*</span></label>
                                <input type="text" name="title" required placeholder="نام جذاب بازی را وارد کنید">
                            </div>
                            <div class="form-group">
                                <label>درس <span class="required">*</span></label>
                               <select name="category_id" required>
    <option value="">انتخاب کنید</option>
    <!-- گزینه‌ها با JavaScript پر می‌شوند -->
</select>
                            </div>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>موضوع درس</label>
                                <input type="text" name="topic" placeholder="مثال: جمع و تفریق، املا و نگارش">
                            </div>
                            <div class="form-group">
                                <label>زمان تقریبی (دقیقه)</label>
                                <input type="number" name="estimated_time" value="5" min="1" max="60">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>توضیحات کوتاه</label>
                            <textarea name="description" rows="3" placeholder="توضیح کوتاه درباره بازی"></textarea>
                        </div>

                        <div class="form-group">
                            <label>راهنمای بازی</label>
                            <textarea name="instructions" rows="3" placeholder="نحوه انجام بازی را برای دانش‌آموزان توضیح دهید"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>کد بازی (HTML/CSS/JS) <span class="required">*</span></label>
                            <textarea name="game_code" rows="10" required placeholder="کد کامل بازی شامل HTML, CSS و JavaScript"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeAddGameModal()">لغو</button>
                    <button type="submit" form="addGameForm" class="btn btn-primary">ذخیره بازی</button>
                </div>
            </div>
        </div>

        <!-- مودال ویرایش بازی -->
        <div id="editGameModal" class="game-modal">
            <div class="modal-backdrop" onclick="closeEditGameModal()"></div>
            <div class="modal-container">
                <div class="modal-header">
                    <h3>✏️ ویرایش بازی</h3>
                    <button class="modal-close" onclick="closeEditGameModal()">×</button>
                </div>
                <div class="modal-body">
                    <form id="editGameForm">
                        <input type="hidden" name="game_id" id="editGameId">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>عنوان بازی <span class="required">*</span></label>
                                <input type="text" name="title" id="editGameTitle" required>
                            </div>
                            <div class="form-group">
                                <label>درس <span class="required">*</span></label>
                                <select name="category_id" id="editGameCategory" required>
                                    <option value="">انتخاب کنید</option>
                                    <?php
                                    try {
                                        $stmt = $conn->prepare("SELECT id, name FROM game_categories WHERE is_active = 1 ORDER BY name");
                                        $stmt->execute();
                                        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                        
                                        foreach($categories as $category) {
                                            echo '<option value="' . htmlspecialchars($category['id']) . '">' . htmlspecialchars($category['name']) . '</option>';
                                        }
                                    } catch (Exception $e) {
                                        echo '<option value="1">ریاضی</option>';
                                        echo '<option value="2">فارسی</option>';
                                        echo '<option value="3">علوم</option>';
                                        echo '<option value="4">مطالعات اجتماعی</option>';
                                        echo '<option value="5">دینی و اخلاق</option>';
                                        echo '<option value="6">انگلیسی</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>موضوع درس</label>
                                <input type="text" name="topic" id="editGameTopic">
                            </div>
                            <div class="form-group">
                                <label>زمان تقریبی (دقیقه)</label>
                                <input type="number" name="estimated_time" id="editGameTime" min="1" max="60">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>توضیحات</label>
                            <textarea name="description" id="editGameDescription" rows="3"></textarea>
                        </div>

                        <div class="form-group">
                            <label>راهنمای بازی</label>
                            <textarea name="instructions" id="editGameInstructions" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>کد بازی (HTML/CSS/JS) <span class="required">*</span></label>
                            <textarea name="game_code" id="editGameCode" rows="10" required></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeEditGameModal()">لغو</button>
                    <button type="submit" form="editGameForm" class="btn btn-primary">بروزرسانی</button>
                </div>
            </div>
        </div>

        <!-- مودال نتایج بازی -->
        <div id="gameResultsModal" class="game-modal">
            <div class="modal-backdrop" onclick="closeGameResultsModal()"></div>
            <div class="modal-container large">
                <div class="modal-header">
                    <h3>📊 نتایج بازی</h3>
                    <button class="modal-close" onclick="closeGameResultsModal()">×</button>
                </div>
                <div class="modal-body">
                    <!-- آمار کلی بازی -->
                    <div class="results-stats">
                        <div class="stat-item">
                            <div class="stat-value" id="resultsTotalPlays">0</div>
                            <div class="stat-label">کل بازی‌ها</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value" id="resultsAvgScore">0</div>
                            <div class="stat-label">میانگین امتیاز</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value" id="resultsAvgTime">0</div>
                            <div class="stat-label">میانگین زمان</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value" id="resultsAvgAccuracy">0%</div>
                            <div class="stat-label">میانگین دقت</div>
                        </div>
                    </div>

                    <!-- جدول نتایج -->
                     <!-- افزودن عملیات عمومی بالای جدول -->
    <div class="modal-results-actions">
        <!-- این بخش برای عملیات فیلتر، جستجو و حذف کلی است -->
        
        <!-- فیلترها در خط جداگانه قرار می‌گیرند تا با حذف تداخل نکند -->
    </div>

    <!-- جدول نتایج و فیلترهای سریع -->
    <div style="display: flex; justify-content: space-between; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem;">
        <div class="results-filters" style="margin: 0;">
            <input type="text" id="resultsSearch" placeholder="جستجو در نام دانش‌آموز...">
            <select id="resultsDateFilter">
                <option value="">همه تاریخ‌ها</option>
                <option value="today">امروز</option>
                <option value="week">این هفته</option>
                <option value="month">این ماه</option>
            </select>
        </div>
         <button type="button" class="delete-all-btn" onclick="deleteAllGameResults()">🗑️ حذف همه نتایج</button>
    </div>

    <!-- جدول نتایج -->
    <div class="results-table-container">
        <!-- اصلاح سربرگ جدول در اینجا: -->
        <table class="results-table">
            <thead>
                <tr>
                    <th>دانش‌آموز</th>
                    <th>امتیاز</th>
                    <th>زمان (ثانیه)</th>
                    <th>دقت (%)</th>
                    <th>تاریخ</th>
                    <th>عملیات</th> <!-- ستون جدید -->
                </tr>
            </thead>
            <tbody id="gameModalResultsTableBody"></tbody>
        </table>
    </div>
</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeGameResultsModal()">بستن</button>
                    <button type="button" class="btn btn-primary" onclick="exportGameResults()">خروجی Excel</button>
                </div>
            </div>
        </div>

    </div>
    
<!-- مودال ویرایش نتیجه بازی (نسخه اصلاح شده) -->
<div id="editResultModal" class="game-modal">
    <div class="modal-backdrop" onclick="closeEditResultModal()"></div>
    <div class="modal-container">
        <div class="modal-header">
            <h3>📝 ویرایش نتیجه بازی</h3>
            <button class="modal-close" onclick="closeEditResultModal()">×</button>
        </div>
        <div class="modal-body">
            <!-- فرم از اینجا شروع می‌شود -->
            <form id="editResultForm">
                <!-- **نکته کلیدی: این فیلد باید بلافاصله داخل فرم باشد** -->
                <input type="hidden" name="result_id" id="editResultId">
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>دانش‌آموز</label>
                    <input type="text" id="editStudentName" readonly style="background-color: #f1f3f5; color: #6c757d;">
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>امتیاز (۰ تا ۱۰۰) <span class="required">*</span></label>
                        <input type="number" name="score" id="editResultScore" min="0" max="100" required>
                    </div>
                    <div class="form-group">
                        <label>دقت (%) (۰ تا ۱۰۰) <span class="required">*</span></label>
                        <input type="number" name="accuracy" id="editResultAccuracy" min="0" max="100" step="0.1" required>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>زمان صرف شده (ثانیه) <span class="required">*</span></label>
                        <input type="number" name="time_spent" id="editResultTimeSpent" min="1" required>
                    </div>
                    <div class="form-group">
                        <label>تعداد تلاش‌ها</label>
                        <input type="number" name="attempts" id="editResultAttempts" min="1">
                    </div>
                </div>

                <div class="form-group">
                    <label>تاریخ و زمان اتمام <span class="required">*</span></label>
                    <input type="datetime-local" name="completed_at" id="editResultCompletedAt" required style="direction: ltr; text-align: right;">
                </div>

            </form>
            <!-- فرم در اینجا تمام می‌شود -->
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeEditResultModal()">لغو</button>
            <!-- این دکمه فرم را با شناسه آن پیدا کرده و ارسال می‌کند -->
            <button type="submit" form="editResultForm" class="btn btn-primary">ذخیره تغییرات</button>
        </div>
    </div>
</div>

    <!-- اسکریپت Chart.js برای نمودارها -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    
    <script>
    let currentViewingGameId = null; // متغیر سراسری برای ذخیره ID بازی فعلی
const resultsPerPage = 25; // می‌توانید این مقدار را تغییر دهید
let currentResultsPage = 1;
let currentTotalResults = 0;
let lastFetchedResults = []; // برای ذخیره نتایج خام بارگذاری شده جهت فیلترینگ در فرانت‌اند (به جای فرستادن درخواست‌های مکرر)

        // تابع مدیریت تب‌ها
        function showGameTab(tabId) {
            console.log('Switching to tab:', tabId);
            
            // مخفی کردن همه تب‌ها
            document.querySelectorAll('.games-tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // غیرفعال کردن همه دکمه‌های تب
            document.querySelectorAll('.games-tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // نمایش تب انتخاب‌شده
            const activeTab = document.getElementById(tabId);
            if (activeTab) {
                activeTab.classList.add('active');
            }
            
            // فعال کردن دکمه تب
            event.target.classList.add('active');
            
            // بارگذاری محتوای خاص تب (در صورت نیاز)
            if (tabId === 'games-list') {
                loadGamesList();
            } else if (tabId === 'results-management') {
                loadResultsData();
            }
        }

        // بارگذاری لیست بازی‌ها
        function loadGamesList() {
            fetch('../ajax/load_games.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateGamesTable(data.games);
                        updateResultsInfo(data.games.length);
                    } else {
                        console.error('خطا در بارگیری بازی‌ها:', data.message);
                    }
                })
                .catch(error => {
                    console.error('خطا در ارتباط با سرور:', error);
                });
        }

        // بروزرسانی جدول بازی‌ها
        function updateGamesTable(games) {
            const tbody = document.getElementById('gamesTableBody');
            if (!tbody) return;

            if (games.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.7);">هیچ بازی‌ای یافت نشد</td></tr>';
                return;
            }

            tbody.innerHTML = games.map(game => `
                <tr>
                    <td><strong>${game.title}</strong></td>
                    <td>${game.category_name || game.subject || 'نامشخص'}</td>
                    <td>${game.play_count || 0}</td>
                    <td>${game.avg_score ? parseFloat(game.avg_score).toFixed(1) : '0.0'}</td>
                    <td>
                        <span class="${game.is_active ? 'status-active' : 'status-inactive'}">
                            ${game.is_active ? 'فعال' : 'غیرفعال'}
                        </span>
                    </td>
                    <td class="game-actions">
                        <button onclick="editGame(${game.id})" title="ویرایش">✏️</button>
                        <button onclick="toggleGameStatus(${game.id}, ${game.is_active})" title="${game.is_active ? 'غیرفعال کردن' : 'فعال کردن'}">
                            ${game.is_active ? '🔴' : '🟢'}
                        </button>
                        <button onclick="viewGameResults(${game.id})" title="نمایش نتایج">📊</button>
                        <button onclick="deleteGame(${game.id})" title="حذف" class="delete-btn">🗑️</button>
                    </td>
                </tr>
            `).join('');
        }

        // بروزرسانی اطلاعات نتایج
        function updateResultsInfo(count) {
            const info = document.getElementById('resultsInfo');
            if (info) {
                info.textContent = `${count} بازی یافت شد`;
            }
        }

        // فیلتر کردن بازی‌ها
        function filterGamesList() {
            const subject = document.getElementById('filterGameSubject').value;
            const status = document.getElementById('filterGameStatus').value;
            
            const params = new URLSearchParams();
            if (subject) params.append('subject', subject);
            if (status !== '') params.append('status', status);
            
            fetch(`../ajax/load_games.php?${params.toString()}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateGamesTable(data.games);
                        updateResultsInfo(data.games.length);
                    }
                })
                .catch(error => console.error('خطا در فیلتر:', error));
        }

        // ریست کردن فیلترها
        function resetFilters() {
            document.getElementById('filterGameSubject').value = '';
            document.getElementById('filterGameStatus').value = '';
            loadGamesList();
        }

        // عملکردهای CRUD بازی‌ها
        // عملکردهای CRUD بازی‌ها
        function showAddGameModal() {
            document.getElementById('addGameModal').classList.add('show');
            document.body.style.overflow = 'hidden';
        }

        function closeAddGameModal() {
            document.getElementById('addGameModal').classList.remove('show');
            document.body.style.overflow = 'auto';
            document.getElementById('addGameForm').reset();
        }

        function editGame(gameId) {
            showLoading();
            
            fetch(`../ajax/get_game.php?id=${gameId}`)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    
                    if (data.success) {
                        populateEditForm(data.game);
                        document.getElementById('editGameModal').classList.add('show');
                        document.body.style.overflow = 'hidden';
                    } else {
                        alert('خطا در بارگیری اطلاعات بازی: ' + data.message);
                    }
                })
                .catch(error => {
                    hideLoading();
                    console.error('خطا:', error);
                    alert('خطا در ارتباط با سرور');
                });
        }

        function populateEditForm(game) {
            document.getElementById('editGameId').value = game.id;
            document.getElementById('editGameTitle').value = game.title;
            document.getElementById('editGameCategory').value = game.category_id;
            document.getElementById('editGameTopic').value = game.topic || '';
            document.getElementById('editGameTime').value = game.estimated_time;
            document.getElementById('editGameDescription').value = game.description || '';
            document.getElementById('editGameInstructions').value = game.instructions || '';
            document.getElementById('editGameCode').value = game.game_code;
        }

        function closeEditGameModal() {
            document.getElementById('editGameModal').classList.remove('show');
            document.body.style.overflow = 'auto';
            document.getElementById('editGameForm').reset();
        }

              function viewGameResults(gameId) {
            currentViewingGameId = gameId; // ذخیره ID بازی فعال
            currentResultsPage = 1; // ریست صفحه به 1
            document.getElementById('resultsSearch').value = ''; // ریست جستجو
            document.getElementById('resultsDateFilter').value = ''; // ریست فیلتر تاریخ

            showLoading();

            // فراخوانی تابع جدید برای بارگذاری و نمایش نتایج
            loadModalResults(gameId); 
            
            // نمایش مودال در صورت موفقیت‌آمیز بودن fetch
            document.getElementById('gameResultsModal').classList.add('show');
            document.body.style.overflow = 'hidden';
        }
      
                       async function loadModalResults(gameId, search = '', dateFilter = '') {
            showLoading();

            try {
                // Fetch داده خام (نتایج کلی) را هر بار که modal باز می‌شود، می‌گیریم
                const response = await fetch(`../ajax/get_game_results.php?game_id=${gameId}`);
                const data = await response.json();
                
                hideLoading();

                if (data.success) {
                    // ذخیره نتایج خام
                    lastFetchedResults = data.results;
                    // پر کردن آمار کلی در بالای مودال (بدون فیلتر)
                    populateResultsStats(data.stats);
                    
                    // اعمال فیلتر و صفحه بندی محلی و پر کردن جدول
                    filterAndPaginateResults(search, dateFilter); 

                } else {
                    alert('خطا در بارگیری نتایج: ' + data.message);
                }
            } catch (error) {
                hideLoading();
                console.error('خطا در ارتباط با سرور:', error);
                alert('خطا در ارتباط با سرور');
            }
        }
        
        function populateResultsStats(stats) {
             document.getElementById('resultsTotalPlays').textContent = stats.total_plays || 0;
            // مطمئن شوید که اینجا آیدی gameResultsModal استفاده شود و نه آیدی results-management
             document.getElementById('resultsAvgScore').textContent = parseFloat(stats.avg_score || 0).toFixed(1);
             document.getElementById('resultsAvgTime').textContent = (stats.avg_time || 0) + ' ث';
             document.getElementById('resultsAvgAccuracy').textContent = (stats.avg_accuracy || 0) + '%';
        }
        
        // **این بخش قلب حل مشکل نمایش جدول شماست**
        function populateResultsModal(results, currentPage, totalPages) {
            const tbody = document.getElementById('gameModalResultsTableBody');
            
            // 1. اطمینان از پاکسازی محتویات قبلی (با توجه به ریسک نشت حافظه یا نمایش ناقص)
            if (!tbody) {
                console.error("tbody not found!");
                return;
            }
            tbody.innerHTML = '';
            
            if (results && results.length > 0) {
                // 2. ساخت ردیف‌ها با داده‌های فیلترشده و صفحه بندی شده
                tbody.innerHTML = results.map(result => {
                    const accuracyPercentage = parseFloat(result.accuracy).toFixed(1) + '%';
                    let accuracyClass = 'accuracy-low';
                    if (result.accuracy >= 90) accuracyClass = 'accuracy-high';
                    else if (result.accuracy >= 60) accuracyClass = 'accuracy-medium';

                    return `
                        <tr>
                            <td>${result.student_name || 'ناشناس'}</td>
                            <td><span class="score-badge score-average">${result.score}</span></td>
                            <td>${result.time_spent || '---'}</td>
                            <td><span class="accuracy-badge ${accuracyClass}">${accuracyPercentage}</span></td>
                            <td>${formatDate(result.completed_at)}</td>
                            <td> <!-- ستون جدید عملیات -->
                                <div class="result-actions">
                                    <button class="edit-result-btn" onclick="editSingleResult(${result.id})" title="ویرایش">✏️</button>
                                    <button class="delete-result-btn" onclick="deleteSingleResult(${result.id})" title="حذف">🗑️</button>
                                </div>
                            </td>
                        </tr>
                    `;
                }).join('');
            } else {
          
                // 3. در صورت خالی بودن نتایج، پیام مناسب نمایش داده شود
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 2rem;">هیچ نتیجه‌ای مطابق فیلتر/جستجو یافت نشد.</td></tr>';
            }
        }

        // تابع برای اعمال فیلترهای داخلی مودال و به‌روزرسانی جدول
        function filterAndPaginateResults(search, dateFilter) {
            if (!lastFetchedResults) return;

            let filteredResults = [...lastFetchedResults];
            
            // 1. اعمال فیلتر جستجو (جستجو در نام)
            if (search) {
                const searchLower = search.toLowerCase();
                filteredResults = filteredResults.filter(result => 
                    (result.student_name && result.student_name.toLowerCase().includes(searchLower))
                );
            }
            
            // 2. اعمال فیلتر تاریخ (نیاز به پیاده سازی کامل بر اساس تاریخ)
            if (dateFilter) {
                 // **نکته مهم:** فیلتر تاریخ پیچیده است و در اینجا برای سادگی فقط برای این ماه در نظر گرفته می‌شود
                const now = new Date();
                filteredResults = filteredResults.filter(result => {
                    const resultDate = new Date(result.completed_at);
                    
                    if (dateFilter === 'today') {
                         return resultDate.toDateString() === now.toDateString();
                    } else if (dateFilter === 'week') {
                         const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                         return resultDate >= oneWeekAgo;
                    } else if (dateFilter === 'month') {
                         return resultDate.getMonth() === now.getMonth() && resultDate.getFullYear() === now.getFullYear();
                    }
                    return true;
                });
            }
            
            currentTotalResults = filteredResults.length;
            
            // 3. اعمال صفحه بندی
            const start = (currentResultsPage - 1) * resultsPerPage;
            const end = start + resultsPerPage;
            const paginatedResults = filteredResults.slice(start, end);
            const totalPages = Math.ceil(currentTotalResults / resultsPerPage);

            // 4. پر کردن جدول
            populateResultsModal(paginatedResults, currentResultsPage, totalPages);
        }

        // توابع event listener برای فیلترهای مودال
        document.addEventListener('DOMContentLoaded', function() {
            // ... کدهای موجود
            
            // افزودن شنونده‌های رویداد برای جستجو و فیلتر تاریخ داخل مودال
            const resultsSearch = document.getElementById('resultsSearch');
            const resultsDateFilter = document.getElementById('resultsDateFilter');
            
            if (resultsSearch && resultsDateFilter) {
                // با تغییر فیلتر تاریخ، داده را فیلتر کند
                resultsDateFilter.addEventListener('change', function() {
                    currentResultsPage = 1;
                    filterAndPaginateResults(resultsSearch.value, this.value);
                });

                // با تایپ در فیلد جستجو (با تاخیر کم برای جلوگیری از درخواست‌های مکرر)
                let searchTimeout;
                resultsSearch.addEventListener('input', function() {
                    clearTimeout(searchTimeout);
                    searchTimeout = setTimeout(() => {
                        currentResultsPage = 1;
                        filterAndPaginateResults(this.value, resultsDateFilter.value);
                    }, 300); // 300 میلی‌ثانیه تاخیر
                });
            }

            // ... ادامه کدهای موجود
        });

        function closeGameResultsModal() {
            document.getElementById('gameResultsModal').classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        function exportGameResults() {
            // TODO: پیاده‌سازی خروجی Excel
            alert('خروجی Excel به زودی اضافه می‌شود');
        }

        // مدیریت فرم‌ها
        function initializeGameForm() {
            // فرم افزودن بازی
            document.getElementById('addGameForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                console.log('Form submitted'); // لاگ دیباگ
                
                const formData = new FormData(this);
                
                // بررسی فیلدهای الزامی
                const title = formData.get('title');
                const category_id = formData.get('category_id');
                const game_code = formData.get('game_code');
                
                if (!title || !category_id || !game_code) {
                    showNotification('لطفاً تمام فیلدهای الزامی را پر کنید', 'error');
                    return;
                }
                
                console.log('Form data:', {
                    title: title,
                    category_id: category_id,
                    game_code_length: game_code.length
                });
                
                showLoading();
                
                fetch('../ajax/add_game.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.text(); // ابتدا text بگیریم
                })
                .then(text => {
                    console.log('Response text:', text);
                    
                    let data;
                    try {
                        data = JSON.parse(text);
                    } catch (e) {
                        console.error('JSON parse error:', e);
                        throw new Error('پاسخ سرور نامعتبر است: ' + text);
                    }
                    
                    hideLoading();
                    
                    if (data.success) {
                        closeAddGameModal();
                        loadGamesList();
                        showNotification('بازی با موفقیت اضافه شد', 'success');
                    } else {
                        showNotification('خطا: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    console.error('Fetch error:', error);
                    showNotification('خطا در ارتباط با سرور: ' + error.message, 'error');
                });
            });

            // فرم ویرایش بازی
            document.getElementById('editGameForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                showLoading();
                
                fetch('../ajax/edit_game.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    
                    if (data.success) {
                        closeEditGameModal();
                        loadGamesList();
                        showNotification('بازی با موفقیت بروزرسانی شد', 'success');
                    } else {
                        showNotification('خطا: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    console.error('خطا:', error);
                    showNotification('خطا در ارتباط با سرور', 'error');
                });
            });
        }

        // توابع کمکی
        function showLoading() {
            // ایجاد overlay لودینگ در صورت عدم وجود
            let overlay = document.getElementById('loadingOverlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'loadingOverlay';
                overlay.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0,0,0,0.7);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 2000;
                `;
                overlay.innerHTML = '<div class="spinner"></div>';
                document.body.appendChild(overlay);
            }
            overlay.style.display = 'flex';
        }

        function hideLoading() {
            const overlay = document.getElementById('loadingOverlay');
            if (overlay) {
                overlay.style.display = 'none';
            }
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 10px;
                z-index: 3000;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                transform: translateX(400px);
                transition: transform 0.3s ease;
            `;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);
            
            setTimeout(() => {
                notification.style.transform = 'translateX(400px)';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('fa-IR') + ' ' + date.toLocaleTimeString('fa-IR');
        }

        // بستن مودال‌ها با کلید Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.game-modal.show').forEach(modal => {
                    modal.classList.remove('show');
                    document.body.style.overflow = 'auto';
                });
            }
        });

        function toggleGameStatus(gameId, currentStatus) {
            if (confirm(`آیا مطمئن هستید که می‌خواهید وضعیت این بازی را ${currentStatus ? 'غیرفعال' : 'فعال'} کنید؟`)) {
                console.log('Toggle game status:', gameId);
                showLoading();
                
                // تست چندین مسیر برای پیدا کردن مسیر صحیح
                const paths = [
                    './ajax/toggle_game_status.php',
                    '../ajax/toggle_game_status.php', 
                    'ajax/toggle_game_status.php',
                    '/ajax/toggle_game_status.php'
                ];
                
                testTogglePaths(paths, gameId, 0);
            }
        }
        
        async function testTogglePaths(paths, gameId, index) {
            if (index >= paths.length) {
                hideLoading();
                showNotification('هیچ مسیری برای toggle کار نکرد', 'error');
                return;
            }
            
            const path = paths[index];
            console.log(`Testing toggle path: ${path}`);
            
            try {
                const response = await fetch(path, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ game_id: parseInt(gameId) })
                });
                
                console.log(`Response from ${path}:`, response.status);
                
                const responseText = await response.text();
                console.log(`Raw response from ${path}:`, responseText);
                
                // بررسی اینکه آیا پاسخ JSON است یا HTML
                if (responseText.trim().startsWith('{') || responseText.trim().startsWith('[')) {
                    try {
                        const data = JSON.parse(responseText);
                        console.log(`Parsed JSON from ${path}:`, data);
                        
                        hideLoading();
                        
                        if (data.success) {
                            loadGamesList(); // بارگذاری مجدد لیست
                            showNotification('وضعیت بازی با موفقیت تغییر کرد', 'success');
                        } else {
                            showNotification('خطا: ' + data.message, 'error');
                        }
                        return; // موفقیت - متوقف کن
                        
                    } catch (jsonError) {
                        console.error(`JSON parse error for ${path}:`, jsonError);
                        // ادامه به مسیر بعدی
                    }
                } else {
                    console.log(`${path} returned HTML instead of JSON`);
                    // ادامه به مسیر بعدی
                }
                
            } catch (networkError) {
                console.error(`Network error for ${path}:`, networkError);
                // ادامه به مسیر بعدی
            }
            
            // تست مسیر بعدی
            testTogglePaths(paths, gameId, index + 1);
        }

        function deleteGame(gameId) {
            if (confirm('آیا مطمئن هستید که می‌خواهید این بازی را حذف کنید؟ این عمل غیرقابل بازگشت است.')) {
                console.log('Delete game:', gameId);
                showLoading();
                
                // تست چندین مسیر برای پیدا کردن مسیر صحیح
                const paths = [
                    './ajax/delete_game.php',
                    '../ajax/delete_game.php', 
                    'ajax/delete_game.php',
                    '/ajax/delete_game.php'
                ];
                
                testDeletePaths(paths, gameId, 0);
            }
        }
        
        async function testDeletePaths(paths, gameId, index) {
            if (index >= paths.length) {
                hideLoading();
                showNotification('هیچ مسیری برای حذف کار نکرد', 'error');
                return;
            }
            
            const path = paths[index];
            console.log(`Testing delete path: ${path}`);
            
            try {
                const response = await fetch(path, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ game_id: parseInt(gameId) })
                });
                
                console.log(`Delete response from ${path}:`, response.status);
                
                const responseText = await response.text();
                console.log(`Raw delete response from ${path}:`, responseText);
                
                // بررسی اینکه آیا پاسخ JSON است یا HTML
                if (responseText.trim().startsWith('{') || responseText.trim().startsWith('[')) {
                    try {
                        const data = JSON.parse(responseText);
                        console.log(`Parsed delete JSON from ${path}:`, data);
                        
                        hideLoading();
                        
                        if (data.success) {
                            loadGamesList(); // بارگذاری مجدد لیست
                            showNotification('بازی با موفقیت حذف شد', 'success');
                        } else {
                            showNotification('خطا: ' + data.message, 'error');
                        }
                        return; // موفقیت - متوقف کن
                        
                    } catch (jsonError) {
                        console.error(`Delete JSON parse error for ${path}:`, jsonError);
                        // ادامه به مسیر بعدی
                    }
                } else {
                    console.log(`${path} returned HTML instead of JSON`);
                    // ادامه به مسیر بعدی
                }
                
            } catch (networkError) {
                console.error(`Delete network error for ${path}:`, networkError);
                // ادامه به مسیر بعدی
            }
            
            // تست مسیر بعدی
            testDeletePaths(paths, gameId, index + 1);
        }

        // بارگذاری اولیه
        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM loaded, initializing...');
            
            // بررسی وجود عناصر مهم
            const addModal = document.getElementById('addGameModal');
            const editModal = document.getElementById('editGameModal');
            const addForm = document.getElementById('addGameForm');
            const editForm = document.getElementById('editGameForm');
            
            console.log('Modal elements check:', {
                addModal: !!addModal,
                editModal: !!editModal,
                addForm: !!addForm,
                editForm: !!editForm
            });
            
            // راه‌اندازی فرم‌ها
            initializeGameForm();
            
            // بارگذاری اولیه لیست بازی‌ها
            loadGamesList();
            
            console.log('Initialization completed');
        });
                // توابع جدید برای مدیریت نتایج تکی و گروهی

       // جایگزین کردن تابع قبلی با این نسخه کامل
function editSingleResult(resultId) {
    showLoading();
    
    // ۱. دریافت اطلاعات نتیجه از سرور
    fetch(`../ajax/get_single_result.php?id=${resultId}`)
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) {
                // ۲. پر کردن فرم با اطلاعات دریافتی
                populateEditResultForm(data.result);
                // ۳. نمایش مودال ویرایش
                document.getElementById('editResultModal').classList.add('show');
                document.body.style.overflow = 'hidden';
            } else {
                showNotification('خطا در بارگیری اطلاعات نتیجه: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Error fetching result data:', error);
            showNotification('خطا در ارتباط با سرور.', 'error');
        });
}

// تابع برای پر کردن فرم ویرایش
// تابع برای پر کردن فرم ویرایش
function populateEditResultForm(result) {
    document.getElementById('editResultId').value = result.id;
    document.getElementById('editStudentName').value = result.student_name || 'ناشناس';
    document.getElementById('editResultScore').value = result.score;
    document.getElementById('editResultAccuracy').value = result.accuracy;
    document.getElementById('editResultTimeSpent').value = result.time_spent;
    document.getElementById('editResultAttempts').value = result.attempts;
    
    // **این بخش کلیدی اصلاح شده است**
    if (result.completed_at) {
        // دیتابیس فرمت 'YYYY-MM-DD HH:MM:SS' را می‌دهد.
        // اینپوت به فرمت 'YYYY-MM-DDTHH:MM' نیاز دارد (بدون ثانیه).
        // ما با slice(0, 16) ثانیه‌ها را حذف می‌کنیم.
        const formattedDate = result.completed_at.slice(0, 16).replace(' ', 'T');
        document.getElementById('editResultCompletedAt').value = formattedDate;
    }
}

// تابع برای بستن مودال ویرایش
function closeEditResultModal() {
    document.getElementById('editResultModal').classList.remove('show');
    document.body.style.overflow = 'auto';
    document.getElementById('editResultForm').reset();
}

// حذف یک نتیجه (نسخه بهبود یافته)
async function deleteSingleResult(resultId) {
    if (!confirm(`آیا مطمئن هستید که می‌خواهید این نتیجه را حذف کنید؟\n\n⚠️ این عمل غیرقابل بازگشت است و:\n• رکورد از game_results حذف می‌شود\n• رکورد از xp_history حذف می‌شود\n• امتیاز XP دانش‌آموز کاهش می‌یابد`)) {
        return;
    }

    showLoading();

    try {
        const response = await fetch('../ajax/delete_single_result.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'  // اضافه شد
            },
            body: JSON.stringify({ result_id: resultId })
        });

        // بررسی وضعیت HTTP
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        hideLoading();

        if (data.success) {
            // نمایش پیام موفقیت با جزئیات
            let message = data.message || 'نتیجه با موفقیت حذف شد';
            
            // اگر اطلاعات بیشتری از سرور آمده، نمایش بده
            if (data.xp_returned && data.xp_returned > 0) {
                message += `\n\n📊 جزئیات:\n`;
                message += `• ${data.xp_records_deleted || 0} رکورد XP حذف شد\n`;
                message += `• ${data.xp_returned} امتیاز به دانش‌آموز بازگردانده شد`;
            }
            
            showNotification(message, 'success');
            
            // بارگذاری مجدد نتایج
            if (currentViewingGameId) {
                await loadModalResults(currentViewingGameId);
            } else {
                // اگر در صفحه دیگری هستیم، رفرش کنیم
                location.reload();
            }
            
        } else {
            // نمایش خطای دقیق از سرور
            showNotification('خطا در حذف: ' + (data.message || 'خطای ناشناخته'), 'error');
            console.error('Delete failed:', data);
        }
        
    } catch (error) {
        hideLoading();
        console.error('Delete error:', error);
        
        // پیام خطای دقیق‌تر
        let errorMsg = 'خطا در ارتباط با سرور';
        if (error.message) {
            errorMsg += ': ' + error.message;
        }
        showNotification(errorMsg, 'error');
    }
}

// حذف همه نتایج یک بازی (بهبود یافته)
async function deleteAllGameResults() {
    if (!currentViewingGameId) {
        showNotification('شناسه بازی یافت نشد.', 'error');
        return;
    }
    
    if (!confirm('⚠️⚠️⚠️ اخطار شدید ⚠️⚠️⚠️\n\nآیا مطمئن هستید که می‌خواهید **همه** نتایج این بازی را حذف کنید؟\n\nاین عمل:\n• تمام نتایج را از game_results حذف می‌کند\n• تمام رکوردهای مرتبط را از xp_history حذف می‌کند\n• امتیازات XP همه دانش‌آموزان را کاهش می‌دهد\n\nاین عمل غیرقابل بازگشت است!')) {
        return;
    }
    
    // تایید دوباره برای امنیت بیشتر
    if (!confirm('آیا واقعاً مطمئن هستید؟ این آخرین هشدار است!')) {
        return;
    }

    showLoading();
    
    try {
        const response = await fetch('../ajax/delete_all_game_results.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ game_id: currentViewingGameId })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        hideLoading();

        if (data.success) {
            const count = data.deleted_count || 0;
            showNotification(`✅ موفقیت!\n\n${count} نتیجه با موفقیت حذف شدند`, 'success');
            
            // بارگذاری مجدد
            await loadModalResults(currentViewingGameId);
            
            // بروزرسانی لیست بازی‌ها
            if (typeof loadGamesList === 'function') {
                loadGamesList();
            }
        } else {
            showNotification('خطا در حذف نتایج: ' + (data.message || 'خطای ناشناخته'), 'error');
            console.error('Delete all failed:', data);
        }
        
    } catch (error) {
        hideLoading();
        console.error('Delete all error:', error);
        showNotification('خطا در ارتباط با سرور: ' + (error.message || ''), 'error');
    }
}

// تابع کمکی برای نمایش console log (اختیاری - برای debug)
function logDeleteOperation(operation, data) {
    if (console && console.group) {
        console.group(`🗑️ ${operation}`);
        console.log('Time:', new Date().toLocaleString('fa-IR'));
        console.log('Data:', data);
        console.groupEnd();
    }
}
        // ... (بقیه کدهای جاوا اسکریپت پرامپت) ...
    // =================== جاوا اسکریپت‌های پرامپت‌ساز اصلاح شده ===================

// متغیرهای سراسری پرامپت‌ساز
let currentStep = 1;
let wizardData = {
    subject: '',
    grade: '',
    topic: '',
    gameType: '',
    difficulty: '',
    duration: 120,
    notes: ''
};

// راه‌اندازی پرامپت‌ساز
function initializePromptWizard() {
    console.log('Initializing Prompt Wizard...');
    
    // تنظیم مرحله اولیه
    currentStep = 1;
    updateStepDisplay();
    
    // رویدادهای انتخاب موضوع
    document.querySelectorAll('.subject-card').forEach(card => {
        card.addEventListener('click', function() {
            selectSubject(this.dataset.subject);
        });
    });

    // رویدادهای انتخاب مقطع
    document.querySelectorAll('.grade-pill').forEach(pill => {
        pill.addEventListener('click', function() {
            selectGrade(this.dataset.grade);
        });
    });

    // رویدادهای انتخاب نوع بازی
    document.querySelectorAll('.game-type-card').forEach(card => {
        card.addEventListener('click', function() {
            selectGameType(this.dataset.type);
        });
    });

    // رویدادهای انتخاب سختی
    document.querySelectorAll('.difficulty-option').forEach(option => {
        option.addEventListener('click', function() {
            selectDifficulty(this.dataset.difficulty);
        });
    });

    // رویداد اسلایدر مدت زمان
    const durationSlider = document.getElementById('durationSlider');
    if (durationSlider) {
        durationSlider.addEventListener('input', function() {
            updateDuration(this.value);
        });
        // مقدار اولیه
        updateDuration(120);
    }

    // رویداد تغییر موضوع درس
    const topicInput = document.getElementById('promptTopic');
    if (topicInput) {
        topicInput.addEventListener('input', function() {
            wizardData.topic = this.value;
            checkStep2Completion();
        });
    }

    // رویداد تغییر توضیحات
    const notesTextarea = document.getElementById('promptNotes');
    if (notesTextarea) {
        notesTextarea.addEventListener('input', function() {
            wizardData.notes = this.value;
        });
    }

    console.log('Prompt Wizard initialized successfully');
}

// بروزرسانی نمایش مراحل
function updateStepDisplay() {
    // مخفی کردن همه مراحل
    document.querySelectorAll('.wizard-step').forEach(step => {
        step.classList.remove('active');
    });
    
    // نمایش مرحله فعلی
    const currentStepElement = document.querySelector(`.wizard-step[data-step="${currentStep}"]`);
    if (currentStepElement) {
        currentStepElement.classList.add('active');
    }
    
    // بروزرسانی نشانگرهای مرحله
    document.querySelectorAll('.step-item').forEach(item => {
        const stepNum = parseInt(item.dataset.step);
        item.classList.remove('active', 'completed');
        
        if (stepNum === currentStep) {
            item.classList.add('active');
        } else if (stepNum < currentStep) {
            item.classList.add('completed');
        }
    });
}

// انتخاب موضوع
function selectSubject(subject) {
    console.log('Subject selected:', subject);
    
    // حذف انتخاب قبلی
    document.querySelectorAll('.subject-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // انتخاب جدید
    const selectedCard = document.querySelector(`[data-subject="${subject}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
        wizardData.subject = subject;
        checkStep1Completion();
    }
}

// انتخاب مقطع
function selectGrade(grade) {
    console.log('Grade selected:', grade);
    
    // حذف انتخاب قبلی
    document.querySelectorAll('.grade-pill').forEach(pill => {
        pill.classList.remove('selected');
    });
    
    // انتخاب جدید
    const selectedPill = document.querySelector(`[data-grade="${grade}"]`);
    if (selectedPill) {
        selectedPill.classList.add('selected');
        wizardData.grade = grade;
        checkStep1Completion();
    }
}

// بررسی تکمیل مرحله ۱
function checkStep1Completion() {
    console.log('Checking step 1 completion:', wizardData.subject, wizardData.grade);
    
    const nextBtn = document.querySelector('.wizard-step[data-step="1"] .next-btn');
    if (nextBtn) {
        if (wizardData.subject && wizardData.grade) {
            nextBtn.disabled = false;
            nextBtn.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
            console.log('Step 1 completed - next button enabled');
        } else {
            nextBtn.disabled = true;
            nextBtn.style.background = 'rgba(255,255,255,0.1)';
            console.log('Step 1 not completed - next button disabled');
        }
    }
}

// انتخاب نوع بازی
function selectGameType(gameType) {
    console.log('Game type selected:', gameType);
    
    // حذف انتخاب قبلی
    document.querySelectorAll('.game-type-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // انتخاب جدید
    const selectedCard = document.querySelector(`[data-type="${gameType}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
        wizardData.gameType = gameType;
        checkStep2Completion();
    }
}

// انتخاب سختی
function selectDifficulty(difficulty) {
    console.log('Difficulty selected:', difficulty);
    
    // حذف انتخاب قبلی
    document.querySelectorAll('.difficulty-option').forEach(option => {
        option.classList.remove('selected');
    });
    
    // انتخاب جدید
    const selectedOption = document.querySelector(`[data-difficulty="${difficulty}"]`);
    if (selectedOption) {
        selectedOption.classList.add('selected');
        wizardData.difficulty = difficulty;
        checkStep2Completion();
    }
}

// بروزرسانی مدت زمان
function updateDuration(value) {
    wizardData.duration = parseInt(value);
    const durationValue = document.getElementById('durationValue');
    if (durationValue) {
        durationValue.textContent = Math.round(value / 60);
    }
    console.log('Duration updated:', wizardData.duration);
}

// بررسی تکمیل مرحله ۲
function checkStep2Completion() {
    const nextBtn = document.querySelector('.wizard-step[data-step="2"] .next-btn');
    const topicValue = document.getElementById('promptTopic')?.value?.trim() || '';
    
    console.log('Checking step 2 completion:', {
        gameType: wizardData.gameType,
        difficulty: wizardData.difficulty,
        topic: topicValue
    });
    
    if (nextBtn) {
        if (wizardData.gameType && wizardData.difficulty && topicValue) {
            wizardData.topic = topicValue; // بروزرسانی topic
            nextBtn.disabled = false;
            nextBtn.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
            console.log('Step 2 completed - next button enabled');
        } else {
            nextBtn.disabled = true;
            nextBtn.style.background = 'rgba(255,255,255,0.1)';
            console.log('Step 2 not completed - next button disabled');
        }
    }
}

// رفتن به مرحله بعدی
function nextStep() {
    console.log('Next step called, current step:', currentStep);
    
    if (currentStep === 1) {
        // بررسی تکمیل مرحله 1
        if (!wizardData.subject || !wizardData.grade) {
            showNotification('لطفاً درس و مقطع را انتخاب کنید', 'error');
            return;
        }
    } else if (currentStep === 2) {
        // بررسی تکمیل مرحله 2
        const topicValue = document.getElementById('promptTopic')?.value?.trim() || '';
        if (!wizardData.gameType || !wizardData.difficulty || !topicValue) {
            showNotification('لطفاً تمام فیلدهای الزامی را پر کنید', 'error');
            return;
        }
        wizardData.topic = topicValue;
        wizardData.notes = document.getElementById('promptNotes')?.value || '';
    }
    
    if (currentStep < 3) {
        currentStep++;
        updateStepDisplay();
        
        // اگر رسیدیم به مرحله ۳، پرامپت را تولید کن
        if (currentStep === 3) {
            console.log('Reached step 3, generating prompt...');
            setTimeout(() => {
                generatePrompt();
            }, 500);
        }
        
        console.log('Moved to step:', currentStep);
    }
}

// رفتن به مرحله قبلی
function prevStep() {
    console.log('Previous step called, current step:', currentStep);
    
    if (currentStep > 1) {
        currentStep--;
        updateStepDisplay();
        console.log('Moved to step:', currentStep);
    }
}

// تولید پرامپت
function generatePrompt() {
    console.log('Generating prompt with data:', wizardData);
    
    // پر کردن خلاصه
    const summaryElements = {
        subject: document.getElementById('summarySubject'),
        grade: document.getElementById('summaryGrade'),
        gameType: document.getElementById('summaryGameType'),
        difficulty: document.getElementById('summaryDifficulty')
    };
    
    if (summaryElements.subject) summaryElements.subject.textContent = wizardData.subject;
    if (summaryElements.grade) summaryElements.grade.textContent = wizardData.grade;
    if (summaryElements.gameType) summaryElements.gameType.textContent = wizardData.gameType;
    if (summaryElements.difficulty) summaryElements.difficulty.textContent = wizardData.difficulty;
    
    // تولید پرامپت نهایی
    const prompt = createAdvancedPrompt();
    const finalPromptText = document.getElementById('finalPromptText');
    if (finalPromptText) {
        finalPromptText.value = prompt;
    }
    
    // انیمیشن موفقیت
    setTimeout(() => {
        showNotification('پرامپت با موفقیت تولید شد! 🎉', 'success');
    }, 500);
    
    console.log('Prompt generated successfully');
}

function createAdvancedPrompt() {
    const durationMinutes = Math.round(wizardData.duration / 60);
    
    return `شما یک طراح بازی‌های آموزشی حرفه‌ای هستید. لطفاً یک بازی HTML کامل، تعاملی و جذاب با مشخصات زیر طراحی کنید. این بازی باید **کاملاً بر اساس ساختار و منطق کد نمونه‌ای که در ادامه ارائه می‌شود** ساخته شود.

═══════════════════════════════════════════════════════════════════
📋 مشخصات بازی
═══════════════════════════════════════════════════════════════════
• درس: ${wizardData.subject}
• مقطع: ${wizardData.grade}
• موضوع: ${wizardData.topic}
• نوع بازی: ${wizardData.gameType}
• سطح سختی: ${wizardData.difficulty}
• مدت زمان هدف: ${durationMinutes} دقیقه
• حداقل سوالات: 15 سوال متنوع

═══════════════════════════════════════════════════════════════════
🔗 نقطه اتصال حیاتی (بر اساس کد نمونه)
═══════════════════════════════════════════════════════════════════
بازی شما باید دقیقاً از این الگو برای اتصال به سیستم ما پیروی کند.

1.  **دریافت شناسه بازی (الزامی):**
    \`\`\`javascript
    const urlParams = new URLSearchParams(window.location.search);
    const GAME_ID = parseInt(urlParams.get('game_id')) || 1;
    window.GAME_ID = GAME_ID;
    console.log('🎮 [بازی] بازی با شناسه مقداردهی اولیه شد:', GAME_ID);
    \`\`\`

2.  **تابع پایان بازی و ارسال نتیجه (حیاتی):**
    این تابع فقط و فقط زمانی فراخوانی می‌شود که کاربر روی دکمه پایان کلیک کند. این تابع مسئول محاسبه مقادیر نهایی و ارسال آن به صفحه اصلی است.

    \`\`\`javascript
    function endGame() {
        console.log('🏁 [بازی] بازی در حال پایان است.');
        gameState.isActive = false;
        if (gameState.timerInterval) {
            clearInterval(gameState.timerInterval);
        }
        finishButton.classList.add('hidden'); // مخفی کردن دکمه پایان
        
        // محاسبه مقادیر نهایی
        const finalScore = gameState.score;
        const finalTimeSpent = gameState.timeElapsed;
        const finalAccuracy = gameState.totalQuestions > 0 
            ? Math.round((gameState.correctAnswers / gameState.totalQuestions) * 100) 
            : 0;

        // 🔥 ساخت شیء داده برای ارسال به صفحه اصلی
        const resultData = {
            game_id: window.GAME_ID,
            score: finalScore,
            time_spent: finalTimeSpent,
            accuracy: finalAccuracy
        };

        console.log('📦 [بازی] شیء داده برای ارسال به پوسته:', resultData);

        // ارسال داده‌ها به تابع onGameComplete در پوسته
        if (typeof window.onGameComplete === 'function') {
            try {
                window.onGameComplete(resultData);
                console.log('✅ [بازی] داده‌ها با موفقیت به پوسته ارسال شد.');
            } catch (error) {
                console.error('❌ [بازی] خطا در فراخوانی onGameComplete:', error);
            }
        } else {
            console.error('❌ [بازی] تابع onGameComplete در پوسته یافت نشد!');
        }
    }
    \`\`\`

═══════════════════════════════════════════════════════════════════
🔥 منطق پایان بازی (قانون حیاتی - کپی شده از کد نمونه)
═══════════════════════════════════════════════════════════════════
این مهم‌ترین بخش منطق بازی است. **باید دقیقاً به این شکل پیاده‌سازی شود.**

*   **قانون:** بازی پس از آخرین سوال به طور خودکار تمام نمی‌شود. تابع \`endGame\` فراخوانی **نشود**.
*   **نحوه اجرا:** این منطق در تابع \`checkAnswer\` پیاده‌سازی می‌شود.

**مثال دقیق از کد نمونه برای تابع \`checkAnswer\`:**
\`\`\`javascript
function checkAnswer(selectedAnswer, buttonElement) {
    // ... منطق بررسی پاسخ و نمایش بازخورد ...
    updateDisplay();
    
    setTimeout(() => {
        // ⚠️ این بخش بسیار مهم است. باید دقیقاً کپی شود.
        if (gameState.totalQuestions >= gameState.maxQuestions) {
            // ۱. تایمر را متوقف کن
            clearInterval(gameState.timerInterval);
            console.log('⏹️ تایمر متوقف شد. منتظر ثبت نتیجه توسط کاربر...');
            // ۲. بازی تمام نشده! سوال جدیدی تولید نکن و برگرد.
            // ۳. دکمه "پایان بازی" هنوز فعال است تا کاربر روی آن کلیک کند.
            return; 
        }

        // اگر بازی تمام نشده باشد، سوال بعدی را تولید کن
        if (gameState.isActive) {
            generateQuestion();
        }
    }, 2000); // 2 ثانیه تاخیر برای نمایش بازخورد
}
\`\`\`

**کد HTML دکمه پایان (بسیار مهم):**
\`\`\`html
<!-- این دکمه باید همیشه در صفحه بازی وجود داشته باشد -->
<button id="finishButton" class="finish-button" onclick="endGame()">🏁 پایان بازی و ثبت نتیجه</button>
\`\`\`

═══════════════════════════════════════════════════════════════════
⚠️ قوانین حیاتی برای جلوگیری از خطا (بسیار مهم)
═══════════════════════════════════════════════════════════════════
برای جلوگیری از خطای "undefined" در ارسال نتیجه، **باید دقیقاً از این الگو پیروی کنید.**

1.  **تابع \`endGame\` فقط توسط دکمه فراخوانی شود:** در هیچ جای کد، به جز در \`onclick\` دکمه پایان، تابع \`endGame()\` را فراخوانی نکنید.

2.  **ساخت شیء \`resultData\` در ابتدای تابع \`endGame\`:**
    *   در ابتدای تابع \`endGame\`، **قبل از هر کد دیگری**، مقادیر نهایی را محاسبه و شیء \`resultData\` را بسازید.
    *   **هرگز** تابع \`window.onGameComplete\` را بدون آرگومان یا با آرگومان \`undefined\` فراخوانی نکنید.

3.  **کد نهایی تابع \`endGame\` باید دقیقاً به این شکل باشد:**
    \`\`\`javascript
    function endGame() {
        console.log('🏁 [بازی] بازی در حال پایان است.');
        gameState.isActive = false;
        if (gameState.timerInterval) {
            clearInterval(gameState.timerInterval);
        }
        finishButton.classList.add('hidden');
        
        // ⭐ مرحله ۱: محاسبه و ساخت شیء داده (بسیار مهم)
        const finalScore = gameState.score;
        const finalTimeSpent = gameState.timeElapsed;
        const finalAccuracy = gameState.totalQuestions > 0 
            ? Math.round((gameState.correctAnswers / gameState.totalQuestions) * 100) 
            : 0;

        const resultData = {
            game_id: window.GAME_ID,
            score: finalScore,
            time_spent: finalTimeSpent,
            accuracy: finalAccuracy
        };
        
        // ⭐ مرحله ۲: لاگ گرفtings برای اطمینان
        console.log('📦 [بازی] شیء داده برای ارسال به پوسته:', resultData);

        // ⭐ مرحله ۳: فراخوانی با آرگومان صحیح
        if (typeof window.onGameComplete === 'function') {
            try {
                window.onGameComplete(resultData); // حتماً با resultData فراخوانی شود
                console.log('✅ [بازی] داده‌ها با موفقیت به پوسته ارسال شد.');
            } catch (error) {
                console.error('❌ [بازی] خطا در فراخوانی onGameComplete:', error);
            }
        } else {
            console.error('❌ [بازی] تابع onGameComplete در پوسته یافت نشد!');
        }
    }
    \`\`\`

═══════════════════════════════════════════════════════════════════
🎨 الزامات فنی و ساختار (بر اساس کد نمونه)
═══════════════════════════════════════════════════════════════════

1.  **ساختار HTML:** از ساختار کد نمونه پیروی کنید.
    *   یک \`div.game-wrapper\` اصلی.
    *   یک \`div.game-header\`.
    *   یک \`div.game-content\`.
    *   داخل \`game-content\`: یک \`div.status-bar\`، یک \`div.intro-screen\` و یک \`div.game-screen\`.
2.  **متغیرهای gameState:** از ساختار زیر استفاده کنید.
    \`\`\`javascript
    let gameState = {
        score: 0, correctAnswers: 0, totalQuestions: 0, maxQuestions: 15,
        startTime: null, timeElapsed: 0, isActive: false,
        timerInterval: null, currentQuestion: null, usedQuestions: []
    };
    \`\`\`
3.  **داده‌های بازی:** یک آرایه مناسب برای موضوع بازی ایجاد کنید (مثلاً \`fractionsData\` برای کسرها، \`wordsData\` برای کلمات و غیره).
4.  **امتیازدهی:** +10 برای صحیح، -5 برای غلط (امتیاز منفی نباشد).
5.  **نمایش سوالات:** برای نمایش محتوای پیچیده مانند کسرها، از تابع کمکی HTML استفاده کنید:
    \`\`\`javascript
    function createFractionHTML(fraction) {
        return \`<span class="fraction">
                    <span class="fraction-numerator">\${fraction.numerator}</span>
                    <span class="fraction-denominator">\${fraction.denominator}</span>
                </span>\`;
    }
    \`\`\`

═══════════════════════════════════════════════════════════════════
🎨 الزامات طراحی UI/UX (مشابه کد نمونه)
═══════════════════════════════════════════════════════════════════
طراحی باید کودک‌پسند، مدرن و جذاب باشد.

1.  **صفحه‌بندی:** \`max-width: 700px\`, \`max-height: 95vh\`, انیمیشن \`float\`.
2.  **فونت:** حتماً از \`Vazirmatn\` استفاده کنید.
3.  **صفحه معرفی:** با ایموجی متحرک \`bounce\` و دکمه شروع.
4.  **نوار وضعیت:** نمایش امتیاز، زمان، دقت و شمارنده سوال.
5.  **انیمیشن‌ها:** \`scaleUp\` برای پاسخ صحیح، \`shake\` برای پاسخ غلط.
6.  **دکمه پایان:** گرادینت سبز، وسط‌چین، با متن "🏁 پایان بازی و ثبت نتیجه".
7.  **استایل کسرها:** برای نمایش کسرها از استایل زیر استفاده کنید:
    \`\`\`css
    .fraction {
        display: inline-block;
        text-align: center;
        vertical-align: middle;
        margin: 0 5px;
        font-size: 1.2em;
    }
    .fraction-numerator {
        border-bottom: 1px solid #495057;
        padding: 0 5px;
    }
    .fraction-denominator {
        padding: 0 5px;
    }
    \`\`\`

═══════════════════════════════════════════════════════════════════
✅ چک‌لیست نهایی (همه باید رعایت شود)
═══════════════════════════════════════════════════════════════════
□ ساختار HTML و CSS مشابه کد نمونه است.
□ game_id از URL دریافت و در window.GAME_ID ذخیره می‌شود.
□ تابع endGame فقط با کلیک دکمه فراخوانی می‌شود.
□ 🔥 در تابع checkAnswer، پس از آخرین سوال، تایمر متوقف و سوال جدیدی تولید نمی‌شود.
□ ⚠️ در تابع endGame، شیء resultData قبل از هر چیز دیگری ساخته می‌شود و با آرگومان صحیح به window.onGameComplete ارسال می‌گردد.
□ شیء resultData با کلیدهای game_id, score, time_spent, accuracy ساخته می‌شود.
□ resultData با window.onGameComplete ارسال می‌شود.
□ حداقل 15 سوال متنوع بر اساس موضوع ${wizardData.topic} دارد.
□ برای نمایش محتوای پیچیده مانند کسرها، از تابع کمکی HTML استفاده شده است.
□ استایل‌های CSS برای نمایش محتوای پیچیده مانند کسرها پیاده‌سازی شده است.

═══════════════════════════════════════════════════════════════════
🎯 خروجی مورد انتظار
═══════════════════════════════════════════════════════════════════
لطفاً خروجی را به این صورت ارائه دهید:

1.  **کد HTML کامل:** آماده کپی و اجرا.
2.  **اسم بازی:** یک نام جذاب و کوتاه.
3.  **توضیح یک خطی:** توضیح مختصر درباره بازی.
4.  **راهنما:** راهنمای مختصر برای بازی کردن.

 ${wizardData.notes ? `\n📝 نکات اضافی:\n${wizardData.notes}` : ''}

لطفاً کد کامل و آماده اجرا ارائه دهید که بتوان مستقیماً در مرورگر اجرا کرد.`;
}

// کپی کردن پرامپت
function copyAdvancedPrompt() {
    const promptText = document.getElementById('finalPromptText');
    if (promptText) {
        promptText.select();
        document.execCommand('copy');
        
        // تغییر متن دکمه موقتی
        const copyBtn = document.querySelector('.copy-btn .copy-text');
        if (copyBtn) {
            const originalText = copyBtn.textContent;
            copyBtn.textContent = 'کپی شد!';
            
            setTimeout(() => {
                copyBtn.textContent = originalText;
            }, 2000);
        }
        
        showNotification('پرامپت کپی شد! 📋', 'success');
    }
}

// شروع مجدد جادوگر
function restartWizard() {
    if (confirm('آیا مطمئن هستید که می‌خواهید شروع مجدد کنید؟ تمام اطلاعات وارد شده حذف خواهد شد.')) {
        console.log('Restarting wizard...');
        
        // ریست داده‌ها
        wizardData = {
            subject: '',
            grade: '',
            topic: '',
            gameType: '',
            difficulty: '',
            duration: 120,
            notes: ''
        };
        
        // ریست مرحله
        currentStep = 1;
        updateStepDisplay();
        
        // پاک کردن انتخاب‌ها
        document.querySelectorAll('.selected').forEach(el => {
            el.classList.remove('selected');
        });
        
        // ریست فرم‌ها
        const topicInput = document.getElementById('promptTopic');
        const notesTextarea = document.getElementById('promptNotes');
        const durationSlider = document.getElementById('durationSlider');
        const finalPromptText = document.getElementById('finalPromptText');
        
        if (topicInput) topicInput.value = '';
        if (notesTextarea) notesTextarea.value = '';
        if (durationSlider) {
            durationSlider.value = 120;
            updateDuration(120);
        }
        if (finalPromptText) finalPromptText.value = '';
        
        // غیرفعال کردن دکمه‌های بعدی
        document.querySelectorAll('.next-btn').forEach(btn => {
            btn.disabled = true;
            btn.style.background = 'rgba(255,255,255,0.1)';
        });
        
        showNotification('جادوگر ریست شد! شروع مجدد کنید 🔄', 'info');
        console.log('Wizard restarted successfully');
    }
}

// اطمینان از آماده بودن DOM قبل از راه‌اندازی
document.addEventListener('DOMContentLoaded', function() {
    // تاخیر کوتاه برای اطمینان از بارگذاری کامل
    setTimeout(() => {
        if (document.getElementById('prompt-generator')) {
            initializePromptWizard();
        }
    }, 100);
});
    
    
    // =================== جاوا اسکریپت‌های مدیریت دسته‌بندی‌ها ===================

// متغیرهای سراسری دسته‌بندی‌ها
let categoriesData = [];
let filteredCategories = [];

// راه‌اندازی مدیریت دسته‌بندی‌ها
function initializeCategoriesManagement() {
    console.log('Initializing Categories Management...');
    
    // بارگذاری اولیه دسته‌بندی‌ها
    loadCategories();
    
    // راه‌اندازی فرم‌ها
    initializeCategoryForms();
    
    console.log('Categories Management initialized successfully');
}

// بارگذاری دسته‌بندی‌ها
function loadCategories() {
    showLoading();
    
    fetch('../ajax/load_categories.php')
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                categoriesData = data.categories;
                filteredCategories = [...categoriesData];
                updateCategoriesDisplay();
                updateCategoriesStats(data.stats);
            } else {
                console.error('خطا در بارگیری دسته‌بندی‌ها:', data.message);
                showNotification('خطا در بارگیری دسته‌بندی‌ها: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا در ارتباط با سرور:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
}

// بروزرسانی نمایش دسته‌بندی‌ها
function updateCategoriesDisplay() {
    updateCategoriesTable();
    updateCategoriesCards();
    updateCategoriesCount();
}

// بروزرسانی جدول دسته‌بندی‌ها
function updateCategoriesTable() {
    const tbody = document.getElementById('categoriesTableBody');
    if (!tbody) return;

    if (filteredCategories.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.7);">هیچ دسته‌بندی‌ای یافت نشد</td></tr>';
        return;
    }

    tbody.innerHTML = filteredCategories.map(category => `
        <tr>
            <td>${category.id}</td>
            <td><strong>${escapeHtml(category.name)}</strong></td>
            <td>
                <div class="category-icon" style="background-color: ${category.color}20; color: ${category.color};">
                    ${category.icon || '📁'}
                </div>
            </td>
            <td>
                <div class="category-color" style="background-color: ${category.color}" data-color="${category.color}"></div>
            </td>
            <td>${category.games_count || 0}</td>
            <td>
                <span class="category-status-${category.is_active ? 'active' : 'inactive'}">
                    ${category.is_active ? 'فعال' : 'غیرفعال'}
                </span>
            </td>
            <td>${formatDate(category.created_at)}</td>
            <td class="category-actions">
                <button onclick="editCategory(${category.id})" title="ویرایش" class="edit-category-btn">✏️</button>
                <button onclick="toggleCategoryStatus(${category.id}, ${category.is_active})" title="${category.is_active ? 'غیرفعال کردن' : 'فعال کردن'}" class="toggle-category-btn">
                    ${category.is_active ? '🔴' : '🟢'}
                </button>
                <button onclick="deleteCategory(${category.id})" title="حذف" class="delete-category-btn">🗑️</button>
            </td>
        </tr>
    `).join('');
}

// بروزرسانی کارت‌های موبایل
function updateCategoriesCards() {
    const container = document.getElementById('categoriesCards');
    if (!container) return;

    if (filteredCategories.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.7);">هیچ دسته‌بندی‌ای یافت نشد</div>';
        return;
    }

    container.innerHTML = filteredCategories.map(category => `
        <div class="category-card-mobile">
            <div class="card-header">
                <div class="category-name">${escapeHtml(category.name)}</div>
                <div class="category-icon" style="background-color: ${category.color}20; color: ${category.color};">
                    ${category.icon || '📁'}
                </div>
            </div>
            <div class="card-info">
                <div class="info-item">
                    <div class="info-label">شناسه</div>
                    <div class="info-value">${category.id}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">تعداد بازی</div>
                    <div class="info-value">${category.games_count || 0}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">رنگ</div>
                    <div class="info-value">
                        <div class="category-color" style="background-color: ${category.color}"></div>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">وضعیت</div>
                    <div class="info-value">
                        <span class="category-status-${category.is_active ? 'active' : 'inactive'}">
                            ${category.is_active ? 'فعال' : 'غیرفعال'}
                        </span>
                    </div>
                </div>
            </div>
            <div class="card-actions">
                <button onclick="editCategory(${category.id})" class="action-btn-mobile edit">✏️ ویرایش</button>
                <button onclick="toggleCategoryStatus(${category.id}, ${category.is_active})" class="action-btn-mobile toggle">
                    ${category.is_active ? '🔴 غیرفعال' : '🟢 فعال'}
                </button>
                <button onclick="deleteCategory(${category.id})" class="action-btn-mobile delete">🗑️ حذف</button>
            </div>
        </div>
    `).join('');
}

// بروزرسانی تعداد دسته‌بندی‌ها
function updateCategoriesCount() {
    const countElement = document.getElementById('categoriesCount');
    if (countElement) {
        countElement.textContent = `${filteredCategories.length} دسته‌بندی`;
    }
}

// بروزرسانی آمار دسته‌بندی‌ها
function updateCategoriesStats(stats) {
    document.getElementById('totalCategories').textContent = stats.total || 0;
    document.getElementById('activeCategories').textContent = stats.active || 0;
    document.getElementById('inactiveCategories').textContent = stats.inactive || 0;
    document.getElementById('totalGamesInCategories').textContent = stats.total_games || 0;
}

// فیلتر کردن دسته‌بندی‌ها
function filterCategories() {
    const searchTerm = document.getElementById('categorySearch').value.toLowerCase();
    const statusFilter = document.getElementById('categoryStatusFilter').value;
    
    filteredCategories = categoriesData.filter(category => {
        const matchesSearch = category.name.toLowerCase().includes(searchTerm);
        const matchesStatus = statusFilter === '' || category.is_active == statusFilter;
        
        return matchesSearch && matchesStatus;
    });
    
    updateCategoriesDisplay();
}

// مرتب‌سازی دسته‌بندی‌ها
function sortCategories() {
    const sortValue = document.getElementById('categorySortFilter').value;
    
    filteredCategories.sort((a, b) => {
        switch (sortValue) {
            case 'name_asc':
                return a.name.localeCompare(b.name, 'fa');
            case 'name_desc':
                return b.name.localeCompare(a.name, 'fa');
            case 'created_desc':
                return new Date(b.created_at) - new Date(a.created_at);
            case 'created_asc':
                return new Date(a.created_at) - new Date(b.created_at);
            case 'games_desc':
                return (b.games_count || 0) - (a.games_count || 0);
            default:
                return 0;
        }
    });
    
    updateCategoriesDisplay();
}

// پاک کردن فیلترها
function clearCategoryFilters() {
    document.getElementById('categorySearch').value = '';
    document.getElementById('categoryStatusFilter').value = '';
    document.getElementById('categorySortFilter').value = 'name_asc';
    
    filteredCategories = [...categoriesData];
    updateCategoriesDisplay();
    
    showNotification('فیلترها پاک شدند', 'info');
}

// نمایش مودال افزودن دسته‌بندی
function showAddCategoryModal() {
    document.getElementById('addCategoryModal').classList.add('show');
    document.body.style.overflow = 'hidden';
}

// بستن مودال افزودن دسته‌بندی
function closeAddCategoryModal() {
    document.getElementById('addCategoryModal').classList.remove('show');
    document.body.style.overflow = 'auto';
    document.getElementById('addCategoryForm').reset();
    
    // بازنشانی انتخاب آیکون
    document.querySelectorAll('#addCategoryModal .icon-option.selected').forEach(icon => {
        icon.classList.remove('selected');
    });
}

// انتخاب آیکون در فرم افزودن
function selectIcon(icon) {
    document.getElementById('categoryIcon').value = icon;
    
    // بروزرسانی انتخاب بصری
    document.querySelectorAll('#addCategoryModal .icon-option').forEach(option => {
        option.classList.remove('selected');
    });
    event.target.classList.add('selected');
}

// انتخاب رنگ در فرم افزودن
function selectColor(color) {
    document.querySelector('#addCategoryModal input[name="color"]').value = color;
}

// ویرایش دسته‌بندی
function editCategory(categoryId) {
    const category = categoriesData.find(c => c.id === categoryId);
    if (!category) {
        showNotification('دسته‌بندی یافت نشد', 'error');
        return;
    }
    
    // پر کردن فرم ویرایش
    document.getElementById('editCategoryId').value = category.id;
    document.getElementById('editCategoryName').value = category.name;
    document.getElementById('editCategoryIcon').value = category.icon || '';
    document.getElementById('editCategoryColor').value = category.color || '#4d9de0';
    document.getElementById('editCategoryActive').checked = category.is_active == 1;
    
    // نمایش مودال
    document.getElementById('editCategoryModal').classList.add('show');
    document.body.style.overflow = 'hidden';
}

// بستن مودال ویرایش
function closeEditCategoryModal() {
    document.getElementById('editCategoryModal').classList.remove('show');
    document.body.style.overflow = 'auto';
    document.getElementById('editCategoryForm').reset();
    
    // بازنشانی انتخاب آیکون
    document.querySelectorAll('#editCategoryModal .icon-option.selected').forEach(icon => {
        icon.classList.remove('selected');
    });
}

// انتخاب آیکون در فرم ویرایش
function selectEditIcon(icon) {
    document.getElementById('editCategoryIcon').value = icon;
    
    // بروزرسانی انتخاب بصری
    document.querySelectorAll('#editCategoryModal .icon-option').forEach(option => {
        option.classList.remove('selected');
    });
    event.target.classList.add('selected');
}

// انتخاب رنگ در فرم ویرایش
function selectEditColor(color) {
    document.getElementById('editCategoryColor').value = color;
}

// تغییر وضعیت دسته‌بندی
function toggleCategoryStatus(categoryId, currentStatus) {
    const action = currentStatus ? 'غیرفعال' : 'فعال';
    
    if (confirm(`آیا مطمئن هستید که می‌خواهید این دسته‌بندی را ${action} کنید؟`)) {
        showLoading();
        
        fetch('../ajax/toggle_category_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ category_id: categoryId })
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                loadCategories(); // بارگذاری مجدد
                showNotification(`دسته‌بندی با موفقیت ${action} شد`, 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    }
}

// حذف دسته‌بندی
function deleteCategory(categoryId) {
    const category = categoriesData.find(c => c.id === categoryId);
    if (!category) return;
    
    if (confirm(`آیا مطمئن هستید که می‌خواهید دسته‌بندی "${category.name}" را حذف کنید؟\n\nتوجه: در صورت وجود بازی در این دسته‌بندی، امکان حذف وجود ندارد.`)) {
        showLoading();
        
        fetch('../ajax/delete_category.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ category_id: categoryId })
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                loadCategories(); // بارگذاری مجدد
                showNotification('دسته‌بندی با موفقیت حذف شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    }
}

// راه‌اندازی فرم‌های دسته‌بندی
function initializeCategoryForms() {
    // فرم افزودن دسته‌بندی
    document.getElementById('addCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // بررسی فیلدهای الزامی
        const name = formData.get('name');
        if (!name || !name.trim()) {
            showNotification('نام دسته‌بندی الزامی است', 'error');
            return;
        }
        
        showLoading();
        
        fetch('../ajax/add_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                closeAddCategoryModal();
                loadCategories();
                showNotification('دسته‌بندی با موفقیت اضافه شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    });
    
    // فرم ویرایش دسته‌بندی
    document.getElementById('editCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // بررسی فیلدهای الزامی
        const name = formData.get('name');
        if (!name || !name.trim()) {
            showNotification('نام دسته‌بندی الزامی است', 'error');
            return;
        }
        
        showLoading();
        
        fetch('../ajax/edit_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                closeEditCategoryModal();
                loadCategories();
                showNotification('دسته‌بندی با موفقیت بروزرسانی شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    });
}

// تابع کمکی برای escape کردن HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

// بستن مودال‌ها با کلید Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.category-modal.show').forEach(modal => {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        });
    }
});

// اضافه کردن رویدادها به راه‌اندازی اصلی
document.addEventListener('DOMContentLoaded', function() {
    // اگر تب دسته‌بندی‌ها فعال است، مدیریت دسته‌بندی‌ها را راه‌اندازی کن
    setTimeout(() => {
        if (document.getElementById('categories')) {
            initializeCategoriesManagement();
        }
    }, 100);
});

// =================== اتصال همه بخش‌ها به جدول دسته‌بندی‌ها ===================

// متغیر سراسری برای ذخیره دسته‌بندی‌های فعال
let activeCategories = [];

// بارگذاری دسته‌بندی‌های فعال از دیتابیس
function loadActiveCategories() {
    return fetch('../ajax/load_active_categories.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                activeCategories = data.categories;
                updateAllCategorySelectors();
                return data.categories;
            } else {
                console.error('خطا در بارگیری دسته‌بندی‌ها:', data.message);
                return [];
            }
        })
        .catch(error => {
            console.error('خطا در ارتباط با سرور:', error);
            return [];
        });
}

// بروزرسانی همه انتخابگرهای دسته‌بندی
function updateAllCategorySelectors() {
    // 1. فرم افزودن بازی
    updateCategorySelector('select[name="category_id"]', true);
    
    // 2. فرم ویرایش بازی  
    updateCategorySelector('select[name="category_id"]', true);
    
    // 3. فیلتر مدیریت بازی‌ها
    updateCategorySelector('#filterGameSubject', false);
    
    // 4. پرامپت‌ساز - کارت‌های انتخاب درس
    updatePromptSubjectCards();
    
    console.log('همه انتخابگرهای دسته‌بندی بروزرسانی شدند');
}

// بروزرسانی انتخابگر خاص
function updateCategorySelector(selector, isRequired = false) {
    const selectors = document.querySelectorAll(selector);
    
    selectors.forEach(select => {
        if (!select) return;
        
        // ذخیره مقدار فعلی
        const currentValue = select.value;
        
        // پاک کردن گزینه‌های قبلی (جز گزینه اول)
        const firstOption = select.querySelector('option:first-child');
        select.innerHTML = '';
        
        // اضافه کردن گزینه اول
        if (firstOption) {
            select.appendChild(firstOption);
        } else if (!isRequired) {
            select.innerHTML = '<option value="">همه دروس</option>';
        } else {
            select.innerHTML = '<option value="">انتخاب کنید</option>';
        }
        
        // اضافه کردن دسته‌بندی‌های فعال
        activeCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            
            // اضافه کردن آیکون (اختیاری)
            if (category.icon) {
                option.textContent = `${category.icon} ${category.name}`;
            }
            
            select.appendChild(option);
        });
        
        // بازنشانی مقدار قبلی (اگر هنوز موجود باشد)
        if (currentValue) {
            select.value = currentValue;
        }
    });
}

// بروزرسانی کارت‌های انتخاب درس در پرامپت‌ساز
function updatePromptSubjectCards() {
    const subjectGrid = document.querySelector('.subject-grid');
    if (!subjectGrid) return;
    
    // پاک کردن کارت‌های قبلی
    subjectGrid.innerHTML = '';
    
    // اضافه کردن کارت‌های جدید بر اساس دیتابیس
    activeCategories.forEach(category => {
        const card = document.createElement('div');
        card.className = 'subject-card';
        card.setAttribute('data-subject', category.name);
        
        // تعیین آیکون (اگر موجود نباشد از آیکون پیش‌فرض استفاده کن)
        const icon = category.icon || getDefaultSubjectIcon(category.name);
        
        card.innerHTML = `
            <div class="subject-icon">${icon}</div>
            <div class="subject-name">${category.name}</div>
        `;
        
        // اضافه کردن رویداد کلیک
        card.addEventListener('click', function() {
            selectSubject(category.name);
        });
        
        subjectGrid.appendChild(card);
    });
}

// تابع کمکی برای آیکون‌های پیش‌فرض
function getDefaultSubjectIcon(categoryName) {
    const iconMap = {
        'ریاضی': '🔢',
        'فارسی': '📖', 
        'علوم': '🔬',
        'اجتماعی': '🌍',
        'مطالعات اجتماعی': '🌍',
        'دینی': '☪️',
        'دینی و اخلاق': '☪️',
        'انگلیسی': '🇬🇧',
        'هنر': '🎨',
        'موسیقی': '🎵',
        'ورزش': '⚽',
        'کامپیوتر': '💻',
        'تاریخ': '🏛️',
        'حساب': '🧮'
    };
    
    // جستجوی تطبیقی برای پیدا کردن آیکون مناسب
    for (const [key, icon] of Object.entries(iconMap)) {
        if (categoryName.includes(key)) {
            return icon;
        }
    }
    
    return '📚'; // آیکون پیش‌فرض
}

// بروزرسانی همه فرم‌ها هنگام تغییر دسته‌بندی‌ها
function refreshCategoriesInAllForms() {
    console.log('بروزرسانی دسته‌بندی‌ها در همه فرم‌ها...');
    loadActiveCategories().then(() => {
        showNotification('دسته‌بندی‌ها در همه فرم‌ها بروزرسانی شدند', 'success');
    });
}

// تابع برای بروزرسانی دسته‌بندی‌ها هنگام تغییر در تب مدیریت دسته‌بندی‌ها
function onCategoryChanged() {
    // این تابع هنگام افزودن، ویرایش یا حذف دسته‌بندی فراخوانی می‌شود
    refreshCategoriesInAllForms();
}

// بروزرسانی تابع موجود برای نمایش تب بازی‌ها
function showGameTab(tabId) {
    console.log('Switching to tab:', tabId);
    
    // مخفی کردن همه تب‌ها
    document.querySelectorAll('.games-tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // غیرفعال کردن همه دکمه‌های تب
    document.querySelectorAll('.games-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // نمایش تب انتخاب‌شده
    const activeTab = document.getElementById(tabId);
    if (activeTab) {
        activeTab.classList.add('active');
    }
    
    // فعال کردن دکمه تب
    if (event && event.target) {
        event.target.classList.add('active');
    }
    
    // بارگذاری محتوای خاص تب (در صورت نیاز)
    if (tabId === 'games-list') {
        loadGamesList();
    } else if (tabId === 'results-management') {
        loadResultsData();
    } else if (tabId === 'categories') {
        initializeCategoriesManagement();
    } else if (tabId === 'prompt-generator') {
        // بروزرسانی کارت‌های درس در پرامپت‌ساز
        updatePromptSubjectCards();
    }
}

// بروزرسانی توابع مدیریت دسته‌بندی‌ها برای فراخوانی onCategoryChanged
function initializeCategoryFormsWithRefresh() {
    // فرم افزودن دسته‌بندی
    document.getElementById('addCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // بررسی فیلدهای الزامی
        const name = formData.get('name');
        if (!name || !name.trim()) {
            showNotification('نام دسته‌بندی الزامی است', 'error');
            return;
        }
        
        showLoading();
        
        fetch('../ajax/add_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                closeAddCategoryModal();
                loadCategories();
                onCategoryChanged(); // بروزرسانی همه فرم‌ها
                showNotification('دسته‌بندی با موفقیت اضافه شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    });
    
    // فرم ویرایش دسته‌بندی
    document.getElementById('editCategoryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        // بررسی فیلدهای الزامی
        const name = formData.get('name');
        if (!name || !name.trim()) {
            showNotification('نام دسته‌بندی الزامی است', 'error');
            return;
        }
        
        showLoading();
        
        fetch('../ajax/edit_category.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                closeEditCategoryModal();
                loadCategories();
                onCategoryChanged(); // بروزرسانی همه فرم‌ها
                showNotification('دسته‌بندی با موفقیت بروزرسانی شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    });
}

// بروزرسانی تابع toggle وضعیت دسته‌بندی
function toggleCategoryStatus(categoryId, currentStatus) {
    const action = currentStatus ? 'غیرفعال' : 'فعال';
    
    if (confirm(`آیا مطمئن هستید که می‌خواهید این دسته‌بندی را ${action} کنید؟`)) {
        showLoading();
        
        fetch('../ajax/toggle_category_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ category_id: categoryId })
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                loadCategories(); // بارگذاری مجدد
                onCategoryChanged(); // بروزرسانی همه فرم‌ها
                showNotification(`دسته‌بندی با موفقیت ${action} شد`, 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    }
}

// بروزرسانی تابع حذف دسته‌بندی  
function deleteCategory(categoryId) {
    const category = categoriesData.find(c => c.id === categoryId);
    if (!category) return;
    
    if (confirm(`آیا مطمئن هستید که می‌خواهید دسته‌بندی "${category.name}" را حذف کنید؟\n\nتوجه: در صورت وجود بازی در این دسته‌بندی، امکان حذف وجود ندارد.`)) {
        showLoading();
        
        fetch('../ajax/delete_category.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ category_id: categoryId })
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                loadCategories(); // بارگذاری مجدد
                onCategoryChanged(); // بروزرسانی همه فرم‌ها
                showNotification('دسته‌بندی با موفقیت حذف شد', 'success');
            } else {
                showNotification('خطا: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('خطا:', error);
            showNotification('خطا در ارتباط با سرور', 'error');
        });
    }
}

// راه‌اندازی اولیه هنگام بارگذاری صفحه
document.addEventListener('DOMContentLoaded', function() {
    // بارگذاری اولیه دسته‌بندی‌ها
    loadActiveCategories();
    
    // تنظیم رویدادها برای تب‌ها
    document.querySelectorAll('.games-tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('onclick').match(/showGameTab\('([^']+)'\)/)[1];
            if (tabId === 'prompt-generator') {
                // تاخیر کوتاه برای اطمینان از بارگذاری کامل تب
                setTimeout(() => {
                    updatePromptSubjectCards();
                }, 100);
            }
        });
    });
    
    console.log('اتصال دسته‌بندی‌ها به همه بخش‌ها تکمیل شد');
});
// بروزرسانی تابع موجود
function initializeCategoriesManagement() {
    console.log('Initializing Categories Management...');
    
    // بارگذاری اولیه دسته‌بندی‌ها
    loadCategories();
    
    // راه‌اندازی فرم‌ها با قابلیت بروزرسانی
    initializeCategoryFormsWithRefresh();
    
    console.log('Categories Management initialized successfully');
}

// =================== ماژول تحلیل نتایج (نسخه کامل با همه عملکردها) ===================

const ResultsAnalysis = {
    // متغیرهای داخلی
    data: {
        results: [],
        filteredResults: [],
        currentPage: 1,
        totalPages: 1,
        resultsPerPage: 25,
        charts: {},
        currentStudentId: null,
        filters: {
            student_id: '',
            game_id: '',
            category_id: '',
            date_from: '',
            date_to: '',
            min_score: '',
            max_score: '',
            sort: 'date_desc'
        }
    },

    // راه‌اندازی اولیه
    init: function() {
        console.log('Initializing Results Analysis Module...');
        
        // راه‌اندازی رویدادها
        this.setupEventListeners();
        
        // ایجاد مودال‌ها
        this.createModals();
        
        // بارگذاری اولیه داده‌ها
        this.loadData();
        
        // بارگذاری فیلترها
        this.loadFilters();
        
        console.log('Results Analysis Module initialized successfully');
    },

  // ایجاد مودال‌ها (نسخه کاملاً اصلاح شده)
createModals: function() {
    // مودال جزئیات دانش‌آموز
    const studentModal = document.createElement('div');
    studentModal.id = 'studentDetailsModal';
    studentModal.className = 'analysis-modal';
    studentModal.innerHTML = `
        <div class="modal-backdrop" onclick="ResultsAnalysis.closeStudentModal()"></div>
        <div class="modal-container large">
            <div class="modal-header">
                <h3>📊 تحلیل جامع عملکرد دانش‌آموز</h3>
                <div class="modal-header-actions">
                    <button class="modal-action-btn print-btn" onclick="ResultsAnalysis.printStudentReport()" title="چاپ گزارش">
                        🖨️
                    </button>
                    <button class="modal-close" onclick="ResultsAnalysis.closeStudentModal()">×</button>
                </div>
            </div>
            <div class="modal-body">
                <div class="student-full-info">
                    <div class="student-profile">
                        <div class="student-avatar-large" id="studentAvatarLarge">👤</div>
                        <div class="student-details">
                            <h4 id="studentFullName">نام دانش‌آموز</h4>
                            <p id="studentInfo">کلاس: -- | کد ملی: --</p>
                            <div class="student-rank-display">
                                رتبه: <span id="studentRankDisplay">#--</span>
                            </div>
                        </div>
                    </div>
                    <div class="student-quick-stats">
                        <div class="quick-stat">
                            <span class="stat-number" id="studentTotalGames">0</span>
                            <span class="stat-label">کل بازی‌ها</span>
                        </div>
                        <div class="quick-stat">
                            <span class="stat-number" id="studentAvgScoreDisplay">0</span>
                            <span class="stat-label">میانگین امتیاز</span>
                        </div>
                        <div class="quick-stat">
                            <span class="stat-number" id="studentBestScoreDisplay">0</span>
                            <span class="stat-label">بهترین امتیاز</span>
                        </div>
                        <div class="quick-stat">
                            <span class="stat-number" id="studentAvgAccuracyDisplay">0%</span>
                            <span class="stat-label">میانگین دقت</span>
                        </div>
                    </div>
                </div>
                
                <div class="student-performance-chart">
                    <h5>📈 نمودار پیشرفت دانش‌آموز</h5>
                    <div class="chart-placeholder">
                        <canvas id="studentChart" width="600" height="200"></canvas>
                    </div>
                </div>
                
                <div class="student-games-history">
                    <h5>📋 تاریخچه بازی‌ها</h5>
                    <div class="games-history-table">
                        <table class="history-table">
                            <thead>
                                <tr>
                                    <th>بازی</th>
                                    <th>دسته‌بندی</th>
                                    <th>امتیاز</th>
                                    <th>دقت</th>
                                    <th>زمان</th>
                                    <th>تاریخ</th>
                                </tr>
                            </thead>
                            <tbody id="studentGamesHistory">
                                <!-- داده‌ها اینجا پر می‌شود -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="ResultsAnalysis.closeStudentModal()">بستن</button>
                <button class="btn btn-primary" onclick="ResultsAnalysis.exportStudentReport()">📄 خروجی Excel</button>
                <button class="btn btn-success" onclick="ResultsAnalysis.printStudentReport()">🖨️ چاپ گزارش</button>
            </div>
        </div>
    `;
    document.body.appendChild(studentModal);

    // مودال ویرایش نتیجه
    const editModal = document.createElement('div');
    editModal.id = 'editResultModal';
    editModal.className = 'analysis-modal';
    editModal.innerHTML = `
        <div class="modal-backdrop" onclick="ResultsAnalysis.closeEditModal()"></div>
        <div class="modal-container">
            <div class="modal-header">
                <h3>✏️ ویرایش نتیجه بازی</h3>
                <button class="modal-close" onclick="ResultsAnalysis.closeEditModal()">×</button>
            </div>
            <div class="modal-body">
                <form id="editResultForm">
                    <input type="hidden" id="editResultId">
                    
                    <div class="form-section">
                        <h4>اطلاعات بازی</h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>دانش‌آموز:</label>
                                <input type="text" id="editStudentName" readonly class="readonly-input">
                            </div>
                            <div class="form-group">
                                <label>نام بازی:</label>
                                <input type="text" id="editGameTitle" readonly class="readonly-input">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h4>نتایج قابل ویرایش</h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>امتیاز (0-100): <span class="required">*</span></label>
                                <input type="number" id="editScore" min="0" max="100" required class="editable-input">
                            </div>
                            <div class="form-group">
                                <label>دقت (%): <span class="required">*</span></label>
                                <input type="number" id="editAccuracy" min="0" max="100" step="0.1" required class="editable-input">
                            </div>
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>زمان صرف شده (ثانیه): <span class="required">*</span></label>
                                <input type="number" id="editTimeSpent" min="1" required class="editable-input">
                            </div>
                            <div class="form-group">
                                <label>تعداد تلاش:</label>
                                <input type="number" id="editAttempts" min="1" value="1" class="editable-input">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="ResultsAnalysis.closeEditModal()">لغو</button>
                <button class="btn btn-primary" onclick="ResultsAnalysis.saveEditResult()">💾 ذخیره تغییرات</button>
            </div>
        </div>
    `;
    document.body.appendChild(editModal);
},

// تابع چاپ گزارش دانش‌آموز
printStudentReport: function() {
    if (!this.data.currentStudentId) {
        showNotification('ابتدا دانش‌آموز را انتخاب کنید', 'error');
        return;
    }
    
    console.log('Printing student report...');
    showNotification('در حال آماده‌سازی گزارش برای چاپ...', 'info');
    
    const studentResults = this.data.results.filter(r => r.student_id == this.data.currentStudentId);
    const studentInfo = studentResults[0];
    
    if (!studentInfo) {
        showNotification('اطلاعات دانش‌آموز یافت نشد', 'error');
        return;
    }
    
    // ایجاد صفحه چاپ
    const printWindow = window.open('', '_blank');
    const printContent = this.generateStudentPrintHTML(studentInfo, studentResults);
    
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
        showNotification('گزارش دانش‌آموز آماده چاپ شد!', 'success');
    }, 500);
},

// تولید HTML چاپ دانش‌آموز
generateStudentPrintHTML: function(studentInfo, allResults) {
    const totalGames = allResults.length;
    const avgScore = allResults.reduce((sum, r) => sum + r.score, 0) / totalGames;
    const bestScore = Math.max(...allResults.map(r => r.score));
    const avgAccuracy = allResults.reduce((sum, r) => sum + r.accuracy, 0) / totalGames;
    
    return `
    <!DOCTYPE html>
    <html dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>گزارش دانش‌آموز: ${studentInfo.student_name}</title>
        <style>
            body { 
                font-family: Tahoma, Arial; 
                direction: rtl; 
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 20px;
            }
            .header { 
                text-align: center; 
                margin-bottom: 3rem; 
                border-bottom: 3px solid #667eea;
                padding-bottom: 1rem;
            }
            .header h1 {
                color: #667eea;
                margin-bottom: 0.5rem;
            }
            .student-info { 
                background: #f8f9fa;
                padding: 2rem;
                border-radius: 10px;
                margin-bottom: 2rem;
                border: 1px solid #dee2e6;
            }
            .stats-grid { 
                display: grid; 
                grid-template-columns: repeat(4, 1fr); 
                gap: 1rem; 
                margin: 2rem 0; 
            }
            .stat-box { 
                border: 2px solid #667eea; 
                padding: 1.5rem; 
                text-align: center; 
                border-radius: 10px;
                background: linear-gradient(135deg, #667eea10, #764ba210);
            }
            .stat-number {
                font-size: 2rem;
                font-weight: bold;
                color: #667eea;
                display: block;
            }
            .stat-label {
                font-size: 0.9rem;
                color: #6c757d;
                margin-top: 0.5rem;
            }
            table { 
                width: 100%; 
                border-collapse: collapse; 
                margin: 2rem 0; 
                border: 1px solid #dee2e6;
            }
            th, td { 
                border: 1px solid #dee2e6; 
                padding: 12px; 
                text-align: right; 
            }
            th { 
                background: #667eea; 
                color: white;
                font-weight: bold;
            }
            tr:nth-child(even) {
                background: #f8f9fa;
            }
            .section-title {
                color: #667eea;
                border-bottom: 2px solid #667eea;
                padding-bottom: 0.5rem;
                margin: 2rem 0 1rem 0;
            }
            @media print { 
                .no-print { display: none; }
                body { margin: 0; }
                .header { page-break-after: avoid; }
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>گزارش تحلیل عملکرد دانش‌آموز</h1>
            <h2>${studentInfo.student_name}</h2>
            <p>تاریخ تهیه گزارش: ${new Date().toLocaleDateString('fa-IR')}</p>
        </div>
        
        <div class="student-info">
            <h3>اطلاعات دانش‌آموز</h3>
            <p><strong>نام و نام خانوادگی:</strong> ${studentInfo.student_name}</p>
            <p><strong>کلاس:</strong> ${studentInfo.class || 'نامشخص'}</p>
            <p><strong>کد ملی:</strong> ${studentInfo.national_id || 'نامشخص'}</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-box">
                <span class="stat-number">${totalGames}</span>
                <div class="stat-label">کل بازی‌ها</div>
            </div>
            <div class="stat-box">
                <span class="stat-number">${avgScore.toFixed(1)}</span>
                <div class="stat-label">میانگین امتیاز</div>
            </div>
            <div class="stat-box">
                <span class="stat-number">${bestScore}</span>
                <div class="stat-label">بهترین امتیاز</div>
            </div>
            <div class="stat-box">
                <span class="stat-number">${avgAccuracy.toFixed(1)}%</span>
                <div class="stat-label">میانگین دقت</div>
            </div>
        </div>
        
        <h3 class="section-title">تاریخچه تفصیلی بازی‌ها</h3>
        <table>
            <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام بازی</th>
                    <th>دسته‌بندی</th>
                    <th>امتیاز</th>
                    <th>دقت (%)</th>
                    <th>زمان (ثانیه)</th>
                    <th>تعداد تلاش</th>
                    <th>تاریخ انجام</th>
                </tr>
            </thead>
            <tbody>
                ${allResults.map((result, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${result.game_title}</td>
                        <td>${result.category_name}</td>
                        <td>${result.score}</td>
                        <td>${result.accuracy.toFixed(1)}</td>
                        <td>${result.time_spent}</td>
                        <td>${result.attempts || 1}</td>
                        <td>${this.formatDate(result.completed_at)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
        
        <div style="margin-top: 3rem; text-align: center; color: #6c757d; border-top: 1px solid #dee2e6; padding-top: 1rem;">
            <p>این گزارش توسط سیستم مدیریت بازی‌های آموزشی تولید شده است</p>
        </div>
    </body>
    </html>
    `;
},

    // راه‌اندازی رویدادها
    setupEventListeners: function() {
        const self = this;
        
        // رویدادهای فیلتر - با real-time update
        const filterElements = [
            'filterStudent', 'filterGame', 'filterCategory', 
            'filterDateFrom', 'filterDateTo', 'filterSort'
        ];
        
        filterElements.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', () => {
                    console.log(`Filter ${id} changed to:`, element.value);
                    self.applyFilters();
                });
            }
        });

        // فیلترهای عددی با debounce
        ['filterMinScore', 'filterMaxScore'].forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('input', this.debounce(() => {
                    console.log(`Numeric filter ${id} changed to:`, element.value);
                    self.applyFilters();
                }, 500));
            }
        });

        // رویدادهای نمودار
        const chartPeriod = document.getElementById('chartPeriod');
        if (chartPeriod) {
            chartPeriod.addEventListener('change', () => self.updateChart());
        }

        const rankingCriteria = document.getElementById('rankingCriteria');
        if (rankingCriteria) {
            rankingCriteria.addEventListener('change', () => self.updateRanking());
        }

        // کلیدهای میانبر
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                self.closeAllModals();
            }
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                self.printReport();
            }
            if (e.ctrlKey && e.key === 'e') {
                e.preventDefault();
                self.exportAll();
            }
        });
    },

    // بارگذاری داده‌ها
    loadData: function() {
        const self = this;
        showLoading();
        
        console.log('Loading data with filters:', this.data.filters);
        
        const params = new URLSearchParams(this.data.filters);
        params.append('page', this.data.currentPage);
        params.append('limit', this.data.resultsPerPage);
        
        fetch(`../ajax/load_results_analysis.php?${params.toString()}`)
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    self.updateDashboard(data.stats || {});
                    self.updateTopStudents(data.top_students || []);
                    self.updateTable(data.results || []);
                    self.updatePagination(data.pagination || {});
                    self.updateCharts(data.chart_data || [], data.category_stats || []);
                    
                    console.log('Results analysis loaded successfully');
                } else {
                    console.error('خطا در بارگیری تحلیل:', data.message);
                    showNotification('خطا در بارگیری تحلیل نتایج: ' + data.message, 'error');
                    
                    // بارگذاری داده‌های نمونه در صورت خطا
                    self.loadSampleData();
                }
            })
            .catch(error => {
                hideLoading();
                console.error('خطا در ارتباط با سرور:', error);
                
                // بارگذاری داده‌های نمونه در صورت خطا
                self.loadSampleData();
                showNotification('بارگیری داده‌های نمونه...', 'info');
            });
    },

   // بروزرسانی تابع loadSampleData
loadSampleData: function() {
    const sampleStats = {
        total_results: 1250,
        total_students: 45,
        avg_score: 75.5,
        best_score: 98,
        avg_accuracy: 82.3,
        avg_time: 245
    };

    const sampleStudents = [
        {id: 1, student_name: 'علی احمدی', avg_score: 95.5, total_plays: 25, avg_accuracy: 94.2, best_score: 100},
        {id: 2, student_name: 'فاطمه کریمی', avg_score: 92.3, total_plays: 22, avg_accuracy: 91.8, best_score: 98},
        {id: 3, student_name: 'محمد رضایی', avg_score: 89.7, total_plays: 28, avg_accuracy: 88.5, best_score: 96},
        {id: 4, student_name: 'زهرا موسوی', avg_score: 87.1, total_plays: 20, avg_accuracy: 85.3, best_score: 94},
        {id: 5, student_name: 'حسین جوادی', avg_score: 84.8, total_plays: 24, avg_accuracy: 82.7, best_score: 92}
    ];

    const sampleResults = [
        {
            id: 1, student_id: 1, student_name: 'علی احمدی', game_title: 'جمع و تفریق', 
            category_name: 'ریاضی', category_color: '#4d9de0', category_icon: '🔢',
            score: 95, max_possible_score: 100, accuracy: 94.5, time_spent: 180,
            attempts: 1, completed_at: '2024-01-15 10:30:00'
        },
        {
            id: 2, student_id: 2, student_name: 'فاطمه کریمی', game_title: 'املا و نگارش', 
            category_name: 'فارسی', category_color: '#28a745', category_icon: '📖',
            score: 88, max_possible_score: 100, accuracy: 87.2, time_spent: 220,
            attempts: 2, completed_at: '2024-01-15 11:15:00'
        },
        {
            id: 3, student_id: 3, student_name: 'محمد رضایی', game_title: 'علوم طبیعی', 
            category_name: 'علوم', category_color: '#dc3545', category_icon: '🔬',
            score: 78, max_possible_score: 100, accuracy: 75.8, time_spent: 300,
            attempts: 1, completed_at: '2024-01-15 12:00:00'
        },
        {
            id: 4, student_id: 4, student_name: 'زهرا موسوی', game_title: 'تاریخ ایران', 
            category_name: 'اجتماعی', category_color: '#ffc107', category_icon: '🏛️',
            score: 82, max_possible_score: 100, accuracy: 80.5, time_spent: 260,
            attempts: 3, completed_at: '2024-01-15 13:20:00'
        },
        {
            id: 5, student_id: 1, student_name: 'علی احمدی', game_title: 'ضرب و تقسیم', 
            category_name: 'ریاضی', category_color: '#4d9de0', category_icon: '🔢',
            score: 92, max_possible_score: 100, accuracy: 90.2, time_spent: 195,
            attempts: 1, completed_at: '2024-01-14 09:45:00'
        },
        {
            id: 6, student_id: 2, student_name: 'فاطمه کریمی', game_title: 'شعر و ادبیات', 
            category_name: 'فارسی', category_color: '#28a745', category_icon: '📖',
            score: 85, max_possible_score: 100, accuracy: 83.7, time_spent: 240,
            attempts: 1, completed_at: '2024-01-14 14:20:00'
        }
    ];

    const chartData = [
        {play_date: '2024-01-10', avg_score: 78.5, plays_count: 12},
        {play_date: '2024-01-11', avg_score: 80.2, plays_count: 15},
        {play_date: '2024-01-12', avg_score: 82.1, plays_count: 18},
        {play_date: '2024-01-13', avg_score: 79.8, plays_count: 14},
        {play_date: '2024-01-14', avg_score: 83.5, plays_count: 20},
        {play_date: '2024-01-15', avg_score: 85.2, plays_count: 22}
    ];

    const categoryStats = [
        {category_name: 'ریاضی', avg_score: 82.5, color: '#4d9de0'},
        {category_name: 'فارسی', avg_score: 78.3, color: '#28a745'},
        {category_name: 'علوم', avg_score: 75.8, color: '#dc3545'},
        {category_name: 'اجتماعی', avg_score: 73.2, color: '#ffc107'}
    ];

    // **نکته کلیدی: ذخیره داده‌ها در متغیر data**
    this.data.results = sampleResults;
    this.data.filteredResults = sampleResults;

    this.updateDashboard(sampleStats);
    this.updateTopStudents(sampleStudents);
    this.updateTable(sampleResults);
    this.updatePagination({current_page: 1, total_pages: 5, total_results: 1250});
    this.updateCharts(chartData, categoryStats);
},

    // باقی توابع مثل قبل...
    updateDashboard: function(stats) {
        const elements = {
            totalResults: this.formatNumber(stats.total_results || 0),
            activeStudents: this.formatNumber(stats.total_students || 0),
            avgPerformance: this.formatScore(stats.avg_score || 0)
        };

        Object.keys(elements).forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = elements[id];
            }
        });

        this.updateTrends();
    },

    updateTrends: function() {
        const trends = [
            { id: 'resultsTrend', change: Math.random() * 20 - 10 },
            { id: 'studentsTrend', change: Math.random() * 15 - 7.5 },
            { id: 'performanceTrend', change: Math.random() * 10 - 5 }
        ];
        
        trends.forEach(trend => {
            const element = document.getElementById(trend.id);
            if (element) {
                const icon = trend.change > 0 ? '↗️' : trend.change < 0 ? '↘️' : '➡️';
                const color = trend.change > 0 ? '#28a745' : trend.change < 0 ? '#dc3545' : '#6c757d';
                element.innerHTML = `${icon} ${Math.abs(trend.change).toFixed(1)}%`;
                element.style.color = color;
            }
        });
    },

    updateTopStudents: function(students) {
        const container = document.getElementById('topStudentsGrid');
        if (!container) return;
        
        if (!students || students.length === 0) {
            container.innerHTML = '<div style="text-align: center; color: rgba(255,255,255,0.7); grid-column: 1/-1;">داده‌ای یافت نشد</div>';
            return;
        }
        
        container.innerHTML = students.map((student, index) => `
            <div class="student-rank-card" onclick="ResultsAnalysis.showStudentDetails(${student.id || student.student_id})">
                <div class="rank-number">${index + 1}</div>
                <div class="student-info">
                    <div class="student-avatar">
                        ${student.avatar ? `<img src="${student.avatar}" alt="${student.student_name}">` : this.getInitials(student.student_name)}
                    </div>
                    <div class="student-name">${this.escapeHtml(student.student_name)}</div>
                </div>
                <div class="student-stats">
                    <div class="stat-item">
                        <span>میانگین: </span>
                        <span class="stat-value">${this.formatScore(student.avg_score)}</span>
                    </div>
                    <div class="stat-item">
                        <span>تعداد بازی: </span>
                        <span class="stat-value">${student.total_plays}</span>
                    </div>
                    <div class="stat-item">
                        <span>دقت: </span>
                        <span class="stat-value">${this.formatPercentage(student.avg_accuracy)}</span>
                    </div>
                    <div class="stat-item">
                        <span>بهترین: </span>
                        <span class="stat-value">${this.formatScore(student.best_score)}</span>
                    </div>
                </div>
            </div>
        `).join('');
    },

    // اصلاح تابع updateTable
updateTable: function(results) {
    const tbody = document.getElementById('resultsTableBody');
    if (!tbody) return;
    
    // **ذخیره داده‌ها برای استفاده در توابع دیگر**
    this.data.results = results || this.data.results;
    
    if (!results || results.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.7);">هیچ نتیجه‌ای یافت نشد</td></tr>';
        return;
    }

    tbody.innerHTML = results.map(result => `
        <tr>
            <td>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    ${result.avatar ? `<img src="${result.avatar}" style="width: 30px; height: 30px; border-radius: 50%;" alt="">` : 
                      `<div style="width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 0.8rem;">${this.getInitials(result.student_name)}</div>`}
                    <span>${this.escapeHtml(result.student_name)}</span>
                </div>
            </td>
            <td>
                <div style="font-weight: 600;">${this.escapeHtml(result.game_title)}</div>
                <div style="font-size: 0.8rem; opacity: 0.8;">${result.difficulty || 'متوسط'}</div>
            </td>
            <td>
                <div class="category-badge" style="background-color: ${result.category_color}20; color: ${result.category_color};">
                    ${result.category_icon || '📚'} ${this.escapeHtml(result.category_name)}
                </div>
            </td>
            <td>
                <div class="score-badge ${this.getScoreClass(result.score, result.max_possible_score)}">
                    ${result.score}/${result.max_possible_score || 100}
                </div>
            </td>
            <td>
                <div class="accuracy-badge ${this.getAccuracyClass(result.accuracy)}">
                    ${this.formatPercentage(result.accuracy)}
                </div>
            </td>
            <td>
                <div class="time-badge">
                    ${this.formatTime(result.time_spent)}
                </div>
            </td>
            <td>${result.attempts || 1}</td>
            <td>
                <div>${this.formatDate(result.completed_at)}</div>
                <div style="font-size: 0.8rem; opacity: 0.7;">${this.formatTime24(result.completed_at)}</div>
            </td>
            <td class="result-actions">
                <button onclick="ResultsAnalysis.showStudentDetails(${result.student_id})" title="جزئیات دانش‌آموز" class="view-details-btn">👤</button>
                <button onclick="ResultsAnalysis.editResult(${result.id})" title="ویرایش" class="edit-result-btn">✏️</button>
                <button onclick="ResultsAnalysis.deleteResult(${result.id})" title="حذف" class="delete-result-btn">🗑️</button>
            </td>
        </tr>
    `).join('');
},


    updatePagination: function(pagination) {
        this.data.currentPage = pagination.current_page || 1;
        this.data.totalPages = pagination.total_pages || 1;
        
        const currentPageEl = document.getElementById('currentPage');
        const totalPagesEl = document.getElementById('totalPages');
        const resultsInfoEl = document.getElementById('resultsInfo');
        
        if (currentPageEl) currentPageEl.textContent = this.data.currentPage;
        if (totalPagesEl) totalPagesEl.textContent = this.data.totalPages;
        if (resultsInfoEl) resultsInfoEl.textContent = `${this.formatNumber(pagination.total_results || 0)} نتیجه`;

        const prevBtn = document.getElementById('prevPageBtn');
        const nextBtn = document.getElementById('nextPageBtn');
        
        if (prevBtn) prevBtn.disabled = this.data.currentPage <= 1;
        if (nextBtn) nextBtn.disabled = this.data.currentPage >= this.data.totalPages;

        this.updatePageNumbers();
    },

    updatePageNumbers: function() {
        const container = document.getElementById('pageNumbers');
        if (!container) return;
        
        const pages = [];
        const maxVisible = 5;
        
        let startPage = Math.max(1, this.data.currentPage - Math.floor(maxVisible / 2));
        let endPage = Math.min(this.data.totalPages, startPage + maxVisible - 1);
        
        if (endPage - startPage + 1 < maxVisible) {
            startPage = Math.max(1, endPage - maxVisible + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            pages.push(`
                <div class="page-number ${i === this.data.currentPage ? 'active' : ''}" 
                     onclick="ResultsAnalysis.changePage(${i})">${i}</div>
            `);
        }
        
        container.innerHTML = pages.join('');
    },

    updateCharts: function(chartData, categoryStats) {
        this.updatePerformanceChart(chartData);
        this.updateCategoryChart(categoryStats);
    },

    updatePerformanceChart: function(data) {
        const ctx = document.getElementById('performanceChart');
        if (!ctx) return;
        
        if (this.data.charts.performance) {
            this.data.charts.performance.destroy();
        }
        
        const labels = data.map(item => this.formatDateShort(item.play_date));
        const scores = data.map(item => parseFloat(item.avg_score) || 0);
        const plays = data.map(item => parseInt(item.plays_count) || 0);
        
        this.data.charts.performance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'میانگین امتیاز',
                    data: scores,
                    borderColor: '#ffd93d',
                    backgroundColor: 'rgba(255, 217, 61, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'تعداد بازی',
                    data: plays,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: 'white' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: 'white' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        ticks: { color: 'white' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        ticks: { color: 'white' },
                        grid: { drawOnChartArea: false }
                    }
                }
            }
        });
    },

    updateCategoryChart: function(data) {
        const ctx = document.getElementById('categoryChart');
        if (!ctx) return;
        
        if (this.data.charts.category) {
            this.data.charts.category.destroy();
        }
        
        const labels = data.map(item => item.category_name);
        const scores = data.map(item => parseFloat(item.avg_score) || 0);
        const colors = data.map(item => item.color || '#667eea');
        
        this.data.charts.category = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: scores,
                    backgroundColor: colors.map(color => color + '80'),
                    borderColor: colors,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { 
                            color: 'white',
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    },

    // =================== عملکردهای کاملاً فعال ===================

    // 1. بروزرسانی، خروجی اکسل و چاپ
    refreshData: function() {
        console.log('Refreshing all data...');
        showNotification('در حال بروزرسانی داده‌ها...', 'info');
        this.loadData();
        showNotification('داده‌ها با موفقیت بروزرسانی شدند! 🔄', 'success');
    },

    exportAll: function() {
        console.log('Exporting to Excel...');
        showNotification('در حال تولید فایل Excel...', 'info');
        
        // تولید CSV از داده‌های موجود
        const csvData = this.generateCSV();
        this.downloadCSV(csvData, `نتایج_تحلیل_${new Date().toISOString().slice(0,10)}.csv`);
        
        showNotification('فایل Excel با موفقیت دانلود شد! 📊', 'success');
    },

    printReport: function() {
        console.log('Printing report...');
        showNotification('در حال آماده‌سازی برای چاپ...', 'info');
        
        // ایجاد صفحه چاپ
        const printWindow = window.open('', '_blank');
        const printContent = this.generatePrintHTML();
        
        printWindow.document.write(printContent);
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
            showNotification('گزارش آماده چاپ شد! 🖨️', 'success');
        }, 500);
    },

    // 2. فیلترهای پیشرفته
    applyFilters: function() {
        console.log('Applying advanced filters...');
        
        // جمع‌آوری مقادیر فیلتر
        this.data.filters.student_id = document.getElementById('filterStudent')?.value || '';
        this.data.filters.game_id = document.getElementById('filterGame')?.value || '';
        this.data.filters.category_id = document.getElementById('filterCategory')?.value || '';
        this.data.filters.date_from = document.getElementById('filterDateFrom')?.value || '';
        this.data.filters.date_to = document.getElementById('filterDateTo')?.value || '';
        this.data.filters.min_score = document.getElementById('filterMinScore')?.value || '';
        this.data.filters.max_score = document.getElementById('filterMaxScore')?.value || '';
        this.data.filters.sort = document.getElementById('filterSort')?.value || 'date_desc';
        
        // نمایش فیلترهای فعال
        this.showActiveFilters();
        
        this.data.currentPage = 1;
        this.loadData();
        
        showNotification('فیلترها اعمال شدند 🔍', 'info');
    },

    clearFilters: function() {
        console.log('Clearing all filters...');
        
        const filterIds = [
            'filterStudent', 'filterGame', 'filterCategory', 
            'filterDateFrom', 'filterDateTo', 'filterMinScore', 
            'filterMaxScore', 'filterSort'
        ];
        
        filterIds.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.value = '';
            }
        });
        
        this.data.filters = {
            student_id: '',
            game_id: '',
            category_id: '',
            date_from: '',
            date_to: '',
            min_score: '',
            max_score: '',
            sort: 'date_desc'
        };
        
        this.hideActiveFilters();
        this.data.currentPage = 1;
        this.loadData();
        
        showNotification('همه فیلترها پاک شدند 🗑️', 'success');
    },

    toggleFilters: function() {
        const content = document.getElementById('filtersContent');
        const toggle = document.querySelector('.filters-toggle');
        
        if (content && toggle) {
            content.classList.toggle('expanded');
            toggle.classList.toggle('expanded');
            
            const text = toggle.querySelector('.toggle-text');
            if (text) {
                text.textContent = content.classList.contains('expanded') ? 
                    'مخفی کردن فیلترها' : 'نمایش فیلترها';
            }
        }
    },

  // اصلاح تابع showStudentDetails
showStudentDetails: function(studentId) {
    console.log('Showing student details for ID:', studentId);
    console.log('Available results:', this.data.results);
    
    this.data.currentStudentId = studentId;
    
    showLoading();
    
    // یافتن اطلاعات دانش‌آموز از داده‌های موجود
    const studentResults = this.data.results.filter(r => r.student_id == studentId);
    console.log('Student results found:', studentResults);
    
    setTimeout(() => {
        hideLoading();
        
        if (studentResults && studentResults.length > 0) {
            const studentInfo = studentResults[0]; // اولین نتیجه برای اطلاعات پایه
            this.populateStudentModal(studentInfo, studentResults);
            document.getElementById('studentDetailsModal').classList.add('show');
            document.body.style.overflow = 'hidden';
        } else {
            showNotification('اطلاعات دانش‌آموز یافت نشد', 'error');
            console.error('No results found for student ID:', studentId);
        }
    }, 500);
},

// اصلاح تابع editResult
editResult: function(resultId) {
    console.log('Editing result ID:', resultId);
    console.log('Available results:', this.data.results);
    
    const result = this.data.results.find(r => r.id == resultId);
    console.log('Result found:', result);
    
    if (!result) {
        showNotification('نتیجه یافت نشد', 'error');
        console.error('No result found for ID:', resultId);
        return;
    }
    
    // پر کردن فرم ویرایش
    document.getElementById('editResultId').value = result.id;
    document.getElementById('editStudentName').value = result.student_name;
    document.getElementById('editGameTitle').value = result.game_title;
    document.getElementById('editScore').value = result.score;
    document.getElementById('editAccuracy').value = result.accuracy;
    document.getElementById('editTimeSpent').value = result.time_spent;
    document.getElementById('editAttempts').value = result.attempts || 1;
    
    // نمایش مودال
    document.getElementById('editResultModal').classList.add('show');
    document.body.style.overflow = 'hidden';
},

   deleteResult: async function(resultId) {
    console.log('=== DELETE FUNCTION CALLED ===');
    console.log('Result ID:', resultId);
    console.log('Type:', typeof resultId);
    
    // تبدیل به عدد
    const id = parseInt(resultId);
    
    if (!id || id <= 0) {
        console.error('Invalid ID:', id);
        showNotification('❌ شناسه نامعتبر است', 'error');
        return;
    }
    
    if (!confirm('آیا مطمئن هستید که می‌خواهید این نتیجه را حذف کنید؟\n\nاین عمل غیرقابل بازگشت است.')) {
        console.log('User cancelled');
        return;
    }
    
    console.log('Sending delete request for ID:', id);
    
    // نمایش loading
    showLoading();
    
    try {
        const response = await fetch('../ajax/delete_single_result.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ result_id: id })
        });
        
        console.log('Response status:', response.status);
        console.log('Response OK:', response.ok);
        
        // دریافت متن خام
        const text = await response.text();
        console.log('Raw response:', text);
        
        // تلاش برای parse کردن JSON
        let data;
        try {
            data = JSON.parse(text);
            console.log('Parsed data:', data);
        } catch (e) {
            console.error('JSON parse error:', e);
            console.error('Response was:', text);
            throw new Error('پاسخ سرور JSON معتبر نیست');
        }
        
        hideLoading();
        
        if (data.success) {
            let message = '✅ ' + (data.message || 'نتیجه با موفقیت حذف شد');
            
            // اطلاعات debug اگر موجود است
            if (data.debug) {
                console.log('Debug info:', data.debug);
                message += '\n\n📊 جزئیات:';
                message += '\n• رکوردهای game_results حذف شده: ' + (data.debug.game_results_deleted || 0);
                message += '\n• رکوردهای XP حذف شده: ' + (data.debug.xp_records_deleted || 0);
                if (data.debug.xp_returned > 0) {
                    message += '\n• XP بازگردانده شده: ' + data.debug.xp_returned;
                }
            }
            
            showNotification(message, 'success');
            
            // حذف از داده‌های محلی
            this.data.results = this.data.results.filter(r => r.id != id);
            
            // بروزرسانی نمایش
            this.updateTable(this.data.results);
            
            // اگر در مودال هستیم، بارگذاری مجدد (اختیاری - بر اساس کد دوم)
            if (typeof currentViewingGameId !== 'undefined' && currentViewingGameId) {
                console.log('Reloading modal results...');
                if (typeof loadModalResults === 'function') {
                    await loadModalResults(currentViewingGameId);
                }
            }
            
        } else {
            showNotification('❌ خطا در حذف: ' + (data.message || 'خطای ناشناخته'), 'error');
            console.error('Delete failed:', data);
        }
        
    } catch (error) {
        hideLoading();
        
        console.error('=== DELETE ERROR ===');
        console.error('Error:', error);
        console.error('Stack:', error.stack);
        
        showNotification('❌ خطا در حذف:\n' + error.message, 'error');
    }
},

    // توابع کمکی مودال‌ها
    populateStudentModal: function(studentInfo, allResults) {
        document.getElementById('studentFullName').textContent = studentInfo.student_name;
        document.getElementById('studentInfo').textContent = `کلاس: ${studentInfo.class || '--'} | کد ملی: ${studentInfo.national_id || '--'}`;
        
        // محاسبه آمار
        const totalGames = allResults.length;
        const avgScore = allResults.reduce((sum, r) => sum + r.score, 0) / totalGames;
        const bestScore = Math.max(...allResults.map(r => r.score));
        const avgAccuracy = allResults.reduce((sum, r) => sum + r.accuracy, 0) / totalGames;
        
        document.getElementById('studentTotalGames').textContent = totalGames;
        document.getElementById('studentAvgScoreDisplay').textContent = this.formatScore(avgScore);
        document.getElementById('studentBestScoreDisplay').textContent = bestScore;
        document.getElementById('studentAvgAccuracyDisplay').textContent = this.formatPercentage(avgAccuracy);
        document.getElementById('studentRankDisplay').textContent = '#' + (Math.floor(Math.random() * 10) + 1);
        
        // پر کردن جدول تاریخچه
        const historyTable = document.getElementById('studentGamesHistory');
        historyTable.innerHTML = allResults.map(result => `
            <tr>
                <td>${result.game_title}</td>
                <td><span class="score-badge ${this.getScoreClass(result.score, 100)}">${result.score}</span></td>
                <td><span class="accuracy-badge ${this.getAccuracyClass(result.accuracy)}">${this.formatPercentage(result.accuracy)}</span></td>
                <td>${this.formatTime(result.time_spent)}</td>
                <td>${this.formatDate(result.completed_at)}</td>
            </tr>
        `).join('');
    },

   saveEditResult: function() {
    console.log('Saving edited result (Real Save)...');
    
    // 1. دریافت مقادیر از ورودی‌ها
    // توجه: مطمئن شوید IDها با HTML مودال شما یکی باشند
    // در کدی که فرستادید از این IDها استفاده شده بود:
    const resultId = document.getElementById('editResultId').value;
    const newScore = document.getElementById('editScore').value;
    const newAccuracy = document.getElementById('editAccuracy').value;
    const newTimeSpent = document.getElementById('editTimeSpent').value;
    const newAttempts = document.getElementById('editAttempts').value;
    
    // دریافت فیلد تاریخ (اگر در فرم HTML وجود دارد)
    const newCompletedAt = document.getElementById('editResultCompletedAt') ? document.getElementById('editResultCompletedAt').value : null;

    // 2. اعتبارسنجی ساده
    if (resultId === '' || !newScore || !newAccuracy || !newTimeSpent) {
        showNotification('لطفاً همه فیلدهای الزامی را پر کنید', 'error');
        return;
    }
    
    showLoading();

    // 3. ساخت FormData برای ارسال به PHP
    const formData = new FormData();
    formData.append('result_id', resultId);
    formData.append('score', newScore);
    formData.append('accuracy', newAccuracy);
    formData.append('time_spent', newTimeSpent);
    formData.append('attempts', newAttempts);
    
    if (newCompletedAt) {
        formData.append('completed_at', newCompletedAt);
    }

    // 4. ارسال درخواست AJAX به سرور
    fetch('../ajax/update_result.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading(); // مخفی کردن لودینگ
        
        if (data.success) {
            // الف) بروزرسانی آرایه محلی (برای اینکه جدول بدون رفرش آپدیت شود)
            // فرض بر این است که this.data.results وجود دارد (چون در کد قبلی شما بود)
            if (this.data && this.data.results) {
                const resultIndex = this.data.results.findIndex(r => r.id == resultId);
                if (resultIndex !== -1) {
                    this.data.results[resultIndex].score = parseInt(newScore);
                    this.data.results[resultIndex].accuracy = parseFloat(newAccuracy);
                    this.data.results[resultIndex].time_spent = parseInt(newTimeSpent);
                    this.data.results[resultIndex].attempts = parseInt(newAttempts);
                    if (newCompletedAt) {
                        // فرمت ساده‌سازی شده برای نمایش سریع
                        this.data.results[resultIndex].completed_at = newCompletedAt.replace('T', ' ');
                    }
                    
                    // رندر مجدد جدول
                    if (typeof this.updateTable === 'function') {
                        this.updateTable(this.data.results);
                    }
                }
            }

            // ب) بستن مودال و نمایش پیام
            this.closeEditModal();
            showNotification('✅ ' + data.message, 'success');
            
        } else {
            showNotification('❌ ' + data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showNotification('خطا در ارتباط با سرور', 'error');
    });
},

    closeStudentModal: function() {
        document.getElementById('studentDetailsModal').classList.remove('show');
        document.body.style.overflow = 'auto';
        this.data.currentStudentId = null;
    },

    closeEditModal: function() {
        document.getElementById('editResultModal').classList.remove('show');
        document.body.style.overflow = 'auto';
        document.getElementById('editResultForm').reset();
    },

    closeAllModals: function() {
        this.closeStudentModal();
        this.closeEditModal();
    },

    // توابع کمکی اضافی
    showActiveFilters: function() {
        const activeFilters = [];
        Object.keys(this.data.filters).forEach(key => {
            if (this.data.filters[key]) {
                activeFilters.push(key);
            }
        });
        
        if (activeFilters.length > 0) {
            console.log('Active filters:', activeFilters);
        }
    },

    hideActiveFilters: function() {
        console.log('All filters cleared');
    },

    exportStudentReport: function() {
        if (!this.data.currentStudentId) return;
        
        const studentResults = this.data.results.filter(r => r.student_id == this.data.currentStudentId);
        const csvData = this.generateStudentCSV(studentResults);
        this.downloadCSV(csvData, `گزارش_دانش_آموز_${this.data.currentStudentId}.csv`);
        
        showNotification('گزارش دانش‌آموز دانلود شد! 📄', 'success');
    },

    generateCSV: function() {
        const headers = ['نام دانش‌آموز', 'بازی', 'دسته‌بندی', 'امتیاز', 'دقت', 'زمان', 'تلاش‌ها', 'تاریخ'];
        const rows = this.data.results.map(result => [
            result.student_name,
            result.game_title,
            result.category_name,
            result.score,
            result.accuracy + '%',
            this.formatTime(result.time_spent),
            result.attempts,
            this.formatDate(result.completed_at)
        ]);
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    },

    generateStudentCSV: function(studentResults) {
        const headers = ['بازی', 'امتیاز', 'دقت', 'زمان', 'تاریخ'];
        const rows = studentResults.map(result => [
            result.game_title,
            result.score,
            result.accuracy + '%',
            this.formatTime(result.time_spent),
            this.formatDate(result.completed_at)
        ]);
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    },

    downloadCSV: function(csvContent, filename) {
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    },

    generatePrintHTML: function() {
        return `
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>گزارش تحلیل نتایج</title>
            <style>
                body { font-family: Tahoma, Arial; direction: rtl; }
                .header { text-align: center; margin-bottom: 2rem; }
                .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 2rem; }
                .stat { border: 1px solid #ddd; padding: 1rem; text-align: center; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 2rem; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
                th { background: #f5f5f5; }
                @media print { .no-print { display: none; } }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>گزارش تحلیل نتایج بازی‌های آموزشی</h1>
                <p>تاریخ: ${new Date().toLocaleDateString('fa-IR')}</p>
            </div>
            <div class="stats">
                <div class="stat">
                    <h3>${this.formatNumber(document.getElementById('totalResults')?.textContent || 0)}</h3>
                    <p>کل نتایج</p>
                </div>
                <div class="stat">
                    <h3>${this.formatNumber(document.getElementById('activeStudents')?.textContent || 0)}</h3>
                    <p>دانش‌آموزان فعال</p>
                </div>
                <div class="stat">
                    <h3>${document.getElementById('avgPerformance')?.textContent || 0}</h3>
                    <p>میانگین عملکرد</p>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>دانش‌آموز</th>
                        <th>بازی</th>
                        <th>امتیاز</th>
                        <th>دقت</th>
                        <th>زمان</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.data.results.slice(0, 20).map(result => `
                        <tr>
                            <td>${result.student_name}</td>
                            <td>${result.game_title}</td>
                            <td>${result.score}</td>
                            <td>${this.formatPercentage(result.accuracy)}</td>
                            <td>${this.formatTime(result.time_spent)}</td>
                            <td>${this.formatDate(result.completed_at)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </body>
        </html>
        `;
    },

    changePage: function(page) {
        if (typeof page === 'string') {
            if (page === 'prev' && this.data.currentPage > 1) {
                this.data.currentPage--;
            } else if (page === 'next' && this.data.currentPage < this.data.totalPages) {
                this.data.currentPage++;
            }
        } else {
            this.data.currentPage = page;
        }
        
        this.loadData();
    },

    updateChart: function() {
        const period = document.getElementById('chartPeriod')?.value || '30';
        console.log('Updating chart for period:', period);
        showNotification(`بروزرسانی نمودار برای ${period} روز اخیر...`, 'info');
        this.loadData();
    },

    updateRanking: function() {
        const criteria = document.getElementById('rankingCriteria')?.value || 'avg_score';
        console.log('Updating ranking by:', criteria);
        showNotification(`بروزرسانی رنکینگ بر اساس ${criteria}...`, 'info');
        this.loadData();
    },

    loadFilters: function() {
        this.loadStudentsFilter();
        this.loadGamesFilter();
        this.loadCategoryFilter();
    },

    loadStudentsFilter: function() {
        const sampleStudents = [
            {id: 1, first_name: 'علی', last_name: 'احمدی'},
            {id: 2, first_name: 'فاطمه', last_name: 'کریمی'},
            {id: 3, first_name: 'محمد', last_name: 'رضایی'},
            {id: 4, first_name: 'زهرا', last_name: 'موسوی'},
            {id: 5, first_name: 'حسین', last_name: 'جوادی'}
        ];

        const select = document.getElementById('filterStudent');
        if (select) {
            select.innerHTML = '<option value="">همه دانش‌آموزان</option>' +
                sampleStudents.map(student => 
                    `<option value="${student.id}">${student.first_name} ${student.last_name}</option>`
                ).join('');
        }
    },

    loadGamesFilter: function() {
        const sampleGames = [
            {id: 1, title: 'جمع و تفریق'},
            {id: 2, title: 'املا و نگارش'},
            {id: 3, title: 'علوم طبیعی'},
            {id: 4, title: 'تاریخ ایران'},
            {id: 5, title: 'جغرافیا'}
        ];

        const select = document.getElementById('filterGame');
        if (select) {
            select.innerHTML = '<option value="">همه بازی‌ها</option>' +
                sampleGames.map(game => 
                    `<option value="${game.id}">${game.title}</option>`
                ).join('');
        }
    },

    loadCategoryFilter: function() {
        const sampleCategories = [
            {id: 1, name: 'ریاضی', icon: '🔢'},
            {id: 2, name: 'فارسی', icon: '📖'},
            {id: 3, name: 'علوم', icon: '🔬'},
            {id: 4, name: 'اجتماعی', icon: '🏛️'}
        ];

        const select = document.getElementById('filterCategory');
        if (select) {
            select.innerHTML = '<option value="">همه دسته‌بندی‌ها</option>' +
                sampleCategories.map(category => 
                    `<option value="${category.id}">${category.icon} ${category.name}</option>`
                ).join('');
        }
    },

    // توابع کمکی
    formatNumber: function(num) {
        return new Intl.NumberFormat('fa-IR').format(num);
    },

    formatScore: function(score) {
        return parseFloat(score || 0).toFixed(1);
    },

    formatPercentage: function(percent) {
        return parseFloat(percent || 0).toFixed(1) + '%';
    },

    formatTime: function(seconds) {
        if (!seconds) return '--';
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return mins > 0 ? `${mins}:${secs.toString().padStart(2, '0')}` : `${secs}ث`;
    },

    formatDate: function(dateString) {
        if (!dateString) return '--';
        const date = new Date(dateString);
        return date.toLocaleDateString('fa-IR');
    },

    formatDateShort: function(dateString) {
        if (!dateString) return '--';
        const date = new Date(dateString);
        return `${date.getMonth() + 1}/${date.getDate()}`;
    },

    formatTime24: function(dateString) {
        if (!dateString) return '--';
        const date = new Date(dateString);
        return date.toLocaleTimeString('fa-IR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    },

    getInitials: function(name) {
        if (!name) return 'N/A';
        return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    },

    getScoreClass: function(score, maxScore) {
        const percentage = (score / (maxScore || 100)) * 100;
        if (percentage >= 90) return 'score-excellent';
        if (percentage >= 70) return 'score-good';
        if (percentage >= 50) return 'score-average';
        return 'score-poor';
    },

    getAccuracyClass: function(accuracy) {
        if (accuracy >= 90) return 'accuracy-high';
        if (accuracy >= 70) return 'accuracy-medium';
        return 'accuracy-low';
    },

    escapeHtml: function(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// اضافه کردن CSS برای مودال‌ها و استایل‌های جدید
const modalCSS = `
<style>
.analysis-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.85);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    padding: 1rem;
}

.analysis-modal.show {
    display: flex;
    animation: fadeIn 0.4s ease;
}

.analysis-modal .modal-container {
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 25px;
    width: 100%;
    max-width: 900px;
    max-height: 95vh;
    overflow: hidden;
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.4);
    animation: slideUp 0.4s ease;
}

.analysis-modal .modal-container.large {
    max-width: 1200px;
}

.analysis-modal .modal-header {
    background: rgba(0,0,0,0.3);
    color: white;
    padding: 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.analysis-modal .modal-header h3 {
    margin: 0;
    font-size: 1.8rem;
    font-weight: 800;
    text-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.analysis-modal .modal-close {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.8rem;
    transition: all 0.3s ease;
}

.analysis-modal .modal-close:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
}

.analysis-modal .modal-body {
    padding: 2rem;
    max-height: 70vh;
    overflow-y: auto;
    background: rgba(255,255,255,0.1);
}

.analysis-modal .modal-footer {
    background: rgba(0,0,0,0.2);
    padding: 1.5rem 2rem;
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
}

.student-full-info {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
    background: rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 2rem;
    border: 1px solid rgba(255,255,255,0.2);
}

.student-profile {
    display: flex;
    gap: 1rem;
    flex: 1;
}

.student-avatar-large {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: white;
    border: 3px solid rgba(255,255,255,0.3);
}

.student-details h4 {
    color: white;
    font-size: 1.5rem;
    font-weight: 800;
    margin: 0 0 0.5rem 0;
}

.student-details p {
    color: rgba(255,255,255,0.8);
    margin: 0 0 1rem 0;
}

.student-rank-display {
    background: linear-gradient(135deg, #ffd93d, #ffb300);
    color: #333;
    padding: 0.5rem 1rem;
    border-radius: 15px;
    font-weight: 700;
    display: inline-block;
}

.student-quick-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
    flex: 1;
}

.quick-stat {
    text-align: center;
    background: rgba(255,255,255,0.1);
    padding: 1rem;
    border-radius: 15px;
    border: 1px solid rgba(255,255,255,0.2);
}

.quick-stat .stat-number {
    display: block;
    font-size: 1.5rem;
    font-weight: 900;
    color: #ffd93d;
    margin-bottom: 0.5rem;
}

.quick-stat .stat-label {
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
    font-weight: 600;
}

.student-games-history h5 {
    color: white;
    font-weight: 700;
    margin-bottom: 1rem;
    font-size: 1.2rem;
}

.games-history-table {
    background: rgba(255,255,255,0.1);
    border-radius: 15px;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.2);
}

.history-table {
    width: 100%;
    border-collapse: collapse;
}

.history-table th {
    background: rgba(0,0,0,0.3);
    color: white;
    padding: 1rem;
    text-align: right;
    font-weight: 700;
    border-bottom: 2px solid rgba(255,255,255,0.2);
}

.history-table td {
    padding: 0.8rem 1rem;
    color: white;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.history-table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: white;
}

.form-group input {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 10px;
    font-family: inherit;
    font-size: 1rem;
    background: rgba(255,255,255,0.1);
    color: white;
    transition: all 0.3s ease;
}

.form-group input:focus {
    outline: none;
    border-color: #ffd93d;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3);
}

.form-group input[readonly] {
    background: rgba(255,255,255,0.05);
    color: rgba(255,255,255,0.7);
}

.btn {
    padding: 0.8rem 1.5rem;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.btn-primary {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
}

.btn-secondary {
    background: rgba(108, 117, 125, 0.8);
    color: white;
}

.btn-secondary:hover {
    background: rgba(108, 117, 125, 1);
    transform: translateY(-2px);
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 768px) {
    .student-full-info {
        flex-direction: column;
    }
    
    .student-profile {
        justify-content: center;
        text-align: center;
    }
    
    .student-quick-stats {
        grid-template-columns: 1fr 1fr;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .analysis-modal .modal-body {
        padding: 1.5rem;
    }
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', modalCSS);

// اضافه کردن listener برای تب‌های مدیریت
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.games-tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const onclickValue = this.getAttribute('onclick');
            if (onclickValue && onclickValue.includes('results-management')) {
                setTimeout(() => {
                    if (document.getElementById('results-management').classList.contains('active')) {
                        ResultsAnalysis.init();
                    }
                }, 150);
            }
        });
    });
    
    console.log('Results Analysis listeners added successfully');
});

// متغیرهای سراسری برای سازگاری
window.ResultsAnalysis = ResultsAnalysis;
window.changePage = function(page) { ResultsAnalysis.changePage(page); };

console.log('Results Analysis module registered successfully - Complete Version with All Features');

// اضافه کردن CSS برای رفع مشکل رنگ select option ها
const selectFixCSS = `
<style>
/* رفع مشکل رنگ select option ها */
select {
    background: rgba(255,255,255,0.2) !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    color: white !important;
    padding: 0.8rem !important;
    border-radius: 10px !important;
    font-family: inherit !important;
    font-size: 1rem !important;
}

select:focus {
    outline: none !important;
    border-color: #ffd93d !important;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3) !important;
}

/* رفع مشکل option ها */
select option {
    background: #333 !important;
    color: white !important;
    padding: 0.5rem !important;
    border: none !important;
}

select option:hover {
    background: #444 !important;
    color: #ffd93d !important;
}

select option:checked {
    background: #555 !important;
    color: #ffd93d !important;
}

/* رفع مشکل فیلترهای خاص */
#chartPeriod,
#rankingCriteria,
#filterStudent,
#filterGame,
#filterCategory,
#filterDateFrom,
#filterDateTo,
#filterSort,
#filterGameSubject,
#filterGameStatus {
    background: rgba(255,255,255,0.2) !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    color: white !important;
    padding: 0.75rem 1rem !important;
    border-radius: 15px !important;
    font-family: inherit !important;
    font-size: 1rem !important;
}

#chartPeriod option,
#rankingCriteria option,
#filterStudent option,
#filterGame option,
#filterCategory option,
#filterSort option,
#filterGameSubject option,
#filterGameStatus option {
    background: #2c3e50 !important;
    color: white !important;
    padding: 0.5rem !important;
}

#chartPeriod:focus,
#rankingCriteria:focus,
#filterStudent:focus,
#filterGame:focus,
#filterCategory:focus,
#filterSort:focus,
#filterGameSubject:focus,
#filterGameStatus:focus {
    outline: none !important;
    border-color: #ffd93d !important;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3) !important;
}

/* بهبود ظاهر کلی جداول انتخاب */
.chart-controls select,
.ranking-controls select,
.results-filters select,
.games-filter select {
    background: rgba(255,255,255,0.2) !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    color: white !important;
    padding: 0.6rem 1rem !important;
    border-radius: 10px !important;
}

.chart-controls select option,
.ranking-controls select option,
.results-filters select option,
.games-filter select option {
    background: #34495e !important;
    color: white !important;
    padding: 0.5rem !important;
}

/* رفع مشکل input های date */
input[type="date"] {
    background: rgba(255,255,255,0.2) !important;
    border: 2px solid rgba(255,255,255,0.3) !important;
    color: white !important;
    padding: 0.8rem !important;
    border-radius: 10px !important;
}

input[type="date"]:focus {
    outline: none !important;
    border-color: #ffd93d !important;
    box-shadow: 0 0 0 3px rgba(255, 217, 61, 0.3) !important;
}

/* رفع مشکل رنگ placeholder و متن انتخاب نشده */
select:invalid {
    color: rgba(255,255,255,0.7) !important;
}

select option:first-child {
    color: rgba(255,255,255,0.8) !important;
    font-style: italic;
}
</style>
`;

document.head.insertAdjacentHTML('beforeend', selectFixCSS);


// اضافه کردن CSS و JavaScript در انتها
document.head.insertAdjacentHTML('beforeend', modalCSS + selectFixCSS);

// اضافه کردن listener برای تب‌های مدیریت
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.games-tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const onclickValue = this.getAttribute('onclick');
            if (onclickValue && onclickValue.includes('results-management')) {
                setTimeout(() => {
                    if (document.getElementById('results-management').classList.contains('active')) {
                        ResultsAnalysis.init();
                    }
                }, 150);
            }
        });
    });
    
    console.log('Results Analysis listeners added successfully');
});

// متغیرهای سراسری برای سازگاری
window.ResultsAnalysis = ResultsAnalysis;
window.changePage = function(page) { ResultsAnalysis.changePage(page); };

console.log('Results Analysis module registered successfully - Fixed Version');

// CSS کاملاً اصلاح شده برای مودال‌ها
const fixedModalCSS = `
<style>
/* مودال‌های تحلیل - نسخه اصلاح شده */
.analysis-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.85);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 2000;
    padding: 1rem;
}

.analysis-modal.show {
    display: flex;
    animation: fadeIn 0.4s ease;
}

.analysis-modal .modal-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    cursor: pointer;
}

.analysis-modal .modal-container {
    background: linear-gradient(135deg, #2c3e50, #34495e);
    border: 2px solid #667eea;
    border-radius: 25px;
    width: 100%;
    max-width: 900px;
    max-height: 95vh;
    overflow: hidden;
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.4);
    animation: slideUp 0.4s ease;
    position: relative;
    z-index: 2001;
}

.analysis-modal .modal-container.large {
    max-width: 1200px;
}

.analysis-modal .modal-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 1.5rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 3px solid #5a67d8;
}

.analysis-modal .modal-header h3 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 800;
    text-shadow: 0 2px 8px rgba(0,0,0,0.3);
    color: white;
}

.modal-header-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.modal-action-btn {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.5rem;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-action-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
}

.analysis-modal .modal-close {
    background: rgba(220, 53, 69, 0.8);
    border: none;
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.5rem;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.analysis-modal .modal-close:hover {
    background: rgba(220, 53, 69, 1);
    transform: scale(1.1);
}

.analysis-modal .modal-body {
    padding: 2rem;
    max-height: 70vh;
    overflow-y: auto;
    background: linear-gradient(135deg, #ecf0f1, #bdc3c7);
    color: #2c3e50;
}

.analysis-modal .modal-footer {
    background: linear-gradient(135deg, #34495e, #2c3e50);
    padding: 1.5rem 2rem;
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    border-top: 2px solid #667eea;
}

/* اطلاعات کامل دانش‌آموز */
.student-full-info {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
    background: white;
    border-radius: 20px;
    padding: 2rem;
    border: 2px solid #667eea;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.student-profile {
    display: flex;
    gap: 1.5rem;
    flex: 1;
    align-items: center;
}

.student-avatar-large {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: white;
    border: 3px solid #5a67d8;
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

.student-details h4 {
    color: #2c3e50;
    font-size: 1.8rem;
    font-weight: 800;
    margin: 0 0 0.5rem 0;
}

.student-details p {
    color: #7f8c8d;
    margin: 0 0 1rem 0;
    font-weight: 600;
}

.student-rank-display {
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 15px;
    font-weight: 700;
    display: inline-block;
    box-shadow: 0 5px 15px rgba(243, 156, 18, 0.3);
}

.student-quick-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
    flex: 1;
}

.quick-stat {
    text-align: center;
    background: linear-gradient(135deg, #ecf0f1, #bdc3c7);
    padding: 1.5rem;
    border-radius: 15px;
    border: 2px solid #95a5a6;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.quick-stat .stat-number {
    display: block;
    font-size: 2rem;
    font-weight: 900;
    color: #e74c3c;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.quick-stat .stat-label {
    color: #34495e;
    font-size: 0.9rem;
    font-weight: 600;
}

/* نمودار پیشرفت */
.student-performance-chart {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    margin-bottom: 2rem;
    border: 2px solid #3498db;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.student-performance-chart h5 {
    color: #2c3e50;
    font-weight: 700;
    margin-bottom: 1rem;
    font-size: 1.3rem;
}

.chart-placeholder {
    background: #ecf0f1;
    border-radius: 10px;
    padding: 1rem;
    min-height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* تاریخچه بازی‌ها */
.student-games-history {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    border: 2px solid #27ae60;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.student-games-history h5 {
    color: #2c3e50;
    font-weight: 700;
    margin-bottom: 1.5rem;
    font-size: 1.3rem;
}

.games-history-table {
    background: #ecf0f1;
    border-radius: 15px;
    overflow: hidden;
    border: 2px solid #bdc3c7;
}

.history-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

.history-table th {
    background: linear-gradient(135deg, #34495e, #2c3e50);
    color: white;
    padding: 1rem;
    text-align: right;
    font-weight: 700;
    border: none;
}

.history-table td {
    padding: 0.8rem 1rem;
    color: #2c3e50;
    border-bottom: 1px solid #ecf0f1;
    font-weight: 600;
}

.history-table tbody tr:hover {
    background: #f8f9fa;
}

.history-table tbody tr:nth-child(even) {
    background: #ecf0f1;
}

/* فرم ویرایش */
.form-section {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    border: 2px solid #95a5a6;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.form-section h4 {
    color: #2c3e50;
    font-size: 1.2rem;
    font-weight: 700;
    margin: 0 0 1rem 0;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #ecf0f1;
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #2c3e50;
    font-size: 0.9rem;
}

.required {
    color: #e74c3c;
    font-weight: bold;
}

.form-group input {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid #bdc3c7;
    border-radius: 10px;
    font-family: inherit;
    font-size: 1rem;
    background: white;
    color: #2c3e50;
    transition: all 0.3s ease;
    font-weight: 600;
}

.readonly-input {
    background: #ecf0f1 !important;
    color: #7f8c8d !important;
    border-color: #95a5a6 !important;
    cursor: not-allowed;
}

.editable-input:focus {
    outline: none;
    border-color: #3498db !important;
    box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2) !important;
    background: #f8f9fa !important;
}

/* دکمه‌ها */
.btn {
    padding: 0.8rem 1.5rem;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 700;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: inherit;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.btn-primary {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #2980b9, #1f4e79);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(52, 152, 219, 0.4);
}

.btn-secondary {
    background: linear-gradient(135deg, #95a5a6, #7f8c8d);
    color: white;
}

.btn-secondary:hover {
    background: linear-gradient(135deg, #7f8c8d, #6c7b7b);
    transform: translateY(-2px);
}

.btn-success {
    background: linear-gradient(135deg, #27ae60, #229954);
    color: white;
}

.btn-success:hover {
    background: linear-gradient(135deg, #229954, #1e8449);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(39, 174, 96, 0.4);
}

/* انیمیشن‌ها */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(50px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ریسپانسیو */
@media (max-width: 768px) {
    .student-full-info {
        flex-direction: column;
        gap: 1rem;
    }
    
    .student-profile {
        justify-content: center;
        text-align: center;
    }
    
    .student-quick-stats {
        grid-template-columns: 1fr 1fr;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .analysis-modal .modal-body {
        padding: 1.5rem;
    }
    
    .analysis-modal .modal-footer {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
}

/* اصلاح score badge ها */
.score-badge {
    display: inline-block;
    padding: 0.3rem 0.8rem;
    border-radius: 15px;
    font-weight: 600;
    font-size: 0.9rem;
    color: white;
}

.accuracy-badge {
    padding: 0.2rem 0.6rem;
    border-radius: 10px;
    font-size: 0.8rem;
    font-weight: 600;
    color: white;
}
</style>
`;

// جایگزین کردن CSS قدیمی با جدید
document.head.insertAdjacentHTML('beforeend', fixedModalCSS);
// اضافه کردن این بخش در انتهای کد
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        // بستن هر مودالی که باز است
        if (document.getElementById('studentDetailsModal')?.classList.contains('show')) {
            ResultsAnalysis.closeStudentModal();
        }
        if (document.getElementById('editResultModal')?.classList.contains('show')) {
            ResultsAnalysis.closeEditModal();
        }
    }
});
// اطمینان از مشکی بودن فونت جدول
function fixBadgesTableColors() {
    const table = document.querySelector('.badges-table');
    if (table) {
        const cells = table.querySelectorAll('td');
        cells.forEach(cell => {
            cell.style.color = '#000';
            cell.style.backgroundColor = '#fff';
        });
    }
}

// اجرا بعد از بارگذاری داده‌ها
setTimeout(fixBadgesTableColors, 1000);

// اجرا مجدد بعد از هر بروزرسانی
const originalRenderTable = renderBadgesTable;
if (typeof renderBadgesTable === 'function') {
    renderBadgesTable = function(...args) {
        originalRenderTable.apply(this, args);
        fixBadgesTableColors();
    };
}
// اجبار مشکی کردن فونت در نمایش کارتی
function fixCardViewColors() {
    const cards = document.querySelectorAll('.badge-card');
    cards.forEach(card => {
        card.style.backgroundColor = '#fff';
        card.style.color = '#000';
        
        // تمام المان‌های داخل را مشکی کن
        const elements = card.querySelectorAll('*:not(.level-badge):not(.btn-action)');
        elements.forEach(el => {
            el.style.color = '#000';
        });
    });
}

// اجرا بعد از تغییر به نمایش کارتی
const originalToggle = toggleBadgeViewMode;
toggleBadgeViewMode = function() {
    originalToggle();
    setTimeout(fixCardViewColors, 100);
};

// اجرا بعد از render کردن کارت‌ها
const originalRender = renderBadgesTable;
renderBadgesTable = function(...args) {
    originalRender.apply(this, args);
    if (currentViewMode === 'card') {
        setTimeout(fixCardViewColors, 100);
    }
};
    </script>
    
</body>
</html>