<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// بررسی دسترسی
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// تابع دریافت سال‌های موجود
function getAvailableYears($conn) {
    $stmt = $conn->query("SELECT DISTINCT year FROM weekly_xp_summary ORDER BY year DESC");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// دریافت داده‌های اولیه برای فیلترها
 $availableYears = getAvailableYears($conn);
 $currentYear = !empty($availableYears) ? $availableYears[0] : null;

 $monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
               'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد تحلیل عملکرد - استارماه</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        /* ... تمام استایل‌های قبلی را بدون تغییر نگه دارید ... */
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            --warning-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --dark-bg: #0f0f23;
            --card-bg: #1a1a2e;
            --card-hover: #252542;
            --text-primary: #ffffff;
            --text-secondary: #b8b9c9;
            --border-color: #2d2d44;
            --success-color: #38ef7d;
            --warning-color: #f5576c;
            --danger-color: #ff6b6b;
            --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.3);
            --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.4);
            --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.5);
        }

        body {
            font-family: 'Vazirmatn', sans-serif;
            background: var(--dark-bg);
            color: var(--text-primary);
            min-height: 100vh;
            padding: 20px;
            background-image: 
                radial-gradient(circle at 20% 50%, rgba(102, 126, 234, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(118, 75, 162, 0.05) 0%, transparent 50%);
        }

        .container { max-width: 1800px; margin: 0 auto; }
        
        /* استایل دکمه بازگشت */
        .back-button-container {
            margin-bottom: 20px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 24px;
            background: var(--card-bg);
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            border: 2px solid var(--border-color);
            transition: all 0.3s ease;
        }
        .back-button:hover {
            color: var(--text-primary);
            border-color: var(--accent-color);
            transform: translateX(-5px);
        }

        .header { text-align: center; margin-bottom: 40px; padding: 30px 20px; background: var(--card-bg); border-radius: 20px; box-shadow: var(--shadow-md); border: 1px solid var(--border-color); position: relative; overflow: hidden; }
        .header::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: var(--primary-gradient); }
        .header h1 { font-size: 2.5rem; font-weight: 800; background: var(--primary-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; gap: 15px; }
        .header p { color: var(--text-secondary); font-size: 1rem; }

        .controls { display: flex; flex-direction: column; gap: 20px; margin-bottom: 40px; padding: 25px; background: var(--card-bg); border-radius: 20px; box-shadow: var(--shadow-md); border: 1px solid var(--border-color); }
        .control-row { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
        .control-group { display: flex; align-items: center; gap: 10px; }
        .control-group label { font-weight: 600; color: var(--text-secondary); font-size: 1.1rem; white-space: nowrap; }
        .control-group select { padding: 12px 20px; border-radius: 12px; border: 2px solid var(--border-color); background: var(--dark-bg); color: var(--text-primary); font-size: 1rem; font-family: 'Vazirmatn', sans-serif; font-weight: 500; cursor: pointer; transition: all 0.3s ease; min-width: 150px; }
        .control-group select:hover { border-color: #667eea; }
        .control-group select:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2); }
        .filter-type-selector { font-size: 1.1rem; font-weight: 600; }
        .filter-details { display: none; padding-top: 15px; border-top: 1px solid var(--border-color); margin-top: 15px; }
        .filter-details.active { display: flex; }
        
        /* ... بقیه استایل‌های کارت‌ها، جدول‌ها و نمودارها را بدون تغییر نگه دارید ... */
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 40px; }
        .summary-card { background: var(--card-bg); border-radius: 20px; padding: 30px; box-shadow: var(--shadow-md); border: 1px solid var(--border-color); position: relative; overflow: hidden; transition: all 0.3s ease; }
        .summary-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); border-color: rgba(102, 126, 234, 0.5); }
        .summary-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; }
        .summary-card.total-xp::before { background: var(--primary-gradient); }
        .summary-card.active-students::before { background: var(--success-gradient); }
        .summary-card.avg-xp::before { background: var(--warning-gradient); }
        .summary-card.total-students::before { background: var(--info-gradient); }
        .summary-card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .summary-card-icon { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; }
        .total-xp .summary-card-icon { background: rgba(102, 126, 234, 0.15); color: #667eea; }
        .active-students .summary-card-icon { background: rgba(56, 239, 125, 0.15); color: #38ef7d; }
        .avg-xp .summary-card-icon { background: rgba(245, 87, 108, 0.15); color: #f5576c; }
        .total-students .summary-card-icon { background: rgba(79, 172, 254, 0.15); color: #4facfe; }
        .summary-card-value { font-size: 2.5rem; font-weight: 800; margin-bottom: 8px; line-height: 1; }
        .summary-card-label { color: var(--text-secondary); font-size: 0.95rem; font-weight: 500; }
        .dashboard-grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 25px; }
        .card { background: var(--card-bg); border-radius: 20px; padding: 30px; box-shadow: var(--shadow-md); border: 1px solid var(--border-color); transition: all 0.3s ease; }
        .card:hover { box-shadow: var(--shadow-lg); }
        .card-header { display: flex; align-items: center; gap: 12px; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 2px solid var(--border-color); }
        .card-header i { font-size: 1.5rem; background: var(--primary-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .card-header h2 { font-size: 1.4rem; font-weight: 700; }
        .card-6 { grid-column: span 6; }
        .card-12 { grid-column: span 12; }
        .data-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 0.95rem; }
        .data-table thead th { padding: 15px 12px; text-align: right; background: var(--dark-bg); color: var(--text-secondary); font-weight: 600; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 0.5px; position: sticky; top: 0; z-index: 10; }
        .data-table thead th:first-child { border-top-right-radius: 12px; }
        .data-table thead th:last-child { border-top-left-radius: 12px; }
        .data-table tbody tr { transition: all 0.2s ease; }
        .data-table tbody tr:hover { background: var(--card-hover); }
        .data-table tbody td { padding: 16px 12px; border-bottom: 1px solid var(--border-color); color: var(--text-primary); }
        .rank-badge { display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 50%; font-weight: 700; font-size: 0.9rem; box-shadow: var(--shadow-sm); }
        .rank-1 { background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%); color: #000; }
        .rank-2 { background: linear-gradient(135deg, #C0C0C0 0%, #808080 100%); color: #000; }
        .rank-3 { background: linear-gradient(135deg, #CD7F32 0%, #8B4513 100%); color: #fff; }
        .rank-default { background: var(--dark-bg); color: var(--text-secondary); border: 2px solid var(--border-color); }
        .xp-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 20px; background: rgba(102, 126, 234, 0.15); color: #667eea; font-weight: 600; font-size: 0.9rem; }
        .analysis-btn { display: inline-flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 10px; background: rgba(102, 126, 234, 0.15); color: #667eea; font-size: 1rem; transition: all 0.2s ease; cursor: pointer; border: none; }
        .analysis-btn:hover { background: var(--primary-gradient); color: white; transform: scale(1.1); }
        .attention-list { list-style: none; }
        .attention-item { padding: 18px; margin-bottom: 12px; border-radius: 12px; background: rgba(255, 107, 107, 0.1); border-right: 4px solid var(--danger-color); display: flex; justify-content: space-between; align-items: center; transition: all 0.2s ease; }
        .attention-item:hover { background: rgba(255, 107, 107, 0.15); transform: translateX(-5px); }
        .attention-name { font-weight: 600; color: var(--text-primary); }
        .attention-xp { color: var(--danger-color); font-weight: 700; font-size: 1.1rem; }
        .search-box { position: relative; margin-bottom: 20px; }
        .search-box input { width: 100%; padding: 14px 20px 14px 50px; border-radius: 12px; border: 2px solid var(--border-color); background: var(--dark-bg); color: var(--text-primary); font-size: 1rem; font-family: 'Vazirmatn', sans-serif; transition: all 0.3s ease; }
        .search-box input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2); }
        .search-box i { position: absolute; right: 18px; top: 50%; transform: translateY(-50%); color: var(--text-secondary); font-size: 1.1rem; }
        .table-container { max-height: 500px; overflow-y: auto; border-radius: 12px; }
        .table-container::-webkit-scrollbar { width: 8px; }
        .table-container::-webkit-scrollbar-track { background: var(--dark-bg); border-radius: 4px; }
        .table-container::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 4px; }
        .table-container::-webkit-scrollbar-thumb:hover { background: #667eea; }
        .chart-wrapper { position: relative; height: 350px; }
        .loading-state, .empty-state, .error-state { text-align: center; padding: 60px 20px; }
        .loading-state i { font-size: 3rem; color: #667eea; animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .empty-state i { font-size: 4rem; color: var(--text-secondary); margin-bottom: 20px; }
        .empty-state p { color: var(--text-secondary); font-size: 1.1rem; }
        .error-state { color: var(--danger-color); }
        @media (max-width: 1400px) { .card-6 { grid-column: span 12; } }
        @media (max-width: 768px) { .header h1 { font-size: 1.8rem; flex-direction: column; gap: 10px; } .summary-grid { grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); } .controls { flex-direction: column; } .control-row { flex-direction: column; align-items: stretch; } .control-group select { width: 100%; } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .summary-card, .card { animation: fadeInUp 0.5s ease forwards; opacity: 0; }
        .summary-card:nth-child(1) { animation-delay: 0.1s; }
        .summary-card:nth-child(2) { animation-delay: 0.2s; }
        .summary-card:nth-child(3) { animation-delay: 0.3s; }
        .summary-card:nth-child(4) { animation-delay: 0.4s; }
        .card:nth-child(1) { animation-delay: 0.5s; }
        .card:nth-child(2) { animation-delay: 0.6s; }
        .card:nth-child(3) { animation-delay: 0.7s; }
        .card:nth-child(4) { animation-delay: 0.8s; }
        /* استایل کانتینر دکمه‌ها */
.action-buttons-container {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    flex-wrap: wrap;
    align-items: stretch;
}

/* استایل دکمه بازگشت - به‌روزرسانی شده */
.back-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 20px 30px;
    background: var(--card-bg);
    color: var(--text-secondary);
    text-decoration: none;
    border-radius: 16px;
    font-weight: 600;
    font-size: 1rem;
    border: 2px solid var(--border-color);
    transition: all 0.3s ease;
    white-space: nowrap;
    flex-shrink: 0;
}

.back-button:hover {
    color: var(--text-primary);
    border-color: #667eea;
    transform: translateX(-5px);
    box-shadow: 0 4px 20px rgba(102, 126, 234, 0.2);
}

.back-button i {
    font-size: 1.2rem;
}

/* استایل دکمه به‌روزرسانی - به‌روزرسانی شده */
.update-button {
    display: flex;
    align-items: center;
    gap: 15px;
    flex: 1;
    min-width: 400px;
    padding: 20px 25px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: var(--text-primary);
    border: none;
    border-radius: 16px;
    font-family: 'Vazirmatn', sans-serif;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
    position: relative;
    overflow: hidden;
}

.update-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
}

.update-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(102, 126, 234, 0.5);
}

.update-button:hover::before {
    left: 100%;
}

.update-button:active {
    transform: translateY(-1px);
}

.update-button.updating {
    pointer-events: none;
    opacity: 0.8;
}

.update-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 50px;
    height: 50px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 12px;
    font-size: 1.5rem;
    flex-shrink: 0;
    backdrop-filter: blur(10px);
}

.update-button.updating .update-icon i {
    animation: spin-smooth 1s linear infinite;
}

@keyframes spin-smooth {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.update-text {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
    flex: 1;
    text-align: right;
}

.update-title {
    font-size: 1.1rem;
    font-weight: 700;
    line-height: 1.2;
}

.update-subtitle {
    font-size: 0.85rem;
    font-weight: 400;
    opacity: 0.9;
    direction: rtl;
}

#last-update-time {
    font-weight: 600;
    color: #ffd700;
}

.update-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    background: rgba(255, 215, 0, 0.2);
    border-radius: 50%;
    font-size: 1rem;
    color: #ffd700;
    flex-shrink: 0;
    animation: pulse-glow 2s ease-in-out infinite;
}

@keyframes pulse-glow {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.4);
    }
    50% {
        box-shadow: 0 0 0 8px rgba(255, 215, 0, 0);
    }
}

.update-status {
    margin-bottom: 20px;
    padding: 15px 20px;
    border-radius: 12px;
    font-size: 0.95rem;
    font-weight: 500;
    display: none;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.update-status.show {
    display: block;
}

.update-status.success {
    background: rgba(56, 239, 125, 0.15);
    border: 2px solid rgba(56, 239, 125, 0.3);
    color: var(--success-color);
}

.update-status.error {
    background: rgba(255, 107, 107, 0.15);
    border: 2px solid rgba(255, 107, 107, 0.3);
    color: var(--danger-color);
}

.update-status.info {
    background: rgba(79, 172, 254, 0.15);
    border: 2px solid rgba(79, 172, 254, 0.3);
    color: #4facfe;
}

.update-status i {
    margin-left: 8px;
}

/* Responsive */
@media (max-width: 1024px) {
    .action-buttons-container {
        flex-direction: column;
    }
    
    .back-button {
        width: 100%;
        justify-content: center;
    }
    
    .update-button {
        min-width: 100%;
    }
}

@media (max-width: 768px) {
    .update-button {
        padding: 18px 20px;
    }
    
    .update-icon {
        width: 45px;
        height: 45px;
        font-size: 1.3rem;
    }
    
    .update-title {
        font-size: 1rem;
    }
    
    .update-subtitle {
        font-size: 0.8rem;
    }
    
    .back-button {
        padding: 18px 25px;
        font-size: 0.95rem;
    }
}
    </style>
</head>
<body>

<div class="container">
    <!-- دکمه‌های بازگشت و به‌روزرسانی - جایگزین کنید -->
<div class="action-buttons-container">
    <a href="../index.php" class="back-button">
        <i class="fas fa-arrow-right"></i>
        بازگشت به پنل مدیریت
    </a>
    
    <button id="update-database-btn" class="update-button">
        <span class="update-icon">
            <i class="fas fa-sync-alt"></i>
        </span>
        <span class="update-text">
            <span class="update-title">به‌روزرسانی بانک اطلاعاتی</span>
            <span class="update-subtitle">آخرین بروزرسانی: <span id="last-update-time">در حال بارگذاری...</span></span>
        </span>
        <span class="update-badge">
            <i class="fas fa-bolt"></i>
        </span>
    </button>
</div>
<div id="update-status" class="update-status"></div>
    <!-- هدر -->
    <div class="header">
        <h1>
            <i class="fas fa-chart-line"></i>
            داشبورد تحلیل عملکرد
        </h1>
        <p>سیستم جامع رصد و ارزیابی پیشرفت دانش‌آموزان</p>
    </div>

    <!-- کنترل‌های جدید -->
    <section class="controls">
        <div class="control-row">
            <div class="control-group">
                <label for="filter-type">نمایش بر اساس:</label>
                <select id="filter-type" class="filter-type-selector">
                    <option value="overall">کلی (همه زمان‌ها)</option>
                    <option value="yearly">از ابتدای سال تحصیلی</option>
                    <option value="monthly">به تفکیک ماه</option>
                    <option value="weekly" selected>به تفکیک هفته</option>
                </select>
            </div>
        </div>

        <!-- جزئیات فیلتر کلی -->
        <div id="filter-overall" class="filter-details">
            <p>تمام داده‌های موجود از ابتدا تا به امروز نمایش داده می‌شود.</p>
        </div>

        <!-- جزئیات فیلتر سالانه -->
        <div id="filter-yearly" class="filter-details">
            <div class="control-group">
                <label for="year-selector">سال تحصیلی:</label>
                <select id="year-selector">
                    <?php foreach ($availableYears as $year): ?>
                        <option value="<?= $year ?>"><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- جزئیات فیلتر ماهانه -->
        <div id="filter-monthly" class="filter-details">
            <div class="control-row">
                <div class="control-group">
                    <label for="month-year-selector">سال:</label>
                    <select id="month-year-selector">
                        <?php foreach ($availableYears as $year): ?>
                            <option value="<?= $year ?>"><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="control-group">
                    <label for="month-selector">ماه:</label>
                    <select id="month-selector">
                        <option value="">در حال بارگذاری...</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- جزئیات فیلتر هفتگی -->
        <div id="filter-weekly" class="filter-details active">
            <div class="control-row">
                <div class="control-group">
                    <label for="week-year-selector">سال:</label>
                    <select id="week-year-selector">
                        <?php foreach ($availableYears as $year): ?>
                            <option value="<?= $year ?>"><?= $year ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="control-group">
                    <label for="week-month-selector">ماه:</label>
                    <select id="week-month-selector">
                        <option value="">در حال بارگذاری...</option>
                    </select>
                </div>
                <div class="control-group">
                    <label for="week-selector">هفته:</label>
                    <select id="week-selector">
                        <option value="">در حال بارگذاری...</option>
                    </select>
                </div>
            </div>
        </div>
    </section>

    <!-- کارت‌های خلاصه و داشبورد اصلی (بدون تغییر) -->
    <section class="summary-grid" id="summary-section">
        <div class="summary-card total-xp"><div class="summary-card-header"><div class="summary-card-icon"><i class="fas fa-trophy"></i></div></div><div class="summary-card-value" id="total-xp-value">-</div><div class="summary-card-label">کل امتیاز کلاس</div></div>
        <div class="summary-card active-students"><div class="summary-card-header"><div class="summary-card-icon"><i class="fas fa-user-check"></i></div></div><div class="summary-card-value" id="active-students-value">-</div><div class="summary-card-label">دانش‌آموزان فعال</div></div>
        <div class="summary-card avg-xp"><div class="summary-card-header"><div class="summary-card-icon"><i class="fas fa-chart-bar"></i></div></div><div class="summary-card-value" id="avg-xp-value">-</div><div class="summary-card-label">میانگین امتیاز</div></div>
        <div class="summary-card total-students"><div class="summary-card-header"><div class="summary-card-icon"><i class="fas fa-users"></i></div></div><div class="summary-card-value" id="total-students-value">-</div><div class="summary-card-label">تعداد کل دانش‌آموزان</div></div>
    </section>
    <main class="dashboard-grid">
        <div class="card card-6"><div class="card-header"><i class="fas fa-star"></i><h2>ستاره‌های برتر</h2></div><div id="top-performers-content"><div class="loading-state"><i class="fas fa-spinner"></i></div></div></div>
        <div class="card card-6"><div class="card-header"><i class="fas fa-exclamation-triangle"></i><h2>نیازمند توجه</h2></div><div id="needs-attention-content"><div class="loading-state"><i class="fas fa-spinner"></i></div></div></div>
        <div class="card card-12"><div class="card-header"><i class="fas fa-chart-area"></i><h2>نمودار مشارکت کلاسی (۱۰ برتر)</h2></div><div class="chart-wrapper"><canvas id="participation-chart"></canvas></div></div>
        <div class="card card-12"><div class="card-header"><i class="fas fa-list"></i><h2>لیست کامل دانش‌آموزان</h2></div><div class="search-box"><i class="fas fa-search"></i><input type="text" id="student-search" placeholder="جستجوی نام یا نام خانوادگی..."></div><div class="table-container"><div id="full-student-list-content"><div class="loading-state"><i class="fas fa-spinner"></i></div></div></div></div>
    </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 صفحه بارگذاری شد');
    
    const filterType = document.getElementById('filter-type');
    const studentSearch = document.getElementById('student-search');
    
    // عناصر انتخابگر
    const yearSelector = document.getElementById('year-selector');
    const monthYearSelector = document.getElementById('month-year-selector');
    const monthSelector = document.getElementById('month-selector');
    const weekYearSelector = document.getElementById('week-year-selector');
    const weekMonthSelector = document.getElementById('week-month-selector');
    const weekSelector = document.getElementById('week-selector');

    let allStudentsData = [];
    let participationChart = null;

    // تابع برای نمایش جزئیات فیلتر مناسب
    function showFilterDetails(type) {
        console.log('📋 نمایش فیلتر:', type);
        document.querySelectorAll('.filter-details').forEach(detail => detail.classList.remove('active'));
        const activeDetail = document.getElementById(`filter-${type}`);
        if (activeDetail) {
            activeDetail.classList.add('active');
        }
    }

    // تابع برای به‌روزرسانی dropdown ماه‌ها
    async function updateMonths(yearSelector, monthSelector) {
        const year = yearSelector.value;
        if (!year) {
            console.warn('⚠️ سال انتخاب نشده');
            monthSelector.innerHTML = '<option value="">ابتدا سال را انتخاب کنید</option>';
            return;
        }
        
        console.log('📅 دریافت ماه‌ها برای سال:', year);
        monthSelector.innerHTML = '<option value="">در حال بارگذاری...</option>';
        
        try {
            const url = `../ajax/get_weekly_data_all.php?mode=get_months&year=${year}`;
            console.log('🌐 URL:', url);
            
            const response = await fetch(url);
            const responseText = await response.text();
            console.log('📥 پاسخ خام ماه‌ها:', responseText);
            
            let months;
            try {
                months = JSON.parse(responseText);
            } catch (e) {
                console.error('❌ خطا در تجزیه JSON:', e);
                throw new Error('پاسخ سرور معتبر نیست');
            }
            
            console.log('✅ ماه‌های دریافت شده:', months);
            
            if (!Array.isArray(months) || months.length === 0) {
                monthSelector.innerHTML = '<option value="">ماهی یافت نشد</option>';
                return;
            }
            
            monthSelector.innerHTML = months.map(m => 
                `<option value="${m.value}">${m.label}</option>`
            ).join('');
            
            // اگر ماهی وجود داشت، اولین ماه را انتخاب کن
            if (months.length > 0) {
                monthSelector.value = months[0].value;
                // اگر در حالت monthly هستیم، داده‌ها را بارگذاری کن
                if (filterType.value === 'monthly') {
                    fetchAnalysisData();
                }
            }
        } catch (error) {
            console.error('❌ خطا در دریافت ماه‌ها:', error);
            monthSelector.innerHTML = '<option value="">خطا در بارگذاری</option>';
            showErrorState('خطا در دریافت لیست ماه‌ها: ' + error.message);
        }
    }

    // تابع برای به‌روزرسانی dropdown هفته‌ها
    async function updateWeeks(yearSelector, monthSelector, weekSelector) {
        const year = yearSelector.value;
        const month = monthSelector.value;
        
        console.log('🔍 updateWeeks فراخوانی شد:', {year, month});
        
        if (!year) {
            console.warn('⚠️ سال انتخاب نشده');
            weekSelector.innerHTML = '<option value="">ابتدا سال را انتخاب کنید</option>';
            return;
        }
        
        if (!month) {
            console.warn('⚠️ ماه انتخاب نشده');
            weekSelector.innerHTML = '<option value="">ابتدا ماه را انتخاب کنید</option>';
            return;
        }

        console.log('📅 دریافت هفته‌ها برای:', {year, month});
        weekSelector.innerHTML = '<option value="">در حال بارگذاری...</option>';
        
        try {
            const url = `../ajax/get_weekly_data_all.php?mode=get_weeks&year=${year}&month=${month}`;
            console.log('🌐 URL:', url);
            
            const response = await fetch(url);
            const responseText = await response.text();
            console.log('📥 پاسخ خام هفته‌ها:', responseText);
            
            let weeks;
            try {
                weeks = JSON.parse(responseText);
            } catch (e) {
                console.error('❌ خطا در تجزیه JSON:', e);
                throw new Error('پاسخ سرور معتبر نیست');
            }
            
            console.log('✅ هفته‌های دریافت شده:', weeks);
            
            if (!Array.isArray(weeks) || weeks.length === 0) {
                weekSelector.innerHTML = '<option value="">هفته‌ای یافت نشد</option>';
                showEmptyState();
                return;
            }
            
            weekSelector.innerHTML = weeks.map(w => 
                `<option value="${w.value}">${w.label}</option>`
            ).join('');
            
            // اگر هفته‌ای وجود داشت، اولین هفته را انتخاب کن
            if (weeks.length > 0) {
                weekSelector.value = weeks[0].value;
                console.log('✅ هفته انتخاب شد:', weeks[0].value);
                // فقط در فیلتر هفتگی، با تغییر هفته داده‌ها را بارگذاری کن
                if (filterType.value === 'weekly') {
                    fetchAnalysisData();
                }
            }
        } catch (error) {
            console.error('❌ خطا در دریافت هفته‌ها:', error);
            weekSelector.innerHTML = '<option value="">خطا در بارگذاری</option>';
            showErrorState('خطا در دریافت لیست هفته‌ها: ' + error.message);
        }
    }

    // بارگذاری داده‌ها بر اساس فیلتر انتخاب شده
    async function fetchAnalysisData() {
        const type = filterType.value;
        let url = `../ajax/get_weekly_data_all.php?type=${type}`;

        console.log('📊 دریافت داده‌ها با نوع:', type);

        if (type === 'yearly') {
            url += `&year=${yearSelector.value}`;
        } else if (type === 'monthly') {
            const year = monthYearSelector.value;
            const month = monthSelector.value;
            if (!year || !month) {
                console.warn('⚠️ سال یا ماه انتخاب نشده');
                showEmptyState();
                return;
            }
            url += `&year=${year}&month=${month}`;
        } else if (type === 'weekly') {
            const weekValue = weekSelector.value;
            if(!weekValue) {
                console.warn('⚠️ هفته انتخاب نشده');
                showEmptyState();
                return;
            }
            url += `&week=${weekValue}`;
        }

        console.log('🌐 URL نهایی:', url);
        showLoadingState();
        
        try {
            const response = await fetch(url);
            const responseText = await response.text();
            console.log('📥 پاسخ خام (اول 500 کاراکتر):', responseText.substring(0, 500));
            
            let result;
            try {
                result = JSON.parse(responseText);
            } catch (e) {
                console.error('❌ خطا در تجزیه JSON:', e);
                console.error('📄 محتوای کامل:', responseText);
                throw new Error('پاسخ سرور معتبر نیست');
            }
            
            console.log('✅ نتیجه:', result);
            
            if (!response.ok) {
                throw new Error(result.message || 'خطا در دریافت اطلاعات از سرور');
            }
            
            if (!result.success) {
                throw new Error(result.message || 'خطای نامشخص');
            }

            allStudentsData = result.data || [];
            console.log('👥 تعداد دانش‌آموزان:', allStudentsData.length);
            
            renderDashboard(allStudentsData);

        } catch (error) {
            console.error('❌ خطا:', error);
            showErrorState(error.message);
        }
    }
    
    // رویدادها
    filterType.addEventListener('change', (e) => {
        console.log('🔄 تغییر نوع فیلتر به:', e.target.value);
        showFilterDetails(e.target.value);
        
        if (e.target.value === 'weekly') {
            // بارگذاری ماه‌ها برای سال انتخاب شده
            const year = weekYearSelector.value;
            if (year) {
                updateMonths(weekYearSelector, weekMonthSelector);
            }
        } else if (e.target.value === 'monthly') {
            // بارگذاری ماه‌ها برای سال انتخاب شده
            const year = monthYearSelector.value;
            if (year) {
                updateMonths(monthYearSelector, monthSelector);
            }
        } else {
            fetchAnalysisData();
        }
    });

    yearSelector.addEventListener('change', () => {
        console.log('📅 تغییر سال (yearly)');
        fetchAnalysisData();
    });
    
    monthYearSelector.addEventListener('change', () => {
        console.log('📅 تغییر سال (monthly)');
        updateMonths(monthYearSelector, monthSelector);
    });
    
    monthSelector.addEventListener('change', () => {
        console.log('📅 تغییر ماه (monthly)');
        fetchAnalysisData();
    });
    
    weekYearSelector.addEventListener('change', () => {
        console.log('📅 تغییر سال (weekly)');
        // بارگذاری ماه‌ها با سال جدید
        updateMonths(weekYearSelector, weekMonthSelector).then(() => {
            // بعد از بارگذاری ماه‌ها، هفته‌ها را بارگذاری کن
            const month = weekMonthSelector.value;
            if (month) {
                updateWeeks(weekYearSelector, weekMonthSelector, weekSelector);
            }
        });
    });
    
    weekMonthSelector.addEventListener('change', () => {
        console.log('📅 تغییر ماه (weekly)');
        updateWeeks(weekYearSelector, weekMonthSelector, weekSelector);
    });
    
    weekSelector.addEventListener('change', () => {
        console.log('📅 تغییر هفته');
        fetchAnalysisData();
    });

    studentSearch.addEventListener('input', (e) => {
        renderFullStudentList(allStudentsData, e.target.value);
    });

    // بارگذاری اولیه
    console.log('🎬 شروع بارگذاری اولیه');
    showFilterDetails('weekly');
    
    // بارگذاری ماه‌ها برای سال پیش‌فرض
    const initialYear = weekYearSelector.value;
    console.log('📅 سال اولیه:', initialYear);
    
    if (initialYear) {
        updateMonths(weekYearSelector, weekMonthSelector).then(() => {
            console.log('✅ ماه‌ها بارگذاری شدند');
            // بعد از بارگذاری ماه‌ها، هفته‌ها را بارگذاری کن
            const month = weekMonthSelector.value;
            if (month) {
                console.log('📅 بارگذاری هفته‌ها برای ماه:', month);
                updateWeeks(weekYearSelector, weekMonthSelector, weekSelector);
            }
        }).catch(err => {
            console.error('❌ خطا در بارگذاری اولیه:', err);
        });
    }

    // توابع رندر (بدون تغییر)
    function renderDashboard(data) {
        console.log('🎨 رندر داشبورد با', data.length, 'دانش‌آموز');
        renderSummaryCards(data);
        renderTopPerformers(data);
        renderNeedsAttention(data);
        renderParticipationChart(data);
        renderFullStudentList(data);
    }
    
    function renderSummaryCards(data) {
        const totalXP = data.reduce((sum, s) => sum + parseInt(s.total_xp || 0), 0);
        const activeStudents = data.filter(s => parseInt(s.total_xp || 0) > 0).length;
        const avgXP = data.length > 0 ? Math.round(totalXP / data.length) : 0;
        
        document.getElementById('total-xp-value').textContent = totalXP.toLocaleString('fa-IR');
        document.getElementById('active-students-value').textContent = activeStudents.toLocaleString('fa-IR');
        document.getElementById('avg-xp-value').textContent = avgXP.toLocaleString('fa-IR');
        document.getElementById('total-students-value').textContent = data.length.toLocaleString('fa-IR');
    }
    
    function renderTopPerformers(data) {
        const container = document.getElementById('top-performers-content');
        const topStudents = [...data]
            .filter(s => parseInt(s.total_xp || 0) > 0)
            .sort((a, b) => parseInt(b.total_xp) - parseInt(a.total_xp))
            .slice(0, 10);
        
        if (topStudents.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-inbox"></i><p>هنوز هیچ دانش‌آموز فعالی ثبت نشده است</p></div>';
            return;
        }
        
        const tableHTML = `<table class="data-table">
            <thead>
                <tr>
                    <th>رتبه</th>
                    <th>نام دانش‌آموز</th>
                    <th>امتیاز</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                ${topStudents.map((student, index) => `
                    <tr>
                        <td><span class="rank-badge ${getRankClass(index + 1)}">${(index + 1).toLocaleString('fa-IR')}</span></td>
                        <td>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</td>
                        <td><span class="xp-badge"><i class="fas fa-star"></i>${parseInt(student.total_xp).toLocaleString('fa-IR')}</span></td>
                        <td><button class="analysis-btn" onclick="viewStudentAnalysis(${student.student_id})" title="مشاهده تحلیل"><i class="fas fa-chart-line"></i></button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>`;
        
        container.innerHTML = tableHTML;
    }
    
    function renderNeedsAttention(data) {
        const container = document.getElementById('needs-attention-content');
        const needsAttention = [...data]
            .filter(s => parseInt(s.total_xp || 0) === 0)
            .sort((a, b) => `${a.first_name} ${a.last_name}`.localeCompare(`${b.first_name} ${b.last_name}`))
            .slice(0, 15);
        
        if (needsAttention.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-check-circle"></i><p>همه دانش‌آموزان فعال هستند!</p></div>';
            return;
        }
        
        const listHTML = `<ul class="attention-list">
            ${needsAttention.map(student => `
                <li class="attention-item">
                    <span class="attention-name">${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</span>
                    <span class="attention-xp"><i class="fas fa-exclamation-circle"></i>${parseInt(student.total_xp).toLocaleString('fa-IR')} امتیاز</span>
                </li>
            `).join('')}
        </ul>`;
        
        container.innerHTML = listHTML;
    }
    
    function renderParticipationChart(data) {
        const chartCanvas = document.getElementById('participation-chart');
        const topStudents = [...data]
            .filter(s => parseInt(s.total_xp || 0) > 0)
            .sort((a, b) => parseInt(b.total_xp) - parseInt(a.total_xp))
            .slice(0, 10);
        
        if (topStudents.length === 0) {
            chartCanvas.parentElement.innerHTML = '<div class="empty-state"><i class="fas fa-chart-bar"></i><p>داده‌ای برای نمایش وجود ندارد</p></div>';
            return;
        }
        
        if (participationChart) {
            participationChart.destroy();
        }
        
        const ctx = chartCanvas.getContext('2d');
        participationChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: topStudents.map(s => `${s.first_name} ${s.last_name}`),
                datasets: [{
                    label: 'امتیاز',
                    data: topStudents.map(s => parseInt(s.total_xp)),
                    backgroundColor: topStudents.map((_, i) => {
                        if (i === 0) return 'rgba(255, 215, 0, 0.8)';
                        if (i === 1) return 'rgba(192, 192, 192, 0.8)';
                        if (i === 2) return 'rgba(205, 127, 50, 0.8)';
                        return 'rgba(102, 126, 234, 0.6)';
                    }),
                    borderColor: topStudents.map((_, i) => {
                        if (i === 0) return '#FFD700';
                        if (i === 1) return '#C0C0C0';
                        if (i === 2) return '#CD7F32';
                        return '#667eea';
                    }),
                    borderWidth: 2,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(26, 26, 46, 0.95)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#667eea',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return `امتیاز: ${context.parsed.y.toLocaleString('fa-IR')}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(45, 45, 68, 0.5)',
                            borderColor: 'rgba(45, 45, 68, 0.5)'
                        },
                        ticks: {
                            color: '#b8b9c9',
                            font: { family: 'Vazirmatn' },
                            callback: function(value) {
                                return value.toLocaleString('fa-IR');
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                            borderColor: 'rgba(45, 45, 68, 0.5)'
                        },
                        ticks: {
                            color: '#b8b9c9',
                            font: { family: 'Vazirmatn' }
                        }
                    }
                }
            }
        });
    }
    
    function renderFullStudentList(data, searchTerm = '') {
        const container = document.getElementById('full-student-list-content');
        let filteredData = data;
        
        if (searchTerm) {
            const term = searchTerm.toLowerCase();
            filteredData = data.filter(s => 
                s.first_name.toLowerCase().includes(term) || 
                s.last_name.toLowerCase().includes(term)
            );
        }
        
        const sortedData = [...filteredData].sort((a, b) => 
            parseInt(b.total_xp || 0) - parseInt(a.total_xp || 0)
        );
        
        if (sortedData.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><p>نتیجه‌ای یافت نشد</p></div>';
            return;
        }
        
        const tableHTML = `<table class="data-table">
            <thead>
                <tr>
                    <th>رتبه</th>
                    <th>نام دانش‌آموز</th>
                    <th>امتیاز</th>
                    <th>وضعیت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                ${sortedData.map((student, index) => {
                    const xp = parseInt(student.total_xp || 0);
                    const isActive = xp > 0;
                    return `
                        <tr>
                            <td><span class="rank-badge ${getRankClass(index + 1)}">${(index + 1).toLocaleString('fa-IR')}</span></td>
                            <td>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</td>
                            <td><span class="xp-badge"><i class="fas fa-star"></i>${xp.toLocaleString('fa-IR')}</span></td>
                            <td>${isActive ? 
                                '<span style="color: var(--success-color);"><i class="fas fa-check-circle"></i> فعال</span>' : 
                                '<span style="color: var(--danger-color);"><i class="fas fa-times-circle"></i> غیرفعال</span>'
                            }</td>
                            <td><button class="analysis-btn" onclick="viewStudentAnalysis(${student.student_id})" title="مشاهده تحلیل"><i class="fas fa-chart-line"></i></button></td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>`;
        
        container.innerHTML = tableHTML;
    }
    
    function getRankClass(rank) {
        if (rank === 1) return 'rank-1';
        if (rank === 2) return 'rank-2';
        if (rank === 3) return 'rank-3';
        return 'rank-default';
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function showLoadingState() {
        const loadingHTML = '<div class="loading-state"><i class="fas fa-spinner"></i></div>';
        document.getElementById('top-performers-content').innerHTML = loadingHTML;
        document.getElementById('needs-attention-content').innerHTML = loadingHTML;
        document.getElementById('full-student-list-content').innerHTML = loadingHTML;
        
        ['total-xp-value', 'active-students-value', 'avg-xp-value', 'total-students-value'].forEach(id => {
            document.getElementById(id).textContent = '-';
        });
    }
    
    function showEmptyState() {
        const emptyHTML = '<div class="empty-state"><i class="fas fa-inbox"></i><p>لطفاً یک بازه زمانی را انتخاب کنید</p></div>';
        document.getElementById('top-performers-content').innerHTML = emptyHTML;
        document.getElementById('needs-attention-content').innerHTML = emptyHTML;
        document.getElementById('full-student-list-content').innerHTML = emptyHTML;
    }
    
    function showErrorState(message) {
        const errorHTML = `<div class="error-state"><i class="fas fa-exclamation-circle"></i><p>خطا: ${escapeHtml(message)}</p></div>`;
        document.getElementById('top-performers-content').innerHTML = errorHTML;
        document.getElementById('needs-attention-content').innerHTML = errorHTML;
        document.getElementById('full-student-list-content').innerHTML = errorHTML;
    }
});

function viewStudentAnalysis(studentId) {
    if (!studentId) {
        alert('خطا: شناسه دانش‌آموز معتبر نیست');
        return;
    }
    window.location.href = `student_analysis.php?student_id=${studentId}`;
}
// تابع به‌روزرسانی بانک اطلاعاتی
async function updateDatabase() {
    const button = document.getElementById('update-database-btn');
    const statusDiv = document.getElementById('update-status');
    const updateIcon = button.querySelector('.update-icon i');
    
    // فعال کردن حالت بارگذاری
    button.classList.add('updating');
    button.disabled = true;
    
    // نمایش پیام در حال پردازش
    statusDiv.className = 'update-status info show';
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> در حال به‌روزرسانی بانک اطلاعاتی...';
    
    try {
        const response = await fetch('../backfill_weekly_data.php', {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        if (!response.ok) {
            throw new Error('خطا در ارتباط با سرور');
        }
        
        const result = await response.text();
        
        // به‌روزرسانی موفق
        statusDiv.className = 'update-status success show';
        statusDiv.innerHTML = '<i class="fas fa-check-circle"></i> بانک اطلاعاتی با موفقیت به‌روزرسانی شد!';
        
        // به‌روزرسانی زمان آخرین بروزرسانی
        updateLastUpdateTime();
        
        // بارگذاری مجدد داده‌ها
        setTimeout(() => {
            fetchAnalysisData();
        }, 1000);
        
        // پنهان کردن پیام بعد از 5 ثانیه
        setTimeout(() => {
            statusDiv.classList.remove('show');
        }, 5000);
        
    } catch (error) {
        console.error('❌ خطا در به‌روزرسانی:', error);
        statusDiv.className = 'update-status error show';
        statusDiv.innerHTML = '<i class="fas fa-times-circle"></i> خطا: ' + error.message;
        
        setTimeout(() => {
            statusDiv.classList.remove('show');
        }, 5000);
    } finally {
        // غیرفعال کردن حالت بارگذاری
        button.classList.remove('updating');
        button.disabled = false;
    }
}

// تابع به‌روزرسانی زمان آخرین بروزرسانی
function updateLastUpdateTime() {
    const now = new Date();
    
    // تبدیل به تاریخ شمسی
    const persianDate = now.toLocaleDateString('fa-IR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    const persianTime = now.toLocaleTimeString('fa-IR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    const lastUpdateElement = document.getElementById('last-update-time');
    lastUpdateElement.textContent = `${persianDate} - ${persianTime}`;
    
    // ذخیره در localStorage
    localStorage.setItem('lastDatabaseUpdate', now.toISOString());
}

// بارگذاری زمان آخرین بروزرسانی از localStorage
function loadLastUpdateTime() {
    const lastUpdate = localStorage.getItem('lastDatabaseUpdate');
    
    if (lastUpdate) {
        const date = new Date(lastUpdate);
        const persianDate = date.toLocaleDateString('fa-IR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const persianTime = date.toLocaleTimeString('fa-IR', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        document.getElementById('last-update-time').textContent = `${persianDate} - ${persianTime}`;
    } else {
        document.getElementById('last-update-time').textContent = 'هنوز به‌روزرسانی نشده';
    }
}

// اضافه کردن event listener به دکمه برای کلیک دستی
document.getElementById('update-database-btn').addEventListener('click', updateDatabase);

// بارگذاری زمان در هنگام لود صفحه
loadLastUpdateTime();

// 🆕 اجرای خودکار به‌روزرسانی هنگام ورود به صفحه
console.log('🚀 شروع به‌روزرسانی خودکار هنگام ورود به صفحه...');
setTimeout(() => {
    updateDatabase();
}, 500); // تاخیر 500 میلی‌ثانیه برای اطمینان از لود کامل صفحه
</script>

</body>
</html>