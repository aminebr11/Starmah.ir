<?php
// sections/prompt_builder.php
// Prompt Builder (Farsi/RTL) with Cascading (grade -> course -> topic)
// Single-file PHP + HTML + CSS + JS. No external dependencies.

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>🧠 پرومپت‌ساز بازی | ستاره‌ماه</title>
<style>
:root{
  --bg1:#6a85f1; --bg2:#a777e3;
  --panel:rgba(255,255,255,.16); --panel-br:rgba(255,255,255,.36);
  --ink:#1d1d1f; --ink-soft:#2a2a30;
  --good:#2ecc71; --warn:#f1c40f; --bad:#ff4757; --brand:#66c1ff; --accent:#ffd36e;
}
*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0; font-family: Vazirmatn, "IRANSans", "Segoe UI", Tahoma, sans-serif;
  background: linear-gradient(135deg,var(--bg1),var(--bg2));
  color:#fff;
}
.wrap{max-width:1100px; margin:0 auto; padding:clamp(14px,3.2vw,28px)}
.header{display:flex; gap:12px; align-items:center; justify-content:space-between; flex-wrap:wrap}
.title{font-weight:900; font-size:clamp(18px,3.6vw,28px); text-shadow:0 8px 24px rgba(0,0,0,.25); display:flex; gap:10px; align-items:center}
.badge{background:linear-gradient(135deg,#FFD166,#FF6B6B); color:#1d1d1f; font-weight:900; padding:.35rem .8rem; border-radius:999px; border:2px solid rgba(255,255,255,.7)}
.panel{
  background:var(--panel); border:1px solid var(--panel-br);
  backdrop-filter:blur(10px); -webkit-backdrop-filter:blur(10px);
  border-radius:18px; box-shadow:0 14px 40px rgba(0,0,0,.2);
}
.grid{display:grid; grid-template-columns:1.2fr .8fr; gap:16px; margin-top:14px}
@media (max-width:940px){ .grid{grid-template-columns:1fr} }

.form{padding:16px}
.row{display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:8px}
@media (max-width:720px){ .row{grid-template-columns:1fr} }

.label{font-weight:800; margin:6px 2px 6px}
.input, .select, .textarea{
  width:100%; padding:.85rem 1rem; border-radius:14px; border:1px solid rgba(255,255,255,.45);
  background:rgba(255,255,255,.94); color:var(--ink); font-weight:700; outline:none;
  box-shadow:0 8px 20px rgba(0,0,0,.1);
  appearance:none;
}
.select{background-image: linear-gradient(135deg, #fff 0, #fff0 30%), radial-gradient(#999 0,#999 30%,#0000 31%);
  background-position: right .9rem top 50%, right 2.2rem top 1.15rem;
  background-size: 12px 12px, 4px 4px; background-repeat:no-repeat}
.textarea{min-height:120px; resize:vertical}
.hint{font-size:.9rem; opacity:.9; margin-top:2px}

.btns{display:flex; gap:8px; flex-wrap:wrap; margin-top:12px}
.btn{
  border:none; cursor:pointer; font-family:inherit; font-weight:900; letter-spacing:.2px;
  border-radius:999px; padding:.9rem 1.1rem; color:#1d1d1f;
  box-shadow:0 10px 24px rgba(0,0,0,.16); transition:transform .12s ease, opacity .12s ease;
}
.btn:active{transform:translateY(1px) scale(.99)}
.btn.primary{background:linear-gradient(135deg,#8ef6d2,#66d1ff)}
.btn.secondary{background:linear-gradient(135deg,#ffd36e,#ff9fb7)}
.btn.ghost{background:rgba(255,255,255,.22); color:#fff; border:1px solid rgba(255,255,255,.6)}
.btn.warn{background:linear-gradient(135deg,#ffeaa7,#fab1a0)}

.kpis{display:flex; gap:10px; flex-wrap:wrap; padding:12px}
.kpi{flex:1 1 200px; background:rgba(255,255,255,.18); border:1px solid rgba(255,255,255,.38); border-radius:14px; padding:.8rem 1rem; font-weight:800; display:flex; align-items:center; justify-content:space-between}

.out{padding:14px}
#output{min-height:360px; white-space:pre; font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace}
.mono{font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace}
.toast{
  position:fixed; bottom:18px; right:18px; background:rgba(255,255,255,.96); color:var(--ink);
  padding:.8rem 1rem; border-radius:12px; border:2px solid #fff; font-weight:800; box-shadow:0 14px 32px rgba(0,0,0,.25);
  opacity:0; transition:opacity .3s ease; z-index:99;
}
.footerNote{padding:12px; font-weight:700; opacity:.95}
.small{font-size:.92rem}
.hidden{display:none}
.chips{display:flex; flex-wrap:wrap; gap:6px; margin-top:6px}
.chip{background:rgba(255,255,255,.22); border:1px dashed rgba(255,255,255,.5); color:#fff; padding:.35rem .6rem; border-radius:999px; font-weight:800}
</style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <div class="title">🧠 پرومپت‌ساز بازی <span class="badge">ستاره‌ماه</span></div>
      <div class="kpis panel">
        <div class="kpi">⏱️ زمان تخمینی ساخت <span id="eta" class="mono">~15s</span></div>
        <div class="kpi">📝 کاراکترهای خروجی <span id="charCount" class="mono">0</span></div>
      </div>
    </div>

    <div class="grid">
      <!-- فرم ورودی با منوهای آبشاری -->
      <div class="panel form">
        <div class="row">
          <div>
            <div class="label">مقطع/پایه</div>
            <select id="gradeSelect" class="select"></select>
            <div class="hint">ابتدا پایه را انتخاب کنید تا فهرست درس‌ها متناسب با آن پُر شود.</div>
          </div>
          <div>
            <div class="label">نام درس</div>
            <select id="courseSelect" class="select"></select>
            <div class="hint">پس از انتخاب درس، موضوعات مربوط به آن نمایش داده می‌شوند.</div>
          </div>
        </div>

        <div class="row">
          <div>
            <div class="label">موضوع بازی</div>
            <select id="topicSelect" class="select"></select>
            <div class="chips"><span class="chip">🔽 منوی آبشاری</span><span class="chip">🎯 موضوعات پیشنهادی</span></div>
            <div class="hint">در صورت نیاز می‌توانید «موضوع سفارشی» را نیز وارد کنید.</div>
          </div>
          <div>
            <div class="label">موضوع سفارشی (اختیاری)</div>
            <input id="customTopic" class="input" placeholder="اگر موضوعِ مدنظر شما در لیست نبود، اینجا بنویسید">
          </div>
        </div>

        <div class="row">
          <div>
            <div class="label">سختی</div>
            <select id="difficulty" class="select">
              <option>آسان</option>
              <option selected>متوسط</option>
              <option>سخت</option>
            </select>
          </div>
          <div>
            <div class="label">زمان بازی (دقیقه)</div>
            <input id="minutes" class="input" type="number" min="1" max="30" step="1" value="5">
          </div>
        </div>

        <div class="row">
          <div>
            <div class="label">نوع بازی (صرفاً برای عنوان)</div>
            <select id="gametype" class="select">
              <option selected>تطبیق</option>
              <option>کوییز چهارگزینه‌ای</option>
              <option>درست/نادرست</option>
              <option>مرتب‌سازی</option>
            </select>
            <div class="hint">ساختار فنی خروجی همان بازی «دوستونه/تطبیق» سازگار با سایت شماست.</div>
          </div>
          <div>
            <div class="label">راهنمای اختصاصی معلم (اختیاری)</div>
            <input id="notes" class="input" placeholder="مثلاً: مثال‌های روزمره؛ بازخورد ملایم؛ لحن شاد و کودک‌پسند">
          </div>
        </div>

        <div class="btns">
          <button class="btn primary" id="btnBuild">✨ ساخت پرومپت</button>
          <button class="btn secondary" id="btnSample">🧪 نمونه‌پرکن</button>
          <button class="btn ghost" id="btnClear">🧹 پاک‌سازی</button>
        </div>
      </div>

      <!-- خروجی پرومپت -->
      <div class="panel out">
        <div class="label">خروجی پرومپت برای مدل هوش مصنوعی</div>
        <textarea id="output" class="textarea mono" placeholder="اینجا پرومپت آمادهٔ ارسال به مدل نمایش داده می‌شود..."></textarea>
        <div class="btns">
          <button class="btn primary" id="btnCopy">📋 کپی پرومپت</button>
          <button class="btn warn" id="btnDownload">⬇️ دانلود .txt</button>
        </div>
        <div class="footerNote small">
          نکته: خروجی یک «فایل HTML واحد و اجراشدنی» خواهد ساخت که با سیستم امتیازدهی و ذخیرهٔ نتیجهٔ سایت شما سازگار است.
        </div>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="toast" class="toast"></div>

<script>
// ===== داده‌های برنامهٔ درسی (پایه ← درس ← موضوع) =====
const CURRICULUM = {
  "پایه اول": {
    "ریاضی": ["شمارش تا 20","جمع و تفریق ساده","الگوهای تصویری","اندازه‌گیری با واحدهای غیرمعیار"],
    "فارسی": ["حروف و صداها","ترتیب حروف الفبا","کلمات هم‌قافیه","جملات کوتاه و روانخوانی"],
    "علوم":  ["حواس پنجگانه","گیاهان و جانوران","مواد پیرامون ما","نور و سایهٔ ساده"]
  },
  "پایه دوم": {
    "ریاضی": ["جمع و تفریقِ چندرقمی","الگوها و دنباله‌ها","اندازه‌گیری طول و جرم","مقدمهٔ ضرب"],
    "فارسی": ["املا و دیکته","درک مطلب کوتاه","جمله‌نویسی ساده","نشانه‌گذاری مقدماتی"],
    "علوم":  ["مواد و تغییرات ساده","زندگی جانوران","آب و هوا","زمین و خاک"]
  },
  "پایه سوم": {
    "ریاضی": ["ضرب‌های 1 تا 10","تقسیمِ مقدماتی","کسرهای ساده","محیط و اشکال هندسی"],
    "فارسی": ["درک مطلب متوسط","واژه‌سازی ساده","نهاد و گزاره مقدماتی","انشا کوتاه"],
    "علوم":  ["نیرو و حرکتِ ساده","انرژی اطراف ما","چرخهٔ زندگی گیاه","تغییر حالت ماده"]
  },
  "پایه چهارم": {
    "ریاضی": [
      "ارزش مکانی تا میلیون","جمع و تفریق چندرقمی",
      "ضرب و تقسیم","کسر و مقایسه","اعشاری مقدماتی",
      "زاویه و نقاله","محیط و مساحت","نمودارها و تفسیر داده","الگوهای عددی"
    ],
    "فارسی": [
      "درک مطلب","املا (ی/همزه/کلمات مشکِل)","نشانه‌گذاری",
      "ساخت واژه","نهاد و گزاره","صفت و موصوف","نامه‌نویسی","انشا"
    ],
    "علوم": [
      "چرخهٔ آب","حالت‌های ماده","ماشین‌های ساده","انرژی و تبدیل‌ها",
      "نور و سایه","خاک و فرسایش","زنجیرهٔ غذایی","الکتریسیتهٔ ساده","بازیافت و تفکیک"
    ],
    "مطالعات اجتماعی": [
      "نقشه و جهت‌یابی","آب‌وهوای ایران","منابع طبیعی",
      "استان‌ها و نواحی","شهر و روستا","حمل‌ونقل و ارتباطات","سواد رسانه‌ای مقدماتی"
    ],
    "هدیه‌های آسمانی": ["نماز و آداب","راستگویی و امانتداری","احترام به والدین","دوستی و مهربانی","نظم و مسئولیت"],
    "قرآن": ["روخوانی سوره‌ها","وقف و ابتدا مقدماتی","حفظ سوره‌های منتخب","معانی واژگان ساده"]
  },
  "پایه پنجم": {
    "ریاضی": ["کسرهای مساوی/مقایسه","اعشاری و تبدیل","نسبت و تناسب","محیط و مساحت پیشرفته","احتمال شهودی"],
    "فارسی": ["انشا توصیفی","املا و دستور","جملهٔ مرکب","درک مطلب تحلیلی"],
    "علوم":  ["ویژگی مواد","محلول‌ها و غلظت","گرما و دما","زمین‌ساخت","نیرو و فشار"]
  },
  "پایه ششم": {
    "ریاضی": ["اعداد صحیح","توان و جذر","حجم و مساحت جانبی","مختصات","درصد و کاربردها"],
    "فارسی": ["انشا استدلالی","آرایه‌های ادبی مقدماتی","دستور پیشرفته","درک مطلب تفسیری"],
    "علوم":  ["سازه‌ها و استحکام","برق و مغناطیس","تنفس و گردش خون","نجوم مقدماتی","زمین‌لرزه و آتشفشان"]
  }
};

// ===== ابزارهای UI =====
const $ = s => document.querySelector(s);

function toast(msg){
  const t = $("#toast");
  t.textContent = msg;
  t.style.opacity = 1;
  setTimeout(()=> t.style.opacity = 0, 1800);
}

function updateCount(){
  const n = ($("#output").value || "").length;
  $("#charCount").textContent = n.toLocaleString("fa-IR");
}

function downloadTxt(filename, text) {
  const blob = new Blob([text], {type: "text/plain;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  URL.revokeObjectURL(url); a.remove();
}

// ===== منوهای آبشاری =====
function populateGrades(){
  const g = $("#gradeSelect");
  g.innerHTML = "";
  Object.keys(CURRICULUM).forEach((grade)=>{
    const opt = document.createElement("option");
    opt.value = grade; opt.textContent = grade;
    g.appendChild(opt);
  });
  // پیش‌فرض: پایه چهارم (طبق نیاز شما)
  g.value = "پایه چهارم";
}

function populateCourses(){
  const grade = $("#gradeSelect").value;
  const c = $("#courseSelect");
  c.innerHTML = "";
  const subjects = Object.keys(CURRICULUM[grade] || {});
  subjects.forEach(sub=>{
    const opt = document.createElement("option");
    opt.value = opt.textContent = sub;
    c.appendChild(opt);
  });
  // اگر نبود، یک گزینهٔ خالی
  if(!subjects.length){
    const opt = document.createElement("option");
    opt.value = ""; opt.textContent = "—";
    c.appendChild(opt);
  }
}

function populateTopics(){
  const grade = $("#gradeSelect").value;
  const course = $("#courseSelect").value;
  const t = $("#topicSelect");
  t.innerHTML = "";
  const topics = (CURRICULUM[grade] && CURRICULUM[grade][course]) ? CURRICULUM[grade][course] : [];

  topics.forEach(tp=>{
    const opt = document.createElement("option");
    opt.value = opt.textContent = tp;
    t.appendChild(opt);
  });

  // گزینهٔ «انتخاب آزاد / موضوع سفارشی»
  const optCustom = document.createElement("option");
  optCustom.value = "__custom__";
  optCustom.textContent = "➕ موضوع سفارشی...";
  t.appendChild(optCustom);

  // اگر فهرست تهی بود، پیش‌فرض به سفارشی
  if(!topics.length){ t.value = "__custom__"; }
}

function handleTopicChange(){
  const val = $("#topicSelect").value;
  const custom = $("#customTopic");
  if(val === "__custom__"){
    custom.classList.remove("hidden");
    custom.focus();
  }else{
    custom.classList.add("hidden");
    custom.value = "";
  }
}

// ===== نمونه‌پرکن =====
function sampleFill(){
  $("#gradeSelect").value = "پایه چهارم";
  populateCourses();
  $("#courseSelect").value = "علوم";
  populateTopics();
  $("#topicSelect").value = "چرخهٔ آب";
  handleTopicChange();
  $("#difficulty").value = "متوسط";
  $("#minutes").value = 5;
  $("#gametype").value = "تطبیق";
  $("#notes").value = "مثال‌ها از زندگی روزمره دانش‌آموزان باشد (ابر، باران، برف). لحن شاد و تشویقی؛ راهنمای واضح.";
  toast("نمونه پر شد ✅");
}

// ===== ساخت پرومپت =====
function buildPrompt(){
  const grade = $("#gradeSelect").value.trim();
  const course = $("#courseSelect").value.trim();
  const topicSel = $("#topicSelect").value.trim();
  const customTopic = $("#customTopic").value.trim();
  const topic = (topicSel === "__custom__" ? customTopic : topicSel).trim();
  const difficulty = $("#difficulty").value.trim();
  const minutes = ($("#minutes").value || "5").toString().trim();
  const gametype = $("#gametype").value.trim();
  const notes = $("#notes").value.trim();

  if(!grade || !course || !topic){
    toast("لطفاً مقطع، درس و موضوع را کامل انتخاب/وارد کنید.");
    return;
  }

  const prompt =
`نقش و خروجی
- تو یک ژنراتور بازی آموزشی تک‌فایل (HTML+CSS+JS) برای سایت دبستان هستی.
- فقط یک فایل HTML کامل و اجراشدنی برگردان که تمام CSS/JS داخل خود صفحه باشد، بدون هیچ کتابخانهٔ خارجی.
- زبان و چیدمان: lang="fa" و dir="rtl"، همهٔ متن‌ها فارسی کودکانه و قابل‌فهم.
- موضوع: ${topic} — درس: ${course} — مقطع/پایه: ${grade} — سختی: ${difficulty}.

الزامات سازگاری (قرارداد یکپارچگی با سایت)
1) شناسه‌ها/ساختار DOM را دقیقاً بساز:
   - HUD: #time, #score, #acc, #roundInfo ، نوار زمان #timeProgress
   - دکمه‌ها: #btnRestart, #btnNextTip, #btnFinish ، و چک‌باکس #muteToggle
   - ستون‌ها/لیست‌ها: #leftList و #rightList (هر آیتم با کلاس .item و data-side="L|R" و data-id)
   - مودال نتیجه: #resultModal با #rScore, #rAcc, #rTime, #rPairs
   - بوم کنفتی: <canvas id="confetti">
   - کلاس‌ها: .wrap, .header, .title, .badge, .panel, .hud, .chip, .board, .col, .colTitle, .item, .footer, .btn, .modal, .card, .stat
2) تابع ذخیره‌سازی نتیجه را حتماً فراخوانی کن (بدون تغییر نام/امضا):
   saveGameResult(gameId, finalScore, timeSpent, finalAccuracy);
   - gameId را از ?id یا ?gameId بگیر؛ اگر نبود از window.GAME_ID؛ در غیر این صورت 0.
3) فرمول امتیاز و دقت:
   - accuracy = round(100 * correctPairs / (correctPairs + wrongAttempts || 1))
   - score    = clamp( round(100 * (correctPairs / totalPairs)) - min(40, wrongAttempts*5), 0, 100 )
4) تایمر و پایان خودکار، نمایش مودال نتیجه.
5) صدا با WebAudio و سوئیچ بی‌صدا (#muteToggle).
6) واکنش‌گرا و موبایل‌پسند، بدون فونت/تصویر/کتابخانهٔ خارجی.

پیکربندی بازی
- مدت بازی: ${minutes} دقیقه (اگر تعیین نشد، ۵).
- تعداد مراحل و جفت‌ها برحسب سختی:
  آسان: ۱ مرحله (۶–۸ جفت) | متوسط: ۲ مرحله (۸–۱۰ جفت) | سخت: ۲–۳ مرحله (۱۰–۱۴ جفت)
- داده‌ها در آرایهٔ ROUNDS (هر مرحله: [{id,left,right}])
- نکته‌های آموزشی مرتبط با موضوع در TIP_LIST (حداقل ۴ مورد).

راهنما و لحن
- بخش «راهنما» حتماً باشد؛ مرحله‌به‌مرحله، کودک‌پسند، با مثال.
- متن‌ها کوتاه، شاد و تشویقی؛ ایموجی محدود ولی کاربردی.${notes ? `\n- نکتهٔ اختصاصی معلم: ${notes}` : ""}

الگوی زمان و HUD
- تایمر ثانیه‌ای (MM:SS) در #time ، نوار پیشرفت در #timeProgress.
- HUD پس از هر اقدام #score و #acc را به‌روز کند.
- با حل همهٔ جفت‌ها در یک مرحله، به مرحلهٔ بعد برو؛ در انتها finishGame().

الگوی پایان و ذخیره
- در finishGame():
  - timeSpent = ثانیه‌های سپری‌شده
  - finalAccuracy و finalScore طبق فرمول بالا
  - مقادیر #rScore, #rAcc, #rTime, #rPairs را پر کن و مودال را باز کن
  - سپس حتماً:
    const gameId = getGameIdFromURL();
    saveGameResult(gameId, finalScore, timeSpent, finalAccuracy);
- اگر saveGameResult نبود، فقط console.warn بده (فراخوان را حذف نکن).

توابع سازگاری داخل خروجی (بدون تغییر نام)
- getGameIdFromURL(), computeAccuracy(), computeScore(), updateHUD(), startTimer()
- رویدادهای #btnRestart, #btnNextTip, #btnFinish ، مدیریت انتخاب جفت‌ها با .selected, .correct, .locked, .wrong

الزامات کیفیت
- بدون کتابخانهٔ خارجی/درخواست شبکه/فونت بیرونی.
- کد تمیز و قابل‌خواندن، با چند کامنت روشنگر.
- بازخورد بصریِ کوتاه برای درست/نادرست.

قالب دادهٔ محتوایی
- عنوان صفحه: "🎮 ${gametype}: ${topic} (${grade})"
- ROUNDS: مفاهیم/نمونه‌های واقعی مرتبط با ${course} و ${topic}، با زبان سادهٔ ${grade}.
- TIP_LIST: حداقل ۴ نکتهٔ کلیدی درس با لحن کودکانه.

خروجی نهایی
- فقط یک فایل HTML کامل بازگردان. هیچ توضیح اضافی ننویس.
- همهٔ شناسه‌ها/کلاس‌ها/توابع بالا باید دقیقاً وجود داشته باشند.`;

  $("#output").value = prompt;
  updateCount();
  toast("پرومپت آماده شد ✨");
}

// ===== کپی/دانلود =====
async function copyPrompt(){
  const text = $("#output").value.trim();
  if(!text){ toast("چیزی برای کپی وجود ندارد."); return; }
  try{
    await navigator.clipboard.writeText(text);
    toast("در کلیپ‌بورد کپی شد ✅");
  }catch(e){
    const ta = $("#output"); ta.select(); document.execCommand("copy");
    toast("کپی انجام شد ✅");
  }
}

// ===== راه‌اندازی =====
document.addEventListener("DOMContentLoaded", ()=>{
  populateGrades();
  populateCourses();
  populateTopics();
  handleTopicChange();

  $("#gradeSelect").addEventListener("change", ()=>{ populateCourses(); populateTopics(); handleTopicChange(); });
  $("#courseSelect").addEventListener("change", ()=>{ populateTopics(); handleTopicChange(); });
  $("#topicSelect").addEventListener("change", handleTopicChange);

  $("#btnBuild").addEventListener("click", e=>{ e.preventDefault(); buildPrompt(); });
  $("#btnSample").addEventListener("click", e=>{ e.preventDefault(); sampleFill(); });
  $("#btnClear").addEventListener("click", e=>{
    e.preventDefault();
    populateGrades(); populateCourses(); populateTopics(); handleTopicChange();
    $("#difficulty").value = "متوسط";
    $("#minutes").value = 5;
    $("#gametype").value = "تطبیق";
    $("#notes").value = "";
    $("#output").value = "";
    updateCount();
    toast("پاک شد 🧹");
  });
  $("#btnCopy").addEventListener("click", e=>{ e.preventDefault(); copyPrompt(); });
  $("#btnDownload").addEventListener("click", e=>{
    e.preventDefault();
    const text = $("#output").value.trim();
    if(!text){ toast("ابتدا پرومپت را بسازید."); return; }
    const course = $("#courseSelect").value || "lesson";
    const topic  = ($("#topicSelect").value === "__custom__" ? ($("#customTopic").value || "customTopic") : $("#topicSelect").value);
    downloadTxt(`prompt_${course}_${topic}.txt`, text);
    toast("فایل متنی دانلود شد ⬇️");
  });

  $("#output").addEventListener("input", updateCount);
  updateCount();
});
</script>
</body>
</html>
