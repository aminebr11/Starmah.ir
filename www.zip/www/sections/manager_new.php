<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = $conn;
$success_message = '';
$error_message = '';

// توابع XP
function calculateNumericXP($score, $maxScore = 20) {
    return round(($score / $maxScore) * 100);
}

function calculateDescriptiveXP($grade) {
    $xpMap = [
        'خیلی خوب' => 100,
        'خوب' => 75,
        'قابل قبول' => 50,
        'نیاز به تلاش' => 25,
        'غایب' => -25
    ];
    return $xpMap[$grade] ?? 0;
}

function calculateHomeworkXP($status) {
    $xpMap = [
        'کامل' => 50,
        'ناقص' => 25,
        'انجام نداده' => -15,
        'غایب' => -25
    ];
    return $xpMap[$status] ?? 0;
}

function getSubjectXPField($lesson) {
    $lesson = trim($lesson);
    $subjectMapping = [
        'ریاضی' => 'math_xp',
        'علوم' => 'science_xp',
        'علوم تجربی' => 'science_xp',
        'فارسی' => 'persian_xp',
        'زبان فارسی' => 'persian_xp',
        'مطالعات اجتماعی' => 'social_xp',
        'مطالعات' => 'social_xp',
        'دین' => 'religion_xp',
        'دینی' => 'religion_xp',
        'قرآن' => 'religion_xp',
        'تکلیف روز' => 'other_xp',
        'آزمون جامع' => 'other_xp',
        'هدیه های آسمانی' => 'religion_xp',
        'هدیه‌های آسمانی' => 'religion_xp'
    ];
    return $subjectMapping[$lesson] ?? null;
}

function updateStudentXP($db, $student_id, $lesson, $xp_amount, $reason) {
    try {
        $admin_id = $_SESSION['user_id'] ?? null;
        
        $checkStmt = $db->prepare("SELECT id FROM student_xp WHERE student_id = ?");
        $checkStmt->execute([$student_id]);
        
        if (!$checkStmt->fetch()) {
            $db->prepare("INSERT INTO student_xp (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp, other_xp) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0)")->execute([$student_id]);
        }
        
        $xpField = getSubjectXPField($lesson);
        
        if ($xpField) {
            $db->prepare("UPDATE student_xp SET {$xpField} = {$xpField} + ? WHERE student_id = ?")->execute([$xp_amount, $student_id]);
            $db->prepare("INSERT INTO xp_history (student_id, game_result_id, subject, amount, reason, admin_id, created_at) VALUES (?, NULL, ?, ?, ?, ?, NOW())")->execute([$student_id, $lesson, $xp_amount, $reason, $admin_id]);
        }
        
        return true;
    } catch (Exception $e) {
        error_log("XP Error: " . $e->getMessage());
        return false;
    }
}

function extractMaxScoreFromTitle($title) {
    if (preg_match('/\(از\s*(\d+)\s*نمره\)/u', $title, $matches)) {
        return (int)$matches[1];
    }
    if (preg_match('/\((\d+)\s*نمره\)/u', $title, $matches)) {
        return (int)$matches[1];
    }
    if (preg_match('/\/(\d+)$/u', $title, $matches)) {
        return (int)$matches[1];
    }
    return 20;
}

// توابع تبدیل تاریخ
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + floor(($gy2 + 3) / 4) - floor(($gy2 + 99) / 100) + floor(($gy2 + 399) / 400) + $gd;
    for ($i = 0; $i < $gm; $i++) $days += $g_d_m[$i];
    $jy = -1595 + (33 * floor($days / 12053));
    $days %= 12053;
    $jy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + floor($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $days -= 186;
        $jm = 7 + floor($days / 30);
        $jd = 1 + ($days % 30);
    }
    return [$jy, $jm, $jd];
}

function en_to_fa_digits($str) {
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, $str);
}

function dbdate_to_jalali_fa($dateStr) {
    $dateStr = trim((string)$dateStr);
    if ($dateStr === '') return '';
    $parts = preg_split('/[\-\/\.]/', $dateStr);
    if (count($parts) < 3) return $dateStr;
    $gy = (int)$parts[0]; $gm = (int)$parts[1]; $gd = (int)$parts[2];
    if ($gy <= 0 || $gm <= 0 || $gd <= 0) return $dateStr;
    [$jy, $jm, $jd] = gregorian_to_jalali($gy, $gm, $gd);
    return en_to_fa_digits(sprintf('%04d/%02d/%02d', $jy, $jm, $jd));
}

function getDerivedStatus($record) {
    if (isset($record['status']) && $record['status'] === 'absent') {
        return ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'];
    }
    
    if (empty($record['score'])) {
        return ['text' => 'ثبت نشده', 'color' => '#a0aec0', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'descriptive') {
        $map = [
            'خیلی خوب' => ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'],
            'خوب' => ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'],
            'قابل قبول' => ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'],
            'نیاز به تلاش' => ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'homework') {
        $map = [
            'کامل' => ['text' => 'کامل', 'color' => '#22c55e', 'icon' => '✅'],
            'ناقص' => ['text' => 'ناقص', 'color' => '#f59e0b', 'icon' => '⚠️'],
            'انجام نداده' => ['text' => 'انجام نشده', 'color' => '#ef4444', 'icon' => '❌'],
            'غایب' => ['text' => 'غایب', 'color' => '#6b7280', 'icon' => '🚫'],
        ];
        return $map[trim($record['score'])] ?? ['text' => $record['score'], 'color' => '#9ca3af', 'icon' => ''];
    }
    
    if ($record['score_type'] === 'numeric') {
        $numeric_score = (float)str_replace(',', '.', $record['score']);
        $maxScore = extractMaxScoreFromTitle($record['activity_title'] ?? $record['title'] ?? '');
        $percentage = $maxScore > 0 ? ($numeric_score / $maxScore) : 0;
        
        if ($percentage >= 0.9) return ['text' => 'عالی', 'color' => '#059669', 'icon' => '🌟'];
        if ($percentage >= 0.75) return ['text' => 'خوب', 'color' => '#10b981', 'icon' => '👍'];
        if ($percentage >= 0.5) return ['text' => 'قابل قبول', 'color' => '#f59e0b', 'icon' => '🟡'];
        return ['text' => 'نیاز به تلاش', 'color' => '#ef4444', 'icon' => '🔴'];
    }
    
    return ['text' => 'نامشخص', 'color' => '#9ca3af', 'icon' => ''];
}

// پردازش فرم‌ها
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'edit_batch_record') {
            // ویرایش رکورد دسته‌ای
            $activity_id = (int)$_POST['activity_id'];
            
            // ویرایش activity
            $stmt = $db->prepare("UPDATE activities SET title = ?, lesson = ?, topic = ? WHERE id = ?");
            $stmt->execute([$_POST['title'], $_POST['lesson'], $_POST['topic'], $activity_id]);
            
            // پردازش نمرات دانش‌آموزان
            if (isset($_POST['student_results']) && is_array($_POST['student_results'])) {
                foreach ($_POST['student_results'] as $student_id => $result) {
                    $result_id = (int)($result['result_id'] ?? 0);
                    
                    // دریافت نمره قبلی برای محاسبه XP
                    if ($result_id > 0) {
                        $stmt = $db->prepare("SELECT ar.score, a.score_type, a.title, a.lesson FROM activity_results ar JOIN activities a ON ar.activity_id = a.id WHERE ar.id = ?");
                        $stmt->execute([$result_id]);
                        $old_record = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($old_record) {
                            $maxScore = extractMaxScoreFromTitle($old_record['title']);
                            
                            // محاسبه XP قدیم
                            $old_xp = 0;
                            if ($old_record['score_type'] === 'numeric' && !empty($old_record['score'])) {
                                $old_xp = calculateNumericXP($old_record['score'], $maxScore);
                            } elseif ($old_record['score_type'] === 'descriptive' && !empty($old_record['score'])) {
                                $old_xp = calculateDescriptiveXP($old_record['score']);
                            } elseif ($old_record['score_type'] === 'homework' && !empty($old_record['score'])) {
                                $old_xp = calculateHomeworkXP($old_record['score']);
                            }
                            
                            // به‌روزرسانی نمره
                            $stmt = $db->prepare("UPDATE activity_results SET score = ?, feedback = ? WHERE id = ?");
                            $stmt->execute([$result['score'], $result['feedback'] ?? '', $result_id]);
                            
                            // محاسبه XP جدید
                            $new_xp = 0;
                            if ($old_record['score_type'] === 'numeric' && !empty($result['score'])) {
                                $new_xp = calculateNumericXP($result['score'], $maxScore);
                            } elseif ($old_record['score_type'] === 'descriptive' && !empty($result['score'])) {
                                $new_xp = calculateDescriptiveXP($result['score']);
                            } elseif ($old_record['score_type'] === 'homework' && !empty($result['score'])) {
                                $new_xp = calculateHomeworkXP($result['score']);
                            }
                            
                            $xp_diff = $new_xp - $old_xp;
                            if ($xp_diff != 0) {
                                updateStudentXP($db, $student_id, $old_record['lesson'], $xp_diff, "ویرایش نمره");
                            }
                        }
                    } else {
                        // اضافه کردن نمره جدید
                        if (!empty($result['score'])) {
                            $stmt = $db->prepare("INSERT INTO activity_results (activity_id, student_id, score, status, feedback) VALUES (?, ?, ?, 'submitted', ?)");
                            $stmt->execute([$activity_id, $student_id, $result['score'], $result['feedback'] ?? '']);
                            
                            // محاسبه و اضافه XP
                            $stmt = $db->prepare("SELECT score_type, title, lesson FROM activities WHERE id = ?");
                            $stmt->execute([$activity_id]);
                            $activity = $stmt->fetch(PDO::FETCH_ASSOC);
                            
                            if ($activity) {
                                $maxScore = extractMaxScoreFromTitle($activity['title']);
                                $xp = 0;
                                
                                if ($activity['score_type'] === 'numeric' && !empty($result['score'])) {
                                    $xp = calculateNumericXP($result['score'], $maxScore);
                                } elseif ($activity['score_type'] === 'descriptive' && !empty($result['score'])) {
                                    $xp = calculateDescriptiveXP($result['score']);
                                } elseif ($activity['score_type'] === 'homework' && !empty($result['score'])) {
                                    $xp = calculateHomeworkXP($result['score']);
                                }
                                
                                if ($xp != 0) {
                                    updateStudentXP($db, $student_id, $activity['lesson'], $xp, "افزودن نمره جدید");
                                }
                            }
                        }
                    }
                }
            }
            
            $success_message = "✅ رکورد دسته‌ای با موفقیت ویرایش شد.";
            
        } elseif ($action === 'delete_student_score') {
            // حذف نمره یک دانش‌آموز
            $result_id = (int)$_POST['result_id'];
            
            $stmt = $db->prepare("SELECT ar.student_id, ar.score, a.lesson, a.title, a.score_type, a.id as activity_id FROM activity_results ar JOIN activities a ON ar.activity_id = a.id WHERE ar.id = ?");
            $stmt->execute([$result_id]);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($record) {
                $maxScore = extractMaxScoreFromTitle($record['title']);
                $xp = 0;
                
                if ($record['score_type'] === 'numeric' && !empty($record['score'])) {
                    $xp = calculateNumericXP($record['score'], $maxScore);
                } elseif ($record['score_type'] === 'descriptive' && !empty($record['score'])) {
                    $xp = calculateDescriptiveXP($record['score']);
                } elseif ($record['score_type'] === 'homework' && !empty($record['score'])) {
                    $xp = calculateHomeworkXP($record['score']);
                }
                
                $db->prepare("DELETE FROM activity_results WHERE id = ?")->execute([$result_id]);
                
                if ($xp != 0) {
                    updateStudentXP($db, $record['student_id'], $record['lesson'], -$xp, "حذف نمره");
                }
                
                // بررسی و حذف activity اگر خالی شد
                $check = $db->prepare("SELECT COUNT(*) FROM activity_results WHERE activity_id = ?");
                $check->execute([$record['activity_id']]);
                if ($check->fetchColumn() == 0) {
                    $db->prepare("DELETE FROM activities WHERE id = ?")->execute([$record['activity_id']]);
                }
            }
            
            $success_message = "✅ نمره با موفقیت حذف شد.";
            
        } elseif ($action === 'delete_batch') {
            // حذف کامل رکورد دسته‌ای
            $activity_id = (int)$_POST['activity_id'];
            
            $stmt = $db->prepare("SELECT ar.student_id, ar.score, a.lesson, a.title, a.score_type FROM activity_results ar JOIN activities a ON ar.activity_id = a.id WHERE ar.activity_id = ?");
            $stmt->execute([$activity_id]);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($records as $record) {
                $maxScore = extractMaxScoreFromTitle($record['title']);
                $xp = 0;
                
                if ($record['score_type'] === 'numeric' && !empty($record['score'])) {
                    $xp = calculateNumericXP($record['score'], $maxScore);
                } elseif ($record['score_type'] === 'descriptive' && !empty($record['score'])) {
                    $xp = calculateDescriptiveXP($record['score']);
                } elseif ($record['score_type'] === 'homework' && !empty($record['score'])) {
                    $xp = calculateHomeworkXP($record['score']);
                }
                
                if ($xp != 0) {
                    updateStudentXP($db, $record['student_id'], $record['lesson'], -$xp, "حذف کامل رکورد");
                }
            }
            
            $db->prepare("DELETE FROM activity_results WHERE activity_id = ?")->execute([$activity_id]);
            $db->prepare("DELETE FROM activities WHERE id = ?")->execute([$activity_id]);
            
            $success_message = "✅ رکورد دسته‌ای به طور کامل حذف شد.";
            
        } elseif ($action === 'delete_student_all') {
            // حذف تمام سوابق دانش‌آموز
            $student_id = (int)$_POST['student_id'];
            
            $stmt = $db->prepare("SELECT ar.score, a.lesson, a.title, a.score_type FROM activity_results ar JOIN activities a ON ar.activity_id = a.id WHERE ar.student_id = ?");
            $stmt->execute([$student_id]);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($records as $record) {
                $maxScore = extractMaxScoreFromTitle($record['title']);
                $xp = 0;
                
                if ($record['score_type'] === 'numeric' && !empty($record['score'])) {
                    $xp = calculateNumericXP($record['score'], $maxScore);
                } elseif ($record['score_type'] === 'descriptive' && !empty($record['score'])) {
                    $xp = calculateDescriptiveXP($record['score']);
                } elseif ($record['score_type'] === 'homework' && !empty($record['score'])) {
                    $xp = calculateHomeworkXP($record['score']);
                }
                
                if ($xp != 0) {
                    updateStudentXP($db, $student_id, $record['lesson'], -$xp, "حذف تمام سوابق");
                }
            }
            
            $db->prepare("DELETE FROM activity_results WHERE student_id = ?")->execute([$student_id]);
            
            $success_message = "✅ تمام سوابق دانش‌آموز حذف شد.";
        }
        
    } catch (Exception $e) {
        $error_message = "❌ خطا: " . $e->getMessage();
    }
    
    if (isset($_POST['redirect_to'])) {
        header("Location: " . $_POST['redirect_to']);
    } else {
        header("Location: manager_records.php");
    }
    exit;
}

// گرفتن پیام‌ها
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// تشخیص view mode
$view_mode = $_GET['mode'] ?? 'list';
$selected_batch_id = (int)($_GET['batch_id'] ?? 0);
$selected_student_id = (int)($_GET['student_id'] ?? 0);

// دریافت دانش‌آموزان
$students = $db->query("SELECT id, first_name, last_name FROM users WHERE user_type = 'student' AND is_active = 1 ORDER BY first_name, last_name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>مدیریت سوابق نمرات</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css">
<link href="https://fonts.googleapis.com/css2?family=Vazir:wght@400;500;700&display=swap" rel="stylesheet">
<style>
:root {
    --primary: #667eea;
    --secondary: #764ba2;
    --success: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --info: #3b82f6;
}

* {
    font-family: 'Vazir', sans-serif;
    box-sizing: border-box;
}

body {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    min-height: 100vh;
    padding: 2rem 0;
}

.container-main {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1rem;
}

.card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 15px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.card-header-custom {
    background: linear-gradient(135deg, #6bcf7f, #4d9de0);
    color: white;
    padding: 1.5rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
}

.card-header-custom h2 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
}

.btn-custom {
    padding: 0.6rem 1.2rem;
    border-radius: 10px;
    border: none;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-primary-custom {
    background: linear-gradient(135deg, #6bcf7f, #4d9de0);
    color: white;
}

.btn-primary-custom:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(107, 207, 127, 0.4);
}

.btn-danger-custom {
    background: var(--danger);
    color: white;
}

.btn-danger-custom:hover {
    background: #dc2626;
}

.btn-warning-custom {
    background: var(--warning);
    color: white;
}

.btn-warning-custom:hover {
    background: #d97706;
}

.btn-secondary-custom {
    background: #6b7280;
    color: white;
}

.btn-secondary-custom:hover {
    background: #4b5563;
}

.table-custom {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
}

.table-custom thead {
    background: linear-gradient(135deg, #6bcf7f, #4d9de0);
    color: white;
}

.table-custom th {
    padding: 1rem;
    text-align: right;
    font-weight: 700;
}

.table-custom td {
    padding: 0.8rem 1rem;
    border-bottom: 1px solid #e5e7eb;
}

.table-custom tbody tr:hover {
    background-color: #f9fafb;
}

.table-custom tbody tr {
    cursor: pointer;
    transition: all 0.2s;
}

.status-badge {
    padding: 0.4rem 0.8rem;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
    display: inline-block;
}

.alert-custom {
    padding: 1rem 1.5rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.alert-success-custom {
    background: rgba(16, 185, 129, 0.1);
    color: #065f46;
    border: 1px solid rgba(16, 185, 129, 0.3);
}

.alert-danger-custom {
    background: rgba(239, 68, 68, 0.1);
    color: #991b1b;
    border: 1px solid rgba(239, 68, 68, 0.3);
}

.grade-input {
    width: 80px;
    padding: 0.5rem;
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    text-align: center;
    font-weight: 600;
}

.grade-input:focus {
    border-color: var(--primary);
    outline: none;
}

.grade-btn {
    padding: 0.3rem 0.6rem;
    margin: 0.1rem;
    border: 2px solid #ddd;
    border-radius: 15px;
    background: white;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 0.75rem;
    white-space: nowrap;
    display: inline-block;
}

.grade-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.grade-btn.selected {
    background: #6bcf7f;
    color: white;
    border-color: #6bcf7f;
}

.grade-buttons-container {
    display: flex;
    flex-wrap: nowrap;
    gap: 0.2rem;
    align-items: center;
    overflow-x: auto;
}

/* در صورت نیاز به wrap در موبایل */
@media (max-width: 768px) {
    .grade-buttons-container {
        flex-wrap: wrap;
    }
}

.feedback-input {
    width: 100%;
    min-height: 60px;
    padding: 0.5rem;
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    resize: vertical;
}

.feedback-input:focus {
    border-color: var(--primary);
    outline: none;
}

.nav-tabs-custom {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.nav-tab {
    padding: 0.8rem 1.5rem;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
}

.nav-tab:hover {
    background: rgba(255, 255, 255, 0.3);
    color: white;
}

.nav-tab.active {
    background: white;
    color: var(--primary);
}

.search-box {
    padding: 0.8rem 1rem;
    border: 2px solid #e5e7eb;
    border-radius: 10px;
    width: 100%;
    max-width: 400px;
}

.search-box:focus {
    border-color: var(--primary);
    outline: none;
}

@media (max-width: 768px) {
    .card {
        padding: 1rem;
    }
    
    .table-custom {
        font-size: 0.85rem;
    }
    
    .table-custom th,
    .table-custom td {
        padding: 0.5rem;
    }
}
</style>
</head>
<body>
<div class="container-main">
    <?php if ($success_message): ?>
        <div class="alert-custom alert-success-custom">
            ✅ <?php echo $success_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="alert-custom alert-danger-custom">
            ❌ <?php echo $error_message; ?>
        </div>
    <?php endif; ?>
    
    <div class="nav-tabs-custom">
        <a href="?mode=list" class="nav-tab <?php echo $view_mode === 'list' ? 'active' : ''; ?>">
            📦 لیست رکوردهای دسته‌ای
        </a>
        <a href="?mode=student" class="nav-tab <?php echo $view_mode === 'student' ? 'active' : ''; ?>">
            👤 مدیریت دانش‌آموز محور
        </a>
    </div>
    
    <?php if ($view_mode === 'list'): ?>
        <!-- لیست رکوردهای دسته‌ای -->
        <div class="card">
            <div class="card-header-custom">
                <h2>📋 لیست رکوردهای دسته‌ای</h2>
            </div>
            
            <?php
            $batches = $db->query("
                SELECT 
                    a.id,
                    a.date,
                    a.lesson,
                    a.topic,
                    a.title,
                    a.score_type,
                    COUNT(ar.id) as student_count
                FROM activities a
                LEFT JOIN activity_results ar ON a.id = ar.activity_id
                GROUP BY a.id
                ORDER BY a.date DESC, a.id DESC
            ")->fetchAll(PDO::FETCH_ASSOC);
            ?>
            
            <?php if (empty($batches)): ?>
                <div style="text-align: center; padding: 3rem; color: #9ca3af;">
                    <i style="font-size: 4rem;">📭</i>
                    <h3>هیچ رکوردی یافت نشد</h3>
                    <p>رکوردهای ثبت شده در اینجا نمایش داده می‌شوند</p>
                </div>
            <?php else: ?>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th style="width: 50px;">ردیف</th>
                            <th style="width: 100px;">تاریخ</th>
                            <th>عنوان فعالیت</th>
                            <th style="width: 150px;">درس</th>
                            <th style="width: 150px;">موضوع</th>
                            <th style="width: 100px;">تعداد نمرات</th>
                            <th style="width: 200px;">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $counter = 1;
                        foreach ($batches as $batch): 
                        ?>
                            <tr onclick="window.location.href='?mode=edit_batch&batch_id=<?php echo $batch['id']; ?>'">
                                <td><?php echo en_to_fa_digits($counter++); ?></td>
                                <td><?php echo dbdate_to_jalali_fa($batch['date']); ?></td>
                                <td><strong><?php echo htmlspecialchars($batch['title']); ?></strong></td>
                                <td><?php echo htmlspecialchars($batch['lesson']); ?></td>
                                <td><?php echo htmlspecialchars($batch['topic']); ?></td>
                                <td style="text-align: center;">
                                    <span class="status-badge" style="background-color: #dbeafe; color: #1e40af;">
                                        <?php echo en_to_fa_digits($batch['student_count']); ?> نمره
                                    </span>
                                </td>
                                <td onclick="event.stopPropagation();">
                                    <button class="btn-custom btn-warning-custom" onclick="window.location.href='?mode=edit_batch&batch_id=<?php echo $batch['id']; ?>'">
                                        ✏️ ویرایش
                                    </button>
                                    <button class="btn-custom btn-danger-custom" onclick="deleteBatch(<?php echo $batch['id']; ?>)">
                                        🗑️ حذف
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
    <?php elseif ($view_mode === 'edit_batch' && $selected_batch_id > 0): ?>
        <!-- ویرایش رکورد دسته‌ای -->
        <?php
        // دریافت اطلاعات activity
        $stmt = $db->prepare("SELECT * FROM activities WHERE id = ?");
        $stmt->execute([$selected_batch_id]);
        $activity = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$activity) {
            echo "<div class='alert-custom alert-danger-custom'>رکورد یافت نشد</div>";
            exit;
        }
        
        $maxScore = extractMaxScoreFromTitle($activity['title']);
        
        // دریافت نمرات
        $stmt = $db->prepare("
            SELECT 
                ar.id as result_id,
                ar.student_id,
                ar.score,
                ar.status,
                ar.feedback,
                u.first_name,
                u.last_name
            FROM activity_results ar
            JOIN users u ON ar.student_id = u.id
            WHERE ar.activity_id = ?
            ORDER BY u.first_name, u.last_name
        ");
        $stmt->execute([$selected_batch_id]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // ایجاد آرایه برای دسترسی سریع
        $results_map = [];
        foreach ($results as $result) {
            $results_map[$result['student_id']] = $result;
        }
        ?>
        
        <div class="card">
            <div class="card-header-custom">
                <h2>✏️ ویرایش رکورد دسته‌ای</h2>
                <div>
                    <a href="?mode=list" class="btn-custom btn-secondary-custom">
                        ← بازگشت
                    </a>
                </div>
            </div>
            
            <form method="POST" id="editBatchForm">
                <input type="hidden" name="action" value="edit_batch_record">
                <input type="hidden" name="activity_id" value="<?php echo $selected_batch_id; ?>">
                <input type="hidden" name="redirect_to" value="?mode=list">
                
                <!-- اطلاعات کلی -->
                <div style="background: #f9fafb; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
                    <h3 style="margin-bottom: 1rem;">📝 اطلاعات کلی فعالیت</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">عنوان فعالیت</label>
                            <input type="text" name="title" class="search-box" style="max-width: none;" value="<?php echo htmlspecialchars($activity['title']); ?>" required>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">درس</label>
                            <input type="text" name="lesson" class="search-box" style="max-width: none;" value="<?php echo htmlspecialchars($activity['lesson']); ?>" required>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">موضوع</label>
                            <input type="text" name="topic" class="search-box" style="max-width: none;" value="<?php echo htmlspecialchars($activity['topic']); ?>" required>
                        </div>
                    </div>
                    <div style="margin-top: 1rem; padding: 0.5rem; background: #e0f2fe; border-radius: 8px; color: #0369a1;">
                        <strong>نوع نمره:</strong> 
                        <?php 
                        if ($activity['score_type'] === 'numeric') echo '🔢 عددی';
                        elseif ($activity['score_type'] === 'descriptive') echo '📊 توصیفی';
                        elseif ($activity['score_type'] === 'homework') echo '📝 تکلیف';
                        else echo $activity['score_type'];
                        ?>
                    </div>
                </div>
                
                <!-- جدول نمرات -->
                <div style="margin-bottom: 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <h3>👥 نمرات دانش‌آموزان</h3>
                        <input type="text" class="search-box" placeholder="🔍 جستجوی نام..." onkeyup="searchTable(this.value)">
                    </div>
                    
                    <table class="table-custom" id="studentsTable">
                        <thead>
                            <tr>
                                <th style="width: 50px;">ردیف</th>
                                <th>نام و نام خانوادگی</th>
                                <th style="width: 250px;">نمره</th>
                                <th style="width: 200px;">بازخورد</th>
                                <th style="width: 100px;">عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $counter = 1;
                            foreach ($students as $student):
                                $result = $results_map[$student['id']] ?? null;
                            ?>
                                <tr data-student-name="<?php echo strtolower($student['first_name'] . ' ' . $student['last_name']); ?>">
                                    <td><?php echo en_to_fa_digits($counter++); ?></td>
                                    <td><strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong></td>
                                    <td>
                                        <?php if ($result): ?>
                                            <input type="hidden" name="student_results[<?php echo $student['id']; ?>][result_id]" value="<?php echo $result['result_id']; ?>">
                                        <?php endif; ?>
                                        
                                        <?php if ($activity['score_type'] === 'numeric'): ?>
                                            <input type="number" name="student_results[<?php echo $student['id']; ?>][score]" 
                                                   class="grade-input" min="0" max="<?php echo $maxScore; ?>" step="0.25"
                                                   value="<?php echo $result ? htmlspecialchars($result['score']) : ''; ?>">
                                            <small style="color: #6b7280;">/ <?php echo en_to_fa_digits($maxScore); ?></small>
                                        <?php elseif ($activity['score_type'] === 'descriptive'): ?>
                                            <div class="grade-buttons-container">
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'خیلی خوب') ? 'selected' : ''; ?>" 
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'خیلی خوب')">خیلی خوب</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'خوب') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'خوب')">خوب</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'قابل قبول') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'قابل قبول')">قابل قبول</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'نیاز به تلاش') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'نیاز به تلاش')">نیاز به تلاش</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'غایب') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'غایب')">🚫 غایب</button>
                                                <input type="hidden" name="student_results[<?php echo $student['id']; ?>][score]" 
                                                       value="<?php echo $result ? htmlspecialchars($result['score']) : ''; ?>">
                                            </div>
                                        <?php elseif ($activity['score_type'] === 'homework'): ?>
                                            <div class="grade-buttons-container">
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'کامل') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'کامل')">✅ کامل</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'ناقص') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'ناقص')">⚠️ ناقص</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'انجام نداده') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'انجام نداده')">❌ انجام نداده</button>
                                                <button type="button" class="grade-btn <?php echo ($result && $result['score'] === 'غایب') ? 'selected' : ''; ?>"
                                                        onclick="selectDescriptiveGrade(this, <?php echo $student['id']; ?>, 'غایب')">🚫 غایب</button>
                                                <input type="hidden" name="student_results[<?php echo $student['id']; ?>][score]" 
                                                       value="<?php echo $result ? htmlspecialchars($result['score']) : ''; ?>">
                                            </div>
                                        <?php else: ?>
                                            <input type="text" name="student_results[<?php echo $student['id']; ?>][score]" 
                                                   class="grade-input" 
                                                   value="<?php echo $result ? htmlspecialchars($result['score']) : ''; ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <textarea name="student_results[<?php echo $student['id']; ?>][feedback]" 
                                                  class="feedback-input" placeholder="بازخورد..."><?php echo $result ? htmlspecialchars($result['feedback']) : ''; ?></textarea>
                                    </td>
                                    <td>
                                        <?php if ($result): ?>
                                            <button type="button" class="btn-custom btn-danger-custom" style="font-size: 0.8rem; padding: 0.3rem 0.6rem;"
                                                    onclick="deleteScore(<?php echo $result['result_id']; ?>)">
                                                🗑️ حذف
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="text-align: center; display: flex; gap: 1rem; justify-content: center;">
                    <button type="submit" class="btn-custom btn-primary-custom">
                        💾 ذخیره تغییرات
                    </button>
                    <a href="?mode=list" class="btn-custom btn-secondary-custom">
                        انصراف
                    </a>
                    <button type="button" class="btn-custom btn-danger-custom" onclick="deleteBatch(<?php echo $selected_batch_id; ?>)">
                        🗑️ حذف کامل رکورد
                    </button>
                </div>
            </form>
        </div>
        
    <?php elseif ($view_mode === 'student'): ?>
        <!-- مدیریت دانش‌آموز محور -->
        <div class="card">
            <div class="card-header-custom">
                <h2>👤 مدیریت دانش‌آموز محور</h2>
            </div>
            
            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">انتخاب دانش‌آموز:</label>
                <select class="search-box" style="max-width: 400px;" onchange="window.location.href='?mode=student&student_id=' + this.value">
                    <option value="">-- یک دانش‌آموز را انتخاب کنید --</option>
                    <?php foreach ($students as $student): ?>
                        <option value="<?php echo $student['id']; ?>" <?php echo $selected_student_id == $student['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <?php if ($selected_student_id > 0): ?>
                <?php
                // دریافت اطلاعات دانش‌آموز
                $stmt = $db->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
                $stmt->execute([$selected_student_id]);
                $student_info = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // دریافت سوابق
                $stmt = $db->prepare("
                    SELECT 
                        ar.id as result_id,
                        ar.score,
                        ar.status,
                        ar.feedback,
                        a.id as activity_id,
                        a.date,
                        a.lesson,
                        a.topic,
                        a.title,
                        a.score_type
                    FROM activity_results ar
                    JOIN activities a ON ar.activity_id = a.id
                    WHERE ar.student_id = ?
                    ORDER BY a.date DESC, a.id DESC
                ");
                $stmt->execute([$selected_student_id]);
                $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                
                <div style="background: #f9fafb; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
                    <h3><?php echo htmlspecialchars($student_info['first_name'] . ' ' . $student_info['last_name']); ?></h3>
                    <p style="color: #6b7280; margin: 0.5rem 0 0 0;">
                        تعداد کل نمرات: <strong><?php echo en_to_fa_digits(count($records)); ?></strong>
                    </p>
                    <?php if (count($records) > 0): ?>
                        <button class="btn-custom btn-danger-custom" style="margin-top: 1rem;" onclick="deleteStudentAll(<?php echo $selected_student_id; ?>)">
                            🗑️ حذف تمام سوابق
                        </button>
                    <?php endif; ?>
                </div>
                
                <?php if (empty($records)): ?>
                    <div style="text-align: center; padding: 3rem; color: #9ca3af;">
                        <i style="font-size: 4rem;">📭</i>
                        <h3>هیچ نمره‌ای ثبت نشده است</h3>
                    </div>
                <?php else: ?>
                    <div style="margin-bottom: 1rem;">
                        <input type="text" class="search-box" placeholder="🔍 جستجو در سوابق (درس، عنوان، موضوع)..." onkeyup="searchStudentRecords(this.value)">
                    </div>
                    
                    <table class="table-custom" id="studentRecordsTable">
                        <thead>
                            <tr>
                                <th style="width: 50px;">ردیف</th>
                                <th style="width: 100px;">تاریخ</th>
                                <th style="width: 150px;">درس</th>
                                <th>عنوان فعالیت</th>
                                <th style="width: 150px;">نمره</th>
                                <th style="width: 150px;">وضعیت</th>
                                <th style="width: 200px;">بازخورد</th>
                                <th style="width: 150px;">عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $counter = 1;
                            foreach ($records as $record):
                                $maxScore = extractMaxScoreFromTitle($record['title']);
                                $status = getDerivedStatus(array_merge($record, ['activity_title' => $record['title']]));
                            ?>
                                <tr data-search-text="<?php echo strtolower($record['lesson'] . ' ' . $record['title'] . ' ' . $record['topic']); ?>">
                                    <td><?php echo en_to_fa_digits($counter++); ?></td>
                                    <td><?php echo dbdate_to_jalali_fa($record['date']); ?></td>
                                    <td><?php echo htmlspecialchars($record['lesson']); ?></td>
                                    <td><strong><?php echo htmlspecialchars($record['title']); ?></strong></td>
                                    <td style="text-align: center;">
                                        <?php if ($record['score_type'] === 'numeric' && !empty($record['score'])): ?>
                                            <strong><?php echo en_to_fa_digits($record['score'] . '/' . $maxScore); ?></strong>
                                        <?php elseif (!empty($record['score'])): ?>
                                            <strong><?php echo htmlspecialchars($record['score']); ?></strong>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge" style="background-color: <?php echo $status['color']; ?>20; color: <?php echo $status['color']; ?>;">
                                            <?php echo $status['icon']; ?> <?php echo $status['text']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($record['feedback'] ?: '-'); ?></td>
                                    <td>
                                        <button class="btn-custom btn-warning-custom" style="font-size: 0.8rem; padding: 0.3rem 0.6rem;"
                                                onclick="window.location.href='?mode=edit_batch&batch_id=<?php echo $record['activity_id']; ?>'">
                                            ✏️ ویرایش
                                        </button>
                                        <button class="btn-custom btn-danger-custom" style="font-size: 0.8rem; padding: 0.3rem 0.6rem;"
                                                onclick="deleteScore(<?php echo $record['result_id']; ?>)">
                                            🗑️ حذف
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function searchTable(searchTerm) {
    const rows = document.querySelectorAll('#studentsTable tbody tr');
    const term = searchTerm.toLowerCase();
    
    rows.forEach(row => {
        const name = row.getAttribute('data-student-name');
        if (name && name.includes(term)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function searchStudentRecords(searchTerm) {
    const rows = document.querySelectorAll('#studentRecordsTable tbody tr');
    const term = searchTerm.toLowerCase();
    
    rows.forEach(row => {
        const searchText = row.getAttribute('data-search-text');
        if (searchText && searchText.includes(term)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function selectDescriptiveGrade(button, studentId, grade) {
    // حذف selected از همه دکمه‌های همین ردیف
    const container = button.closest('.grade-buttons-container');
    container.querySelectorAll('.grade-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    
    // افزودن selected به دکمه کلیک شده
    button.classList.add('selected');
    
    // تنظیم مقدار input hidden
    const hiddenInput = container.querySelector('input[type="hidden"]');
    if (hiddenInput) {
        hiddenInput.value = grade;
    }
}

function deleteScore(resultId) {
    if (confirm('آیا از حذف این نمره اطمینان دارید؟\n\nXP دانش‌آموز به صورت خودکار اصلاح می‌شود.')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_student_score">
            <input type="hidden" name="result_id" value="${resultId}">
            <input type="hidden" name="redirect_to" value="${window.location.href}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function deleteBatch(activityId) {
    if (confirm('⚠️ هشدار!\n\nآیا از حذف کامل این رکورد دسته‌ای اطمینان دارید؟\n\nتمام نمرات دانش‌آموزان حذف خواهد شد و XP آنها اصلاح می‌شود.\n\nاین عمل غیرقابل بازگشت است!')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_batch">
            <input type="hidden" name="activity_id" value="${activityId}">
            <input type="hidden" name="redirect_to" value="?mode=list">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function deleteStudentAll(studentId) {
    if (confirm('⚠️ هشدار!\n\nآیا از حذف تمام سوابق این دانش‌آموز اطمینان دارید؟\n\nتمام نمرات و XP او پاک خواهد شد.\n\nاین عمل غیرقابل بازگشت است!')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_student_all">
            <input type="hidden" name="student_id" value="${studentId}">
            <input type="hidden" name="redirect_to" value="?mode=student&student_id=${studentId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
</body>
</html>