<?php
session_start();
require_once '../config.php';
$db = $conn;

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    header('Location: ../index.php');
    exit;
}

$student_id   = (int)$_SESSION['user_id'];
$student_name = $_SESSION['user_name'] ?? 'دانش‌آموز';

/* ---------- Helpers ---------- */
function getSubjects($db) {
    try {
        $stmt = $db->prepare("SELECT setting_value FROM class_settings WHERE setting_type='subject' AND is_active=1");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if ($rows) return $rows;
    } catch (Exception $e) {}
    return ['ریاضی','فارسی','علوم','مطالعات اجتماعی','انگلیسی'];
}

function getStatusInfo($status) {
    $status = trim((string)$status);
    $map = [
        'complete'      => ['text'=>'کامل','color'=>'#22c55e','icon'=>'✅'],
        'completed'     => ['text'=>'کامل','color'=>'#22c55e','icon'=>'✅'],
        'submitted'     => ['text'=>'ثبت شده','color'=>'#22c55e','icon'=>'✅'],
        'incomplete'    => ['text'=>'ناقص','color'=>'#f59e0b','icon'=>'⚠️'],
        'not_submitted' => ['text'=>'انجام نشده','color'=>'#ef4444','icon'=>'❌'],
        'absent'        => ['text'=>'غایب','color'=>'#6b7280','icon'=>'🚫'],
        'خیلی خوب'      => ['text'=>'عالی','color'=>'#059669','icon'=>'🌟'],
        'خوب'           => ['text'=>'خوب','color'=>'#10b981','icon'=>'👍'],
        'قابل قبول'     => ['text'=>'قابل قبول','color'=>'#f59e0b','icon'=>'🟡'],
        'نیاز به تلاش'  => ['text'=>'نیاز به تلاش','color'=>'#ef4444','icon'=>'🔴'],
        'کامل'          => ['text'=>'کامل','color'=>'#22c55e','icon'=>'✅'],
        'ناقص'          => ['text'=>'ناقص','color'=>'#f59e0b','icon'=>'⚠️'],
        'عدم ارائه'     => ['text'=>'انجام نشده','color'=>'#ef4444','icon'=>'❌'],
        'غایب'          => ['text'=>'غایب','color'=>'#6b7280','icon'=>'🚫'],
        'انجام نداده'   => ['text'=>'انجام نداده','color'=>'#ef4444','icon'=>'❌'],
    ];
    return $map[$status] ?? ['text'=>'','color'=>'#9ca3af','icon'=>''];
}

function extractMaxScoreFromTitle($title) {
    if (preg_match('/\(از\s*?(\d+)\s*?نمره\)/u', $title, $matches)) {
        $score = (int)$matches[1];
        if ($score > 0) {
            return $score;
        }
    }
    return 20;
}

function getNumericEquivalentForDescriptive($score) {
    $equivalenceMap = [
        'عالی' => 20, 'خیلی خوب' => 20, 'خوب' => 17.5, 'قابل قبول' => 15,
        'ناقص' => 15, 'نیاز به تلاش' => 10, 'انجام نداده' => 10,
        'کامل' => 20, 'غایب' => 0
    ];
    return $equivalenceMap[trim($score)] ?? 10;
}

function getDescriptiveFromNumeric($score, $maxScore) {
    if ($maxScore <= 0) return 'نامشخص';
    $percentage = $score / $maxScore;
    if ($percentage >= 0.9) return 'عالی';
    if ($percentage >= 0.75) return 'خوب';
    if ($percentage >= 0.5) return 'قابل قبول';
    return 'نیاز به تلاش';
}

/* ---------- Date Helpers ---------- */
function en_to_fa_digits($str) {
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, $str);
}

function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + floor(($gy2 + 3) / 4) - floor(($gy2 + 99) / 100) + floor(($gy2 + 399) / 400) + $gd;
    for ($i = 0; $i < $gm; $i++) $days += $g_d_m[$i];
    $jy = -1595 + (33 * floor($days / 12053));
    $days %= 12053;
    $jy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + floor($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $days -= 186;
        $jm = 7 + floor($days / 30);
        $jd = 1 + ($days % 30);
    }
    return [$jy, $jm, $jd];
}

function dbdate_to_jalali_fa($dateStr) {
    $dateStr = trim((string)$dateStr);
    if ($dateStr === '') return '';
    $dateStr = str_replace('.', '-', $dateStr);
    $parts = preg_split('/[\/\-]/', $dateStr);
    if (count($parts) < 3) return $dateStr;
    $gy = (int)$parts[0]; $gm = (int)$parts[1]; $gd = (int)$parts[2];
    if ($gy <= 0 || $gm <= 0 || $gd <= 0) return $dateStr;
    [$jy, $jm, $jd] = gregorian_to_jalali($gy, $gm, $gd);
    $out = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    return en_to_fa_digits($out);
}

/* ---------- Student info ---------- */
try {
    $stmt = $db->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['first_name'=>'','last_name'=>''];
} catch (Exception $e) {
    $student_info = ['first_name'=>'','last_name'=>''];
}

/* ---------- Calculate Stats ---------- */
$stats = [
    'total_activities' => 0,
    'completed_homework' => 0,
    'avg_score' => 0,
    'subject_averages' => [],
    'latest_grade' => null
];

try {
    $stmt = $db->prepare("
        SELECT a.*, ar.score, ar.status, ar.feedback, ar.id as result_id
        FROM activities a
        LEFT JOIN activity_results ar ON ar.activity_id = a.id AND ar.student_id = ?
        ORDER BY a.date DESC, ar.id DESC
    ");
    $stmt->execute([$student_id]);
    $all_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $all_activities = array_filter($all_activities, function($activity) {
        return !empty($activity['score']);
    });
    
    $numeric_scores = [];
    $subject_scores = [];
    $three_days_ago = date('Y-m-d', strtotime('-3 days'));

    foreach ($all_activities as $activity) {
        // *** شروع تغییر شماره 2: اصلاح منطق کارت تکلیف انجام شده ***
        // فقط فعالیت‌هایی را بشمار که موضوع آن‌ها "تکلیف" و وضعیتشان "کامل" یا "ناقص" است
        if ($activity['topic'] === 'تکلیف') {
            if (in_array($activity['score'], ['کامل', 'ناقص'])) {
                $stats['completed_homework']++;
            }
        }
        // *** پایان تغییر شماره 2 ***
        
        $scoreForAverage = null;
        if ($activity['score_type'] === 'numeric' && !empty($activity['score'])) {
            $s2 = preg_replace('/[^\d\.\-]/u', '', strtr($activity['score'] ?? '', ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']));
            if ($s2 !== '' && is_numeric($s2)) {
                $rawScore = (float)$s2;
                $maxScore = extractMaxScoreFromTitle($activity['title']);
                if ($maxScore <= 0) { $maxScore = 20; }
                $scoreForAverage = ($rawScore / $maxScore) * 20;
            }
        } elseif (in_array($activity['score_type'], ['descriptive', 'homework'])) {
            $scoreForAverage = getNumericEquivalentForDescriptive($activity['score']);
        }

        if ($scoreForAverage !== null) {
            $numeric_scores[] = $scoreForAverage;
            $lesson = $activity['lesson'];
            if (!isset($subject_scores[$lesson])) {
                $subject_scores[$lesson] = [];
            }
            $subject_scores[$lesson][] = $scoreForAverage;
        }

        if ($stats['latest_grade'] === null) {
            $stats['latest_grade'] = $activity;
        }
    }
    $stats['total_activities'] = count($all_activities);
    
    if (!empty($numeric_scores)) {
        $stats['avg_score'] = round(array_sum($numeric_scores) / count($numeric_scores), 1);
    }
    
    foreach ($subject_scores as $lesson => $scores) {
        $stats['subject_averages'][$lesson] = round(array_sum($scores) / count($scores), 1);
    }
    
} catch (Exception $e) {
    $all_activities = [];
}

/* ---------- Filtering ---------- */
$subjects = getSubjects($db);
$lesson_filter = trim($_GET['lesson'] ?? '');
$filtered_activities = $all_activities;

if ($lesson_filter !== '') {
    $filtered_activities = array_filter($all_activities, function($activity) use ($lesson_filter) {
        return $activity['lesson'] === $lesson_filter;
    });
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType   = $_SESSION['user_type'] ?? '';
$userName   = $_SESSION['user_name'] ?? 'کاربر';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>نمرات من - ستاره ماه</title>
  <link rel="stylesheet" href="/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/script.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --primary: #4ade80; --primary-dark: #22c55e; --secondary: #60a5fa; --accent: #fbbf24; --success: #10b981; --warning: #f59e0b; --danger: #ef4444; --gray: #6b7280; --light: #f0fdf4; --white: #ffffff; --shadow: 0 4px 15px rgba(0,0,0,0.08); --shadow-lg: 0 10px 30px rgba(0,0,0,0.12); }
    * { box-sizing: border-box; }
    body { font-family: 'Vazir', sans-serif; background: linear-gradient(135deg, #4ade80 0%, #60a5fa 50%, #fbbf24 100%); min-height: 100vh; margin: 0; padding: 20px 0; color: #1f2937; }
    .container { max-width: 1100px; margin: 0 auto; padding: 0 15px; }
    .header { background: var(--white); border-radius: 20px; padding: 20px 30px; margin-bottom: 25px; box-shadow: var(--shadow-lg); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; border: 2px solid var(--primary); }
    .header-title { font-size: 22px; font-weight: 700; color: var(--primary-dark); display: flex; align-items: center; gap: 10px; }
    .notifications { position: fixed; top: 20px; left: 20px; z-index: 1000; display: flex; flex-direction: column; gap: 10px; }
    .notification { background: var(--white); padding: 15px 20px; border-radius: 15px; box-shadow: var(--shadow-lg); display: flex; align-items: center; gap: 12px; min-width: 300px; animation: slideIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55); border-right: 5px solid var(--accent); }
    .notification.success { border-right-color: var(--success); }
    .notification.warning { border-right-color: var(--warning); }
    .notification-icon { font-size: 24px; }
    .notification-content h4 { margin: 0 0 4px 0; font-size: 15px; font-weight: 700; }
    .notification-content p { margin: 0; font-size: 13px; color: var(--gray); }
    .notification-close { margin-right: auto; background: none; border: none; font-size: 20px; color: var(--gray); cursor: pointer; padding: 0; }
    @keyframes slideIn { from { transform: translateX(-100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 25px; }
    .stat-card { background: var(--white); border-radius: 20px; padding: 25px; box-shadow: var(--shadow); text-align: center; transition: transform 0.3s ease, box-shadow 0.3s ease; border-top: 4px solid var(--primary); }
    .stat-card:nth-child(2) { border-top-color: var(--secondary); }
    .stat-card:nth-child(3) { border-top-color: var(--accent); }
    .stat-card:nth-child(4) { border-top-color: var(--warning); }
    .stat-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); }
    .stat-card h3 { font-size: 15px; font-weight: 600; color: var(--gray); margin: 0 0 10px 0; }
    .stat-value { font-size: 32px; font-weight: 800; color: #1f2937; margin: 0; }
    .stat-detail { font-size: 13px; color: var(--gray); margin-top: 5px; }
    .subject-averages { background: var(--white); border-radius: 20px; padding: 25px; margin-bottom: 25px; box-shadow: var(--shadow); }
    .subject-averages h2 { font-size: 20px; font-weight: 700; margin: 0 0 20px 0; color: #1f2937; text-align: center; }
    .subject-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 15px; }
    .subject-item { background: var(--light); border: 2px solid #e5e7eb; border-radius: 15px; padding: 15px; text-align: center; transition: transform 0.2s ease; }
    .subject-item:hover { transform: scale(1.05); }
    .subject-name { font-size: 14px; font-weight: 600; color: var(--gray); margin-bottom: 5px; }
    .subject-score { font-size: 22px; font-weight: 800; }
    .subject-score.max { color: var(--success); }
    .subject-score.good { color: var(--primary); }
    .subject-score.low { color: var(--warning); }
    .filter-bar { background: var(--white); border-radius: 20px; padding: 20px 25px; margin-bottom: 25px; box-shadow: var(--shadow); display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
    .filter-bar select { padding: 10px 15px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 14px; font-family: 'Vazir', sans-serif; }
    .btn { padding: 10px 20px; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; font-family: 'Vazir', sans-serif; }
    .btn-primary { background: var(--primary); color: white; }
    .btn-primary:hover { background: var(--primary-dark); }
    .grades-section { background: var(--white); border-radius: 20px; padding: 25px; box-shadow: var(--shadow); }
    .grades-section h2 { font-size: 20px; font-weight: 700; margin: 0 0 20px 0; color: #1f2937; text-align: center; }
    .grades-table { width: 100%; border-collapse: collapse; }
    .grades-table th { background: #f9fafb; padding: 15px; text-align: right; font-size: 14px; font-weight: 700; color: #000; border-bottom: 2px solid #e5e7eb; }
    .grades-table td { padding: 15px; border-bottom: 1px solid #f3f4f6; font-size: 14px; color: #000; }
    .grades-table tr:hover { background: #f9fafb; }
    .grade-new { background: #fef3c7 !important; font-weight: bold; animation: highlightNew 2s ease; }
    @keyframes highlightNew { 0% { background-color: #fde047; } 100% { background-color: #fef3c7; } }
    .lesson-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; background: #f3f4f6; border-radius: 10px; font-size: 13px; font-weight: 600; }
    .score-badge { display: inline-block; padding: 8px 15px; border-radius: 10px; font-weight: 700; font-size: 15px; }
    .score-badge.numeric { background: #dbeafe; color: #1e40af; }
    .score-badge.descriptive { background: #d1fae5; color: #065f46; }
    .score-badge.homework { background: #fef3c7; color: #92400e; }
    .status-badge { display: inline-flex; align-items: center; gap: 5px; padding: 5px 10px; border-radius: 8px; font-size: 12px; font-weight: 600; }
    .feedback-text { font-size: 13px; color: var(--gray); font-style: italic; max-width: 300px; }
    .empty-state { text-align: center; padding: 40px; color: var(--gray); }
    .empty-state i { font-size: 48px; margin-bottom: 10px; opacity: 0.5; }
    @media (max-width: 768px) { .header { flex-direction: column; text-align: center; } .stats-grid { grid-template-columns: 1fr; } .subject-list { grid-template-columns: repeat(2, 1fr); } .grades-table { font-size: 12px; } .grades-table th, .grades-table td { padding: 10px; } }
  </style>
</head>
<body>
  <div class="stars" id="stars" aria-hidden="true"></div>
  <div class="moon" aria-hidden="true"></div>
  <nav role="navigation" aria-label="منوی اصلی">
    <div class="nav-container">
      <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه"><img src="/images/logo.png" alt="لوگو ستاره ماه"></div>
      <div class="desktop-menu" role="menubar">
        <div class="menu-row"><a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a><a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a><a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a><a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a></div>
        <div class="menu-row"><a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮 بازی‌ها</a><a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a><a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a><a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a><?php if($isLoggedIn && $userType == 'admin'): ?><a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a><?php endif; ?></div>
      </div>
      <div class="mobile-menu-container"><button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی موبایل" aria-expanded="false" aria-controls="mobileDropdown"><span>منو</span><span class="menu-icon">▼</span></button><div class="mobile-dropdown" id="mobileDropdown" role="menu"><ul><li><a href="/index.php" role="menuitem">🏠 خانه</a></li><li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li><li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li><li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li><li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li><li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li><li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li><li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li><?php if($isLoggedIn && $userType == 'admin'): ?><li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li><?php endif; ?></ul></div></div>
      <div class="auth-section"><?php if ($isLoggedIn): ?><div class="user-info glass-effect"><span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span><a href="/logout.php" class="logout-btn interactive-element">خروج</a></div><?php else: ?><button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button><?php endif; ?></div>
    </div>
  </nav>
  <div class="container">
    <header class="header"><div class="header-title"><i class="fas fa-graduation-cap"></i>دفتر کلاسی دانش‌آموز (<?php echo htmlspecialchars($student_info['first_name'] . ' ' . $student_info['last_name']); ?>)</div></header>
    <div class="notifications" id="notifications"></div>
    <div class="stats-grid">
      <div class="stat-card"><h3>میانگین کل نمرات</h3><p class="stat-value"><?php echo $stats['avg_score']; ?></p><p class="stat-detail">از 20 نمره</p></div>
      <div class="stat-card"><h3>تکالیف انجام شده</h3><p class="stat-value"><?php echo $stats['completed_homework']; ?></p><p class="stat-detail">از <?php echo $stats['total_activities']; ?> فعالیت</p></div>
      <div class="stat-card">
        <h3>آخرین نمره</h3>
        <?php if ($stats['latest_grade']): ?>
          <?php if (is_numeric($stats['latest_grade']['score'])): ?>
              <p class="stat-value"><?php echo htmlspecialchars($stats['latest_grade']['score']); ?></p>
          <?php else: ?>
              <p class="stat-value" style="font-size: 20px;"><?php echo htmlspecialchars($stats['latest_grade']['score']); ?></p>
          <?php endif; ?>
          <p class="stat-detail"><?php echo htmlspecialchars($stats['latest_grade']['lesson']); ?></p>
        <?php else: ?>
          <p class="stat-value">-</p><p class="stat-detail">موردی یافت نشد</p>
        <?php endif; ?>
      </div>
      <div class="stat-card"><h3>تعداد فعالیت‌ها</h3><p class="stat-value"><?php echo count($filtered_activities); ?></p><p class="stat-detail">ثبت شده</p></div>
    </div>
    <?php if (!empty($stats['subject_averages'])): ?>
    <div class="subject-averages"><h2>میانگین نمرات به تفکیک درس</h2><div class="subject-list"><?php foreach ($stats['subject_averages'] as $subject => $avg): ?><?php $scoreClass = ''; if ($avg >= 17) $scoreClass = 'max'; elseif ($avg >= 14) $scoreClass = 'good'; else $scoreClass = 'low'; $icon = '📚'; if (strpos($subject, 'ریاضی') !== false) $icon = '🧮'; elseif (strpos($subject, 'علوم') !== false) $icon = '🔬'; elseif (strpos($subject, 'فارسی') !== false) $icon = '📖'; elseif (strpos($subject, 'مطالعات') !== false) $icon = '🗺️'; elseif (strpos($subject, 'انگلیسی') !== false) $icon = '🗣️'; ?><div class="subject-item"><div class="subject-name"><?php echo $icon; ?> <?php echo htmlspecialchars($subject); ?></div><div class="subject-score <?php echo $scoreClass; ?>"><?php echo $avg; ?></div></div><?php endforeach; ?></div></div>
    <?php endif; ?>
    <div class="filter-bar"><label for="lesson" style="font-weight: 600;">فیلتر درس:</label><form method="get" style="display: flex; gap: 10px; align-items: center; flex: 1;"><select id="lesson" name="lesson"><option value="">همه دروس</option><?php foreach ($subjects as $subject): ?><option value="<?php echo htmlspecialchars($subject); ?>" <?php echo ($lesson_filter === $subject) ? 'selected' : ''; ?>><?php echo htmlspecialchars($subject); ?></option><?php endforeach; ?></select><button type="submit" class="btn btn-primary">اعمال</button><?php if ($lesson_filter !== ''): ?><a href="?" class="btn" style="background: #f3f4f6; color: #374151;">حذف فیلتر</a><?php endif; ?></form></div>
    <div class="grades-section"><h2>لیست نمرات</h2><?php if (empty($filtered_activities)): ?><div class="empty-state"><i class="fas fa-inbox"></i><h3>موردی برای نمایش وجود ندارد</h3><p>هنوز نمره‌ای برای شما ثبت نشده است</p></div><?php else: ?>
    <table class="grades-table">
      <thead>
        <tr>
          <th>تاریخ</th>
          <th>درس</th>
          <th>موضوع</th>
          <th>عنوان فعالیت</th>
          <th>نمره</th>
          <th>وضعیت</th>
          <th>توضیحات</th>
        </tr>
      </thead>
      <tbody id="grades-table-body"><?php foreach ($filtered_activities as $activity): ?><?php $dateFa = dbdate_to_jalali_fa($activity['date'] ?? ''); $maxScore = extractMaxScoreFromTitle($activity['title']); $isNew = false; if (!empty($activity['date']) && $activity['date'] >= $three_days_ago) { $isNew = true; } ?><tr class="<?php echo $isNew ? 'grade-new' : ''; ?>" data-id="<?php echo $activity['result_id']; ?>"><td><?php echo $dateFa; ?></td><td><span class="lesson-badge"><?php $icon = '📚'; if (strpos($activity['lesson'], 'ریاضی') !== false) $icon = '🧮'; elseif (strpos($activity['lesson'], 'علوم') !== false) $icon = '🔬'; elseif (strpos($activity['lesson'], 'فارسی') !== false) $icon = '📖'; elseif (strpos($activity['lesson'], 'مطالعات') !== false) $icon = '🗺️'; elseif (strpos($activity['lesson'], 'انگلیسی') !== false) $icon = '🗣️'; ?><?php echo $icon; ?> <?php echo htmlspecialchars($activity['lesson']); ?></span></td>
          <td><?php echo htmlspecialchars($activity['topic']); ?></td>
          <td><?php echo htmlspecialchars($activity['title']); ?></td>
                <td>
                  <?php if (is_numeric($activity['score'])): ?>
                    <span class="score-badge numeric"><?php echo htmlspecialchars($activity['score']); ?>/<?php echo $maxScore; ?></span>
                  <?php else: ?>
                    <span class="score-badge <?php echo ($activity['score_type'] === 'homework') ? 'homework' : 'descriptive'; ?>"><?php echo htmlspecialchars($activity['score']); ?></span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php 
                    $statusInfo = [];
                    if (is_numeric($activity['score'])) {
                        $rawScore = (float)$activity['score'];
                        $descriptiveStatus = getDescriptiveFromNumeric($rawScore, $maxScore);
                        $statusInfo = getStatusInfo($descriptiveStatus);
                    } else {
                        $statusInfo = getStatusInfo($activity['score']);
                    }
                  ?>
                  <?php if($statusInfo['text'] !== ''): ?>
                    <span class="status-badge" style="background-color: <?php echo $statusInfo['color']; ?>20; color: <?php echo $statusInfo['color']; ?>;"><?php echo $statusInfo['icon']; ?> <?php echo $statusInfo['text']; ?></span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td><?php if (!empty($activity['feedback'])): ?><span class="feedback-text"><?php echo htmlspecialchars($activity['feedback']); ?></span><?php else: ?>-<?php endif; ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
  </div>
  <script>
    let existingGradeIds = new Set(Array.from(document.querySelectorAll('#grades-table-body tr[data-id]')).map(row => row.dataset.id));
    function checkForNewGrades() { fetch('classNotebook_user.php?check_new=true&<?php echo time(); ?>').then(response => response.json()).then(data => { if (data.newGrades && data.newGrades.length > 0) { const tableBody = document.getElementById('grades-table-body'); let hasNewGrades = false; data.newGrades.forEach(grade => { if (!existingGradeIds.has(grade.result_id.toString())) { hasNewGrades = true; existingGradeIds.add(grade.result_id.toString()); let icon = '📚'; if (grade.lesson.includes('ریاضی')) icon = '🧮'; else if (grade.lesson.includes('علوم')) icon = '🔬'; else if (grade.lesson.includes('فارسی')) icon = '📖'; else if (grade.lesson.includes('مطالعات')) icon = '🗺️'; else if (grade.lesson.includes('انگلیسی')) icon = '🗣️'; const maxScore = grade.title.match(/\(از\s*?(\d+)\s*?نمره\)/) ? grade.title.match(/\(از\s*?(\d+)\s*?نمره\)/)[1] : 20; let scoreBadgeHtml = ''; if (isNumeric(grade.score)) { scoreBadgeHtml = `<span class="score-badge numeric">${grade.score}/${maxScore}</span>`; } else { scoreBadgeHtml = `<span class="score-badge ${grade.score_type === 'homework' ? 'homework' : 'descriptive'}">${grade.score}</span>`; } let statusInfo = {}; if (isNumeric(grade.score)) { const descriptiveStatus = getDescriptiveFromNumeric(parseFloat(grade.score), maxScore); statusInfo = getStatusInfo(descriptiveStatus); } else { statusInfo = getStatusInfo(grade.score); } const statusBadgeHtml = statusInfo.text ? `<span class="status-badge" style="background-color: ${statusInfo.color}20; color: ${statusInfo.color};">${statusInfo.icon} ${statusInfo.text}</span>` : '-'; const newRowHtml = `<tr class="grade-new" data-id="${grade.result_id}"><td>${grade.date_fa}</td><td><span class="lesson-badge">${icon} ${grade.lesson}</span></td><td>${grade.topic}</td><td>${grade.title}</td><td>${scoreBadgeHtml}</td><td>${statusBadgeHtml}</td><td><span class="feedback-text">${grade.feedback || '-'}</span></td></tr>`; tableBody.insertAdjacentHTML('afterbegin', newRowHtml); } }); if (hasNewGrades) { showNotification('نمره جدید!', `${data.newGrades.length} نمره جدید برای شما ثبت شده است.`, 'success'); } } }).catch(error => console.error('Error checking for new grades:', error)); }
    function isNumeric(str) { return !isNaN(parseFloat(str)) && isFinite(str); }
    function getStatusInfo(status) { const map = { 'complete': {text:'کامل', color:'#22c55e', icon:'✅'}, 'completed': {text:'کامل', color:'#22c55e', icon:'✅'}, 'submitted': {text:'ثبت شده', color:'#22c55e', icon:'✅'}, 'incomplete': {text:'ناقص', color:'#f59e0b', icon:'⚠️'}, 'not_submitted': {text:'انجام نشده', color:'#ef4444', icon:'❌'}, 'absent': {text:'غایب', color:'#6b7280', icon:'🚫'}, 'خیلی خوب': {text:'عالی', color:'#059669', icon:'🌟'}, 'خوب': {text:'خوب', color:'#10b981', icon:'👍'}, 'قابل قبول': {text:'قابل قبول', color:'#f59e0b', icon:'🟡'}, 'نیاز به تلاش': {text:'نیاز به تلاش', color:'#ef4444', icon:'🔴'}, 'کامل': {text:'کامل', color:'#22c55e', icon:'✅'}, 'ناقص': {text:'ناقص', color:'#f59e0b', icon:'⚠️'}, 'عدم ارائه': {text:'انجام نشده', color:'#ef4444', icon:'❌'}, 'غایب': {text:'غایب', color:'#6b7280', icon:'🚫'}, 'انجام نداده': {text:'انجام نداده', color:'#ef4444', icon:'❌'} }; return map[status] || {text:'', color:'#9ca3af', icon:''}; }
    function getDescriptiveFromNumeric(score, maxScore) { if (maxScore <= 0) return 'نامشخص'; const percentage = score / maxScore; if (percentage >= 0.9) return 'عالی'; if (percentage >= 0.75) return 'خوب'; if (percentage >= 0.5) return 'قابل قبول'; return 'نیاز به تلاش'; }
    function showNotification(title, message, type = 'success') { const notificationsContainer = document.getElementById('notifications'); const notification = document.createElement('div'); notification.className = `notification ${type}`; notification.innerHTML = `<i class="fas fa-sparkles notification-icon"></i><div class="notification-content"><h4>${title}</h4><p>${message}</p></div><button class="notification-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>`; notificationsContainer.appendChild(notification); setTimeout(() => { notification.style.animation = 'slideOut 0.3s ease forwards'; setTimeout(() => notification.remove(), 300); }, 5000); }
    setInterval(checkForNewGrades, 30000);
    document.addEventListener('DOMContentLoaded', function() { checkForNewGrades(); const starsContainer = document.getElementById('stars'); if (starsContainer) { for (let i = 0; i < 50; i++) { const star = document.createElement('div'); star.className = 'star'; star.style.left = Math.random() * 100 + '%'; star.style.top = Math.random() * 100 + '%'; star.style.animationDelay = Math.random() * 4 + 's'; star.style.animationDuration = (Math.random() * 3 + 2) + 's'; starsContainer.appendChild(star); } } const mobileMenuBtn = document.getElementById('mobileMenuBtn'); const mobileDropdown = document.getElementById('mobileDropdown'); if (mobileMenuBtn && mobileDropdown) { mobileMenuBtn.addEventListener('click', function(e) { e.stopPropagation(); const isOpen = mobileDropdown.classList.contains('show'); if (isOpen) { mobileDropdown.classList.remove('show'); mobileMenuBtn.classList.remove('active'); mobileMenuBtn.setAttribute('aria-expanded', 'false'); } else { mobileDropdown.classList.add('show'); mobileMenuBtn.classList.add('active'); mobileMenuBtn.setAttribute('aria-expanded', 'true'); } }); document.addEventListener('click', function(e) { if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) { mobileDropdown.classList.remove('show'); mobileMenuBtn.classList.remove('active'); mobileMenuBtn.setAttribute('aria-expanded', 'false'); } }); } });
    const style = document.createElement('style'); style.textContent = `@keyframes slideOut { to { transform: translateX(-120%); opacity: 0; } }`; document.head.appendChild(style);
  </script>
</body>
</html>
<?php
if (isset($_GET['check_new']) && $_GET['check_new'] === 'true') {
    header('Content-Type: application/json');
    $new_grades = []; $three_days_ago = date('Y-m-d', strtotime('-3 days'));
    try {
        $stmt = $db->prepare("SELECT a.*, ar.score, ar.status, ar.feedback, ar.id as result_id FROM activities a LEFT JOIN activity_results ar ON ar.activity_id = a.id AND ar.student_id = ? WHERE ar.score IS NOT NULL AND ar.score != '' AND a.date >= ? ORDER BY a.date DESC, ar.id DESC");
        $stmt->execute([$student_id, $three_days_ago]);
        $recent_activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $recent_activities = array_filter($recent_activities, function($activity) { return !empty($activity['score']); });
        foreach ($recent_activities as $activity) { $new_grades[] = [ 'result_id' => $activity['result_id'], 'date_fa' => dbdate_to_jalali_fa($activity['date']), 'lesson' => $activity['lesson'], 'topic' => $activity['topic'], 'title' => $activity['title'], 'score' => $activity['score'], 'score_type' => $activity['score_type'], 'status' => $activity['status'], 'feedback' => $activity['feedback'] ]; }
    } catch (Exception $e) {}
    echo json_encode(['newGrades' => $new_grades]); exit;
}
?>