<?php
// Podcast section - Only show if logged in
// فرض می‌کنیم توابع isLoggedIn(), getPodcasts($conn), isAdmin() و اتصال به دیتابیس ($conn) در جای دیگری تعریف شده‌اند.
if (!isLoggedIn()) { exit(); }

// تابع تبدیل تاریخ میلادی به شمسی
function convertToShamsi($gregorianDate) {
    if (empty($gregorianDate)) return '';
    
    $timestamp = strtotime($gregorianDate);
    if (!$timestamp) return $gregorianDate;
    
    $jy = null; $jm = null; $jd = null;
    
    $gy = date('Y', $timestamp);
    $gm = date('n', $timestamp);
    $gd = date('j', $timestamp);
    $gh = date('H', $timestamp);
    $gi = date('i', $timestamp);
    
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    
    if ($gy <= 1600) {
        $jy = 0;
        $gy -= 621;
    } else {
        $jy = 979;
        $gy -= 1600;
    }
    
    if ($gm > 2) {
        $gy2 = $gy + 1;
    } else {
        $gy2 = $gy;
    }
    
    $days = (365 * $gy) + (intval(($gy2 + 3) / 4)) - (intval(($gy2 + 99) / 100)) + (intval(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];
    
    $jy += 33 * intval($days / 12053);
    $days %= 12053;
    
    $jy += 4 * intval($days / 1461);
    $days %= 1461;
    
    if ($days > 365) {
        $jy += intval(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    
    if ($days < 186) {
        $jm = 1 + intval($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intval(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    
    $shamsi_months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    
    return $jd . ' ' . $shamsi_months[$jm] . ' ' . $jy . ' - ' . sprintf('%02d:%02d', $gh, $gi);
}
?>
<section id="podcast" class="section" dir="rtl">
    <div class="podcast-header">
        <h2 class="podcast-title">🎧 اتاق جادویی پادکست‌ها</h2>
        <p class="podcast-subtitle">به دنیای شگفت‌انگیز داستان‌ها و آموزش‌ها خوش آمدید!</p>
    </div>

    <?php
    // تابع getPodcasts باید طوری تغییر کند که اگر کاربر ادمین نبود، فقط پادکست‌های فعال را برگرداند
    $podcasts = getPodcasts($conn) ?: [];
    // استخراج موضوعات برای فیلتر
    $topicMap = [];
    foreach ($podcasts as $p) {
        $t = trim($p['topic'] ?? ($p['subject'] ?? ''));
        if ($t !== '') { $topicMap[$t] = true; }
    }
    $topics = array_keys($topicMap);
    ?>

    <!-- نوار ابزار بالای لیست: جستجو / فیلتر موضوع / مرتب‌سازی -->
    <div class="podcast-toolbar">
        <div class="search-box">
            <input id="podcastSearch" type="search" placeholder="🔍 جستجو در عنوان یا توضیحات…" aria-label="جستجو پادکست">
        </div>
        <div class="filter-box">
            <select id="filterTopic" aria-label="فیلتر موضوع">
                <option value="">🌟 همهٔ موضوع‌ها</option>
                <?php foreach ($topics as $t): ?>
                    <option value="<?php echo htmlspecialchars($t); ?>"><?php echo htmlspecialchars($t); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="sort-box">
            <select id="podcastSort" aria-label="مرتب‌سازی">
                <option value="new">📅 جدیدترین</option>
                <option value="old">🕰 قدیمی‌ترین</option>
                <option value="title">🔤 عنوان (الف⇢ی)</option>
                <option value="topic">🏷 موضوع</option>
            </select>
        </div>
    </div>

    <div id="podcastList" class="podcast-list">
        <?php if ($podcasts): ?>
            <?php foreach ($podcasts as $podcast): ?>
                <?php
                    $id    = htmlspecialchars($podcast['id']);
                    $title = htmlspecialchars($podcast['title'] ?? 'بدون عنوان');
                    $desc  = htmlspecialchars($podcast['description'] ?? '');
                    $dur   = htmlspecialchars($podcast['duration'] ?? '');
                    $file  = htmlspecialchars($podcast['file_path'] ?? '');
                    $topic = htmlspecialchars($podcast['topic'] ?? ($podcast['subject'] ?? ''));
                    $file_type = $podcast['file_type'] ?? 'audio';
                    // تبدیل تاریخ به شمسی
                    $date_raw  = $podcast['created_at'] ?? $podcast['updated_at'] ?? '';
                    $date = convertToShamsi($date_raw);
                    // وضعیت فعال بودن پادکست
                    $is_active = (int)($podcast['is_active'] ?? 1);
                ?>
                <div class="podcast-card <?php echo isAdmin() && !$is_active ? 'inactive-card' : ''; ?>" 
                     data-id="<?php echo $id; ?>"
                     data-title="<?php echo $title; ?>"
                     data-desc="<?php echo $desc; ?>"
                     data-topic="<?php echo $topic; ?>"
                     data-date="<?php echo $date_raw; ?>"
                     data-file-type="<?php echo $file_type; ?>">
                    
                    <div class="podcast-image">
                        <div class="play-button" aria-label="پخش/توقف" data-audio="<?php echo $file; ?>">
                            <div class="play-icon">▶</div>
                        </div>
                        <div class="podcast-duration"><?php echo $dur ?: '⏱ نامشخص'; ?></div>
                    </div>

                    <div class="podcast-content">
                        <div class="podcast-topic"><?php echo $topic ?: '🎵 عمومی'; ?></div>
                        <h3 class="podcast-title-text"><?php echo $title; ?></h3>
                        <?php if ($desc): ?>
                            <p class="podcast-description"><?php echo $desc; ?></p>
                        <?php endif; ?>
                        
                        <div class="podcast-meta">
                            <div class="podcast-date">📅 <?php echo $date; ?></div>
                        </div>

                        <!-- پلیر صوتی یا ویدیویی -->
                        <div class="media-player-container">
                            <?php if ($file_type === 'audio'): ?>
                                <audio class="inline-media inline-audio" controls preload="metadata" src="<?php echo $file; ?>"></audio>
                            <?php else: ?>
                                <video class="inline-media inline-video" controls preload="metadata" src="<?php echo $file; ?>"></video>
                                <button class="full-media-btn" title="نمایش بزرگ">🔍 بزرگ‌نمایی</button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (isAdmin()): ?>
                    <div class="podcast-actions">
                        <!-- دکمه جدید برای تغییر وضعیت فعال/غیرفعال -->
                        <label class="switch" title="فعال/غیرفعال کردن پادکست">
                            <input type="checkbox" class="status-toggle" data-id="<?php echo $id; ?>" <?php echo $is_active ? 'checked' : ''; ?>>
                            <span class="slider round"></span>
                        </label>
                        <button class="action-btn edit-btn" title="ویرایش">✏️</button>
                        <button class="action-btn delete-btn" title="حذف">🗑️</button>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🎧</div>
                <h3>هنوز پادکستی موجود نیست!</h3>
                <p>اولین پادکست را اضافه کنید تا ماجراجویی شروع شود!</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if (isAdmin()): ?>
    <div class="upload-container">
        <div class="upload-header">
            <h3>🎙️ افزودن پادکست جدید</h3>
            <p>فایل‌های صوتی و تصویری را آپلود کنید</p>
        </div>
        <form id="uploadPodcastForm" enctype="multipart/form-data" class="upload-form">
            <div class="form-row">
                <div class="form-group">
                    <label>📝 عنوان پادکست:</label>
                    <input type="text" name="title" required placeholder="عنوان جذاب انتخاب کنید...">
                </div>
                <div class="form-group">
                    <label>⏱️ مدت زمان:</label>
                    <input type="text" name="duration" placeholder="مثال: 15 دقیقه">
                </div>
            </div>
            
            <div class="form-group">
                <label>📖 توضیحات:</label>
                <textarea name="description" rows="3" placeholder="توضیح کوتاهی درباره محتوای پادکست..."></textarea>
            </div>
            
            <div class="form-group file-group">
                <label>🎵 فایل صوتی/تصویری:</label>
                <div class="file-input-wrapper">
                    <input type="file" name="audio_file" accept="audio/*,video/*" required id="audioFile">
                    <label for="audioFile" class="file-input-label">
                        <span class="file-icon">📁</span>
                        <span class="file-text">فایل خود را انتخاب کنید</span>
                        <span class="file-formats">mp3, wav, mp4, m4a, ogg و ...</span>
                    </label>
                </div>
            </div>

            <div class="upload-actions">
                <button type="submit" class="submit-button">
                    <span class="btn-icon">🚀</span>
                    آپلود پادکست
                </button>
                <div class="upload-progress" style="display: none;">
                    <div class="progress-bar">
                        <div class="progress-fill" id="uploadBar"></div>
                    </div>
                    <span class="progress-text" id="uploadPct">0%</span>
                </div>
            </div>
        </form>
    </div>

    <!-- مودال ویرایش -->
    <div id="editPodcastModal" class="modal" style="display: none;">
        <div class="modal-backdrop"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>✏️ ویرایش پادکست</h3>
                <button class="close-modal" aria-label="بستن">✕</button>
            </div>
            <form id="editPodcastForm" enctype="multipart/form-data" class="edit-form">
                <input type="hidden" name="id">
                <div class="form-group">
                    <label>📝 عنوان پادکست:</label>
                    <input type="text" name="title" required>
                </div>
                <div class="form-group">
                    <label>📖 توضیحات:</label>
                    <textarea name="description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>⏱️ مدت زمان:</label>
                    <input type="text" name="duration" placeholder="15 دقیقه">
                </div>
                <div class="form-group">
                    <label>🎵 فایل جدید (اختیاری):</label>
                    <input type="file" name="audio_file" accept="audio/*,video/*">
                </div>
                <button type="submit" class="submit-button">
                    <span class="btn-icon">💾</span>
                    ذخیره تغییرات
                </button>
            </form>
        </div>
    </div>

    <!-- مودال نمایش ویدیو بزرگ -->
    <div id="fullVideoModal" class="modal" style="display: none;">
        <div class="modal-backdrop"></div>
        <div class="modal-content full-video-content">
            <div class="modal-header">
                <h3>📺 نمایش ویدیو بزرگ</h3>
                <button class="close-modal" aria-label="بستن">✕</button>
            </div>
            <video id="fullVideoPlayer" controls preload="metadata" style="width: 100%; height: auto;"></video>
        </div>
    </div>
    <?php endif; ?>
</section>

<style>
/* استایل‌های کلی */
.podcast-header {
    text-align: center;
    margin-bottom: 2rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 2rem;
    border-radius: 25px;
    color: white;
    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
}

.podcast-title {
    font-size: 2.2rem;
    margin: 0 0 0.5rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.podcast-subtitle {
    font-size: 1.1rem;
    opacity: 0.9;
    margin: 0;
}

/* نوار ابزار */
.podcast-toolbar {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 1rem;
    margin: 2rem 0;
    padding: 1.5rem;
    background: white;
    border-radius: 20px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}

.search-box, .filter-box, .sort-box {
    position: relative;
}

.search-box input, .filter-box select, .sort-box select {
    width: 100%;
    padding: 1rem 1.2rem;
    border: 2px solid #e8ecf4;
    border-radius: 15px;
    font-size: 1rem;
    background: #f8fafc;
    transition: all 0.3s ease;
    outline: none;
}

.search-box input:focus, .filter-box select:focus, .sort-box select:focus {
    border-color: #667eea;
    background: white;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
}

/* لیست پادکست‌ها */
.podcast-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
    margin: 2rem 0;
}

.podcast-card {
    background: white;
    border-radius: 25px;
    padding: 1.5rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border: 3px solid transparent;
    position: relative;
    overflow: hidden;
}

.podcast-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4);
    border-radius: 25px 25px 0 0;
}

.podcast-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    border-color: #667eea;
}



/* تصویر و دکمه پخش */
.podcast-image {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 1rem;
}

.play-button {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #ff6b6b, #ee5a6f);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
}

.play-button:hover {
    transform: scale(1.1);
    box-shadow: 0 12px 30px rgba(255, 107, 107, 0.6);
}

.play-icon {
    color: white;
    font-size: 2rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.podcast-duration {
    position: absolute;
    top: -10px;
    right: -10px;
    background: #4ecdc4;
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: bold;
    box-shadow: 0 4px 12px rgba(78, 205, 196, 0.3);
}

/* محتوای پادکست */
.podcast-content {
    text-align: center;
}

.podcast-topic {
    display: inline-block;
    background: linear-gradient(135deg, #96ceb4, #4ecdc4);
    color: white;
    padding: 0.4rem 1rem;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: bold;
    margin-bottom: 1rem;
}

.podcast-title-text {
    color: #2d3748;
    margin: 0.8rem 0;
    font-size: 1.3rem;
    font-weight: bold;
    line-height: 1.4;
}

.podcast-description {
    color: #4a5568;
    margin: 0.8rem 0;
    line-height: 1.6;
    font-size: 0.95rem;
}

.podcast-meta {
    margin: 1rem 0;
}

.podcast-date {
    color: #718096;
    font-size: 0.9rem;
    padding: 0.5rem 1rem;
    background: #f7fafc;
    border-radius: 15px;
    display: inline-block;
}

/* پلیر رسانه */
.media-player-container {
    margin: 1.5rem 0;
    position: relative;
    display: block;
    width: 100%;
}

.media-player-container audio,
.media-player-container video {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
}

.inline-media {
    width: 100%;
    height: auto;
    border-radius: 15px;
    outline: none;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin: 0.5rem 0;
    display: block;
}

.inline-audio {
    width: 100%;
    height: 40px;
    border-radius: 15px;
    outline: none;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin: 0.5rem 0;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
}

.inline-video {
    width: 100% !important;
    max-width: 300px !important;
    height: auto !important;
    aspect-ratio: 16/9;
    display: block;
    margin: 0 auto;
    transition: all 0.3s ease;
}

.inline-video:hover {
    box-shadow: 0 6px 16px rgba(0,0,0,0.2);
    transform: scale(1.02);
}

.full-media-btn {
    display: block;
    margin: 1rem auto 0;
    padding: 0.7rem 1.5rem;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 20px;
    cursor: pointer;
    font-size: 1rem;
    font-weight: bold;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.full-media-btn:hover {
    background: linear-gradient(135deg, #764ba2, #667eea);
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
}

.full-video-content {
    max-width: 90vw;
    max-height: 90vh;
    width: auto;
    height: auto;
}

.full-video-content video {
    width: 100%;
    height: auto;
    max-height: 70vh;
    border-radius: 15px;
}

/* دکمه‌های عمل */
.podcast-actions {
    position: absolute;
    top: 1rem;
    left: 1rem;
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.action-btn {
    width: 40px;
    height: 40px;
    border: none;
    border-radius: 50%;
    background: rgba(255,255,255,0.9);
    backdrop-filter: blur(10px);
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    font-size: 1.2rem;
}

.action-btn:hover {
    transform: scale(1.1);
    background: white;
}

.edit-btn:hover { box-shadow: 0 6px 15px rgba(102, 126, 234, 0.3); }
.delete-btn:hover { box-shadow: 0 6px 15px rgba(255, 107, 107, 0.3); }

/* استایل برای پیام امتیازدهی */
#xp-notification {
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    padding: 1rem 2rem;
    border-radius: 50px;
    box-shadow: 0 8px 25px rgba(40, 167, 69, 0.4);
    z-index: 1050;
    font-size: 1rem;
    font-weight: bold;
    opacity: 1;
    transition: opacity 0.5s ease-in-out;
    text-align: center;
}

/* استایل دکمه toggle */
.switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 24px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: .4s;
}

input:checked + .slider {
    background-color: #28a745;
}

input:focus + .slider {
    box-shadow: 0 0 1px #28a745;
}

input:checked + .slider:before {
    transform: translateX(26px);
}

.slider.round {
    border-radius: 24px;
}

.slider.round:before {
    border-radius: 50%;
}


/* حالت خالی */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    color: #718096;
}

.empty-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
}

.empty-state h3 {
    color: #2d3748;
    margin-bottom: 0.5rem;
}

/* کانتینر آپلود */
.upload-container {
    background: white;
    border-radius: 25px;
    padding: 2rem;
    margin-top: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    border: 3px solid #e2e8f0;
}

.upload-header {
    text-align: center;
    margin-bottom: 2rem;
}

.upload-header h3 {
    color: #2d3748;
    margin-bottom: 0.5rem;
    font-size: 1.5rem;
}

.upload-header p {
    color: #718096;
    margin: 0;
}

.form-row {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    color: #2d3748;
    font-weight: bold;
}

.form-group input, .form-group textarea {
    width: 100%;
    padding: 1rem;
    border: 2px solid #e2e8f0;
    border-radius: 15px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: #f8fafc;
}

.form-group input:focus, .form-group textarea:focus {
    outline: none;
    border-color: #667eea;
    background: white;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
}

/* فایل ورودی */
.file-group {
    margin-bottom: 2rem;
}

.file-input-wrapper {
    position: relative;
}

.file-input-wrapper input[type="file"] {
    position: absolute;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

.file-input-label {
    display: block;
    padding: 2rem;
    border: 3px dashed #cbd5e0;
    border-radius: 20px;
    text-align: center;
    transition: all 0.3s ease;
    background: #f8fafc;
    cursor: pointer;
}

.file-input-label:hover {
    border-color: #667eea;
    background: white;
}

.file-icon {
    font-size: 3rem;
    display: block;
    margin-bottom: 0.5rem;
}

.file-text {
    display: block;
    font-weight: bold;
    color: #2d3748;
    margin-bottom: 0.5rem;
}

.file-formats {
    display: block;
    font-size: 0.9rem;
    color: #718096;
}

/* دکمه‌ها و نوار پیشرفت */
.upload-actions {
    display: flex;
    align-items: center;
    gap: 2rem;
    margin-top: 2rem;
}

.submit-button {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 15px;
    font-size: 1.1rem;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    min-width: 200px;
    justify-content: center;
}

.submit-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
}

.submit-button:disabled {
    background: #a0a0a0;
    cursor: not-allowed;
    transform: none;
}

.upload-progress {
    flex: 1;
    align-items: center;
    gap: 1rem;
    padding: 1.2rem;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.08), rgba(118, 75, 162, 0.08));
    border-radius: 20px;
    border: 2px solid rgba(102, 126, 234, 0.15);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.1);
    transition: all 0.3s ease;
    display: flex;
    opacity: 0;
    visibility: hidden;
    height: 0;
    overflow: hidden;
    margin: 0;
}

.upload-progress.visible {
    opacity: 1 !important;
    visibility: visible !important;
    height: auto !important;
    margin: 1rem 0 !important;
}

.progress-bar {
    flex: 1;
    height: 20px;
    background: #e2e8f0;
    border-radius: 15px;
    overflow: hidden;
    position: relative;
    box-shadow: inset 0 2px 6px rgba(0,0,0,0.1);
    border: 1px solid rgba(0,0,0,0.05);
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #ff6b6b, #4ecdc4);
    width: 0%;
    transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    border-radius: 15px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.progress-fill.progress-active {
    animation: progress-pulse 1.5s ease-in-out infinite;
}

@keyframes progress-pulse {
    0%, 100% { 
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    50% { 
        box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
    }
}

.progress-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: progress-shine 2s ease-in-out infinite;
}

@keyframes progress-shine {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

.progress-text {
    font-weight: bold;
    color: #2d3748;
    min-width: 70px;
    font-size: 1.2rem;
    text-shadow: 1px 1px 2px rgba(255,255,255,0.8);
    background: rgba(255,255,255,0.8);
    padding: 0.3rem 0.8rem;
    border-radius: 10px;
    border: 1px solid rgba(102, 126, 234, 0.2);
}

/* مودال */
.modal {
    position: fixed;
    inset: 0;
    z-index: 1000;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}

.modal-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}

.modal-content {
    position: relative;
    background: white;
    border-radius: 25px;
    padding: 2rem;
    width: 100%;
    max-width: 600px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e2e8f0;
}

.modal-header h3 {
    color: #2d3748;
    margin: 0;
    font-size: 1.4rem;
}

.close-modal {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    transition: all 0.3s ease;
}

.close-modal:hover {
    background: #f7fafc;
    transform: rotate(90deg);
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-50px) scale(0.9);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

/* تبلت و موبایل */
@media (max-width: 768px) {
    .podcast-title { font-size: 1.8rem; }
    .podcast-toolbar { grid-template-columns: 1fr; gap: 1rem; }
    .podcast-list { grid-template-columns: 1fr; gap: 1rem; }
    .podcast-card { padding: 1rem; }
    .play-button { width: 60px; height: 60px; touch-action: manipulation; }
    .play-icon { font-size: 1.5rem; }
    .form-row { grid-template-columns: 1fr; }
    .upload-actions { flex-direction: column; gap: 1rem; }
    .upload-progress { width: 100%; order: -1; }
    .inline-video { max-width: 250px !important; }
    .full-video-content { max-width: 95vw; margin: 1rem; }
    .modal-content { margin: 1rem; padding: 1rem; max-width: calc(100vw - 2rem); }
    .action-btn { width: 45px; height: 45px; font-size: 1.3rem; touch-action: manipulation; }
    .podcast-card { margin-bottom: 1.5rem; min-height: 200px; }
    .podcast-title-text { font-size: 1.3rem; }
    .podcast-description { font-size: 1rem; line-height: 1.6; }
    .progress-bar { height: 20px; }
    .progress-text { font-size: 1.2rem; min-width: 70px; }
}

@media (max-width: 480px) {
    .podcast-header { padding: 1.5rem; margin-bottom: 1rem; }
    .podcast-title { font-size: 1.5rem; }
    .podcast-subtitle { font-size: 1rem; }
    .upload-container { padding: 1.5rem; }
    .modal-content { padding: 1rem; }
    .inline-video { max-width: 200px !important; }
    .submit-button { width: 100%; padding: 1.2rem; font-size: 1.2rem; }
    .upload-progress { margin-top: 1rem; padding: 0.8rem; }
    .file-input-label { padding: 1.5rem; }
    .file-icon { font-size: 2.5rem; }
}
/* استایل برای کارت‌های غیرفعال (فقط برای ادمین) */
.inactive-card {
    opacity: 0.5; /* نیمه‌شفاف کردن کارت */
    pointer-events: none; /* غیرفعال کردن کلیک روی کل کارت (پخش و...) */
    border-color: #dc3545; /* تغییر رنگ حاشیه به قرمز */
    transition: all 0.3s ease;
}

/* این بخش مهم است: دکمه‌های ادمین (تغییر وضعیت، ویرایش، حذف) باید قابل کلیک باقی بمانند */
.inactive-card .podcast-actions {
    pointer-events: auto; /* فعال کردن مجدد کلیک برای دکمه‌های ادمین */
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
    console.log('Podcast script loaded - DOM ready');
    
    // =============================================================
    // تابع سفارشی برای نمایش پیام با استایل درخواستی
    // =============================================================
    function showAlert(type, message) {
    // اگر پیام از قبل وجود دارد، آن را حذف کن
    let existingAlert = document.getElementById('custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }

    const alertBox = document.createElement('div');
    alertBox.id = 'custom-alert';
    
    // تعریف رنگ‌ها
    let bgColor, textColor;

    if (type === 'success') {
        bgColor = '#28a745'; // یک پس‌زمینه سبز یکدست
        textColor = 'white'; // متن سفید برای خوانایی بهتر روی پس‌زمینه سبز
    } else {
        bgColor = 'linear-gradient(135deg, #dc3545, #c82333)'; // پس‌زمینه قرمز برای خطا
        textColor = 'white';
    }

    // اعمال تمام استایل‌ها در یکجا
    alertBox.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: ${bgColor};
        color: ${textColor};
        padding: 1rem 2rem;
        border-radius: 50px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        z-index: 10000;
        font-size: 1rem;
        font-weight: bold;
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
        text-align: center;
        max-width: 90%;
        word-wrap: break-word;
    `;
    
    alertBox.textContent = message;
    document.body.appendChild(alertBox);

    // نمایش پیام با انیمیشن fade-in
    setTimeout(() => { alertBox.style.opacity = '1'; }, 10);

    // مخفی کردن و حذف پیام بعد از 4 ثانیه
    setTimeout(() => {
        alertBox.style.opacity = '0';
        setTimeout(() => alertBox.remove(), 500);
    }, 4000);
}
    // =============================================================
    // بخش جستجو، فیلتر و مرتب‌سازی (بدون تغییر)
    // =============================================================
    const listEl = document.getElementById('podcastList');
    const searchEl = document.getElementById('podcastSearch');
    const sortEl   = document.getElementById('podcastSort');
    const topicEl  = document.getElementById('filterTopic');

    function getCards(){ return Array.from(listEl.querySelectorAll('.podcast-card')); }

    function applyFilters(){
        const q = (searchEl?.value || '').trim().toLowerCase();
        const topic = (topicEl?.value || '').trim().toLowerCase();
        getCards().forEach(card=>{
            const t = (card.dataset.title || '').toLowerCase();
            const d = (card.dataset.desc  || '').toLowerCase();
            const tp= (card.dataset.topic || '').toLowerCase();
            const matchesText = !q || t.includes(q) || d.includes(q) || tp.includes(q);
            const matchesTopic = !topic || tp === topic;
            card.style.display = (matchesText && matchesTopic) ? '' : 'none';
        });
    }

    function applySort(){
        const mode = (sortEl?.value || 'new');
        const cards = getCards().filter(c=>c.style.display!=='none');
        const toTime = (s)=> {
            if (!s) return 0;
            const t = Date.parse(s);
            return isNaN(t) ? 0 : t;
        };
        cards.sort((a,b)=>{
            if (mode === 'title') {
                return (a.dataset.title||'').localeCompare(b.dataset.title||'', 'fa');
            }
            if (mode === 'topic') {
                return (a.dataset.topic||'').localeCompare(b.dataset.topic||'', 'fa');
            }
            if (mode === 'old') {
                return toTime(a.dataset.date) - toTime(b.dataset.date);
            }
            return toTime(b.dataset.date) - toTime(a.dataset.date);
        });
        cards.forEach(c=> listEl.appendChild(c));
    }

    if (searchEl) searchEl.addEventListener('input', ()=>{ applyFilters(); applySort(); });
    if (topicEl) topicEl.addEventListener('change', ()=>{ applyFilters(); applySort(); });
    if (sortEl) sortEl.addEventListener('change', ()=>{ applySort(); });

    // =============================================================
    // ====== FEATURE 1: NEW XP LOGIC (COMPLETION BASED) ======
    // =============================================================
    console.log('Initializing revised podcast player logic');

    const podcastXPStatus = new Map();

    function showXPNotification() {
        let notification = document.getElementById('xp-notification');
        if (notification) { notification.remove(); }
        notification = document.createElement('div');
        notification.id = 'xp-notification';
        notification.innerHTML = '🏆 🏆🏆  پادکست را به صورت کامل تا پایان  گوش دهید (بدون رد کردن یا تغییر سرعت) تا ۵۰ امتیاز هیجان انگیز بگیرید!🏆 🏆🏆';
        document.body.appendChild(notification);
        setTimeout(() => { notification.style.opacity = '0'; setTimeout(() => notification.remove(), 500); }, 5000);
    }

    function sendCompletionXP(podcastId) {
    console.log(`Sending completion XP for podcast ${podcastId}`);

    fetch('ajax/add-listening-xp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            podcast_id: podcastId,
            action: 'completion'
        })
    })
    .then(r => r.json())
    .then(data => {
        console.log('XP response:', data);
        if (data.success && data.xp_earned > 0) {
            showAlert('success', `🎉 تبریک! شما ${data.xp_earned} امتیاز کسب کردید!`);
        } else if (!data.success) {
            // --- اصلاح کلیدی: همیشه پیام سرور را به کاربر نشان بده ---
            showAlert('error', data.message);
        }
    })
    .catch(e => console.error('Error sending XP:', e));
}

    document.querySelectorAll('.inline-media').forEach(media => {
        const card = media.closest('.podcast-card');
        const playButton = card ? card.querySelector('.play-button') : null;
        const playIcon = playButton ? playButton.querySelector('.play-icon') : null;
        const podcastId = card ? card.dataset.id : null;
        if (!card || !playButton || !playIcon || !podcastId) return;

        podcastXPStatus.set(podcastId, { hasSkipped: false, hasChangedSpeed: false, isEligible: true });

        media.addEventListener('play', () => {
            document.querySelectorAll('.inline-media').forEach(otherMedia => { if (otherMedia !== media) otherMedia.pause(); });
            playIcon.textContent = '⏸';
            playButton.style.background = 'linear-gradient(135deg, #4ecdc4, #44a08d)';
            showXPNotification();
            podcastXPStatus.set(podcastId, { hasSkipped: false, hasChangedSpeed: false, isEligible: true });
        });
        media.addEventListener('pause', () => { playIcon.textContent = '▶'; playButton.style.background = 'linear-gradient(135deg, #ff6b6b, #ee5a6f)'; });
        media.addEventListener('seeked', () => { const status = podcastXPStatus.get(podcastId); if (status) { status.hasSkipped = true; status.isEligible = false; } });
        media.addEventListener('ratechange', () => { if (media.playbackRate !== 1.0) { const status = podcastXPStatus.get(podcastId); if (status) { status.hasChangedSpeed = true; status.isEligible = false; } } });
        media.addEventListener('ended', () => {
            const status = podcastXPStatus.get(podcastId);
            playIcon.textContent = '▶';
            playButton.style.background = 'linear-gradient(135deg, #ff6b6b, #ee5a6f)';
            if (status && status.isEligible) { sendCompletionXP(podcastId); }
        });
    });

    document.querySelectorAll('.play-button').forEach(btn => {
        btn.addEventListener('click', () => {
            const card = btn.closest('.podcast-card');
            const media = card ? card.querySelector('.inline-media') : null;
            if (media) { if (media.paused) { media.play().catch(e => console.error("Play error:", e)); } else { media.pause(); } }
        });
    });

    // =============================================================
    // ====== FEATURE 2: ADMIN TOGGLE STATUS (WITH CONFIRMATION) ======
    // =============================================================
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('status-toggle')) {
            const podcastId = e.target.dataset.id;
            const isActive = e.target.checked ? 1 : 0;
            const toggleElement = e.target;
            const card = e.target.closest('.podcast-card');
            const actionText = isActive ? 'فعال کردن' : 'غیرفعال کردن';

            if (!confirm(`آیا از ${actionText} این پادکست مطمئن هستید؟`)) {
                toggleElement.checked = !toggleElement.checked; // بازگرداندن وضعیت چک‌باکس
                return;
            }

            fetch('ajax/toggle-podcast-status.php', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: podcastId, is_active: isActive })
            })
            .then(response => { if (!response.ok) throw new Error(`خطای سرور: ${response.status}`); return response.json(); })
            .then(data => {
                if (data.success) {
                    const message = isActive ? 'پادکست با موفقیت فعال شد.' : 'پادکست با موفقیت غیرفعال شد.';
                    showAlert('success', message);
                    if (card) {
                        if (isActive === 0) {
                            card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                            card.style.opacity = '0'; card.style.transform = 'scale(0.8)';
                            setTimeout(() => { card.style.display = 'none'; }, 300);
                        } else {
                            card.style.display = '';
                            setTimeout(() => { card.style.opacity = '1'; card.style.transform = 'scale(1)'; }, 10);
                        }
                    }
                } else {
                    toggleElement.checked = !toggleElement.checked;
                    showAlert('error', data.message || 'خطا');
                }
            })
            .catch(error => {
                toggleElement.checked = !toggleElement.checked;
                console.error('Fetch Error:', error);
                showAlert('error', 'خطا در ارتباط با سرور');
            });
        }
    });
    
    // =============================================================
    // بخش‌های دیگر (مودال، آپلود، ویرایش و حذف) - با تایید
    // =============================================================

    // باز کردن ویدیو بزرگ
    document.querySelectorAll('.full-media-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const item = btn.closest('.podcast-card');
            const video = item.querySelector('.inline-video');
            if (video) {
                const src = video.src;
                const fullVideo = document.getElementById('fullVideoPlayer');
                if (fullVideo) {
                    fullVideo.src = src;
                    document.getElementById('fullVideoModal').style.display = 'flex';
                    fullVideo.play().catch(e => console.log('Play error:', e));
                }
            }
        });
    });
    
    const fullModal = document.getElementById('fullVideoModal');
    if (fullModal) {
        const closeBtn = fullModal.querySelector('.close-modal');
        const backdrop = fullModal.querySelector('.modal-backdrop');
        const closeLogic = () => { fullModal.style.display = 'none'; const video = document.getElementById('fullVideoPlayer'); if (video) video.pause(); };
        if (closeBtn) closeBtn.addEventListener('click', closeLogic);
        if (backdrop) backdrop.addEventListener('click', closeLogic);
    }
    
    // منطق آپلود فایل
    const uploadForm = document.getElementById('uploadPodcastForm');
    if (uploadForm){
        const fileInput = uploadForm.querySelector('input[type="file"]');
        const fileLabel = uploadForm.querySelector('.file-input-label');
        const fileText = fileLabel?.querySelector('.file-text');
        
        if (fileInput && fileText) {
            fileInput.addEventListener('change', (e) => {
                const fileName = e.target.files[0]?.name || 'فایل خود را انتخاب کنید';
                fileText.textContent = fileName;
                if (fileLabel) { fileLabel.style.borderColor = '#4ecdc4'; fileLabel.style.background = 'rgba(78, 205, 196, 0.05)'; }
            });
        }

        uploadForm.addEventListener('submit', function(e){
            e.preventDefault();
            if (!confirm('آیا از آپلود این پادکست مطمئن هستید؟')) return;

            const fd = new FormData(uploadForm); fd.append('type','podcast');
            const bar = document.getElementById('uploadBar'); const pct = document.getElementById('uploadPct');
            const progressContainer = document.querySelector('.upload-progress');
            if (!bar || !pct || !progressContainer) { console.error('Progress elements not found!'); return; }
            bar.style.width = '0%'; pct.textContent = '0%'; progressContainer.classList.add('visible');
            const submitBtn = uploadForm.querySelector('.submit-button');
            if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<span class="btn-icon">⏳</span>در حال آپلود...'; }
            const xhr = new XMLHttpRequest(); xhr.timeout = 300000; xhr.open('POST', 'ajax/upload-podcast.php', true);
            xhr.upload.onprogress = (ev) => { if (ev.lengthComputable) { const p = Math.round((ev.loaded / ev.total) * 100); bar.style.width = p + '%'; pct.textContent = p + '%'; bar.classList.add('progress-active'); } };
            xhr.onload = ()=>{
                if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = '<span class="btn-icon">🚀</span>آپلود پادکست'; }
                setTimeout(() => { progressContainer.classList.remove('visible'); }, 2000);
                if (xhr.status !== 200) { showAlert('error', `خطای سرور (کد ${xhr.status})`); return; }
                try {
                    const data = JSON.parse(xhr.responseText || '{}');
                    if (data?.success){ bar.style.width = '100%'; pct.textContent = '100%'; showAlert('success','🎉 پادکست با موفقیت آپلود شد!'); uploadForm.reset(); if (fileText) fileText.textContent = 'فایل خود را انتخاب کنید'; setTimeout(() => location.reload(), 1500); }
                    else { showAlert('error', data?.message || 'خطا در آپلود'); }
                } catch(err) { showAlert('error', 'پاسخ نامعتبر از سرور'); }
            };
            xhr.onerror = ()=>{ if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = '<span class="btn-icon">🚀</span>آپلود پادکست'; } progressContainer.classList.remove('visible'); showAlert('error', 'خطا در ارتباط با سرور'); };
            xhr.send(fd);
        });
    }

    // منطق ویرایش و حذف
    document.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.edit-btn');
        const deleteBtn = e.target.closest('.delete-btn');
        
        if (editBtn) {
            e.preventDefault();
            const item = editBtn.closest('.podcast-card'); if (!item) return;
            const id = item.dataset.id;
            const title = item.querySelector('.podcast-title-text')?.textContent?.trim() || '';
            const description = item.querySelector('.podcast-description')?.textContent?.trim() || '';
            const dur = item.querySelector('.podcast-duration')?.textContent?.replace(/^⏱\s*/, '').trim() || '';
            const modal = document.getElementById('editPodcastModal'); if (!modal) return;
            modal.querySelector('input[name="id"]').value = id || '';
            modal.querySelector('input[name="title"]').value = title;
            modal.querySelector('textarea[name="description"]').value = description;
            modal.querySelector('input[name="duration"]').value = dur;
            modal.style.display = 'flex';
        }
        
        if (deleteBtn) {
            e.preventDefault();
            const item = deleteBtn.closest('.podcast-card');
            const id = item?.dataset?.id;
            if (!id || !confirm('آیا مطمئن هستید که می‌خواهید این پادکست را حذف کنید؟')) return;
            
            fetch('ajax/delete-podcast.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id }) })
            .then(r => r.json())
            .then(d => {
                if (d?.success) { showAlert('success', 'پادکست حذف شد'); item.style.transition = 'all 0.3s ease'; item.style.opacity = '0'; item.style.transform = 'scale(0.8)'; setTimeout(() => item.remove(), 300); }
                else { showAlert('error', d?.message || 'خطا در حذف'); }
            })
            .catch(error => { showAlert('error', 'خطا در ارتباط'); });
        }
    });

    // منطق فرم ویرایش
    const editForm = document.getElementById('editPodcastForm');
    if (editForm) {
        editForm.addEventListener('submit', function(e) {
            e.preventDefault();
            if (!confirm('آیا از ذخیره تغییرات این پادکست مطمئن هستید؟')) return;

            const fd = new FormData(editForm);
            fetch('ajax/edit-podcast.php', { method: 'POST', body: fd })
            .then(r => r.json())
            .then(d => {
                if (d?.success) { showAlert('success', 'پادکست ویرایش شد'); document.getElementById('editPodcastModal').style.display = 'none'; setTimeout(() => location.reload(), 1000); }
                else { showAlert('error', d?.message || 'خطا در ویرایش'); }
            })
            .catch(error => { showAlert('error', 'خطا در ارتباط'); });
        });
    }

    // منطق بستن مودال ویرایش
    const editModal = document.getElementById('editPodcastModal');
    if (editModal) {
        const closeLogic = () => { editModal.style.display = 'none'; };
        editModal.querySelector('.close-modal')?.addEventListener('click', closeLogic);
        editModal.querySelector('.modal-backdrop')?.addEventListener('click', closeLogic);
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && editModal.style.display === 'flex') closeLogic(); });
    }
    
    console.log('Podcast script initialization complete');
});
</script>