<?php
// Materials section - Only show if logged in
if (!isLoggedIn()) { exit(); }

// آمار موضوع‌ها
$stmt = $conn->prepare("SELECT subject, COUNT(*) as count FROM materials GROUP BY subject");
$stmt->execute();
$materialStats = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// آخرین مطالب
$stmt = $conn->prepare("
    SELECT m.*, u.first_name, u.last_name
    FROM materials m
    LEFT JOIN users u ON m.created_by = u.id
    ORDER BY m.created_at DESC
    LIMIT 8
");
$stmt->execute();
$recentMaterials = $stmt->fetchAll();

$subjects = [
    'math'     => ['icon' => '🔢', 'title' => 'ریاضی',              'color' => '#FF6B6B'],
    'science'  => ['icon' => '🔬', 'title' => 'علوم',               'color' => '#4ECDC4'],
    'persian'  => ['icon' => '📖', 'title' => 'فارسی',              'color' => '#45B7D1'],
    'social'   => ['icon' => '🗺️', 'title' => 'مطالعات اجتماعی',   'color' => '#F9CA24'],
    'religion' => ['icon' => '🕌', 'title' => 'هدیه های آسمانی',               'color' => '#A29BFE'],
];
?>
<section id="materials" class="section materials-pro" dir="rtl" aria-labelledby="materialsTitle">

  <!-- TOP BAR (دکمه‌ای و چسبان) -->
  <div class="materials-topbar">
    <div class="topbar-row">
      <h2 id="materialsTitle" class="topbar-title">کتابخانهٔ رنگیِ کلاس ✨</h2>
      <div class="topbar-tools">
        <div class="segmented as-buttons" role="tablist" aria-label="فیلتر موضوع">
          <button class="seg btn active" data-subject="all" role="tab" onclick="filterMaterials('all')" aria-selected="true">همه</button>
          <?php foreach($subjects as $key => $s): ?>
            <button class="seg btn" data-subject="<?= $key ?>" role="tab" onclick="filterMaterials('<?= $key ?>')">
              <span aria-hidden="true"><?= $s['icon'] ?></span>
              <span><?= $s['title'] ?></span>
            </button>
          <?php endforeach; ?>
        </div>

        <div class="topbar-search">
          <input type="text" id="materialSearch" placeholder="جستجو در عنوان یا توضیحات..." oninput="searchMaterials()" aria-label="جستجو">
          <span class="sicon" aria-hidden="true">🔍</span>
        </div>

        <div class="topbar-sort">
          <label for="sortSelect">مرتب‌سازی:</label>
          <select id="sortSelect" onchange="sortMaterials(this.value)">
            <option value="newest">جدیدترین</option>
            <option value="popular">پر‌دانلود</option>
            <option value="title">عنوان (الف→ی)</option>
          </select>
        </div>
      </div>
    </div>
  </div>

  <!-- روبان آمار (کلیک‌پذیر برای فیلتر سریع) -->
  <div class="stats-ribbon">
    <?php foreach($subjects as $key => $s): $count = $materialStats[$key] ?? 0; ?>
      <button class="stat-pill btn-lite" style="--pill: <?= $s['color'] ?>" onclick="filterMaterials('<?= $key ?>')">
        <span class="pill-icn"><?= $s['icon'] ?></span>
        <strong><?= $s['title'] ?></strong>
        <span class="pill-num"><?= $count ?> فایل</span>
      </button>
    <?php endforeach; ?>
  </div>

  <!-- گرید کارت‌ها -->
  <div id="materialsContainer" class="materials-grid">
    <?php
    $stmt = $conn->prepare("
      SELECT m.*, u.first_name, u.last_name,
            (SELECT COUNT(*) FROM material_downloads WHERE material_id = m.id) as download_count
      FROM materials m
      LEFT JOIN users u ON m.created_by = u.id
      ORDER BY m.created_at DESC
    ");
    $stmt->execute();
    $materials = $stmt->fetchAll();

    // تشخیص نوع رسانه برای پیش‌نمایش (اصلاح شده)
    function mediaKind($fileType, $path) {
      $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
      $videoExt = ['mp4','webm','mov','m4v','ogv','avi','wmv','mkv','flv'];
      $audioExt = ['mp3','m4a','ogg','wav','aac','flac','oga','wma'];
      $imageExt = ['jpg','jpeg','png','gif','bmp','svg','tiff','webp'];
      
      if (strpos($fileType, 'video/') === 0 || in_array($ext, $videoExt)) return 'video';
      if (strpos($fileType, 'audio/') === 0 || in_array($ext, $audioExt)) return 'audio';
      if (strpos($fileType, 'image/') === 0 || in_array($ext, $imageExt)) return 'image';
      if ($ext === 'pdf' || $fileType === 'application/pdf') return 'pdf';
      return 'doc';
    }
    function safe($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

    foreach($materials as $m):
      $subjKey   = $m['subject'];
      $sConf     = $subjects[$subjKey] ?? ['color'=>'#999','title'=>'دیگر','icon'=>'📎'];
      $filePath  = $m['file_path']; // حذف ../
      $hasFile   = is_file('../' . $m['file_path']); // فقط برای بررسی وجود
      $fileSize  = $hasFile ? formatFileSize(filesize('../' . $m['file_path'])) : 'N/A';
      $kind      = mediaKind($m['file_type'], $m['file_path']);
      $isNew     = (time() - strtotime($m['created_at'])) < 86400*7; // 7 روز
      $titleLow  = mb_strtolower($m['title'] ?? '', 'UTF-8');
      $desc      = trim($m['content'] ?? '');
      
      // تشخیص نوع فایل بر اساس پسوند و نوع MIME
      $ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
      $isVideo = (strpos($m['file_type'], 'video/') === 0) || in_array($ext, ['mp4','avi','mov','wmv','mkv','flv','webm','ogv','m4v']);
      $isAudio = (strpos($m['file_type'], 'audio/') === 0) || in_array($ext, ['mp3','wav','ogg','aac','flac','m4a','wma','oga']);
      $isImage = (strpos($m['file_type'], 'image/') === 0) || in_array($ext, ['jpg','jpeg','png','gif','bmp','svg','tiff','webp']);
      $isPDF = ($ext === 'pdf') || (strpos($m['file_type'], 'application/pdf') === 0);
    ?>
    <article class="material-card compact"
      data-subject="<?= safe($subjKey) ?>"
      data-title="<?= safe($titleLow) ?>"
      data-dcount="<?= (int)$m['download_count'] ?>">

      <!-- اکشن‌های شناور روی کارت -->
      <div class="card-actions">
        <?php if (!$isVideo && !$isAudio && !$isImage): ?>
        <button class="act view" title="پیش‌نمایش" onclick="togglePreview(this)">👁️</button>
        <?php endif; ?>
        <button class="act dl" title="دانلود" onclick="downloadMaterial(<?= (int)$m['id'] ?>)">⬇️</button>
        <?php if (isAdmin()): ?>
        <button class="act del" title="حذف" onclick="deleteMaterial(<?= (int)$m['id'] ?>)">🗑️</button>
        <?php endif; ?>
      </div>

      <header class="m-head">
        <div class="m-icon" style="--icbg: <?= $sConf['color'] ?>1F; --ic: <?= $sConf['color'] ?>"><?= getFileIcon($m['file_type']) ?></div>
        <div class="m-txt">
          <h3 class="m-title"><?= safe($m['title']) ?></h3>
          <div class="m-meta">
            <span class="tag" style="background: <?= $sConf['color'] ?>"><?= $sConf['title'] ?></span>
            <span class="date">📅 <?= convertToJalali($m['created_at']) ?></span>
            <span class="size">📎 <?= safe($fileSize) ?></span>
            <?php if ($isNew): ?><span class="new">جدید!</span><?php endif; ?>
          </div>
        </div>
      </header>

      <!-- نمایش مستقیم بر اساس نوع فایل -->
      <?php if ($hasFile): ?>
        <?php if ($isVideo): ?>
          <!-- پلیر ویدیو -->
          <div class="media-player video-player">
            <video controls preload="metadata" playsinline class="inline-video">
              <source src="../<?= safe($m['file_path']) ?>" type="<?= safe($m['file_type']) ?>">
              مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
            </video>
          </div>
        <?php elseif ($isAudio): ?>
          <!-- پلیر صوتی -->
          <div class="media-player audio-player">
            <div class="audio-info">
              <span class="audio-icon">🎵</span>
              <span class="audio-name"><?= safe(pathinfo($m['title'], PATHINFO_FILENAME)) ?></span>
            </div>
            <audio controls preload="metadata" class="inline-audio">
              <source src="../<?= safe($m['file_path']) ?>" type="<?= safe($m['file_type']) ?>">
              مرورگر شما از پخش صوت پشتیبانی نمی‌کند.
            </audio>
          </div>
        <?php elseif ($isImage): ?>
          <!-- نمایش تصاویر -->
          <div class="media-player image-viewer" onclick="showImageModal('../<?= safe($m['file_path']) ?>', '<?= safe($m['title']) ?>')">
            <img src="../<?= safe($m['file_path']) ?>" alt="<?= safe($m['title']) ?>" class="inline-image" loading="lazy">
            <div class="image-overlay">
              <span class="zoom-icon">🔍</span>
            </div>
          </div>
        <?php elseif ($isPDF): ?>
          <!-- پیش‌نمایش PDF قابل کلیک -->
          <div class="m-preview" style="display:none">
            <iframe class="pdf-frame" src="../<?= safe($m['file_path']) ?>" title="پیش‌نمایش PDF"></iframe>
          </div>
          <div class="m-illustration doc-preview" aria-hidden="true" onclick="togglePreview(this)">📄</div>
        <?php else: ?>
          <!-- سایر فایل‌ها -->
          <div class="m-illustration" aria-hidden="true">📄</div>
        <?php endif; ?>
      <?php else: ?>
        <div class="m-illustration error" aria-hidden="true" title="فایل یافت نشد">🏫</div>
      <?php endif; ?>

      <?php if ($desc): ?>
        <p class="m-desc"><?= safe(mb_substr($desc, 0, 110, 'UTF-8')) ?><?= mb_strlen($desc, 'UTF-8') > 110 ? '…' : '' ?></p>
      <?php else: ?>
        <p class="m-desc m-muted">بدون توضیح…</p>
      <?php endif; ?>

      <footer class="m-foot">
        <div class="stats">
          <span>⬇️ <?= (int)$m['download_count'] ?> دانلود</span>
          <span>👩‍🏫 <?= safe(($m['first_name']??'').' '.($m['last_name']??'')) ?></span>
        </div>
      </footer>
    </article>
    <?php endforeach; ?>

    <?php if (empty($materials)): ?>
      <div class="empty-state">
        <div class="emoji">📚</div>
        <h3>هنوز محتوایی آپلود نشده</h3>
        <p>به‌زودی کلی درس جذاب اینجا می‌بینی!</p>
      </div>
    <?php endif; ?>
  </div>

  <!-- تازه‌ها: ایکونی با عنوان درس و دانلود با کلیک -->
  <aside class="recent-rail">
    <h3>🆕 تازه‌های کلاس</h3>
    <div class="recent-icons">
      <?php foreach($recentMaterials as $r):
        $subj = $subjects[$r['subject']] ?? ['icon'=>'📎','title'=>'دیگر','color'=>'#999'];
      ?>
        <button class="recent-chip" style="--chip: <?= $subj['color'] ?>"
                onclick="downloadMaterial(<?= (int)$r['id'] ?>)"
                title="دانلود: <?= safe($r['title']) ?>">
          <span class="rc-icn"><?= $subj['icon'] ?></span>
          <span class="rc-title"><?= $subj['title'] ?></span>
        </button>
      <?php endforeach; ?>
    </div>
  </aside>

  <?php if (isAdmin()): ?>
  <!-- آپلود با نوار پیشرفت + اجازهٔ همهٔ فرمت‌ها -->
  <div class="upload-section">
    <h3>📤 آپلود محتوای جدید</h3>
    <form id="uploadMaterialForm" enctype="multipart/form-data">
      <div class="upload-grid">
        <div class="form-group">
          <label>عنوان محتوا:</label>
          <input type="text" name="title" required>
        </div>
        <div class="form-group">
          <label>موضوع:</label>
          <select name="subject" required>
            <option value="">انتخاب کنید</option>
            <?php foreach($subjects as $key => $s): ?>
              <option value="<?= $key ?>"><?= $s['title'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>توضیحات (اختیاری):</label>
        <textarea name="content" rows="3" placeholder="چند خط دربارهٔ محتوا…"></textarea>
      </div>
      <div class="form-group">
        <label>فایل:</label>
        <div class="file-upload-area" id="fileUploadArea">
          <!-- اجازه همهٔ فرمت‌ها -->
          <input type="file" name="material_file" id="materialFile" accept="*/*" required>
          <label for="materialFile" class="file-upload-label">
            <span class="upload-icon">📁</span>
            <span class="upload-text">انتخاب فایل یا بکشید و رها کنید</span>
            <span class="file-info"></span>
          </label>
        </div>
      </div>

      <!-- نوار پیشرفت -->
      <div id="uploadProgress" class="progress hidden" aria-live="polite">
        <div class="progress-top">
          <span id="uploadPct">0%</span>
          <span id="uploadSpeed">— KB/s</span>
        </div>
        <div class="progress-bar">
          <div id="uploadBar" class="bar" style="width:0%"></div>
        </div>
        <div class="progress-bottom">
          <span id="uploadStatus">در انتظار شروع آپلود…</span>
          <button type="button" id="uploadCancel" class="btn danger ghost small" disabled>لغو</button>
        </div>
      </div>

      <button type="submit" class="btn xl solid"><span>⬆️</span> آپلود محتوا</button>
    </form>
  </div>
  <?php endif; ?>
</section>

<!-- Modal برای نمایش تصاویر بزرگ -->
<div id="imageModal" class="image-modal" onclick="closeImageModal()">
  <div class="close-btn" onclick="closeImageModal()">&times;</div>
  <img id="modalImage" src="" alt="">
</div>

<style>
/* --- فونت سراسری تاهوما --- */
html, body, * { font-family: Tahoma, sans-serif !important; }

:root{
  --indigo:#667eea; --purple:#764ba2; --accent:#ffd93d; --ink:#222; --muted:#777;
  --card:rgba(255,255,255,.96); --glass:rgba(255,255,255,.18);
}

/* کلاس برای مخفی کردن المنت‌ها در فیلتر */
.hidden {
  display: none !important;
}

/* TOP BAR به‌صورت دکمه‌ای - چسبان بعد از منو اصلی */
.materials-topbar {
    position: relative; /* یا حذف کامل position */
    z-index: auto;
    backdrop-filter: blur(12px);
    background: linear-gradient(135deg, rgba(102,126,234,.25), rgba(118,75,162,.25));
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 18px;
    padding: .8rem 1rem;
    margin-bottom: 1rem;
}
/* حذف padding-top اضافه */
.materials-pro {
  padding-top: 0;
}
.topbar-row{display:flex; gap:.8rem; align-items:center; justify-content:space-between; flex-wrap:wrap}
.topbar-title{color:#fff; margin:0; font-size:1.4rem; text-shadow:0 3px 12px rgba(0,0,0,.25)}
.topbar-tools{display:flex; gap:.6rem; align-items:center; flex-wrap:wrap}

.segmented.as-buttons{display:flex; gap:.4rem; padding:.25rem; border-radius:999px; background:rgba(255,255,255,.15); border:1px solid rgba(255,255,255,.35)}
.seg.btn{
  border:0; padding:.5rem .9rem; border-radius:999px; cursor:pointer; color:#fff; font-weight:800;
  background:linear-gradient(135deg, rgba(255,255,255,.15), rgba(255,255,255,.08));
  box-shadow: 0 6px 14px rgba(0,0,0,.15) inset, 0 4px 10px rgba(0,0,0,.12);
  transition:.15s transform, .2s background;
  display:flex; gap:.35rem; align-items:center;
}
.seg.btn:hover{transform:translateY(-1px)}
.seg.btn.active{
  background:linear-gradient(135deg, #6bcf7f, #4d9de0);
  box-shadow: 0 6px 16px rgba(77,157,224,.35);
}

.topbar-search{position:relative; min-width:240px}
.topbar-search input{width:100%; border-radius:999px; padding:.6rem 2.2rem .6rem .8rem; border:2px solid rgba(255,255,255,.35); background:rgba(255,255,255,.15); color:#fff}
.topbar-search .sicon{position:absolute; left:.8rem; top:50%; transform:translateY(-50%)}
.topbar-sort{display:flex; gap:.35rem; color:#fff; align-items:center}
.topbar-sort select{border-radius:12px; padding:.45rem .6rem; border:1px solid rgba(255,255,255,.35); background:rgba(255,255,255,.15); color:#fff}

/* روبان آمار به‌صورت دکمه لایت */
.stats-ribbon{display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:.6rem; margin:1rem 0}
.stat-pill.btn-lite{
  display:flex; align-items:center; gap:.4rem; padding:.55rem .8rem; width:100%;
  background:rgba(255,255,255,.92); border-radius:12px; border:none; cursor:pointer;
  box-shadow:0 6px 16px rgba(0,0,0,.08); border-top:4px solid var(--pill); transition:.15s transform;
}
.stat-pill.btn-lite:hover{transform:translateY(-2px)}
.pill-icn{font-size:1.2rem}
.pill-num{color:#555}

/* GRID & CARDS */
.materials-grid{display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:.8rem}
.material-card{background:var(--card); border-radius:16px; padding:.8rem; box-shadow:0 8px 22px rgba(0,0,0,.08); position:relative; overflow:hidden; display:flex; flex-direction:column}
.material-card.compact .m-title{font-size:1rem}
.material-card.compact .m-desc{font-size:.9rem}
.material-card:hover{transform:translateY(-2px); box-shadow:0 12px 26px rgba(0,0,0,.12); transition:.2s}

/* اکشن‌های روی کارت */
.card-actions{position:absolute; top:.5rem; left:.5rem; display:flex; gap:.3rem; z-index:2; opacity:0; transform:translateY(-6px); transition:.2s}
.material-card:hover .card-actions{opacity:1; transform:none}
.act{border:0; border-radius:10px; padding:.35rem .45rem; cursor:pointer; font-weight:800; line-height:1; box-shadow:0 6px 16px rgba(0,0,0,.12)}
.act.view{background:#eef3ff; color:#3b53cc}
.act.dl{background:linear-gradient(135deg,#6bcf7f,#4d9de0); color:#fff}
.act.del{background:#ffefef; color:#c62828}

/* هدر و محتوا */
.m-head{display:flex; gap:.6rem; align-items:center; margin-bottom:.4rem}
.m-icon{width:46px;height:46px;border-radius:12px;display:grid;place-items:center;font-size:1.3rem;flex-shrink:0;background:var(--icbg); color:var(--ic)}
.m-title{margin:0; color:var(--ink); font-size:1.05rem}
.m-meta{display:flex; flex-wrap:wrap; gap:.35rem; align-items:center; color:#666; font-size:.8rem}
.tag{color:#fff; padding:.05rem .45rem; border-radius:999px; font-size:.72rem}
.new{background:#ff6b6b; color:#fff; padding:.05rem .45rem; border-radius:9px; font-size:.7rem; margin-right:.15rem}
.date,.size{color:#777}

/* پیش‌نمایش و پلیرهای مستقیم */
.m-preview{margin:.4rem 0 .2rem}
.m-preview video{width:100%; border-radius:12px; outline:none; background:#000}
.audio-wrap{background:#f8f9ff; border:1px dashed #d9defa; border-radius:12px; padding:.5rem}
.audio-wrap audio{width:100%}
.pdf-frame{width:100%; height:320px; border:0; border-radius:12px; background:#fff}
.m-illustration{display:grid; place-items:center; font-size:2.4rem; height:100px; background:linear-gradient(135deg,#f7f9ff,#eef7ff); border-radius:12px; color:#9aa7ff}

/* پلیرهای مستقیم صوت، تصویر و عکس */
.media-player {
  margin: .5rem 0;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0,0,0,.1);
  transition: all .3s ease;
  position: relative;
}

.media-player:hover {
  box-shadow: 0 6px 20px rgba(0,0,0,.15);
  transform: translateY(-1px);
}

/* پلیر ویدیو */
.video-player {
  background: #000;
}

.inline-video {
  width: 100%;
  height: auto;
  max-height: 240px;
  border-radius: 12px;
  outline: none;
  cursor: pointer;
}

/* پلیر صوتی */
.audio-player {
  background: linear-gradient(135deg, #f8faff, #e8f2ff);
  border: 2px solid #e0e7ff;
  padding: .8rem;
}

.audio-info {
  display: flex;
  align-items: center;
  gap: .5rem;
  margin-bottom: .6rem;
  color: #4f46e5;
  font-weight: bold;
}

.audio-icon {
  font-size: 1.3rem;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.1); }
}

.audio-name {
  font-size: .9rem;
  color: #374151;
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.inline-audio {
  width: 100%;
  height: 45px;
  border-radius: 8px;
  outline: none;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,.1);
}

/* نمایش تصاویر */
.image-viewer {
  background: linear-gradient(135deg, #f9f9f9, #ffffff);
  border: 2px solid #e5e7eb;
  cursor: pointer;
  transition: all .3s ease;
  position: relative;
  overflow: hidden;
}

.image-viewer:hover {
  border-color: #6366f1;
  transform: translateY(-2px);
}

.inline-image {
  width: 100%;
  height: auto;
  max-height: 300px;
  object-fit: cover;
  border-radius: 12px;
  cursor: pointer;
  transition: transform .3s ease;
  display: block;
}

.image-viewer:hover .inline-image {
  transform: scale(1.05);
}

.image-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity .3s ease;
}

.image-viewer:hover .image-overlay {
  opacity: 1;
}

.zoom-icon {
  font-size: 2rem;
  color: #fff;
}

/* Modal برای نمایش تصاویر بزرگ */
.image-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,.9);
  display: none;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  cursor: pointer;
}

.image-modal img {
  max-width: 90%;
  max-height: 90%;
  border-radius: 8px;
  box-shadow: 0 20px 60px rgba(0,0,0,.5);
  object-fit: contain;
}

.image-modal .close-btn {
  position: absolute;
  top: 20px;
  right: 30px;
  color: #fff;
  font-size: 2rem;
  cursor: pointer;
  background: rgba(0,0,0,.7);
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid rgba(255,255,255,.3);
  transition: all .3s ease;
}

/* سفارشی‌سازی کنترل‌های پخش */
.inline-video::-webkit-media-controls-panel {
  background: rgba(0,0,0,.8);
  border-radius: 0 0 12px 12px;
}

.inline-audio::-webkit-media-controls-panel {
  background: linear-gradient(135deg, #667eea, #764ba2);
  border-radius: 6px;
}

.inline-audio::-webkit-media-controls-play-button {
  background-color: #fff;
  border-radius: 50%;
}

.inline-audio::-webkit-media-controls-timeline {
  background: rgba(255,255,255,.3);
  border-radius: 4px;
}

/* حالت فول‌اسکرین */
.video-player:fullscreen {
  background: #000;
}

.video-player:-webkit-full-screen {
  background: #000;
}

/* اثرات انیمیشن برای پلیر */
.media-player::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #ff6b6b, #4ecdc4, #45b7d1, #f9ca24, #a29bfe);
  opacity: 0;
  transition: opacity .3s ease;
  z-index: 1;
}

.media-player:hover::before {
  opacity: 1;
}

/* ایکون خطا */
.m-illustration.error {
  background: linear-gradient(135deg, #fee2e2, #fecaca);
  color: #dc2626;
}

.m-illustration.doc-preview {
  cursor: pointer;
}

.m-illustration.doc-preview:hover {
  background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
  color: #4f46e5;
}

/* توضیح و فوتر */
.m-desc{color:#444; line-height:1.6; margin:.3rem 0 .1rem}
.m-desc.m-muted{color:#9aa}
.m-foot{display:flex; justify-content:space-between; align-items:center; gap:.6rem; padding-top:.5rem; border-top:1px solid #eee}
.stats{display:flex; gap:.6rem; color:#777; font-size:.85rem}

/* تازه‌ها: چیپ آیکونی قابل دانلود */
.recent-rail{margin-top:1rem}
.recent-rail h3{color:#fff; margin:.2rem 0 .7rem}
.recent-icons{display:flex; flex-wrap:wrap; gap:.5rem}
.recent-chip{
  display:flex; align-items:center; gap:.4rem; cursor:pointer; border:0; border-radius:999px;
  padding:.45rem .75rem; background:#fff; box-shadow:0 6px 16px rgba(0,0,0,.08); border-top:3px solid var(--chip);
}
.recent-chip:hover{transform:translateY(-1px)}
.rc-icn{font-size:1.1rem}
.rc-title{font-weight:700; color:#333}

/* آپلود + نوار پیشرفت - رنگ‌بندی جدید */
.upload-section{
  background:rgba(255,255,255,.96); 
  border-radius:16px; 
  padding:1rem; 
  box-shadow:0 8px 22px rgba(0,0,0,.08); 
  margin-top:1rem;
  border: 3px solid #000; /* حاشیه مشکی اضافه شده */
}
.upload-section h3{color:#222; margin:0 0 .6rem}
.upload-grid{display:grid; grid-template-columns:1fr 1fr; gap:.6rem}

/* استایل فرم با حاشیه مشکی */
.form-group {
  margin-bottom: 1rem;
}
.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: bold;
  color: #000;
}
.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 0.6rem;
  border: 2px solid #000; /* حاشیه مشکی */
  border-radius: 8px;
  background: #fff;
  color: #000;
  font-size: 1rem;
}

.file-upload-area{
  position:relative; 
  border:3px dashed #000; /* حاشیه مشکی ضخیم‌تر */
  border-radius:12px; 
  padding:1rem; 
  text-align:center;
  background: #f9f9f9; /* پس‌زمینه روشن‌تر */
}
.file-upload-area:hover{background:#f5f5f5}
.file-upload-area input[type=file]{position:absolute; inset:0; opacity:0; cursor:pointer}
.file-upload-label{display:flex; flex-direction:column; gap:.25rem; align-items:center}
.upload-icon{font-size:2rem}
.upload-text{color:#333; font-weight: bold}
.file-info{color:#3b53cc; font-size:.9rem; margin-top:.15rem}

.progress{margin-top:.8rem; border: 2px solid #000; border-radius: 8px; padding: 0.5rem; background: #fff;}
.progress.hidden{display:none}
.progress-top, .progress-bottom{display:flex; align-items:center; justify-content:space-between; font-size:.9rem; color:#000}
.progress-bar{width:100%; height:10px; background:#eef2ff; border-radius:999px; overflow:hidden; margin:.35rem 0; border: 1px solid #000;}
.bar{height:100%; width:0; background:linear-gradient(90deg,#6bcf7f,#4d9de0); transition:width .15s}
.btn.small{padding:.3rem .55rem; border-radius:8px; font-size:.85rem}
.btn.danger.ghost{background:#ffefef; color:#c62828; border: 1px solid #000; cursor:pointer}
.btn.xl.solid{
  background:linear-gradient(135deg,#6bcf7f,#4d9de0); 
  color:#fff; 
  border: 2px solid #000; 
  padding:0.8rem 1.5rem; 
  border-radius:12px; 
  font-size:1.1rem; 
  cursor:pointer; 
  font-weight:bold;
  width: 100%;
}

/* واکنش‌گرا */
@media (max-width: 640px){
  .upload-grid{grid-template-columns:1fr}
  .topbar-search{min-width:0; flex:1}
  .materials-topbar{
    top: 70px; /* کمتر برای موبایل */
    padding: .6rem .8rem;
  }
  .topbar-tools{
    flex-direction: column;
    align-items: stretch;
    gap: .4rem;
  }
  .segmented.as-buttons{
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>

<script>
// جستجو
function searchMaterials(){
  const term = (document.getElementById('materialSearch').value||'').toLowerCase();
  document.querySelectorAll('.material-card').forEach(card=>{
    const t = card.dataset.title || '';
    const desc = (card.querySelector('.m-desc')?.textContent||'').toLowerCase();
    card.classList.toggle('hidden', !(t.includes(term) || desc.includes(term)));
  });
}

// فیلتر موضوع + دکمه فعال (اصلاح شده)
function filterMaterials(subj){
  console.log('فیلتر برای:', subj); // برای دیباگ
  
  // دکمه‌های تاپ‌بار
  document.querySelectorAll('.seg.btn').forEach(b=>{
    const active = (b.dataset.subject===subj) || (subj==='all' && b.dataset.subject==='all');
    b.classList.toggle('active', active);
    b.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  
  // کارت‌ها - اصلاح منطق فیلتر
  document.querySelectorAll('.material-card').forEach(card=>{
    const cardSubject = card.dataset.subject;
    console.log('کارت:', cardSubject, 'فیلتر:', subj); // برای دیباگ
    
    if(subj==='all') {
      card.classList.remove('hidden');
    } else if (cardSubject === subj) {
      card.classList.remove('hidden');
    } else {
      card.classList.add('hidden');
    }
  });
  
  // اسکرول نرم حذف شد تا منو ثابت بماند
}

// مرتب‌سازی
function sortMaterials(mode){
  const grid = document.getElementById('materialsContainer');
  const cards = Array.from(grid.children);
  cards.sort((a,b)=>{
    if(mode==='title'){
      return a.querySelector('.m-title').textContent.localeCompare(b.querySelector('.m-title').textContent,'fa');
    } else if(mode==='popular'){
      return (parseInt(b.dataset.dcount||'0') - parseInt(a.dataset.dcount||'0'));
    }
    return 0; // newest
  });
  cards.forEach(c=>grid.appendChild(c));
}

// نمایش/پنهان کردن پریویو
function togglePreview(btn){
  const card = btn.closest('.material-card');
  const pv = card.querySelector('.m-preview');
  if(!pv){ return; }
  pv.style.display = (pv.style.display==='none' || pv.style.display==='') ? 'block' : 'none';
  btn.classList.toggle('active');
}

// نمایش تصاویر در modal
function showImageModal(imgSrc, title) {
  // حذف modal قبلی اگر وجود دارد
  const existingModal = document.querySelector('.image-modal');
  if (existingModal) {
    existingModal.remove();
  }

  // ایجاد modal جدید
  const modal = document.createElement('div');
  modal.className = 'image-modal';
  modal.innerHTML = `
    <div class="close-btn" onclick="this.parentElement.remove()">&times;</div>
    <img src="${imgSrc}" alt="${title}" loading="lazy">
  `;
  
  // اضافه کردن به صفحه
  document.body.appendChild(modal);
  modal.style.display = 'flex';
  
  // بستن با کلیک روی پس‌زمینه
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.remove();
    }
  });
  
  // بستن با کلید ESC
  const handleEsc = (e) => {
    if (e.key === 'Escape') {
      modal.remove();
      document.removeEventListener('keydown', handleEsc);
    }
  };
  document.addEventListener('keydown', handleEsc);
}

// دانلود
function downloadMaterial(id){
  fetch('ajax/record-download.php', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({material_id:id})
  }).catch(()=>{});
  window.location.href = `ajax/download-material.php?id=${id}`;
}

// حذف
function deleteMaterial(id){
  if(!confirm('آیا از حذف این محتوا مطمئن هستید؟')) return;
  fetch('ajax/delete-material.php',{
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({material_id:id})
  }).then(r=>r.json()).then(d=>{
    if(d.success){ location.reload(); }
    else { alert(d.message||'خطا در حذف'); }
  }).catch(()=> alert('خطا در ارتباط با سرور'));
}

// آپلود با نوار پیشرفت و لغو
let currentXhr = null;
document.addEventListener('DOMContentLoaded', ()=>{
  const fileInput   = document.getElementById('materialFile');
  const uploadForm  = document.getElementById('uploadMaterialForm');
  const uploadArea  = document.getElementById('fileUploadArea');
  const progWrap    = document.getElementById('uploadProgress');
  const bar         = document.getElementById('uploadBar');
  const pct         = document.getElementById('uploadPct');
  const speedEl     = document.getElementById('uploadSpeed');
  const statusEl    = document.getElementById('uploadStatus');
  const cancelBtn   = document.getElementById('uploadCancel');

  // اضافه کردن event listener برای کلیک روی تصاویر
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('inline-image')) {
      const title = e.target.alt || 'تصویر';
      showImageModal(e.target.src, title);
    }
  });

  // نمایش نام فایل + Drag & Drop
  if(fileInput){
    fileInput.addEventListener('change', e=>{
      const f = e.target.files?.[0];
      if(f) document.querySelector('.file-info').textContent = `${f.name} (${formatFileSize(f.size)})`;
    });
    ['dragenter','dragover','dragleave','drop'].forEach(ev=>{
      uploadArea.addEventListener(ev, e=>{e.preventDefault(); e.stopPropagation();}, false);
    });
    ['dragenter','dragover'].forEach(ev=> uploadArea.addEventListener(ev, ()=> uploadArea.classList.add('highlight'), false));
    ['dragleave','drop'].forEach(ev=> uploadArea.addEventListener(ev, ()=> uploadArea.classList.remove('highlight'), false));
    uploadArea.addEventListener('drop', e=>{
      const files = e.dataTransfer.files;
      if(files?.length){ fileInput.files = files; fileInput.dispatchEvent(new Event('change',{bubbles:true})); }
    });
  }

  // ارسال با XHR برای دریافت progress
  if(uploadForm){
    uploadForm.addEventListener('submit', e=>{
      e.preventDefault();
      const fd = new FormData(uploadForm);
      const f = fileInput?.files?.[0];
      if(!f){ alert('لطفاً فایل را انتخاب کنید'); return; }
      if(!fd.get('material_file')) fd.append('material_file', f);

      // آماده‌سازی UI
      progWrap.classList.remove('hidden');
      bar.style.width = '0%'; pct.textContent = '0%';
      statusEl.textContent = 'در حال شروع آپلود…'; speedEl.textContent = '— KB/s';
      cancelBtn.disabled = false;

      currentXhr = new XMLHttpRequest();
      let lastLoaded = 0, lastTime = Date.now();

      currentXhr.upload.onprogress = (e)=>{
        if(e.lengthComputable){
          const percent = Math.floor((e.loaded / e.total) * 100);
          bar.style.width = percent + '%';
          pct.textContent = percent + '%';
          statusEl.textContent = `${formatFileSize(e.loaded)} از ${formatFileSize(e.total)}`;

          const now = Date.now();
          const deltaBytes = e.loaded - lastLoaded;
          const deltaTime  = (now - lastTime) / 1000;
          if(deltaTime > 0){
            const speed = deltaBytes / deltaTime; // B/s
            speedEl.textContent = `${(speed/1024).toFixed(1)} KB/s`;
          }
          lastLoaded = e.loaded; lastTime = now;
        }
      };

      currentXhr.onreadystatechange = ()=>{
        if(currentXhr.readyState === 4){
          cancelBtn.disabled = true;
          try{
            const data = JSON.parse(currentXhr.responseText || '{}');
            if(currentXhr.status === 200 && data.success){
              bar.style.width = '100%'; pct.textContent = '100%';
              statusEl.textContent = 'آپلود موفق بود 🎉';
              setTimeout(()=>{ uploadForm.reset(); document.querySelector('.file-info').textContent=''; location.reload(); }, 600);
            } else {
              statusEl.textContent = data.message || 'خطا در آپلود';
              alert(data.message || 'خطا در آپلود');
            }
          }catch(_){
            statusEl.textContent = 'پاسخ نامعتبر از سرور';
            alert('پاسخ نامعتبر از سرور');
          }
        }
      };

      currentXhr.open('POST', 'ajax/upload-material.php', true);
      currentXhr.send(fd);

      // لغو
      cancelBtn.onclick = ()=>{
        if(currentXhr){
          currentXhr.abort();
          statusEl.textContent = 'آپلود لغو شد';
          cancelBtn.disabled = true;
        }
      };
    });
  }
});

function formatFileSize(bytes){
  if(bytes===0) return '0 Bytes';
  const k=1024, sizes=['Bytes','KB','MB','GB'], i=Math.floor(Math.log(bytes)/Math.log(k));
  return (bytes/Math.pow(k,i)).toFixed(2)+' '+sizes[i];
}
</script>

<?php
// آیکن فایل‌ها
function getFileIcon($fileType) {
  $map = [
    'application/pdf' => '📄',
    'application/msword' => '📝',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => '📝',
    'application/vnd.ms-powerpoint' => '📊',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation' => '📊',
    'text/plain' => '📃',
    'application/zip' => '📦',
    'audio/mpeg' => '🎧', 'audio/mp4' => '🎧', 'audio/ogg'=>'🎧','audio/wav'=>'🎧',
    'video/mp4' => '🎬', 'video/webm' => '🎬', 'video/quicktime'=>'🎬'
  ];
  if (strpos($fileType,'audio/')===0) return '🎧';
  if (strpos($fileType,'video/')===0) return '🎬';
  return $map[$fileType] ?? '📎';
}
function formatFileSize($bytes) {
  if ($bytes == 0) return 'N/A';
  $k = 1024; $sizes = ['Bytes', 'KB', 'MB', 'GB'];
  $i = floor(log($bytes) / log($k));
  return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>