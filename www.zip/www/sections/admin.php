<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

 $db = $conn;
// This file is admin.php - assuming it's included or required in the main file where $conn is defined
// Admin panel - Only show if admin
if (!isAdmin()) {
    exit();
}

 $adminStats = getAdminStats($conn);
 $aboutSettings = getAboutSettings($conn);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پنل مدیریت</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
</head>
<body>
  <section id="admin" class="section">
    <h2 style="text-align: center; color: #FF7F50; margin-bottom: 2rem;">پنل مدیریت</h2>
    
    <!-- Admin Stats -->
    <div class="dashboard-stats">
        <div class="stat-card" style="background: linear-gradient(135deg, #FFE4E1, #FFA07A);">
            <h4>تعداد دانش‌آموزان</h4>
            <span class="stat-number"><?php echo $adminStats['totalStudents']; ?></span>
            <p>فعال در سیستم</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #E0F2E9, #98FB98);">
            <h4>بازخوردهای جدید</h4>
            <span class="stat-number"><?php echo $adminStats['newFeedbacks']; ?></span>
            <p>در انتظار بررسی</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #E6E6FA, #DDA0DD);">
            <h4>محتوای آپلود شده</h4>
            <span class="stat-number"><?php echo $adminStats['totalContent']; ?></span>
            <p>فایل و رسانه</p>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #F0E68C, #FFD700);">
            <h4>بازدید امروز</h4>
            <span class="stat-number"><?php echo $adminStats['todayVisits']; ?></span>
            <p>کاربر فعال</p>
        </div>
    </div>
    
    <!-- Admin Navigation Buttons - چیدمان جذاب با grid -->
    <div class="admin-buttons" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; margin: 3rem 0;">
        <a href="sections/students_admin.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">🎓</span> مدیریت دانش آموزان
        </a>
        <a href="/sections/Discipline.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">⚖️</span> موارد انضباطی
        </a>
        <a href="/sections/classNotebook_admin.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">📔</span> دفتر کلاسی
        </a>
        <a href="/sections/exams/library.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">🧪</span> آزمون ساز
        </a>
        <a href="sections/gamesettings_admin.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">🎮</span> تنظیمات بازیها و نشان ها
        </a>
        <a href="/sections/visitor.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">👥</span> مدیریت بازدید کنندگان
        </a>
        <a href="https://starmah.ir/exam.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">🤖</span> طراح برگه سوال 
        </a>
        <a href="sections/admin_user.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">⚙️</span>تنظیمات کاربر ادمین
        </a>
        
        <!-- دکمه جدید -->
        <a href="sections/weekly_analysis.php" class="admin-button" style="background: linear-gradient(135deg, #E0F7FA, #B2EBF2); color: #000; padding: 2rem; border-radius: 25px; text-align: center; font-weight: bold; font-size: 1.4rem; box-shadow: 0 8px 25px rgba(178, 235, 242, 0.5); transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
            <span style="font-size: 2.5rem; margin-left: 1rem;">📊</span> تحلیل عملکرد امتیازات به دست آورده
        </a>
        
    </div>
    
    <!-- حذف بخش‌های محتوایی زیرا حالا در صفحات جداگانه بارگذاری می‌شوند -->
    
</section>

<style>
/* حفظ تمام استایل‌های اصلی بدون تغییر تم */

/* استایل اضافی برای دکمه‌های جذاب */
.admin-button:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 12px 35px rgba(178, 235, 242, 0.6);
}

.admin-button::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.4) 0%, transparent 70%);
    transition: all 0.5s ease;
    opacity: 0;
}

.admin-button:hover::before {
    opacity: 1;
    top: -100%;
    left: -100%;
}

/* ریسپانسیو برای موبایل */
@media (max-width: 768px) {
    .admin-buttons {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }

    .admin-button {
        font-size: 1.3rem;
        padding: 1.5rem;
    }
}

/* بقیه استایل‌های اصلی */
</style>

<script>
/* حذف اسکریپت‌های showAdminSection زیرا حالا لینک هستند */

// بقیه اسکریپت‌های لازم مانند AJAX اگر در صفحات جداگانه نیاز باشند
</script>
</body>
</html>