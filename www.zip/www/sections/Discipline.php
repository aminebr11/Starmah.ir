<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// اطلاعات کاربر
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// عنوان صفحه
$page_title = 'مدیریت موارد انضباطی';
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - سیستم مدیریت مدرسه</title>
    
    <!-- CSS فایل‌ها -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Persian DatePicker -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.js"></script>
    
    <style>
        body {
            font-family: 'Tahoma', 'Vazir', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .header-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title h1 {
            margin: 0;
            font-size: 2rem;
            font-weight: 700;
        }

        .header-user {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .back-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 25px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .back-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* استایل‌های موجود از کد قبلی */
        .discipline-header {
            background: linear-gradient(135deg, #ff416c, #ff4b2b, #ff6b35);
            color: white;
            padding: 40px 30px 20px;
            border-radius: 25px 25px 0 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .tab-navigation {
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .discipline-tab-btn {
            padding: 15px 30px;
            background: rgba(255,255,255,0.1);
            border: 2px solid rgba(255,255,255,0.2);
            border-radius: 50px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            color: rgba(255,255,255,0.8);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .discipline-tab-btn.active {
            background: rgba(255,255,255,0.3) !important;
            border-color: rgba(255,255,255,0.5) !important;
            color: white !important;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2);
        }

        .discipline-tab-btn:hover:not(.active) {
            background: rgba(255,255,255,0.2) !important;
            border-color: rgba(255,255,255,0.4) !important;
            transform: translateY(-1px);
        }

        .discipline-tab-content {
            background: white;
            padding: 40px;
            border-radius: 0 0 25px 25px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            display: none;
        }

        .discipline-tab-content.active {
            display: block;
        }

        /* انیمیشن شناور */
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
        }

        /* استایل‌های کارت دانش‌آموزان */
        .student-card {
            background: linear-gradient(135deg, #f8f9ff, #e8eeff);
            border: 3px solid #e3e8ee;
            border-radius: 20px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.4s ease;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .student-card:hover {
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 15px 30px rgba(102, 126, 234, 0.3);
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .student-card.selected {
            background: linear-gradient(135deg, #28a745, #20c997) !important;
            border-color: #28a745 !important;
            color: white !important;
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 15px 30px rgba(40, 167, 69, 0.4);
        }

        .student-card.selected .selection-indicator {
            background: #28a745 !important;
            border-color: #28a745 !important;
        }

        .student-card.selected .check-mark {
            opacity: 1 !important;
            color: white !important;
        }

        /* استایل‌های موارد انضباطی */
        .discipline-item {
            background: linear-gradient(135deg, #ffe5e5, #fff0f0);
            border: 3px solid #ffcccb;
            border-radius: 18px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .discipline-item:hover {
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 15px 30px rgba(255, 107, 107, 0.3);
            border-color: #ff6b6b;
            background: linear-gradient(135deg, #ff6b6b, #ffd93d);
            color: white;
        }

        .discipline-item.selected {
            background: linear-gradient(135deg, #dc3545, #c82333) !important;
            border-color: #dc3545 !important;
            color: white !important;
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 15px 30px rgba(220, 53, 69, 0.4);
        }

        .discipline-item.selected .selection-indicator {
            background: #dc3545 !important;
            border-color: #dc3545 !important;
        }

        .discipline-item.selected .check-mark {
            opacity: 1 !important;
            color: white !important;
        }

        /* استایل‌های کارت موبایل */
        .discipline-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 2px solid #f1f3f4;
            position: relative;
            transition: all 0.3s ease;
        }

        .discipline-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .discipline-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e9ecef;
        }

        .discipline-card-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            justify-content: center;
        }

        /* استایل‌های صفحه‌بندی */
        .pagination-btn {
            padding: 10px 15px;
            border: 2px solid #e9ecef;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .pagination-btn.active {
            background: #ff416c;
            color: white;
            border-color: #ff416c;
        }

        .pagination-btn:hover:not(.active) {
            border-color: #ff416c;
            color: #ff416c;
            transform: translateY(-2px);
        }

        /* استایل‌های مودال */
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            display: none;
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #000;
        }

        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: #ff416c;
            box-shadow: 0 0 0 3px rgba(255, 65, 108, 0.1);
        }

        /* موبایل ریسپانسیو */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column !important;
                text-align: center !important;
                gap: 15px !important;
            }

            .header-title h1 {
                font-size: 1.5rem !important;
            }

            .tab-navigation {
                flex-direction: column !important;
            }

            .discipline-tab-btn {
                padding: 12px 20px !important;
                font-size: 1rem !important;
            }

            .container {
                padding: 0 10px !important;
            }

            .discipline-header {
                padding: 30px 20px !important;
            }

            .discipline-header h2 {
                font-size: 2rem !important;
            }

            #disciplineStudentGrid,
            #disciplineItems {
                grid-template-columns: 1fr !important;
            }

            /* نمایش کارت‌ها در موبایل */
            #disciplineHistoryTable {
                display: none !important;
            }
            
            .discipline-cards {
                display: block !important;
            }

            .filter-actions {
                flex-direction: column !important;
            }

            .action-btn {
                justify-content: center !important;
                width: 100% !important;
                margin-bottom: 10px !important;
            }

            .history-stats {
                grid-template-columns: repeat(2, 1fr) !important;
            }

            .modal-content {
                width: 95% !important;
                margin: 2% auto !important;
            }
        }

        /* استایل‌های نوتیفیکیشن */
        .discipline-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            z-index: 100000;
            animation: slideInRight 0.3s ease;
            max-width: 400px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.3);
        }

        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .discipline-notification.success {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .discipline-notification.error {
            background: linear-gradient(135deg, #dc3545, #c82333);
        }

        .discipline-notification.info {
            background: linear-gradient(135deg, #17a2b8, #138496);
        }

        .discipline-notification.warning {
            background: linear-gradient(135deg, #ffc107, #e0a800);
            color: #333;
        }

        /* استایل‌های تاریخچه */
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }

        .history-table th,
        .history-table td {
            padding: 15px 12px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        .history-table thead tr {
            background: linear-gradient(135deg, #495057, #343a40);
        }

        .history-table tbody tr:hover {
            background: rgba(255, 65, 108, 0.05);
        }

        /* Loading Spinner */
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #ff416c;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <div class="header-section">
        <div class="header-content">
            <div class="header-title">
                <h1><i class="fas fa-balance-scale"></i> <?php echo $page_title; ?></h1>
            </div>
            <div class="header-user">
                <span>سلام، <?php echo $user['first_name'] . ' ' . $user['last_name']; ?></span>
                <a href="../index.php" class="back-btn">
                    <i class="fas fa-arrow-right"></i>
                    بازگشت به داشبورد
                </a>
            </div>
        </div>
    </div>

    <!-- محتوای اصلی -->
    <div class="container">
        <div class="form-container" style="max-width: none; padding: 0;">
            
            <!-- Header جذاب با تب‌ها -->
            <div class="discipline-header">
                <div style="position: absolute; top: -50px; right: -50px; width: 200px; height: 200px; background: rgba(255,255,255,0.1); border-radius: 50%; animation: float 6s ease-in-out infinite;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 150px; height: 150px; background: rgba(255,255,255,0.05); border-radius: 50%; animation: float 4s ease-in-out infinite reverse;"></div>
                
                <div style="position: relative; z-index: 2;">
                    <h2 style="font-size: 2.8rem; margin: 0 0 15px 0; font-weight: 800; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">⚖️ مدیریت موارد انضباطی</h2>
                    <p style="font-size: 1.2rem; margin: 0 0 30px 0; opacity: 0.9; font-weight: 400;">ثبت هوشمند و مدیریت جامع رفتار دانش‌آموزان</p>
                    
                    <!-- ناوبری تب‌ها -->
                    <div class="tab-navigation">
                        <button class="discipline-tab-btn active" data-tab="registration" onclick="showDisciplineTab('registration')">
                            <i class="fas fa-plus-circle" style="font-size: 1.2rem;"></i> ثبت مورد انضباطی
                        </button>
                        <button class="discipline-tab-btn" data-tab="history" onclick="showDisciplineTab('history')">
                            <i class="fas fa-history" style="font-size: 1.2rem;"></i> تاریخچه و مدیریت
                        </button>
                    </div>
                </div>
            </div>

            <!-- محتوای تب ثبت -->
            <div id="discipline-registration" class="discipline-tab-content active">
                
                <!-- مرحله 1: انتخاب دانش‌آموزان -->
                <div class="selection-step" style="margin-bottom: 40px;">
                    <div class="step-header" style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px; padding: 20px; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 15px; box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);">
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 50%; font-size: 1.5rem;">1️⃣</div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem; font-weight: 700;">انتخاب دانش‌آموزان</h3>
                            <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 1rem;">می‌توانید یک یا چند دانش‌آموز را انتخاب کنید</p>
                        </div>
                        <div class="selected-counter" id="selectedStudentsCounter" style="margin-right: auto; background: rgba(255,255,255,0.2); padding: 10px 15px; border-radius: 20px; font-weight: 600;">
                            انتخاب شده: <span id="studentsCount">0</span>
                        </div>
                    </div>

                    <!-- جستجوی دانش‌آموز -->
                    <div style="margin-bottom: 20px;">
                        <input type="text" id="studentSearch" placeholder="🔍 جستجوی نام دانش‌آموز..." 
                               style="width: 100%; padding: 15px 20px; border: 2px solid #e3e8ee; border-radius: 50px; font-size: 1rem; transition: all 0.3s ease;"
                               onkeyup="searchStudents(this.value)"
                               onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 20px rgba(102,126,234,0.2)'"
                               onblur="this.style.borderColor='#e3e8ee'; this.style.boxShadow='none'">
                    </div>

                    <div id="disciplineStudentGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; max-height: 400px; overflow-y: auto; padding: 10px;">
                        <?php
                        $stmt = $conn->prepare("SELECT id, first_name, last_name, national_id FROM users WHERE user_type = 'student' AND is_active = 1 ORDER BY last_name, first_name");
                        $stmt->execute();
                        $students = $stmt->fetchAll();
                        
                        foreach($students as $student):
                        ?>
                        <div class="student-card" data-student-id="<?php echo $student['id']; ?>" data-student-name="<?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>" 
                             onclick="toggleStudentSelection(this, <?php echo $student['id']; ?>, '<?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>', '<?php echo $student['national_id']; ?>')">
                            
                            <div class="selection-indicator" style="position: absolute; top: 10px; right: 10px; width: 25px; height: 25px; border-radius: 50%; border: 2px solid #ccc; background: white; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                                <span class="check-mark" style="color: #28a745; font-size: 16px; opacity: 0; transition: opacity 0.3s ease;">✓</span>
                            </div>

                            <div style="font-size: 2.5rem; margin-bottom: 15px;">🎓</div>
                            <div style="font-weight: 700; font-size: 1.2rem; margin-bottom: 8px; color: #2c3e50;">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                            </div>
                            <div style="font-size: 0.9rem; color: #6c757d; background: rgba(255,255,255,0.7); padding: 5px 10px; border-radius: 15px; display: inline-block;">
                                کد ملی: <?php echo htmlspecialchars($student['national_id']); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- مرحله 2: انتخاب موارد انضباطی -->
                <div class="selection-step" style="margin-bottom: 40px;">
                    <div class="step-header" style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px; padding: 20px; background: linear-gradient(135deg, #ff6b6b, #ee5a52); color: white; border-radius: 15px; box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);">
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 50%; font-size: 1.5rem;">2️⃣</div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem; font-weight: 700;">انتخاب موارد انضباطی</h3>
                            <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 1rem;">می‌توانید چندین مورد انضباطی را همزمان انتخاب کنید</p>
                        </div>
                        <div class="selected-counter" id="selectedDisciplinesCounter" style="margin-right: auto; background: rgba(255,255,255,0.2); padding: 10px 15px; border-radius: 20px; font-weight: 600;">
                            انتخاب شده: <span id="disciplinesCount">0</span>
                        </div>
                    </div>

                    <!-- افزودن مورد جدید -->
                    <div style="background: linear-gradient(135deg, #fff3cd, #ffeaa7); border: 2px solid #ffd93d; border-radius: 20px; padding: 25px; margin-bottom: 25px;">
                        <h4 style="color: #856404; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 1.3rem;">
                            <span style="font-size: 1.8rem;">➕</span> افزودن مورد انضباطی جدید
                        </h4>
                        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 20px; align-items: end;">
                            <div>
                                <label style="font-weight: 600; color: #856404; margin-bottom: 8px; display: block;">عنوان مورد:</label>
                                <input type="text" id="newDisciplineTitle" placeholder="مثال: عدم حضور در صف صبحگاهی" 
                                       style="width: 80%; padding: 15px; border: 2px solid #ffd93d; border-radius: 12px; font-size: 1rem; transition: all 0.3s ease;">
                            </div>
                            <div>
                                <label style="font-weight: 600; color: #856404; margin-bottom: 8px; display: block;">نمره منفی:</label>
                                <input type="number" id="newDisciplineScore" min="1" max="50" placeholder="5"
                                       style="width: 90%; padding: 15px; border: 2px solid #ffd93d; border-radius: 12px; font-size: 1rem; text-align: center;">
                            </div>
                            <div>
                                <button onclick="addNewDisciplineItem()" 
                                        style="background: linear-gradient(135deg, #28a745, #20c997); color: white; border: none; padding: 15px 25px; border-radius: 12px; cursor: pointer; font-weight: 700; font-size: 1rem; width: 100%; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);"
                                        onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 8px 25px rgba(40,167,69,0.4)'" 
                                        onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(40,167,69,0.3)'">
                                    ✨ افزودن
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="disciplineItems" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px;">
                        <!-- موارد انضباطی از دیتابیس بارگیری می‌شوند -->
                        <div style="text-align: center; padding: 40px; color: #6c757d; grid-column: 1/-1;">
                            <div class="loading-spinner" style="margin: 0 auto 1rem;"></div>
                            <div>در حال بارگیری موارد انضباطی...</div>
                        </div>
                    </div>
                </div>

                <!-- مرحله 3: جزئیات و ثبت -->
                <div class="selection-step">
                    <div class="step-header" style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px; padding: 20px; background: linear-gradient(135deg, #4facfe, #00f2fe); color: white; border-radius: 15px; box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);">
                        <div style="background: rgba(255,255,255,0.2); padding: 12px; border-radius: 50%; font-size: 1.5rem;">3️⃣</div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem; font-weight: 700;">جزئیات و ثبت نهایی</h3>
                            <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 1rem;">تاریخ و توضیحات مورد انضباطی را وارد کنید</p>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 25px; margin-bottom: 40px;">
                        <div style="background: linear-gradient(135deg, #e8f4fd, #f0f8ff); border: 2px solid #87ceeb; border-radius: 20px; padding: 25px;">
                            <label style="font-weight: 700; color: #1976d2; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; font-size: 1.1rem;">
                                <span style="font-size: 1.3rem;">📅</span> تاریخ وقوع
                            </label>
                            <div style="position: relative;">
                                <input type="text" id="disciplineDate" readonly
                                       placeholder="روز/ماه/سال شمسی" 
                                       style="width: 70%; padding: 15px 50px 15px 15px; border: 2px solid #87ceeb; border-radius: 15px; font-size: 1.1rem; text-align: center; font-weight: 600; background: white; cursor: pointer;">
                                <span class="calendar-icon" onclick="openPersianDatePicker()" 
                                      style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 16px; color: #1976d2;">
                                    📅
                                </span>
                            </div>
                            <div id="dateError" class="date-error" style="display: none; color: #dc3545; font-size: 12px; margin-top: 4px;"></div>
                        </div>
                        
                        <div style="background: linear-gradient(135deg, #f0f8ff, #e8f4fd); border: 2px solid #87ceeb; border-radius: 20px; padding: 25px;">
                            <label style="font-weight: 700; color: #1976d2; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; font-size: 1.1rem;">
                                <span style="font-size: 1.3rem;">💬</span> توضیحات تکمیلی (اختیاری)
                            </label>
                            <textarea id="disciplineDescription" rows="4" placeholder="جزئیات بیشتر در مورد وقوع این مورد انضباطی..."
                                      style="width: 90%; padding: 15px; border: 2px solid #87ceeb; border-radius: 15px; font-size: 1rem; resize: vertical; line-height: 1.6;"></textarea>
                        </div>
                    </div>

                    <!-- خلاصه انتخاب‌ها -->
                    <div id="summarySection" style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); border: 2px solid #dee2e6; border-radius: 20px; padding: 25px; margin-bottom: 30px; display: none;">
                        <h4 style="color: #495057; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 1.3rem;">
                            <span style="font-size: 1.5rem;">📋</span> خلاصه انتخاب‌ها
                        </h4>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div>
                                <strong style="color: #667eea;">دانش‌آموزان انتخاب شده:</strong>
                                <ul id="selectedStudentsList" style="margin: 10px 0; padding-right: 20px; color: #495057;"></ul>
                            </div>
                            <div>
                                <strong style="color: #ff6b6b;">موارد انضباطی انتخاب شده:</strong>
                                <ul id="selectedDisciplinesList" style="margin: 10px 0; padding-right: 20px; color: #495057;"></ul>
                            </div>
                        </div>
                    </div>

                    <!-- دکمه ثبت -->
                    <div style="text-align: center;">
                        <button onclick="submitDisciplineRecord()" id="submitBtn" disabled
                                style="background: linear-gradient(135deg, #6c757d, #5a6268); color: white; border: none; padding: 20px 50px; border-radius: 50px; font-size: 1.3rem; font-weight: 700; cursor: not-allowed; transition: all 0.4s ease; opacity: 0.5; box-shadow: 0 8px 25px rgba(220,53,69,0.3);">
                            <span style="font-size: 1.5rem; margin-left: 10px;">🚀</span>
                            ثبت و ارسال موارد انضباطی
                        </button>
                        <p style="margin-top: 15px; color: #6c757d; font-size: 0.9rem;">برای فعال شدن دکمه، حداقل یک دانش‌آموز، یک مورد انضباطی و تاریخ انتخاب کنید</p>
                    </div>
                </div>
            </div>

            <!-- محتوای تب تاریخچه -->
            <div id="discipline-history" class="discipline-tab-content">
                
                <!-- فیلترها و آمار -->
                <div class="history-filters" style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 20px; padding: 30px; margin-bottom: 30px; border: 2px solid #dee2e6;">
                    
                    <!-- آمار سریع -->
                    <div class="history-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                        <div class="stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);">
                            <div class="stat-number" id="totalRecords" style="font-size: 2.5rem; font-weight: 700; margin-bottom: 8px;">0</div>
                            <div class="stat-label" style="font-size: 1rem; opacity: 0.9;">کل موارد</div>
                        </div>
                        <div class="stat-card" style="background: linear-gradient(135deg, #ff6b6b, #ee5a52); color: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);">
                            <div class="stat-number" id="violatedStudents" style="font-size: 2.5rem; font-weight: 700; margin-bottom: 8px;">0</div>
                            <div class="stat-label" style="font-size: 1rem; opacity: 0.9;">دانش‌آموزان متخلف</div>
                        </div>
                        <div class="stat-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe); color: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);">
                            <div class="stat-number" id="thisWeekRecords" style="font-size: 2.5rem; font-weight: 700; margin-bottom: 8px;">0</div>
                            <div class="stat-label" style="font-size: 1rem; opacity: 0.9;">موارد هفته جاری</div>
                        </div>
                        <div class="stat-card" style="background: linear-gradient(135deg, #ffc107, #e0a800); color: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);">
                            <div class="stat-number" id="totalScore" style="font-size: 2.5rem; font-weight: 700; margin-bottom: 8px;">0</div>
                            <div class="stat-label" style="font-size: 1rem; opacity: 0.9;">کل امتیاز منفی</div>
                        </div>
                    </div>

                    <!-- فیلترهای جستجو -->
                    <div class="filter-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 25px;">
                        <div class="form-group">
                            <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                                <i class="fas fa-user" style="color: #667eea;"></i> فیلتر دانش‌آموز
                            </label>
                            <select class="form-input" id="filterStudent" style="width: 100%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                                <option value="">همه دانش‌آموزان</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                                <i class="fas fa-exclamation-triangle" style="color: #ff6b6b;"></i> نوع مورد
                            </label>
                            <select class="form-input" id="filterDisciplineType" style="width: 100%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                                <option value="">همه موارد</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                                <i class="fas fa-calendar-alt" style="color: #4facfe;"></i> از تاریخ
                            </label>
                            <input type="text" class="form-input" id="filterFromDate" placeholder="مثال: 1403/06/15" style="width: 100%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                                <i class="fas fa-calendar-alt" style="color: #4facfe;"></i> تا تاریخ
                            </label>
                            <input type="text" class="form-input" id="filterToDate" placeholder="مثال: 1403/06/20" style="width: 100%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                        </div>
                    </div>

                    <!-- دکمه‌های عملیات -->
                    <div class="filter-actions" style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <button class="action-btn btn-primary" onclick="applyFilters()" style="padding: 12px 24px; border-radius: 25px; border: none; cursor: pointer; font-weight: 600; transition: all 0.3s ease; display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #007bff, #0056b3); color: white;">
                            <i class="fas fa-filter"></i> اعمال فیلتر
                        </button>
                        <button class="action-btn btn-warning" onclick="clearFilters()" style="padding: 12px 24px; border-radius: 25px; border: none; cursor: pointer; font-weight: 600; transition: all 0.3s ease; display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #ffc107, #e0a800); color: #333;">
                            <i class="fas fa-times"></i> پاک کردن فیلتر
                        </button>
                        <button class="action-btn btn-success" onclick="exportToExcel()" style="padding: 12px 24px; border-radius: 25px; border: none; cursor: pointer; font-weight: 600; transition: all 0.3s ease; display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #28a745, #1e7e34); color: white;">
                            <i class="fas fa-file-excel"></i> خروجی اکسل
                        </button>
                        <button class="action-btn btn-info" onclick="printReport()" style="padding: 12px 24px; border-radius: 25px; border: none; cursor: pointer; font-weight: 600; transition: all 0.3s ease; display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, #17a2b8, #138496); color: white;">
                            <i class="fas fa-print"></i> چاپ گزارش
                        </button>
                    </div>
                </div>

                <!-- جدول تاریخچه -->
                <div class="history-table-container" style="background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); border: 2px solid #e9ecef;">
                    <table class="history-table" id="disciplineHistoryTable" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: linear-gradient(135deg, #495057, #343a40);">
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">ردیف</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">دانش‌آموز</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">مورد انضباطی</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">امتیاز منفی</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">تاریخ</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">توضیحات</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">ثبت کننده</th>
                                <th style="color: white; padding: 18px 15px; text-align: center; font-weight: 600; font-size: 1rem;">عملیات</th>
                            </tr>
                        </thead>
                        <tbody id="disciplineHistoryTableBody">
                            <!-- محتوا به صورت دینامیک بارگیری می‌شود -->
                        </tbody>
                    </table>

                    <!-- کارت‌های موبایل -->
                    <div class="discipline-cards" id="disciplineCards" style="display: none;">
                        <!-- کارت‌ها برای نمایش موبایل -->
                    </div>

                    <!-- صفحه‌بندی -->
                    <div class="pagination" id="paginationContainer" style="display: flex; justify-content: center; align-items: center; gap: 8px; margin: 25px 0; padding: 20px;">
                        <!-- دکمه‌های صفحه‌بندی -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- مودال ویرایش -->
    <div id="editModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(5px);">
        <div class="modal-content" style="background-color: white; margin: 5% auto; padding: 30px; border-radius: 20px; width: 90%; max-width: 600px; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid #e9ecef;">
                <h3 style="margin: 0; color: #495057; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-edit" style="color: #ffc107;"></i> ویرایش مورد انضباطی
                </h3>
                <span class="close" onclick="closeEditModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer; transition: color 0.3s;">&times;</span>
            </div>
            
            <form id="editForm">
                <input type="hidden" id="editRecordId">
                <div class="form-group" style="margin-bottom: 20px;">
                    <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: block;">عنوان مورد انضباطی</label>
                    <input type="text" class="form-input" id="editTitle" required style="width: 90%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                </div>
                <div class="form-group" style="margin-bottom: 20px;">
                    <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: block;">امتیاز منفی</label>
                    <input type="number" class="form-input" id="editScore" min="1" max="100" required style="width: 90%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;">
                </div>
                <div class="form-group" style="margin-bottom: 20px;">
                    <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: block;">تاریخ</label>
                    <input type="text" class="form-input" id="editDate" required style="width: 90%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem;" placeholder="مثال: 1403/06/15">
                </div>
                <div class="form-group" style="margin-bottom: 25px;">
                    <label style="font-weight: 600; color: #495057; margin-bottom: 8px; display: block;">توضیحات</label>
                    <textarea class="form-input" id="editDescription" rows="3" style="width: 90%; padding: 12px 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem; resize: vertical;"></textarea>
                </div>
                <button type="button" class="submit-btn" onclick="saveEdit()" style="background: linear-gradient(135deg, #28a745, #20c997); color: white; border: none; padding: 15px 30px; border-radius: 25px; font-size: 1.1rem; font-weight: 600; cursor: pointer; width: 100%; transition: all 0.3s ease;">
                    <i class="fas fa-save"></i> ذخیره تغییرات
                </button>
            </form>
        </div>
    </div>

    <script>
        // متغیرهای سراسری
        let selectedStudents = [];
        let selectedDisciplines = [];
        let disciplineHistory = [];
        let currentPage = 1;
        let totalPages = 1;

        // Initialize Persian Datepicker
        $(document).ready(function() {
            const disciplineDate = $('#disciplineDate');
            if (disciplineDate.length) {
                disciplineDate.persianDatepicker({
                    format: 'YYYY/MM/DD',
                    autoClose: true,
                    toolbox: {
                        calendarSwitch: { enabled: true }
                    },
                    onSelect: function() {
                        checkSubmitButton();
                    }
                });
            }

            // بارگیری موارد انضباطی از دیتابیس
            loadDisciplineItems();
        });

        // بارگیری موارد انضباطی از دیتابیس
        function loadDisciplineItems() {
            console.log('Loading discipline items from database...');
            
            fetch('../ajax/discipline-items.php?action=get_all', {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Received discipline items:', data);
                if (data.success) {
                    renderDisciplineItems(data.items);
                    showNotification(`${data.count} مورد انضباطی بارگیری شد`, 'success');
                } else {
                    console.error('Server error:', data.message);
                    showNotification('خطا در بارگیری موارد انضباطی: ' + data.message, 'error');
                    renderDefaultItems();
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                showNotification('خطا در اتصال به سرور', 'error');
                renderDefaultItems();
            });
        }

        // نمایش موارد انضباطی
        function renderDisciplineItems(items) {
            const container = document.getElementById('disciplineItems');
            if (!container) return;
            
            container.innerHTML = '';
            
            if (!items || items.length === 0) {
                container.innerHTML = `
                    <div style="text-align: center; padding: 40px; color: #6c757d; grid-column: 1/-1;">
                        <i class="fas fa-plus-circle" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <br>هیچ موردی یافت نشد. اولین مورد را اضافه کنید.
                    </div>
                `;
                return;
            }
            
            items.forEach(item => {
                const disciplineElement = createDisciplineItemHTML(item.title, item.score, item.id, true);
                container.appendChild(disciplineElement);
            });
        }

        // ایجاد HTML برای مورد انضباطی
        function createDisciplineItemHTML(title, score, id = null, fromDatabase = false) {
            const newItem = document.createElement('div');
            newItem.className = 'discipline-item';
            newItem.dataset.title = title;
            newItem.dataset.score = score;
            newItem.dataset.id = id || '';
            newItem.dataset.fromDatabase = fromDatabase;
            
            newItem.onclick = (e) => {
                // اگر روی دکمه حذف کلیک نشده، انتخاب/لغو انتخاب کن
                if (!e.target.closest('.delete-discipline-item')) {
                    toggleDisciplineSelection(newItem, title, score);
                }
            };
            
            // دکمه حذف فقط برای موارد ذخیره شده در دیتابیس
            const deleteButton = fromDatabase ? `
                <button class="delete-discipline-item" onclick="deleteDisciplineItemFromDB(event, ${id})" 
                        style="position: absolute; top: 5px; left: 5px; background: rgba(220,53,69,0.9); color: white; border: none; border-radius: 50%; width: 25px; height: 25px; cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center; z-index: 10;"
                        title="حذف از دیتابیس">
                    ×
                </button>
            ` : '';
            
            // تعیین آیکون بر اساس عنوان
            const icon = getIconForDiscipline(title);
            
            newItem.innerHTML = `
                ${deleteButton}
                
                <div class="selection-indicator" style="position: absolute; top: 15px; right: 15px; width: 25px; height: 25px; border-radius: 50%; border: 2px solid #ccc; background: white; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                    <span class="check-mark" style="color: #28a745; font-size: 16px; opacity: 0; transition: opacity 0.3s ease;">✓</span>
                </div>
                
                <div style="font-size: 2.5rem; margin-bottom: 15px;">${icon}</div>
                <div style="font-weight: 700; font-size: 1.2rem; margin-bottom: 8px; color: #721c24;">${title}</div>
                <div style="font-size: 0.95rem; color: #856404; font-weight: 600; background: rgba(255,255,255,0.8); padding: 8px 15px; border-radius: 20px; display: inline-block;">
                    نمره منفی: -${score} امتیاز ${fromDatabase ? '(ذخیره شده)' : '(موقت)'}
                </div>
            `;
            
            return newItem;
        }

        // تعیین آیکون برای هر نوع مورد انضباطی
        function getIconForDiscipline(title) {
            const titleLower = title.toLowerCase();
            
            if (titleLower.includes('تأخیر') || titleLower.includes('تاخیر')) return '⏰';
            if (titleLower.includes('تکلیف') || titleLower.includes('تمرین')) return '📝';
            if (titleLower.includes('مزاحمت') || titleLower.includes('سروصدا')) return '🗣️';
            if (titleLower.includes('لوازم') || titleLower.includes('کتاب')) return '🎒';
            if (titleLower.includes('غیبت')) return '🚫';
            if (titleLower.includes('موبایل') || titleLower.includes('تلفن')) return '📱';
            if (titleLower.includes('لباس') || titleLower.includes('فرم')) return '👔';
            if (titleLower.includes('کارت')) return '🆔';
            if (titleLower.includes('بی‌احترامی') || titleLower.includes('بی احترامی')) return '😠';
            if (titleLower.includes('نظم')) return '⚖️';
            
            return '⚠️'; // آیکون پیش‌فرض
        }

        // افزودن مورد انضباطی جدید (به دیتابیس)
        function addNewDisciplineItem() {
            const titleElement = document.getElementById('newDisciplineTitle');
            const scoreElement = document.getElementById('newDisciplineScore');
            
            const title = titleElement.value.trim();
            const score = parseInt(scoreElement.value);
            
            if (!title) {
                showNotification('لطفاً عنوان مورد انضباطی را وارد کنید', 'error');
                titleElement.focus();
                return;
            }
            
            if (isNaN(score) || score < 1 || score > 100) {
                showNotification('نمره منفی باید بین ۱ تا ۱۰۰ باشد', 'error');
                scoreElement.focus();
                return;
            }
            
            // بررسی تکرار عنوان در موارد موجود
            const existingItems = document.querySelectorAll('#disciplineItems .discipline-item');
            for (let item of existingItems) {
                if (item.dataset.title === title) {
                    showNotification('این مورد انضباطی قبلاً وجود دارد', 'error');
                    return;
                }
            }
            
            // نمایش loading
            const addButton = event.target;
            const originalText = addButton.innerHTML;
            addButton.innerHTML = '⏳ در حال افزودن...';
            addButton.disabled = true;
            
            // ارسال به سرور
            const formData = new FormData();
            formData.append('action', 'add');
            formData.append('title', title);
            formData.append('score', score);
            
            fetch('../ajax/discipline-items.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // پاک کردن فیلدها
                    titleElement.value = '';
                    scoreElement.value = '';
                    
                    // بارگیری مجدد موارد از دیتابیس
                    loadDisciplineItems();
                    
                    showNotification(data.message, 'success');
                } else {
                    showNotification('خطا: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error adding discipline item:', error);
                showNotification('خطا در افزودن مورد انضباطی', 'error');
            })
            .finally(() => {
                addButton.innerHTML = originalText;
                addButton.disabled = false;
            });
        }

        // حذف مورد انضباطی از دیتابیس
        function deleteDisciplineItemFromDB(event, id) {
            event.stopPropagation(); // جلوگیری از trigger شدن click روی parent
            
            const item = document.querySelector(`[data-id="${id}"]`);
            if (!item) return;
            
            const title = item.dataset.title;
            
            if (!confirm(`آیا می‌خواهید مورد "${title}" را از دیتابیس حذف کنید؟\n\nتوجه: این عمل قابل بازگشت نیست.`)) {
                return;
            }
            
            // ارسال درخواست حذف
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', id);
            
            fetch('../ajax/discipline-items.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // اگر این آیتم انتخاب شده بود، از لیست انتخاب‌ها حذفش کن
                    const index = selectedDisciplines.findIndex(d => d.title === title);
                    if (index !== -1) {
                        selectedDisciplines.splice(index, 1);
                        updateDisciplinesCounter();
                        updateSummary();
                        checkSubmitButton();
                    }
                    
                    // بارگیری مجدد موارد از دیتابیس
                    loadDisciplineItems();
                    
                    showNotification(data.message, 'success');
                } else {
                    showNotification('خطا: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error deleting discipline item:', error);
                showNotification('خطا در حذف مورد انضباطی', 'error');
            });
        }

        // نمایش موارد پیش‌فرض در صورت خطا
        function renderDefaultItems() {
            const container = document.getElementById('disciplineItems');
            if (!container) return;
            
            const defaultItems = [
                { title: 'تأخیر در حضور', score: 5 },
                { title: 'عدم انجام تکلیف', score: 10 },
                { title: 'مزاحمت در کلاس', score: 15 },
                { title: 'فراموشی لوازم درسی', score: 3 }
            ];
            
            container.innerHTML = '';
            
            defaultItems.forEach(item => {
                const disciplineElement = createDisciplineItemHTML(item.title, item.score, null, false);
                container.appendChild(disciplineElement);
            });
        }

        // جستجوی دانش‌آموزان
        function searchStudents(query) {
            const cards = document.querySelectorAll('#disciplineStudentGrid .student-card');
            cards.forEach(card => {
                const name = card.dataset.studentName.toLowerCase();
                card.style.display = name.includes(query.toLowerCase()) ? 'block' : 'none';
            });
        }

        // انتخاب/لغو انتخاب دانش‌آموز
        function toggleStudentSelection(element, id, name, nationalId) {
            element.classList.toggle('selected');
            const indicator = element.querySelector('.selection-indicator .check-mark');
            if (indicator) {
                indicator.style.opacity = element.classList.contains('selected') ? '1' : '0';
            }
            
            const index = selectedStudents.findIndex(s => s.id === id);
            if (index === -1) {
                selectedStudents.push({id, name, nationalId});
            } else {
                selectedStudents.splice(index, 1);
            }
            
            updateStudentsCounter();
            updateSummary();
            checkSubmitButton();
        }

        // انتخاب/لغو انتخاب مورد انضباطی
        function toggleDisciplineSelection(element, title, score) {
            element.classList.toggle('selected');
            const indicator = element.querySelector('.selection-indicator .check-mark');
            if (indicator) {
                indicator.style.opacity = element.classList.contains('selected') ? '1' : '0';
            }
            
            const index = selectedDisciplines.findIndex(d => d.title === title);
            if (index === -1) {
                selectedDisciplines.push({title, score});
            } else {
                selectedDisciplines.splice(index, 1);
            }
            
            updateDisciplinesCounter();
            updateSummary();
            checkSubmitButton();
        }

        // بروزرسانی شمارنده دانش‌آموزان
        function updateStudentsCounter() {
            document.getElementById('studentsCount').textContent = selectedStudents.length;
        }

        // بروزرسانی شمارنده موارد انضباطی
        function updateDisciplinesCounter() {
            document.getElementById('disciplinesCount').textContent = selectedDisciplines.length;
        }

        // بروزرسانی خلاصه
        function updateSummary() {
            const summarySection = document.getElementById('summarySection');
            
            if (selectedStudents.length > 0 && selectedDisciplines.length > 0) {
                summarySection.style.display = 'block';
                
                // لیست دانش‌آموزان
                const studentsList = document.getElementById('selectedStudentsList');
                studentsList.innerHTML = selectedStudents.map(s => 
                    `<li>👤 ${s.name} (${s.nationalId})</li>`
                ).join('');
                
                // لیست موارد انضباطی
                const disciplinesList = document.getElementById('selectedDisciplinesList');
                disciplinesList.innerHTML = selectedDisciplines.map(d => 
                    `<li>⚠️ ${d.title} (-${d.score} امتیاز)</li>`
                ).join('');
            } else {
                summarySection.style.display = 'none';
            }
        }

        // بررسی وضعیت دکمه ثبت
        function checkSubmitButton() {
            const btn = document.getElementById('submitBtn');
            const dateInput = document.getElementById('disciplineDate');
            
            const hasStudents = selectedStudents.length > 0;
            const hasDisciplines = selectedDisciplines.length > 0;
            const hasDate = dateInput && dateInput.value.trim() !== '';
            
            const shouldEnable = hasStudents && hasDisciplines && hasDate;
            
            if (btn) {
                btn.disabled = !shouldEnable;
                btn.style.opacity = shouldEnable ? '1' : '0.5';
                btn.style.cursor = shouldEnable ? 'pointer' : 'not-allowed';
                btn.style.background = shouldEnable ? 
                    'linear-gradient(135deg, #dc3545, #c82333)' : 
                    'linear-gradient(135deg, #6c757d, #5a6268)';
            }
        }

       
        // ایجاد element مورد انضباطی
        function createDisciplineItemElement(title, score, isDeletable = false) {
            const newItem = document.createElement('div');
            newItem.className = 'discipline-item';
            newItem.dataset.title = title;
            newItem.dataset.score = score;
            newItem.dataset.deletable = isDeletable;
            newItem.onclick = (e) => {
                // اگر روی دکمه حذف کلیک نشده، انتخاب/لغو انتخاب کن
                if (!e.target.closest('.delete-temp-item')) {
                    toggleDisciplineSelection(newItem, title, score);
                }
            };
            
            // دکمه حذف برای آیتم‌های موقت
            const deleteButton = isDeletable ? `
                <button class="delete-temp-item" onclick="deleteTempDisciplineItem(this)" 
                        style="position: absolute; top: 5px; left: 5px; background: rgba(220,53,69,0.9); color: white; border: none; border-radius: 50%; width: 25px; height: 25px; cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center; z-index: 10;"
                        title="حذف این مورد موقت">
                    ×
                </button>
            ` : '';
            
            newItem.innerHTML = `
                ${deleteButton}
                
                <div class="selection-indicator" style="position: absolute; top: 15px; right: 15px; width: 25px; height: 25px; border-radius: 50%; border: 2px solid #ccc; background: white; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                    <span class="check-mark" style="color: #28a745; font-size: 16px; opacity: 0; transition: opacity 0.3s ease;">✓</span>
                </div>
                
                <div style="font-size: 2.5rem; margin-bottom: 15px;">⚠️</div>
                <div style="font-weight: 700; font-size: 1.2rem; margin-bottom: 8px; color: #721c24;">${title}</div>
                <div style="font-size: 0.95rem; color: #856404; font-weight: 600; background: rgba(255,255,255,0.8); padding: 8px 15px; border-radius: 20px; display: inline-block;">
                    نمره منفی: -${score} امتیاز ${isDeletable ? '(موقت)' : ''}
                </div>
            `;
            
            return newItem;
        }

        // حذف آیتم موقت
        function deleteTempDisciplineItem(button) {
            const item = button.closest('.discipline-item');
            const title = item.dataset.title;
            
            if (confirm(`آیا می‌خواهید مورد "${title}" را حذف کنید؟`)) {
                // اگر این آیتم انتخاب شده بود، از لیست انتخاب‌ها حذفش کن
                const index = selectedDisciplines.findIndex(d => d.title === title);
                if (index !== -1) {
                    selectedDisciplines.splice(index, 1);
                    updateDisciplinesCounter();
                    updateSummary();
                    checkSubmitButton();
                }
                
                // حذف از DOM
                item.remove();
                showNotification('مورد انضباطی موقت حذف شد', 'info');
            }
        }

        // باز کردن تقویم شمسی
        function openPersianDatePicker() {
            const dateInput = document.getElementById('disciplineDate');
            $('#disciplineDate').persianDatepicker('show');
        }

        // ثبت موارد انضباطی
        function submitDisciplineRecord() {
            if (selectedStudents.length === 0) {
                showNotification('لطفاً حداقل یک دانش‌آموز انتخاب کنید', 'error');
                return;
            }
            
            if (selectedDisciplines.length === 0) {
                showNotification('لطفاً حداقل یک مورد انضباطی انتخاب کنید', 'error');
                return;
            }
            
            const dateValue = document.getElementById('disciplineDate').value.trim();
            if (!dateValue) {
                showNotification('لطفاً تاریخ وقوع را انتخاب کنید', 'error');
                return;
            }
            
            const description = document.getElementById('disciplineDescription').value.trim();
            
            const payload = {
                students: selectedStudents,
                disciplines: selectedDisciplines,
                date: dateValue,
                description: description || 'بدون توضیحات اضافی'
            };
            
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '⏳ در حال ثبت...';
            submitBtn.disabled = true;
            
            fetch('../ajax/submit_discipline.php', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(payload)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(`موارد انضباطی با موفقیت ثبت شد! ${selectedStudents.length} دانش‌آموز، ${selectedDisciplines.length} مورد انضباطی`, 'success');
                    resetForm();
                } else {
                    showNotification('خطا در ثبت: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('خطای اتصال: ' + error.message, 'error');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                checkSubmitButton();
            });
        }

        // ریست کردن فرم
        function resetForm() {
            selectedStudents = [];
            selectedDisciplines = [];
            
            document.querySelectorAll('.student-card.selected').forEach(card => {
                card.classList.remove('selected');
                card.querySelector('.check-mark').style.opacity = 0;
            });
            
            document.querySelectorAll('.discipline-item.selected').forEach(item => {
                item.classList.remove('selected');
                item.querySelector('.check-mark').style.opacity = 0;
            });
            
            document.getElementById('disciplineDate').value = '';
            document.getElementById('disciplineDescription').value = '';
            
            updateStudentsCounter();
            updateDisciplinesCounter();
            updateSummary();
            checkSubmitButton();
        }

        // تغییر تب
        function showDisciplineTab(tabName) {
            document.querySelectorAll('.discipline-tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.querySelectorAll('.discipline-tab-content').forEach(content => {
                content.style.display = 'none';
                content.classList.remove('active');
            });
            
            const targetTab = document.getElementById(`discipline-${tabName}`);
            const targetBtn = document.querySelector(`[data-tab="${tabName}"]`);
            
            if (targetTab && targetBtn) {
                targetTab.style.display = 'block';
                targetTab.classList.add('active');
                targetBtn.classList.add('active');
                
                // اگر تب تاریخچه است، داده‌ها را بارگیری کن
                if (tabName === 'history') {
                    setTimeout(() => {
                        loadDisciplineHistory();
                    }, 100);
                }
            }
        }

        // بارگیری تاریخچه موارد انضباطی
        function loadDisciplineHistory() {
            console.log('Loading discipline history...');
            showHistoryLoading();
            
            // پارامترهای فیلتر
            const params = new URLSearchParams({
                action: 'get_history',
                page: currentPage,
                limit: 20,
                student: document.getElementById('filterStudent')?.value || '',
                discipline_type: document.getElementById('filterDisciplineType')?.value || '',
                from_date: document.getElementById('filterFromDate')?.value || '',
                to_date: document.getElementById('filterToDate')?.value || ''
            });
            
            fetch(`../ajax/get-discipline-history.php?${params}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    disciplineHistory = data.history || [];
                    totalPages = data.pagination?.total_pages || 1;
                    
                    console.log(`Loaded ${disciplineHistory.length} discipline records`);
                    
                    updateHistoryStats(data.stats || {});
                    displayDisciplineHistory();
                    updatePagination(data.pagination || {});
                    loadFilterOptions();
                    
                    showNotification(`${disciplineHistory.length} رکورد بارگیری شد`, 'success');
                } else {
                    throw new Error(data.message || 'Server error');
                }
            })
            .catch(error => {
                console.error('Error loading history:', error);
                showSampleData();
                showNotification('خطا در بارگیری تاریخچه: ' + error.message, 'error');
            });
        }

        // نمایش loading در تاریخچه
        function showHistoryLoading() {
            const tbody = document.getElementById('disciplineHistoryTableBody');
            if (tbody) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 3rem; color: #6c757d;">
                            <div class="loading-spinner" style="margin: 0 auto 1rem;"></div>
                            <div>در حال بارگیری تاریخچه...</div>
                        </td>
                    </tr>
                `;
            }
        }

        // بروزرسانی آمار تاریخچه
        function updateHistoryStats(stats) {
            const elements = [
                { id: 'totalRecords', value: stats.total_records || 0 },
                { id: 'violatedStudents', value: stats.violated_students || 0 },
                { id: 'thisWeekRecords', value: stats.this_week_records || 0 },
                { id: 'totalScore', value: stats.total_score || 0 }
            ];
            
            elements.forEach(({ id, value }) => {
                const element = document.getElementById(id);
                if (element) {
                    animateNumber(element, 0, value, 1000);
                }
            });
        }

        // انیمیشن شمارش عدد
        function animateNumber(element, start, end, duration) {
            const startTime = performance.now();
            
            function update(currentTime) {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                const current = Math.floor(start + (end - start) * progress);
                element.textContent = current.toLocaleString('fa-IR');
                
                if (progress < 1) {
                    requestAnimationFrame(update);
                }
            }
            
            requestAnimationFrame(update);
        }

        // نمایش تاریخچه در جدول و کارت
        function displayDisciplineHistory() {
            const tbody = document.getElementById('disciplineHistoryTableBody');
            const cardsContainer = document.getElementById('disciplineCards');
            
            if (!tbody || !cardsContainer) return;
            
            tbody.innerHTML = '';
            cardsContainer.innerHTML = '';
            
            if (disciplineHistory.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 3rem; color: #6c757d;">
                            <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                            <br>هیچ رکوردی یافت نشد
                        </td>
                    </tr>
                `;
                return;
            }
            
            // نمایش جدولی (دسکتاپ)
            disciplineHistory.forEach((record, index) => {
                const row = document.createElement('tr');
                row.style.color = '#000';
                row.innerHTML = `
                    <td style="color: #000; font-weight: 600;">${(currentPage - 1) * 20 + index + 1}</td>
                    <td style="color: #000; font-weight: 500;">
                        ${record.student_name}
                        <br><small style="color: #666; font-size: 0.85em;">
                            کد ملی: ${record.student_national_id || 'نامشخص'}
                        </small>
                    </td>
                    <td style="color: #000; font-weight: 500;">${record.discipline_title}</td>
                    <td style="color: #dc3545; font-weight: bold; font-size: 1.1em;">-${record.negative_score}</td>
                    <td style="color: #000; font-weight: 500;">${record.persian_date}</td>
                    <td style="color: #000; max-width: 200px; word-wrap: break-word;">
                        ${record.description || '-'}
                    </td>
                    <td style="color: #000; font-weight: 500;">${record.created_by}</td>
                    <td style="padding: 8px;">
                        <button onclick="editRecord(${record.id})" 
                                style="background: linear-gradient(135deg, #ffc107, #e0a800); 
                                       color: #000; 
                                       border: none; 
                                       padding: 6px 12px; 
                                       border-radius: 6px; 
                                       cursor: pointer; 
                                       margin: 2px; 
                                       font-size: 0.85rem;
                                       font-weight: 600;
                                       transition: all 0.3s ease;"
                                title="ویرایش مورد انضباطی">
                            📝
                        </button>
                        <button onclick="deleteRecord(${record.id})" 
                                style="background: linear-gradient(135deg, #dc3545, #c82333); 
                                       color: white; 
                                       border: none; 
                                       padding: 6px 12px; 
                                       border-radius: 6px; 
                                       cursor: pointer; 
                                       margin: 2px; 
                                       font-size: 0.85rem;
                                       font-weight: 600;
                                       transition: all 0.3s ease;"
                                title="حذف مورد انضباطی">
                            🗑️
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // نمایش کارتی (موبایل)
            disciplineHistory.forEach(record => {
                const card = document.createElement('div');
                card.className = 'discipline-card';
                card.innerHTML = `
                    <div class="discipline-card-header">
                        <div>
                            <h4 style="margin: 0; color: #000; font-weight: 700;">${record.student_name}</h4>
                            <small style="color: #666;">کد ملی: ${record.student_national_id || 'نامشخص'}</small>
                        </div>
                        <span style="color: #dc3545; font-weight: bold; background: rgba(220,53,69,0.1); padding: 8px 12px; border-radius: 12px; font-size: 1.1em;">
                            -${record.negative_score} امتیاز
                        </span>
                    </div>
                    <div style="margin-bottom: 8px; color: #000;"><strong>کلاس:</strong> ${record.student_class || 'نامشخص'}</div>
                    <div style="margin-bottom: 8px; color: #000;"><strong>مورد:</strong> ${record.discipline_title}</div>
                    <div style="margin-bottom: 8px; color: #000;"><strong>تاریخ:</strong> ${record.persian_date}</div>
                    <div style="margin-bottom: 8px; color: #000;"><strong>توضیحات:</strong> ${record.description || '-'}</div>
                    <div style="margin-bottom: 15px; color: #000;"><strong>ثبت کننده:</strong> ${record.created_by}</div>
                    <div class="discipline-card-actions">
                        <button onclick="editRecord(${record.id})" 
                                style="background: linear-gradient(135deg, #ffc107, #e0a800); 
                                       color: #000; 
                                       border: none; 
                                       padding: 10px 20px; 
                                       border-radius: 20px; 
                                       cursor: pointer; 
                                       font-weight: 600;
                                       transition: all 0.3s ease;">
                            📝 ویرایش
                        </button>
                        <button onclick="deleteRecord(${record.id})" 
                                style="background: linear-gradient(135deg, #dc3545, #c82333); 
                                       color: white; 
                                       border: none; 
                                       padding: 10px 20px; 
                                       border-radius: 20px; 
                                       cursor: pointer; 
                                       font-weight: 600;
                                       transition: all 0.3s ease;">
                            🗑️ حذف
                        </button>
                    </div>
                `;
                cardsContainer.appendChild(card);
            });
        }

        // بروزرسانی صفحه‌بندی
        function updatePagination(paginationData) {
            const container = document.getElementById('paginationContainer');
            if (!container || !paginationData.total_pages) return;
            
            container.innerHTML = '';
            
            const { current_page, total_pages, total_records } = paginationData;
            
            if (total_pages <= 1) return;
            
            // اطلاعات صفحه‌بندی
            const info = document.createElement('div');
            info.style.cssText = 'margin-bottom: 15px; color: #6c757d; text-align: center;';
            info.textContent = `صفحه ${current_page} از ${total_pages} (مجموع ${total_records} رکورد)`;
            container.appendChild(info);
            
            // دکمه‌های ناوبری
            const buttonsContainer = document.createElement('div');
            buttonsContainer.style.cssText = 'display: flex; justify-content: center; gap: 8px; flex-wrap: wrap;';
            
            // دکمه صفحه اول
            if (current_page > 1) {
                buttonsContainer.appendChild(createPaginationButton('««', 1));
                buttonsContainer.appendChild(createPaginationButton('‹', current_page - 1));
            }
            
            // شماره صفحات
            const startPage = Math.max(1, current_page - 2);
            const endPage = Math.min(total_pages, current_page + 2);
            
            for (let i = startPage; i <= endPage; i++) {
                buttonsContainer.appendChild(createPaginationButton(i, i, i === current_page));
            }
            
            // دکمه صفحه آخر
            if (current_page < total_pages) {
                buttonsContainer.appendChild(createPaginationButton('›', current_page + 1));
                buttonsContainer.appendChild(createPaginationButton('»»', total_pages));
            }
            
            container.appendChild(buttonsContainer);
        }

        // ایجاد دکمه صفحه‌بندی
        function createPaginationButton(text, page, isActive = false) {
            const button = document.createElement('button');
            button.className = `pagination-btn ${isActive ? 'active' : ''}`;
            button.textContent = text;
            button.onclick = () => {
                if (page !== currentPage) {
                    currentPage = page;
                    loadDisciplineHistory();
                }
            };
            
            return button;
        }

        // بارگیری گزینه‌های فیلتر
        function loadFilterOptions() {
            fetch('../ajax/get-discipline-history.php?action=get_filters', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    populateFilterDropdowns(data.students, data.disciplines);
                }
            })
            .catch(error => {
                console.error('Error loading filter options:', error);
            });
        }

        // پر کردن dropdown های فیلتر
        function populateFilterDropdowns(students, disciplines) {
            // فیلتر دانش‌آموزان
            const studentSelect = document.getElementById('filterStudent');
            if (studentSelect) {
                studentSelect.innerHTML = '<option value="">همه دانش‌آموزان</option>';
                students.forEach(student => {
                    const option = document.createElement('option');
                    option.value = student;
                    option.textContent = student;
                    studentSelect.appendChild(option);
                });
            }

            // فیلتر موارد انضباطی
            const disciplineSelect = document.getElementById('filterDisciplineType');
            if (disciplineSelect) {
                disciplineSelect.innerHTML = '<option value="">همه موارد</option>';
                disciplines.forEach(discipline => {
                    const option = document.createElement('option');
                    option.value = discipline;
                    option.textContent = discipline;
                    disciplineSelect.appendChild(option);
                });
            }
        }

        // اعمال فیلترها
        function applyFilters() {
            currentPage = 1;
            loadDisciplineHistory();
            console.log('Filters applied');
        }

        // پاک کردن فیلترها
        function clearFilters() {
            const filterElements = [
                'filterStudent',
                'filterDisciplineType', 
                'filterFromDate',
                'filterToDate'
            ];
            
            filterElements.forEach(id => {
                const element = document.getElementById(id);
                if (element) element.value = '';
            });
            
            currentPage = 1;
            loadDisciplineHistory();
            showNotification('فیلترها پاک شد', 'info');
        }

        // ویرایش رکورد
        function editRecord(recordId) {
            const record = disciplineHistory.find(r => r.id === recordId);
            if (!record) {
                showNotification('رکورد یافت نشد', 'error');
                return;
            }
            
            // پر کردن مودال ویرایش
            const modal = document.getElementById('editModal');
            
            if (modal) {
                document.getElementById('editRecordId').value = record.id;
                document.getElementById('editTitle').value = record.discipline_title;
                document.getElementById('editScore').value = record.negative_score;
                document.getElementById('editDate').value = record.persian_date;
                document.getElementById('editDescription').value = record.description || '';
                
                modal.style.display = 'block';
            }
        }

        // ذخیره ویرایش
        function saveEdit() {
            const formData = {
                id: parseInt(document.getElementById('editRecordId').value),
                title: document.getElementById('editTitle').value.trim(),
                score: parseInt(document.getElementById('editScore').value),
                date: document.getElementById('editDate').value.trim(),
                description: document.getElementById('editDescription').value.trim()
            };
            
            // اعتبارسنجی
            if (!formData.title) {
                showNotification('عنوان نمی‌تواند خالی باشد', 'error');
                return;
            }
            
            if (!formData.score || formData.score < 1 || formData.score > 100) {
                showNotification('امتیاز باید بین 1 تا 100 باشد', 'error');
                return;
            }
            
            if (!formData.date) {
                showNotification('تاریخ نمی‌تواند خالی باشد', 'error');
                return;
            }
            
            fetch('../ajax/get-discipline-history.php?action=edit_record', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showNotification('رکورد با موفقیت ویرایش شد', 'success');
                    loadDisciplineHistory(); // بارگیری مجدد
                    closeEditModal();
                } else {
                    showNotification('خطا در ویرایش: ' + result.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error updating record:', error);
                showNotification('خطای اتصال در ویرایش', 'error');
            });
        }

        // بستن مودال ویرایش
        function closeEditModal() {
            const modal = document.getElementById('editModal');
            if (modal) {
                modal.style.display = 'none';
            }
        }

        // حذف رکورد
        function deleteRecord(recordId) {
            const record = disciplineHistory.find(r => r.id === recordId);
            if (!record) {
                showNotification('رکورد یافت نشد', 'error');
                return;
            }
            
            const confirmMessage = `آیا مطمئن هستید که می‌خواهید این مورد را حذف کنید؟

👤 دانش‌آموز: ${record.student_name}
⚠️ مورد: ${record.discipline_title}
💯 امتیاز: -${record.negative_score}

امتیاز منفی نیز بازگردانده خواهد شد.`;
            
            if (!confirm(confirmMessage)) {
                return;
            }
            
            fetch('../ajax/get-discipline-history.php?action=delete_record', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ id: recordId })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showNotification('رکورد با موفقیت حذف شد', 'success');
                    loadDisciplineHistory(); // بارگیری مجدد
                } else {
                    showNotification('خطا در حذف: ' + result.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error deleting record:', error);
                showNotification('خطای اتصال در حذف', 'error');
            });
        }

        // خروجی اکسل
        function exportToExcel() {
            const params = new URLSearchParams({
                action: 'export_excel',
                student: document.getElementById('filterStudent')?.value || '',
                discipline_type: document.getElementById('filterDisciplineType')?.value || '',
                from_date: document.getElementById('filterFromDate')?.value || '',
                to_date: document.getElementById('filterToDate')?.value || ''
            });
            
            fetch(`../ajax/get-discipline-history.php?${params}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const csvContent = convertToCSV(data.data);
                    downloadCSV(csvContent, data.filename || 'discipline_records.csv');
                    showNotification('فایل اکسل آماده شد', 'success');
                } else {
                    showNotification('خطا در تولید فایل اکسل', 'error');
                }
            })
            .catch(error => {
                console.error('Error exporting to Excel:', error);
                showNotification('خطا در خروجی اکسل', 'error');
            });
        }

        // تبدیل به CSV
        function convertToCSV(data) {
            if (!data || data.length === 0) return '';
            
            const headers = Object.keys(data[0]);
            const csvHeaders = headers.join(',');
            
            const csvRows = data.map(row => 
                headers.map(header => {
                    const value = row[header] || '';
                    return `"${String(value).replace(/"/g, '""')}"`;
                }).join(',')
            );
            
            return [csvHeaders, ...csvRows].join('\n');
        }

        // دانلود فایل CSV
        function downloadCSV(csvContent, filename) {
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            
            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

        // چاپ گزارش
        function printReport() {
            if (disciplineHistory.length === 0) {
                showNotification('هیچ رکوردی برای چاپ وجود ندارد', 'warning');
                return;
            }
            
            const printWindow = window.open('', '_blank');
            const printContent = generatePrintHTML();
            
            printWindow.document.write(printContent);
            printWindow.document.close();
            
            printWindow.onload = function() {
                printWindow.print();
            };
            
            showNotification('صفحه چاپ باز شد', 'info');
        }

        // تولید HTML برای چاپ
        function generatePrintHTML() {
            const stats = {
                total_records: disciplineHistory.length,
                violated_students: new Set(disciplineHistory.map(r => r.student_name)).size,
                total_score: disciplineHistory.reduce((sum, r) => sum + r.negative_score, 0)
            };
            
            return `
                <html>
                <head>
                    <title>گزارش موارد انضباطی</title>
                    <meta charset="UTF-8">
                    <style>
                        body { 
                            font-family: 'Tahoma', Arial, sans-serif; 
                            direction: rtl; 
                            margin: 20px; 
                            line-height: 1.6;
                        }
                        .header { 
                            text-align: center; 
                            margin-bottom: 30px; 
                            border-bottom: 2px solid #333; 
                            padding-bottom: 20px; 
                        }
                        table { 
                            width: 100%; 
                            border-collapse: collapse; 
                            margin-top: 20px; 
                            font-size: 12px;
                        }
                        th, td { 
                            border: 1px solid #ddd; 
                            padding: 8px; 
                            text-align: center; 
                        }
                        th { 
                            background-color: #f2f2f2; 
                            font-weight: bold; 
                        }
                        .negative-score { 
                            color: #dc3545; 
                            font-weight: bold; 
                        }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>گزارش موارد انضباطی</h1>
                        <p>تاریخ چاپ: ${new Date().toLocaleDateString('fa-IR')}</p>
                    </div>
                    
                    <table>
                        <thead>
                            <tr>
                                <th>ردیف</th>
                                <th>دانش‌آموز</th>
                                <th>مورد انضباطی</th>
                                <th>امتیاز منفی</th>
                                <th>تاریخ</th>
                                <th>توضیحات</th>
                                <th>ثبت کننده</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${disciplineHistory.map((record, index) => `
                                <tr>
                                    <td>${index + 1}</td>
                                    <td>${record.student_name}</td>
                                    <td>${record.discipline_title}</td>
                                    <td class="negative-score">-${record.negative_score}</td>
                                    <td>${record.persian_date}</td>
                                    <td>${record.description || '-'}</td>
                                    <td>${record.created_by}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </body>
                </html>
            `;
        }

        // نمایش داده‌های نمونه در صورت خطا
        function showSampleData() {
            disciplineHistory = [
                {
                    id: 1,
                    student_name: 'احمد محمدی',
                    student_national_id: '1234567890',
                    student_class: 'یازدهم الف',
                    discipline_title: 'تأخیر در حضور',
                    negative_score: 5,
                    persian_date: '1403/06/15',
                    description: 'تأخیر 15 دقیقه‌ای',
                    created_by: 'آقای احمدی'
                }
            ];
            
            const stats = {
                total_records: 1,
                violated_students: 1,
                this_week_records: 1,
                total_score: 5
            };
            
            updateHistoryStats(stats);
            displayDisciplineHistory();
        }

        // نمایش اعلان
        function showNotification(message, type = 'info') {
            const existing = document.querySelector('.discipline-notification');
            if (existing) existing.remove();
            
            const notification = document.createElement('div');
            notification.className = `discipline-notification ${type}`;
            
            const icons = {
                success: '✅',
                error: '❌',
                info: 'ℹ️',
                warning: '⚠️'
            };
            
            notification.innerHTML = `${icons[type] || 'ℹ️'} ${message}`;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 4000);
        }
    </script>
</body>
</html>