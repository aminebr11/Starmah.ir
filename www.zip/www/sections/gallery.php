<?php
// gallery.php - نسخه حرفه‌ای و کودک‌پسند (بدون خطا)
if (!isLoggedIn()) { exit(); }
$userIsAdmin = isAdmin();

$items = getGalleryItems($conn);

$CATEGORIES = [
  'all'          => ['label' => 'همه موارد', 'icon' => '🌈', 'color' => '#667eea'],
  'artwork'      => ['label' => 'نقاشی و هنر', 'icon' => '🎨', 'color' => '#f093fb'],
  'activities'   => ['label' => 'فعالیت‌های کلاسی', 'icon' => '✏️', 'color' => '#4facfe'],
  'events'       => ['label' => 'مناسبت‌ها', 'icon' => '🎉', 'color' => '#43e97b'],
  'nature'       => ['label' => 'طبیعت و علوم', 'icon' => '🌱', 'color' => '#0be881'],
  'crafts'       => ['label' => 'کاردستی', 'icon' => '✂️', 'color' => '#ff6348'],
  'other'        => ['label' => 'سایر', 'icon' => '📁', 'color' => '#95afc0']
];

// تابع تبدیل تاریخ میلادی به شمسی
function toJalali($date) {
  if (!$date) return 'نامشخص';
  
  $timestamp = strtotime($date);
  if (!$timestamp) return 'نامشخص';
  
  $gy = (int)date('Y', $timestamp);
  $gm = (int)date('n', $timestamp);
  $gd = (int)date('j', $timestamp);
  
  $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
  $days = 355666 + (365 * $gy) + (int)(($gy2 + 3) / 4) - (int)(($gy2 + 99) / 100) + (int)(($gy2 + 399) / 400) + $gd + $g_d_m[$gm - 1];
  $jy = -1595 + (33 * (int)($days / 12053));
  $days %= 12053;
  $jy += 4 * (int)($days / 1461);
  $days %= 1461;
  if ($days > 365) {
    $jy += (int)(($days - 1) / 365);
    $days = ($days - 1) % 365;
  }
  if ($days < 186) {
    $jm = 1 + (int)($days / 31);
    $jd = 1 + ($days % 31);
  } else {
    $jm = 7 + (int)(($days - 186) / 30);
    $jd = 1 + (($days - 186) % 30);
  }
  
  return sprintf('%d/%02d/%02d', $jy, $jm, $jd);
}
?>
<section id="gallery" class="section" style="direction:rtl">
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;600;700;900&display=swap" rel="stylesheet">

  <style>
    :root{
      --primary:#667eea; --secondary:#f093fb;
      --success:#43e97b; --danger:#ee5a6f; --warning:#feca57;
      --bg-main:#f8f9fe; --bg-card:#ffffff;
      --text-dark:#1a1d29; --text-muted:#6c7993;
      --border:#e4e7f1; --shadow:0 8px 24px rgba(102,126,234,.12);
      --shadow-lg:0 20px 50px rgba(102,126,234,.2);
      --radius:20px; --radius-sm:12px;
    }

    * { box-sizing:border-box; }
    
    #gallery{
      font-family:"Vazirmatn",-apple-system,sans-serif;
      background:linear-gradient(135deg,#f8f9fe 0%,#e8eeff 100%);
      min-height:100vh;
      padding:1.5rem;
    }

    .gal-container{
      max-width:1400px;
      margin:0 auto;
      animation:fadeIn .5s ease;
    }

    @keyframes fadeIn{ from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    @keyframes fadeOut{ to{opacity:0;transform:scale(.8)} }
    @keyframes bounce{ 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
    @keyframes pulse{ 0%,100%{transform:scale(1)} 50%{transform:scale(1.05)} }

    /* ============ HEADER ============ */
    .gal-header{
      background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
      border-radius:var(--radius);
      padding:1rem 1.5rem;
      margin-bottom:1.5rem;
      box-shadow:var(--shadow-lg);
      color:#fff;
      position:relative;
      overflow:hidden;
    }
    .gal-header::before{
      content:'';
      position:absolute;
      top:-50%;
      right:-50%;
      width:200%;
      height:200%;
      background:radial-gradient(circle,rgba(255,255,255,.1) 0%,transparent 70%);
      animation:pulse 4s infinite;
    }
    .header-content{
      position:relative;
      z-index:1;
    }
    .header-top{
      display:flex;
      align-items:center;
      justify-content:space-between;
      flex-wrap:wrap;
      gap:.8rem;
    }
    .header-title{
      display:flex;
      align-items:center;
      gap:.6rem;
    }
    .header-icon{
      font-size:2rem;
      animation:bounce 2s infinite;
      filter:drop-shadow(0 4px 8px rgba(0,0,0,.2));
    }
    .title-text h1{
      font-size:1.4rem;
      font-weight:900;
      margin:0;
      text-shadow:2px 2px 8px rgba(0,0,0,.15);
    }
    .title-text p{
      margin:.2rem 0 0;
      opacity:.95;
      font-weight:300;
      font-size:.85rem;
    }
    .header-badge{
      background:rgba(255,255,255,.25);
      backdrop-filter:blur(10px);
      padding:.4rem 1rem;
      border-radius:999px;
      font-weight:700;
      border:2px solid rgba(255,255,255,.3);
      font-size:.85rem;
    }
    .header-actions{
      display:flex;
      gap:.5rem;
      align-items:center;
    }
    .header-btn{
      background:rgba(255,255,255,.25);
      backdrop-filter:blur(10px);
      padding:.4rem .8rem;
      border-radius:999px;
      font-weight:700;
      border:2px solid rgba(255,255,255,.3);
      cursor:pointer;
      color:#fff;
      display:flex;
      align-items:center;
      gap:.3rem;
      font-size:.85rem;
      transition:all .2s;
    }
    .header-btn:hover{
      background:rgba(255,255,255,.35);
      transform:translateY(-2px);
    }

    /* ============ FILTERS ============ */
    .filter-section{
      background:var(--bg-card);
      border-radius:var(--radius);
      padding:1.5rem;
      margin-bottom:2rem;
      box-shadow:var(--shadow);
    }
    .filter-header{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin-bottom:1rem;
      flex-wrap:wrap;
      gap:.5rem;
    }
    .filter-title{
      font-size:1rem;
      font-weight:700;
      color:var(--text-dark);
      display:flex;
      align-items:center;
      gap:.5rem;
    }
    .filter-grid{
      display:grid;
      grid-template-columns:repeat(auto-fill,minmax(140px,1fr));
      gap:.8rem;
    }
    .filter-btn{
      background:var(--bg-main);
      border:2px solid var(--border);
      border-radius:var(--radius-sm);
      padding:.8rem;
      cursor:pointer;
      transition:all .2s;
      text-align:center;
      font-weight:600;
      color:var(--text-dark);
    }
    .filter-btn .cat-icon{
      font-size:1.8rem;
      display:block;
      margin-bottom:.3rem;
    }
    .filter-btn:hover{
      transform:translateY(-3px);
      box-shadow:var(--shadow);
    }
    .filter-btn.active{
      border-width:3px;
      transform:translateY(-3px);
      box-shadow:var(--shadow-lg);
      font-weight:800;
    }

    /* ============ ADMIN PANEL ============ */
    .admin-panel{
      background:linear-gradient(135deg,#43e97b 0%,#38f9d7 100%);
      border-radius:var(--radius);
      padding:1.5rem;
      margin-bottom:2rem;
      box-shadow:var(--shadow-lg);
      color:#0b3d2e;
    }
    .admin-title{
      font-size:1.1rem;
      font-weight:900;
      margin-bottom:1rem;
      display:flex;
      align-items:center;
      gap:.5rem;
    }
    
    .upload-zone{
      background:rgba(255,255,255,.95);
      border:3px dashed #43e97b;
      border-radius:var(--radius-sm);
      padding:2rem;
      margin-bottom:1rem;
      text-align:center;
      cursor:pointer;
      transition:all .3s;
    }
    .upload-zone:hover{
      background:#fff;
      border-color:#38f9d7;
      transform:scale(1.02);
    }
    .upload-zone.dragover{
      background:#43e97b;
      border-color:#0b3d2e;
      color:#fff;
    }
    .upload-icon{
      font-size:3rem;
      margin-bottom:.5rem;
    }
    .upload-text{
      font-weight:700;
      margin-bottom:.3rem;
    }
    .upload-hint{
      font-size:.85rem;
      opacity:.8;
    }
    
    .upload-form-fields{
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
      gap:.8rem;
      margin-bottom:1rem;
    }
    .form-group label{
      display:block;
      font-weight:700;
      margin-bottom:.3rem;
      font-size:.9rem;
    }
    .form-control{
      width:100%;
      padding:.7rem;
      border:2px solid var(--border);
      border-radius:var(--radius-sm);
      font-family:inherit;
      font-size:.95rem;
      transition:all .2s;
    }
    .form-control:focus{
      outline:none;
      border-color:var(--primary);
      box-shadow:0 0 0 3px rgba(102,126,234,.1);
    }

    .preview-grid{
      display:grid;
      grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
      gap:.8rem;
      margin-top:1rem;
    }
    .preview-item{
      position:relative;
      border-radius:var(--radius-sm);
      overflow:hidden;
      background:var(--bg-main);
      border:2px solid var(--border);
    }
    .preview-img{
      width:100%;
      height:120px;
      object-fit:cover;
      display:block;
    }
    .preview-remove{
      position:absolute;
      top:.3rem;
      left:.3rem;
      background:#ee5a6f;
      color:#fff;
      border:none;
      width:28px;
      height:28px;
      border-radius:50%;
      cursor:pointer;
      font-size:1rem;
      display:flex;
      align-items:center;
      justify-content:center;
      box-shadow:var(--shadow);
      transition:all .2s;
    }
    .preview-remove:hover{
      transform:scale(1.1);
      background:#d63031;
    }
    .preview-progress{
      position:absolute;
      bottom:0;
      left:0;
      right:0;
      height:4px;
      background:rgba(0,0,0,.1);
    }
    .preview-progress-bar{
      height:100%;
      background:#43e97b;
      transition:width .3s;
    }

    .admin-actions{
      display:flex;
      gap:.8rem;
      flex-wrap:wrap;
    }
    .btn{
      border:none;
      border-radius:var(--radius-sm);
      padding:.8rem 1.5rem;
      font-weight:800;
      cursor:pointer;
      font-family:inherit;
      font-size:.95rem;
      transition:all .2s;
      display:inline-flex;
      align-items:center;
      gap:.5rem;
      box-shadow:var(--shadow);
    }
    .btn:hover:not(:disabled){
      transform:translateY(-2px);
      box-shadow:var(--shadow-lg);
    }
    .btn:disabled{
      opacity:.5;
      cursor:not-allowed;
      transform:none !important;
    }
    .btn-primary{
      background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
      color:#fff;
    }
    .btn-success{
      background:#43e97b;
      color:#0b3d2e;
    }
    .btn-danger{
      background:#ee5a6f;
      color:#fff;
    }
    .btn-secondary{
      background:var(--bg-main);
      color:var(--text-dark);
      border:2px solid var(--border);
    }

    /* ============ GALLERY GRID ============ */
    .gallery-grid{
      display:grid;
      grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
      gap:1.2rem;
      margin-bottom:2rem;
    }
    @media(min-width:768px){
      .gallery-grid{
        grid-template-columns:repeat(auto-fill,minmax(240px,1fr));
        gap:1.5rem;
      }
    }
    @media(min-width:1200px){
      .gallery-grid{
        grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
      }
    }

    .gallery-card{
      position:relative;
      background:var(--bg-card);
      border-radius:var(--radius);
      overflow:hidden;
      box-shadow:var(--shadow);
      transition:all .3s;
      cursor:pointer;
      animation:fadeIn .5s ease backwards;
    }
    .gallery-card:hover{
      transform:translateY(-8px);
      box-shadow:var(--shadow-lg);
    }
    
    .card-image-wrap{
      position:relative;
      width:100%;
      padding-top:100%;
      background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%);
      overflow:hidden;
    }
    .card-image{
      position:absolute;
      top:0;
      left:0;
      width:100%;
      height:100%;
      object-fit:cover;
      transition:transform .3s;
    }
    .gallery-card:hover .card-image{
      transform:scale(1.1);
    }
    
    .card-overlay{
      position:absolute;
      top:0;
      left:0;
      right:0;
      bottom:0;
      background:linear-gradient(to bottom,rgba(0,0,0,0) 0%,rgba(0,0,0,.7) 100%);
      opacity:0;
      transition:opacity .3s;
      display:flex;
      align-items:center;
      justify-content:center;
      gap:.5rem;
    }
    .gallery-card:hover .card-overlay{
      opacity:1;
    }
    .overlay-btn{
      background:rgba(255,255,255,.95);
      border:none;
      width:45px;
      height:45px;
      border-radius:50%;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:1.3rem;
      cursor:pointer;
      transition:all .2s;
      box-shadow:var(--shadow);
      text-decoration:none;
    }
    .overlay-btn:hover{
      transform:scale(1.15);
      background:#fff;
    }

    .card-category{
      position:absolute;
      top:.8rem;
      right:.8rem;
      padding:.4rem .8rem;
      border-radius:999px;
      font-size:.8rem;
      font-weight:700;
      color:#fff;
      display:flex;
      align-items:center;
      gap:.3rem;
      box-shadow:var(--shadow);
      backdrop-filter:blur(10px);
    }

    .card-select{
      position:absolute;
      top:.8rem;
      left:.8rem;
      background:rgba(255,255,255,.95);
      border:2px solid var(--border);
      border-radius:var(--radius-sm);
      padding:.4rem;
      display:flex;
      align-items:center;
      gap:.3rem;
      box-shadow:var(--shadow);
      cursor:pointer;
      transition:all .2s;
    }
    .card-select:hover{
      background:#fff;
      transform:scale(1.05);
    }
    .card-select input[type="checkbox"]{
      width:18px;
      height:18px;
      cursor:pointer;
    }

    .card-info{
      padding:1rem;
    }
    .card-title{
      font-weight:800;
      font-size:1rem;
      color:var(--text-dark);
      margin:0 0 .4rem;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    .card-desc{
      font-size:.85rem;
      color:var(--text-muted);
      line-height:1.4;
      max-height:2.8em;
      overflow:hidden;
      display:-webkit-box;
      -webkit-line-clamp:2;
      -webkit-box-orient:vertical;
    }
    .card-date{
      font-size:.75rem;
      color:var(--text-muted);
      margin-top:.5rem;
      display:flex;
      align-items:center;
      gap:.3rem;
    }

    .empty-state{
      grid-column:1/-1;
      text-align:center;
      padding:4rem 2rem;
      background:var(--bg-card);
      border-radius:var(--radius);
      border:3px dashed var(--border);
    }
    .empty-icon{
      font-size:5rem;
      margin-bottom:1rem;
      opacity:.5;
    }
    .empty-text{
      font-size:1.2rem;
      font-weight:700;
      color:var(--text-muted);
    }

    /* ============ MODAL (LIGHTBOX) ============ */
    .gallery-modal{
      position:fixed;
      inset:0;
      background:rgba(0,0,0,.92);
      z-index:99999;
      display:none;
      align-items:center;
      justify-content:center;
      padding:1rem;
      backdrop-filter:blur(10px);
    }
    .gallery-modal.show{
      display:flex;
      animation:fadeIn .3s ease;
    }
    .modal-content{
      background:#1a1d29;
      border-radius:var(--radius);
      max-width:1200px;
      width:100%;
      max-height:90vh;
      overflow:hidden;
      box-shadow:0 30px 80px rgba(0,0,0,.8);
      display:flex;
      flex-direction:column;
    }
    .modal-header{
      padding:1rem 1.5rem;
      border-bottom:1px solid rgba(255,255,255,.1);
      display:flex;
      align-items:center;
      justify-content:space-between;
      background:rgba(255,255,255,.03);
    }
    .modal-title{
      font-weight:900;
      color:#fff;
      font-size:1.2rem;
    }
    .modal-close{
      background:transparent;
      border:none;
      color:#fff;
      font-size:1.5rem;
      width:40px;
      height:40px;
      border-radius:50%;
      cursor:pointer;
      transition:all .2s;
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .modal-close:hover{
      background:rgba(255,255,255,.1);
      transform:rotate(90deg);
    }
    .modal-body{
      display:grid;
      grid-template-columns:1fr;
      gap:1.5rem;
      padding:1.5rem;
      overflow-y:auto;
    }
    @media(min-width:900px){
      .modal-body{
        grid-template-columns:2fr 1fr;
      }
    }
    .modal-image-wrap{
      background:#000;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      min-height:400px;
      overflow:hidden;
    }
    .modal-image{
      max-width:100%;
      max-height:70vh;
      border-radius:var(--radius-sm);
    }
    .modal-info{
      background:rgba(255,255,255,.05);
      border:1px solid rgba(255,255,255,.1);
      border-radius:var(--radius-sm);
      padding:1.5rem;
      color:#fff;
    }
    .modal-info p{
      margin:.5rem 0;
      line-height:1.6;
    }
    .modal-info strong{
      color:#feca57;
      font-weight:700;
    }
    .modal-actions{
      display:flex;
      gap:.8rem;
      flex-wrap:wrap;
      margin-top:1.5rem;
    }
    .modal-btn{
      flex:1;
      min-width:140px;
      padding:.8rem 1.2rem;
      border:none;
      border-radius:var(--radius-sm);
      font-weight:800;
      cursor:pointer;
      font-family:inherit;
      transition:all .2s;
      display:flex;
      align-items:center;
      justify-content:center;
      gap:.5rem;
      text-decoration:none;
    }
    .modal-btn:hover{
      transform:translateY(-2px);
    }
    .modal-btn-primary{
      background:#43e97b;
      color:#0b3d2e;
    }
    .modal-btn-secondary{
      background:rgba(255,255,255,.1);
      color:#fff;
      border:1px solid rgba(255,255,255,.2);
    }

    /* ============ PROGRESS BAR ============ */
    .upload-progress-container{
      background:var(--bg-card);
      border-radius:var(--radius-sm);
      padding:1rem;
      margin-top:1rem;
      box-shadow:var(--shadow);
      display:none;
    }
    .upload-progress-container.show{
      display:block;
    }
    .progress-title{
      font-weight:700;
      margin-bottom:.8rem;
      display:flex;
      align-items:center;
      gap:.5rem;
    }
    .progress-bar{
      height:8px;
      background:var(--bg-main);
      border-radius:999px;
      overflow:hidden;
      margin-bottom:.5rem;
    }
    .progress-fill{
      height:100%;
      background:linear-gradient(90deg,#43e97b 0%,#38f9d7 100%);
      border-radius:999px;
      transition:width .3s;
      box-shadow:0 2px 8px rgba(67,233,123,.4);
    }
    .progress-text{
      font-size:.85rem;
      color:var(--text-muted);
      text-align:center;
    }

    /* ============ NOTIFICATION ============ */
    .notification{
      position:fixed;
      top:2rem;
      right:2rem;
      background:#fff;
      border-radius:var(--radius-sm);
      padding:1rem 1.5rem;
      box-shadow:var(--shadow-lg);
      z-index:999999;
      display:flex;
      align-items:center;
      gap:.8rem;
      min-width:280px;
      animation:slideIn .3s ease;
      border-right:4px solid var(--success);
    }
    @keyframes slideIn{ from{transform:translateX(400px);opacity:0} to{transform:translateX(0);opacity:1} }
    .notification.error{
      border-right-color:var(--danger);
    }
    .notification-icon{
      font-size:1.5rem;
    }
    .notification-text{
      flex:1;
      font-weight:700;
      color:var(--text-dark);
    }

    /* ============ RESPONSIVE ============ */
    @media(max-width:768px){
      .gal-header{
        padding:1rem;
      }
      .header-icon{
        font-size:1.5rem;
      }
      .title-text h1{
        font-size:1.2rem;
      }
      .title-text p{
        font-size:.8rem;
      }
      .header-badge{
        font-size:.75rem;
        padding:.3rem .7rem;
      }
      .header-btn{
        font-size:.8rem;
        padding:.35rem .6rem;
      }
      .header-top{
        flex-direction:column;
        align-items:flex-start;
        gap:.6rem;
      }
      .header-actions{
        width:100%;
        flex-direction:column;
        align-items:stretch;
        gap:.5rem;
      }
      .header-actions .header-btn{
        width:100%;
        justify-content:center;
      }
      .filter-header{
        flex-direction:column;
        align-items:stretch;
      }
      .filter-header .btn{
        width:100%;
        justify-content:center;
      }
      .filter-grid{
        grid-template-columns:repeat(auto-fill,minmax(100px,1fr));
        gap:.6rem;
      }
      .filter-btn{
        padding:.6rem;
        font-size:.85rem;
      }
      .filter-btn .cat-icon{
        font-size:1.5rem;
      }
      .upload-form-fields{
        grid-template-columns:1fr;
      }
      .admin-actions{
        flex-direction:column;
      }
      .btn{
        width:100%;
        justify-content:center;
      }
      .modal-content{
        max-height:95vh;
      }
      .modal-actions{
        flex-direction:column;
      }
      .modal-btn{
        width:100%;
      }
    }
  </style>

  <div class="gal-container">
    <!-- Header -->
    <div class="gal-header">
      <div class="header-content">
        <div class="header-top">
          <div class="header-title">
            <div class="header-icon">🎨</div>
            <div class="title-text">
              <h1>گالری شاد کلاس ما</h1>
              <p>مجموعه خاطرات زیبای دانش‌آموزان عزیز ✨</p>
            </div>
          </div>
          <?php if ($userIsAdmin): ?>
            <div class="header-actions">
              <div class="header-badge">👨‍💼 پنل مدیریت</div>
              <button onclick="document.getElementById('uploadForm').scrollIntoView({behavior:'smooth'})" class="header-btn">
                <span>➕</span>
                <span>افزودن</span>
              </button>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="filter-section">
      <div class="filter-header">
        <div class="filter-title">🔍 جستجو در دسته‌بندی‌ها</div>
        <?php if ($userIsAdmin): ?>
          <button onclick="document.getElementById('uploadForm').scrollIntoView({behavior:'smooth'})" 
                  class="btn btn-primary" 
                  style="padding:.5rem 1rem;font-size:.85rem">
            <span>➕</span>
            <span>افزودن تصویر جدید</span>
          </button>
        <?php endif; ?>
      </div>
      <div class="filter-grid" id="filterGrid">
        <?php foreach ($CATEGORIES as $key => $cat): ?>
          <button class="filter-btn<?php echo $key==='all'?' active':''; ?>" 
                  data-cat="<?php echo $key; ?>"
                  style="border-color:<?php echo $cat['color']; ?>">
            <span class="cat-icon"><?php echo $cat['icon']; ?></span>
            <div><?php echo $cat['label']; ?></div>
          </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Gallery Grid -->
    <div class="gallery-grid" id="galleryGrid">
      <?php if (!empty($items)):
        foreach ($items as $index => $item):
          $id = (int)$item['id'];
          $cat = htmlspecialchars($item['category'] ?? 'other');
          $title = htmlspecialchars($item['title'] ?? 'بدون عنوان');
          $desc = htmlspecialchars($item['description'] ?? '');
          $src = htmlspecialchars($item['file_path'] ?? '');
          $date = $item['created_at'] ?? '';
          $exists = $src && file_exists($item['file_path']);
          $catInfo = $CATEGORIES[$cat] ?? $CATEGORIES['other'];
          $jalaliDate = toJalali($date);
      ?>
        <div class="gallery-card" 
             data-id="<?php echo $id; ?>" 
             data-cat="<?php echo $cat; ?>"
             style="animation-delay:<?php echo $index * 0.05; ?>s">
          
          <div class="card-image-wrap">
            <?php if ($exists): ?>
              <img src="<?php echo $src; ?>" alt="<?php echo $title; ?>" class="card-image" loading="lazy">
            <?php else: ?>
              <img src="assets/img/placeholder.jpg" alt="Placeholder" class="card-image" loading="lazy">
            <?php endif; ?>
            
            <div class="card-overlay">
              <button class="overlay-btn view-btn" title="بزرگنمایی">🔍</button>
              <a href="<?php echo $exists ? $src : '#'; ?>" 
                 download 
                 class="overlay-btn" 
                 title="دانلود"
                 onclick="event.stopPropagation()">⬇️</a>
              <?php if ($userIsAdmin): ?>
                <button class="overlay-btn delete-btn" title="حذف">🗑️</button>
              <?php endif; ?>
            </div>
          </div>

          <div class="card-category" style="background:<?php echo $catInfo['color']; ?>">
            <span><?php echo $catInfo['icon']; ?></span>
            <span><?php echo $catInfo['label']; ?></span>
          </div>

          <?php if ($userIsAdmin): ?>
            <label class="card-select" onclick="event.stopPropagation()">
              <input type="checkbox" class="item-checkbox">
              <span style="font-size:.8rem">انتخاب</span>
            </label>
          <?php endif; ?>

          <div class="card-info">
            <h3 class="card-title"><?php echo $title; ?></h3>
            <?php if ($desc): ?>
              <p class="card-desc"><?php echo $desc; ?></p>
            <?php endif; ?>
            <div class="card-date">
              <span>📅</span>
              <span><?php echo $jalaliDate; ?></span>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php else: ?>
        <div class="empty-state">
          <div class="empty-icon">📭</div>
          <div class="empty-text">هنوز تصویری در گالری قرار نگرفته است</div>
        </div>
      <?php endif; ?>
    </div>

    <!-- Admin Panel - Upload Section -->
    <?php if ($userIsAdmin): ?>
      <div class="admin-panel" style="margin-top:2rem">
        <div class="admin-title">
          <span>📤</span>
          <span>افزودن تصاویر جدید</span>
        </div>

        <form id="uploadForm" enctype="multipart/form-data">
          <div class="upload-zone" id="uploadZone">
            <div class="upload-icon">📸</div>
            <div class="upload-text">کلیک کنید یا فایل‌ها را اینجا بکشید</div>
            <div class="upload-hint">می‌توانید چندین عکس همزمان انتخاب کنید</div>
            <input type="file" id="fileInput" multiple accept="image/*" style="display:none">
          </div>

          <div id="previewContainer" class="preview-grid" style="display:none"></div>

          <div class="upload-form-fields">
            <div class="form-group">
              <label>📝 عنوان پیش‌فرض</label>
              <input type="text" id="uploadTitle" class="form-control" placeholder="عنوان تصاویر">
            </div>
            <div class="form-group">
              <label>📂 دسته‌بندی</label>
              <select id="uploadCategory" class="form-control" required>
                <?php foreach ($CATEGORIES as $key => $cat):
                  if ($key === 'all') continue; ?>
                  <option value="<?php echo $key; ?>"><?php echo $cat['icon'].' '.$cat['label']; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>💬 توضیحات (اختیاری)</label>
              <input type="text" id="uploadDescription" class="form-control" placeholder="توضیح کوتاه">
            </div>
          </div>

          <div class="upload-progress-container" id="progressContainer">
            <div class="progress-title">
              <span>⏳</span>
              <span>در حال آپلود...</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" id="progressFill" style="width:0"></div>
            </div>
            <div class="progress-text" id="progressText">0%</div>
          </div>

          <div class="admin-actions">
            <button type="submit" class="btn btn-success" id="uploadBtn" disabled>
              <span>✅</span>
              <span>آپلود تصاویر</span>
            </button>
            <button type="button" class="btn btn-danger" id="bulkDeleteBtn" disabled>
              <span>🗑️</span>
              <span>حذف موارد انتخابی (<span id="selectedCount">0</span>)</span>
            </button>
            <button type="button" class="btn btn-secondary" id="clearBtn">
              <span>🔄</span>
              <span>پاک کردن فرم</span>
            </button>
          </div>
        </form>
      </div>
    <?php endif; ?>
  </div>

  <!-- Modal -->
  <div class="gallery-modal" id="galleryModal" aria-hidden="true">
    <div class="modal-content">
      <div class="modal-header">
        <div class="modal-title" id="modalTitle">عنوان تصویر</div>
        <button class="modal-close" id="modalClose" aria-label="بستن">✖</button>
      </div>
      <div class="modal-body">
        <div class="modal-image-wrap">
          <img id="modalImage" src="" alt="" class="modal-image">
        </div>
        <div class="modal-info">
          <p><strong>📝 توضیحات:</strong></p>
          <p id="modalDesc">—</p>
          <p><strong>📂 دسته‌بندی:</strong> <span id="modalCat">—</span></p>
          <p><strong>📅 تاریخ:</strong> <span id="modalDate">—</span></p>
          <div class="modal-actions">
            <a id="modalDownload" href="#" download class="modal-btn modal-btn-primary">
              <span>⬇️</span>
              <span>دانلود تصویر</span>
            </a>
            <button id="modalOpen" class="modal-btn modal-btn-secondary">
              <span>🔗</span>
              <span>باز کردن در صفحه جدید</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  (function(){
    'use strict';
    
    const isAdmin = <?php echo $userIsAdmin ? 'true' : 'false'; ?>;
    const categories = <?php echo json_encode($CATEGORIES); ?>;
    
    // Helper functions
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    
    function notify(text, isError = false) {
      const notif = document.createElement('div');
      notif.className = 'notification' + (isError ? ' error' : '');
      notif.innerHTML = `
        <div class="notification-icon">${isError ? '❌' : '✅'}</div>
        <div class="notification-text">${text}</div>
      `;
      document.body.appendChild(notif);
      setTimeout(() => notif.remove(), 3000);
    }

    // ============ FILTERS ============
    const filterGrid = $('#filterGrid');
    if (filterGrid) {
      filterGrid.addEventListener('click', e => {
        const btn = e.target.closest('.filter-btn');
        if (!btn) return;
        
        $$('.filter-btn', filterGrid).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const cat = btn.dataset.cat;
        const cards = $$('#galleryGrid .gallery-card');
        
        cards.forEach((card, i) => {
          const cardCat = card.dataset.cat;
          if (cat === 'all' || cat === cardCat) {
            card.style.display = 'block';
            card.style.animation = `fadeIn .5s ease ${i * 0.05}s backwards`;
          } else {
            card.style.display = 'none';
          }
        });
      });
    }

    // ============ MODAL ============
    const modal = $('#galleryModal');
    const modalImage = $('#modalImage');
    const modalTitle = $('#modalTitle');
    const modalDesc = $('#modalDesc');
    const modalCat = $('#modalCat');
    const modalDate = $('#modalDate');
    const modalDownload = $('#modalDownload');
    const modalOpen = $('#modalOpen');
    const modalClose = $('#modalClose');

    function openModal(data) {
      modalImage.src = data.src;
      modalTitle.textContent = data.title;
      modalDesc.textContent = data.desc || '—';
      modalCat.textContent = data.catLabel;
      modalDate.textContent = data.date;
      modalDownload.href = data.src;
      modal.classList.add('show');
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      modal.classList.remove('show');
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
      setTimeout(() => { modalImage.src = ''; }, 300);
    }

    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modal) {
      modal.addEventListener('click', e => {
        if (e.target === modal) closeModal();
      });
    }
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeModal();
    });
    if (modalOpen) {
      modalOpen.addEventListener('click', () => {
        if (modalImage.src) window.open(modalImage.src, '_blank');
      });
    }

    // ============ CARD ACTIONS ============
    document.addEventListener('click', e => {
      const card = e.target.closest('.gallery-card');
      if (!card) return;

      // View
      if (e.target.closest('.view-btn') || e.target.closest('.card-image-wrap')) {
        const img = $('.card-image', card);
        const title = $('.card-title', card)?.textContent || '';
        const desc = $('.card-desc', card)?.textContent || '';
        const cat = card.dataset.cat;
        const catInfo = categories[cat] || categories['other'];
        const date = $('.card-date span:last-child', card)?.textContent || '';
        
        openModal({
          src: img.src,
          title,
          desc,
          catLabel: catInfo.icon + ' ' + catInfo.label,
          date
        });
        return;
      }

      if (!isAdmin) return;

      // Delete
      if (e.target.closest('.delete-btn')) {
        const id = card.dataset.id;
        if (!confirm('این تصویر حذف شود؟')) return;
        
        fetch('ajax/gallery-delete.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: parseInt(id) })
        })
        .then(r => r.json())
        .then(data => {
          if (!data.success) throw new Error(data.message);
          notify('تصویر با موفقیت حذف شد');
          card.style.animation = 'fadeOut .3s ease';
          setTimeout(() => card.remove(), 300);
          updateSelectedCount();
        })
        .catch(err => notify(err.message || 'خطا در حذف', true));
      }
    });

    // ============ ADMIN UPLOAD ============
    if (isAdmin) {
      const uploadZone = $('#uploadZone');
      const fileInput = $('#fileInput');
      const uploadForm = $('#uploadForm');
      const uploadBtn = $('#uploadBtn');
      const clearBtn = $('#clearBtn');
      const previewContainer = $('#previewContainer');
      const progressContainer = $('#progressContainer');
      const progressFill = $('#progressFill');
      const progressText = $('#progressText');
      
      let selectedFiles = [];

      // Click to upload
      if (uploadZone) {
        uploadZone.addEventListener('click', () => fileInput.click());
      }

      // Drag & drop
      if (uploadZone) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(event => {
          uploadZone.addEventListener(event, e => {
            e.preventDefault();
            e.stopPropagation();
          });
        });

        ['dragenter', 'dragover'].forEach(event => {
          uploadZone.addEventListener(event, () => {
            uploadZone.classList.add('dragover');
          });
        });

        ['dragleave', 'drop'].forEach(event => {
          uploadZone.addEventListener(event, () => {
            uploadZone.classList.remove('dragover');
          });
        });

        uploadZone.addEventListener('drop', e => {
          const files = e.dataTransfer.files;
          handleFiles(files);
        });
      }

      // File input change
      if (fileInput) {
        fileInput.addEventListener('change', e => {
          handleFiles(e.target.files);
        });
      }

      function handleFiles(files) {
        selectedFiles = Array.from(files).filter(f => f.type.startsWith('image/'));
        
        if (selectedFiles.length === 0) {
          notify('لطفاً فایل تصویری انتخاب کنید', true);
          return;
        }

        displayPreviews();
        uploadBtn.disabled = false;
      }

      function displayPreviews() {
        previewContainer.innerHTML = '';
        previewContainer.style.display = selectedFiles.length > 0 ? 'grid' : 'none';

        selectedFiles.forEach((file, index) => {
          const reader = new FileReader();
          reader.onload = e => {
            const div = document.createElement('div');
            div.className = 'preview-item';
            div.innerHTML = `
              <img src="${e.target.result}" alt="Preview" class="preview-img">
              <button type="button" class="preview-remove" data-index="${index}">✖</button>
              <div class="preview-progress">
                <div class="preview-progress-bar" style="width:0"></div>
              </div>
            `;
            previewContainer.appendChild(div);
          };
          reader.readAsDataURL(file);
        });
      }

      // Remove preview
      if (previewContainer) {
        previewContainer.addEventListener('click', e => {
          if (e.target.classList.contains('preview-remove')) {
            const index = parseInt(e.target.dataset.index);
            selectedFiles.splice(index, 1);
            displayPreviews();
            
            if (selectedFiles.length === 0) {
              uploadBtn.disabled = true;
              fileInput.value = '';
            }
          }
        });
      }

     // Upload
      if (uploadForm) {
        uploadForm.addEventListener('submit', async e => {
          e.preventDefault();
          
          if (selectedFiles.length === 0) {
            notify('لطفاً حداقل یک تصویر انتخاب کنید', true);
            return;
          }

          const title = $('#uploadTitle').value || 'بدون عنوان';
          const category = $('#uploadCategory').value;
          const description = $('#uploadDescription').value;

          uploadBtn.disabled = true;
          progressContainer.classList.add('show');

          let completed = 0;
          const total = selectedFiles.length;

          for (let i = 0; i < total; i++) {
            const formData = new FormData();
            formData.append('image_file', selectedFiles[i]); // تغییر از images[] به image_file
            formData.append('title', title + (total > 1 ? ` - ${i+1}` : ''));
            formData.append('category', category);
            formData.append('description', description);

            try {
              const response = await fetch('ajax/upload-gallery.php', {
                method: 'POST',
                body: formData
              });

              const data = await response.json();
              if (!data.success) throw new Error(data.message);

              completed++;
              const percent = Math.round((completed / total) * 100);
              progressFill.style.width = percent + '%';
              progressText.textContent = `${completed} از ${total} تصویر (${percent}%)`;

              // Update preview progress
              const previewItem = previewContainer.children[i];
              if (previewItem) {
                const bar = previewItem.querySelector('.preview-progress-bar');
                if (bar) bar.style.width = '100%';
              }

            } catch (err) {
              notify(`خطا در آپلود تصویر ${i + 1}: ${err.message}`, true);
            }
          }

          setTimeout(() => {
            if (completed > 0) {
              notify(`${completed} تصویر با موفقیت آپلود شد`);
              setTimeout(() => location.reload(), 1000);
            } else {
              uploadBtn.disabled = false;
            }
            progressContainer.classList.remove('show');
          }, 1000);
        });
      }

      // Clear form
      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          uploadForm.reset();
          selectedFiles = [];
          previewContainer.innerHTML = '';
          previewContainer.style.display = 'none';
          fileInput.value = '';
          uploadBtn.disabled = true;
        });
      }

      // ============ BULK DELETE ============
      const bulkDeleteBtn = $('#bulkDeleteBtn');
      const selectedCountSpan = $('#selectedCount');

      function updateSelectedCount() {
        const count = $$('.item-checkbox:checked').length;
        selectedCountSpan.textContent = count;
        bulkDeleteBtn.disabled = count === 0;
      }

      document.addEventListener('change', e => {
        if (e.target.classList.contains('item-checkbox')) {
          updateSelectedCount();
        }
      });

      if (bulkDeleteBtn) {
        bulkDeleteBtn.addEventListener('click', async () => {
          const checked = $$('.item-checkbox:checked');
          if (checked.length === 0) return;

          if (!confirm(`${checked.length} تصویر حذف شود؟`)) return;

          bulkDeleteBtn.disabled = true;
          let deleted = 0;

          for (const cb of checked) {
            const card = cb.closest('.gallery-card');
            const id = card.dataset.id;

            try {
              const response = await fetch('ajax/gallery-delete.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: parseInt(id) })
              });

              const data = await response.json();
              if (!data.success) throw new Error(data.message);

              card.style.animation = 'fadeOut .3s ease';
              setTimeout(() => card.remove(), 300);
              deleted++;

            } catch (err) {
              notify(`خطا در حذف: ${err.message}`, true);
            }
          }

          setTimeout(() => {
            notify(`${deleted} تصویر با موفقیت حذف شد`);
            updateSelectedCount();
          }, 500);
        });
      }
    }

  })();
  </script>
</section>