<?php
/* =============================================================
 * xp_admin_panel.php - پنل مدیریت سیستم XP
 * ============================================================= */

// Session check
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
require_once '../config.php';
$db = $conn;

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Include the auto updater class - اصلاح مسیر
$autoUpdaterPath = __DIR__ . '/auto_level_updater.php';
if (!file_exists($autoUpdaterPath)) {
    // اگر در مسیر classnotebook نبود، در همین مجلد جستجو کن
    $autoUpdaterPath = __DIR__ . '../auto_level_updater.php';
}

if (file_exists($autoUpdaterPath)) {
    require_once $autoUpdaterPath;
    $updater = new AutoLevelUpdater($conn);
} else {
    // اگر فایل پیدا نشد، کلاس را همینجا تعریف کن
    class AutoLevelUpdater {
        private $db;
        private $levelThresholds = [
            1 => 0, 2 => 1000, 3 => 2500, 4 => 5000, 5 => 10000,
            6 => 20000, 7 => 40000, 8 => 80000, 9 => 160000, 10 => 320000
        ];
        
        public function __construct($database) {
            $this->db = $database;
        }
        
        private function calculateLevel($totalXP) {
            $level = 1;
            foreach ($this->levelThresholds as $targetLevel => $requiredXP) {
                if ($totalXP >= $requiredXP) {
                    $level = $targetLevel;
                } else {
                    break;
                }
            }
            return $level;
        }
        
        public function updateAllLevels() {
            try {
                $stmt = $this->db->prepare("
                    SELECT s.id, s.student_id, s.total_xp, s.level as current_level,
                           u.first_name, u.last_name
                    FROM student_xp s
                    INNER JOIN users u ON s.student_id = u.id 
                    WHERE u.user_type = 'student' AND u.is_active = 1
                ");
                $stmt->execute();
                $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (empty($students)) {
                    return ['success' => true, 'message' => 'هیچ دانش‌آموزی یافت نشد.'];
                }
                
                $updatedCount = 0;
                $errors = [];
                
                foreach ($students as $student) {
                    $newLevel = $this->calculateLevel($student['total_xp']);
                    
                    if ($newLevel != $student['current_level']) {
                        $success = $this->updateStudentLevel(
                            $student['student_id'], 
                            $newLevel, 
                            $student['current_level'],
                            $student['total_xp']
                        );
                        
                        if ($success) {
                            $updatedCount++;
                        } else {
                            $errors[] = "خطا در بروزرسانی سطح دانش‌آموز ID: {$student['student_id']}";
                        }
                    }
                }
                
                $totalStudents = count($students);
                return [
                    'success' => true, 
                    'message' => "بروزرسانی سطح‌ها انجام شد. {$updatedCount} از {$totalStudents} دانش‌آموز بروزرسانی شدند.",
                    'updated_count' => $updatedCount,
                    'total_count' => $totalStudents,
                    'errors' => $errors
                ];
                
            } catch (Exception $e) {
                return ['success' => false, 'message' => 'خطا در بروزرسانی: ' . $e->getMessage()];
            }
        }
        
        private function updateStudentLevel($studentId, $newLevel, $oldLevel, $totalXP) {
            try {
                $stmt = $this->db->prepare("
                    UPDATE student_xp 
                    SET level = ?, updated_at = CURRENT_TIMESTAMP 
                    WHERE student_id = ?
                ");
                $result = $stmt->execute([$newLevel, $studentId]);
                
                if ($result) {
                    $historyStmt = $this->db->prepare("
                        INSERT INTO xp_history (student_id, subject, amount, reason, admin_id) 
                        VALUES (?, 'level_change', ?, ?, 18)
                    ");
                    $reason = "تغییر خودکار سطح از {$oldLevel} به {$newLevel} (بر اساس کل XP: {$totalXP})";
                    $historyStmt->execute([$studentId, 0, $reason]);
                }
                
                return $result;
                
            } catch (Exception $e) {
                return false;
            }
        }
        
        public function getStatusReport() {
            try {
                $stmt = $this->db->prepare("
                    SELECT 
                        COUNT(*) as total_students,
                        COALESCE(AVG(total_xp), 0) as avg_xp,
                        COALESCE(MAX(total_xp), 0) as max_xp,
                        COALESCE(MIN(total_xp), 0) as min_xp,
                        COALESCE(AVG(level), 1) as avg_level,
                        COALESCE(MAX(level), 1) as max_level
                    FROM student_xp s
                    INNER JOIN users u ON s.student_id = u.id
                    WHERE u.user_type = 'student' AND u.is_active = 1
                ");
                $stmt->execute();
                $stats = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $levelStmt = $this->db->prepare("
                    SELECT COALESCE(level, 1) as level, COUNT(*) as count
                    FROM student_xp s
                    INNER JOIN users u ON s.student_id = u.id
                    WHERE u.user_type = 'student' AND u.is_active = 1
                    GROUP BY level
                    ORDER BY level
                ");
                $levelStmt->execute();
                $levelDistribution = $levelStmt->fetchAll(PDO::FETCH_ASSOC);
                
                return [
                    'stats' => $stats,
                    'level_distribution' => $levelDistribution,
                    'timestamp' => date('Y-m-d H:i:s')
                ];
                
            } catch (Exception $e) {
                return ['stats' => [], 'level_distribution' => [], 'timestamp' => date('Y-m-d H:i:s')];
            }
        }
    }
    $updater = new AutoLevelUpdater($conn);
}

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    
    switch ($_POST['action']) {
        case 'update_levels':
            $result = $updater->updateAllLevels();
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            exit;
            
        case 'get_status':
            $report = $updater->getStatusReport();
            echo json_encode($report, JSON_UNESCAPED_UNICODE);
            exit;
            
        case 'manual_xp_update':
            $result = handleManualXPUpdate($db, $_POST);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            exit;
            
        case 'bulk_xp_update':
            $result = handleBulkXPUpdate($db, $_POST);
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
            exit;
    }
}

// Function to handle manual XP updates
function handleManualXPUpdate($db, $data) {
    try {
        $studentId = $data['student_id'];
        $subject = $data['subject'];
        $xpAmount = intval($data['xp_amount']);
        $operation = $data['operation'];
        $reason = $data['reason'] ?: 'بروزرسانی دستی توسط مدیر';
        
        // تعیین فیلد مربوطه
        $subjectField = match($subject) {
            'math' => 'math_xp',
            'science' => 'science_xp', 
            'persian' => 'persian_xp',
            'social' => 'social_xp',
            'religion' => 'religion_xp',
            default => 'total_xp'
        };
        
        // چک وجود رکورد
        $checkStmt = $db->prepare("SELECT id, {$subjectField}, total_xp FROM student_xp WHERE student_id = ?");
        $checkStmt->execute([$studentId]);
        $current = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$current) {
            // ایجاد رکورد جدید
            $insertStmt = $db->prepare("INSERT INTO student_xp (student_id) VALUES (?)");
            $insertStmt->execute([$studentId]);
            $current = [$subjectField => 0, 'total_xp' => 0];
        }
        
        // محاسبه مقدار جدید
        $oldValue = $current[$subjectField];
        $newValue = match($operation) {
            'add' => $oldValue + $xpAmount,
            'subtract' => max(0, $oldValue - $xpAmount),
            'set' => $xpAmount
        };
        
        // محاسبه تغییر در total_xp
        $totalChange = $newValue - $oldValue;
        
        // بروزرسانی
        if ($subjectField === 'total_xp') {
            $updateStmt = $db->prepare("UPDATE student_xp SET total_xp = ? WHERE student_id = ?");
            $updateStmt->execute([$newValue, $studentId]);
        } else {
            $updateStmt = $db->prepare("UPDATE student_xp SET {$subjectField} = ?, total_xp = total_xp + ? WHERE student_id = ?");
            $updateStmt->execute([$newValue, $totalChange, $studentId]);
        }
        
        // ثبت تاریخچه
        $historyStmt = $db->prepare("INSERT INTO xp_history (student_id, subject, amount, reason, admin_id) VALUES (?, ?, ?, ?, 18)");
        $historyStmt->execute([$studentId, $subject, $totalChange, $reason]);
        
        // محاسبه سطح جدید
        $levelStmt = $db->prepare("SELECT total_xp FROM student_xp WHERE student_id = ?");
        $levelStmt->execute([$studentId]);
        $totalXP = $levelStmt->fetchColumn();
        $newLevel = floor($totalXP / 1000) + 1;
        
        $updateLevelStmt = $db->prepare("UPDATE student_xp SET level = ? WHERE student_id = ?");
        $updateLevelStmt->execute([$newLevel, $studentId]);
        
        return ['success' => true, 'message' => 'امتیاز با موفقیت بروزرسانی شد'];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
    }
}

// Function to handle bulk XP updates
function handleBulkXPUpdate($db, $data) {
    try {
        $studentIds = $data['student_ids'];
        $subject = $data['subject'];
        $xpAmount = intval($data['xp_amount']);
        $reason = $data['reason'] ?: 'بروزرسانی گروهی توسط مدیر';
        
        $updatedCount = 0;
        foreach ($studentIds as $studentId) {
            $result = handleManualXPUpdate($db, [
                'student_id' => $studentId,
                'subject' => $subject,
                'xp_amount' => $xpAmount,
                'operation' => 'add',
                'reason' => $reason
            ]);
            if ($result['success']) $updatedCount++;
        }
        
        return [
            'success' => true, 
            'message' => "{$updatedCount} دانش‌آموز بروزرسانی شدند"
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'خطا: ' . $e->getMessage()];
    }
}

// Get students list
function getStudents($db) {
    $stmt = $db->prepare("
        SELECT u.id, u.first_name, u.last_name, 
               COALESCE(sx.total_xp, 0) as total_xp,
               COALESCE(sx.level, 1) as level
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.user_type = 'student' AND u.is_active = 1
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$students = getStudents($db);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>🎮 مدیریت سیستم XP - ستاره ماه</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/script.css" />
    
    <style>
        body {
            font-family: 'Tahoma', tahoma, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        
        .xp-admin-container {
            max-width: 1200px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
        }
        
        .admin-header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #eee;
        }
        
        .admin-header h1 {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 2.5rem;
            margin: 0;
        }
        
        .control-panel {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .control-card {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 15px;
            padding: 1.5rem;
            border: 1px solid #dee2e6;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .control-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .control-card h3 {
            color: #495057;
            margin: 0 0 1rem 0;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            cursor: pointer;
            font-family: 'Tahoma', tahoma, sans-serif;
            font-weight: 600;
            transition: all 0.3s ease;
            margin: 0.5rem 0;
            width: 100%;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
        }
        
        .btn-info {
            background: linear-gradient(135deg, #17a2b8, #6f42c1);
        }
        
        .status-display {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 1rem;
            margin: 1rem 0;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .status-success {
            border-color: #28a745;
            background: #d4edda;
            color: #155724;
        }
        
        .status-error {
            border-color: #dc3545;
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-info {
            border-color: #17a2b8;
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .students-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        
        .student-card {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            border: 1px solid #dee2e6;
            text-align: center;
        }
        
        .student-name {
            font-weight: bold;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        
        .student-stats {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
        }
        
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            position: relative;
        }
        
        .close {
            position: absolute;
            right: 1rem;
            top: 1rem;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        
        .close:hover {
            color: #333;
        }
        
        .form-group {
            margin: 1rem 0;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #495057;
        }
        
        .form-group select,
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Tahoma', tahoma, sans-serif;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .loading {
            text-align: center;
            color: #6c757d;
            padding: 2rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="xp-admin-container">
        <div class="admin-header">
            <h1>🎮 مدیریت سیستم XP</h1>
            <p>پنل کنترل امتیازات و سطوح دانش‌آموزان</p>
        </div>
        
        <div class="control-panel">
            <!-- بروزرسانی خودکار سطوح -->
            <div class="control-card">
                <h3>🔄 بروزرسانی سطوح</h3>
                <p>بروزرسانی خودکار سطح تمام دانش‌آموزان بر اساس کل XP</p>
                <button class="btn" onclick="updateAllLevels()">
                    اجرای بروزرسانی
                </button>
                <div id="updateStatus" class="status-display" style="display: none;"></div>
            </div>
            
            <!-- گزارش وضعیت -->
            <div class="control-card">
                <h3>📊 گزارش وضعیت</h3>
                <p>مشاهده آمار کامل سیستم XP و توزیع سطوح</p>
                <button class="btn btn-info" onclick="getStatusReport()">
                    نمایش گزارش
                </button>
                <div id="statusReport" class="status-display" style="display: none;"></div>
            </div>
            
            <!-- بروزرسانی دستی -->
            <div class="control-card">
                <h3>✏️ بروزرسانی دستی</h3>
                <p>تغییر دستی امتیاز یک دانش‌آموز</p>
                <button class="btn btn-success" onclick="openManualUpdateModal()">
                    افزودن/کم کردن XP
                </button>
            </div>
            
            <!-- بروزرسانی گروهی -->
            <div class="control-card">
                <h3>🎯 بروزرسانی گروهی</h3>
                <p>اعطای امتیاز به چندین دانش‌آموز همزمان</p>
                <button class="btn btn-warning" onclick="openBulkUpdateModal()">
                    امتیاز گروهی
                </button>
            </div>
        </div>
        
        <!-- نمایش دانش‌آموزان -->
        <div class="control-card">
            <h3>👥 دانش‌آموزان</h3>
            <div class="students-grid">
                <?php foreach ($students as $student): ?>
                <div class="student-card">
                    <div class="student-name">
                        <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                    </div>
                    <div class="student-stats">
                        <span>سطح: <?php echo $student['level']; ?></span>
                        <span>XP: <?php echo number_format($student['total_xp']); ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Modal برای بروزرسانی دستی -->
    <div id="manualUpdateModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeManualUpdateModal()">&times;</span>
            <h3>✏️ بروزرسانی دستی XP</h3>
            <form id="manualUpdateForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>دانش‌آموز:</label>
                        <select name="student_id" required>
                            <option value="">انتخاب کنید</option>
                            <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>موضوع:</label>
                        <select name="subject" required>
                            <option value="total">کل امتیاز</option>
                            <option value="math">ریاضی</option>
                            <option value="science">علوم</option>
                            <option value="persian">فارسی</option>
                            <option value="social">اجتماعی</option>
                            <option value="religion">دینی</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>مقدار XP:</label>
                        <input type="number" name="xp_amount" min="1" max="10000" required>
                    </div>
                    <div class="form-group">
                        <label>عملیات:</label>
                        <select name="operation" required>
                            <option value="add">افزودن</option>
                            <option value="subtract">کم کردن</option>
                            <option value="set">تنظیم مستقیم</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>دلیل:</label>
                    <textarea name="reason" rows="3" placeholder="دلیل تغییر را بنویسید..."></textarea>
                </div>
                <button type="submit" class="btn">اعمال تغییرات</button>
            </form>
        </div>
    </div>
    
    <!-- Modal برای بروزرسانی گروهی -->
    <div id="bulkUpdateModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeBulkUpdateModal()">&times;</span>
            <h3>🎯 بروزرسانی گروهی XP</h3>
            <form id="bulkUpdateForm">
                <div class="form-group">
                    <label>دانش‌آموزان (Ctrl را نگه دارید):</label>
                    <select name="student_ids[]" multiple size="8" required style="height: 200px;">
                        <?php foreach ($students as $student): ?>
                        <option value="<?php echo $student['id']; ?>">
                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> 
                            (سطح <?php echo $student['level']; ?> - <?php echo number_format($student['total_xp']); ?> XP)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>موضوع:</label>
                        <select name="subject" required>
                            <option value="total">کل امتیاز</option>
                            <option value="math">ریاضی</option>
                            <option value="science">علوم</option>
                            <option value="persian">فارسی</option>
                            <option value="social">اجتماعی</option>
                            <option value="religion">دینی</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>مقدار XP:</label>
                        <input type="number" name="xp_amount" min="1" max="1000" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>دلیل:</label>
                    <textarea name="reason" rows="3" placeholder="دلیل اعطای امتیاز گروهی..." required></textarea>
                </div>
                <button type="submit" class="btn btn-warning">اعطای امتیاز به انتخاب شدگان</button>
            </form>
        </div>
    </div>
    
    <script>
        // بروزرسانی خودکار سطوح
        function updateAllLevels() {
            const statusDiv = document.getElementById('updateStatus');
            statusDiv.style.display = 'block';
            statusDiv.className = 'status-display loading';
            statusDiv.innerHTML = '⏳ در حال بروزرسانی سطوح...';
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_levels'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    statusDiv.className = 'status-display status-success';
                    statusDiv.innerHTML = `
                        ✅ ${data.message}<br>
                        📊 بروزرسانی شده: ${data.updated_count} از ${data.total_count}<br>
                        🕐 زمان: ${new Date().toLocaleString('fa-IR')}
                    `;
                    setTimeout(() => location.reload(), 2000);
                } else {
                    statusDiv.className = 'status-display status-error';
                    statusDiv.innerHTML = `❌ ${data.message}`;
                }
            })
            .catch(error => {
                statusDiv.className = 'status-display status-error';
                statusDiv.innerHTML = `❌ خطا در ارتباط: ${error.message}`;
            });
        }
        
        // گزارش وضعیت
        function getStatusReport() {
            const reportDiv = document.getElementById('statusReport');
            reportDiv.style.display = 'block';
            reportDiv.className = 'status-display loading';
            reportDiv.innerHTML = '⏳ در حال بارگذاری گزارش...';
            
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=get_status'
            })
            .then(response => response.json())
            .then(data => {
                const stats = data.stats;
                const levels = data.level_distribution;
                
                let levelChart = '<br><strong>📈 توزیع سطوح:</strong><br>';
                levels.forEach(level => {
                    levelChart += `• سطح ${level.level}: ${level.count} نفر<br>`;
                });
                
                reportDiv.className = 'status-display status-info';
                reportDiv.innerHTML = `
                    📊 <strong>گزارش وضعیت - ${data.timestamp}</strong><br><br>
                    👥 کل دانش‌آموزان: ${stats.total_students} نفر<br>
                    ⭐ میانگین XP: ${Math.round(stats.avg_xp)} امتیاز<br>
                    🏆 حداکثر XP: ${stats.max_xp} امتیاز<br>
                    📉 حداقل XP: ${stats.min_xp} امتیاز<br>
                    🎯 میانگین سطح: ${(Math.round(stats.avg_level * 10) / 10)}<br>
                    👑 بالاترین سطح: ${stats.max_level}
                    ${levelChart}
                `;
            })
            .catch(error => {
                reportDiv.className = 'status-display status-error';
                reportDiv.innerHTML = `❌ خطا در دریافت گزارش: ${error.message}`;
            });
        }
        
        // Modal management
        function openManualUpdateModal() {
            document.getElementById('manualUpdateModal').style.display = 'block';
        }
        
        function closeManualUpdateModal() {
            document.getElementById('manualUpdateModal').style.display = 'none';
        }
        
        function openBulkUpdateModal() {
            document.getElementById('bulkUpdateModal').style.display = 'block';
        }
        
        function closeBulkUpdateModal() {
            document.getElementById('bulkUpdateModal').style.display = 'none';
        }
        
        // Form submissions
        document.getElementById('manualUpdateForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'manual_xp_update');
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeManualUpdateModal();
                    location.reload();
                }
            })
            .catch(error => {
                alert('خطا در ارتباط: ' + error.message);
            });
        });
        
        document.getElementById('bulkUpdateForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'bulk_xp_update');
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeBulkUpdateModal();
                    location.reload();
                }
            })
            .catch(error => {
                alert('خطا در ارتباط: ' + error.message);
            });
        });
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const manualModal = document.getElementById('manualUpdateModal');
            const bulkModal = document.getElementById('bulkUpdateModal');
            
            if (event.target == manualModal) {
                closeManualUpdateModal();
            }
            if (event.target == bulkModal) {
                closeBulkUpdateModal();
            }
        }
    </script>
</body>
</html>