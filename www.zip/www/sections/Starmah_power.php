<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پرزنت ستاره ماه | سفر به آینده یادگیری</title>
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts (Vazir) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700;900&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --accent-color: #f093fb;
            --text-color: #333;
            --light-bg: #f8f9fa;
            --dark-bg: #1a1a2e;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Vazirmatn', sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: #000;
            overflow: hidden; /* پیش‌فرض برای دسکتاپ */
        }

        /* ===== لینک بازگشت به خانه ===== */
        .back-to-home {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            text-align: center;
            padding: 10px;
        }

        .back-to-home a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .back-to-home a:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        /* Slideshow Container */
        .slideshow-container {
            position: relative;
            width: 100vw;
            height: 100vh;
        }

        /* Individual Slides */
        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 2rem;
            opacity: 0;
            transition: opacity 1s ease-in-out, transform 1s ease-in-out;
            transform: scale(0.95);
            pointer-events: none;
        }

        .slide.active {
            opacity: 1;
            transform: scale(1);
            pointer-events: auto;
        }

        /* Slide Specific Backgrounds */
        .slide-1 { background: linear-gradient(135deg, var(--dark-bg) 0%, var(--primary-color) 50%, var(--secondary-color) 100%); color: white; }
        .slide-2 { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; }
        .slide-3 { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }
        .slide-4 { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: var(--dark-bg); }
        .slide-5 { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: var(--dark-bg); }
        .slide-6 { background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); color: white; }
        .slide-7 { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: white; }
        .slide-8 { background: linear-gradient(135deg, #0f3460 0%, #16213e 50%, #1a1a2e 100%); color: white; }
        .slide-9 { background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); color: var(--dark-bg); }
        .slide-10 { background: var(--dark-bg); color: white; }

        .slide h1 {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 900;
            margin-bottom: 1.5rem;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.3);
        }

        .slide h2 {
            font-size: clamp(2rem, 5vw, 3rem);
            font-weight: 800;
            margin-bottom: 1rem;
        }

        .slide p {
            font-size: 1.2rem;
            max-width: 800px;
            margin-bottom: 1.5rem;
            line-height: 1.8;
        }

        /* ===== بهبود خوانایی محتوا ===== */
        .slide .content-box {
            background: rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 2rem;
            border-radius: 20px;
            max-width: 900px;
        }

        .slide-9 .content-box {
            background: rgba(0, 0, 0, 0.4);
            color: #fff;
        }
        /* ===== پایان بهبود خوانایی ===== */

        .slide .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.15);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
        }

        .feature-card i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .myth-reality {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .myth-reality > div {
            flex: 1;
            min-width: 280px;
            padding: 1.5rem;
            border-radius: 15px;
            background: rgba(0,0,0,0.2);
        }

        .myth-reality h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        /* ===== استایل‌دهی جدید به فلش‌های ناوبری ===== */
        .prev, .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 1rem 1.5rem;
            min-width: 180px;
            color: white;
            font-weight: bold;
            font-size: 1rem;
            transition: all 0.3s ease;
            user-select: none;
            background-color: rgba(0,0,0,0.3);
            border-radius: 0 5px 5px 0;
            text-align: center;
        }

        .next {
            right: 0;
            border-radius: 5px 0 0 5px;
            flex-direction: row;
        }

        .prev {
            left: 0;
            border-radius: 0 5px 5px 0;
            flex-direction: row-reverse;
        }

        .nav-arrow-symbol {
            font-size: 1.5rem;
            flex-shrink: 0;
        }

        .nav-arrow-title {
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .prev:hover, .next:hover {
            background-color: rgba(0,0,0,0.6);
        }
        /* ===== پایان استایل‌دهی جدید به فلش‌های ناوبری ===== */

        <!-- ===== شماره اسلاید (منتقل شده به پایین) ===== -->
        .bottom-controls {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        .slide-number-container {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            padding: 8px 20px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        #slide-number-display {
            color: #fff;
            font-weight: 600;
            font-size: 0.9rem;
        }
        <!-- ===== پایان شماره اسلاید ===== -->

        /* Dots Indicators */
        .dots-container {
            display: flex;
            gap: 10px;
        }
        .dot {
            cursor: pointer;
            height: 12px;
            width: 12px;
            margin: 0 5px;
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .dot.active, .dot:hover {
            background-color: white;
        }

        /* FAQ Accordion */
        .faq-item {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            margin-bottom: 1rem;
            text-align: right;
        }
        .faq-question {
            padding: 1.5rem;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
        }
        .faq-item.active .faq-answer {
            padding: 0 1.5rem 1.5rem 1.5rem;
            max-height: 300px;
        }
        .faq-question i {
            transition: transform 0.3s ease;
        }
        .faq-item.active .faq-question i {
            transform: rotate(180deg);
        }

        /* ===== مدیا کوئری برای حالت موبایل ===== */
        @media (max-width: 768px) {
            /* مخفی کردن متن فلش‌های ناوبری */
            .nav-arrow-title {
                display: none;
            }
            /* کوچک کردن خود دکمه فلش */
            .prev, .next {
                min-width: auto;
                padding: 1rem;
            }

            /* ===== اصلاح جدید: فعال‌سازی اسکرول در موبایل ===== */
            body {
                overflow: auto; /* اجازه دادن به اسکرول کردن کل صفحه */
            }

            .slideshow-container {
                /* ===== اصلاح اصلی ===== */
                min-height: 80vh; /* حداقل ارتفاع، کل صفحه را بپوشاند تا دکمه‌ها در جای درست باشند */
                height: auto; /* اجازه دادن به رشد کانتینر اسلایدها در صورت نیاز */
                padding-top: 20px; /* این فاصله باعث می‌شود محتوا زیر هدر قرار بگیرد */
            }

            .slide {
                height: auto; /* ارتفاع اسلاید بر اساس محتوا تنظیم شود */
                min-height: 100vh; /* حداقل ارتفاع، کل صفحه را بپوشاند */
                overflow-y: auto; /* اگر محتوا بیشتر از صفحه بود، اسکرول عمودی فعال شود */
            }
            /* ===== پایان فعال‌سازی اسکرول در موبایل ===== */
        }
        /* ===== پایان مدیا کوئری برای حالت موبایل ===== */

    </style>
</head>
<body>

    <!-- ===== لینک بازگشت به خانه ===== -->
    <div class="back-to-home">
        <a href="../index.php" title="بازگشت به صفحه اصلی">
            <i class="fas fa-arrow-right"></i> بازگشت به خانه
        </a>
    </div>

    <div class="slideshow-container">

        <!-- Slide 1: Title -->
        <div class="slide slide-1 active">
            <div class="content-box">
                <h1>به دنیای ستاره ماه خوش آمدید</h1>
                <p>سفر مشترک ما به سوی آینده‌ای درخشان برای فرزندانمان</p>
                <i class="fas fa-star fa-3x" style="color: var(--accent-color); animation: pulse 2s infinite;"></i>
            </div>
        </div>

        <!-- Slide 2: The Why -->
        <div class="slide slide-2">
            <div class="content-box">
                <h2>چرا به یک تغییر فکر می‌کنیم؟</h2>
                <p>دنیا در حال تغییر است. ما در آستانه انقلاب چهارم صنعتی و عصر هوش مصنوعی هستیم. روش‌های آموزشی ما نیز باید تغییر کنند تا بچه‌ها را برای آینده‌ای که <strong>الا</strong> منتظرشان است، آماده کنیم.</p>
                <div class="myth-reality">
                    <div>
                        <h3>📜 دیروز</h3>
                        <p>دفترچه، قلم و اطلاعات محدود. یادگیری یک فرآیند یک‌طرفه بود.</p>
                    </div>
                    <div>
                        <h3>🚀 امروز</h3>
                        <p>دنیایی از اطلاعات، تعامل و هیجان. یادگیری باید یک ماجراجویی شخصی باشد.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 3: The What -->
        <div class="slide slide-3">
            <div class="content-box">
                <h2>معرفی می‌کنیم: ستاره ماه</h2>
                <p>ستاره ماه فقط یک سایت نیست؛ یک **اکوسیستم یادگیری** زنده است که در آن هر کودک می‌درخشد.</p>
                <div class="features-grid">
                    <div class="feature-card">
                        <i class="fas fa-backpack"></i>
                        <h3>کیف دیجیتال</h3>
                        <p>دسترسی همیشگی به تکالیف و دروس</p>
                    </div>
                    <div class="feature-card">
                        <i class="fas fa-gamepad"></i>
                        <h3>بازی‌وارسازی</h3>
                        <p>تبدیل تلاش به امتیاز و هیجان</p>
                    </div>
                    <div class="feature-card">
                        <i class="fas fa-trophy"></i>
                        <h3>قهرمان خودت باش</h3>
                        <p>پیشرفت شخصی و رقابت سالم</p>
                    </div>
                    <div class="feature-card">
                        <i class="fas fa-users"></i>
                        <h3>ارتباط همیشگی</h3>
                        <p>پل ارتباطی مدرسه و خانه</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 4: The Magic -->
        <div class="slide slide-4">
            <div class="content-box">
                <h2>جادوی اصلی: وقتی تلاش، به بازی تبدیل می‌شود</h2>
                <p>سیستم امتیازدهی (XP) ما، مغز متفکر این اکوسیستم است. این سیستم به کودک شما یاد می‌دهد که **فرآیند یادگیری** به اندازه **نتیجه** اهمیت دارد.</p>
                <p style="font-size: 1.5rem; font-weight: bold;">هر تکلیف، یک مأموریت. هر موفقیت، یک ستاره.</p>
                <p>این یعنی فرزند شما یاد می‌گیرد که برای هدف تلاش کند، از چالش‌ها نترسد و به پیشرفت مداوم خود افتخار کند.</p>
            </div>
        </div>

        <!-- Slide 5: The Big Question (Screen Time) -->
        <div class="slide slide-5">
            <div class="content-box">
                <h2>نگرانی بزرگ: آیا وقت‌شان تلف می‌شود؟</h2>
                <p>این نگرانی کاملاً به‌جاست. اما بیایید تفاوت را ببینیم:</p>
                <div class="myth-reality">
                    <div style="background: rgba(255,0,0,0.2);">
                        <h3>❌ مصرف منفعل</h3>
                        <p>تماشای بی‌هدف ویدیو، وب‌گردی بدون برنامه. در این حالت، مغز در حال دریافت اطلاعات است، نه پردازش.</p>
                    </div>
                    <div style="background: rgba(0,255,0,0.2);">
                        <h3>✅ خلق فعال</h3>
                        <p>حل مسئله، خلاقیت در تکلیف، دریافت بازخورد. در این حالت، مغز در حال ساخت دانش و مهارت است.</p>
                    </div>
                </div>
                <p>ستاره ماه، ابزاری برای **استفاده هوشمندانه و متمرکز** از زمان است، نه اتلاف آن.</p>
            </div>
        </div>

        <!-- Slide 6: Parent's Role -->
        <div class="slide slide-6">
            <div class="content-box">
                <h2>شما: مربی و هم‌سفر اصلی</h2>
                <p>شما دیگر تماشاگر نیستید؛ شما مهم‌ترین راهنمای فرزندتان در این سفر هستید. ستاره ماه به شما قدرت می‌دهد:</p>
                <div class="features-grid">
                    <div class="feature-card">
                        <i class="fas fa-eye"></i>
                        <h3>همیشه در جریان</h3>
                        <p>از پیشرفت او باخبر باشید</p>
                    </div>
                    <div class="feature-card">
                        <i class="fas fa-gift"></i>
                        <h3>جشن گرفتن</h3>
                        <p>موفقیت‌های کوچک را بزرگ کنید</p>
                    </div>
                    <div class="feature-card">
                        <i class="fas fa-hands-helping"></i>
                        <h3>راهنمایی کردن</h3>
                        <p>در نقاط ضعف به او کمک کنید</p>
                    </div>
                </div>
                <p style="margin-top: 2rem; font-style: italic;">به جای پرسیدن "مدرسه چطور بود؟"، بپرسید "امروز چه مأموری رو در ستاره ماه انجام دادی؟"</p>
            </div>
        </div>

        <!-- Slide 7: The Future & AI (بخش اول) -->
        <div class="slide slide-7">
            <div class="content-box">
                <h2>نگاه به آینده: دنیای جدید ما</h2>
                <p>دنیا دیگر در حال تغییر نیست؛ <strong>تغییر کرده است.</strong> ما وارد عصری شده‌ایم که خلاقیت، هوش هیجانی و توانایی حل مسئله، از حفظ کردن اطلاعات مهم‌تر هستند.</p>
                
                <p style="font-size: 1.3rem; font-weight: bold; margin-top: 2rem;">🤖 هوش مصنوعی، همکار جدید ماست</p>
                <p>هوش مصنوعی قرار است جایگزین ما نشود؛ قرار است کارهای تکراری و محاسباتی را انجام دهد تا انسان‌ها بتوانند روی آنچه <em>واقعاً منحصر به فرد است</em> تمرکز کنند: <strong>خلاقیت، نوآوری و ارتباط.</strong></p>
            </div>
        </div>

        <!-- Slide 8: The Teacher's Role (بخش دوم) -->
        <div class="slide slide-8">
            <div class="content-box">
                <h2>نقش معلم: معماران آینده</h2>
                <p>در این دنیای جدید، نقش معلم ما بسیار فراتر از آموزش است. ایشان یک <strong>معمار آینده</strong> است. ایشان:</p>
                <ul style="text-align: right; font-size: 1.1rem; max-width: 700px; margin: 1rem auto;">
                    <li>مهارت‌های انسانی را که هوش مصنوعی هرگز نمی‌تواند یاد بگیرد (همدلی، خلاقیت، تفکر انتقادی) در فرزند شما پرورش می‌دهد.</li>
                    <li>با استفاده از داده‌های "ستاره ماه"، نقاط قوت و ضعف هر کودک را شناسایی کرده و مسیر یادگیری را شخصی‌سازی می‌کند.</li>
                    <li>به فرزند شما یاد می‌دهد که چگونه از فناوری به عنوان ابزاری برای قدرتمند شدن استفاده کند، نه مصرف‌کننده آن باشد.</li>
                </ul>
                <p style="margin-top: 2rem; font-style: italic; font-weight: bold;">
                    "ستاره ماه" اولین زمین تمرین فرزند شما برای ورود موفق به این دنیای هیجان‌انگیز است.
                </p>
            </div>
        </div>

        <!-- Slide 9: FAQ -->
        <div class="slide slide-9">
            <div class="content-box">
                <h2>سوالات شما، پاسخ‌های ما</h2>
                <div class="faq-item">
                    <div class="faq-question">
                        اگر اینترنت قوی نداریم چه کار کنیم؟
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>فعالیت‌ها نیاز به پهنای باند بالایی ندارند. می‌توان از گوشی استفاده کرد و کودک بخشی از کارها را در مدرسه انجام دهد.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        آیا اطلاعات فرزندم امن است؟
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>بله، امنیت داده‌ها اولویت ماست و تمام اطلاعات در سرورهای امن نگهداری می‌شود.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        آیا باعث رقابت ناسالم می‌شود؟
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>خیر، تمرکز ما بر رقابت با خودِ گذشته و تقدیر از "تلاش" است، نه مقایسه با دیگران.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 10: Thank You -->
        <div class="slide slide-10">
            <div class="content-box">
                <h1>با هم می‌درخشیم!</h1>
                <p>از همراهی شما سپاسگزاریم. بیایید با هم، برای فرزندانمان آینده‌ای درخشان بسازیم.</p>
                <p style="margin-top: 2rem;">
                    <strong>www.starmah.ir</strong><br>
                    <i class="fas fa-envelope"></i> info@starmah.ir
                </p>
            </div>
        </div>

        <!-- Navigation (ساختار جدید) -->
        <a class="prev" onclick="changeSlide(-1)">
            <span class="nav-arrow-title" id="prev-slide-title">اسلاید قبلی</span>
            <span class="nav-arrow-symbol">&#10094;</span>
        </a>
        <a class="next" onclick="changeSlide(1)">
            <span class="nav-arrow-symbol">&#10095;</span>
            <span class="nav-arrow-title" id="next-slide-title">اسلاید بعدی</span>
        </a>

        <!-- Bottom Controls (شماره اسلاید و نقاط) -->
        <div class="bottom-controls">
            <div class="slide-number-container">
                <span id="slide-number-display">1 / 10</span>
            </div>
            <div class="dots-container">
                <span class="dot active" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
                <span class="dot" onclick="currentSlide(4)"></span>
                <span class="dot" onclick="currentSlide(5)"></span>
                <span class="dot" onclick="currentSlide(6)"></span>
                <span class="dot" onclick="currentSlide(7)"></span>
                <span class="dot" onclick="currentSlide(8)"></span>
                <span class="dot" onclick="currentSlide(9)"></span>
                <span class="dot" onclick="currentSlide(10)"></span>
            </div>
        </div>

    </div>

    <script>
        let slideIndex = 1;
        const slides = document.getElementsByClassName("slide");
        const dots = document.getElementsByClassName("dot");

        // ===== آرایه عناوین اسلایدها (به‌روز شده) =====
        const slideTitles = [
            "به دنیای ستاره ماه خوش آمدید",
            "چرا به یک تغییر فکر می‌کنیم؟",
            "معرفی می‌کنیم: ستاره ماه",
            "جادوی اصلی: وقتی تلاش، به بازی تبدیل می‌شود",
            "نگرانی بزرگ: آیا وقت‌شان تلف می‌شود؟",
            "شما: مربی و هم‌سفر اصلی",
            "نگاه به آینده: دنیای جدید ما",
            "نقش معلم: معماران آینده",
            "سوالات شما، پاسخ‌های ما",
            "با هم می‌درخشیم!"
        ];
        // ===== پایان آرایه عناوین اسلایدها =====

        function showSlide(n) {
            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }
            
            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove('active');
            }
            
            for (let i = 0; i < dots.length; i++) {
                dots[i].classList.remove('active');
            }
            
            slides[slideIndex - 1].classList.add('active');
            dots[slideIndex - 1].classList.add('active');

            updateNavigationInfo();
        }

        function updateNavigationInfo() {
            document.getElementById('slide-number-display').textContent = `${slideIndex} / ${slides.length}`;

            let prevIndex = slideIndex - 2;
            if (prevIndex < 0) prevIndex = slides.length - 1;

            let nextIndex = slideIndex;
            if (nextIndex >= slides.length) nextIndex = 0;

            document.getElementById('prev-slide-title').textContent = slideTitles[prevIndex];
            document.getElementById('next-slide-title').textContent = slideTitles[nextIndex];
        }

        function changeSlide(n) {
            slideIndex += n;
            showSlide(slideIndex);
        }

        function currentSlide(n) {
            slideIndex = n;
            showSlide(slideIndex);
        }

        document.addEventListener('keydown', function(event) {
            if (event.key === 'ArrowRight') {
                changeSlide(1);
            } else if (event.key === 'ArrowLeft') {
                changeSlide(-1);
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            const faqItems = document.querySelectorAll('.faq-item');
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                question.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    faqItems.forEach(otherItem => {
                        if (otherItem !== item) {
                            otherItem.classList.remove('active');
                        }
                    });
                    if (!isActive) {
                        item.classList.add('active');
                    } else {
                        item.classList.remove('active');
                    }
                });
            });

            updateNavigationInfo();
        });
        
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.1); }
                100% { transform: scale(1); }
            }
        `;
        document.head.appendChild(style);

    </script>

</body>
</html>