<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

// نمایش خطاها فقط در حالت توسعه (برای دیباگ)
// در محیط واقعی بهتره display_errors خاموش باشه
ini_set('display_errors', 1);
error_reporting(E_ALL);

// اتصال به دیتابیس
require_once __DIR__ . '/../../../config.php';

if (!isset($conn) || !$conn instanceof PDO) {
    echo json_encode(['success' => false, 'message' => 'اتصال به دیتابیس برقرار نشد']);
    exit;
}

// دریافت داده‌های ورودی
$input = json_decode(file_get_contents('php://input'), true);
$examId = (int)($input['exam_id'] ?? 0);
$studentId = (int)($input['student_id'] ?? 0);

// بررسی سطح دسترسی
if (!in_array($_SESSION['user_type'] ?? '', ['admin', 'teacher'])) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// بررسی ورودی‌ها
if ($examId <= 0 || $studentId <= 0) {
    echo json_encode(['success' => false, 'message' => 'ورودی نامعتبر']);
    exit;
}

// حذف رکورد از دیتابیس
try {
    $stmt = $conn->prepare("DELETE FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?");
    $stmt->execute([$examId, $studentId]);

    echo json_encode(['success' => true, 'message' => 'آزمون برای دانش‌آموز آزاد شد.']);
} catch (PDOException $e) {
    error_log("DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در عملیات دیتابیس']);
}