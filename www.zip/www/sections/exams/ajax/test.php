<?php
// test.php
header('Content-Type: application/json; charset=utf-8');
$in = json_decode(file_get_contents('php://input'), true);
echo json_encode(['you_sent' => $in]);