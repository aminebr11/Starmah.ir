<?php
$raw = file_get_contents('php://input');
error_log('RAW input: ' . $raw);

header('Content-Type: application/json; charset=utf-8');
session_start();

// نمایش خطاها فقط در حالت توسعه
ini_set('display_errors', 1);
error_reporting(E_ALL);

// اتصال به دیتابیس
require_once __DIR__ . '/../../../config.php';

if (!isset($conn) || !$conn instanceof PDO) {
    echo json_encode(['success' => false, 'message' => 'اتصال به دیتابیس برقرار نشد']);
    exit;
}

$input  = json_decode(file_get_contents('php://input'), true);
error_log('Decoded input: ' . print_r($input, true));
$examId = (int)($input['exam_id'] ?? 0);

// لاگ برای تست
error_log("Received exam_id: " . var_export($examId, true));

// بررسی سطح دسترسی
if (!in_array($_SESSION['user_type'] ?? '', ['admin', 'teacher'])) {
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// بررسی ورودی
if ($examId <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه آزمون نامعتبر است']);
    exit;
}

// حذف همه رکوردهای این آزمون
try {
    $stmt = $conn->prepare("DELETE FROM quiz_attempts WHERE quiz_id = ?");
    $stmt->execute([$examId]);

    echo json_encode(['success' => true, 'message' => 'آزمون برای همه شرکت‌کنندگان آزاد شد.']);
} catch (PDOException $e) {
    error_log("DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطا در عملیات دیتابیس']);
}