<?php
/* =============================================================
 * student_report.php - صفحه گزارش تفصیلی دانش‌آموز
 * - تاریخچه کامل آزمون‌های دانش‌آموز
 * - تحلیل نقاط قوت و ضعف
 * - روند عملکرد فردی
 * - مقایسه با میانگین کلاس
 * ============================================================= */

// Session Management
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Database Connection
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../functions.php';

// تابع تبدیل تاریخ میلادی به شمسی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }
    if ($gm > 2) {
        $gy2 = $gy + 1;
    } else {
        $gy2 = $gy;
    }
    $days = (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];
    $jy += 33 * ((int)($days / 12053));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return array($jy, $jm, $jd);
}

function formatJalaliDate($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}

function formatJalaliDateTime($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    $time = date('H:i', $timestamp);
    return sprintf('%04d/%02d/%02d - %s', $jy, $jm, $jd, $time);
}

/* ====================== دسترسی و تعیین studentId ====================== */

// مقدار اولیه studentId از GET (برای ادمین‌ها)
$studentId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// اگر لاگین نیست
if (!$isLoggedIn) {
    header('Location: /index.php');
    exit;
}

// اگر دانش‌آموز است → همیشه فقط گزارش خودش را ببیند
if ($userType === 'student') {
    // آیدی را از سشن می‌گیریم و کاری به GET نداریم
    $studentId = (int)$_SESSION['user_id'];
}

// اگر بعد از این مرحله هنوز studentId نامعتبر است
if ($studentId <= 0) {
    // برای ادمین برگرد به لیست گزارش‌ها
    if ($userType === 'admin') {
        header('Location: /sections/exams/reports.php');
    } else {
        // برای هر نوع دیگر کاربر (اگر بود) برگرد به خانه
        header('Location: /index.php');
    }
    exit;
}

/* ==================================================================== */

try {
    // اطلاعات دانش‌آموز
    $stmt = $conn->prepare("
        SELECT 
            id, username, first_name, last_name, national_id,
            birth_date, email, father_name, father_phone,
            mother_name, mother_phone, created_at
        FROM users
        WHERE id = ? AND user_type = 'student'
    ");
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        header('Location: /sections/exams/reports.php');
        exit;
    }
    
    // آمار کلی دانش‌آموز
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_exams,
            AVG((qa.score / qa.total_score) * 100) as avg_percentage,
            MAX((qa.score / qa.total_score) * 100) as max_percentage,
            MIN((qa.score / qa.total_score) * 100) as min_percentage,
            SUM(qa.score) as total_score_earned,
            SUM(qa.total_score) as total_score_possible,
            AVG(qa.time_taken) as avg_time_taken
        FROM quiz_attempts qa
        WHERE qa.student_id = ? AND qa.total_score > 0
    ");
    $stmt->execute([$studentId]);
    $studentStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // مقایسه با میانگین کلاس
    $stmt = $conn->query("
        SELECT 
            AVG((qa.score / qa.total_score) * 100) as class_avg
        FROM quiz_attempts qa
        WHERE qa.total_score > 0
    ");
    $classStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $classAverage = round($classStats['class_avg'] ?? 0, 1);
    
    // رتبه دانش‌آموز
    $stmt = $conn->prepare("
        SELECT COUNT(*) + 1 as student_rank
        FROM (
            SELECT 
                student_id,
                AVG((score / total_score) * 100) as avg_perc
            FROM quiz_attempts
            WHERE total_score > 0
            GROUP BY student_id
            HAVING avg_perc > (
                SELECT AVG((score / total_score) * 100)
                FROM quiz_attempts
                WHERE student_id = ? AND total_score > 0
            )
        ) as ranked
    ");
    $stmt->execute([$studentId]);
    $rankData = $stmt->fetch(PDO::FETCH_ASSOC);
    $studentRank = $rankData['student_rank'] ?? '-';
    
    // لیست آزمون‌های شرکت کرده
    $stmt = $conn->prepare("
        SELECT 
            q.id as quiz_id,
            q.title as quiz_title,
            q.exam_date,
            q.questions_count,
            qa.score,
            qa.total_score,
            qa.time_taken,
            qa.submitted_at,
            (qa.score / qa.total_score * 100) as percentage,
            (SELECT AVG((score / total_score) * 100) 
             FROM quiz_attempts 
             WHERE quiz_id = q.id AND total_score > 0) as quiz_class_avg
        FROM quiz_attempts qa
        INNER JOIN quizzes q ON qa.quiz_id = q.id
        WHERE qa.student_id = ?
        ORDER BY qa.submitted_at DESC
    ");
    $stmt->execute([$studentId]);
    $examHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // روند عملکرد در طول زمان
    $stmt = $conn->prepare("
        SELECT 
            DATE(qa.submitted_at) as exam_date,
            (qa.score / qa.total_score * 100) as percentage,
            q.title as quiz_title
        FROM quiz_attempts qa
        INNER JOIN quizzes q ON qa.quiz_id = q.id
        WHERE qa.student_id = ? AND qa.total_score > 0
        ORDER BY qa.submitted_at ASC
        LIMIT 20
    ");
    $stmt->execute([$studentId]);
    $performanceTrend = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تحلیل نقاط قوت و ضعف (بر اساس نوع سوالات)
    $stmt = $conn->prepare("
        SELECT 
            qq.question_type,
            COUNT(*) as total_questions,
            SUM(
                CASE 
                    WHEN JSON_EXTRACT(qa.answers, CONCAT('$.\"', qq.id, '\".is_correct')) = true 
                    THEN 1 
                    ELSE 0 
                END
            ) as correct_answers
        FROM quiz_attempts qa
        INNER JOIN quiz_questions qq ON qa.quiz_id = qq.quiz_id
        WHERE qa.student_id = ? AND qq.is_active = 1
        GROUP BY qq.question_type
    ");
    $stmt->execute([$studentId]);
    $questionTypeAnalysis = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $strengthsWeaknesses = [];
    foreach ($questionTypeAnalysis as $analysis) {
        $correctRate = $analysis['total_questions'] > 0 
            ? ($analysis['correct_answers'] / $analysis['total_questions']) * 100 
            : 0;
        
        $typeLabel = $analysis['question_type'] == 'mcq' ? 'سوالات چندگزینه‌ای' : 
                     ($analysis['question_type'] == 'tf' ? 'سوالات درست/نادرست' : 'سوالات پاسخ کوتاه');
        
        $strengthsWeaknesses[] = [
            'type' => $typeLabel,
            'correct_rate' => round($correctRate, 1),
            'total' => $analysis['total_questions'],
            'correct' => $analysis['correct_answers']
        ];
    }
    
} catch (PDOException $e) {
    error_log("Error fetching student report: " . $e->getMessage());
    header('Location: /sections/exams/reports.php');
    exit;
}

// آماده‌سازی داده برای نمودارها
$trendDataJson = json_encode($performanceTrend);
$studentAvg = round($studentStats['avg_percentage'] ?? 0, 1);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>📊 گزارش دانش‌آموز - <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></title>
  <link rel="stylesheet" href="/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/script.css" />
  
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  
  <style>
    /* فونت و رنگ کلی صفحه */
    body {
      font-family: 'Vazirmatn', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      color: #1f2933;
    }

    .exam-builder-container {
      max-width: 1400px;
      margin: 2rem auto;
      padding: 0 1rem;
    }
    
    /* دکمه بازگشت روشن و خوانا */
    .back-button {
      background: #fffbeb;
      color: #1f2933;
      padding: 0.8rem 1.5rem;
      border-radius: 15px;
      text-decoration: none;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 1.5rem;
      transition: all 0.3s ease;
      border: 1px solid #fed7aa;
    }
    
    .back-button:hover {
      background: #fed7aa;
      transform: translateY(-2px);
    }
    
    /* کارت‌ها سفید و کودک‌پسند */
    .exam-card {
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 20px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
    }
    
    /* هدر کارت‌ها با رنگ پاستلی شاد */
    .exam-card-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      background: linear-gradient(135deg, #bfdbfe, #f9a8d4);
      color: #111827;
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }
    
    .exam-step-number {
      background: #fef3c7;
      color: #b45309;
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 800;
      font-size: 0.9rem;
    }
    
    .exam-card-title {
      flex: 1;
    }
    
    .exam-card-title h2 {
      margin: 0;
      font-size: 1.15rem;
      font-weight: 800;
      color: #111827;
    }
    
    .exam-card-title p {
      margin: 0.3rem 0 0 0;
      opacity: 0.9;
      font-size: 0.9rem;
      color: #374151;
    }
    
    .exam-badge {
      background: #fef3c7;
      color: #92400e;
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 700;
      font-size: 0.85rem;
    }
    
    /* کارت‌های آمار */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .stat-card {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 15px;
      padding: 1.2rem;
      text-align: center;
      transition: all 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-3px);
      background: #eef2ff;
      box-shadow: 0 8px 20px rgba(129, 140, 248, 0.25);
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 800;
      color: #2563eb;
      margin-bottom: 0.5rem;
      display: block;
    }
    
    .stat-label {
      color: #4b5563;
      font-size: 0.9rem;
      font-weight: 600;
    }
    
    /* اطلاعات دانش‌آموز */
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
      margin: 1rem 0;
    }
    
    .info-item {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 1rem;
    }
    
    .info-label {
      color: #6b7280;
      font-size: 0.85rem;
      margin-bottom: 0.3rem;
    }
    
    .info-value {
      color: #111827;
      font-size: 1.1rem;
      font-weight: 700;
    }
    
    /* جدول آزمون‌ها */
    .reports-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 0.5rem;
      margin-top: 1rem;
    }
    
    .reports-table thead th {
      background: #fee2e2;
      color: #7f1d1d;
      padding: 0.8rem;
      font-weight: 700;
      font-size: 0.9rem;
      border: none;
      text-align: right;
    }
    
    .reports-table thead th:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table thead th:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    .reports-table tbody tr {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      transition: all 0.3s ease;
    }
    
    .reports-table tbody tr:hover {
      background: #e0f2fe;
      transform: translateX(-3px);
    }
    
    .reports-table tbody td {
      padding: 0.8rem;
      color: #111827;
      border: none;
      font-size: 0.9rem;
    }
    
    .reports-table tbody td:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table tbody td:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    /* نمودار */
    .chart-container {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 15px;
      padding: 1.5rem;
      height: 350px;
      position: relative;
    }
    
    .reports-main-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-bottom: 2rem;
    }
    
    /* نوار مقایسه‌ای */
    .comparison-bar {
      background: #eff6ff;
      border-radius: 10px;
      padding: 1rem;
      margin-bottom: 1rem;
    }
    
    .comparison-label {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
      color: #1f2933;
      font-size: 0.9rem;
    }
    
    .progress-bar-container {
      background: #e5e7eb;
      border-radius: 10px;
      height: 8px;
      overflow: hidden;
    }
    
    .progress-bar {
      height: 100%;
      border-radius: 10px;
      transition: width 0.5s ease;
    }
    
    .progress-student {
      background: linear-gradient(90deg, #22c55e, #3b82f6);
    }
    
    .progress-class {
      background: linear-gradient(90deg, #f97316, #facc15);
    }
    
    /* دکمه‌ها */
    .exam-btn {
      border: none;
      border-radius: 12px;
      padding: 0.8rem 1.5rem;
      cursor: pointer;
      font-weight: 700;
      transition: all 0.3s ease;
      font-family: inherit;
      font-size: 0.95rem;
    }
    
    .exam-btn-primary {
      background: linear-gradient(135deg, #34d399, #60a5fa);
      color: #111827;
      box-shadow: 0 5px 20px rgba(56, 189, 248, 0.4);
    }
    
    .exam-btn-soft {
      background: #e0f2fe;
      color: #1f2933;
      border: 1px solid #bfdbfe;
    }
    
    .exam-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 18px rgba(15, 23, 42, 0.12);
    }
    
    .quick-actions {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      margin: 1rem 0;
    }

    /* هدر بالای صفحه (hero) روشن‌تر و کودک‌پسند */
    .hero.glass-effect {
      background: #fefce8 !important;
      border-radius: 20px;
      border: 1px solid #fde68a;
    }
    
    /* متن داخل ناوبری بالا خواناتر شود */
    .user-info.glass-effect {
      background: #fefce8;
      color: #1f2933;
      border: 1px solid #fde68a;
    }
    .user-info.glass-effect span {
      color: #1f2933;
      font-weight: 600;
    }
    .logout-btn {
      background: #f97373;
      color: #111827 !important;
      font-weight: 700;
    }
    
    @media (max-width: 1024px) {
      .reports-main-grid {
        grid-template-columns: 1fr;
      }
    }
    
    @media (max-width: 768px) {
      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .info-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#admin" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                </div>
            </div>

            <div class="auth-section">
                <div class="user-info glass-effect">
                    <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                    <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="exam-builder-container">
        
        <!-- دکمه بازگشت -->
        <a href="/sections/exams/reports.php" class="back-button">
            ← بازگشت به گزارش‌ها
        </a>

        <!-- نام دانش‌آموز -->
        <div class="hero glass-effect" style="text-align: center; padding: 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 0.5rem 0; font-size: 2rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                👤 <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
            </h1>
            <p style="margin: 0; color: #374151;">گزارش تفصیلی و تحلیل عملکرد</p>
        </div>

        <!-- اطلاعات دانش‌آموز -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">ℹ️</div>
                <div class="exam-card-title">
                    <h2>مشخصات دانش‌آموز</h2>
                    <p>اطلاعات شخصی و تماس</p>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">👤 نام کاربری</div>
                    <div class="info-value"><?php echo htmlspecialchars($student['username']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">🆔 کد ملی</div>
                    <div class="info-value"><?php echo htmlspecialchars($student['national_id']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">📧 ایمیل</div>
                    <div class="info-value"><?php echo htmlspecialchars($student['email'] ?: '-'); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">🎂 تاریخ تولد</div>
                    <div class="info-value"><?php echo formatJalaliDate($student['birth_date']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">👨 نام پدر</div>
                    <div class="info-value"><?php echo htmlspecialchars($student['father_name'] ?: '-'); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">📞 تلفن پدر</div>
                    <div class="info-value"><?php echo htmlspecialchars($student['father_phone'] ?: '-'); ?></div>
                </div>
            </div>
        </div>

        <!-- آمار کلی عملکرد -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📊</div>
                <div class="exam-card-title">
                    <h2>آمار کلی عملکرد</h2>
                    <p>خلاصه نتایج و رتبه</p>
                </div>
                <div class="exam-badge">رتبه <?php echo $studentRank; ?></div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value"><?php echo $studentStats['total_exams']; ?></span>
                    <div class="stat-label">تعداد آزمون‌های شرکت کرده</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #059669;"><?php echo $studentAvg; ?>%</span>
                    <div class="stat-label">میانگین کلی نمرات</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #f59e0b;"><?php echo round($studentStats['max_percentage'] ?? 0, 1); ?>%</span>
                    <div class="stat-label">بالاترین نمره</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #dc2626;"><?php echo round($studentStats['min_percentage'] ?? 0, 1); ?>%</span>
                    <div class="stat-label">پایین‌ترین نمره</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $studentStats['total_score_earned']; ?></span>
                    <div class="stat-label">مجموع امتیاز کسب شده</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo round(($studentStats['avg_time_taken'] ?? 0) / 60, 1); ?></span>
                    <div class="stat-label">میانگین زمان (دقیقه)</div>
                </div>
            </div>
        </div>

        <!-- مقایسه با میانگین کلاس -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">⚖️</div>
                <div class="exam-card-title">
                    <h2>مقایسه با میانگین کلاس</h2>
                    <p>عملکرد دانش‌آموز در مقابل میانگین</p>
                </div>
            </div>

            <div class="comparison-bar">
                <div class="comparison-label">
                    <span>میانگین دانش‌آموز</span>
                    <span style="color: #16a34a; font-weight: 700;"><?php echo $studentAvg; ?>%</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar progress-student" style="width: <?php echo $studentAvg; ?>%;"></div>
                </div>
            </div>

            <div class="comparison-bar">
                <div class="comparison-label">
                    <span>میانگین کلاس</span>
                    <span style="color: #ea580c; font-weight: 700;"><?php echo $classAverage; ?>%</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar progress-class" style="width: <?php echo $classAverage; ?>%;"></div>
                </div>
            </div>

            <div style="text-align: center; margin-top: 1.5rem; padding: 1rem; background: #fef9c3; border-radius: 12px;">
                <?php 
                $difference = $studentAvg - $classAverage;
                if ($difference > 0) {
                    echo "<p style='color: #166534; font-weight: 600; margin: 0;'>✅ دانش‌آموز " . round(abs($difference), 1) . "% بالاتر از میانگین کلاس عمل کرده است</p>";
                } elseif ($difference < 0) {
                    echo "<p style='color: #b91c1c; font-weight: 600; margin: 0;'>⚠️ دانش‌آموز " . round(abs($difference), 1) . "% پایین‌تر از میانگین کلاس عمل کرده است</p>";
                } else {
                    echo "<p style='color: #92400e; font-weight: 600; margin: 0;'>➡️ دانش‌آموز دقیقاً در سطح میانگین کلاس است</p>";
                }
                ?>
            </div>
        </div>

        <!-- نقاط قوت و ضعف -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">💪</div>
                <div class="exam-card-title">
                    <h2>تحلیل نقاط قوت و ضعف</h2>
                    <p>عملکرد در انواع مختلف سوالات</p>
                </div>
            </div>

            <?php if (empty($strengthsWeaknesses)): ?>
                <p style="text-align: center; color: #6b7280; padding: 2rem;">
                    هنوز داده کافی برای تحلیل وجود ندارد.
                </p>
            <?php else: ?>
                <?php foreach ($strengthsWeaknesses as $sw): ?>
                <div class="comparison-bar" style="background:#fefce8;">
                    <div class="comparison-label">
                        <span><?php echo $sw['type']; ?></span>
                        <span style="font-weight: 700; color:#111827;">
                            <?php echo $sw['correct']; ?> از <?php echo $sw['total']; ?> 
                            (<?php echo $sw['correct_rate']; ?>%)
                        </span>
                    </div>
                    <div class="progress-bar-container">
                        <div class="progress-bar" 
                             style="width: <?php echo $sw['correct_rate']; ?>%;
                                    background: <?php echo $sw['correct_rate'] >= 75 ? '#22c55e' : ($sw['correct_rate'] >= 50 ? '#fbbf24' : '#f97373'); ?>;">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- روند عملکرد -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📈</div>
                <div class="exam-card-title">
                    <h2>روند عملکرد</h2>
                    <p>تغییرات نمرات در طول زمان</p>
                </div>
            </div>
            
            <div class="chart-container">
                <canvas id="performanceChart"></canvas>
            </div>
        </div>

        <!-- تاریخچه آزمون‌ها -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📋</div>
                <div class="exam-card-title">
                    <h2>تاریخچه کامل آزمون‌ها</h2>
                    <p>لیست تمام آزمون‌های شرکت کرده</p>
                </div>
                <div class="exam-badge"><?php echo count($examHistory); ?> آزمون</div>
            </div>

            <?php if (empty($examHistory)): ?>
                <p style="text-align: center; color: #6b7280; padding: 2rem;">
                    هنوز در آزمونی شرکت نکرده است.
                </p>
            <?php else: ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>عنوان آزمون</th>
                        <th>تاریخ</th>
                        <th>نمره</th>
                        <th>از</th>
                        <th>درصد</th>
                        <th>میانگین کلاس</th>
                        <th>اختلاف</th>
                        <th>زمان (دقیقه)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($examHistory as $exam): 
                        $diff = round($exam['percentage'] - $exam['quiz_class_avg'], 1);
                    ?>
                    <tr>
                        <td style="font-weight: 600;"><?php echo htmlspecialchars($exam['quiz_title']); ?></td>
                        <td><?php echo formatJalaliDate($exam['submitted_at']); ?></td>
                        <td style="color: #059669; font-weight: 600;"><?php echo $exam['score']; ?></td>
                        <td><?php echo $exam['total_score']; ?></td>
                        <td style="font-weight: 700; font-size: 1.05rem;">
                            <?php echo round($exam['percentage'], 1); ?>%
                        </td>
                        <td><?php echo round($exam['quiz_class_avg'], 1); ?>%</td>
                        <td style="font-weight: 600; color: <?php echo $diff > 0 ? '#16a34a' : '#b91c1c'; ?>">
                            <?php echo $diff > 0 ? '+' : ''; ?><?php echo $diff; ?>%
                        </td>
                        <td><?php echo round($exam['time_taken'] / 60, 1); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- اقدامات -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">⚡</div>
                <div class="exam-card-title">
                    <h2>اقدامات سریع</h2>
                    <p>عملیات مرتبط با این دانش‌آموز</p>
                </div>
            </div>

            <div class="quick-actions">
                <button class="exam-btn exam-btn-primary" onclick="sendReportToParent()">
                    📧 ارسال به والدین
                </button>
                <button class="exam-btn exam-btn-soft" onclick="exportStudentReport()">
                    📥 خروجی PDF
                </button>
                <button class="exam-btn exam-btn-soft" onclick="window.print()">
                    🖨️ چاپ گزارش
                </button>
                <button class="exam-btn exam-btn-soft" onclick="window.location.href='/sections/exams/reports.php'">
                    📊 بازگشت به گزارش‌ها
                </button>
            </div>
        </div>
    </div>

    <script>
        // Initialize stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // نمودار روند عملکرد
        const trendData = <?php echo $trendDataJson; ?>;
        const performanceCtx = document.getElementById('performanceChart');
        
        if (performanceCtx && trendData.length > 0) {
            const labels = trendData.map(d => d.quiz_title.substring(0, 15) + '...');
            const data = trendData.map(d => parseFloat(d.percentage));
            
            new Chart(performanceCtx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'درصد نمره',
                        data: data,
                        borderColor: '#38bdf8',
                        backgroundColor: 'rgba(56, 189, 248, 0.15)',
                        tension: 0.4,
                        fill: true,
                        pointRadius: 6,
                        pointHoverRadius: 8,
                        pointBackgroundColor: '#0ea5e9',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    }, {
                        label: 'میانگین کلاس',
                        data: Array(data.length).fill(<?php echo $classAverage; ?>),
                        borderColor: '#fbbf24',
                        borderDash: [5, 5],
                        pointRadius: 0,
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            labels: {
                                color: '#111827',
                                font: { family: 'Vazirmatn', size: 12 }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                color: '#4b5563',
                                callback: function(value) { return value + '%'; }
                            },
                            grid: { color: '#e5e7eb' }
                        },
                        x: {
                            ticks: { color: '#4b5563' },
                            grid: { color: '#e5e7eb' }
                        }
                    }
                }
            });
        }

        function sendReportToParent() {
            alert('📧 قابلیت ارسال به والدین به زودی اضافه می‌شود');
        }

        function exportStudentReport() {
            alert('📥 قابلیت خروجی PDF به زودی اضافه می‌شود');
        }

        document.addEventListener('DOMContentLoaded', function() {
            createStars();
        });
    </script>
</body>
</html>
