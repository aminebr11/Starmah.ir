// ===== state =====
window.CURRENT_EXAM_ID = null;
window.examQuestions = [];
window.currentQuestionType = 'mcq';
window.tfCorrectAnswer = true;

// ===== helpers =====
function $(sel, root=document){ return root.querySelector(sel); }
function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

function updateBadges(){
  // badge مرحله ۱
  const ok = !!($('#examTitle')?.value.trim());
  $('#examInfoBadge').textContent = ok ? '✅ ذخیره شد' : 'در حال تکمیل…';

  // summary pills
  $('#smTitle').textContent     = $('#examTitle')?.value || '—';
  $('#smDate').textContent      = $('#examDate')?.value || '—';
  $('#smDuration').textContent  = $('#examDuration')?.value || '—';
  $('#smShuffle').textContent   = $('#examShuffle')?.checked ? 'بله' : 'خیر';
  $('#smNegative').textContent  = $('#examNegative')?.checked ? 'بله' : 'خیر';
  $('#smCount').textContent     = String(window.examQuestions.length);

  // فعال شدن انتشار
  const canPublish = !!window.CURRENT_EXAM_ID && window.examQuestions.length > 0;
  const btn = $('#publishBtn');
  if (canPublish){ btn.classList.remove('disabled'); btn.removeAttribute('disabled'); }
  else { btn.classList.add('disabled'); btn.setAttribute('disabled', 'disabled'); }
}

function renderQuestions(){
  const wrap = $('#questionsList');
  wrap.innerHTML = '';
  window.examQuestions.forEach((q, idx)=>{
    const card = document.createElement('div');
    card.className = 'q-card';
    const points = `<span style="background:#eef2ff; padding:2px 8px; border-radius:999px">🏅 ${q.points}</span>`;
    let detail = '';
    if(q.type==='mcq'){
      detail = '<ol style="margin:6px 0 0 0; padding-left:20px">' +
        q.options.map((o,i)=>`<li>${o.text} ${o.correct?'✔️':''}</li>`).join('') + '</ol>';
    }else if(q.type==='tf'){
      detail = `<div style="margin-top:6px">پاسخ صحیح: ${q.correct? '✅ درست' : '❌ نادرست'}</div>`;
    }else{
      detail = `<div style="margin-top:6px">پاسخ مورد انتظار: ${q.expected || '—'}</div>`;
    }
    card.innerHTML = `
      <div style="display:flex; gap:8px; align-items:flex-start; justify-content:space-between">
        <div>
          <div style="font-weight:700">سوال ${idx+1} (${q.type}) ${points}</div>
          <div style="margin-top:4px">${q.text}</div>
          ${detail}
        </div>
        <div class="q-actions">
          <button class="btn-mini" onclick="editQuestion(${idx})">✏️ ویرایش</button>
          <button class="btn-mini danger" onclick="deleteQuestion(${idx})">🗑️ حذف</button>
        </div>
      </div>`;
    wrap.appendChild(card);
  });
  updateBadges();
}

// ===== step 1 =====
window.saveExamInfo = function(){
  const title = $('#examTitle')?.value.trim();
  if(!title){ alert('عنوان آزمون را وارد کنید.'); $('#examTitle')?.focus(); return; }

  // شبیه‌سازی ذخیره سمت سرور: یک ID موقت می‌سازیم
  if(!window.CURRENT_EXAM_ID){
    window.CURRENT_EXAM_ID = 'tmp-' + Date.now();
  }
  updateBadges();
  alert('اطلاعات مرحله ۱ ذخیره شد.');
};

// ===== step 2: type switch =====
window.setQType = function(el, type){
  window.currentQuestionType = type;
  // pills UI
  $all('.type-pill').forEach(p=>p.classList.remove('active'));
  el.classList.add('active');
  // boxes
  $('#mcqBox').style.display   = (type==='mcq')?'block':'none';
  $('#tfBox').style.display    = (type==='tf')?'block':'none';
  $('#shortBox').style.display = (type==='short')?'block':'none';
};

window.toggleCorrect = function(btn){
  // روی همان سطر گزینه
  const row = btn.closest('.option-row');
  if(!row) return;
  // برچسب ✔️ را on/off می‌کنیم با data-attr
  const active = btn.getAttribute('data-active') === '1';
  btn.setAttribute('data-active', active ? '0' : '1');
  btn.textContent = active ? '✔️ صحیح' : '✔️ صحیح (انتخاب شد)';
  row.setAttribute('data-correct', active ? '0' : '1');
};

window.removeOption = function(btn){
  const row = btn.closest('.option-row');
  if(!row) return;
  const box = $('#mcqBox');
  const rows = $all('.option-row', box);
  if(rows.length <= 2){ alert('حداقل ۲ گزینه لازم است.'); return; }
  row.remove();
};

window.addOption = function(){
  const box = $('#mcqBox');
  const row = document.createElement('div');
  row.className = 'option-row';
  row.innerHTML = `
    <input class="cute-input" type="text" placeholder="گزینه جدید">
    <button class="btn-mini" onclick="toggleCorrect(this)" type="button">✔️ صحیح</button>
    <button class="btn-mini danger" onclick="removeOption(this)" type="button">🗑️ حذف</button>
  `;
  box.appendChild(row);
};

// TF select
window.setTF = function(val){
  window.tfCorrectAnswer = !!val;
  $all('#tfBox .pill-radio').forEach(el=>el.classList.remove('active'));
  const labels = $all('#tfBox .pill-radio');
  (val ? labels[0] : labels[1]).classList.add('active');
};

// Add Question
window.addQuestion = function(){
  if(!window.CURRENT_EXAM_ID){
    alert('❌ ابتدا مرحله ۱ را ذخیره کنید.');
    return;
  }
  const text = $('#qText')?.value.trim();
  if(!text){ alert('متن سوال را وارد کنید.'); $('#qText').focus(); return; }
  const points = parseInt($('#qPoint')?.value || '1', 10) || 1;

  let q = { type: window.currentQuestionType, text, points };

  if(window.currentQuestionType==='mcq'){
    const rows = $all('#mcqBox .option-row');
    const options = rows.map(r=>{
      const inp = $('input', r);
      return { text: (inp?.value||'').trim(), correct: r.getAttribute('data-correct')==='1' };
    }).filter(o=>o.text);
    if(options.length < 2){ alert('حداقل ۲ گزینه معتبر وارد کنید.'); return; }
    if(!options.some(o=>o.correct)){ alert('حداقل یک گزینه صحیح را تعیین کنید.'); return; }
    q.options = options;
  } else if(window.currentQuestionType==='tf'){
    q.correct = !!window.tfCorrectAnswer;
  } else {
    q.expected = $('#shortExpected')?.value.trim() || '';
  }

  window.examQuestions.push(q);
  // پاک‌سازی فرم
  $('#qText').value = '';
  if(q.type==='short'){ $('#shortExpected').value=''; }
  if(q.type==='mcq'){
    // ریست ساده: حذف و ساخت ۴ ردیف پیش‌فرض
    const box = $('#mcqBox');
    box.innerHTML = '';
    for(let i=1;i<=4;i++){
      const row = document.createElement('div');
      row.className = 'option-row';
      row.innerHTML = `
        <input class="cute-input" type="text" placeholder="گزینه ${i}">
        <button class="btn-mini" onclick="toggleCorrect(this)" type="button">✔️ صحیح</button>
        <button class="btn-mini danger" onclick="removeOption(this)" type="button">🗑️ حذف</button>
      `;
      box.appendChild(row);
    }
  }

  renderQuestions();
};

// edit/delete (در حد پایه)
window.deleteQuestion = function(idx){
  if(!confirm('حذف شود؟')) return;
  window.examQuestions.splice(idx,1);
  renderQuestions();
};

window.editQuestion = function(idx){
  const q = window.examQuestions[idx];
  if(!q) return;
  // ساده: مقدارهای سوال را برمی‌گردانیم به فرم تا کاربر اصلاح/افزودن مجدد کند
  $('#qText').value = q.text;
  $('#qPoint').value = q.points;
  if(q.type==='mcq'){
    setQType($('.type-pill[data-type="mcq"]'), 'mcq');
    const box = $('#mcqBox'); box.innerHTML='';
    q.options.forEach((o,i)=>{
      const row = document.createElement('div');
      row.className = 'option-row';
      row.setAttribute('data-correct', o.correct ? '1' : '0');
      row.innerHTML = `
        <input class="cute-input" type="text" value="${o.text.replace(/"/g,'&quot;')}">
        <button class="btn-mini" onclick="toggleCorrect(this)" type="button">${o.correct?'✔️ صحیح (انتخاب شد)':'✔️ صحیح'}</button>
        <button class="btn-mini danger" onclick="removeOption(this)" type="button">🗑️ حذف</button>
      `;
      box.appendChild(row);
    });
  } else if(q.type==='tf'){
    setQType($('.type-pill[data-type="tf"]'), 'tf');
    setTF(!!q.correct);
  } else {
    setQType($('.type-pill[data-type="short"]'), 'short');
    $('#shortExpected').value = q.expected||'';
  }
  // حذف قدیمی و انتظار برای افزودن نسخه‌ی اصلاح‌شده
  window.examQuestions.splice(idx,1);
  renderQuestions();
};

// ===== step 3: publish (ماک) =====
window.publishExam = function(){
  if(!window.CURRENT_EXAM_ID || window.examQuestions.length===0){
    alert('شرایط انتشار کامل نیست.');
    return;
  }
  // اینجا معمولاً درخواست AJAX به PHP می‌فرستیم
  // fetch('/api/exams/publish.php', {method:'POST', body: JSON.stringify({...})})
  alert('🚀 آزمون منتشر شد (نسخه نمایشی)');
};

// init
document.addEventListener('DOMContentLoaded', ()=>{
  updateBadges();
});
