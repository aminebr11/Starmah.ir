<?php
/* =============================================================
 * students_full_report.php - گزارش کامل دانش‌آموزان (با قابلیت سورت)
 * ============================================================= */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../functions.php';

// بررسی وضعیت سشن
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// بررسی دسترسی ادمین
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'admin') {
    header('Location: /index.php');
    exit;
}

// --- منطق مرتب‌سازی (Sorting Logic) ---

// ستون‌های مجاز برای سورت (برای امنیت و جلوگیری از SQL Injection)
$validColumns = [
    'name'   => 'u.last_name',       // نام خانوادگی
    'email'  => 'u.email',           // ایمیل
    'exams'  => 'exams_taken',       // تعداد آزمون (نام مستعار در کوئری)
    'score'  => 'avg_score',         // میانگین نمره (نام مستعار در کوئری)
    'date'   => 'last_activity',     // تاریخ (نام مستعار در کوئری)
    'status' => 'u.is_active'        // وضعیت
];

// دریافت پارامترها از URL (با مقادیر پیش‌فرض)
$sort = $_GET['sort'] ?? 'name';
$order = $_GET['order'] ?? 'ASC';

// اعتبارسنجی پارامترها
if (!array_key_exists($sort, $validColumns)) {
    $sort = 'name';
}
if ($order !== 'ASC' && $order !== 'DESC') {
    $order = 'ASC';
}

// تعیین ستون نهایی برای کوئری
$orderBy = $validColumns[$sort];

// اگر سورت روی نام بود، نام کوچک را هم به عنوان معیار دوم اضافه کن
if ($sort === 'name') {
    $sqlOrder = "$orderBy $order, u.first_name $order";
} else {
    $sqlOrder = "$orderBy $order";
}

// --- اجرای کوئری ---
try {
    // نکته: متغیر $sqlOrder مستقیماً در کوئری قرار گرفت چون مقادیر آن را خودمان در بالا کنترل کردیم (امن است)
    $stmt = $conn->query("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.email,
            u.is_active,
            COUNT(qa.id) as exams_taken,
            AVG(CASE WHEN qa.total_score > 0 THEN (qa.score / qa.total_score) * 100 ELSE 0 END) as avg_score,
            MAX(qa.submitted_at) as last_activity
        FROM users u
        LEFT JOIN quiz_attempts qa ON u.id = qa.student_id
        WHERE u.user_type = 'student'
        GROUP BY u.id
        ORDER BY $sqlOrder
    ");
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $students = [];
    // برای دیباگ می‌توانید اکو کنید: echo $e->getMessage();
}

// --- توابع کمکی ---

// تابع نمایش تاریخ
function renderDate($dateStr) {
    if (empty($dateStr)) return '---';
    $ts = strtotime($dateStr);
    if (function_exists('gregorian_to_jalali')) {
        list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $ts), date('m', $ts), date('d', $ts));
        return "$jy/$jm/$jd";
    }
    return date('Y/m/d', $ts);
}

// تابع تولید لینک سورت برای هدر جدول
function sortLink($columnKey, $title, $currentSort, $currentOrder) {
    $newOrder = 'ASC';
    $icon = '';
    
    // اگر الان همین ستون در حال نمایش است
    if ($currentSort === $columnKey) {
        // جهت را برعکس کن
        $newOrder = ($currentOrder === 'ASC') ? 'DESC' : 'ASC';
        // آیکون مناسب را انتخاب کن
        $icon = ($currentOrder === 'ASC') ? ' ▲' : ' ▼';
    }
    
    $url = "?sort=$columnKey&order=$newOrder";
    
    // کلاس css برای استایل دهی لینک فعال
    $activeClass = ($currentSort === $columnKey) ? 'sort-active' : '';
    
    return "<a href='$url' class='sort-link $activeClass'>$title $icon</a>";
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <title>گزارش کامل دانش‌آموزان</title>
    <link rel="stylesheet" href="/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Vazirmatn', sans-serif; background: #f3f4f6; padding: 2rem; }
        .container { max-width: 1200px; margin: 0 auto; background: white; border-radius: 15px; padding: 2rem; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; border-bottom: 2px solid #eee; padding-bottom: 1rem; }
        .btn-back { background: #6b7280; color: white; padding: 0.5rem 1rem; border-radius: 8px; text-decoration: none; }
        
        table { width: 100%; border-collapse: collapse; }
        th { background: #f9fafb; padding: 1rem; text-align: right; font-weight: bold; color: #374151; user-select: none; }
        td { padding: 1rem; border-bottom: 1px solid #e5e7eb; color: #1f2937; }
        tr:hover { background: #f9fafb; }
        
        /* استایل لینک‌های سورت */
        .sort-link {
            color: #374151;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
            transition: color 0.2s;
        }
        .sort-link:hover {
            color: #2563eb;
        }
        .sort-active {
            color: #2563eb;
        }
        
        .score-high { color: #059669; font-weight: bold; }
        .score-mid { color: #d97706; font-weight: bold; }
        .score-low { color: #dc2626; font-weight: bold; }
        .status-badge { padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.85rem; }
        .active { background: #d1fae5; color: #065f46; }
        .inactive { background: #f3f4f6; color: #6b7280; }
        .action-btn { background: #3b82f6; color: white; padding: 0.4rem 0.8rem; border-radius: 6px; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1 style="margin:0;">👥 گزارش جامع دانش‌آموزان</h1>
                <p style="margin:0.5rem 0 0; color: #6b7280;">لیست کامل عملکرد تحصیلی تمامی کاربران</p>
            </div>
            <div style="display: flex; gap: 10px;">
                <button onclick="window.print()" class="btn-back" style="background: #10b981; border:none; cursor:pointer;">🖨️ چاپ</button>
                <a href="/sections/exams/reports.php" class="btn-back">بازگشت</a>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <!-- هدرهای قابل کلیک -->
                    <th><?php echo sortLink('name', 'نام دانش‌آموز', $sort, $order); ?></th>
                    <th><?php echo sortLink('email', 'ایمیل / کاربری', $sort, $order); ?></th>
                    <th><?php echo sortLink('exams', 'تعداد آزمون', $sort, $order); ?></th>
                    <th><?php echo sortLink('score', 'میانگین نمرات', $sort, $order); ?></th>
                    <th><?php echo sortLink('date', 'آخرین فعالیت', $sort, $order); ?></th>
                    <th><?php echo sortLink('status', 'وضعیت', $sort, $order); ?></th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($students)): ?>
                    <tr><td colspan="8" style="text-align:center;">دانش‌آموزی یافت نشد.</td></tr>
                <?php else: ?>
                    <?php foreach($students as $index => $std): 
                        $avg = round($std['avg_score'], 1);
                        $scoreClass = $avg >= 75 ? 'score-high' : ($avg >= 50 ? 'score-mid' : 'score-low');
                        $email = $std['email'] ?? '---';
                    ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td style="font-weight: bold;"><?php echo htmlspecialchars($std['first_name'] . ' ' . $std['last_name']); ?></td>
                        <td style="font-size: 0.9rem; color: #6b7280;"><?php echo htmlspecialchars($email); ?></td>
                        <td><?php echo $std['exams_taken']; ?></td>
                        <td class="<?php echo $scoreClass; ?>"><?php echo $std['exams_taken'] > 0 ? $avg . '%' : '-'; ?></td>
                        <td><?php echo renderDate($std['last_activity']); ?></td>
                        <td>
                            <span class="status-badge <?php echo $std['is_active'] ? 'active' : 'inactive'; ?>">
                                <?php echo $std['is_active'] ? 'فعال' : 'غیرفعال'; ?>
                            </span>
                        </td>
                        <td>
                            <a href="/sections/exams/student_report.php?id=<?php echo $std['id']; ?>" class="action-btn">کارنامه</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>