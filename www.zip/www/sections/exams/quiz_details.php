<?php
/* =============================================================
 * quiz_details.php - صفحه جزئیات و تحلیل یک آزمون خاص
 * - تحلیل تفصیلی هر سوال
 * - عملکرد دانش‌آموزان در این آزمون
 * - گزارش‌های بصری و آماری
 * ============================================================= */

// Session Management
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Check admin access
if (!$isLoggedIn || $userType !== 'admin') {
    header('Location: /index.php');
    exit;
}

// Database Connection
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../functions.php';

// تابع تبدیل تاریخ میلادی به شمسی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }
    if ($gm > 2) {
        $gy2 = $gy + 1;
    } else {
        $gy2 = $gy;
    }
    $days = (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];
    $jy += 33 * ((int)($days / 12053));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return array($jy, $jm, $jd);
}

function formatJalaliDate($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}

function formatJalaliDateTime($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    $time = date('H:i', $timestamp);
    return sprintf('%04d/%02d/%02d - %s', $jy, $jm, $jd, $time);
}

// Get quiz ID
$quizId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($quizId <= 0) {
    header('Location: /sections/exams/reports.php');
    exit;
}

try {
    // دریافت اطلاعات آزمون
    $stmt = $conn->prepare("
        SELECT 
            id, title, exam_date, exam_time, duration_minutes,
            questions_count, total_points, is_active, shuffle_questions,
            negative_marking, is_visible, created_at
        FROM quizzes
        WHERE id = ?
    ");
    $stmt->execute([$quizId]);
    $quiz = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$quiz) {
        header('Location: /sections/exams/reports.php');
        exit;
    }
    
    // آمار کلی آزمون
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_attempts,
            AVG(score) as avg_score,
            MAX(score) as max_score,
            MIN(score) as min_score,
            AVG(total_score) as avg_total,
            AVG(time_taken) as avg_time
        FROM quiz_attempts
        WHERE quiz_id = ?
    ");
    $stmt->execute([$quizId]);
    $quizStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // لیست دانش‌آموزان شرکت کننده
    $stmt = $conn->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            qa.score,
            qa.total_score,
            qa.time_taken,
            qa.submitted_at,
            (qa.score / qa.total_score * 100) as percentage
        FROM quiz_attempts qa
        INNER JOIN users u ON qa.student_id = u.id
        WHERE qa.quiz_id = ?
        ORDER BY percentage DESC
    ");
    $stmt->execute([$quizId]);
    $participants = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تحلیل سوالات
    $stmt = $conn->prepare("
        SELECT 
            qq.id,
            qq.question_text,
            qq.question_type,
            qq.points,
            qq.question_order
        FROM quiz_questions qq
        WHERE qq.quiz_id = ? AND qq.is_active = 1
        ORDER BY qq.question_order ASC
    ");
    $stmt->execute([$quizId]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تحلیل پاسخ‌های هر سوال
    $questionAnalysis = [];
    foreach ($questions as $question) {
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_answers,
                SUM(
                    CASE 
                        WHEN JSON_EXTRACT(qa.answers, CONCAT('$.\"', ?, '\".is_correct')) = true 
                        THEN 1 
                        ELSE 0 
                    END
                ) as correct_answers
            FROM quiz_attempts qa
            WHERE qa.quiz_id = ?
        ");
        $stmt->execute([$question['id'], $quizId]);
        $analysis = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $correctRate = $analysis['total_answers'] > 0 
            ? ($analysis['correct_answers'] / $analysis['total_answers']) * 100 
            : 0;
        
        $questionAnalysis[$question['id']] = [
            'total_answers' => $analysis['total_answers'],
            'correct_answers' => $analysis['correct_answers'],
            'wrong_answers' => $analysis['total_answers'] - $analysis['correct_answers'],
            'correct_rate' => round($correctRate, 1),
            'difficulty' => $correctRate >= 75 ? 'easy' : ($correctRate >= 25 ? 'medium' : 'hard')
        ];
    }
    
} catch (PDOException $e) {
    error_log("Error fetching quiz details: " . $e->getMessage());
    header('Location: /sections/exams/reports.php');
    exit;
}

// محاسبات آماری
$avgPercentage = $quizStats['avg_total'] > 0 
    ? round(($quizStats['avg_score'] / $quizStats['avg_total']) * 100, 1) 
    : 0;
$maxPercentage = $quizStats['avg_total'] > 0 
    ? round(($quizStats['max_score'] / $quizStats['avg_total']) * 100, 1) 
    : 0;
$minPercentage = $quizStats['avg_total'] > 0 
    ? round(($quizStats['min_score'] / $quizStats['avg_total']) * 100, 1) 
    : 0;
$avgTimeMinutes = round($quizStats['avg_time'] / 60, 1);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>📊 جزئیات آزمون - <?php echo htmlspecialchars($quiz['title']); ?> - ستاره ماه</title>
  <link rel="stylesheet" href="/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/script.css" />
  
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  
  <style>

  
    .exam-builder-container {
      max-width:1400px;
      margin: 2rem auto;
      padding: 0 1rem;
    }
    
    .back-button {
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.9);
      padding: 0.8rem 1.5rem;
      border-radius: 15px;
      text-decoration: none;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 1.5rem;
      transition: all 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .back-button:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-2px);
    }
    
    .exam-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    }
    
    .exam-card-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      background: linear-gradient(135deg, #83eaf1, #63a4ff);
      color: #0b1220;
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }
    
    .exam-step-number {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 800;
      font-size: 0.9rem;
    }
    
    .exam-card-title {
      flex: 1;
    }
    
    .exam-card-title h2 {
      margin: 0;
      font-size: 1.1rem;
      font-weight: 800;
    }
    
    .exam-card-title p {
      margin: 0.3rem 0 0 0;
      opacity: 0.9;
      font-size: 0.9rem;
    }
    
    .exam-badge {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 700;
      font-size: 0.85rem;
    }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .stat-card {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 15px;
      padding: 1.2rem;
      text-align: center;
      transition: all 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-3px);
      background: rgba(255, 255, 255, 0.15);
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 800;
      color: #ffd93d;
      margin-bottom: 0.5rem;
      display: block;
    }
    
    .stat-label {
      color: rgba(255, 255, 255, 0.9);
      font-size: 0.9rem;
      font-weight: 600;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
      margin: 1rem 0;
    }
    
    .info-item {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 12px;
      padding: 1rem;
    }
    
    .info-label {
      color: rgba(255, 255, 255, 0.7);
      font-size: 0.85rem;
      margin-bottom: 0.3rem;
    }
    
    .info-value {
      color: white;
      font-size: 1.1rem;
      font-weight: 600;
    }
    
    .reports-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 0.5rem;
      margin-top: 1rem;
    }
    
    .reports-table thead th {
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.9);
      padding: 0.8rem;
      font-weight: 600;
      font-size: 0.9rem;
      border: none;
      text-align: right;
    }
    
    .reports-table thead th:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table thead th:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    .reports-table tbody tr {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      transition: all 0.3s ease;
    }
    
    .reports-table tbody tr:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateX(-3px);
    }
    
    .reports-table tbody td {
      padding: 0.8rem;
      color: rgba(255, 255, 255, 0.9);
      border: none;
      font-size: 0.9rem;
    }
    
    .reports-table tbody td:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table tbody td:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    .difficulty-badge {
      padding: 0.3rem 0.8rem;
      border-radius: 50px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .difficulty-easy {
      background: rgba(34, 197, 94, 0.2);
      color: #4ade80;
      border: 1px solid rgba(34, 197, 94, 0.3);
    }
    
    .difficulty-medium {
      background: rgba(251, 191, 36, 0.2);
      color: #fbbf24;
      border: 1px solid rgba(251, 191, 36, 0.3);
    }
    
    .difficulty-hard {
      background: rgba(248, 113, 113, 0.2);
      color: #f87171;
      border: 1px solid rgba(248, 113, 113, 0.3);
    }
    
    .chart-container {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 15px;
      padding: 1.5rem;
      height: 350px;
      position: relative;
    }
    
    .reports-main-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-bottom: 2rem;
    }
    
    .exam-btn {
      border: none;
      border-radius: 12px;
      padding: 0.8rem 1.5rem;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      font-family: inherit;
    }
    
    .exam-btn-primary {
      background: linear-gradient(135deg, #6bcf7f, #4d9de0);
      color: white;
      box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
    }
    
    .exam-btn-soft {
      background: rgba(139,92,246,.15);
      color: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .quick-actions {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      margin: 1rem 0;
    }
    
    @media (max-width: 1024px) {
      .reports-main-grid {
        grid-template-columns: 1fr;
      }
    }
    
    @media (max-width: 768px) {
      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .info-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#admin" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                </div>
            </div>

            <div class="auth-section">
                <div class="user-info glass-effect">
                    <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                    <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="exam-builder-container">
        
        <!-- دکمه بازگشت -->
        <a href="/sections/exams/reports.php" class="back-button">
            ← بازگشت به گزارش‌ها
        </a>

        <!-- عنوان آزمون -->
        <div class="hero glass-effect" style="text-align: center; padding: 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 0.5rem 0; font-size: 2rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                📊 <?php echo htmlspecialchars($quiz['title']); ?>
            </h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9);">تحلیل کامل و جزئیات آزمون</p>
        </div>

        <!-- اطلاعات آزمون -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">ℹ️</div>
                <div class="exam-card-title">
                    <h2>مشخصات آزمون</h2>
                    <p>جزئیات و تنظیمات</p>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">📅 تاریخ برگزاری</div>
                    <div class="info-value">
                        <?php echo formatJalaliDate($quiz['exam_date']); ?>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">⏰ ساعت شروع</div>
                    <div class="info-value"><?php echo $quiz['exam_time'] ?: 'تعیین نشده'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">⏱️ مدت زمان</div>
                    <div class="info-value"><?php echo $quiz['duration_minutes']; ?> دقیقه</div>
                </div>
                <div class="info-item">
                    <div class="info-label">❓ تعداد سوالات</div>
                    <div class="info-value"><?php echo $quiz['questions_count']; ?> سوال</div>
                </div>
                <div class="info-item">
                    <div class="info-label">⭐ کل امتیاز</div>
                    <div class="info-value"><?php echo $quiz['total_points']; ?> نمره</div>
                </div>
                <div class="info-item">
                    <div class="info-label">🔀 ترتیب تصادفی</div>
                    <div class="info-value"><?php echo $quiz['shuffle_questions'] ? 'فعال' : 'غیرفعال'; ?></div>
                </div>
            </div>
        </div>

        <!-- آمار عملکرد -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📊</div>
                <div class="exam-card-title">
                    <h2>آمار عملکرد کلی</h2>
                    <p>نتایج و آمار شرکت‌کنندگان</p>
                </div>
                <div class="exam-badge"><?php echo $quizStats['total_attempts']; ?> شرکت‌کننده</div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value"><?php echo $quizStats['total_attempts']; ?></span>
                    <div class="stat-label">تعداد شرکت‌کنندگان</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #6bcf7f;"><?php echo $avgPercentage; ?>%</span>
                    <div class="stat-label">میانگین نمرات</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #ffd93d;"><?php echo $maxPercentage; ?>%</span>
                    <div class="stat-label">بالاترین نمره</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value" style="color: #f87171;"><?php echo $minPercentage; ?>%</span>
                    <div class="stat-label">پایین‌ترین نمره</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $avgTimeMinutes; ?></span>
                    <div class="stat-label">میانگین زمان (دقیقه)</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value">
                        <?php echo $quiz['duration_minutes'] > 0 ? round(($avgTimeMinutes / $quiz['duration_minutes']) * 100, 0) : 0; ?>%
                    </span>
                    <div class="stat-label">درصد زمان استفاده شده</div>
                </div>
            </div>
        </div>

        <!-- تحلیل سوالات -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">❓</div>
                <div class="exam-card-title">
                    <h2>تحلیل سوالات</h2>
                    <p>بررسی دقیق هر سوال</p>
                </div>
                <div class="exam-badge"><?php echo count($questions); ?> سوال</div>
            </div>

            <?php if (empty($questions)): ?>
                <p style="text-align: center; color: rgba(255, 255, 255, 0.7); padding: 2rem;">
                    هنوز سوالی برای این آزمون ثبت نشده است.
                </p>
            <?php else: ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>شماره</th>
                        <th>متن سوال (خلاصه)</th>
                        <th>نوع</th>
                        <th>امتیاز</th>
                        <th>پاسخ صحیح</th>
                        <th>پاسخ غلط</th>
                        <th>درصد صحیح</th>
                        <th>سطح دشواری</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($questions as $index => $q): 
                        $analysis = $questionAnalysis[$q['id']];
                        $questionPreview = mb_substr(strip_tags($q['question_text']), 0, 50) . '...';
                        $typeLabel = $q['question_type'] == 'mcq' ? 'چندگزینه‌ای' : ($q['question_type'] == 'tf' ? 'درست/نادرست' : 'پاسخ کوتاه');
                        $difficultyLabel = $analysis['difficulty'] == 'easy' ? 'آسان' : ($analysis['difficulty'] == 'medium' ? 'متوسط' : 'دشوار');
                    ?>
                    <tr>
                        <td style="font-weight: 600;"><?php echo $index + 1; ?></td>
                        <td><?php echo htmlspecialchars($questionPreview); ?></td>
                        <td><?php echo $typeLabel; ?></td>
                        <td><?php echo $q['points']; ?> نمره</td>
                        <td style="color: #4ade80; font-weight: 600;"><?php echo $analysis['correct_answers']; ?></td>
                        <td style="color: #f87171; font-weight: 600;"><?php echo $analysis['wrong_answers']; ?></td>
                        <td style="font-weight: 600;">
                            <?php echo $analysis['correct_rate']; ?>%
                        </td>
                        <td>
                            <span class="difficulty-badge difficulty-<?php echo $analysis['difficulty']; ?>">
                                <?php echo $difficultyLabel; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- لیست شرکت‌کنندگان -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">👥</div>
                <div class="exam-card-title">
                    <h2>لیست شرکت‌کنندگان</h2>
                    <p>نمرات و زمان هر دانش‌آموز</p>
                </div>
            </div>

            <?php if (empty($participants)): ?>
                <p style="text-align: center; color: rgba(255, 255, 255, 0.7); padding: 2rem;">
                    هنوز دانش‌آموزی در این آزمون شرکت نکرده است.
                </p>
            <?php else: ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>رتبه</th>
                        <th>نام و نام خانوادگی</th>
                        <th>نمره</th>
                        <th>از</th>
                        <th>درصد</th>
                        <th>زمان (دقیقه)</th>
                        <th>تاریخ پاسخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    foreach ($participants as $p): 
                        $badge = '';
                        if ($rank == 1) $badge = '🥇 ';
                        elseif ($rank == 2) $badge = '🥈 ';
                        elseif ($rank == 3) $badge = '🥉 ';
                    ?>
                    <tr>
                        <td><?php echo $badge . $rank; ?></td>
                        <td style="font-weight: 600;">
                            <?php echo htmlspecialchars($p['first_name'] . ' ' . $p['last_name']); ?>
                        </td>
                        <td style="color: #6bcf7f; font-weight: 600;"><?php echo $p['score']; ?></td>
                        <td><?php echo $p['total_score']; ?></td>
                        <td style="font-weight: 700; font-size: 1.05rem;">
                            <?php echo round($p['percentage'], 1); ?>%
                        </td>
                        <td><?php echo round($p['time_taken'] / 60, 1); ?></td>
                        <td><?php echo formatJalaliDateTime($p['submitted_at']); ?></td>
                    </tr>
                    <?php 
                    $rank++;
                    endforeach; 
                    ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- اقدامات -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">⚡</div>
                <div class="exam-card-title">
                    <h2>اقدامات سریع</h2>
                    <p>عملیات مرتبط با این آزمون</p>
                </div>
            </div>

            <div class="quick-actions">
                <button class="exam-btn exam-btn-primary" onclick="editQuiz(<?php echo $quizId; ?>)">
                    ✏️ ویرایش آزمون
                </button>
                <button class="exam-btn exam-btn-soft" onclick="exportQuizReport()">
                    📥 خروجی Excel
                </button>
                <button class="exam-btn exam-btn-soft" onclick="window.print()">
                    🖨️ چاپ گزارش
                </button>
                <button class="exam-btn exam-btn-soft" onclick="sendQuizReports()">
                    📧 ارسال نتایج
                </button>
                <button class="exam-btn exam-btn-soft" onclick="window.location.href='/sections/exams/reports.php'">
                    📊 بازگشت به گزارش‌ها
                </button>
            </div>
        </div>
    </div>

    <script>
        // Initialize stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        function editQuiz(quizId) {
            window.location.href = `/sections/exams/builder.php?id=${quizId}`;
        }

        function exportQuizReport() {
            alert('📥 قابلیت خروجی Excel به زودی اضافه می‌شود');
        }

        function sendQuizReports() {
            alert('📧 قابلیت ارسال نتایج به زودی اضافه می‌شود');
        }

        document.addEventListener('DOMContentLoaded', function() {
            createStars();
        });
    </script>
</body>
</html>