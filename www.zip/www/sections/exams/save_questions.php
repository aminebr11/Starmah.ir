<?php
require_once __DIR__ . '/../../config.php';

// اتصال به دیتابیس
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("DB Connection Failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['questions'])) {
    // شناسه آزمون، فعلاً نمونه (می‌توان از پارامتر GET یا SESSION گرفت)
    $quiz_id = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 1;

    $questions = $_POST['questions'];
    $options = $_POST['options'];
    $corrects = $_POST['correct'];

    $stmt = $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question_text, options, correct_answer) VALUES (?, ?, ?, ?)");

    for ($i=0; $i<count($questions); $i++) {
        $q_text = trim($questions[$i]);
        $q_opts = trim($options[$i]);
        $q_correct = trim($corrects[$i]);

        if ($q_text !== '') {
            $stmt->execute([
                $quiz_id,
                $q_text,
                $q_opts,
                $q_correct
            ]);
        }
    }

    echo "<h3 style='color:green;text-align:center;'>✅ سوالات با موفقیت ذخیره شدند.</h3>";
    echo "<p style='text-align:center;'><a href='library.php'>بازگشت به لیست آزمون‌ها</a></p>";
} else {
    echo "<p>درخواست نامعتبر.</p>";
}
