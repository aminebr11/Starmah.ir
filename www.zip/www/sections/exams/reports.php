<?php
/* =============================================================
 * reports.php - صفحه گزارش‌ها و آمارهای آزمون‌ها (نسخه حرفه‌ای)
 * - متصل به دیتابیس واقعی
 * - تحلیل عملکرد دانش‌آموزان
 * - نمودارهای تحلیلی با Chart.js
 * - فیلترهای پیشرفته
 * - خروجی Excel/PDF
 * ============================================================= */

// Session Management
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Check admin access
if (!$isLoggedIn || $userType !== 'admin') {
    header('Location: /index.php');
    exit;
}

// Database Connection
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../functions.php';

// تابع تبدیل تاریخ میلادی به شمسی
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }
    if ($gm > 2) {
        $gy2 = $gy + 1;
    } else {
        $gy2 = $gy;
    }
    $days = (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];
    $jy += 33 * ((int)($days / 12053));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return array($jy, $jm, $jd);
}

function formatJalaliDate($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}

function formatJalaliDateTime($dateStr) {
    if (empty($dateStr)) return '-';
    $timestamp = strtotime($dateStr);
    if (!$timestamp) return '-';
    
    list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp));
    $time = date('H:i', $timestamp);
    return sprintf('%04d/%02d/%02d - %s', $jy, $jm, $jd, $time);
}

// Get filter parameters
$filterTimeRange = $_GET['time_range'] ?? 'all';
$filterQuizId = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : null;
$filterStudentId = isset($_GET['student_id']) ? intval($_GET['student_id']) : null;

// Build WHERE clause for filters
$whereConditions = ["qa.id IS NOT NULL"];
if ($filterQuizId) {
    $whereConditions[] = "qa.quiz_id = " . intval($filterQuizId);
}
if ($filterStudentId) {
    $whereConditions[] = "qa.student_id = " . intval($filterStudentId);
}

// Time range filter
switch ($filterTimeRange) {
    case 'week':
        $whereConditions[] = "qa.submitted_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
        break;
    case 'month':
        $whereConditions[] = "qa.submitted_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        break;
    case 'semester':
        $whereConditions[] = "qa.submitted_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)";
        break;
}

$whereClause = implode(' AND ', $whereConditions);

// ===== آمار کلی =====
try {
    // تعداد آزمون‌های فعال
    $stmt = $conn->query("SELECT COUNT(*) as total FROM quizzes WHERE is_active = 1");
    $totalActiveQuizzes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // تعداد کل سوالات
    $stmt = $conn->query("SELECT COUNT(*) as total FROM quiz_questions WHERE is_active = 1");
    $totalQuestions = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // تعداد دانش‌آموزان
    $stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE user_type = 'student' AND is_active = 1");
    $totalStudents = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // میانگین نمرات کل
    $stmt = $conn->query("
        SELECT 
            AVG((qa.score / qa.total_score) * 100) as avg_percentage,
            MAX((qa.score / qa.total_score) * 100) as max_percentage
        FROM quiz_attempts qa
        WHERE qa.total_score > 0
    ");
    $overallStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $classAverage = round($overallStats['avg_percentage'] ?? 0, 1);
    $highestScore = round($overallStats['max_percentage'] ?? 0, 1);
    
    // میزان مشارکت
    $stmt = $conn->query("
        SELECT 
            COUNT(DISTINCT qa.student_id) as participated,
            (SELECT COUNT(*) FROM users WHERE user_type = 'student' AND is_active = 1) as total
        FROM quiz_attempts qa
    ");
    $participationData = $stmt->fetch(PDO::FETCH_ASSOC);
    $participationRate = $participationData['total'] > 0 
        ? round(($participationData['participated'] / $participationData['total']) * 100, 0) 
        : 0;

} catch (PDOException $e) {
    error_log("Error fetching overall stats: " . $e->getMessage());
    $totalActiveQuizzes = 0;
    $totalQuestions = 0;
    $totalStudents = 0;
    $classAverage = 0;
    $highestScore = 0;
    $participationRate = 0;
}

// ===== لیست آزمون‌ها با آمار =====
try {
    $stmt = $conn->query("
        SELECT 
            q.id,
            q.title,
            q.exam_date,
            q.exam_time,
            q.duration_minutes,
            q.questions_count,
            q.is_active,
            COUNT(DISTINCT qa.student_id) as participants,
            AVG(qa.score) as avg_score,
            MAX(qa.score) as max_score,
            MIN(qa.score) as min_score,
            AVG(qa.total_score) as avg_total_score
        FROM quizzes q
        LEFT JOIN quiz_attempts qa ON q.id = qa.quiz_id
        GROUP BY q.id
        ORDER BY q.exam_date DESC, q.id DESC
        LIMIT 20
    ");
    $quizzesList = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching quizzes list: " . $e->getMessage());
    $quizzesList = [];
}

// ===== عملکرد دانش‌آموزان برتر =====
try {
    $topWhere = ["u.user_type = 'student'", "qa.total_score > 0"];
    if ($filterQuizId) {
        $topWhere[] = "qa.quiz_id = " . intval($filterQuizId);
    }
    
    $topWhereClause = implode(' AND ', $topWhere);
    
    $stmt = $conn->query("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            COUNT(qa.id) as total_attempts,
            AVG((qa.score / qa.total_score) * 100) as avg_percentage,
            SUM(qa.score) as total_score
        FROM users u
        INNER JOIN quiz_attempts qa ON u.id = qa.student_id
        WHERE {$topWhereClause}
        GROUP BY u.id
        
    ");
    $topStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching top students: " . $e->getMessage());
    $topStudents = [];
}

// ===== آمار برای نمودار روند عملکرد =====
try {
    $perfWhere = ["qa.submitted_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)", "qa.total_score > 0"];
    if ($filterQuizId) {
        $perfWhere[] = "qa.quiz_id = " . intval($filterQuizId);
    }
    if ($filterStudentId) {
        $perfWhere[] = "qa.student_id = " . intval($filterStudentId);
    }
    
    $perfWhereClause = implode(' AND ', $perfWhere);
    
    $stmt = $conn->query("
        SELECT 
            DATE(qa.submitted_at) as exam_date,
            AVG((qa.score / qa.total_score) * 100) as avg_percentage
        FROM quiz_attempts qa
        WHERE {$perfWhereClause}
        GROUP BY DATE(qa.submitted_at)
        ORDER BY exam_date ASC
    ");
    $performanceData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل تاریخ‌ها به شمسی برای نمودار
    $performanceDataWithJalali = [];
    foreach ($performanceData as $row) {
        $jalaliDate = formatJalaliDate($row['exam_date']);
        $performanceDataWithJalali[] = [
            'exam_date' => $row['exam_date'],
            'jalali_date' => $jalaliDate,
            'avg_percentage' => $row['avg_percentage']
        ];
    }
} catch (PDOException $e) {
    error_log("Error fetching performance data: " . $e->getMessage());
    $performanceDataWithJalali = [];
}

// ===== توزیع نمرات =====
try {
    $stmt = $conn->query("
        SELECT 
            CASE
                WHEN (qa.score / qa.total_score) * 100 >= 90 THEN 'excellent'
                WHEN (qa.score / qa.total_score) * 100 >= 75 THEN 'good'
                WHEN (qa.score / qa.total_score) * 100 >= 60 THEN 'average'
                ELSE 'weak'
            END as grade_category,
            COUNT(*) as count
        FROM quiz_attempts qa
        WHERE qa.total_score > 0
        GROUP BY grade_category
    ");
    $gradeDistribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $distribution = ['excellent' => 0, 'good' => 0, 'average' => 0, 'weak' => 0];
    foreach ($gradeDistribution as $row) {
        $distribution[$row['grade_category']] = intval($row['count']);
    }
} catch (PDOException $e) {
    error_log("Error fetching grade distribution: " . $e->getMessage());
    $distribution = ['excellent' => 0, 'good' => 0, 'average' => 0, 'weak' => 0];
}

// ===== تحلیل سوالات =====
try {
    // محاسبه درصد پاسخ صحیح برای هر سوال
    $stmt = $conn->query("
        SELECT 
            qq.id as question_id,
            qq.question_text,
            qq.quiz_id,
            COUNT(*) as total_answers,
            SUM(
                CASE 
                    WHEN JSON_EXTRACT(qa.answers, CONCAT('$.\"', qq.id, '\".is_correct')) = true 
                    THEN 1 
                    ELSE 0 
                END
            ) as correct_answers
        FROM quiz_questions qq
        LEFT JOIN quiz_attempts qa ON qq.quiz_id = qa.quiz_id
        WHERE qq.is_active = 1
        GROUP BY qq.id
        HAVING total_answers > 0
    ");
    $questionsAnalysis = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $easyQuestions = 0;
    $mediumQuestions = 0;
    $hardQuestions = 0;
    
    foreach ($questionsAnalysis as $q) {
        $correctRate = ($q['correct_answers'] / $q['total_answers']) * 100;
        if ($correctRate >= 75) {
            $easyQuestions++;
        } elseif ($correctRate >= 25) {
            $mediumQuestions++;
        } else {
            $hardQuestions++;
        }
    }
    
    $totalAnalyzedQuestions = count($questionsAnalysis);
    $easyPercentage = $totalAnalyzedQuestions > 0 ? round(($easyQuestions / $totalAnalyzedQuestions) * 100, 0) : 0;
    $mediumPercentage = $totalAnalyzedQuestions > 0 ? round(($mediumQuestions / $totalAnalyzedQuestions) * 100, 0) : 0;
    $hardPercentage = $totalAnalyzedQuestions > 0 ? round(($hardQuestions / $totalAnalyzedQuestions) * 100, 0) : 0;
    
} catch (PDOException $e) {
    error_log("Error analyzing questions: " . $e->getMessage());
    $easyPercentage = 0;
    $mediumPercentage = 0;
    $hardPercentage = 0;
}

// ===== آمار زمان‌بندی =====
try {
    $stmt = $conn->query("
        SELECT 
            AVG(qa.time_taken / q.questions_count) as avg_time_per_question,
            COUNT(CASE WHEN qa.time_taken <= q.duration_minutes * 60 THEN 1 END) as completed_in_time,
            COUNT(*) as total_attempts
        FROM quiz_attempts qa
        INNER JOIN quizzes q ON qa.quiz_id = q.id
        WHERE q.questions_count > 0
    ");
    $timingStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $avgTimePerQuestion = round(($timingStats['avg_time_per_question'] ?? 0) / 60, 1); // به دقیقه
    $completionRate = $timingStats['total_attempts'] > 0 
        ? round(($timingStats['completed_in_time'] / $timingStats['total_attempts']) * 100, 0) 
        : 0;
} catch (PDOException $e) {
    error_log("Error fetching timing stats: " . $e->getMessage());
    $avgTimePerQuestion = 0;
    $completionRate = 0;
}

// ===== لیست کامل دانش‌آموزان برای فیلتر =====
try {
    $stmt = $conn->query("
        SELECT id, first_name, last_name 
        FROM users 
        WHERE user_type = 'student' AND is_active = 1
        ORDER BY first_name, last_name
    ");
    $allStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching students list: " . $e->getMessage());
    $allStudents = [];
}

// تبدیل داده‌ها به JSON برای JavaScript
$performanceDataJson = json_encode($performanceDataWithJalali);
$distributionJson = json_encode(array_values($distribution));
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>📈 گزارش‌ها و آمار آزمون‌ها - ستاره ماه</title>
  <link rel="stylesheet" href="/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/script.css" />
  
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  
  <style>
    /* استایل‌های اضافی برای گزارش‌ها */
    .exam-builder-container {
      max-width:1400px;
      margin: 2rem auto;
      padding: 0 1rem;
    }
    
    .exam-subnav {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      margin: 1rem 0 2rem 0;
      padding: 1rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .exam-subnav-links {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }
    
    .exam-subnav-link {
      background: rgba(255, 255, 255, 0.9);
      color: #1a1a1a;
      padding: 0.8rem 1.5rem;
      border-radius: 15px;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s ease;
      border: 1px solid rgba(0, 0, 0, 0.1);
      font-size: 0.95rem;
    }
    
    .exam-subnav-link:hover {
      background: rgba(255, 255, 255, 1);
      transform: translateY(-2px);
      color: #000;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    .exam-subnav-link.active {
      background: linear-gradient(135deg, #6bcf7f, #4d9de0);
      color: white;
      border-color: transparent;
      box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
    }
    
    /* Grid برای محتوای اصلی */
    .reports-main-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-bottom: 2rem;
    }
    
    @media (max-width: 1024px) {
      .reports-main-grid {
        grid-template-columns: 1fr;
      }
    }
    
    /* کارت‌ها */
    .exam-card {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 20px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    }
    
    .exam-card-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      background: linear-gradient(135deg, #83eaf1, #63a4ff);
      color: #0b1220;
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }
    
    .exam-step-number {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 800;
      font-size: 0.9rem;
    }
    
    .exam-card-title {
      flex: 1;
    }
    
    .exam-card-title h2 {
      margin: 0;
      font-size: 1.1rem;
      font-weight: 800;
      color: #0b1220;
    }
    
    .exam-card-title p {
      margin: 0.3rem 0 0 0;
      opacity: 0.8;
      font-size: 0.9rem;
      color: #0b1220;
    }
    
    .exam-badge {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 700;
      font-size: 0.85rem;
    }
    
    /* Stats Cards */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .stat-card {
      background: rgba(255, 255, 255, 0.85);
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 15px;
      padding: 1.2rem;
      text-align: center;
      transition: all 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-3px);
      background: rgba(255, 255, 255, 0.95);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 800;
      color: #2563eb;
      margin-bottom: 0.5rem;
      display: block;
    }
    
    .stat-label {
      color: #1a1a1a;
      font-size: 0.9rem;
      font-weight: 600;
    }
    
    /* دکمه‌ها */
    .exam-btn {
      border: none;
      border-radius: 12px;
      padding: 0.8rem 1.5rem;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      font-family: inherit;
    }
    
    .exam-btn-primary {
      background: linear-gradient(135deg, #6bcf7f, #4d9de0);
      color: white;
      box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
    }
    
    .exam-btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6);
    }
    
    .exam-btn-soft {
      background: rgba(139,92,246,.15);
      color: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .exam-btn-mini {
      background: #111827;
      color: #e5e7eb;
      font-size: 0.85rem;
      padding: 0.5rem 1rem;
    }
    
    /* جداول */
    .reports-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 0.5rem;
      margin-top: 1rem;
    }
    
    .reports-table thead th {
      background: rgba(255, 255, 255, 0.9);
      color: #1a1a1a;
      padding: 0.8rem;
      font-weight: 600;
      font-size: 0.9rem;
      border: none;
      text-align: right;
    }
    
    .reports-table thead th:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table thead th:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    .reports-table tbody tr {
      background: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
    }
    
    .reports-table tbody tr:hover {
      background: rgba(255, 255, 255, 0.95);
      transform: translateX(-3px);
    }
    
    .reports-table tbody td {
      padding: 0.8rem;
      color: #1a1a1a;
      border: none;
      font-size: 0.9rem;
    }
    
    .reports-table tbody td:first-child {
      border-radius: 8px 0 0 8px;
    }
    
    .reports-table tbody td:last-child {
      border-radius: 0 8px 8px 0;
    }
    
    /* Status Badges */
    .status-badge {
      padding: 0.3rem 0.8rem;
      border-radius: 50px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    
    .status-active {
      background: rgba(34, 197, 94, 0.2);
      color: #4ade80;
      border: 1px solid rgba(34, 197, 94, 0.3);
    }
    
    .status-inactive {
      background: rgba(156, 163, 175, 0.2);
      color: #9ca3af;
      border: 1px solid rgba(156, 163, 175, 0.3);
    }
    
    /* نمودارها */
    .chart-container {
      background: rgba(255, 255, 255, 0.7);
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 15px;
      padding: 1.5rem;
      height: 350px;
      position: relative;
    }
    
    /* فیلترها */
    .filter-section {
      background: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 15px;
      padding: 1rem;
      margin-bottom: 1.5rem;
    }
    
    .filter-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
    }
    
    .filter-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: #1a1a1a;
      font-size: 0.9rem;
    }
    
    .filter-group select {
      width: 100%;
      padding: 0.6rem 0.8rem;
      border-radius: 8px;
      border: 1px solid rgba(0, 0, 0, 0.2);
      background: rgba(255, 255, 255, 0.9);
      color: #1a1a1a;
      font-family: inherit;
      font-size: 0.9rem;
    }
    
    .filter-group select:focus {
      border-color: #2563eb;
      outline: none;
      background: rgba(255, 255, 255, 1);
    }
    
    /* اقدامات سریع */
    .quick-actions {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      margin: 1rem 0;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .exam-builder-container {
        padding: 0.5rem;
      }
      
      .reports-main-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
      }
      
      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .quick-actions {
        flex-direction: column;
      }
      
      .reports-table {
        font-size: 0.8rem;
      }
      
      .reports-table th,
      .reports-table td {
        padding: 0.5rem;
      }
    }
  </style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <!-- Desktop Menu -->
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮 بازی‌ها</a>
                    <a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی موبایل" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Auth Section -->
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Reports Container -->
    <div class="exam-builder-container">
        
        <!-- زیرناوبری آزمون‌ساز -->
        <div class="exam-subnav">
            <div class="exam-subnav-links">
                <a href="/sections/exams/create_ai_exam.php" class="exam-subnav-link">🤖 ساخت خودکار (AI)</a>
                <a href="/sections/exams/builder.php" class="exam-subnav-link">🛠️ آزمون‌ساز دستی</a>
                <a href="/sections/exams/library.php" class="exam-subnav-link">📚 کتابخانه آزمون‌ها</a>
                <a href="/sections/exams/reports.php" class="exam-subnav-link active">📈 گزارش‌ها</a>
            </div>
        </div>

        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">📈 گزارش‌ها و آمار حرفه‌ای</h1>
            <p style="margin: 0; color: #1a1a1a; font-size: 1.2rem; font-weight: 600;">تحلیل عملکرد دقیق، بررسی نقاط قوت و ضعف، و گزارش‌گیری جامع</p>
        </div>

        <!-- آمار کلی -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📊</div>
                <div class="exam-card-title">
                    <h2>آمار کلی سیستم</h2>
                    <p>خلاصه وضعیت کلی عملکرد</p>
                </div>
                <div class="exam-badge">زنده و به‌روز</div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value"><?php echo $totalActiveQuizzes; ?></span>
                    <div class="stat-label">آزمون فعال</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $totalQuestions; ?></span>
                    <div class="stat-label">کل سوالات</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $totalStudents; ?></span>
                    <div class="stat-label">دانش‌آموز</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $participationRate; ?>%</span>
                    <div class="stat-label">میزان مشارکت</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $highestScore; ?>%</span>
                    <div class="stat-label">بالاترین نمره</div>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $classAverage; ?>%</span>
                    <div class="stat-label">میانگین کلاس</div>
                </div>
            </div>
        </div>

        <!-- فیلترها -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">🔍</div>
                <div class="exam-card-title">
                    <h2>فیلترهای پیشرفته</h2>
                    <p>محدود کردن و تحلیل داده‌های خاص</p>
                </div>
            </div>

            <form method="GET" action="" class="filter-section">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label>بازه زمانی</label>
                        <select name="time_range" id="timeRange">
                            <option value="all" <?php echo $filterTimeRange === 'all' ? 'selected' : ''; ?>>همه زمان‌ها</option>
                            <option value="week" <?php echo $filterTimeRange === 'week' ? 'selected' : ''; ?>>هفته گذشته</option>
                            <option value="month" <?php echo $filterTimeRange === 'month' ? 'selected' : ''; ?>>ماه گذشته</option>
                            <option value="semester" <?php echo $filterTimeRange === 'semester' ? 'selected' : ''; ?>>نیمسال جاری</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>آزمون خاص</label>
                        <select name="quiz_id" id="quizId">
                            <option value="">همه آزمون‌ها</option>
                            <?php foreach ($quizzesList as $quiz): ?>
                            <option value="<?php echo $quiz['id']; ?>" <?php echo $filterQuizId == $quiz['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($quiz['title']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>دانش‌آموز خاص</label>
                        <select name="student_id" id="studentId">
                            <option value="">همه دانش‌آموزان</option>
                            <?php foreach ($allStudents as $student): ?>
                            <option value="<?php echo $student['id']; ?>" <?php echo $filterStudentId == $student['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="quick-actions">
                    <button type="submit" class="exam-btn exam-btn-primary">🔍 اعمال فیلتر</button>
                    <button type="button" class="exam-btn exam-btn-soft" onclick="window.location.href='/sections/exams/reports.php'">🔄 پاک کردن</button>
                    <button type="button" class="exam-btn exam-btn-soft" onclick="exportToExcel()">📥 خروجی Excel</button>
                    <button type="button" class="exam-btn exam-btn-soft" onclick="window.print()">🖨️ چاپ گزارش</button>
                </div>
            </form>
        </div>

        <!-- نمودارهای تحلیلی -->
        <div class="reports-main-grid">
            <!-- نمودار روند عملکرد -->
            <div class="exam-card">
                <div class="exam-card-header">
                    <div class="exam-step-number">📈</div>
                    <div class="exam-card-title">
                        <h2>روند عملکرد کلاس</h2>
                        <p>تغییرات میانگین نمرات در ۳۰ روز اخیر</p>
                    </div>
                </div>
                
                <div class="chart-container">
                    <canvas id="performanceChart"></canvas>
                </div>
            </div>

            <!-- توزیع نمرات -->
            <div class="exam-card">
                <div class="exam-card-header">
                    <div class="exam-step-number">🎯</div>
                    <div class="exam-card-title">
                        <h2>توزیع نمرات</h2>
                        <p>تحلیل سطح عملکرد دانش‌آموزان</p>
                    </div>
                </div>
                
                <div class="chart-container">
                    <canvas id="distributionChart"></canvas>
                </div>
            </div>
        </div>

        <!-- جدول آزمون‌ها -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">📋</div>
                <div class="exam-card-title">
                    <h2>فهرست آزمون‌ها</h2>
                    <p>جزئیات تمام آزمون‌های برگزار شده</p>
                </div>
                <div class="exam-badge"><?php echo count($quizzesList); ?> آزمون</div>
            </div>

            <?php if (empty($quizzesList)): ?>
                <p style="text-align: center; color: #555; padding: 2rem; font-weight: 600;">
                    هنوز آزمونی برگزار نشده است.
                </p>
            <?php else: ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>عنوان آزمون</th>
                        <th>تاریخ</th>
                        <th>مدت</th>
                        <th>سوالات</th>
                        <th>شرکت‌کنندگان</th>
                        <th>میانگین</th>
                        <th>بالاترین</th>
                        <th>پایین‌ترین</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($quizzesList as $quiz): 
                        $avgScore = $quiz['avg_score'] ?? 0;
                        $avgTotal = $quiz['avg_total_score'] ?? 1;
                        $avgPercentage = $avgTotal > 0 ? round(($avgScore / $avgTotal) * 100, 1) : 0;
                        
                        $maxScore = $quiz['max_score'] ?? 0;
                        $maxPercentage = $avgTotal > 0 ? round(($maxScore / $avgTotal) * 100, 1) : 0;
                        
                        $minScore = $quiz['min_score'] ?? 0;
                        $minPercentage = $avgTotal > 0 ? round(($minScore / $avgTotal) * 100, 1) : 0;
                    ?>
                    <tr>
                        <td style="font-weight: 600;"><?php echo htmlspecialchars($quiz['title']); ?></td>
                        <td><?php echo formatJalaliDate($quiz['exam_date']); ?></td>
                        <td><?php echo $quiz['duration_minutes']; ?> دقیقه</td>
                        <td><?php echo $quiz['questions_count']; ?> سوال</td>
                        <td><?php echo $quiz['participants']; ?> نفر</td>
                        <td style="color: #6bcf7f; font-weight: 600;"><?php echo $avgPercentage; ?>%</td>
                        <td style="color: #ffd93d; font-weight: 600;"><?php echo $maxPercentage; ?>%</td>
                        <td style="color: #f87171; font-weight: 600;"><?php echo $quiz['participants'] > 0 ? $minPercentage . '%' : '-'; ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $quiz['is_active'] ? 'active' : 'inactive'; ?>">
                                <?php echo $quiz['is_active'] ? 'فعال' : 'غیرفعال'; ?>
                            </span>
                        </td>
                        <td>
                            <button class="exam-btn exam-btn-mini" onclick="viewQuizDetails(<?php echo $quiz['id']; ?>)">👁️ جزئیات</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- دانش‌آموزان برتر -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">🏆</div>
                <div class="exam-card-title">
                    <h2>دانش‌آموزان برتر</h2>
                    <p>رتبه‌بندی بر اساس میانگین عملکرد</p>
                </div>
                <div class="exam-badge"><?php echo count($topStudents); ?> نفر برتر</div>
            </div>

            <?php if (empty($topStudents)): ?>
                <p style="text-align: center; color: #555; padding: 2rem; font-weight: 600;">
                    هنوز آزمونی انجام نشده است.
                </p>
            <?php else: ?>
            <table class="reports-table">
                <thead>
                    <tr>
                        <th>رتبه</th>
                        <th>نام و نام خانوادگی</th>
                        <th>تعداد آزمون‌ها</th>
                        <th>میانگین نمره</th>
                        <th>مجموع امتیاز</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    foreach ($topStudents as $student): 
                        $badge = '';
                        if ($rank == 1) $badge = '🥇';
                        elseif ($rank == 2) $badge = '🥈';
                        elseif ($rank == 3) $badge = '🥉';
                    ?>
                    <tr>
                        <td style="font-size: 1.5rem;"><?php echo $badge ?: $rank; ?></td>
                        <td style="font-weight: 600;">
                            <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                        </td>
                        <td><?php echo $student['total_attempts']; ?> آزمون</td>
                        <td style="color: #6bcf7f; font-weight: 700; font-size: 1.1rem;">
                            <?php echo round($student['avg_percentage'], 1); ?>%
                        </td>
                        <td><?php echo $student['total_score']; ?> امتیاز</td>
                        <td>
                            <button class="exam-btn exam-btn-mini" onclick="viewStudentDetails(<?php echo $student['id']; ?>)">
                                📊 عملکرد فردی
                            </button>
                        </td>
                    </tr>
                    <?php 
                    $rank++;
                    endforeach; 
                    ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- تحلیل سوالات و زمان‌بندی -->
        <div class="reports-main-grid">
            <!-- تحلیل سوالات -->
            <div class="exam-card">
                <div class="exam-card-header">
                    <div class="exam-step-number">❓</div>
                    <div class="exam-card-title">
                        <h2>تحلیل سوالات</h2>
                        <p>سطح دشواری سوالات</p>
                    </div>
                </div>
                
                <div class="stats-grid" style="grid-template-columns: 1fr 1fr 1fr;">
                    <div class="stat-card">
                        <span class="stat-value" style="color: #4ade80;"><?php echo $easyPercentage; ?>%</span>
                        <div class="stat-label">سوالات آسان<br><small>پاسخ صحیح >75%</small></div>
                    </div>
                    <div class="stat-card">
                        <span class="stat-value" style="color: #fbbf24;"><?php echo $mediumPercentage; ?>%</span>
                        <div class="stat-label">سوالات متوسط<br><small>پاسخ صحیح 25-75%</small></div>
                    </div>
                    <div class="stat-card">
                        <span class="stat-value" style="color: #f87171;"><?php echo $hardPercentage; ?>%</span>
                        <div class="stat-label">سوالات دشوار<br><small>پاسخ صحیح <25%</small></div>
                    </div>
                </div>
            </div>

            <!-- آمار زمان‌بندی -->
            <div class="exam-card">
                <div class="exam-card-header">
                    <div class="exam-step-number">⏰</div>
                    <div class="exam-card-title">
                        <h2>آمار زمان‌بندی</h2>
                        <p>میانگین زمان پاسخ‌دهی</p>
                    </div>
                </div>
                
                <div class="stats-grid" style="grid-template-columns: 1fr 1fr;">
                    <div class="stat-card">
                        <span class="stat-value"><?php echo $avgTimePerQuestion; ?></span>
                        <div class="stat-label">دقیقه به ازای سوال<br><small>میانگین کلاس</small></div>
                    </div>
                    <div class="stat-card">
                        <span class="stat-value"><?php echo $completionRate; ?>%</span>
                        <div class="stat-label">تکمیل در زمان<br><small>پاسخ به همه سوالات</small></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- اقدامات سریع -->
        <div class="exam-card">
            <div class="exam-card-header">
                <div class="exam-step-number">⚡</div>
                <div class="exam-card-title">
                    <h2>اقدامات سریع</h2>
                    <p>دسترسی سریع به عملیات مهم</p>
                </div>
            </div>

            <div class="quick-actions">
                <button class="exam-btn exam-btn-primary" onclick="window.location.href='/sections/exams/builder.php'">
                    ➕ آزمون جدید
                </button>
                <button class="exam-btn exam-btn-soft" onclick="viewAllStudentsReport()">
                    👥 گزارش کامل دانش‌آموزان
                </button>
                <button class="exam-btn exam-btn-soft" onclick="exportDetailedReport()">
                    📤 گزارش تفصیلی (PDF)
                </button>
                <button class="exam-btn exam-btn-soft" onclick="window.location.href='/sections/exams/library.php'">
                    📚 کتابخانه آزمون‌ها
                </button>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');

            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                    }
                });

                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    }
                });
            }
        });

        // Initialize stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // نمودار روند عملکرد
        const performanceData = <?php echo $performanceDataJson; ?>;
        const performanceCtx = document.getElementById('performanceChart');
        
        if (performanceCtx && performanceData.length > 0) {
            const labels = performanceData.map(d => d.jalali_date);  // استفاده از تاریخ شمسی
            const data = performanceData.map(d => parseFloat(d.avg_percentage));
            
            new Chart(performanceCtx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'میانگین درصد نمرات',
                        data: data,
                        borderColor: '#6bcf7f',
                        backgroundColor: 'rgba(107, 207, 127, 0.1)',
                        tension: 0.4,
                        fill: true,
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBackgroundColor: '#6bcf7f',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            labels: {
                                color: '#1a1a1a',
                                font: { family: 'Vazirmatn', size: 12, weight: 'bold' }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                color: '#1a1a1a',
                                font: { weight: 'bold' },
                                callback: function(value) { return value + '%'; }
                            },
                            grid: { color: 'rgba(0, 0, 0, 0.1)' }
                        },
                        x: {
                            ticks: { 
                                color: '#1a1a1a',
                                font: { weight: 'bold' }
                            },
                            grid: { color: 'rgba(0, 0, 0, 0.1)' }
                        }
                    }
                }
            });
        }

        // نمودار توزیع نمرات
        const distributionData = <?php echo $distributionJson; ?>;
        const distributionCtx = document.getElementById('distributionChart');
        
        if (distributionCtx) {
            new Chart(distributionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['عالی (90-100%)', 'خوب (75-89%)', 'متوسط (60-74%)', 'ضعیف (<60%)'],
                    datasets: [{
                        data: distributionData,
                        backgroundColor: [
                            'rgba(74, 222, 128, 0.8)',
                            'rgba(251, 191, 36, 0.8)',
                            'rgba(59, 130, 246, 0.8)',
                            'rgba(248, 113, 113, 0.8)'
                        ],
                        borderColor: [
                            '#4ade80',
                            '#fbbf24',
                            '#3b82f6',
                            '#f87171'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                color: '#1a1a1a',
                                font: { family: 'Vazirmatn', size: 12, weight: 'bold' },
                                padding: 15
                            }
                        }
                    }
                }
            });
        }

        // Functions
        function viewQuizDetails(quizId) {
            window.location.href = `/sections/exams/quiz_details.php?id=${quizId}`;
        }

        function viewStudentDetails(studentId) {
            window.location.href = `/sections/exams/student_report.php?id=${studentId}`;
        }

        function exportToExcel() {
            alert('📥 قابلیت خروجی Excel به زودی اضافه می‌شود');
            // TODO: Implement Excel export
        }

        // جایگزین توابع قبلی در reports.php

function viewAllStudentsReport() {
    // هدایت به صفحه گزارش کامل دانش‌آموزان
    window.location.href = '/sections/exams/students_full_report.php';
}

function exportDetailedReport() {
    // هدایت به اسکریپت ساخت PDF
    window.open('/sections/exams/export_pdf.php', '_blank');
}

        

        // Navigation helper
        function navigateToSection(section) {
            window.location.href = `/index.php#${section}`;
        }

        // Initialize everything
        document.addEventListener('DOMContentLoaded', function() {
            createStars();
        });
    </script>
</body>
</html>