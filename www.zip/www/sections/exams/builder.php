<?php
/* =============================================================
 * Rewritten builder.php (UI from builder(3).php, logic from builder.php)
 * Notes:
 * - All APIs and logic preserved from original builder.php (JS kept intact).
 * - UI/UX, layout, and styles are adapted from builder(3).php.
 * - Added two top menu rows and exam subnav as in builder(3).php.
 * - Minor non-functional HTML class additions to align with JS selectors (e.g., 'pill', 'tf-pill').
 * - Fixes: Improved Jalali calendar, fixed MCQ question adding, fixed question editing.
 * ============================================================= */

// --- Session for greeting (UI only; no auth logic change) ---
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>🧪 آزمون‌ساز هوشمند - ستاره ماه</title>
  <link rel="stylesheet" href="/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/script.css" />
  <style>
    /* استایل‌های اضافی برای آزمون‌ساز */
    .exam-builder-container {
      max-width:1400px;
      margin: 2rem auto;
      padding: 0 1rem;
    }
    
    .exam-subnav {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      margin: 1rem 0 2rem 0;
      padding: 1rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .exam-subnav-links {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }
    
    .exam-subnav-link {
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.9);
      padding: 0.8rem 1.5rem;
      border-radius: 15px;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.2);
      font-size: 0.95rem;
    }
    
    .exam-subnav-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-2px);
      color: white;
    }
    
    .exam-subnav-link.active {
      background: linear-gradient(135deg, #6bcf7f, #4d9de0);
      color: white;
      border-color: transparent;
      box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
    }
    
    /* Grid برای محتوای اصلی */
    .exam-grid {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: 2rem;
      margin-top: 2rem;
    }
    
    @media (max-width: 1024px) {
      .exam-grid {
        grid-template-columns: 1fr;
      }
    }
    
    /* کارت‌های مراحل */
    .exam-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    }
    
    .exam-card-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      background: linear-gradient(135deg, #83eaf1, #63a4ff);
      color: #0b1220;
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }
    
    .exam-step-number {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 800;
      font-size: 0.9rem;
    }
    
    .exam-card-title {
      flex: 1;
    }
    
    .exam-card-title h2 {
      margin: 0;
      font-size: 1.1rem;
      font-weight: 800;
    }
    
    .exam-card-title p {
      margin: 0.3rem 0 0 0;
      opacity: 0.9;
      font-size: 0.9rem;
    }
    
    .exam-badge {
      background: rgba(255,255,255,.7);
      padding: 0.5rem 0.8rem;
      border-radius: 50px;
      font-weight: 700;
      font-size: 0.85rem;
    }
    
    /* فرم‌ها */
    .exam-form-grid {
      display: grid;
      grid-template-columns: minmax(300px,1fr) minmax(300px,1fr) 160px 160px;
      gap: 1rem;
      align-items: start;
      margin-bottom: 1.5rem;
    }
    
    @media (max-width: 1100px) {
      .exam-form-grid {
        grid-template-columns: 1fr 1fr;
      }
    }
    
    @media (max-width: 640px) {
      .exam-form-grid {
        grid-template-columns: 1fr;
      }
    }
    
    .exam-form-group {
      margin-bottom: 1rem;
    }
    
    .exam-form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: rgba(255, 255, 255, 0.9);
    }
    
    .exam-form-group input,
    .exam-form-group select,
    .exam-form-group textarea {
      width: 100%;
      padding: 0.8rem 1rem;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      background: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.9);
      font-family: inherit;
      transition: all 0.3s ease;
    }
    
    .exam-form-group input:focus,
    .exam-form-group textarea:focus {
      border-color: #ffd93d;
      outline: none;
      background: rgba(255, 255, 255, 0.2);
      box-shadow: 0 0 20px rgba(255, 217, 61, 0.4);
    }
    
    .exam-form-group textarea {
      min-height: 80px;
      resize: vertical;
    }
    
    /* دکمه‌ها */
    .exam-btn {
      border: none;
      border-radius: 12px;
      padding: 0.8rem 1.5rem;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      font-family: inherit;
    }
    
    .exam-btn-primary {
      background: linear-gradient(135deg, #6bcf7f, #4d9de0);
      color: white;
      box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
    }
    
    .exam-btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6);
    }
    
    .exam-btn-soft {
      background: rgba(139,92,246,.15);
      color: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .exam-btn-mini {
      background: #111827;
      color: #e5e7eb;
      font-size: 0.85rem;
      padding: 0.5rem 1rem;
    }
    
    .exam-btn-danger {
      background: rgba(244,63,94,.15);
      color: #fecaca;
      border: 1px solid rgba(244,63,94,.3);
    }
    
    .exam-btn:disabled {
      opacity: 0.6;
      pointer-events: none;
    }
    
    /* Pills و Tags */
    .exam-pills {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
      margin: 1rem 0;
    }
    
    .exam-pill {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 50px;
      padding: 0.6rem 1rem;
      cursor: pointer;
      color: rgba(255, 255, 255, 0.8);
      font-size: 0.9rem;
      transition: all 0.3s ease;
    }
    
    .exam-pill.active {
      background: linear-gradient(135deg, #8b5cf6, #06b6d4);
      color: white;
      border: none;
    }
    
    /* Summary Panel */
    .exam-aside {
      position: sticky;
      top: 2rem;
      height: max-content;
    }
    
    .exam-summary-card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      padding: 1.5rem;
    }
    
    .exam-summary-card h3 {
      margin: 0 0 1rem 0;
      color: rgba(255, 255, 255, 0.95);
      font-weight: 700;
    }
    
    .exam-summary-item {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 12px;
      padding: 0.8rem;
      margin-bottom: 0.8rem;
      color: rgba(255, 255, 255, 0.9);
      font-size: 0.9rem;
    }
    
    .exam-kpis {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.5rem;
      margin-top: 1rem;
    }
    
    .exam-kpi {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 12px;
      padding: 0.8rem;
      text-align: center;
      font-size: 0.85rem;
    }
    
    .exam-kpi strong {
      display: block;
      font-size: 1.1rem;
      color: #ffd93d;
    }
    
    /* سوالات */
    .exam-questions-list {
      margin-top: 1rem;
    }
    
    .exam-question-item {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 12px;
      padding: 1rem;
      margin-bottom: 1rem;
    }
    
    .exam-question-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
    }
    
    .exam-question-content {
      flex: 1;
    }
    
    .exam-question-actions {
      display: flex;
      gap: 0.5rem;
    }
    
    .exam-question-title {
      font-weight: 700;
      margin-bottom: 0.5rem;
      color: rgba(255, 255, 255, 0.95);
    }
    
    .exam-question-text {
      margin-bottom: 0.8rem;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .exam-question-options {
      margin-top: 0.5rem;
    }
    
    .exam-question-options ol {
      margin: 0.5rem 0 0 0;
      padding-right: 1.5rem;
      color: rgba(255, 255, 255, 0.7);
    }
    
    .exam-question-options li {
      margin-bottom: 0.3rem;
    }
    
    /* سوئیچ‌ها */
    .exam-switches {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1rem;
      margin: 1rem 0;
    }
    
    @media (max-width: 900px) {
      .exam-switches {
        grid-template-columns: 1fr;
      }
    }
    
    .exam-switch-card {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 12px;
      padding: 0.8rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    /* گزینه‌ها */
    .exam-options-container {
      margin-top: 1rem;
    }
    
    .exam-option {
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 0.5rem;
      align-items: center;
      margin-bottom: 0.8rem;
    }
    
    /* True/False */
    .exam-tf-choices {
      display: flex;
      gap: 0.8rem;
      flex-wrap: wrap;
      margin-top: 0.8rem;
    }
    
    .exam-tf-pill {
      border: 1px solid rgba(255, 255, 255, 0.3);
      border-radius: 50px;
      padding: 0.8rem 1.2rem;
      cursor: pointer;
      transition: all 0.3s ease;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .exam-tf-pill.true.active {
      background: rgba(34,197,94,.35);
      border-color: rgba(34,197,94,.55);
      color: white;
    }
    
    .exam-tf-pill.false.active {
      background: rgba(239,68,68,.35);
      border-color: rgba(239,68,68,.55);
      color: white;
    }
    
    /* تقویم جلالی - طرح ساده‌تر و جذاب‌تر با قابلیت موبایل */
    .jdp {
      position: relative;
      display: flex;
      gap: 0.3rem;
      align-items: center;
      font-family: Tahoma, sans-serif;
    }
    .jdp input#jdp-input {
      flex: 1;
      height: 40px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.3);
      background: rgba(255,255,255,0.05);
      color: #fff;
      padding: 0.5rem 0.8rem;
      outline: none;
      font-size: 0.9rem;
    }
    .jdp input#jdp-input::placeholder {
      color: rgba(255,255,255,0.5);
    }
    .jdp .jdp-btn {
      height: 40px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.3);
      background: rgba(255,255,255,0.05);
      color: #fff;
      padding: 0 0.8rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      font-size: 1rem;
    }
   .jdp-pop {
  background: #333; /* خاکستری تیره */
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.3);
  width: 280px;
  padding: 1rem;
  z-index: 10000;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  margin-top: 0;
   }
    .jdp-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 0.8rem;
    }
    .jdp-nav {
      border: none;
      background: transparent;
      color: #fff;
      padding: 0.5rem;
      cursor: pointer;
      font-size: 1rem;
    }
    .jdp-title {
      display: flex;
      gap: 0.3rem;
    }
    .jdp-select {
      background: transparent;
      color:#000;
      border: none;
      padding: 0.3rem;
      font-size: 0.9rem;
    }
    .jdp-grid {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 0.3rem;
    }
    .jdp-wd {
      text-align: center;
      font-size: 0.8rem;
      color: rgba(255,255,255,0.6);
      padding: 0.3rem 0;
    }
    .jdp-day {
      background: transparent;
      border: 1px solid transparent;
      border-radius: 50%;
      padding: 0.5rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;
      font-size: 0.85rem;
      color: #fff;
    }
    .jdp-day:hover {
      background: rgba(255,255,255,0.1);
    }
    .jdp-day.muted {
      opacity: 0.3;
      cursor: default;
    }
    .jdp-day.selected {
      background: #4d9de0;
      color: #fff;
      border-color: transparent;
    }
    .jdp-day.today {
      border: 1px solid #6bcf7f;
    }
    .jdp-foot {
      display: flex;
      gap: 0.3rem;
      margin-top: 0.8rem;
      justify-content: center;
    }
    .jdp-mini {
      border: none;
      background: transparent;
      color: #fff;
      padding: 0.3rem 0.8rem;
      cursor: pointer;
      font-size: 0.8rem;
      opacity: 0.8;
    }
    .jdp-mini:hover {
      opacity: 1;
    }
    @media (max-width: 480px) {
      .jdp-pop {
        width: 100%;
        left: 0;
        right: 0;
        margin: 0 auto;
      }
      .jdp-grid {
        gap: 0.2rem;
      }
      .jdp-day {
        padding: 0.4rem;
        font-size: 0.8rem;
      }
    }
    
    /* ===== UI Fixes: enforce Tahoma and comfortable sizes for question fields ===== */
    .exam-form-group input,
    .exam-form-group select,
    .exam-form-group textarea,
    .exam-option input,
    .option input {
      font-family: Tahoma, sans-serif !important;
      font-size: 0.95rem;
      line-height: 1.6;
      padding: 0.75rem 0.9rem;
    }
    .exam-option input,
    .option input {
      min-height: 40px;
      width: 100%;
    }
    
    /* Restrict font change ONLY to action buttons in preview */
    .exam-question-actions .exam-btn { font-family: inherit !important; }
  </style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
  <!-- Main Navigation (مطابق index.php) -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <!-- تغییر لینک لوگو -->
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <!-- Desktop Menu با لینک‌های صحیح -->
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮 بازی‌ها</a>
                    <a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mobile Menu با لینک‌های صحیح -->
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی ناوبری" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Auth Section -->
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>
        
           <!-- Exam Builder Container -->
    <div class="exam-builder-container">
        
        <!-- زیرناوبری چهارگانه آزمون‌ساز -->
        <div class="exam-subnav">
            <div class="exam-subnav-links">
                <a href="/sections/exams/create_ai_exam.php" class="exam-subnav-link">🤖 ساخت خودکار (AI)</a>
                <a href="/sections/exams/builder.php" class="exam-subnav-link active">🛠️ آزمون‌ساز دستی</a>
                <a href="/sections/exams/library.php" class="exam-subnav-link">📚 کتابخانه آزمون‌ها</a>
                <a href="/sections/exams/reports.php" class="exam-subnav-link">📈 گزارش‌ها</a>
            </div>
        </div>

        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">🧪 آزمون‌ساز هوشمند</h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9); font-size: 1.2rem;">ساخت آزمون مثل بازی؛ ساده، رنگی و هیجان‌انگیز</p>
        </div>

        <!-- Main Grid -->
        <div class="exam-grid">
            <div>
                <!-- Step 1 -->
                <div class="exam-card">
                    <div class="exam-card-header">
                        <div class="exam-step-number">1️⃣</div>
                        <div class="exam-card-title">
                            <h2>مشخصات آزمون</h2>
                            <p>عنوان، تاریخ، زمان و قوانین</p>
                        </div>
                        <div id="badge" class="exam-badge">در حال تکمیل…</div>
                    </div>

                    <div class="exam-form-grid">
                        <div class="exam-form-group">
                            <label>🎯 عنوان آزمون</label>
                            <input id="examTitle" type="text" placeholder="مثال: آزمون ریاضی فصل ۲" />
                        </div>
                        <div class="exam-form-group">
                            <label>📅 تاریخ برگزاری (شمسی)</label>
                            <div class="jdp">
                                <input id="jdp-input" type="text" inputmode="numeric" placeholder="مثلاً 1404/06/15" />
                                <input id="examDate" type="hidden" />
                                <button id="jdp-toggle" class="jdp-btn">📅</button>
                                <div id="jdp-pop" class="jdp-pop" hidden>
                                    <div class="jdp-head">
                                        <button id="jdp-prev" class="jdp-nav">◀️</button>
                                        <div class="jdp-title">
                                            <select id="jdp-year" class="jdp-select"></select>
                                            <select id="jdp-month" class="jdp-select"></select>
                                        </div>
                                        <button id="jdp-next" class="jdp-nav">▶️</button>
                                    </div>
                                    <div class="jdp-grid" id="jdp-grid">
                                        <div class="jdp-wd">ش</div><div class="jdp-wd">ی</div><div class="jdp-wd">د</div><div class="jdp-wd">س</div><div class="jdp-wd">چ</div><div class="jdp-wd">پ</div><div class="jdp-wd">ج</div>
                                    </div>
                                    <div class="jdp-foot">
                                        <button id="jdp-today" class="jdp-mini">امروز</button>
                                        <button id="jdp-clear" class="jdp-mini">پاک کردن</button>
                                        <div class="jdp-gap"></div>
                                        <button id="jdp-close" class="jdp-mini">بستن</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="exam-form-group">
                            <label>⏰ ساعت برگزاری</label>
                            <input id="examTime" type="time" value="08:30" />
                        </div>
                        <div class="exam-form-group">
                            <label>⏳ مدت (دقیقه)</label>
                            <input id="examDuration" type="number" min="1" value="20" />
                        </div>
                    </div>
                    
                    <div class="exam-switches">
                        <div class="exam-switch-card">
                            <span>👀 قابل مشاهده</span>
                            <input id="examVisible" type="checkbox" checked />
                        </div>
                        <div class="exam-switch-card">
                            <span>🔀 ترتیب تصادفی</span>
                            <input id="examShuffle" type="checkbox" checked />
                        </div>
                        <div class="exam-switch-card">
                            <span>⚠️ نمره منفی</span>
                            <input id="examNegative" type="checkbox" />
                        </div>
                    </div>
                    
                    <button id="saveStep1" class="exam-btn exam-btn-primary" style="display: block; margin: 0 auto;">💾 ذخیره مشخصات آزمون</button>
                </div>

                <!-- Step 2 -->
                <div class="exam-card">
                    <div class="exam-card-header">
                        <div class="exam-step-number">2️⃣</div>
                        <div class="exam-card-title">
                            <h2>افزودن سوالات</h2>
                            <p>انواع سوال و گزینه‌ها</p>
                        </div>
                        <div id="qCount" class="exam-badge">۰ سوال</div>
                    </div>

                    <div class="exam-pills">
                        <div class="exam-pill active" data-type="mcq">چهارگزینه‌ای</div>
                        <div class="exam-pill" data-type="tf">درست/نادرست</div>
                        <div class="exam-pill" data-type="short">پاسخ کوتاه</div>
                    </div>

                    <div class="exam-form-group">
                        <label>🖊️ متن سوال</label>
                        <textarea id="qText" placeholder="سوال خود را اینجا بنویسید..."></textarea>
                    </div>

                    <div id="mcqBox">
                        <div class="exam-options-container" id="mcqOptions"></div>
                        <button id="addOpt" class="exam-btn exam-btn-soft">➕ افزودن گزینه جدید</button>
                    </div>

                    <div id="tfBox" style="display:none">
                        <div class="exam-tf-choices">
                            <div class="exam-tf-pill true active" data-val="true">✅ درست</div>
                            <div class="exam-tf-pill false" data-val="false">❌ نادرست</div>
                        </div>
                    </div>

                    <div id="shortBox" style="display:none">
                        <div class="exam-form-group">
                            <label>📝 پاسخ مورد انتظار (اختیاری)</label>
                            <input id="shortExpected" type="text" placeholder="پاسخ صحیح را برای تصحیح خودکار بنویسید" />
                        </div>
                    </div>

                    <div class="exam-form-group" style="max-width:200px">
                        <label>🏅 امتیاز</label>
                        <input id="qPoint" type="number" min="1" value="1" />
                    </div>

                    <button id="saveQuestion" class="exam-btn exam-btn-primary">🎉 افزودن سوال به لیست</button>
                    <button id="cancelEdit" class="exam-btn exam-btn-danger" style="display:none; margin-right:0.5rem">لغو ویرایش</button>
                </div>

                <!-- Step 3 -->
                <div class="exam-card">
                    <div class="exam-card-header">
                        <div class="exam-step-number">3️⃣</div>
                        <div class="exam-card-title">
                            <h2>پیش‌نمایش سوالات</h2>
                            <p>ویرایش و حذف</p>
                        </div>
                    </div>

                    <div id="qList" class="exam-questions-list"></div>
                </div>
            </div>

            <!-- Aside -->
            <aside class="exam-aside">
                <div class="exam-summary-card">
                    <h3>📊 خلاصه آزمون</h3>
                    <div class="exam-summary-item">عنوان: <span id="smTitle">—</span></div>
                    <div class="exam-summary-item">تاریخ: <span id="smDate">—</span></div>
                    <div class="exam-summary-item">ترتیب تصادفی: <span id="smShuffle">—</span></div>
                    <div class="exam-summary-item">نمره منفی: <span id="smNegative">—</span></div>
                    <div class="exam-summary-item">مدت: <span id="smDuration">—</span> دقیقه</div>
                    <div class="exam-summary-item">تعداد سوالات: <span id="smCount">—</span></div>
                    <div class="exam-kpis">
                        <div class="exam-kpi">حداکثر امتیاز سوال<br><strong id="kMax">—</strong></div>
                        <div class="exam-kpi">حداقل امتیاز سوال<br><strong id="kMin">—</strong></div>
                        <div class="exam-kpi">میانگین امتیاز<br><strong id="kAvg">—</strong></div>
                    </div>
                    <button id="publishBtn" class="exam-btn exam-btn-primary disabled" disabled style="display: block; margin: 0 auto; margin-top:1rem; width:100%">🚀 انتشار آزمون</button>
                    <p id="publishHint" style="text-align:center; font-size:0.85rem; opacity:0.8; margin-top:0.5rem">برای انتشار: مرحله ۱ را ذخیره کنید و حداقل ۱ سوال اضافه کنید.</p>
                </div>
            </aside>
        </div>
    </div>

    <!-- Template: MCQ Option Row -->
    <template id="tplOpt">
        <div class="exam-option option">
            <input type="text" placeholder="متن گزینه" />
            <button data-role="correct" class="exam-btn exam-btn-soft">✔️ صحیح</button>
            <button data-role="remove" class="exam-btn exam-btn-danger">🗑️</button>
        </div>
    </template>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');
            const menuOverlay = document.getElementById('menuOverlay');

            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                        if (menuOverlay) menuOverlay.classList.add('show');
                    }
                });

                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });

                mobileDropdown.addEventListener('click', function(e) {
                    if (e.target.tagName === 'A') {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });
            }
        });

        // Initialize stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // ====== CONFIG ======
        const API = '/sections/exams/api/quiz.php';

        // ====== STATE ======
        let QUIZ_ID = 0;
        let examSaved = false;
        let questions = [];
        let qType = 'mcq';
        let tfCorrect = true;
        let editingIndex = -1;

        // ====== HELPERS ======
        var $ = s => document.querySelector(s);
        var $$ = s => Array.from(document.querySelectorAll(s));

        function toast(msg) { alert(msg); }

        function updateSummary() {
            $('#smTitle').textContent = $('#examTitle').value || '—';
            $('#smDuration').textContent = $('#examDuration').value || '—';
            $('#smShuffle').textContent = $('#examShuffle').checked ? 'بله' : 'خیر';
            $('#smNegative').textContent = $('#examNegative').checked ? 'بله' : 'خیر';
            $('#smDate').textContent = $('#examDate').value || '—';
            $('#smCount').textContent = String(questions.length);
            const pts = questions.map(q => q.points);
            $('#kMax').textContent = pts.length ? Math.max(...pts) : '—';
            $('#kMin').textContent = pts.length ? Math.min(...pts) : '—';
            $('#kAvg').textContent = pts.length ? (pts.reduce((a, b) => a + b, 0) / pts.length).toFixed(1) : '—';
        }

        function canPublish() {
            return examSaved && $('#examTitle').value.trim() && $('#examDate').value && $('#examTime').value && questions.length > 0;
        }

        function updatePublishState() {
            const btn = $('#publishBtn');
            const hint = $('#publishHint');
            if (canPublish()) {
                btn.classList.remove('disabled');
                btn.removeAttribute('disabled');
                hint.textContent = 'همه‌چیز آماده است! می‌توانید منتشر کنید.';
            } else {
                btn.classList.add('disabled');
                btn.setAttribute('disabled', 'disabled');
                hint.textContent = 'برای انتشار: مرحله ۱ را ذخیره کنید و حداقل ۱ سوال اضافه کنید.';
            }
        }

        // ====== API FETCH WRAPPER ======
        async function callAPI(action, data) {
            console.log('Action:', action, 'Data:', data); // لاگ برای دیباگ
            const res = await fetch(API + '?action=' + encodeURIComponent(action), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data || {})
            });
            const text = await res.text();
            try {
                return JSON.parse(text);
            } catch (err) {
                console.error('RAW RESPONSE:', text);
                toast('❌ پاسخ نامعتبر از سرور — مسیر/خطای PHP را بررسی کنید.');
                return { ok: false, error: 'BAD_JSON', raw: text };
            }
        }

        // ====== LOAD QUESTIONS ======
        async function loadQuestions() {
            if (!QUIZ_ID) return;
            const r = await callAPI('get_questions', { quiz_id: QUIZ_ID });
            if (r.ok && r.questions) {
                questions = r.questions.map(q => ({
                    id: q.id,
                    type: q.question_type,
                    text: q.question_text,
                    points: q.points,
                    options: q.question_data?.options || [],
                    correct: q.question_data?.correct,
                    expected: q.question_data?.expected
                }));
                renderList();
            }
        }

        // ====== STEP 1 SAVE ======
        async function saveExamInfo() {
            const payload = {
                title: $('#examTitle').value.trim(),
                exam_date: $('#examDate').value || null,
                exam_time: $('#examTime').value || null,
                duration_minutes: parseInt($('#examDuration').value || '30', 10),
                is_visible: $('#examVisible').checked ? 1 : 0,
                shuffle_questions: $('#examShuffle').checked ? 1 : 0,
                negative_marking: $('#examNegative').checked ? 1 : 0
            };
            if (!payload.title || !payload.exam_date || !payload.exam_time) {
                toast('اطلاعات آزمون را کامل وارد کنید');
                return;
            }
            const act = (QUIZ_ID > 0) ? 'update_quiz' : 'create_quiz';
            if (QUIZ_ID > 0) payload.quiz_id = QUIZ_ID;
            const r = await callAPI(act, payload);
            if (!r.ok) {
                toast('خطا در ذخیره آزمون: ' + (r.message || r.error));
                return;
            }
            QUIZ_ID = r.quiz_id || QUIZ_ID;
            examSaved = true;
            document.getElementById('badge').textContent = 'ذخیره شد ✔️';
            updateSummary();
            updatePublishState();
            loadQuestions(); // لود سوالات پس از ذخیره آزمون
        }
        window.saveExamInfo = saveExamInfo;
        document.getElementById('saveStep1').addEventListener('click', saveExamInfo);

        ['examTitle', 'examDate', 'examTime', 'examDuration', 'examShuffle', 'examNegative', 'examVisible'].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('input', () => { updateSummary(); updatePublishState(); });
            el.addEventListener('change', () => { updateSummary(); updatePublishState(); });
        });

        // ====== TYPE TABS ======
        $$('.exam-pill').forEach(p => p.addEventListener('click', () => {
            $$('.exam-pill').forEach(x => x.classList.remove('active'));
            p.classList.add('active');
            const t = p.dataset.type;
            document.getElementById('mcqBox').style.display = (t === 'mcq') ? 'block' : 'none';
            document.getElementById('tfBox').style.display = (t === 'tf') ? 'block' : 'none';
            document.getElementById('shortBox').style.display = (t === 'short') ? 'block' : 'none';
            qType = t;
        }));

        // ====== MCQ OPTIONS ======
        function addOptionRow(text = '', correct = false) {
            const tpl = document.getElementById('tplOpt');
            const node = tpl.content.firstElementChild.cloneNode(true);
            const inp = node.querySelector('input');
            inp.value = text;
            if (correct) {
                node.setAttribute('data-correct', '1');
                const btn = node.querySelector('[data-role="correct"]');
                btn.setAttribute('data-active', '1');
                btn.textContent = '✔️ صحیح (انتخاب شد)';
            }
            node.querySelector('[data-role="correct"]').addEventListener('click', (ev) => {
                const btn = ev.currentTarget;
                const active = btn.getAttribute('data-active') === '1';
                btn.setAttribute('data-active', active ? '0' : '1');
                btn.textContent = active ? '✔️ صحیح' : '✔️ صحیح (انتخاب شد)';
                node.setAttribute('data-correct', active ? '0' : '1');
            });
            node.querySelector('[data-role="remove"]').addEventListener('click', () => {
                const all = $$('#mcqOptions .option');
                if (all.length <= 2) {
                    toast('حداقل ۲ گزینه لازم است.');
                    return;
                }
                node.remove();
            });
            document.getElementById('mcqOptions').appendChild(node);
        }
        ['','','',''].forEach(() => addOptionRow());
        document.getElementById('addOpt').addEventListener('click', () => addOptionRow());

        // ====== TF colored ======
        $$('#tfBox .exam-tf-pill').forEach(el => {
            el.addEventListener('click', () => {
                $$('#tfBox .exam-tf-pill').forEach(x => x.classList.remove('active'));
                el.classList.add('active');
                tfCorrect = (el.dataset.val === 'true');
            });
        });

        // ====== CRUD ======
        function resetQuestionForm() {
            document.getElementById('qText').value = '';
            document.getElementById('qPoint').value = '1';
            document.getElementById('mcqOptions').innerHTML = '';
            ['','','',''].forEach(() => addOptionRow());
            $$('#tfBox .exam-tf-pill').forEach(x => x.classList.remove('active'));
            document.querySelector('#tfBox .exam-tf-pill.true')?.classList.add('active');
            tfCorrect = true;
            document.getElementById('shortExpected').value = '';
            editingIndex = -1;
            document.getElementById('saveQuestion').textContent = '🎉 افزودن سوال به لیست';
            document.getElementById('cancelEdit').style.display = 'none';
        }

        function renderList() {
            const wrap = document.getElementById('qList');
            wrap.innerHTML = '';
            questions.forEach((q, idx) => {
                const div = document.createElement('div');
                div.className = 'exam-question-item pill-sum';
                const typeFa = q.type === 'mcq' ? 'چهارگزینه‌ای' : (q.type === 'tf' ? 'درست/نادرست' : 'پاسخ کوتاه');
                let detail = '';
                if (q.type === 'mcq') {
                    detail = '<ol style="margin:6px 0 0 0; padding-right:20px">' + q.options.map(o => `<li>${o.text} ${o.correct ? '✔️' : ''}</li>`).join('') + '</ol>';
                } else if (q.type === 'tf') {
                    detail = `<div style="margin-top:6px">پاسخ صحیح: ${q.correct ? '✅ درست' : '❌ نادرست'}</div>`;
                } else {
                    detail = `<div style="margin-top:6px">پاسخ مورد انتظار: ${q.expected || '—'}</div>`;
                }
                div.innerHTML = `<div class="exam-question-header"><div class="exam-question-content"><div class="exam-question-title"><b>سوال ${idx + 1}</b> — ${typeFa} — 🏅 ${q.points}</div><div class="exam-question-text">${q.text}</div>${detail}</div><div class="exam-question-actions"><button class="exam-btn exam-btn-mini" data-edit="${idx}">✏️ ویرایش</button><button class="exam-btn exam-btn-mini exam-btn-danger" data-del="${idx}">🗑️ حذف</button></div></div>`;
                wrap.appendChild(div);
            });
            document.getElementById('qCount').textContent = questions.length + ' سوال';
            updateSummary();
            updatePublishState();
        }

        function loadQuestionToForm(q) {
            $$('.exam-pill').forEach(p => p.classList.toggle('active', p.dataset.type === q.type));
            const t = q.type;
            document.getElementById('mcqBox').style.display = (t === 'mcq') ? 'block' : 'none';
            document.getElementById('tfBox').style.display = (t === 'tf') ? 'block' : 'none';
            document.getElementById('shortBox').style.display = (t === 'short') ? 'block' : 'none';
            document.getElementById('qText').value = q.text;
            document.getElementById('qPoint').value = q.points;
            if (t === 'mcq') {
                document.getElementById('mcqOptions').innerHTML = '';
                q.options.forEach(o => addOptionRow(o.text, o.correct));
            } else if (t === 'tf') {
                tfCorrect = !!q.correct;
                $$('#tfBox .exam-tf-pill').forEach(x => x.classList.remove('active'));
                document.querySelector(`#tfBox .exam-tf-pill.${tfCorrect ? 'true' : 'false'}`)?.classList.add('active');
            } else {
                document.getElementById('shortExpected').value = q.expected || '';
            }
            document.getElementById('saveQuestion').textContent = '💾 ذخیره تغییرات';
            document.getElementById('cancelEdit').style.display = 'inline-block';
        }

        document.getElementById('qList').addEventListener('click', async (e) => {
            const t = e.target;
            if (t.dataset.edit) {
                editingIndex = parseInt(t.dataset.edit, 10);
                loadQuestionToForm(questions[editingIndex]);
            }
            if (t.dataset.del) {
                const i = parseInt(t.dataset.del, 10);
                const q = questions[i];
                const qid = q.id || q.question_id;
                if (qid) {
                    const r = await callAPI('delete_question', { id: qid, quiz_id: QUIZ_ID, points: q.points });
                    if (!r.ok) {
                        toast('حذف سوال ناموفق بود: ' + (r.message || r.error));
                        return;
                    }
                }
                questions.splice(i, 1);
                renderList();
            }
        });
        document.getElementById('cancelEdit').addEventListener('click', () => resetQuestionForm());

        document.getElementById('saveQuestion').addEventListener('click', async () => {
            if (!QUIZ_ID) { toast('ابتدا مرحله ۱ را ذخیره کنید.'); return; }
            const text = document.getElementById('qText').value.trim();
            if (!text) { toast('متن سوال را بنویسید'); return; }
            const points = parseInt(document.getElementById('qPoint').value || '1', 10) || 1;
            let q = { type: qType, text, points };

            if (qType === 'mcq') {
                const rows = $$('#mcqOptions .exam-option');
                console.log('MCQ Options:', rows); // لاگ برای دیباگ
                const options = rows.map(r => {
                    const input = r.querySelector('input');
                    return input ? { text: input.value.trim(), correct: r.getAttribute('data-correct') === '1' } : null;
                }).filter(o => o && o.text);
                if (options.length < 2) { toast('حداقل ۲ گزینه معتبر وارد کنید.'); return; }
                if (!options.some(o => o.correct)) { toast('حداقل یک گزینه صحیح مشخص کنید.'); return; }
                q.options = options;
            } else if (qType === 'tf') {
                q.correct = !!tfCorrect;
            } else {
                q.expected = document.getElementById('shortExpected').value.trim();
            }

            if (editingIndex > -1) {
                const curr = questions[editingIndex];
                if (!curr || !curr.id) {
                    toast('شناسهٔ سؤال برای ویرایش پیدا نشد.');
                    return;
                }

                const base = {
                    id: curr.id,
                    question_text: q.text,
                    question_type: q.type,
                    points: q.points,
                    question_order: editingIndex + 1,
                    is_active: 1
                };

                if (q.type === 'mcq') base.question_data = { options: q.options };
                if (q.type === 'tf') base.question_data = { correct: !!q.correct };
                if (q.type === 'short') base.question_data = { expected: q.expected || '' };

                console.log('Updating question:', base); // لاگ برای دیباگ
                const r = await callAPI('update_question', base);
                if (!r.ok) {
                    toast('ویرایش سوال ناموفق بود: ' + (r.message || r.error));
                    return;
                }

                questions[editingIndex] = { ...q, id: curr.id };
                resetQuestionForm();
                renderList();
            } else {
                const base = {
                    quiz_id: QUIZ_ID,
                    question_text: q.text,
                    question_type: q.type,
                    points: q.points,
                    question_order: (questions.length + 1),
                    is_active: 1
                };

                if (q.type === 'mcq') base.question_data = { options: q.options };
                if (q.type === 'tf') base.question_data = { correct: !!q.correct };
                if (q.type === 'short') base.question_data = { expected: q.expected || '' };

                console.log('Adding question:', base); // لاگ برای دیباگ
                const r = await callAPI('add_question', base);
                if (!r.ok) {
                    toast('ثبت سوال ناموفق بود: ' + (r.message || r.error));
                    return;
                }

                questions.push({ ...q, id: r.question_id });
                renderList();
                resetQuestionForm();
            }
        });

        // ====== PUBLISH ======
        async function publishExam() {
            if (!canPublish()) { toast('شرایط انتشار کامل نیست.'); return; }
            const r = await callAPI('publish', { quiz_id: QUIZ_ID });
            if (!r.ok) { toast('خطا در انتشار: ' + (r.message || r.error)); return; }
            toast('✅ آزمون منتشر شد');
        }
        window.publishExam = publishExam;
        document.getElementById('publishBtn').addEventListener('click', publishExam);

        // ====== Jalali Calendar + Manual Input ======
        (function() {
            const pad = n => (n < 10 ? '0' + n : '' + n);
            var $ = s => document.querySelector(s);

            const inpt = $('#jdp-input');
            const pop = $('#jdp-pop');
            const btn = $('#jdp-toggle');
            const grid = $('#jdp-grid');
            const selY = $('#jdp-year');
            const selM = $('#jdp-month');
            const prev = $('#jdp-prev');
            const next = $('#jdp-next');
            const todayBtn = $('#jdp-today');
            const clearBtn = $('#jdp-clear');
            const closeBtn = $('#jdp-close');
            const iso = $('#examDate');

            // Gregorian <-> Jalali converters
            function div(a, b) { return ~~(a / b); }
            function j2g(jy, jm, jd) {
                jy += 1595;
                const days = -355668 + 365 * jy + div(jy, 33) * 8 + div((jy % 33 + 3), 4) + jd + (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30 + 186));
                let gy = 400 * div(days, 146097), rem = days % 146097;
                if (rem > 36524) { gy += 100; rem -= 36524; gy += 100 * div(rem, 36524); rem %= 36524; if (rem >= 365) rem++; }
                gy += 4 * div(rem, 1461); rem %= 1461;
                if (rem > 365) { gy += div(rem - 1, 365); rem = (rem - 1) % 365; }
                const gd = rem + 1, sal = [0, 31, ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                let gm = 0, acc = 0;
                for (let i = 1; i <= 12; i++) { if (gd <= acc + sal[i]) { gm = i; break; } acc += sal[i]; }
                return { gy, gm, gd: gd - acc };
            }
            function g2j(gy, gm, gd) {
                function d2j(jdn) {
                    let depoch = jdn - 2121446;
                    let cycle = div(depoch, 1029983);
                    let cyear = depoch % 1029983;
                    let ycycle = (cyear == 1029982) ? 2820 : div(2816 * cyear + 1031337, 1028522);
                    let jy = (33 * cycle) + ycycle + 475;
                    if (jy <= 0) jy -= 1;
                    let yday = jdn - jalali_jdn(jy, 1, 1) + 1;
                    let jm = (yday <= 186) ? Math.ceil(yday / 31) : Math.ceil((yday - 186) / 30) + 6;
                    let jd = jdn - jalali_jdn(jy, jm, 1) + 1;
                    return { jy, jm, jd };
                }
                function gregorian_jdn(y, m, d) {
                    let a = div((14 - m), 12);
                    let y2 = y + 4800 - a;
                    let m2 = m + 12 * a - 3;
                    return d + div((153 * m2 + 2), 5) + 365 * y2 + div(y2, 4) - div(y2, 100) + div(y2, 400) - 32045;
                }
                function jalali_jdn(y, m, d) {
                    let epbase = y - 474;
                    let epyear = 474 + (epbase % 2820);
                    return d + ((m <= 7) ? ((m - 1) * 31) : (((m - 1) * 30) + 6)) + div((epyear * 682 - 110), 2816) + (epyear - 1) * 365 + 1948320 - 1;
                }
                const jdn = gregorian_jdn(gy, gm, gd);
                return d2j(jdn);
            }
            function isJLeap(Y) { return ((((Y + 38) * 31) % 128) < 31); }
            function dimJ(Y, M) { return (M <= 6 ? 31 : (M <= 11 ? 30 : (isJLeap(Y) ? 30 : 29))); }
            function jMonthStartWeekday(jy, jm) {
                const g = j2g(jy, jm, 1);
                const dt = new Date(g.gy, g.gm - 1, g.gd);
                return (dt.getDay() + 6) % 7; // شنبه=0
            }

            // State
            let JY = 1404, JM = 1, JD = null;
            const startYear = 1390, endYear = 1410;

            // Fill selects
            for (let Y = endYear; Y >= startYear; Y--) {
                const o = document.createElement('option');
                o.value = Y;
                o.textContent = Y;
                selY.appendChild(o);
            }
            const months = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
            months.forEach((mm, i) => {
                const o = document.createElement('option');
                o.value = (i + 1);
                o.textContent = mm;
                selM.appendChild(o);
            });

            function renderGrid() {
                grid.querySelectorAll('.jdp-day').forEach(el => el.remove());
                const start = jMonthStartWeekday(JY, JM);
                const days = dimJ(JY, JM);
                for (let b = 0; b < start; b++) {
                    const div = document.createElement('div');
                    div.className = 'jdp-day muted';
                    div.innerHTML = '&nbsp;';
                    grid.appendChild(div);
                }
                for (let d = 1; d <= days; d++) {
                    const cell = document.createElement('div');
                    cell.className = 'jdp-day';
                    cell.textContent = d;
                    const now = new Date();
                    const jnow = g2j(now.getFullYear(), now.getMonth() + 1, now.getDate());
                    if (jnow.jy === JY && jnow.jm === JM && jnow.jd === d) cell.classList.add('today');
                    if (JD && JY === selectedJY && JM === selectedJM && d === selectedJD) cell.classList.add('selected');
                    cell.addEventListener('click', () => {
                        JD = d;
                        selectedJY = JY;
                        selectedJM = JM;
                        selectedJD = JD;
                        inpt.value = `${JY}/${pad(JM)}/${pad(JD)}`;
                        const g = j2g(JY, JM, JD);
                        iso.value = `${g.gy}-${pad(g.gm)}-${pad(g.gd)}`;
                        grid.querySelectorAll('.jdp-day').forEach(el => el.classList.remove('selected'));
                        cell.classList.add('selected');
                        const smJ = document.getElementById('smDate');
                        if (smJ) smJ.textContent = `${JY}/${pad(JM)}/${pad(JD)}`;
                        pop.hidden = true;
                    });
                    grid.appendChild(cell);
                }
            }

            let selectedJY = null, selectedJM = null, selectedJD = null;

            function syncUI() {
                selY.value = JY;
                selM.value = JM;
                renderGrid();
            }

            btn.addEventListener('click', () => {
                pop.hidden = !pop.hidden;
                if (!pop.hidden) syncUI();
            });
            document.addEventListener('click', (e) => {
                if (pop.hidden) return;
                const within = e.target.closest('.jdp');
                if (!within) pop.hidden = true;
            });
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') pop.hidden = true;
            });

            selY.addEventListener('change', () => {
                JY = parseInt(selY.value, 10) || JY;
                syncUI();
            });
            selM.addEventListener('change', () => {
                JM = parseInt(selM.value, 10) || JM;
                syncUI();
            });

            prev.addEventListener('click', () => {
                JM--;
                if (JM < 1) { JM = 12; JY--; }
                syncUI();
            });
            next.addEventListener('click', () => {
                JM++;
                if (JM > 12) { JM = 1; JY++; }
                syncUI();
            });

            todayBtn.addEventListener('click', () => {
                const now = new Date();
                const j = g2j(now.getFullYear(), now.getMonth() + 1, now.getDate());
                JY = j.jy;
                JM = j.jm;
                JD = j.jd;
                selectedJY = JY;
                selectedJM = JM;
                selectedJD = JD;
                inpt.value = `${JY}/${pad(JM)}/${pad(JD)}`;
                const g = j2g(JY, JM, JD);
                iso.value = `${g.gy}-${pad(g.gm)}-${pad(g.gd)}`;
                const smJ = document.getElementById('smDate');
                if (smJ) smJ.textContent = inpt.value;
                syncUI();
            });

            clearBtn.addEventListener('click', () => {
                inpt.value = '';
                iso.value = '';
                selectedJY = selectedJM = selectedJD = null;
                grid.querySelectorAll('.jdp-day').forEach(el => el.classList.remove('selected'));
            });

            closeBtn.addEventListener('click', () => { pop.hidden = true; });

            inpt.addEventListener('input', () => {
                const m = inpt.value.trim().match(/^(13\d{2}|14\d{2})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
                if (!m) { iso.value = ''; return; }
                const jy = parseInt(m[1], 10);
                const jm = parseInt(m[2], 10);
                const jd = parseInt(m[3], 10);
                if (jm < 1 || jm > 12) return;
                const days = dimJ(jy, jm);
                if (jd < 1 || jd > days) return;
                const g = j2g(jy, jm, jd);
                iso.value = `${g.gy}-${pad(g.gm)}-${pad(g.gd)}`;
                JY = jy;
                JM = jm;
                JD = jd;
                selectedJY = jy;
                selectedJM = jm;
                selectedJD = jd;
                const smJ = document.getElementById('smDate');
                if (smJ) smJ.textContent = `${jy}/${pad(jm)}/${pad(jd)}`;
            });

            todayBtn.click();
        })();

        // Initialize everything
        document.addEventListener('DOMContentLoaded', function() {
            createStars();
            updateSummary();
            updatePublishState();
            // loadQuestions(); // در صورت نیاز به لود سوالات از دیتابیس
        });
    </script>
</body>
</html>