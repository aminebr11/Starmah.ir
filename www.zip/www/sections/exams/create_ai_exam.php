<?php

/******************************************************
 * create_ai_exam.php — AI Exam Builder (OpenAI Version)
 * - Persian RTL UI (Tahoma)
 * - Step 1: Collect → Step 2: Generate → Step 3: Review/Save
 * - قابلیت حذف و اضافه سوال
 ******************************************************/

header('Content-Type: text/html; charset=utf-8');

/* =======================
   1) CONFIG
   ======================= */

// --- Database ---
define('DB_HOST', 'localhost:3306');
define('DB_NAME', 'qwaepiuv_starmah_db');
define('DB_USER', 'qwaepiuv_aminebr');
define('DB_PASS', 'Test12345!@#');

// --- OpenAI API ---
define('OPENAI_API_KEY', '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');
define('OPENAI_MODEL', 'gpt-4'); // یا 'gpt-3.5-turbo'
define('OPENAI_API_URL', 'https://api.openai.com/v1/chat/completions');

define('MAX_QUESTION_COUNT', 30);

/* =======================
   2) BOOTSTRAP
   ======================= */

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    } catch (PDOException $e) {
        die('⚠ Database connection failed: ' . htmlspecialchars($e->getMessage()));
    }
    return $pdo;
}
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* =======================
   3) AI CALL — OpenAI
   ======================= */

function openai_chat(string $prompt): array {
    if (!OPENAI_API_KEY || strpos(OPENAI_API_KEY, 'sk-') !== 0) {
        return ['error' => 'OpenAI API key not set or invalid.'];
    }
    
    $payload = [
        'model' => OPENAI_MODEL,
        'messages' => [
            [
                'role' => 'system',
                'content' => 'شما یک طراح آزمون حرفه‌ای به زبان فارسی هستید که برای معلمان سوالات دقیق و کاربردی طراحی می‌کنید. همیشه خروجی را در قالب JSON معتبر ارائه دهید.'
            ],
            [
                'role' => 'user',
                'content' => $prompt
            ]
        ],
        'temperature' => 0.7,
        'max_tokens' => 3000
    ];
    
    $ch = curl_init(OPENAI_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . OPENAI_API_KEY
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 60,
    ]);
    
    $res = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    
    if ($err) return ['error' => 'AI connection error: ' . $err];

    $data = json_decode($res, true);
    
    if (isset($data['error'])) {
        return ['error' => 'OpenAI Error: ' . ($data['error']['message'] ?? 'Unknown error')];
    }
    
    if (!isset($data['choices'][0]['message']['content'])) {
        return ['error' => 'Invalid AI response format', 'raw' => $data];
    }
    
    return ['text' => $data['choices'][0]['message']['content'], 'raw' => $data];
}

function extract_json(string $text): ?array {
    $text = trim($text);
    if (preg_match('/```json\s*(\{.*?\})\s*```/is', $text, $m)) {
        $decoded = json_decode($m[1], true);
        if (is_array($decoded)) return $decoded;
    }
    if (preg_match('/\{.*\}/s', $text, $m)) {
        $decoded = json_decode($m[0], true);
        if (is_array($decoded)) return $decoded;
    }
    $decoded = json_decode($text, true);
    return is_array($decoded) ? $decoded : null;
}

function build_prompt(array $p, int $additionalCount = 0): string {
    $subject     = $p['subject'];
    $grade       = $p['grade'];
    $difficulty  = $p['difficulty'];
    $topic       = $p['topic'];
    $notes       = $p['notes'];
    $count       = $additionalCount > 0 ? $additionalCount : (int)$p['count'];
    $type        = $p['type'];
    $needAnswers = $p['with_answers'] ? 'بله' : 'خیر';

    $typeDesc = [
        'mcq' => 'چهارگزینه‌ای (Multiple Choice)',
        'tf' => 'درست/غلط (True/False)',
        'short' => 'پاسخ کوتاه (Short Answer)'
    ];

    return <<<PROMPT
برای درس "{$subject}" در مقطع تحصیلی "{$grade}" با موضوع "{$topic}" و سطح دشواری "{$difficulty}"، دقیقاً {$count} سوال از نوع "{$typeDesc[$type]}" تولید کنید.

یادداشت‌های اضافی: {$notes}
نیاز به پاسخ‌ها: {$needAnswers}

قوانین مهم:
1. تمام متون باید به زبان فارسی روان، کوتاه و مناسب برای محیط آموزشی باشند
2. سوالات باید کاملاً مرتبط با درس، مقطع، موضوع و سطح دشواری باشند
3. دقیقاً {$count} سوال تولید شود
4. فقط نوع "{$type}" تولید شود

فرمت خروجی (JSON):
{
  "questions": [
    {
      "type": "mcq",
      "text": "متن سوال",
      "options": ["گزینه 1", "گزینه 2", "گزینه 3", "گزینه 4"],
      "correct_index": 0,
      "points": 1
    }
  ]
}

برای سوالات mcq: دقیقاً 4 گزینه، یک گزینه صحیح
برای سوالات tf: answer باید true یا false باشد
برای سوالات short: answer یک عبارت کوتاه (حداکثر 10 کلمه)

خروجی فقط JSON معتبر باشد، بدون توضیح اضافی.
PROMPT;
}

function normalize_options_to_strings($opts): array {
    $out = [];
    if (!is_array($opts)) return ['', '', '', ''];

    if (isset($opts[0]) && is_array($opts[0])) {
        foreach ($opts as $o) {
            $text =
                ($o['text']  ?? null) ??
                ($o['label'] ?? null) ??
                ($o['title'] ?? null) ??
                ($o['value'] ?? '');
            $out[] = trim((string)$text);
        }
    } else {
        foreach ($opts as $s) $out[] = trim((string)$s);
    }

    $out = array_values(array_slice($out, 0, 4));
    while (count($out) < 4) $out[] = '';
    return $out;
}

function find_correct_index($data, array $opts): ?int {
    if (array_key_exists('correct_index', $data) && $data['correct_index'] !== null) {
        $ci = (int)$data['correct_index'];
        return max(0, min(3, $ci));
    }
    if (isset($data['options'][0]) && is_array($data['options'][0])) {
        foreach (array_values($data['options']) as $i => $o) {
            if (!empty($o['correct']) || !empty($o['is_correct'])) return max(0, min(3, $i));
        }
    }
    if (isset($data['choices']) && is_array($data['choices'])) {
        foreach ($data['choices'] as $i => $c) {
            if (!empty($c['is_correct'])) return max(0, min(3, $i));
        }
    }
    return null;
}

function normalize_questions(array $decoded, string $fallbackType, bool $withAnswers): array {
    $out = [];
    $qs  = $decoded['questions'] ?? [];
    foreach ($qs as $q) {
        $row = [
            'type'   => isset($q['type']) ? (string)$q['type'] : $fallbackType,
            'text'   => trim((string)($q['text'] ?? '')),
            'points' => (int)($q['points'] ?? 1),
        ];
        if ($row['type'] === 'mcq') {
            $opts = normalize_options_to_strings($q['options'] ?? []);
            $ci   = find_correct_index($q, $opts);
            if (!$withAnswers) $ci = null;
            $row['options'] = $opts;
            $row['correct_index'] = $ci;
        } elseif ($row['type'] === 'tf') {
            $ans = $q['answer'] ?? null;
            if (!$withAnswers) $ans = null;
            $row['answer'] = $ans === null ? null : (bool)$ans;
        } else {
            $row['type'] = 'short';
            $ans = trim((string)($q['answer'] ?? ''));
            if (!$withAnswers) $ans = '';
            $row['answer'] = $ans;
        }
        if ($row['text'] !== '') $out[] = $row;
    }
    return $out;
}

/* =======================
   4) DB SAVE
   ======================= */

function save_quiz(PDO $pdo, array $quizMeta, array $questions): int {
    $title     = $quizMeta['title'];
    $exam_date = $quizMeta['exam_date'];
    $exam_time = $quizMeta['exam_time'];
    $duration  = (int)$quizMeta['duration'];

    $totalPoints = 0;
    foreach ($questions as $q) $totalPoints += (int)($q['points'] ?? 1);

    $stmt = $pdo->prepare("
        INSERT INTO quizzes
        (title, exam_date, exam_time, duration_minutes, is_active, is_visible, shuffle_questions, negative_marking, questions_count, total_points)
        VALUES (?, ?, ?, ?, 1, 1, 1, 0, ?, ?)
    ");
    $stmt->execute([$title, $exam_date, $exam_time, $duration, count($questions), $totalPoints]);
    $quizId = (int)$pdo->lastInsertId();

    $order = 1;
    $stmtQ = $pdo->prepare("
        INSERT INTO quiz_questions
        (quiz_id, question_text, question_type, question_data, points, question_order, is_active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
    ");
    foreach ($questions as $q) {
        $type = $q['type'];

        if ($type === 'mcq') {
            $opts = normalize_options_to_strings($q['options'] ?? []);
            $ci   = array_key_exists('correct_index', $q) ? $q['correct_index'] : null;
            $ci   = ($ci === null ? null : max(0, min(3, (int)$ci)));

            $choices = [];
            $options_objects = [];
            foreach ($opts as $i=>$t) {
                $is = ($ci !== null && $i === (int)$ci);
                $choices[] = ['text'=>$t, 'is_correct'=>$is];
                $options_objects[] = ['text'=>$t, 'correct'=>$is, 'is_correct'=>$is];
            }

            $qData = [
                'options'       => $options_objects,
                'correct_index' => $ci,
                'choices'       => $choices,
            ];
        } elseif ($type === 'tf') {
            $ans = array_key_exists('answer', $q) ? $q['answer'] : null;
            $qData = ['answer' => $ans];
        } else {
            $ans = (string)($q['answer'] ?? '');
            $qData = ['answer' => $ans];
        }

        $stmtQ->execute([
            $quizId,
            $q['text'],
            $type,
            json_encode($qData, JSON_UNESCAPED_UNICODE),
            (int)$q['points'],
            $order++
        ]);
    }
    return $quizId;
}

/* =======================
   5) CONTROLLER
   ======================= */

$step = $_POST['step'] ?? 'form';
$errors = [];
$generated = [];

$today   = date('Y-m-d');
$defTime = '08:30';
$defDur  = 20;

$form = [
    'subject'      => $_POST['subject']      ?? '',
    'grade'        => $_POST['grade']        ?? '',
    'difficulty'   => $_POST['difficulty']   ?? 'متوسط',
    'topic'        => $_POST['topic']        ?? '',
    'notes'        => $_POST['notes']        ?? '',
    'type'         => $_POST['type']         ?? 'mcq',
    'count'        => isset($_POST['count']) ? (int)$_POST['count'] : 5,
    'with_answers' => isset($_POST['with_answers']) ? 1 : 0,
];

$defaultTitle = '';

// مرحله تولید سوال
if ($step === 'generate') {
    if ($form['subject'] === '' || $form['grade'] === '' || $form['topic'] === '') {
        $errors[] = 'نام درس، مقطع تحصیلی و موضوع الزامی است.';
    }
    if (!in_array($form['difficulty'], ['آسان','متوسط','سخت'], true)) {
        $errors[] = 'میزان سختی نامعتبر است.';
    }
    if (!in_array($form['type'], ['mcq','tf','short'], true)) {
        $errors[] = 'نوع سؤال نامعتبر است.';
    }
    if ($form['count'] < 1 || $form['count'] > MAX_QUESTION_COUNT) {
        $errors[] = 'تعداد سؤال نامعتبر است.';
    }
    if (!$errors) {
        $prompt = build_prompt($form);
        $ai = openai_chat($prompt);
        if (!empty($ai['error'])) {
            $errors[] = $ai['error'];
        } else {
            $decoded = extract_json($ai['text']);
            if (!$decoded) {
                $errors[] = 'فرمت JSON دریافتی از AI قابل‌خواندن نبود.';
            } else {
                $generated = normalize_questions($decoded, $form['type'], (bool)$form['with_answers']);
                if (!$generated) {
                    $errors[] = 'سوالی تولید نشد. لطفاً دوباره تلاش کنید.';
                } else {
                    $defaultTitle = 'آزمون ' . $form['topic'];
                    $step = 'confirm';
                }
            }
        }
    }
}

// مرحله اضافه کردن سوالات بیشتر
if ($step === 'add_more') {
    $additionalCount = (int)($_POST['additional_count'] ?? 3);
    $existingQuestions = isset($_POST['existing_questions']) ? json_decode($_POST['existing_questions'], true) : [];
    
    if ($additionalCount < 1 || $additionalCount > 10) {
        $errors[] = 'تعداد سوالات اضافی باید بین 1 تا 10 باشد.';
    }
    
    if (!$errors) {
        $prompt = build_prompt($form, $additionalCount);
        $ai = openai_chat($prompt);
        if (!empty($ai['error'])) {
            $errors[] = $ai['error'];
        } else {
            $decoded = extract_json($ai['text']);
            if (!$decoded) {
                $errors[] = 'فرمت JSON دریافتی از AI قابل‌خواندن نبود.';
            } else {
                $newQuestions = normalize_questions($decoded, $form['type'], (bool)$form['with_answers']);
                $generated = array_merge($existingQuestions, $newQuestions);
                $defaultTitle = $_POST['title'] ?? 'آزمون ' . $form['topic'];
                $step = 'confirm';
            }
        }
    }
    
    if ($errors && $existingQuestions) {
        $generated = $existingQuestions;
        $step = 'confirm';
    }
}

// مرحله حذف سوال
if ($step === 'delete_question') {
    $deleteIndex = (int)($_POST['delete_index'] ?? -1);
    $existingQuestions = isset($_POST['existing_questions']) ? json_decode($_POST['existing_questions'], true) : [];
    
    if ($deleteIndex >= 0 && $deleteIndex < count($existingQuestions)) {
        array_splice($existingQuestions, $deleteIndex, 1);
    }
    
    $generated = $existingQuestions;
    $defaultTitle = $_POST['title'] ?? 'آزمون ' . $form['topic'];
    $step = 'confirm';
}

// مرحله ذخیره
if ($step === 'save') {
    $title = trim($_POST['title'] ?? '');
    $exam_date = trim($_POST['exam_date'] ?? $today);
    $exam_time = trim($_POST['exam_time'] ?? $defTime);
    $duration  = (int)($_POST['duration'] ?? $defDur);
    if ($title === '') $errors[] = 'عنوان آزمون الزامی است.';

    $q_text   = $_POST['q_text']   ?? [];
    $q_type   = $_POST['q_type']   ?? [];
    $q_points = $_POST['q_points'] ?? [];
    $qs = [];
    for ($i=0; $i<count($q_text); $i++) {
        $qt = $q_type[$i] ?? 'mcq';
        $row = [
            'type'   => $qt,
            'text'   => trim($q_text[$i] ?? ''),
            'points' => (int)($q_points[$i] ?? 1),
        ];
        if ($qt === 'mcq') {
            $opts = $_POST["q{$i}_opt"] ?? [];
            $opts = normalize_options_to_strings($opts);
            $ci   = isset($_POST["q{$i}_correct"]) ? (int)$_POST["q{$i}_correct"] : null;
            $ci   = ($ci === null ? null : max(0, min(3, (int)$ci)));
            $row['options'] = $opts;
            $row['correct_index'] = $ci;
        } elseif ($qt === 'tf') {
            $row['answer'] = isset($_POST["q{$i}_tf"]) ? (bool)$_POST["q{$i}_tf"] : null;
        } else {
            $row['type'] = 'short';
            $row['answer'] = trim($_POST["q{$i}_short"] ?? '');
        }
        if ($row['text'] !== '') $qs[] = $row;
    }
    if (!$qs) $errors[] = 'هیچ سؤالی برای ذخیره وجود ندارد.';

    if (!$errors) {
        $metaTag = ' | ' . ($_POST['subject'] ?? '') . ' / ' . ($_POST['grade'] ?? '') . ' / ' . ($_POST['difficulty'] ?? '') . ' / ' . ($_POST['topic'] ?? '');
        $titleFull = $title . $metaTag;

        try {
            $quizId = save_quiz(
                db(),
                [
                    'title'      => $titleFull,
                    'exam_date'  => $exam_date,
                    'exam_time'  => $exam_time,
                    'duration'   => $duration,
                ],
                $qs
            );
            header('Location: ' . $_SERVER['PHP_SELF'] . '?saved=1&id=' . $quizId);
            exit;
        } catch (Throwable $e) {
            $errors[] = 'خطا در ذخیره‌سازی: ' . $e->getMessage();
            $generated = $qs;
            $step = 'confirm';
        }
    } else {
        $generated = $qs;
        $step = 'confirm';
    }
}

// Session
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

/* =======================
   6) VIEW (HTML)
   ======================= */
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>🧪 آزمون‌ساز هوشمند - ستاره ماه</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/style.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/script.css" />
<style>
/* استایل‌های موجود در کد اصلی + استایل‌های جدید */
.exam-builder-container {
  max-width:1400px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.exam-subnav {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  margin: 1rem 0 2rem 0;
  padding: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.exam-subnav-links {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.exam-subnav-link {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  padding: 0.8rem 1.5rem;
  border-radius: 15px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 0.95rem;
}

.exam-subnav-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  color: white;
}

.exam-subnav-link.active {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border-color: transparent;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.exam-grid {
  display: grid;
  grid-template-columns: 1fr 320px;
  gap: 2rem;
  margin-top: 2rem;
}

@media (max-width: 1024px) {
  .exam-grid {
    grid-template-columns: 1fr;
  }
}

.exam-card {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.exam-card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: linear-gradient(135deg, #83eaf1, #63a4ff);
  color: #0b1220;
  padding: 1rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
}

.exam-step-number {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 800;
  font-size: 0.9rem;
}

.exam-card-title {
  flex: 1;
}

.exam-card-title h2 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 800;
}

.exam-card-title p {
  margin: 0.3rem 0 0 0;
  opacity: 0.9;
  font-size: 0.9rem;
}

.exam-badge {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.85rem;
}

.exam-form-grid {
  display: grid;
  grid-template-columns: minmax(300px,1fr) minmax(300px,1fr) 160px 160px;
  gap: 1rem;
  align-items: start;
  margin-bottom: 1.5rem;
}

@media (max-width: 1100px) {
  .exam-form-grid {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 640px) {
  .exam-form-grid {
    grid-template-columns: 1fr;
  }
}

.exam-form-group {
  margin-bottom: 1rem;
}

.exam-form-group label {
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: rgba(255, 255, 255, 0.9);
}

.exam-form-group input,
.exam-form-group select,
.exam-form-group textarea {
  width: 100%;
  padding: 0.8rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  font-family: 'Tahoma', tahoma, sans-serif;
  transition: all 0.3s ease;
}

.exam-form-group select {
  background: rgba(255, 255, 255, 0.1) !important;
  color: rgba(255, 255, 255, 0.9) !important;
}

.exam-form-group select option {
  background: #2d3748 !important;
  color: white !important;
  padding: 0.5rem;
}

.exam-form-group input:focus,
.exam-form-group textarea:focus,
.exam-form-group select:focus {
  border-color: #ffd93d;
  outline: none;
  background: rgba(255, 255, 255, 0.2);
  box-shadow: 0 0 20px rgba(255, 217, 61, 0.4);
}

.exam-form-group textarea {
  min-height: 80px;
  resize: vertical;
}

.exam-btn {
  border: none;
  border-radius: 12px;
  padding: 0.8rem 1.5rem;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
  font-family: 'Tahoma', tahoma, sans-serif;
}

.exam-btn-primary {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.exam-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6);
}

.exam-btn-soft {
  background: rgba(139,92,246,.15);
  color: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.exam-btn-mini {
  background: #111827;
  color: #e5e7eb;
  font-size: 0.85rem;
  padding: 0.5rem 1rem;
}

.exam-btn-danger {
  background: rgba(244,63,94,.15);
  color: #fecaca;
  border: 1px solid rgba(244,63,94,.3);
}

.exam-btn:disabled {
  opacity: 0.6;
  pointer-events: none;
}

.exam-aside {
  position: sticky;
  top: 2rem;
  height: max-content;
}

.exam-summary-card {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 1.5rem;
}

.exam-summary-card h3 {
  margin: 0 0 1rem 0;
  color: rgba(255, 255, 255, 0.95);
  font-weight: 700;
}

.exam-summary-item {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 0.8rem;
  margin-bottom: 0.8rem;
  color: rgba(255, 255, 255, 0.9);
  font-size: 0.9rem;
}

.exam-kpis {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.5rem;
  margin-top: 1rem;
}

.exam-kpi {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 0.8rem;
  text-align: center;
  font-size: 0.85rem;
}

.exam-kpi strong {
  display: block;
  font-size: 1.1rem;
  color: #ffd93d;
}

.exam-question-item {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 1rem;
  margin-bottom: 1rem;
  position: relative;
}

.exam-question-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
}

.exam-question-content {
  flex: 1;
}

.exam-question-actions {
  display: flex;
  gap: 0.5rem;
}

.exam-question-title {
  font-weight: 700;
  margin-bottom: 0.5rem;
  color: rgba(255, 255, 255, 0.95);
}

.exam-option {
  display: flex !important;
  align-items: center !important;
  gap: 0.5rem !important;
  margin-bottom: 0.8rem !important;
  padding: 0.5rem !important;
  background: rgba(255, 255, 255, 0.05) !important;
  border-radius: 8px !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
}

.exam-option:hover {
  background: rgba(255, 255, 255, 0.1) !important;
  border-color: rgba(255, 255, 255, 0.2) !important;
}

.exam-question-item textarea,
.exam-question-item input[type="text"] {
  width: 100% !important;
  min-height: 45px !important;
  padding: 0.75rem 0.9rem !important;
  border-radius: 12px !important;
  border: 1px solid rgba(255, 255, 255, 0.3) !important;
  background: rgba(255, 255, 255, 0.1) !important;
  color: #000000 !important;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  font-size: 0.95rem !important;
  line-height: 1.6 !important;
  transition: all 0.3s ease !important;
  resize: vertical !important;
}

.exam-question-item textarea:focus,
.exam-question-item input[type="text"]:focus {
  border-color: #ffd93d !important;
  outline: none !important;
  background: rgba(255, 255, 255, 0.2) !important;
  box-shadow: 0 0 20px rgba(255, 217, 61, 0.4) !important;
}

.exam-option input[type="text"] {
  flex: 1 !important;
  min-height: 40px !important;
  font-size: 0.9rem !important;
  color: #000000 !important;
}

.exam-question-item input[type="number"] {
  width: 100% !important;
  min-height: 40px !important;
  padding: 0.75rem 0.9rem !important;
  border-radius: 12px !important;
  border: 1px solid rgba(255, 255, 255, 0.3) !important;
  background: rgba(255, 255, 255, 0.1) !important;
  color: #000000 !important;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  font-size: 0.95rem !important;
}

.exam-question-item input[type="number"]:focus {
  border-color: #ffd93d !important;
  outline: none !important;
  background: rgba(255, 255, 255, 0.2) !important;
  box-shadow: 0 0 20px rgba(255, 217, 61, 0.4) !important;
}

.exam-option input[type="radio"] {
  width: 18px !important;
  height: 18px !important;
  margin-left: 0.5rem !important;
  accent-color: #6bcf7f !important;
}

.exam-tf-choices {
  display: flex;
  gap: 0.8rem;
  flex-wrap: wrap;
  margin-top: 0.8rem;
}

.exam-tf-pill {
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 50px;
  padding: 0.8rem 1.2rem;
  cursor: pointer;
  transition: all 0.3s ease;
  color: rgba(255, 255, 255, 0.8);
}

.exam-tf-pill.true.active {
  background: rgba(34,197,94,.35);
  border-color: rgba(34,197,94,.55);
  color: white;
}

.exam-tf-pill.false.active {
  background: rgba(239,68,68,.35);
  border-color: rgba(239,68,68,.55);
  color: white;
}

.err {
  background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
  border: 2px solid #fc8181;
  color: #c53030;
  padding: 20px;
  border-radius: 16px;
  margin-bottom: 20px;
  position: relative;
  padding-right: 50px;
}

.err::before {
  content: '⚠️';
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 24px;
}

.success {
  background: linear-gradient(135deg, #f0fff4 0%, #c6f6d5 100%);
  border: 2px solid #68d391;
  color: #22543d;
  padding: 20px;
  border-radius: 16px;
  margin-bottom: 20px;
  position: relative;
  padding-right: 50px;
}

.success::before {
  content: '✅';
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 24px;
}

.help {
  font-size: 12px;
  color: #718096;
  margin-top: 5px;
  font-style: italic;
}

hr {
  border: none;
  height: 2px;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  margin: 25px 0;
}

.footer {
  margin-top: 25px;
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.stats-box {
  display: flex;
  gap: 20px;
  margin: 20px 0;
  flex-wrap: wrap;
}

.stat-item {
  flex: 1;
  min-width: 150px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
  padding: 15px;
  border-radius: 12px;
  text-align: center;
  border: 2px solid rgba(102, 126, 234, 0.2);
}

.stat-item .stat-value {
  font-size: 24px;
  font-weight: 700;
  color: #ffd93d;
}

.stat-item .stat-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.7);
  margin-top: 5px;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  overflow: hidden;
  margin: 20px 0;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #6bcf7f 0%, #4d9de0 100%);
  border-radius: 10px;
  transition: width 0.5s ease;
  animation: shimmer 2s ease-in-out infinite;
}

@keyframes shimmer {
  0% { opacity: 0.8; }
  50% { opacity: 1; }
  100% { opacity: 0.8; }
}

.question-type-badge {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  margin-right: 10px;
}

.type-mcq {
  background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
  color: white;
}

.type-tf {
  background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
  color: white;
}

.type-short {
  background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
  color: white;
}

.fade-in {
  animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.checkbox-wrapper {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 15px;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
  border-radius: 12px;
  border: 2px solid rgba(102, 126, 234, 0.2);
  margin: 15px 0;
}

.checkbox-wrapper input[type="checkbox"] {
  width: 20px;
  height: 20px;
  accent-color: #6bcf7f;
}

.checkbox-wrapper label {
  margin: 0;
  font-size: 15px;
  cursor: pointer;
  color: rgba(255, 255, 255, 0.9);
}

/* استایل دکمه حذف */
.exam-btn-delete {
  background: linear-gradient(135deg, #ef4444, #dc2626);
  color: white;
  padding: 0.5rem 1rem;
  font-size: 0.85rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.exam-btn-delete:hover {
  transform: scale(1.05);
  box-shadow: 0 5px 15px rgba(239, 68, 68, 0.4);
}

/* استایل بخش افزودن سوال */
.add-questions-section {
  background: rgba(255, 255, 255, 0.08);
  border: 2px dashed rgba(255, 255, 255, 0.3);
  border-radius: 16px;
  padding: 1.5rem;
  margin: 1.5rem 0;
  text-align: center;
}

.add-questions-section h4 {
  margin: 0 0 1rem 0;
  color: rgba(255, 255, 255, 0.95);
}

.add-questions-controls {
  display: flex;
  gap: 1rem;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.exam-btn-success {
  background: linear-gradient(135deg, #10b981, #059669);
  color: white;
  box-shadow: 0 5px 20px rgba(16, 185, 129, 0.4);
}

.exam-btn-success:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(16, 185, 129, 0.6);
}

@media (max-width: 768px) {
  .exam-form-grid {
    grid-template-columns: 1fr;
  }
  
  .exam-card-header {
    flex-direction: column;
    gap: 15px;
    text-align: center;
  }
  
  .exam-card {
    padding: 20px;
  }
}
</style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮 بازی‌ها</a>
                    <a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی موبایل" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Exam Builder Container -->
    <div class="exam-builder-container">
        
        <div class="exam-subnav">
            <div class="exam-subnav-links">
                <a href="/sections/exams/create_ai_exam.php" class="exam-subnav-link active">🤖 ساخت خودکار (AI)</a>
                <a href="/sections/exams/builder.php" class="exam-subnav-link">🛠️ آزمون‌ساز دستی</a>
                <a href="/sections/exams/library.php" class="exam-subnav-link">📚 کتابخانه آزمون‌ها</a>
                <a href="/sections/exams/reports.php" class="exam-subnav-link">📈 گزارش‌ها</a>
            </div>
        </div>

        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">🤖 آزمون‌ساز هوش مصنوعی OpenAI</h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9); font-size: 1.2rem;">تولید سوال با کمک GPT-4؛ سریع، دقیق و حرفه‌ای</p>
        </div>

        <?php if (isset($_GET['saved']) && $_GET['saved']=='1'): ?>
            <div class="exam-card success fade-in">
                <strong>آزمون با موفقیت ذخیره شد!</strong>
                <br>شناسه آزمون: <strong><?php echo h($_GET['id'] ?? ''); ?></strong>
            </div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="exam-card err fade-in">
                <strong>⚠️ خطاهای زیر رخ داده است:</strong>
                <ul style="margin:12px 0 0 0;padding-right:25px">
                    <?php foreach ($errors as $e): ?><li><?php echo h($e); ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Main Grid -->
        <div class="exam-grid">
            <div>
                <?php if ($step === 'form'): ?>
                    <!-- Step 1 -->
                    <div class="exam-card fade-in">
                        <div class="exam-card-header">
                            <div class="exam-step-number">1️⃣</div>
                            <div class="exam-card-title">
                                <h2>📝 مرحله ۱: تنظیمات تولید سوال</h2>
                                <p>مشخصات درس، موضوع و نوع سوالات مورد نظر</p>
                            </div>
                            <div class="exam-badge">در حال تکمیل…</div>
                        </div>
                        
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 33%;"></div>
                        </div>
                        
                        <form method="post">
                            <input type="hidden" name="step" value="generate">
                            
                            <div class="exam-form-grid">
                                <div class="exam-form-group">
                                    <label>📚 نام درس</label>
                                    <input type="text" name="subject" value="<?php echo h($form['subject']); ?>" placeholder="مثلاً: ریاضی" required>
                                </div>
                                <div class="exam-form-group">
                                    <label>🎓 مقطع تحصیلی</label>
                                    <input type="text" name="grade" value="<?php echo h($form['grade']); ?>" placeholder="مثلاً: چهارم دبستان" required>
                                </div>
                                <div class="exam-form-group">
                                    <label>📊 سطح دشواری</label>
                                    <select name="difficulty">
                                        <option value="آسان" <?php echo $form['difficulty']==='آسان'?'selected':''; ?>>🟢 آسان</option>
                                        <option value="متوسط" <?php echo $form['difficulty']==='متوسط'?'selected':''; ?>>🟡 متوسط</option>
                                        <option value="سخت" <?php echo $form['difficulty']==='سخت'?'selected':''; ?>>🔴 سخت</option>
                                    </select>
                                </div>
                                <div class="exam-form-group">
                                    <label>🔢 تعداد سؤال</label>
                                    <input type="number" name="count" value="<?php echo h($form['count']); ?>" min="1" max="<?php echo MAX_QUESTION_COUNT; ?>" required>
                                    <div class="help">حداکثر <?php echo MAX_QUESTION_COUNT; ?> سؤال</div>
                                </div>
                            </div>

                            <div class="exam-form-grid" style="grid-template-columns: 2fr 1fr;">
                                <div class="exam-form-group">
                                    <label>📖 موضوع درس</label>
                                    <input type="text" name="topic" value="<?php echo h($form['topic']); ?>" placeholder="مثلاً: کسرها و اعداد اعشاری" required>
                                    <div class="help">موضوع دقیق درسی که می‌خواهید سؤال از آن طرح شود</div>
                                </div>
                                <div class="exam-form-group">
                                    <label>❓ نوع سؤال</label>
                                    <select name="type">
                                        <option value="mcq" <?php echo $form['type']==='mcq'?'selected':''; ?>>چهارگزینه‌ای (Multiple Choice)</option>
                                        <option value="tf" <?php echo $form['type']==='tf'?'selected':''; ?>>درست/غلط (True/False)</option>
                                        <option value="short" <?php echo $form['type']==='short'?'selected':''; ?>>تشریحی کوتاه (Short Answer)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="exam-form-group">
                                <label>💡 توضیحات تکمیلی (اختیاری)</label>
                                <textarea name="notes" placeholder="مثلاً: سؤالات مفهومی باشند، از مثال‌های زندگی روزمره استفاده شود، اعداد ساده باشند..."><?php echo h($form['notes']); ?></textarea>
                                <div class="help">راهنمایی‌هایی که به بهبود کیفیت سؤالات کمک می‌کند</div>
                            </div>
                            
                            <div class="checkbox-wrapper">
                                <input type="checkbox" id="with_answers" name="with_answers" value="1" <?php echo $form['with_answers']? 'checked':''; ?>>
                                <label for="with_answers">✅ سؤالات همراه با پاسخ تولید شود</label>
                            </div>
                            <div class="help" style="margin-top: -10px;">برای آزمون‌های تمرینی یا خودآزمایی مفید است</div>

                            <hr>
                            
                            <div class="footer">
                                <button type="submit" class="exam-btn exam-btn-primary">
                                    🤖 تولید سوال با هوش مصنوعی
                                </button>
                                <button type="button" class="exam-btn exam-btn-soft" onclick="this.form.reset()">
                                    🔄 پاک کردن فرم
                                </button>
                            </div>
                        </form>
                    </div>

                <?php else: ?>
                    <!-- Step 2 -->
                    <div class="exam-card fade-in">
                        <div class="exam-card-header">
                            <div class="exam-step-number">2️⃣</div>
                            <div class="exam-card-title">
                                <h2>✏️ مرحله ۲: بازبینی، ویرایش و ذخیره آزمون</h2>
                                <p>سؤالات تولید شده را بررسی، ویرایش، حذف کنید یا سؤالات بیشتر اضافه کنید</p>
                            </div>
                            <div class="exam-badge">آماده ذخیره ✨</div>
                        </div>
                        
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 66%;"></div>
                        </div>
                        
                        <div class="stats-box">
                            <div class="stat-item">
                                <div class="stat-value"><?php echo count($generated); ?></div>
                                <div class="stat-label">تعداد سؤال</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value"><?php echo h($form['subject']); ?></div>
                                <div class="stat-label">درس</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value"><?php echo h($form['difficulty']); ?></div>
                                <div class="stat-label">سطح دشواری</div>
                            </div>
                        </div>
                        
                        <form method="post" id="mainForm">
                            <input type="hidden" name="step" value="save">
                            <input type="hidden" name="subject" value="<?php echo h($form['subject']); ?>">
                            <input type="hidden" name="grade" value="<?php echo h($form['grade']); ?>">
                            <input type="hidden" name="difficulty" value="<?php echo h($form['difficulty']); ?>">
                            <input type="hidden" name="topic" value="<?php echo h($form['topic']); ?>">

                            <div class="exam-form-grid">
                                <div class="exam-form-group">
                                    <label>📝 عنوان آزمون</label>
                                    <input type="text" name="title" id="examTitle" value="<?php echo h($defaultTitle); ?>" placeholder="مثلاً: آزمون فصل ۲ - کسرها" required>
                                </div>
                                <div class="exam-form-group">
                                    <label>📅 تاریخ آزمون</label>
                                    <input type="date" name="exam_date" value="<?php echo h($today); ?>" required>
                                </div>
                                <div class="exam-form-group">
                                    <label>🕐 ساعت آزمون</label>
                                    <input type="time" name="exam_time" value="<?php echo h($defTime); ?>" required>
                                </div>
                                <div class="exam-form-group">
                                    <label>⏱️ مدت آزمون</label>
                                    <input type="number" name="duration" value="<?php echo h($defDur); ?>" min="1" required>
                                </div>
                            </div>

                            <hr>
                            
                            <h3>📋 سؤالات تولید شده (قابل ویرایش و حذف):</h3>
                            
                            <div id="questionsContainer">
                                <?php foreach ($generated as $i => $q): ?>
                                    <div class="exam-question-item fade-in" id="question-<?php echo $i; ?>">
                                        <div class="exam-question-header">
                                            <div class="exam-question-content">
                                                <div class="exam-question-title">
                                                    <b>سؤال <?php echo $i + 1; ?></b>
                                                    <span class="question-type-badge type-<?php echo $q['type']; ?>">
                                                        <?php echo $q['type'] === 'mcq' ? 'چهارگزینه‌ای' : ($q['type'] === 'tf' ? 'درست/غلط' : 'پاسخ کوتاه'); ?>
                                                    </span>
                                                    🏅 <?php echo $q['points']; ?> امتیاز
                                                </div>
                                            </div>
                                            <div class="exam-question-actions">
                                                <button type="button" class="exam-btn-delete" onclick="deleteQuestion(<?php echo $i; ?>)">
                                                    🗑️ حذف
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="exam-form-grid" style="grid-template-columns: 2fr 1fr;">
                                            <div class="exam-form-group">
                                                <label>متن سؤال</label>
                                                <textarea name="q_text[]" rows="3" required><?php echo h($q['text']); ?></textarea>
                                            </div>
                                            <div class="exam-form-group">
                                                <label>نوع سؤال</label>
                                                <select name="q_type[]">
                                                    <option value="mcq" <?php echo $q['type']==='mcq'?'selected':''; ?>>چهارگزینه‌ای</option>
                                                    <option value="tf" <?php echo $q['type']==='tf'?'selected':''; ?>>درست/غلط</option>
                                                    <option value="short" <?php echo $q['type']==='short'?'selected':''; ?>>تشریحی</option>
                                                </select>
                                                
                                                <label style="margin-top: 10px;">امتیاز</label>
                                                <input type="number" name="q_points[]" value="<?php echo h((int)($q['points']??1)); ?>" min="1" max="10">
                                            </div>
                                        </div>

                                        <?php if ($q['type']==='mcq'): ?>
                                            <div>
                                                <label style="margin-top: 15px;">📘 گزینه‌ها (گزینه صحیح را انتخاب کنید)</label>
                                                <?php
                                                  $opts = normalize_options_to_strings($q['options'] ?? []);
                                                  $ci = array_key_exists('correct_index',$q) ? $q['correct_index'] : null;
                                                  $ci = ($ci === null ? null : max(0, min(3, (int)$ci)));
                                                ?>
                                                <?php for($k=0;$k<4;$k++): ?>
                                                    <div class="exam-option">
                                                        <input type="radio" name="q<?php echo $i; ?>_correct" value="<?php echo $k; ?>" <?php echo ($ci !== null && $ci===$k)?'checked':''; ?>>
                                                        <input type="text" name="q<?php echo $i; ?>_opt[]" value="<?php echo h($opts[$k]); ?>" placeholder="گزینه <?php echo $k+1; ?>" required>
                                                    </div>
                                                <?php endfor; ?>
                                            </div>
                                        <?php elseif ($q['type']==='tf'): ?>
                                            <div>
                                                <label style="margin-top: 15px;">✅ پاسخ صحیح</label>
                                                <?php
                                                  $ans = array_key_exists('answer',$q) ? ( (is_null($q['answer'])) ? null : (int)(!!$q['answer']) ) : null;
                                                ?>
                                                <div class="exam-tf-choices">
                                                    <div class="exam-tf-pill true <?php echo ($ans===1)?'active':''; ?>">
                                                        <input type="radio" name="q<?php echo $i; ?>_tf" value="1" <?php echo ($ans===1)?'checked':''; ?>>
                                                        <label style="margin: 0;">✔️ درست</label>
                                                    </div>
                                                    <div class="exam-tf-pill false <?php echo ($ans===0)?'active':''; ?>">
                                                        <input type="radio" name="q<?php echo $i; ?>_tf" value="0" <?php echo ($ans===0)?'checked':''; ?>>
                                                        <label style="margin: 0;">❌ غلط</label>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div>
                                                <label style="margin-top: 15px;">📝 پاسخ تشریحی (کلید پاسخ)</label>
                                                <textarea name="q<?php echo $i; ?>_short" rows="3" placeholder="پاسخ نمونه یا کلیدواژه‌های مهم..."><?php echo h($q['answer'] ?? ''); ?></textarea>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- بخش افزودن سوالات بیشتر -->
                            <div class="add-questions-section">
                                <h4>➕ افزودن سوالات بیشتر با AI</h4>
                                <p style="margin: 0.5rem 0; color: rgba(255, 255, 255, 0.8);">می‌توانید سوالات بیشتری برای این آزمون تولید کنید</p>
                                <div class="add-questions-controls">
                                    <input type="number" id="additionalCount" min="1" max="10" value="3" 
                                           style="width: 100px; padding: 0.8rem; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.1); color: #000;">
                                    <button type="button" class="exam-btn exam-btn-success" onclick="addMoreQuestions()">
                                        🤖 تولید سوالات بیشتر
                                    </button>
                                </div>
                            </div>

                            <hr>
                            
                            <div class="footer">
                                <button type="submit" class="exam-btn exam-btn-primary">
                                    💾 ذخیره و انتشار آزمون
                                </button>
                                <button type="button" class="exam-btn exam-btn-soft" onclick="if(confirm('آیا از بازگشت اطمینان دارید؟ تغییرات ذخیره نخواهد شد.')) history.back()">
                                    ↩️ بازگشت
                                </button>
                                <button type="button" class="exam-btn exam-btn-danger" onclick="if(confirm('آیا از شروع مجدد اطمینان دارید؟')) window.location.href=window.location.pathname">
                                    🔄 شروع مجدد
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Aside -->
            <aside class="exam-aside">
                <div class="exam-summary-card">
                    <h3>📊 خلاصه آزمون AI</h3>
                    <?php if ($step === 'form'): ?>
                        <div class="exam-summary-item">نوع تولید: <span><?php echo $form['type'] === 'mcq' ? 'چهارگزینه‌ای' : ($form['type'] === 'tf' ? 'درست/غلط' : 'پاسخ کوتاه'); ?></span></div>
                        <div class="exam-summary-item">تعداد سؤال: <span><?php echo h($form['count']); ?></span></div>
                        <div class="exam-summary-item">سطح دشواری: <span><?php echo h($form['difficulty']); ?></span></div>
                        <div class="exam-summary-item">با پاسخ: <span><?php echo $form['with_answers'] ? 'بله' : 'خیر'; ?></span></div>
                    <?php else: ?>
                        <div class="exam-summary-item">عنوان: <span><?php echo h($defaultTitle); ?></span></div>
                        <div class="exam-summary-item">تاریخ: <span><?php echo h($today); ?></span></div>
                        <div class="exam-summary-item">مدت: <span><?php echo h($defDur); ?></span> دقیقه</div>
                        <div class="exam-summary-item">تعداد سؤالات: <span><?php echo count($generated); ?></span></div>
                        <div class="exam-kpis">
                            <?php
                            $pts = array_map(function($q) { return $q['points']; }, $generated);
                            $maxPt = $pts ? max($pts) : 0;
                            $minPt = $pts ? min($pts) : 0;
                            $avgPt = $pts ? array_sum($pts) / count($pts) : 0;
                            ?>
                            <div class="exam-kpi">حداکثر امتیاز سؤال<br><strong><?php echo $maxPt; ?></strong></div>
                            <div class="exam-kpi">حداقل امتیاز سؤال<br><strong><?php echo $minPt; ?></strong></div>
                            <div class="exam-kpi">میانگین امتیاز<br><strong><?php echo number_format($avgPt, 1); ?></strong></div>
                        </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 1.5rem; padding: 1rem; background: rgba(255, 255, 255, 0.1); border-radius: 12px;">
                        <h4 style="margin: 0 0 0.5rem 0; color: #ffd93d;">💡 نکات مهم:</h4>
                        <ul style="margin: 0; padding-right: 1.2rem; font-size: 0.85rem; color: rgba(255, 255, 255, 0.8);">
                            <li>هوش مصنوعی OpenAI (GPT-4) سؤالات را تولید می‌کند</li>
                            <li>می‌توانید سؤالات را ویرایش یا حذف کنید</li>
                            <li>قابلیت افزودن سوالات بیشتر با AI</li>
                            <li>برای نتایج بهتر، موضوع را دقیق وارد کنید</li>
                        </ul>
                    </div>
                </div>
            </aside>
        </div>
    </div>

    <script>
        // حذف سوال
        function deleteQuestion(index) {
            if (!confirm('آیا از حذف این سوال اطمینان دارید؟')) return;
            
            const questionDiv = document.getElementById('question-' + index);
            if (questionDiv) {
                questionDiv.style.opacity = '0';
                questionDiv.style.transform = 'translateX(100%)';
                questionDiv.style.transition = 'all 0.3s ease';
                
                setTimeout(() => {
                    questionDiv.remove();
                    updateQuestionNumbers();
                }, 300);
            }
        }

        // به‌روزرسانی شماره سؤالات
        function updateQuestionNumbers() {
            const questions = document.querySelectorAll('.exam-question-item');
            questions.forEach((q, index) => {
                const titleElement = q.querySelector('.exam-question-title b');
                if (titleElement) {
                    titleElement.textContent = 'سؤال ' + (index + 1);
                }
            });
        }

        // افزودن سوالات بیشتر
        function addMoreQuestions() {
            const count = document.getElementById('additionalCount').value;
            if (count < 1 || count > 10) {
                alert('تعداد سوالات اضافی باید بین 1 تا 10 باشد.');
                return;
            }

            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const stepInput = document.createElement('input');
            stepInput.type = 'hidden';
            stepInput.name = 'step';
            stepInput.value = 'add_more';
            form.appendChild(stepInput);
            
            const countInput = document.createElement('input');
            countInput.type = 'hidden';
            countInput.name = 'additional_count';
            countInput.value = count;
            form.appendChild(countInput);

            // ارسال سؤالات موجود
            const existingQuestions = [];
            const questionDivs = document.querySelectorAll('.exam-question-item');
            questionDivs.forEach((div, i) => {
                const type = div.querySelector('select[name="q_type[]"]').value;
                const text = div.querySelector('textarea[name="q_text[]"]').value;
                const points = div.querySelector('input[name="q_points[]"]').value;
                
                const q = { type, text, points };
                
                if (type === 'mcq') {
                    const opts = [];
                    div.querySelectorAll('input[name="q' + i + '_opt[]"]').forEach(inp => {
                        opts.push(inp.value);
                    });
                    q.options = opts;
                    
                    const correctRadio = div.querySelector('input[name="q' + i + '_correct"]:checked');
                    q.correct_index = correctRadio ? parseInt(correctRadio.value) : null;
                } else if (type === 'tf') {
                    const tfRadio = div.querySelector('input[name="q' + i + '_tf"]:checked');
                    q.answer = tfRadio ? (tfRadio.value === '1') : null;
                } else {
                    const shortText = div.querySelector('textarea[name="q' + i + '_short"]');
                    q.answer = shortText ? shortText.value : '';
                }
                
                existingQuestions.push(q);
            });
            
            const questionsInput = document.createElement('input');
            questionsInput.type = 'hidden';
            questionsInput.name = 'existing_questions';
            questionsInput.value = JSON.stringify(existingQuestions);
            form.appendChild(questionsInput);

            // ارسال فرم‌های پنهان برای حفظ تنظیمات
            ['subject', 'grade', 'difficulty', 'topic', 'notes', 'type', 'count', 'with_answers'].forEach(field => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = field;
                input.value = document.querySelector('input[name="' + field + '"]') ? 
                              document.querySelector('input[name="' + field + '"]').value : '';
                form.appendChild(input);
            });

            const titleInput = document.createElement('input');
            titleInput.type = 'hidden';
            titleInput.name = 'title';
            titleInput.value = document.getElementById('examTitle').value;
            form.appendChild(titleInput);
            
            document.body.appendChild(form);
            form.submit();
        }

        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');

            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                    }
                });

                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    }
                });

                mobileDropdown.addEventListener('click', function(e) {
                    if (e.target.tagName === 'A') {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    }
                });
            }
        });

        // Stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            createStars();
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                setTimeout(() => {
                    el.style.opacity = '1';
                }, index * 100);
            });
        });

        function navigateToSection(section) {
            window.location.href = '/index.php#' + section;
        }
    </script>

</body>
</html>