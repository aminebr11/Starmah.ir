<?php
/* =============================================================
 * export_pdf.php - نسخه بدون نیاز به کتابخانه (HTML Printable)
 * ============================================================= */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../functions.php';

// اصلاح خطای سشن
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// بررسی دسترسی
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'admin') {
    die('دسترسی غیرمجاز');
}

// دریافت داده‌ها
try {
    // آمار کلی
    $stmt = $conn->query("SELECT COUNT(*) FROM quizzes");
    $totalQuizzes = $stmt->fetchColumn();
    $stmt = $conn->query("SELECT COUNT(*) FROM users WHERE user_type='student'");
    $totalStudents = $stmt->fetchColumn();

    // لیست آخرین نمرات
    $stmt = $conn->query("
        SELECT u.last_name, u.first_name, q.title, qa.score, qa.total_score, qa.submitted_at 
        FROM quiz_attempts qa
        JOIN users u ON qa.student_id = u.id
        JOIN quizzes q ON qa.quiz_id = q.id
        ORDER BY qa.submitted_at DESC
        LIMIT 50
    ");
    $recentAttempts = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("خطا در دریافت اطلاعات: " . $e->getMessage());
}

// تابع تاریخ
function getJalaliStr($dateStr) {
    if (empty($dateStr)) return '-';
    $ts = strtotime($dateStr);
    if (function_exists('gregorian_to_jalali')) {
        list($jy, $jm, $jd) = gregorian_to_jalali(date('Y', $ts), date('m', $ts), date('d', $ts));
        return "$jy/$jm/$jd";
    }
    return date('Y/m/d', $ts);
}

$todayDate = getJalaliStr(date('Y-m-d'));
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <title>گزارش تفصیلی - <?php echo $todayDate; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Vazirmatn', Tahoma, sans-serif; 
            padding: 20px; 
            background: #fff;
            color: #000;
        }
        .report-header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        h1 { margin: 0; font-size: 24px; }
        .meta { color: #555; margin-top: 10px; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: center; font-size: 14px; }
        th { background-color: #f0f0f0; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }

        .summary-box {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 8px;
        }
        .stat-item { text-align: center; }
        .stat-value { font-size: 20px; font-weight: bold; display: block; }
        
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
            table { border-color: #000; }
            th { background-color: #ddd !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print" style="text-align: center; margin-bottom: 20px; padding: 10px; background: #e0f2fe; border-radius: 8px;">
        <p>🖨️ پنجره پرینت به صورت خودکار باز می‌شود. برای ذخیره، گزینه <b>Save as PDF</b> را انتخاب کنید.</p>
        <a href="/sections/exams/reports.php" style="text-decoration: none; color: #2563eb; font-weight: bold;">بازگشت به پنل</a>
    </div>

    <div class="report-header">
        <h1>گزارش تفصیلی عملکرد سیستم آزمون</h1>
        <div class="meta">تاریخ گزارش: <?php echo $todayDate; ?></div>
    </div>

    <h3>📊 خلاصه وضعیت کلی</h3>
    <div class="summary-box">
        <div class="stat-item">
            <span class="stat-value"><?php echo $totalQuizzes; ?></span>
            <span>تعداد آزمون‌ها</span>
        </div>
        <div class="stat-item">
            <span class="stat-value"><?php echo $totalStudents; ?></span>
            <span>تعداد دانش‌آموزان</span>
        </div>
    </div>

    <h3>📋 آخرین نتایج ثبت شده (۵۰ مورد اخیر)</h3>
    <table>
        <thead>
            <tr>
                <th>ردیف</th>
                <th>نام دانش‌آموز</th>
                <th>عنوان آزمون</th>
                <th>نمره</th>
                <th>تاریخ و ساعت</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($recentAttempts) > 0): ?>
                <?php foreach ($recentAttempts as $index => $row): 
                    $scorePercent = ($row['total_score'] > 0) ? round(($row['score']/$row['total_score'])*100) : 0;
                    $jDateStr = getJalaliStr($row['submitted_at']) . ' - ' . date('H:i', strtotime($row['submitted_at']));
                ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td style="text-align: right;"><?php echo htmlspecialchars($row['last_name'] . ' ' . $row['first_name']); ?></td>
                    <td style="text-align: right;"><?php echo htmlspecialchars($row['title']); ?></td>
                    <td dir="ltr"><?php echo $scorePercent; ?>%</td>
                    <td dir="ltr"><?php echo $jDateStr; ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">اطلاعاتی یافت نشد</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div style="text-align: center; margin-top: 50px; font-size: 12px; color: #777;">
        این گزارش توسط سیستم مدیریت آزمون ستاره ماه تولید شده است.
    </div>

</body>
</html>