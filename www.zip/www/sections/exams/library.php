<?php
/******************************************************
 * library.php — Quiz Reports & Editor (بازطراحی شده)
 * - Uses quizzes / quiz_questions / quiz_attempts / users
 * - DataTables list + details + editor + print with/without answers
 * - طراحی بصری مطابق با builder.php و create_ai_exam.php
 * - Tahoma font everywhere, RTL Persian UI
 * - Robust MCQ rendering (options array of strings or objects)
 * - Persistent delete of removed questions when saving
 * - Responsive (mobile-friendly)
 ******************************************************/
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Tehran');

/* =======================
   1) CONFIG & DB (حفظ تنظیمات اصلی)
   ======================= */

// Try to load external config if available
if (file_exists(__DIR__.'/config.php')) {
  require_once __DIR__.'/config.php';
}

if (!defined('DB_HOST')) define('DB_HOST', 'localhost:3306');
if (!defined('DB_NAME')) define('DB_NAME', 'qwaepiuv_starmah_db');
if (!defined('DB_USER')) define('DB_USER', 'qwaepiuv_aminebr');
if (!defined('DB_PASS')) define('DB_PASS', 'Test12345!@#');

function db(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;
  try {
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false, 'error'=>'DB connection failed: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
  }
  return $pdo;
}

/* =======================
   2) AJAX API (حفظ API اصلی)
   ======================= */
$action = $_GET['action'] ?? $_POST['action'] ?? null;
if ($action) {
  try {
    $pdo = db();
    switch ($action) {

      case 'list': {
        // quizzes + counts (quiz_attempts is authoritative in this schema)
        $sql = "SELECT 
                  q.*,
                  COUNT(DISTINCT qq.id)  AS questions_count,
                  COUNT(DISTINCT qa.id)  AS participants_count
                FROM quizzes q
                LEFT JOIN quiz_questions qq 
                       ON q.id = qq.quiz_id AND qq.is_active = 1
                LEFT JOIN quiz_attempts qa 
                       ON q.id = qa.quiz_id
                GROUP BY q.id
                ORDER BY q.id DESC";
        $rows = $pdo->query($sql)->fetchAll();
        echo json_encode(['data'=>$rows], JSON_UNESCAPED_UNICODE);
        exit;
      }

      case 'details': {
        $quiz_id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
        if ($quiz_id <= 0) { echo json_encode(['ok'=>false,'error'=>'شناسه آزمون نامعتبر است.']); exit; }

        $stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id=?");
        $stmt->execute([$quiz_id]);
        $quiz = $stmt->fetch();
        if (!$quiz) { echo json_encode(['ok'=>false,'error'=>'آزمون یافت نشد.']); exit; }

        $stmt = $pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id=? AND is_active=1 ORDER BY question_order, id");
        $stmt->execute([$quiz_id]);
        $questions = $stmt->fetchAll();

        // participants from quiz_attempts + users
        $stmt = $pdo->prepare("
          SELECT qa.*,
                 CONCAT(u.first_name,' ',u.last_name) AS name,
                 u.first_name, u.last_name, u.username, u.national_id
          FROM quiz_attempts qa
          LEFT JOIN users u ON qa.student_id = u.id
          WHERE qa.quiz_id = ?
          ORDER BY qa.submitted_at DESC
        ");
        $stmt->execute([$quiz_id]);
        $attempts = $stmt->fetchAll();

        echo json_encode(['ok'=>true, 'quiz'=>$quiz, 'questions'=>$questions, 'attempts'=>$attempts], JSON_UNESCAPED_UNICODE);
        exit;
      }

      case 'update': {
        $quiz_id = (int)($_POST['id'] ?? 0);
        if ($quiz_id <= 0) { echo json_encode(['ok'=>false, 'error'=>'شناسه آزمون نامعتبر است.']); exit; }

        $fields = ['title','exam_date','exam_time','duration_minutes','is_active','is_visible','shuffle_questions','negative_marking'];
        $set = []; $vals = [];
        foreach ($fields as $f) {
          if (isset($_POST[$f])) {
            $set[] = "$f = ?";
            $vals[] = $_POST[$f];
          }
        }
        if (!$set) { echo json_encode(['ok'=>false,'error'=>'فیلدی برای بروزرسانی ارسال نشده است.']); exit; }
        $vals[] = $quiz_id;
        $sql = "UPDATE quizzes SET ".implode(',',$set)." WHERE id=?";
        $stmt = $pdo->prepare($sql); $stmt->execute($vals);
        echo json_encode(['ok'=>true]);
        exit;
      }

      case 'save_questions': {
        $quiz_id = (int)($_POST['quiz_id'] ?? 0);
        if ($quiz_id <= 0) { echo json_encode(['ok'=>false, 'error'=>'شناسه آزمون نامعتبر است.']); exit; }

        // accept JSON body or POST field
        $raw = file_get_contents('php://input');
        $payload = [];
        if ($raw) {
          $tmp = json_decode($raw, true);
          if (is_array($tmp)) $payload = $tmp;
        }
        if (!$payload && isset($_POST['payload'])) {
          $tmp = json_decode($_POST['payload'], true);
          if (is_array($tmp)) $payload = $tmp;
        }
        if (!$payload && isset($_POST['questions'])) {
          $payload['questions'] = $_POST['questions'];
        }

        $questions = $payload['questions'] ?? [];
        if (!is_array($questions)) $questions = [];
        $kept = [];

        foreach ($questions as $q) {
          $qid = isset($q['id']) ? (int)$q['id'] : 0;
          $question_text = trim($q['question_text'] ?? '');
          $question_type = $q['question_type'] ?? 'mcq';
          $question_data = $q['question_data'] ?? [];
          $points        = (int)($q['points'] ?? 1);
          $order         = (int)($q['question_order'] ?? 1);
          $is_active     = 1;

          if ($qid > 0) {
            $stmt = $pdo->prepare("UPDATE quiz_questions SET question_text=?, question_type=?, question_data=?, points=?, question_order=?, is_active=? WHERE id=? AND quiz_id=?");
            $stmt->execute([$question_text, $question_type, json_encode($question_data, JSON_UNESCAPED_UNICODE), $points, $order, $is_active, $qid, $quiz_id]);
            $kept[] = $qid;
          } else {
            $stmt = $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question_text, question_type, question_data, points, question_order, is_active) VALUES (?,?,?,?,?,?,1)");
            $stmt->execute([$quiz_id, $question_text, $question_type, json_encode($question_data, JSON_UNESCAPED_UNICODE), $points, $order]);
            $kept[] = (int)$pdo->lastInsertId();
          }
        }

        // delete removed
        if (count($kept) > 0) {
          $in = implode(',', array_fill(0, count($kept), '?'));
          $params = array_merge([$quiz_id], $kept);
          $del = $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id = ? AND id NOT IN ($in)");
          $del->execute($params);
        } else {
          $del = $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id = ?");
          $del->execute([$quiz_id]);
        }

        // update counts
        $cnt = $pdo->prepare("SELECT COUNT(*) FROM quiz_questions WHERE quiz_id=? AND is_active=1");
        $cnt->execute([$quiz_id]); $questions_count = (int)$cnt->fetchColumn();

        $sum = $pdo->prepare("SELECT COALESCE(SUM(points),0) FROM quiz_questions WHERE quiz_id=? AND is_active=1");
        $sum->execute([$quiz_id]); $total_points = (int)$sum->fetchColumn();

        $u = $pdo->prepare("UPDATE quizzes SET questions_count=?, total_points=? WHERE id=?");
        $u->execute([$questions_count, $total_points, $quiz_id]);

        echo json_encode(['ok'=>true, 'questions_count'=>$questions_count, 'total_points'=>$total_points], JSON_UNESCAPED_UNICODE);
        exit;
      }

      case 'delete': {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { echo json_encode(['ok'=>false, 'error'=>'شناسه نامعتبر.']); exit; }
        $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM quiz_attempts WHERE quiz_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM quizzes WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]); exit;
      }

      case 'delete_bulk': {
        $ids = $_POST['ids'] ?? [];
        if (!is_array($ids) || !$ids) { echo json_encode(['ok'=>false, 'error'=>'ids empty']); exit; }
        $ids = array_map('intval', $ids);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id IN ($in)")->execute($ids);
        $pdo->prepare("DELETE FROM quiz_attempts WHERE quiz_id IN ($in)")->execute($ids);
        $pdo->prepare("DELETE FROM quizzes WHERE id IN ($in)")->execute($ids);
        echo json_encode(['ok'=>true]); exit;
      }

      default:
        echo json_encode(['ok'=>false,'error'=>'unknown action']); exit;
    }

  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'خطا: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
  }
  exit;
}

// --- Session for greeting (مشابه دو صفحه قبلی) ---
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>📚 کتابخانه آزمون‌ها - ستاره ماه</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- اضافه کردن فونت‌ها و استایل‌های مطابق صفحات قبلی -->
<link rel="stylesheet" href="/style.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/script.css" />
<!-- کتابخانه‌های DataTables -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css">
<style>
/* استایل‌های اضافی برای کتابخانه آزمون‌ها (مطابق builder.php) */
.exam-builder-container {
  max-width:1400px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.exam-subnav {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  margin: 1rem 0 2rem 0;
  padding: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.exam-subnav-links {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.exam-subnav-link {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  padding: 0.8rem 1.5rem;
  border-radius: 15px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 0.95rem;
}

.exam-subnav-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  color: white;
}

.exam-subnav-link.active {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border-color: transparent;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

/* کارت‌های اصلی */
.exam-card {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
}

.exam-card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: linear-gradient(135deg, #83eaf1, #63a4ff);
  color: #0b1220;
  padding: 1rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
}

.exam-step-number {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 800;
  font-size: 0.9rem;
}

.exam-card-title {
  flex: 1;
}

.exam-card-title h2 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 800;
}

.exam-card-title p {
  margin: 0.3rem 0 0 0;
  opacity: 0.9;
  font-size: 0.9rem;
}

.exam-badge {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.85rem;
}

/* دکمه‌ها */
.exam-btn {
  border: none;
  border-radius: 12px;
  padding: 0.8rem 1.5rem;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
  font-family: 'Tahoma', tahoma, sans-serif;
}

.exam-btn-primary {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.exam-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6);
}

.exam-btn-soft {
  background: rgba(139,92,246,.15);
  color: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.exam-btn-danger {
  background: rgba(244,63,94,.15);
  color: #fecaca;
  border: 1px solid rgba(244,63,94,.3);
}

/* استایل‌های جدول */
:root{ 
  --primary:#667eea; --primary-dark:#5a67d8; --accent:#764ba2;
  --bg:#f5f7fb; --card:#ffffff; --border:#e2e8f0; --text:#1a202c;
  --muted:#718096;
}

body{
  font-family:'Tahoma', tahoma, sans-serif;
  background:linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
  min-height:100vh
}

.table {
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.btn, .btn-primary, .btn-danger, .btn-secondary, .btn-success{
  font-family:'Tahoma', tahoma, sans-serif !important;
  border-radius:12px
}

.table thead th{
  font-weight:700;
  background: rgba(255, 255, 255, 0.1);
  color: rgba(0, 0, 0, 0.8);
}

.dataTables_wrapper .dataTables_filter input{
  border-radius:10px;
  border:1px solid var(--border);
  font-family: 'Tahoma', tahoma, sans-serif;
}

/* Questions */
.correct-answer{
  background:#e6ffed;
  border:1px solid #34d399;
  padding:6px;
  border-radius:6px;
  display:inline-block;
  margin-top:6px
}

.options-list > div{
  margin:3px 0
}

.question-edit-item.active{
  border:2px solid var(--primary);
  box-shadow:0 0 0 3px rgba(102,126,234,.15)
}

/* Print */
@media print{
  html,body{
    font-family:'Tahoma', tahoma, sans-serif;
    -webkit-print-color-adjust:exact;
    print-color-adjust:exact;
    direction:rtl;
    text-align:right
  }
  .no-print{display:none !important}
  .printable{margin:0}
  .question-item{page-break-inside:avoid}
  .page-break{page-break-before:always}
  h1,h2,h3{color:#000 !important}
}

/* Modal styles */
.modal-content {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
}

.modal-header {
  background: linear-gradient(135deg, #83eaf1, #63a4ff);
  color: #0b1220;
  border-radius: 20px 20px 0 0;
  border-bottom: none;
}

.form-control, .form-select {
  font-family: 'Tahoma', tahoma, sans-serif !important;
  border-radius: 8px;
}

.nav-tabs .nav-link {
  font-family: 'Tahoma', tahoma, sans-serif !important;
  border-radius: 8px 8px 0 0;
}

.nav-tabs .nav-link.active {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border-color: transparent;
}

/* Form styles for edit */
.question-edit-item textarea,
.question-edit-item input[type="text"],
.question-edit-item input[type="number"],
.question-edit-item select {
  font-family: 'Tahoma', tahoma, sans-serif !important;
  color: #000000 !important;
  background: rgba(255, 255, 255, 0.9) !important;
  border: 1px solid rgba(0, 0, 0, 0.2) !important;
  border-radius: 8px !important;
}

.question-edit-item textarea:focus,
.question-edit-item input:focus,
.question-edit-item select:focus {
  border-color: #6bcf7f !important;
  outline: none !important;
  box-shadow: 0 0 10px rgba(107, 207, 127, 0.3) !important;
}

/* Mobile tweaks */
@media (max-width: 768px){
  .exam-builder-container {
    margin: 1rem auto;
    padding: 0 0.5rem;
  }
  
  .exam-card{
    border-radius:16px;
    padding: 1rem;
  }
  
  .btn{
    padding:.4rem .75rem
  }
  
  .table{
    font-size:.9rem
  }
  
  .dataTables_wrapper .dataTables_filter{
    float:none;
    text-align:center;
    margin:8px 0
  }
  
  .exam-subnav {
    margin: 0.5rem 0 1rem 0;
    padding: 0.8rem;
  }
  
  .exam-subnav-link {
    padding: 0.6rem 1rem;
    font-size: 0.9rem;
  }
}

/* Animation for form elements */
.fade-in {
  animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
</head>
<body>
    <!-- Background Elements (مطابق صفحات قبلی) -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation (منوی اصلی مطابق صفحات قبلی) -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <!-- تغییر لینک لوگو -->
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <!-- Desktop Menu با لینک‌های صحیح -->
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮 بازی‌ها</a>
                    <a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mobile Menu با لینک‌های صحیح -->
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی نوببری" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Auth Section -->
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Exam Builder Container -->
    <div class="exam-builder-container">
        
        <!-- زیرناوبری چهارگانه آزمون‌ساز (مطابق صفحات قبلی) -->
        <div class="exam-subnav">
            <div class="exam-subnav-links">
                <a href="/sections/exams/create_ai_exam.php" class="exam-subnav-link">🤖 ساخت خودکار (AI)</a>
                <a href="/sections/exams/builder.php" class="exam-subnav-link">🛠️ آزمون‌ساز دستی</a>
                <a href="/sections/exams/library.php" class="exam-subnav-link active">📚 کتابخانه آزمون‌ها</a>
                <a href="/sections/exams/reports.php" class="exam-subnav-link">📈 گزارش‌ها</a>
            </div>
        </div>

        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">📚 کتابخانه آزمون‌ها</h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9); font-size: 1.2rem;">مدیریت، ویرایش و گزارش‌گیری از آزمون‌های موجود</p>
        </div>

        <!-- Main Content -->
        <div class="exam-card fade-in">
            <div class="exam-card-header">
                <div class="exam-step-number">📋</div>
                <div class="exam-card-title">
                    <h2>لیست آزمون‌های موجود</h2>
                    <p>مشاهده، ویرایش و مدیریت آزمون‌ها</p>
                </div>
                <div class="exam-badge">مدیریت کامل</div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <div class="d-flex align-items-center gap-2">
                    <button class="exam-btn exam-btn-danger btn-sm" id="deleteSelected">🗑️ حذف گروهی</button>
                </div>
            </div>
            
            <div class="table-responsive">
                <table id="quizzesTable" class="table table-striped nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th data-priority="1"><input type="checkbox" id="selectAll"></th>
                            <th data-priority="1">عنوان</th>
                            <th>تاریخ</th>
                            <th>ساعت</th>
                            <th>مدت</th>
                            <th>سوالات</th>
                            <th data-priority="2">شرکت‌کنندگان</th>
                            <th data-priority="1">اقدامات</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Details / Edit Modal (حفظ مودال اصلی) -->
    <div class="modal fade" id="detailsModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">📝 جزئیات آزمون</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
                </div>
                <div class="modal-body">
                    <!-- Quiz Meta Form -->
                    <form id="quizMetaForm" class="border rounded-3 p-3 mb-3" style="background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2) !important;">
                        <div class="row g-2">
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label">عنوان</label>
                                <input type="text" class="form-control" name="title">
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <label class="form-label">تاریخ</label>
                               <input type="text" class="form-control" name="exam_date" id="persianDateInput" placeholder="انتخاب تاریخ">

                               
                            </div>
                            <div class="col-md-6 col-lg-2">
                                <label class="form-label">ساعت</label>
                                <input type="time" class="form-control" name="exam_time">
                            </div>
                            <div class="col-md-6 col-lg-2">
                                <label class="form-label">مدت (دقیقه)</label>
                                <input type="number" class="form-control" name="duration_minutes" min="1">
                            </div>
                            <div class="col-md-6 col-lg-1 d-flex align-items-end">
                                <button type="button" class="exam-btn exam-btn-primary w-100" onclick="updateQuizMeta()">💾 ذخیره</button>
                            </div>
                        </div>
                        <div class="row g-2 mt-1">
                            <div class="col-md-3">
                                <label class="form-label">فعال؟</label>
                                <select name="is_active" class="form-select">
                                    <option value="1">بله</option>
                                    <option value="0">خیر</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">قابل مشاهده؟</label>
                                <select name="is_visible" class="form-select">
                                    <option value="1">بله</option>
                                    <option value="0">خیر</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">به‌هم‌ریختن ترتیب سوالات</label>
                                <select name="shuffle_questions" class="form-select">
                                    <option value="1">بله</option>
                                    <option value="0">خیر</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">نمره منفی</label>
                                <select name="negative_marking" class="form-select">
                                    <option value="0">خیر</option>
                                    <option value="1">بله</option>
                                </select>
                            </div>
                        </div>
                    </form>

                    <div id="quizInfo" class="mb-3"></div>

                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-questions" type="button">📋 سوالات</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-participants" type="button">👥 شرکت‌کنندگان</button></li>
                        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-questions-edit" type="button">✏️ ویرایش سوالات</button></li>
                    </ul>

                    <div class="tab-content pt-3">
                        <div class="tab-pane fade show active" id="tab-questions">
                            <div id="questionsList"></div>
                            <hr>
                            <div class="d-flex gap-2">
                                <button class="exam-btn exam-btn-soft" id="printBtn">🖨️ پرینت بدون پاسخ</button>
                                <button class="exam-btn exam-btn-primary" id="printWithAnswersBtn">🖨️ پرینت با پاسخ</button>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab-participants">
                            <div class="d-flex justify-content-end mb-2">
                                <button class="exam-btn exam-btn-primary btn-sm" onclick="printParticipants()">🖨️ پرینت لیست شرکت‌کنندگان</button>
                               <button 
    class="exam-btn exam-btn-warning btn-sm ms-2"
    id="resetAllBtn"
    onclick="resetAllParticipants()">
    🔄 آزادسازی برای همه
</button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="participantsTable">
                                    <thead>
  <tr>
    <th>#</th>
    <th>نام</th>
    <th>امتیاز</th>
    <th>کل</th>
    <th>زمان(دقیقه)</th>
    <th>تاریخ ارسال</th>
    <th>عملیات</th> <!-- ستون جدید -->
  </tr>
</thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab-questions-edit">
                            <div class="d-flex align-items-center gap-2 my-2 flex-wrap">
                                <button class="exam-btn exam-btn-soft btn-sm" onclick="prevQuestion()">← سوال قبلی</button>
                                <strong id="questionPos">—</strong>
                                <button class="exam-btn exam-btn-soft btn-sm" onclick="nextQuestion()">سوال بعدی →</button>
                                <button class="exam-btn exam-btn-primary ms-auto" onclick="saveAllQuestions()">💾 ذخیره همه سوالات</button>
                            </div>
                            <div id="questionsEditContainer"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="exam-btn exam-btn-soft" data-bs-dismiss="modal">بستن</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Print Window -->
    <div id="printArea" class="d-none"></div>

    <!-- اسکریپت‌های مورد نیاز -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
    <!-- بعد از jQuery اضافه کنید -->
<link rel="stylesheet" href="https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css"/>
<script src="https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js"></script>
<script src="https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
    <script>
    
        // Mobile menu toggle (مطابق صفحات قبلی)
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');
            const menuOverlay = document.getElementById('menuOverlay');

            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                        if (menuOverlay) menuOverlay.classList.add('show');
                    }
                });

                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });

                mobileDropdown.addEventListener('click', function(e) {
                    if (e.target.tagName === 'A') {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });
            }
        });

        // Initialize stars animation (مطابق صفحات قبلی)
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // نکات تعاملی برای تجربه کاربری بهتر
        function navigateToSection(section) {
            window.location.href = '/index.php#' + section;
        }

        // ===== توابع تبدیل تاریخ میلادی به شمسی (نمایش سمت کاربر) =====
        function toJalaliDate(dateStr) {
    if (!dateStr) return '';
    try {
        // اضافه کردن ساعت برای جلوگیری از مشکل timezone
        const dateWithTime = dateStr + 'T12:00:00';
        const d = new Date(dateWithTime);
        if (isNaN(d)) return dateStr;
        return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        }).format(d);
    } catch (e) {
        return dateStr;
    }
}

        function toJalaliDateTime(dateTimeStr) {
            if (!dateTimeStr) return '';
            try {
                // تبدیل "YYYY-MM-DD HH:MM:SS" به ISO قابل فهم برای جاوااسکریپت
                const iso = dateTimeStr.replace(' ', 'T');
                const d = new Date(iso);
                if (isNaN(d)) return dateTimeStr;
                const datePart = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                }).format(d);
                const timePart = d.toLocaleTimeString('fa-IR', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
                return datePart + ' - ' + timePart;
            } catch (e) {
                return dateTimeStr;
            }
        }

        // ===== متغیرهای اصلی (حفظ منطق اصلی) =====
        var DT = null;
        var currentQuizId = null;
        var currentDetails = null;
        var currentEditIndex = 0;
        var detailsModal = null;

        $(function(){
            // Initialize stars and animations
            createStars();
            
            // Initialize DataTable
            DT = $('#quizzesTable').DataTable({
                ajax: '?action=list',
                responsive: true,
                language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/fa.json' },
                columns: [
                    { data: null, render:(d)=>`<input type="checkbox" class="rowSel" value="${d.id}">`, orderable:false },
                    { data: 'title' },
                    { 
                        data: 'exam_date',
                        render: function(data) {
                            return toJalaliDate(data);
                        }
                    },
                    { data: 'exam_time' },
                    { data: 'duration_minutes' },
                    { data: 'questions_count' },
                    { data: 'participants_count' },
                    { data: null, orderable:false, render: (d)=>`
                        <div class="d-flex gap-1 flex-wrap">
                            <button class="exam-btn exam-btn-primary btn-sm" onclick="viewDetails(${d.id})">📝 جزئیات</button>
                            <button class="exam-btn exam-btn-danger btn-sm" onclick="deleteQuiz(${d.id})">🗑️ حذف</button>
                        </div>
                    ` }
                ]
            });

            $('#selectAll').on('change', function(){ $('.rowSel').prop('checked', this.checked); });
            $('#deleteSelected').on('click', function(){
                const ids = $('.rowSel:checked').toArray().map(el => el.value);
                if(!ids.length) return alert('چیزی انتخاب نشده است.');
                if(!confirm('حذف آزمون‌های انتخاب‌شده؟')) return;
                $.post('?action=delete_bulk', { ids: ids }, function(res){
                    if(res && res.ok) DT.ajax.reload(); else alert('حذف ناموفق');
                }, 'json').fail(()=>alert('خطا در حذف گروهی'));
            });
// فعال‌سازی date picker شمسی
    $("#persianDateInput").persianDatepicker({
        format: 'YYYY/MM/DD',
        autoClose: true,
        calendar: {
            persian: {
                locale: 'fa'
            }
        }
    });
            // Print buttons: داخل مودال فعال‌سازی می‌شود
            $('#detailsModal').on('hidden.bs.modal', function(){
                // اطمینان از جمع‌شدن بک‌دراپ و آزاد شدن اسکرول
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open').css('padding-right','');
            });
        });

        // ===== توابع اصلی (حفظ عملکرد اصلی) =====
        function viewDetails(id){
            currentQuizId = id;
            $.getJSON('?action=details', {id:id}, function(res){
                if(!res || !res.ok){ alert('خطا در خواندن جزئیات'); return; }
                currentDetails = res;
                fillQuizMetaForm(res.quiz);
                renderDetails(res);
                if (!detailsModal) { detailsModal = new bootstrap.Modal(document.getElementById('detailsModal')); }
                // فقط یک‌بار show
                if (!document.body.classList.contains('modal-open')) {
                    detailsModal.show();
                }
            }).fail(function(xhr){
                console.error('DETAILS ERR', xhr.responseText);
                alert('خطا در خواندن جزئیات: ' + (xhr.responseText || ''));
            });
        }

        function renderDetails(res){
            $('#quizInfo').html(`
                <div class="row g-2">
                    <div class="col-md-6 col-lg-4"><strong>عنوان:</strong> ${escapeHtml(res.quiz.title || '')}</div>
                    <div class="col-md-6 col-lg-4">
                        <strong>تاریخ:</strong> ${toJalaliDate(res.quiz.exam_date)} 
                        &nbsp; 
                        <strong>ساعت:</strong> ${escapeHtml(res.quiz.exam_time || '')}
                    </div>
                    <div class="col-md-6 col-lg-4"><strong>مدت:</strong> ${res.quiz.duration_minutes} دقیقه</div>
                    <div class="col-md-6 col-lg-4"><strong>سوالات فعال:</strong> ${res.quiz.questions_count}</div>
                    <div class="col-md-6 col-lg-4"><strong>امتیاز کل:</strong> ${res.quiz.total_points}</div>
                </div>
            `);

            // Questions view
            let html = '';
            if (res.questions && res.questions.length){
                res.questions.forEach((q,i)=>{ html += renderQuestionCard(q, i+1); });
            } else { html = '<p>سوالی ثبت نشده است.</p>'; }
            $('#questionsList').html(html);

            // Participants
            const tb = $('#participantsTable tbody');
            tb.empty();
            if (Array.isArray(res.attempts) && res.attempts.length) {
                res.attempts.forEach((a, idx) => {
                    const name = a?.name || ((a?.first_name && a?.last_name) ? (a.first_name + ' ' + a.last_name) : (a?.username || 'کاربر مهمان'));
                    tb.append(`<tr>
                        <td>${idx + 1}</td>
                        <td>${escapeHtml(name)}</td>
                        <td>${a?.score ?? ''}</td>
                        <td>${a?.total_score ?? ''}</td>
                        <td>${a?.time_taken ?? ''}</td>
                        <td>${escapeHtml(toJalaliDateTime(a?.submitted_at || ''))}</td>
                        <td>
                            <button class="exam-btn exam-btn-warning btn-sm" onclick="resetExamForUser(${currentQuizId}, ${a?.student_id})">♻️ آزادسازی</button>
                        </td>
                    </tr>`);
                });
            } else {
                tb.append('<tr><td colspan="7" class="text-center text-muted">شرکت‌کننده‌ای ثبت نشده است.</td></tr>');
            }

            // Load edit tab
            loadQuestionsForEdit();

            // فعال‌سازی دکمه‌های پرینت
            $('#printBtn').off('click').on('click', function(){ printQuiz(false); });
            $('#printWithAnswersBtn').off('click').on('click', function(){ printQuiz(true); });
        }

function fillQuizMetaForm(q){
    const f = document.getElementById('quizMetaForm');
    f.dataset.id = q.id;
    f.title.value = q.title || '';
    
    // تبدیل تاریخ با در نظر گرفتن timezone محلی
    if(q.exam_date) {
        // اضافه کردن ساعت 12 ظهر برای جلوگیری از مشکل timezone
        const dateStr = q.exam_date + 'T12:00:00';
        const pd = new persianDate(new Date(dateStr));
        f.exam_date.value = pd.format('YYYY/MM/DD');
    } else {
        f.exam_date.value = '';
    }
    
    f.exam_time.value = q.exam_time || '';
    f.duration_minutes.value = q.duration_minutes || 30;
    f.is_active.value = (q.is_active ?? 1);
    f.is_visible.value = (q.is_visible ?? 1);
    f.shuffle_questions.value = (q.shuffle_questions ?? 1);
    f.negative_marking.value = (q.negative_marking ?? 0);
}

        function updateQuizMeta(){
    const f = document.getElementById('quizMetaForm');
    const id = f.dataset.id;
    
    // تبدیل تاریخ شمسی به میلادی
    let gregorianDate = '';
    if(f.exam_date.value) {
        const parts = f.exam_date.value.split('/');
        if(parts.length === 3) {
            const pd = new persianDate([parseInt(parts[0]), parseInt(parts[1]), parseInt(parts[2])]);
            gregorianDate = pd.toDate().toISOString().split('T')[0];
        }
    }
    
    const data = {
        action: 'update',
        id: id,
        title: f.title.value,
        exam_date: gregorianDate,  // ارسال تاریخ میلادی به سرور
        exam_time: f.exam_time.value,
        duration_minutes: f.duration_minutes.value,
        is_active: f.is_active.value,
        is_visible: f.is_visible.value,
        shuffle_questions: f.shuffle_questions.value,
        negative_marking: f.negative_marking.value
    };
    
    $.post('', data, function(res){
        if(res && res.ok){
            alert('ذخیره شد.');
            refreshDetails(false);
            DT.ajax.reload(null, false);
        } else {
            alert('ذخیره ناموفق');
        }
    }, 'json').fail(function(xhr){
        console.error('UPDATE ERR', xhr.responseText);
        alert('خطا در ذخیره تنظیمات آزمون');
    });
}
        // ----- Render Question Card (View Tab) ----- //
        function renderQuestionCard(q, no){
            let qd = {};
            try{ qd = q.question_data ? JSON.parse(q.question_data) : {}; } catch(e){}
            let s = `<div class="border rounded-3 p-3 mb-2" style="background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2) !important;"><div class="fw-bold mb-1">${no}. ${escapeHtml(q.question_text || '')}</div>`;
            if (q.question_type === 'mcq' && qd.options){
                const ci = deriveCorrectIndex(qd);
                s += '<div class="options-list">';
                qd.options.forEach((opt, idx)=>{
                    const text = getOptionText(opt);
                    const letter = ['الف','ب','ج','د'][idx] || String.fromCharCode(65+idx);
                    s += `<div ${ci===idx ? 'class="correct-answer"' : ''}>${letter}) ${escapeHtml(text)} ${ci===idx ? '✓' : ''}</div>`;
                });
                s += '</div>';
            } else if (q.question_type === 'tf'){
                const ans = (qd.correct_answer===true || qd.correct_answer==='true');
                s += `<div class="correct-answer">پاسخ: ${ans?'درست':'نادرست'}</div>`;
            } else if (q.question_type === 'short'){
                s += `<div class="correct-answer">پاسخ: ${escapeHtml(qd.correct_answer || '')}</div>`;
            }
            s += `</div>`;
            return s;
        }

        // Helpers for MCQ
        function getOptionText(opt){
            if (typeof opt === 'string') return opt;
            if (!opt) return '';
            return opt.text || opt.label || opt.title || opt.value || '';
        }
        function deriveCorrectIndex(qd){
            if (qd && typeof qd.correct_answer === 'number') return qd.correct_answer;
            if (qd && typeof qd.correct_index === 'number') return qd.correct_index;
            if (qd && Array.isArray(qd.options)){
                for (let i=0;i<qd.options.length;i++){
                    const o = qd.options[i];
                    if (o && (o.is_correct || o.correct)) return i;
                }
            }
            return null;
        }

    // ----- Printing (with/without answers) - طراحی جدید برای دبستانی‌ها ----- //
function printQuiz(withAnswers){
    const res = currentDetails;
    if(!res) return;
    const title = escapeHtml(res.quiz.title || '');
    const date  = toJalaliDate(res.quiz.exam_date); // تبدیل به شمسی
    const time  = escapeHtml(res.quiz.exam_time || '');
    const dur   = res.quiz.duration_minutes || '';
    const total = res.quiz.total_points || '';

    // Header جذاب برای بچه‌های دبستانی
    const header = `
        <div class="exam-header">
            <div class="school-info">
                <div class="school-name">🏫 مدرسه ستاره ماه</div>
                <div class="school-motto">با هم یاد بگیریم، با هم رشد کنیم! 🌟</div>
            </div>
            <div class="exam-title-section">
                <h1 class="exam-main-title">📝 برگه آزمون</h1>
                <h2 class="exam-subject-title">${title}</h2>
            </div>
            <div class="exam-info-grid">
                <div class="info-box">
                    <span class="info-icon">📅</span>
                    <div class="info-content">
                        <div class="info-label">تاریخ آزمون</div>
                        <div class="info-value">${date}</div>
                    </div>
                </div>
                <div class="info-box">
                    <span class="info-icon">⏰</span>
                    <div class="info-content">
                        <div class="info-label">ساعت شروع</div>
                        <div class="info-value">${time}</div>
                    </div>
                </div>
                <div class="info-box">
                    <span class="info-icon">⏱️</span>
                    <div class="info-content">
                        <div class="info-label">مدت آزمون</div>
                        <div class="info-value">${dur} دقیقه</div>
                    </div>
                </div>
                <div class="info-box">
                    <span class="info-icon">🏅</span>
                    <div class="info-content">
                        <div class="info-label">امتیاز کل</div>
                        <div class="info-value">${total} نمره</div>
                    </div>
                </div>
            </div>
            <div class="student-info-section">
                <div class="student-field">
                    <span class="field-icon">👤</span>
                    <span class="field-label">نام و نام خانوادگی:</span>
                    <div class="field-line"></div>
                </div>
                <div class="student-field">
                    <span class="field-icon">🆔</span>
                    <span class="field-label">شماره دانش‌آموزی:</span>
                    <div class="field-line-short"></div>
                </div>
                <div class="student-field">
                    <span class="field-icon">📚</span>
                    <span class="field-label">کلاس:</span>
                    <div class="field-line-short"></div>
                </div>
            </div>
            <div class="instructions">
                <div class="instruction-title">📋 راهنمای پاسخ‌دهی:</div>
                <div class="instruction-content">
                    <div class="instruction-item">✓ برای سوالات چهارگزینه‌ای، حرف گزینه درست را دایره کنید</div>
                    <div class="instruction-item">✓ برای سوالات درست/غلط، گزینه مناسب را علامت بزنید</div>
                    <div class="instruction-item">✓ پاسخ‌ها را واضح و خوانا بنویسید</div>
                </div>
            </div>
            <div class="designer-credit">طراحی: نجمه محمودی • مدرسه ستاره ماه</div>
        </div>`;

    // ساخت سوالات با طراحی جدید
    let questionsHTML = '';
    const answerRows = [];
    
    if(res.questions && res.questions.length > 0){
        res.questions.forEach((q, i) => {
            let qd = {}; 
            try{ qd = q.question_data ? JSON.parse(q.question_data) : {}; }catch(e){}
            const n = i+1;
            const qText = escapeHtml(q.question_text||'');
            const points = q.points || 1;

            questionsHTML += `<div class="question-container">`;
            questionsHTML += `<div class="question-header">
                <span class="question-number">${n}</span>
                <span class="question-text">${qText}</span>
                <span class="question-points">(${points} نمره)</span>
            </div>`;

            if (q.question_type === 'mcq' && Array.isArray(qd.options)){
                const ci = deriveCorrectIndex(qd);
                questionsHTML += `<div class="mcq-options">`;
                
                ['الف', 'ب', 'ج', 'د'].forEach((letter, idx) => {
                    const optText = getOptionText(qd.options[idx] ?? '');
                    const isCorrect = (ci === idx);
                    const highlight = (withAnswers && isCorrect) ? 'correct-option' : '';
                    const checkMark = (withAnswers && isCorrect) ? ' ✓' : '';
                    
                    questionsHTML += `
                        <div class="option-row ${highlight}">
                            <div class="option-circle"></div>
                            <div class="option-letter">${letter})</div>
                            <div class="option-text">${escapeHtml(optText)}${checkMark}</div>
                        </div>`;
                });
                
                questionsHTML += `</div>`;
                if (typeof ci === 'number') answerRows.push({no:n, ans:['الف','ب','ج','د'][ci]});
                
            } else if (q.question_type === 'tf'){
                const corr = (qd.correct_answer===true || qd.correct_answer==='true');
                const trueClass = (withAnswers && corr) ? 'correct-option' : '';
                const falseClass = (withAnswers && !corr) ? 'correct-option' : '';
                const trueMark = (withAnswers && corr) ? ' ✓' : '';
                const falseMark = (withAnswers && !corr) ? ' ✓' : '';
                
                questionsHTML += `
                    <div class="tf-options">
                        <div class="tf-option ${trueClass}">
                            <div class="tf-checkbox"></div>
                            <span class="tf-text">درست${trueMark}</span>
                        </div>
                        <div class="tf-option ${falseClass}">
                            <div class="tf-checkbox"></div>
                            <span class="tf-text">غلط${falseMark}</span>
                        </div>
                    </div>`;
                answerRows.push({no:n, ans: corr ? 'درست' : 'غلط'});
                
            } else {
                const ans = qd.correct_answer || '';
                const answerContent = withAnswers ? escapeHtml(ans) : '';
                questionsHTML += `
                    <div class="short-answer">
                        <div class="answer-label">پاسخ:</div>
                        <div class="answer-lines">
                            <div class="answer-line">${answerContent}</div>
                            <div class="answer-line"></div>
                            <div class="answer-line"></div>
                        </div>
                    </div>`;
                answerRows.push({no:n, ans: ans});
            }
            
            questionsHTML += `</div>`; // بستن question-container
        });
    } else {
        questionsHTML += `<div class="no-questions">هیچ سوالی برای نمایش وجود ندارد.</div>`;
    }

    // صفحه پاسخ‌نامه جداگانه
    const answerSheet = `
        <div class="page-break"></div>
        <div class="answer-sheet">
            <div class="answer-sheet-header">
                <h2>📋 برگه پاسخ‌نامه</h2>
                <p>آزمون: ${title}</p>
            </div>
            <div class="answers-grid">
                ${answerRows.map((r, index) => `
                    <div class="answer-item ${(index + 1) % 5 === 0 ? 'row-end' : ''}">
                        <span class="answer-number">${r.no}</span>
                        <span class="answer-value">${escapeHtml(String(r.ans))}</span>
                    </div>
                `).join('')}
            </div>
        </div>`;

    // فوتر
    const footer = `
        <div class="exam-footer">
            <div class="signature-section">
                <div class="signature-box">
                    <div class="signature-label">امضاء دانش‌آموز</div>
                    <div class="signature-line"></div>
                </div>
                <div class="signature-box">
                    <div class="signature-label">امضاء مراقب</div>
                    <div class="signature-line"></div>
                </div>
                <div class="signature-box">
                    <div class="signature-label">امضاء معلم</div>
                    <div class="signature-line"></div>
                </div>
            </div>
            <div class="footer-message">
                <span>🌟 موفق باشید! 🌟</span>
            </div>
        </div>`;

    const html = `
        <div class="printable exam-paper">
            ${header}
            <div class="questions-section">
                ${questionsHTML}
            </div>
            ${answerSheet}
            ${footer}
        </div>`;

    const w = window.open('', '_blank');
    w.document.write(`<html dir="rtl"><head><title>آزمون ${title}</title>
        <meta charset="UTF-8">
        <style>
            @page { 
                size: A4; 
                margin: 15mm 12mm; 
            }
            
            * { 
                box-sizing: border-box; 
                margin: 0; 
                padding: 0; 
            }
            
            body {
                font-family: 'Tahoma', tahoma, sans-serif;
                font-size: 11pt;
                color: #000;
                direction: rtl;
                text-align: right;
                line-height: 1.4;
                background: white;
            }
            
            .printable {
                width: 100%;
                max-width: 210mm;
                margin: 0 auto;
            }
            
            /* === Header Styles === */
            .exam-header {
                border: 3px solid #2563eb;
                border-radius: 15px;
                padding: 15px;
                margin-bottom: 20px;
                background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
                position: relative;
                overflow: hidden;
            }
            
            .exam-header::before {
                content: '🌟✨🌙⭐';
                position: absolute;
                top: 8px;
                left: 15px;
                font-size: 12px;
                opacity: 0.6;
            }
            
            .school-info {
                text-align: center;
                margin-bottom: 12px;
            }
            
            .school-name {
                font-size: 16pt;
                font-weight: 900;
                color: #1e40af;
                margin-bottom: 4px;
            }
            
            .school-motto {
                font-size: 10pt;
                color: #3730a3;
                font-style: italic;
            }
            
            .exam-title-section {
                text-align: center;
                margin: 15px 0;
            }
            
            .exam-main-title {
                font-size: 22pt;
                font-weight: 900;
                color: #dc2626;
                margin-bottom: 8px;
                text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
            }
            
            .exam-subject-title {
                font-size: 14pt;
                font-weight: 700;
                color: #059669;
                border: 2px dashed #10b981;
                padding: 8px 15px;
                border-radius: 25px;
                display: inline-block;
                background: rgba(16, 185, 129, 0.1);
            }
            
            .exam-info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr 1fr 1fr;
                gap: 10px;
                margin: 15px 0;
            }
            
            .info-box {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px;
                background: white;
                border: 2px solid #e5e7eb;
                border-radius: 10px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .info-icon {
                font-size: 16pt;
            }
            
            .info-label {
                font-size: 8pt;
                color: #6b7280;
                font-weight: 600;
            }
            
            .info-value {
                font-size: 10pt;
                font-weight: 700;
                color: #1f2937;
            }
            
            .student-info-section {
                display: flex;
                justify-content: space-between;
                margin: 15px 0;
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .student-field {
                display: flex;
                align-items: center;
                gap: 8px;
                min-width: 200px;
            }
            
            .field-icon {
                font-size: 12pt;
            }
            
            .field-label {
                font-size: 10pt;
                font-weight: 600;
                color: #374151;
            }
            
            .field-line {
                flex: 1;
                height: 2px;
                border-bottom: 2px dotted #9ca3af;
                min-width: 120px;
            }
            
            .field-line-short {
                width: 80px;
                height: 2px;
                border-bottom: 2px dotted #9ca3af;
            }
            
            .instructions {
                background: #fef3c7;
                border: 2px solid #f59e0b;
                border-radius: 10px;
                padding: 12px;
                margin: 15px 0;
            }
            
            .instruction-title {
                font-size: 11pt;
                font-weight: 700;
                color: #92400e;
                margin-bottom: 8px;
            }
            
            .instruction-content {
                display: flex;
                flex-direction: column;
                gap: 4px;
            }
            
            .instruction-item {
                font-size: 9pt;
                color: #78350f;
            }
            
            .designer-credit {
                text-align: center;
                font-size: 8pt;
                color: #6b7280;
                margin-top: 10px;
                font-style: italic;
            }
            
            /* === Questions Styles === */
            .questions-section {
                margin: 20px 0;
            }
            
            .question-container {
                background: white;
                border: 2px solid #e5e7eb;
                border-radius: 12px;
                margin-bottom: 20px;
                padding: 15px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                break-inside: avoid;
            }
            
            .question-header {
                display: flex;
                align-items: flex-start;
                margin-bottom: 12px;
                gap: 10px;
            }
            
            .question-number {
                background: linear-gradient(135deg, #3b82f6, #1d4ed8);
                color: white;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 700;
                font-size: 11pt;
                flex-shrink: 0;
                box-shadow: 0 3px 6px rgba(59, 130, 246, 0.3);
            }
            
            .question-text {
                flex: 1;
                font-size: 11pt;
                font-weight: 600;
                color: #1f2937;
                line-height: 1.5;
            }
            
            .question-points {
                background: #fef3c7;
                color: #92400e;
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 9pt;
                font-weight: 600;
                border: 1px solid #f59e0b;
            }
            
            /* === MCQ Options === */
            .mcq-options {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
                margin-top: 12px;
            }
            
            .option-row {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                background: #f9fafb;
                transition: all 0.2s;
            }
            
            .option-row.correct-option {
                background: #dcfce7;
                border-color: #16a34a;
                box-shadow: 0 0 0 2px rgba(22, 163, 74, 0.2);
            }
            
            .option-circle {
                width: 18px;
                height: 18px;
                border: 2px solid #6b7280;
                border-radius: 50%;
                flex-shrink: 0;
                background: white;
            }
            
            .option-letter {
                font-weight: 700;
                color: #3730a3;
                font-size: 10pt;
                min-width: 20px;
            }
            
            .option-text {
                flex: 1;
                font-size: 10pt;
                color: #374151;
                line-height: 1.3;
            }
            
            /* === True/False Options === */
            .tf-options {
                display: flex;
                justify-content: center;
                gap: 40px;
                margin-top: 12px;
            }
            
            .tf-option {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 10px 20px;
                border: 2px solid #e5e7eb;
                border-radius: 25px;
                background: #f9fafb;
                min-width: 100px;
                justify-content: center;
            }
            
            .tf-option.correct-option {
                background: #dcfce7;
                border-color: #16a34a;
                box-shadow: 0 0 0 2px rgba(22, 163, 74, 0.2);
            }
            
            .tf-checkbox {
                width: 16px;
                height: 16px;
                border: 2px solid #6b7280;
                border-radius: 3px;
                background: white;
            }
            
            .tf-text {
                font-size: 10pt;
                font-weight: 600;
                color: #374151;
            }
            
            /* === Short Answer === */
            .short-answer {
                margin-top: 12px;
            }
            
            .answer-label {
                font-size: 10pt;
                font-weight: 600;
                color: #374151;
                margin-bottom: 8px;
            }
            
            .answer-lines {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            
            .answer-line {
                height: 25px;
                border-bottom: 2px dotted #9ca3af;
                padding: 4px 0;
                font-size: 10pt;
                color: #1f2937;
            }
            
            /* === Answer Sheet === */
            .page-break {
                page-break-before: always;
            }
            
            .answer-sheet {
                margin-top: 30px;
            }
            
            .answer-sheet-header {
                text-align: center;
                margin-bottom: 20px;
                padding: 15px;
                background: linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 100%);
                border: 2px solid #0284c7;
                border-radius: 12px;
            }
            
            .answer-sheet-header h2 {
                font-size: 18pt;
                color: #0c4a6e;
                margin-bottom: 8px;
            }
            
            .answer-sheet-header p {
                font-size: 11pt;
                color: #0369a1;
            }
            
            .answers-grid {
                display: grid;
                grid-template-columns: repeat(5, 1fr);
                gap: 8px;
                margin: 20px 0;
            }
            
            .answer-item {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                background: #f9fafb;
            }
            
            .answer-item.row-end {
                border-left: 4px solid #3b82f6;
            }
            
            .answer-number {
                font-weight: 700;
                color: #1e40af;
                font-size: 10pt;
            }
            
            .answer-value {
                font-weight: 600;
                color: #059669;
                font-size: 10pt;
            }
            
            /* === Footer === */
            .exam-footer {
                margin-top: 30px;
                border-top: 2px solid #e5e7eb;
                padding-top: 15px;
            }
            
            .signature-section {
                display: flex;
                justify-content: space-between;
                margin-bottom: 15px;
                gap: 20px;
            }
            
            .signature-box {
                flex: 1;
                text-align: center;
            }
            
            .signature-label {
                font-size: 9pt;
                color: #6b7280;
                margin-bottom: 8px;
                font-weight: 600;
            }
            
            .signature-line {
                height: 2px;
                border-bottom: 2px dotted #9ca3af;
                margin: 0 10px;
            }
            
            .footer-message {
                text-align: center;
                font-size: 12pt;
                color: #dc2626;
                font-weight: 700;
            }
            
            .no-questions {
                text-align: center;
                padding: 40px;
                color: #6b7280;
                font-style: italic;
            }
            
            /* === Responsive Adjustments === */
            @media print and (max-width: 600px) {
                .exam-info-grid {
                    grid-template-columns: 1fr 1fr;
                }
                
                .mcq-options {
                    grid-template-columns: 1fr;
                }
                
                .student-info-section {
                    flex-direction: column;
                }
                
                .signature-section {
                    flex-direction: column;
                    gap: 10px;
                }
                
                .answers-grid {
                    grid-template-columns: repeat(3, 1fr);
                }
            }
        </style>
    </head><body>${html}</body></html>`);
    w.document.close();
    w.focus();
    w.print();
}

        // ----- Participants Print ----- //
        function printParticipants(){
            const res = currentDetails;
            if(!res || !res.attempts) return;
            const rows = res.attempts.map((a,idx)=>{
                const name = (a.name || ((a.first_name && a.last_name) ? (a.first_name + ' ' + a.last_name) : (a.username || 'کاربر مهمان')));
                const submitted = toJalaliDateTime(a.submitted_at || '');
                return `<tr>
                    <td style="border:1px solid #000;padding:6px 8px;text-align:center">${idx+1}</td>
                    <td style="border:1px solid #000;padding:6px 8px">${escapeHtml(name)}</td>
                    <td style="border:1px solid #000;padding:6px 8px;text-align:center">${a.score ?? ''}</td>
                    <td style="border:1px solid #000;padding:6px 8px;text-align:center">${a.total_score ?? ''}</td>
                    <td style="border:1px solid #000;padding:6px 8px;text-align:center">${a.time_taken ?? ''}</td>
                    <td style="border:1px solid #000;padding:6px 8px;text-align:center">${escapeHtml(submitted)}</td>
                </tr>`;
            }).join('');

            const html = `
                <div style="text-align:center;margin-bottom:12px">
                    <div style="font-size:18pt;font-weight:800;margin-bottom:6px">لیست شرکت‌کنندگان</div>
                    <div style="font-size:11pt">آزمون: ${escapeHtml(currentDetails.quiz.title || '')}</div>
                </div>
                <table style="width:100%;border-collapse:collapse;font-size:11pt;direction:rtl;text-align:right">
                    <thead>
                        <tr>
                            <th style="border:1.5px solid #000;padding:6px 8px;text-align:center">#</th>
                            <th style="border:1.5px solid #000;padding:6px 8px">نام</th>
                            <th style="border:1.5px solid #000;padding:6px 8px;text-align:center">امتیاز</th>
                            <th style="border:1.5px solid #000;padding:6px 8px;text-align:center">کل</th>
                            <th style="border:1.5px solid #000;padding:6px 8px;text-align:center">زمان(دقیقه)</th>
                            <th style="border:1.5px solid #000;padding:6px 8px;text-align:center">تاریخ ارسال</th>
                        </tr>
                    </thead>
                    <tbody>${rows || '<tr><td colspan="6" style="text-align:center;border:1.5px solid #000;padding:12px">شرکت‌کننده‌ای ثبت نشده است.</td></tr>'}</tbody>
                </table>
            `;

            const w = window.open('', '_blank');
            w.document.write(`<html dir="rtl"><head><title>پرینت شرکت‌کنندگان</title>
                <meta charset="UTF-8">
                <style>
                    @page{ size: A4; margin: 12mm; }
                    body{font-family:'Tahoma', tahoma, sans-serif; font-size:11pt; color:#000; direction:rtl; text-align:right}
                    table{width:100%;border-collapse:collapse}
                    th{background:#f0f0f0}
                </style>
            </head><body>${html}</body></html>`);
            w.document.close();
            w.focus();
            w.print();
        }

        // ----- Edit Tab ----- //
        function loadQuestionsForEdit(){
            const res = currentDetails;
            const box = $('#questionsEditContainer');
            box.empty();
            if(!res || !res.questions || !res.questions.length){
                box.html('<div class="text-muted">سوالی برای ویرایش وجود ندارد.</div>');
                $('#questionPos').text('—');
                return;
            }
            let html = '';
            res.questions.forEach((q,i)=>{ html += generateQuestionEditHTML(q, i); });
            box.html(html);
            highlightQuestion(currentEditIndex || 0);
        }

        function generateQuestionEditHTML(q, idx){
            let qd = {}; try{ qd = q.question_data ? JSON.parse(q.question_data) : {}; }catch(e){}
            const points = parseInt(q.points || 1);
            let s = `<div class="question-edit-item border rounded-3 p-3 mb-2" data-index="${idx}" style="background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2) !important;">
                    <div class="d-flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
                        <strong>سوال ${idx+1}</strong>
                        <div class="btn-group btn-group-sm">
                            <button class="exam-btn exam-btn-soft btn-sm" onclick="moveQuestion(${idx}, -1)">▲</button>
                            <button class="exam-btn exam-btn-soft btn-sm" onclick="moveQuestion(${idx}, 1)">▼</button>
                            <button class="exam-btn exam-btn-danger btn-sm" onclick="deleteQuestion(${idx})">🗑 حذف</button>
                        </div>
                    </div>
                    <div class="mb-2"><textarea class="form-control" rows="2" data-field="text">${escapeHtml(q.question_text || '')}</textarea></div>
                    <div class="row g-2 mb-2">
                        <div class="col-auto">
                            <select class="form-select form-select-sm" data-field="type">
                                <option value="mcq" ${q.question_type==='mcq'?'selected':''}>چهارگزینه‌ای</option>
                                <option value="tf"  ${q.question_type==='tf'?'selected':''}>درست/غلط</option>
                                <option value="short" ${q.question_type==='short'?'selected':''}>تشریحی</option>
                            </select>
                        </div>
                        <div class="col-auto">
                            <input type="number" class="form-control form-control-sm" data-field="points" value="${points}" min="1">
                        </div>
                    </div>`;

            if (q.question_type === 'mcq'){
                const opts = Array.isArray(qd.options) ? qd.options : ['', '', '', ''];
                const ci = deriveCorrectIndex(qd);
                for (let k=0;k<4;k++){
                    const text = getOptionText(opts[k] ?? '');
                    s += `<div class="d-flex align-items-center gap-2 mb-1">
                            <input type="radio" name="mcq_${idx}" ${ci===k ? 'checked' : ''} onchange="setCorrect(${idx}, ${k})">
                            <input type="text" class="form-control form-control-sm" data-field="opt_${k}" value="${escapeHtml(text)}" placeholder="گزینه ${k+1}">
                        </div>`;
                }
            } else if (q.question_type === 'tf'){
                const ans = (qd.correct_answer===true || qd.correct_answer==='true');
                s += `<div class="d-flex align-items-center gap-3">
                        <label class="form-check"><input class="form-check-input" type="radio" name="tf_${idx}" ${ans?'checked':''} onchange="setTF(${idx}, true)"> درست</label>
                        <label class="form-check"><input class="form-check-input" type="radio" name="tf_${idx}" ${!ans?'checked':''} onchange="setTF(${idx}, false)"> غلط</label>
                    </div>`;
            } else {
                s += `<textarea class="form-control" rows="2" data-field="short_answer" placeholder="پاسخ تشریحی">${escapeHtml(qd.correct_answer || '')}</textarea>`;
            }

            s += `</div>`;
            return s;
        }

        function highlightQuestion(idx){
            const cards = document.querySelectorAll('.question-edit-item');
            if (!cards.length) { document.getElementById('questionPos').textContent = '—'; return; }
            currentEditIndex = Math.max(0, Math.min(idx, cards.length - 1));
            cards.forEach(c => c.classList.remove('active'));
            const el = cards[currentEditIndex];
            if (el) {
                el.classList.add('active');
                el.scrollIntoView({behavior:'smooth', block:'center'});
            }
            document.getElementById('questionPos').textContent = (currentEditIndex + 1) + ' / ' + cards.length;
        }

        function prevQuestion(){ highlightQuestion(currentEditIndex - 1); }
        function nextQuestion(){ highlightQuestion(currentEditIndex + 1); }

        function moveQuestion(idx, dir){
            const arr = currentDetails.questions;
            const j = idx + dir;
            if (j < 0 || j >= arr.length) return;
            const tmp = arr[idx]; arr[idx] = arr[j]; arr[j] = tmp;
            // reorder
            arr.forEach((q,i)=> q.question_order = i+1);
            loadQuestionsForEdit();
            highlightQuestion(j);
        }

        function deleteQuestion(idx){
            const arr = currentDetails.questions;
            arr.splice(idx,1);
            arr.forEach((q,i)=> q.question_order = i+1);
            loadQuestionsForEdit();
        }

       function setCorrect(idx, k){
            const q = currentDetails.questions[idx];
            let qd = {};
            try {
                qd = q.question_data ? JSON.parse(q.question_data) : {};
            } catch(e){
                qd = {};
            }
            qd.correct_answer = k;
            q.question_data = JSON.stringify(qd);
        }

        function setTF(idx, val){
            const q = currentDetails.questions[idx];
            let qd = {}; try{ qd = q.question_data ? JSON.parse(q.question_data) : {}; }catch(e){}
            qd.correct_answer = !!val;
            q.question_data = JSON.stringify(qd);
        }

       function collectQuestionsForSave() {
            const items = document.querySelectorAll('.question-edit-item');
            const out = [];
            items.forEach((el, i) => {
                const originalIndex = parseInt(el.getAttribute('data-index'));
                const originalQuestion = currentDetails.questions[originalIndex] || {};

                const type = el.querySelector('[data-field="type"]').value;
                const text = el.querySelector('[data-field="text"]').value.trim();
                const points = parseInt(el.querySelector('[data-field="points"]').value || '1');

                let question_data = {};

                if (type === 'mcq') {
                    const radios = el.querySelectorAll(`input[name="mcq_${originalIndex}"]`);
                    let correctIndex = -1;
                    for (let k = 0; k < radios.length; k++) {
                        if (radios[k].checked) {
                            correctIndex = k;
                            break;
                        }
                    }

                    const newOptionsArray = [];
                    for (let k = 0; k < 4; k++) {
                        const optionText = el.querySelector(`[data-field="opt_${k}"]`).value.trim();
                        if (optionText !== '') {
                             newOptionsArray.push({
                                text: optionText,
                                correct: (k === correctIndex)
                            });
                        }
                    }
                    question_data.options = newOptionsArray;

                } else if (type === 'tf') {
                    const isTrueChecked = el.querySelector(`input[name="tf_${originalIndex}"][onchange*="true"]`).checked;
                    question_data.correct_answer = isTrueChecked;

                } else { // short answer
                    question_data.correct_answer = el.querySelector('[data-field="short_answer"]').value.trim();
                }

                out.push({
                    id: originalQuestion.id || null,
                    question_text: text,
                    question_type: type,
                    question_data: question_data,
                    points: points,
                    question_order: i + 1
                });
            });
            return out;
        }

        function saveAllQuestions(){
            if (!currentQuizId) return;
            const questions = collectQuestionsForSave();
            $.ajax({
                url: '?action=save_questions',
                method: 'POST',
                dataType: 'json',
                data: { quiz_id: currentQuizId, payload: JSON.stringify({questions:questions}) },
                success: function(res){
                    if (res && res.ok) {
                        alert('سوالات ذخیره شد.');
                        refreshDetails(true);
                        DT.ajax.reload(null, false);
                    } else {
                        alert('ذخیره ناموفق: ' + (res && res.error ? res.error : ''));
                    }
                },
                error: function(xhr){ console.error('SAVE ERR:', xhr.responseText); alert('خطا در ذخیره سوالات'); }
            });
        }

        // Refresh details without duplicating modal/backdrop
        function refreshDetails(keepTab){
            $.getJSON('?action=details', {id: currentQuizId}, function(res){
                if (!res || !res.ok) return;
                currentDetails = res;
                let activeTab = keepTab ? document.querySelector('#detailsModal .nav-link.active')?.getAttribute('data-bs-target') : null;
                renderDetails(res);
                if (activeTab) {
                    document.querySelectorAll('#detailsModal .nav-link').forEach(btn=>{
                        if (btn.getAttribute('data-bs-target') === activeTab) new bootstrap.Tab(btn).show();
                    });
                }
            });
        }

        function deleteQuiz(id){
            if(!confirm('حذف این آزمون؟')) return;
            $.post('?action=delete', {id:id}, function(res){
                if(res && res.ok){ alert('آزمون حذف شد.'); DT.ajax.reload(); }
                else { alert('حذف ناموفق: ' + (res && res.error ? res.error : '')); }
            }, 'json').fail(function(xhr){
                console.error('DELETE RAW:', xhr.responseText);
                alert('حذف با خطا مواجه شد.');
            });
        }

        // Escape
        function escapeHtml(str){
            return (''+str).replace(/[&<>"']/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;' }[s]));
        }

        // Animation initialization
        document.addEventListener('DOMContentLoaded', function() {
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                setTimeout(() => {
                    el.style.opacity = '1';
                }, index * 100);
            });
        });

   function resetExamForUser(examId, studentId) {
    if (!confirm('آیا مطمئن هستید؟')) return;

    $.ajax({
        url: '/sections/exams/ajax/reset_exam_for_user.php',
        method: 'POST',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify({ exam_id: examId, student_id: studentId }),
        success: function(res) {
            if (res.success) {
                alert(res.message);
                viewDetails(examId);
            } else {
                alert('خطا: ' + res.message);
            }
        },
        error: function(xhr) {
            console.error(xhr.responseText);
            alert('خطا در ارتباط با سرور');
        }
    });
}
function resetAllParticipants() {
    // استفاده از currentQuizId که در حافظه JavaScript موجود است
    const examId = currentQuizId;
    
    console.log("Using exam ID:", examId);

    if (!examId || examId <= 0) {
        alert('شناسه آزمون معتبر نیست');
        return;
    }

    if (!confirm("آیا مطمئن هستید که می‌خواهید همه شرکت‌کنندگان دوباره بتوانند شرکت کنند؟")) {
        return;
    }

    fetch('/sections/exams/ajax/reset_exam_for_all.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exam_id: examId })
    })
    .then(res => {
        if (!res.ok) {
            throw new Error('خطا در پاسخ سرور');
        }
        return res.json();
    })
    .then(data => {
        alert(data.message);
        if (data.success) {
            // رفرش کردن جزئیات آزمون
            refreshDetails(true);
        }
    })
    .catch(err => {
        console.error(err);
        alert('خطا در ارتباط با سرور');
    });
}
    </script>

</body>
</html>
