<?php
/* =============================================================
 * File: root/sections/exams/api/quiz.php
 * توضیح: API JSON اصلاح شده با پشتیبانی کامل از ویرایش سوالات
 * اکشن‌ها: create_quiz, update_quiz, add_question, update_question, delete_question, publish
 * ============================================================= */

// خروجی JSON و غیرفعال کردن نویزها
while (ob_get_level() > 0) { ob_end_clean(); }
ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// اتصال مستقیم با کرنشنال شما
try {
    $dsn = 'mysql:host=localhost:3306;dbname=qwaepiuv_starmah_db;charset=utf8mb4';
    $pdo = new PDO($dsn, 'qwaepiuv_aminebr', 'Test12345!@#', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'DB_CONNECT', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); 
    exit;
}

function j($x, $code = 200){ 
    while (ob_get_level() > 0) { ob_end_clean(); } 
    http_response_code($code); 
    echo json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); 
    exit; 
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$ct = $_SERVER['CONTENT_TYPE'] ?? '';
$action = $_REQUEST['action'] ?? null;
$payload = [];

// Handle different input methods
if ($method === 'POST') {
    if (stripos($ct, 'application/json') !== false) {
        $payload = json_decode(file_get_contents('php://input'), true) ?: [];
    } else {
        // Handle FormData
        $payload = $_POST;
        // Also check for action in FormData
        if (!$action && isset($_POST['action'])) {
            $action = $_POST['action'];
        }
    }
} else {
    $payload = $_GET;
}

try {
    if (!$action) j(['ok' => false, 'error' => 'NO_ACTION'], 400);

    if ($action === 'create_quiz' || $action === 'update_quiz') {
        $isUpdate = ($action === 'update_quiz'); 
        $quiz_id = (int)($payload['quiz_id'] ?? 0);
        $title = trim($payload['title'] ?? ''); 
        $exam_date = $payload['exam_date'] ?? null; 
        $exam_time = $payload['exam_time'] ?? null; 
        $dur = (int)($payload['duration_minutes'] ?? 0);
        $visible = (int)!!($payload['is_visible'] ?? 1); 
        $shuffle = (int)!!($payload['shuffle_questions'] ?? 1); 
        $neg = (int)!!($payload['negative_marking'] ?? 0);
        
        $missing = []; 
        if ($title === '') $missing[] = 'title'; 
        if (!$exam_date) $missing[] = 'exam_date'; 
        if (!$exam_time) $missing[] = 'exam_time'; 
        if ($dur <= 0) $missing[] = 'duration_minutes'; 
        if ($isUpdate && !$quiz_id) $missing[] = 'quiz_id';
        
        if ($missing) j(['ok' => false, 'error' => 'VALIDATION', 'missing' => $missing, 'received' => $payload], 400);
        
        if ($isUpdate) { 
            $pdo->prepare("UPDATE quizzes SET title=?, exam_date=?, exam_time=?, duration_minutes=?, is_visible=?, shuffle_questions=?, negative_marking=? WHERE id=?")
                ->execute([$title, $exam_date, $exam_time, $dur, $visible, $shuffle, $neg, $quiz_id]); 
            j(['ok' => true, 'quiz_id' => $quiz_id]); 
        } else { 
            $pdo->prepare("INSERT INTO quizzes (title, exam_date, exam_time, duration_minutes, is_active, is_visible, shuffle_questions, negative_marking, questions_count, total_points) VALUES (?,?,?,?,0,?,?,?,0,0)")
                ->execute([$title, $exam_date, $exam_time, $dur, $visible, $shuffle, $neg]); 
            j(['ok' => true, 'quiz_id' => (int)$pdo->lastInsertId()]); 
        }
    }

    if ($action === 'add_question') {
        $quiz_id = (int)($payload['quiz_id'] ?? 0); 
        $text = trim($payload['question_text'] ?? ''); 
        $type = $payload['question_type'] ?? 'mcq'; 
        $pts = (int)($payload['points'] ?? 1); 
        $ord = (int)($payload['question_order'] ?? 1); 
        $act = (int)!!($payload['is_active'] ?? 1); 
        $data = $payload['question_data'] ?? null;
        
        if (!$quiz_id || $text === '') {
            j(['ok' => false, 'error' => 'VALIDATION', 'missing' => [!$quiz_id ? 'quiz_id' : null, $text === '' ? 'question_text' : null], 'received' => $payload], 400);
        }
        
        $json = $data ? json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        
        $pdo->beginTransaction();
        $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question_text, question_type, question_data, points, question_order, is_active) VALUES (?,?,?,?,?,?,?)")
            ->execute([$quiz_id, $text, $type, $json, $pts, $ord, $act]);
        $pdo->prepare("UPDATE quizzes SET questions_count=questions_count+1, total_points=COALESCE(total_points,0)+? WHERE id=?")
            ->execute([$pts, $quiz_id]);
        $qid = (int)$pdo->lastInsertId(); 
        $pdo->commit(); 
        j(['ok' => true, 'question_id' => $qid]);
    }

    if ($action === 'update_question') {
        // FIXED: Handle both 'id' and 'question_id' for backward compatibility
        $id = (int)($payload['id'] ?? $payload['question_id'] ?? 0); 
        $text = trim($payload['question_text'] ?? ''); 
        $type = $payload['question_type'] ?? 'mcq'; 
        $pts = (int)($payload['points'] ?? 1); 
        $ord = (int)($payload['question_order'] ?? 1); 
        $act = (int)!!($payload['is_active'] ?? 1); 
        $data = $payload['question_data'] ?? null;
        
        if (!$id || $text === '') {
            j(['ok' => false, 'error' => 'VALIDATION', 'missing' => [!$id ? 'id' : null, $text === '' ? 'question_text' : null], 'received' => $payload], 400);
        }
        
        $json = $data ? json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        
        // Check if question exists before updating
        $existing = $pdo->prepare("SELECT id FROM quiz_questions WHERE id=?");
        $existing->execute([$id]);
        if (!$existing->fetch()) {
            j(['ok' => false, 'error' => 'QUESTION_NOT_FOUND', 'id' => $id], 404);
        }
        
        $pdo->prepare("UPDATE quiz_questions SET question_text=?, question_type=?, question_data=?, points=?, question_order=?, is_active=? WHERE id=?")
            ->execute([$text, $type, $json, $pts, $ord, $act, $id]);
        j(['ok' => true, 'id' => $id]);
    }

    if ($action === 'delete_question') {
        $id = (int)($payload['id'] ?? 0); 
        $quiz_id = (int)($payload['quiz_id'] ?? 0); 
        $pts = (int)($payload['points'] ?? 0); 
        
        if (!$id || !$quiz_id) {
            j(['ok' => false, 'error' => 'VALIDATION', 'missing' => [!$id ? 'id' : null, !$quiz_id ? 'quiz_id' : null]], 400);
        }
        
        $pdo->beginTransaction();
        $deleted = $pdo->prepare("DELETE FROM quiz_questions WHERE id=?");
        $deleted->execute([$id]);
        
        if ($deleted->rowCount() > 0) {
            $pdo->prepare("UPDATE quizzes SET questions_count=GREATEST(questions_count-1,0), total_points=GREATEST(COALESCE(total_points,0)-?,0) WHERE id=?")
                ->execute([$pts, $quiz_id]);
        }
        
        $pdo->commit(); 
        j(['ok' => true, 'deleted' => $deleted->rowCount() > 0]);
    }

    if ($action === 'publish') {
        $id = (int)($payload['quiz_id'] ?? 0); 
        
        if (!$id) {
            j(['ok' => false, 'error' => 'VALIDATION', 'missing' => ['quiz_id']], 400);
        }
        
        // Check if quiz exists and has questions
        $quiz = $pdo->prepare("SELECT id, questions_count FROM quizzes WHERE id=?");
        $quiz->execute([$id]);
        $quizData = $quiz->fetch();
        
        if (!$quizData) {
            j(['ok' => false, 'error' => 'QUIZ_NOT_FOUND'], 404);
        }
        
        if ($quizData['questions_count'] < 1) {
            j(['ok' => false, 'error' => 'NO_QUESTIONS', 'message' => 'آزمون باید حداقل یک سوال داشته باشد'], 400);
        }
        
        $pdo->prepare("UPDATE quizzes SET is_active=1 WHERE id=?")
            ->execute([$id]); 
        j(['ok' => true, 'success' => true, 'message' => 'آزمون با موفقیت منتشر شد']);
    }

  if ($action === 'get_questions') {
    $quiz_id = (int)($payload['quiz_id'] ?? 0);
    if (!$quiz_id) j(['ok' => false, 'error' => 'NO_ID'], 400);
    $stmt = $pdo->prepare("SELECT id, question_text, question_type, question_data, points FROM quiz_questions WHERE quiz_id = ? AND is_active = 1 ORDER BY question_order");
    $stmt->execute([$quiz_id]);
    $questions = $stmt->fetchAll();
    foreach ($questions as &$q) {
        $q['question_data'] = json_decode($q['question_data'], true);
    }
    j(['ok' => true, 'questions' => $questions]);
}
  
    j(['ok' => false, 'error' => 'UNKNOWN_ACTION', 'action' => $action], 400);
    
} catch (PDOException $e) { 
    if ($pdo->inTransaction()) $pdo->rollBack(); 
    error_log('Quiz API PDO Error: ' . $e->getMessage());
    j(['ok' => false, 'error' => 'DB_ERROR', 'message' => $e->getMessage()], 500); 
} catch (Throwable $e) { 
    error_log('Quiz API General Error: ' . $e->getMessage());
    j(['ok' => false, 'error' => 'SERVER_ERROR', 'message' => $e->getMessage()], 500); 
}
?>