<?php
require_once __DIR__ . '/../../../config.php';
header('Content-Type: application/json; charset=utf-8');

$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$action = $_GET['action'] ?? '';

if($action == 'general'){
    $stmt = $pdo->query("SELECT q.title, AVG(a.score) as avg_score
                         FROM quizzes q
                         LEFT JOIN quiz_attempts a ON q.id = a.quiz_id
                         GROUP BY q.id");
    $labels = [];
    $data = [];
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $labels[] = $row['title'];
        $data[] = round($row['avg_score'],2);
    }
    echo json_encode(['labels'=>$labels,'data'=>$data]);
}
elseif($action == 'exams_list'){
    $stmt = $pdo->query("SELECT id, title FROM quizzes ORDER BY id DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
elseif($action == 'exam_report'){
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT answers FROM quiz_attempts WHERE quiz_id=?");
    $stmt->execute([$id]);
    $correct = 0; $wrong = 0;
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $answers = json_decode($row['answers'], true);
        foreach($answers as $ans){
            if($ans['is_correct']) $correct++;
            else $wrong++;
        }
    }
    echo json_encode(['correct'=>$correct,'wrong'=>$wrong]);
}
elseif($action == 'students_list'){
    $stmt = $pdo->query("SELECT id, first_name, last_name FROM users WHERE user_type='student'");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
elseif($action == 'student_report'){
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT q.title, a.score
                           FROM quiz_attempts a
                           JOIN quizzes q ON q.id=a.quiz_id
                           WHERE a.student_id=?
                           ORDER BY a.submitted_at");
    $stmt->execute([$id]);
    $labels = [];
    $data = [];
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $labels[] = $row['title'];
        $data[] = $row['score'];
    }
    echo json_encode(['labels'=>$labels,'data'=>$data]);
}
else{
    echo json_encode(['error'=>'Invalid action']);
}
