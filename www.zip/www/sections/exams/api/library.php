<?php
require_once __DIR__ . '/../../../config.php';

// ——— JSON-only hardening ———
while (ob_get_level() > 0) { ob_end_clean(); }
ini_set('display_errors', '0'); // برای جلوگیری از echo هشدارها
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function out($x, $code=200){
  while (ob_get_level() > 0) { ob_end_clean(); }
  http_response_code($code);
  echo json_encode($x, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}

try {
  $pdo = new PDO(
    'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
    DB_USER, DB_PASS,
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
  );
} catch(PDOException $e){
  out(['ok'=>false, 'error'=>'DB_CONNECT', 'message'=>$e->getMessage()], 500);
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'list') {
  $q = $pdo->query("
    SELECT q.id, q.title, q.exam_date, q.duration_minutes, q.questions_count,
           (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.quiz_id=q.id) AS participants_count,
           CASE 
             WHEN q.is_active=1 AND q.is_visible=1 THEN 'published'
             WHEN q.is_active=1 AND q.is_visible=0 THEN 'draft'
             ELSE 'disabled'
           END AS status,
           q.is_active, q.is_visible
    FROM quizzes q
    ORDER BY q.created_at DESC
  ");
  $rows = $q->fetchAll();
  out(['ok'=>true, 'data'=>$rows]); // DataTables منتظر فیلد data است
}

if ($action === 'details') {
  $id = (int)($_GET['id'] ?? 0);
  if ($id <= 0) out(['ok'=>false,'error'=>'NO_ID'], 400);

  $st = $pdo->prepare("SELECT * FROM quizzes WHERE id=?");
  $st->execute([$id]);
  $quiz = $st->fetch();
  if (!$quiz) out(['ok'=>false,'error'=>'NOT_FOUND'], 404);

  $qs = $pdo->prepare("SELECT id, question_text, question_type, points, question_order FROM quiz_questions WHERE quiz_id=? ORDER BY question_order ASC");
  $qs->execute([$id]);
  $questions = $qs->fetchAll();

  // join با جدول users برای نام دانش‌آموز
  $as = $pdo->prepare("
    SELECT qa.id, qa.student_id, qa.score, qa.total_score, qa.time_taken, qa.submitted_at,
           u.first_name, u.last_name, u.username
    FROM quiz_attempts qa
    LEFT JOIN users u ON u.id = qa.student_id
    WHERE qa.quiz_id=?
    ORDER BY qa.score DESC, qa.submitted_at DESC
  ");
  $as->execute([$id]);
  $attempts = $as->fetchAll();
  foreach ($attempts as &$a) {
    $full = trim(($a['first_name'] ?? '').' '.($a['last_name'] ?? ''));
    $a['name'] = $full !== '' ? $full : ($a['username'] ?? '—');
  }
  unset($a);

  out([
    'ok'=>true,
    'quiz'=>[
      'id'=>(int)$quiz['id'],
      'title'=>$quiz['title'],
      'exam_date'=>$quiz['exam_date'],
      'duration_minutes'=>(int)$quiz['duration_minutes'],
      'is_active'=>(int)$quiz['is_active'],
      'is_visible'=>(int)$quiz['is_visible'],
      'shuffle_questions'=>(int)$quiz['shuffle_questions'],
      'negative_marking'=>(int)$quiz['negative_marking'],
      'questions_count'=>(int)$quiz['questions_count'],
      'total_points'=>(int)$quiz['total_points'],
    ],
    'questions'=>$questions,
    'attempts'=>$attempts
  ]);
}

if ($action === 'delete') {
  $data = json_decode(file_get_contents('php://input'), true);
  if (!is_array($data)) $data = $_POST;
  $id = (int)($data['id'] ?? ($_GET['id'] ?? 0));
  if ($id <= 0) out(['ok'=>false,'error'=>'NO_ID'], 400);

  $pdo->beginTransaction();
  $pdo->prepare("DELETE FROM quiz_attempts WHERE quiz_id=?")->execute([$id]);
  $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id=?")->execute([$id]);
  $pdo->prepare("DELETE FROM quizzes WHERE id=?")->execute([$id]);
  $pdo->commit();

  out(['ok'=>true,'message'=>'آزمون حذف شد.']);
}

if ($action === 'delete_bulk') {
  $data = json_decode(file_get_contents('php://input'), true);
  if (!is_array($data)) $data = $_POST;
  $ids = $data['ids'] ?? [];
  if (!is_array($ids) || !count($ids)) out(['ok'=>false,'error'=>'NO_IDS'], 400);
  $ids = array_values(array_map('intval', $ids));
  $in = implode(',', array_fill(0, count($ids), '?'));

  $pdo->beginTransaction();
  $pdo->prepare("DELETE FROM quiz_attempts WHERE quiz_id IN ($in)")->execute($ids);
  $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id IN ($in)")->execute($ids);
  $pdo->prepare("DELETE FROM quizzes WHERE id IN ($in)")->execute($ids);
  $pdo->commit();

  out(['ok'=>true,'message'=>'آزمون‌های انتخابی حذف شدند.']);
}

out(['ok'=>false,'error'=>'INVALID_ACTION'], 400);
