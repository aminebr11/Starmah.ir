<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جهان امتیازات: چطور قهرمان بشی؟</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #6C63FF;
            --secondary-color: #FF6B6B;
            --accent-color: #4ECDC4;
            --sunshine-yellow: #FFD93D;
            --forest-green: #6BCF7F;
            --light-bg: #F7F9FC;
            --card-bg: #FFFFFF;
            --text-color: #333;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            color: var(--text-color);
            line-height: 1.8;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* Animated Background Elements */
        .bg-animation {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
            overflow: hidden;
        }

        .star {
            position: absolute;
            background-color: #fff;
            clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
            animation: float-up 15s infinite linear;
            opacity: 0.3;
        }

        @keyframes float-up {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 0.3; }
            90% { opacity: 0.3; }
            100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            background: var(--card-bg);
            border-radius: 30px;
            box-shadow: var(--shadow);
            overflow: hidden;
            animation: bounce-in 1s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        @keyframes bounce-in {
            0% { opacity: 0; transform: scale(0.3); }
            50% { opacity: 1; transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); }
        }

        header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 50px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 20px 20px;
            animation: move-grid 20s linear infinite;
        }

        @keyframes move-grid {
            0% { transform: translate(0, 0); }
            100% { transform: translate(20px, 20px); }
        }

        header h1 {
            font-size: 2.8rem;
            font-weight: 900;
            margin: 0;
            text-shadow: 3px 3px 6px rgba(0,0,0,0.3);
            position: relative;
            z-index: 1;
        }

        header p {
            font-size: 1.2rem;
            margin-top: 15px;
            opacity: 0.95;
            position: relative;
            z-index: 1;
        }

        main {
            padding: 40px;
        }

        .intro {
            background: linear-gradient(135deg, var(--sunshine-yellow), #ffed4e);
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 40px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(255, 217, 61, 0.4);
            animation: slide-in-bottom 0.8s ease-out 0.2s both;
        }

        .intro h2 {
            color: var(--primary-color);
            margin-top: 0;
            font-size: 1.8rem;
        }

        .section {
            margin-bottom: 50px;
            animation: slide-in-left 0.8s ease-out 0.4s both;
        }

        .section h2 {
            font-size: 2rem;
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 15px;
        }

        .section h2::after {
            content: '✨';
            position: absolute;
            left: 50%;
            bottom: -10px;
            transform: translateX(-50%);
            font-size: 1.5rem;
        }

        .quest-card {
            background-color: var(--card-bg);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 25px;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            align-items: center;
            gap: 20px;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .quest-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: left 0.5s;
        }

        .quest-card:hover::before {
            left: 100%;
        }

        .quest-card:hover {
            transform: translateY(-8px) rotate(-1deg);
            box-shadow: var(--shadow);
            border-color: var(--accent-color);
        }

        .quest-icon {
            font-size: 3rem;
            flex-shrink: 0;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .quest-content h3 {
            margin-top: 0;
            color: var(--secondary-color);
            font-size: 1.5rem;
        }

        .levels-path {
            display: flex;
            justify-content: space-around;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 30px;
        }

        /* ===== شروع بخش استایل تغییر کرده: متن کوچکتر در ستاره های بزرگ ===== */
        .level {
            width: 180px;
            height: 180px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
            color: black;
            padding: 25px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            transition: all 0.3s ease, box-shadow 0.3s ease;
            animation: wiggle 4s ease-in-out infinite;
        }

        .level:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 12px 30px rgba(0,0,0,0.3);
            animation-play-state: paused;
        }

        @keyframes wiggle {
            0%, 100% { transform: rotate(-3deg); }
            50% { transform: rotate(3deg); }
        }

        .level h4 {
            margin: 0;
            font-size: 1.1rem; /* از 1.4 به 1.1 کاهش یافت */
            font-weight: 800;
        }

        .level p {
            margin: 5px 0 0 0;
            font-size: 0.85rem; /* از 1 به 0.85 کاهش یافت */
            font-weight: 600;
        }
        
        .level .xp-range {
            font-size: 0.7rem; /* از 0.85 به 0.7 کاهش یافت */
            font-weight: 700;
            opacity: 0.9;
            margin-top: 4px;
        }
        /* ===== پایان بخش استایل تغییر کرده ===== */

        .weekly-competition-section {
            background: linear-gradient(135deg, #FFD93D, #fcf4a3);
            border-radius: 25px;
            padding: 30px;
            margin-top: 40px;
            animation: slide-in-right 0.8s ease-out 0.6s both;
        }

        .weekly-competition-section h2 {
            color: var(--primary-color);
            border: none;
            text-align: center;
        }

        .weekly-competition-section h2::after {
            content: '🏆';
        }

        .special-powers-section {
            background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
            border-radius: 25px;
            padding: 30px;
            margin-top: 40px;
            animation: slide-in-right 0.8s ease-out 0.6s both;
        }

        .special-powers-section h2 {
            color: var(--primary-color);
            border: none;
            text-align: center;
        }

        .special-powers-section h2::after {
            content: '🔮';
        }

        .power-card {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: transform 0.3s ease;
        }

        .power-card:hover {
            transform: scale(1.03);
        }

        .power-card.positive { border-left: 5px solid var(--forest-green); }
        .power-card.negative { border-left: 5px solid var(--secondary-color); }

        footer {
            text-align: center;
            padding: 40px;
            background: linear-gradient(135deg, var(--forest-green), var(--accent-color));
            font-size: 1.2rem;
            font-weight: 700;
            color: white;
            animation: slide-in-bottom 0.8s ease-out 0.8s both;
        }

        .back-button-container {
            margin-top: 30px;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #45B7D1, #2196F3);
            color: white;
            padding: 12px 30px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            box-shadow: 0 8px 20px rgba(33, 150, 243, 0.4);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .back-button:hover {
            transform: translateY(-4px) scale(1.05);
            box-shadow: 0 12px 30px rgba(33, 150, 243, 0.5);
            color: #f0f0f0;
        }

        @keyframes slide-in-left { from { opacity: 0; transform: translateX(-50px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes slide-in-right { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes slide-in-bottom { from { opacity: 0; transform: translateY(50px); } to { opacity: 1; transform: translateY(0); } }

        @media (max-width: 768px) {
            header h1 { font-size: 2.2rem; }
            .quest-card { flex-direction: column; text-align: center; }
            .levels-path { flex-direction: column; align-items: center; }
            .level { 
                margin-bottom: 20px;
                width: 160px;
                height: 160px;
            }
        }
    </style>
</head>
<body>

    <!-- Animated Background -->
    <div class="bg-animation">
        <!-- Stars will be added by JS -->
    </div>

    <div class="container">
        <header>
            <h1>🌟 جهان امتیازات: ماجراجویی قهرمانان! 🌟</h1>
            <p>سلام قهرمان کوچولو! به دنیای شگفت‌انگیز یادگیری خوش اومدی. اینجا هر تلاش تو، یک ستاره‌ی درخشان می‌شه!</p>
        </header>

        <main>
            <section class="intro">
                <h2>ستاره‌های انرژی (XP) چیا هستن؟</h2>
                <p>فکر کن هر امتیازی که می‌گیری، یک <strong>ستاره‌ی جادویی</strong>ه که تو آسمون یادگیری تو می‌درخشه. این ستاره‌ها به ما میگن چقدر باهوش، خلاق و باانگیزه هستی. بیا با هم ببینیم چطور می‌تونی ستاره‌های بیشتری جمع کنی!</p>
            </section>

            <section class="section">
                <h2>مسیر قهرمانی: سطوح تو</h2>
                <div class="levels-path">
                    <div class="level">
                        <h4>مبتدی</h4>
                        <p>شروع ماجراجویی</p>
                        <span class="xp-range">(۰ تا ۹۹ ستاره)</span>
                    </div>
                    <div class="level">
                        <h4>متوسط</h4>
                        <p>در حال یادگیری</p>
                        <span class="xp-range">(۱۰۰ تا ۴۹۹ ستاره)</span>
                    </div>
                    <div class="level">
                        <h4>پیشرفته</h4>
                        <p>دارای مهارت</p>
                        <span class="xp-range">(۵۰۰ تا ۱,۴۹۹ ستاره)</span>
                    </div>
                    <div class="level">
                        <h4>حرفه‌ای</h4>
                        <p>یک قهرمان واقعی</p>
                        <span class="xp-range">(۱,۵۰۰ تا ۲,۹۹۹ ستاره)</span>
                    </div>
                    <div class="level">
                        <h4>استاد</h4>
                        <p>افسانه‌ی سایت!</p>
                        <span class="xp-range">(۳,۰۰۰ ستاره به بالا)</span>
                    </div>
                </div>
            </section>

            <section class="section">
                <h2>مأموریت‌های تو برای جمع کردن ستاره</h2>
                
                <div class="quest-card">
                    <div class="quest-icon">🎧</div>
                    <div class="quest-content">
                        <h3>سفر به دنیای صداها (پادکست)</h3>
                        <p>وقتی یک دفترچه‌ی صوتی رو کامل و تا آخر گوش میدی، <strong>۵۰ ستاره</strong> جایزه می‌گیری! این جایزه فقط برای بار اول هست، پس با دقت گوش کن تا همه‌چیز رو یاد بگیری.</p>
                    </div>
                </div>

                <div class="quest-card">
                    <div class="quest-icon">🎮</div>
                    <div class="quest-content">
                        <h3>بازی‌های هوش و مهارت</h3>
                        <p>برای هر بازی که برای اولین بار تمومش می‌کنی، ستاره می‌گیری. امتیازت به این بستگی داره که چقدر سریع و دقیق بازی می‌کنی. هرچی بهتر بازی کنی، ستاره‌های بیشتری می‌بری!</p>
                    </div>
                </div>

                <div class="quest-card">
                    <div class="quest-icon">🏆</div>
                    <div class="quest-content">
                        <h3>مسابقات بزرگ (آزمون‌ها)</h3>
                        <p>آزمون‌ها بزرگترین جایزه‌ها رو دارن! نمره‌ی بهتر و سرعت بالاتر بهت ستاره‌های بیشتری می‌ده. حتی برای سرعتت هم جایزه داریم! اما اگه آزمون رو نصفه رها کنی یا نمره‌ات صفر باشه، متاسفانه ستاره‌ای نمی‌گیری.</p>
                    </div>
                </div>

                <div class="quest-card">
                    <div class="quest-icon">✍️</div>
                    <div class="quest-content">
                        <h3>فعالیت‌های کلاسی و تکالیف</h3>
                        <p>معلم عزیزت هر روز تلاش تو رو می‌بینه و بهت ستاره می‌ده:</p>
                        <ul>
                            <li><strong>نمره عددی:</strong> هرچی نمره‌ات به ۲۰ نزدیک‌تر باشه، ستاره‌های بیشتری می‌گیری.</li>
                            <li><strong>ارزیابی کیفی:</strong> "خیلی خوب" یعنی ۱۰۰ ستاره! "خوب" هم ۷۵ ستاره جایزه داره.</li>
                            <li><strong>تکلیف:</strong> انجام کامل تکلیف ۵۰ ستاره داره. اما اگه تکلیف رو نکنی یا غایب باشی، ممکنه چند تا ستاره ازت کم بشه. پس سعی کن همیشه تکالیفت رو انجام بدی!</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section class="weekly-competition-section">
                <h2>رقابت هفتگی: قهرمانان این هفته کیستن؟</h2>
                <p>هر هفته یک ماجراجویی جدید شروع می‌شه! ما تمام ستاره‌هایی که تو طول یک هفته (از شنبه تا جمعه) جمع کردی رو می‌شماریم.</p>
                <div class="quest-card">
                    <div class="quest-icon">👑</div>
                    <div class="quest-content">
                        <h3>ستاره‌ی هفته</h3>
                        <p>در صفحه اصلی سایت، لیست <strong>۵ دانش‌آموز برتر هفته</strong> نمایش داده می‌شه. دانش‌آموزی که بیشترین تعداد ستاره رو در اون هفته جمع کرده، به عنوان <strong>"ستاره‌ی هفته"</strong> انتخاب می‌شه و افتخارش برای همیشه تو سایت ثبت می‌شه! پس با تلاش خودت رو به بالای لیست برسون!</p>
                    </div>
                </div>
            </section>

            <section class="special-powers-section">
                <h2>قوانین و قدرت‌های ویژه</h2>
                <p>گاهی وقتا مدیران و معلم‌ها از قدرت‌های ویژه‌ای استفاده می‌کنن تا بازی برای همه عادلانه و سرگرم‌کننده باشه.</p>
                
                <div class="power-card positive">
                    <div class="quest-icon">🎁</div>
                    <div class="quest-content">
                        <h3>هدیه‌ی ویژه (افزودن دستی)</h3>
                        <p>گاهی اوقات، به خاطر یک کمک بزرگ، یک خلاقیت عالی یا یک مناسبت خاص، معلم یا مدیر سایت ممکنه بهت یک <strong>هدیه‌ی ویزه</strong> و چند تا ستاره‌ی اضافی بده. این یک غافلگیری شیرینه برای قدردانی از تلاشت!</p>
                    </div>
                </div>

                <div class="power-card negative">
                    <div class="quest-icon">⚖️</div>
                    <div class="quest-content">
                        <h3>تنظیم مجدد ستاره‌ها (کسر دستی و انضباطی)</h3>
                        <p>قهرمان‌ها همیشه قوانین رو رعایت می‌کنن. اگه کاری کنی که طبق قوانین درست نباشه، یا اگه در تکالیف و فعالیت‌های کلاسی غایب باشی، ممکنه چند تا ستاره ازت کم بشه. این کار کمک می‌کنه که همه با هم محیط بهتر و عادلانه‌تری داشته باشیم.</p>
                    </div>
                </div>
            </section>
        </main>

        <footer>
            <p>🚀 حالا شما آماده‌اید! با تلاش و فعالیت، ستاره‌هایتان را جمع کنید و به بالاترین سطح قهرمانی برسید! 🚀</p>
            
            <div class="back-button-container">
                <a href="../index.php" class="back-button">
                    <span>⬅️</span>
                    <span>بازگشت به صفحه اصلی</span>
                </a>
            </div>
        </footer>
    </div>

    <script>
        // Create floating stars in the background
        const bgAnimation = document.querySelector('.bg-animation');
        for (let i = 0; i < 15; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            star.style.width = Math.random() * 15 + 5 + 'px';
            star.style.height = star.style.width;
            star.style.left = Math.random() * 100 + '%';
            star.style.animationDelay = Math.random() * 15 + 's';
            star.style.animationDuration = (Math.random() * 10 + 15) + 's';
            bgAnimation.appendChild(star);
        }
    </script>
</body>
</html>