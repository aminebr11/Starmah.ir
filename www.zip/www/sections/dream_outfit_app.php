<?php
// ----------------------------------------------------------------
// dream_outfit_app.php - Full version (OpenAI gpt-image-1) - no { } after case
// ----------------------------------------------------------------
declare(strict_types=1);
session_start();
mb_internal_encoding('UTF-8');

ini_set('log_errors', '1');
@mkdir(__DIR__ . '/../logs', 0777, true);
ini_set('error_log', __DIR__ . '/../logs/php-error.log');

require_once '../config.php';

// -------------------- Helpers: throwable logger ------------------
function log_throwable(Throwable $e, string $prefix = ''): void {
    $msg = ($prefix !== '' ? $prefix . ': ' : '') . $e->getMessage() . "\n" . $e->getTraceAsString();
    error_log($msg);
}

// -------------------- DB connection detection -------------------
$db_connection = null;
if (isset($pdo)) {
    $db_connection = $pdo;
} elseif (isset($conn)) {
    $db_connection = $conn;
} elseif (isset($db)) {
    $db_connection = $db;
}
if (!$db_connection) {
    die("خطا: متغیر اتصال به پایگاه داده در config.php پیدا نشد. لطفاً نام متغیر را بررسی کنید (مثلاً \$pdo).");
}

// -------------------- Auth check --------------------------------
if (!isset($_SESSION['user_id'])) {
    die('لطفاً برای دسترسی به این صفحه وارد شوید.');
}

// -------------------- DB helpers --------------------------------
function get_user_info_by_id(int $userId) {
    global $db_connection;
    try {
        $stmt = $db_connection->prepare("SELECT * FROM users WHERE id = :user_id");
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch() ?: false;
    } catch (PDOException $e) {
        log_throwable($e, 'DB get_user_info_by_id');
        return false;
    }
}

function get_user_dream_outfit(int $userId) {
    global $db_connection;
    try {
        $stmt = $db_connection->prepare("SELECT * FROM dream_outfits WHERE user_id = :user_id");
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch() ?: false;
    } catch (PDOException $e) {
        log_throwable($e, 'DB get_user_dream_outfit');
        return false;
    }
}

function clean_input(string $data): string {
    return htmlspecialchars(trim($data), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$userInfo = get_user_info_by_id((int)$_SESSION['user_id']);
if (!$userInfo) {
    die('خطا: اطلاعات کاربر یافت نشد.');
}
$currentUser = [
    'id'      => (int)$userInfo['id'],
    'name'    => trim(($userInfo['first_name'] ?? '') . ' ' . ($userInfo['last_name'] ?? '')),
    'isAdmin' => (($userInfo['user_type'] ?? '') === 'admin'),
];

// -------------------- OpenAI helpers -----------------------------
function get_openai_api_key(): string {
    if (defined('OPENAI_API_KEY') && OPENAI_API_KEY) return OPENAI_API_KEY;
    $env = getenv('OPENAI_API_KEY');
    if ($env) return $env;

    http_response_code(500);
    die("کلید OpenAI تنظیم نشده است. لطفاً OPENAI_API_KEY را در config.php یا متغیر محیطی قرار دهید.");
}

function build_prompt(?string $dreamText, ?string $customPrompt): string {
    $dreamText    = trim((string)$dreamText);
    $customPrompt = trim((string)$customPrompt);

    $base = "یک لباس بسیار زیبا و شیک برای کودکی که در آینده می‌خواهد «{$dreamText}» شود؛ سبک کارتونی، شاد و پرجزئیات؛ پس‌زمینه فانتزی مرتبط با شغل؛ کیفیت بالا؛ نورپردازی نرم؛ بدون متن/لوگو روی تصویر؛ نسبت مربعی.";
    if ($customPrompt !== '') {
        $base .= " اصلاحات کاربر: {$customPrompt}";
    }
    return $base;
}

/**
 * Generate image via OpenAI gpt-image-1 and save as PNG
 * Returns relative path like 'uploads/xxx.png' or false
 */
function openai_generate_image(string $prompt, string $size = '1024x1024') {
    $apiKey = get_openai_api_key();
    $apiUrl = 'https://api.openai.com/v1/images/generations';

    $payload = [
        'model'           => 'gpt-image-1',
        'prompt'          => $prompt,
        'n'               => 1,
        'size'            => $size,
        'response_format' => 'b64_json',
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT        => 120,
    ]);
    $response = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        error_log("cURL Error (OpenAI): $curlErr");
        return false;
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        error_log("OpenAI API HTTP $httpCode: $response");
        return false;
    }

    $data = json_decode($response, true);
    if (!isset($data['data'][0]['b64_json'])) {
        error_log("OpenAI response missing b64_json");
        return false;
    }

    $bytes = base64_decode($data['data'][0]['b64_json'], true);
    if ($bytes === false) {
        error_log("Base64 decode failed");
        return false;
    }

    $uploadRoot = __DIR__ . '/../uploads';
    if (!is_dir($uploadRoot)) @mkdir($uploadRoot, 0777, true);

    $name = 'generated_' . time() . '_' . bin2hex(random_bytes(4)) . '.png';
    $full = $uploadRoot . '/' . $name;

    if (file_put_contents($full, $bytes) === false) {
        error_log("Cannot write image: $full");
        return false;
    }
    return 'uploads/' . $name;
}

// -------------------- AJAX API ----------------------------------
$action = $_GET['action'] ?? '';

if ($action) {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
    }
    $response = ['ok' => false, 'msg' => 'عملیات ناموفق'];

    try {
        switch ($action) {

            case 'upload_and_generate':
                $dreamText = clean_input($_POST['dreamText'] ?? '');
                $category  = clean_input($_POST['category']  ?? '');
                if ($dreamText === '' || $category === '') {
                    http_response_code(400);
                    $response['msg'] = 'لطفاً آرزو و دسته را کامل وارد کنید.';
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    exit;
                }

                // آپلود تصویر کاربر (اختیاری) — سازگار با نبودن افزونهٔ fileinfo
                if (!empty($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                    $tmp = $_FILES['photo']['tmp_name'];
                    $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
                    $mime = null;

                    if (function_exists('finfo_open')) {
                        $fi = finfo_open(FILEINFO_MIME_TYPE);
                        if ($fi) {
                            $mime = @finfo_file($fi, $tmp);
                            finfo_close($fi);
                        }
                    }
                    if (!$mime && function_exists('mime_content_type')) {
                        $mime = @mime_content_type($tmp);
                    }
                    if (!$mime && function_exists('exif_imagetype')) {
                        $type = @exif_imagetype($tmp);
                        if ($type) {
                            if ($type === IMAGETYPE_JPEG) $mime = 'image/jpeg';
                            elseif ($type === IMAGETYPE_PNG) $mime = 'image/png';
                            elseif ($type === IMAGETYPE_WEBP) $mime = 'image/webp';
                            elseif ($type === IMAGETYPE_GIF)  $mime = 'image/gif';
                        }
                    }

                    if ($mime && !in_array($mime, $allowed, true)) {
                        http_response_code(400);
                        $response['msg'] = 'نوع فایل تصویر معتبر نیست.';
                        echo json_encode($response, JSON_UNESCAPED_UNICODE);
                        exit;
                    }

                    $uploadDir = __DIR__ . '/../uploads';
                    if (!is_dir($uploadDir)) @mkdir($uploadDir, 0777, true);

                    // جایگزین match برای سازگاری
                    $ext = 'jpg';
                    if ($mime === 'image/png')  $ext = 'png';
                    elseif ($mime === 'image/webp') $ext = 'webp';
                    elseif ($mime === 'image/gif')  $ext = 'gif';

                    $userPhotoName = 'user_' . $currentUser['id'] . '_' . time() . '.' . $ext;
                    @move_uploaded_file($tmp, $uploadDir . '/' . $userPhotoName);
                }

                $prompt = build_prompt($dreamText, '');
                $rel    = openai_generate_image($prompt, '1024x1024');

                if ($rel !== false) {
                    $response['ok']         = true;
                    $response['previewUrl'] = $rel;
                    $response['msg']        = 'عکس با موفقیت ساخته شد!';
                } else {
                    http_response_code(502);
                    $response['msg'] = 'خطا در ساخت تصویر با OpenAI. لطفاً لاگ را بررسی کنید.';
                }
                break;

            case 'publish':
                $dreamText = clean_input($_POST['dreamText'] ?? '');
                $category  = clean_input($_POST['category']  ?? '');
                $previewUrl= clean_input($_POST['previewUrl'] ?? '');

                if ($dreamText === '' || $previewUrl === '') {
                    http_response_code(400);
                    $response['msg'] = 'تمام فیلدها الزامی هستند.';
                    break;
                }
                if (get_user_dream_outfit($currentUser['id'])) {
                    http_response_code(409);
                    $response['msg'] = 'تو قبلاً یک لباس آرزو ساختی!';
                    break;
                }

                $stmt = $db_connection->prepare("
                    INSERT INTO dream_outfits (user_id, dream_text, image_path, category)
                    VALUES (:user_id, :dream_text, :image_path, :category)
                ");
                $stmt->bindValue(':user_id',    $currentUser['id'], PDO::PARAM_INT);
                $stmt->bindValue(':dream_text', $dreamText);
                $stmt->bindValue(':image_path', $previewUrl);
                $stmt->bindValue(':category',   $category);

                if ($stmt->execute()) {
                    $response['ok']  = true;
                    $response['msg'] = 'آفرین! لباس آرزوی تو روی دیوار نصب شد! 🌟';
                } else {
                    http_response_code(500);
                    $response['msg'] = 'خطا در ذخیره در دیتابیس.';
                }
                break;

            case 'list':
                $category = clean_input($_GET['category'] ?? 'all');
                $sql = "SELECT dream_outfits.*, users.first_name, users.last_name 
                        FROM dream_outfits 
                        JOIN users ON dream_outfits.user_id = users.id";
                if ($category !== 'all') {
                    $sql .= " WHERE dream_outfits.category = :category";
                }
                $sql .= " ORDER BY dream_outfits.created_at DESC";

                $stmt = $db_connection->prepare($sql);
                if ($category !== 'all') {
                    $stmt->bindValue(':category', $category);
                }
                $stmt->execute();
                $items = $stmt->fetchAll();

                foreach ($items as &$o) {
                    $o['student_name'] = trim(($o['first_name'] ?? '') . ' ' . ($o['last_name'] ?? ''));
                }
                unset($o);

                $response['ok']    = true;
                $response['items'] = $items;
                break;

            case 'delete':
                if (!$currentUser['isAdmin']) {
                    http_response_code(403);
                    $response['msg'] = 'دسترسی نداری!';
                    break;
                }
                $id = (int)($_POST['id'] ?? 0);
                if ($id <= 0) {
                    http_response_code(400);
                    $response['msg'] = 'شناسه نامعتبر.';
                    break;
                }

                $stmt = $db_connection->prepare("SELECT image_path FROM dream_outfits WHERE id = :id");
                $stmt->bindValue(':id', $id, PDO::PARAM_INT);
                $stmt->execute();
                $row = $stmt->fetch();

                if ($row && !empty($row['image_path'])) {
                    $full = realpath(__DIR__ . '/../' . $row['image_path']);
                    if ($full && file_exists($full)) @unlink($full);
                }

                $stmt = $db_connection->prepare("DELETE FROM dream_outfits WHERE id = :id");
                $stmt->bindValue(':id', $id, PDO::PARAM_INT);
                if ($stmt->execute()) {
                    $response['ok']  = true;
                    $response['msg'] = 'با موفقیت حذف شد!';
                } else {
                    http_response_code(500);
                    $response['msg'] = 'حذف با خطا مواجه شد.';
                }
                break;

            case 'regenerate':
                $imagePath = clean_input($_POST['image_path'] ?? '');
                $newPrompt = clean_input($_POST['new_prompt'] ?? '');

                if ($imagePath === '' || $newPrompt === '') {
                    http_response_code(400);
                    $response['msg'] = 'پرامپت جدید الزامی است.';
                    break;
                }

                $fullPath = realpath(__DIR__ . '/../' . $imagePath);
                if (!$fullPath || !file_exists($fullPath)) {
                    http_response_code(404);
                    $response['msg'] = 'عکس اصلی یافت نشد.';
                    break;
                }

                $prompt    = build_prompt('', $newPrompt);
                $newRel    = openai_generate_image($prompt, '1024x1024');

                if ($newRel !== false) {
                    $newFull = realpath(__DIR__ . '/../' . $newRel);
                    if (!$newFull || !file_exists($newFull)) {
                        http_response_code(500);
                        $response['msg'] = 'ذخیره‌سازی تصویر جدید ناموفق بود.';
                        break;
                    }
                    @unlink($fullPath); // حذف قدیمی
                    $oldDir = dirname($fullPath);
                    $target = $oldDir . '/' . basename($imagePath);
                    if (@rename($newFull, $target)) {
                        $response['ok']          = true;
                        $response['newImageUrl'] = $imagePath . '?t=' . time();
                        $response['msg']         = 'عکس با موفقیت اصلاح شد! ✨';
                    } else {
                        $response['ok']          = true;
                        $response['newImageUrl'] = $newRel . '?t=' . time();
                        $response['msg']         = 'عکس جدید ساخته شد، اما جایگزینی فایل ناموفق بود.';
                    }
                } else {
                    http_response_code(502);
                    $response['msg'] = 'متاسفانه نتونستیم عکس رو اصلاح کنیم. دوباره امتحان کن.';
                }
                break;

            default:
                http_response_code(400);
                $response['msg'] = 'action نامعتبر است.';
                break;
        }
    } catch (Throwable $e) {
        log_throwable($e, 'UNHANDLED');
        http_response_code(500);
        $response['ok'] = false;
        $response['msg'] = 'خطای غیرمنتظره: ' . $e->getMessage();
    }

    if (ob_get_level()) { @ob_end_clean(); }
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    flush();
    exit;
}

// -------------------- Page data (view) ---------------------------
$userOutfit = get_user_dream_outfit($currentUser['id']);
$categories = [
   'science'   => ['icon' => '🔬', 'title' => 'علم و فناوری', 'color' => '#4facfe'],
   'sports'    => ['icon' => '⚽', 'title' => 'ورزش',        'color' => '#43e97b'],
   'arts'      => ['icon' => '🎨', 'title' => 'هنر',         'color' => '#f093fb'],
   'medical'   => ['icon' => '⚕️', 'title' => 'پزشکی',       'color' => '#ff6348'],
   'education' => ['icon' => '📚', 'title' => 'آموزش',       'color' => '#feca57'],
   'other'     => ['icon' => '⭐', 'title' => 'سایر',         'color' => '#95afc0']
];
$jobButtons = [
   ['title' => 'پزشک', 'icon' => '👨‍⚕️', 'color' => '#ff6b6b'],
   ['title' => 'مهندس', 'icon' => '👷', 'color' => '#4ecdc4'],
   ['title' => 'معلم', 'icon' => '👩‍🏫', 'color' => '#45b7d1'],
   ['title' => 'هنرمند', 'icon' => '👨‍🎨', 'color' => '#f9ca24'],
   ['title' => 'فضانورد', 'icon' => '👨‍🚀', 'color' => '#6c5ce7'],
   ['title' => 'بازیگر', 'icon' => '🎭', 'color' => '#a29bfe'],
   ['title' => 'آشپز', 'icon' => '👨‍🍳', 'color' => '#fd79a8'],
   ['title' => 'نویسنده', 'icon' => '✍️', 'color' => '#fdcb6e'],
   ['title' => 'دانشمند', 'icon' => '👨‍🔬', 'color' => '#00b894'],
   ['title' => 'ورزشکار', 'icon' => '🏃', 'color' => '#e17055'],
   ['title' => 'خلبان', 'icon' => '✈️', 'color' => '#74b9ff'],
   ['title' => 'برنامه‌نویس', 'icon' => '💻', 'color' => '#2d3436'],
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>لباس آرزوهای من ✨</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700;900&display=swap');
        body { font-family: 'Vazirmatn', sans-serif; background: linear-gradient(135deg,#ffecd2 0%,#fcb69f 100%); min-height:100vh; overflow-x:hidden; }
        .animated-bg { position: fixed; width:200%; height:200%; top:-50%; left:-50%; z-index:-1; animation: rotate 30s linear infinite; background: linear-gradient(45deg,#ff9a9e,#fecfef,#fecfef,#fad0c4,#fad0c4,#ff9a9e); background-size:300% 300%; }
        @keyframes rotate { 100% { transform: rotate(360deg);} }
        .tab-button { transition: all .3s cubic-bezier(0.68,-0.55,0.265,1.55); }
        .tab-button:not(.active):hover { transform: translateY(-5px) scale(1.05); }
        .tab-button.active { background: linear-gradient(135deg,#667eea 0%,#764ba2 100%); color:#fff; transform:scale(1.1); box-shadow:0 10px 20px rgba(0,0,0,.2);}
        .dream-card { transition: all .4s ease; backdrop-filter: blur(10px); background: rgba(255,255,255,.8); border:1px solid rgba(255,255,255,.3);}
        .dream-card:hover { transform: translateY(-10px) scale(1.03); box-shadow:0 20px 40px rgba(0,0,0,.15);}
        .image-container { position:relative; overflow:hidden; }
        .image-overlay { position:absolute; inset:0; background:rgba(0,0,0,.5); display:flex; align-items:center; justify-content:center; opacity:0; transition:opacity .3s; cursor:pointer; }
        .dream-card:hover .image-overlay { opacity:1; }
        .job-button { transition: all .2s ease; border:2px solid transparent; }
        .job-button:hover { transform: translateY(-3px) scale(1.05); border-color:#fff; box-shadow:0 8px 15px rgba(0,0,0,.2); }
        .job-button.selected { transform: scale(1.05); border-color:#fff; box-shadow:0 0 0 4px rgba(255,255,255,.5); }
        .bounce-in { animation:bounceIn .8s cubic-bezier(0.68,-0.55,0.265,1.55); }
        @keyframes bounceIn { 0%{opacity:0; transform:scale(.3);} 50%{transform:scale(1.05);} 70%{transform:scale(.9);} 100%{opacity:1; transform:scale(1);} }
        .sparkle { animation: sparkle 1.5s ease-in-out infinite; }
        @keyframes sparkle { 0%,100%{opacity:1; transform:scale(1);} 50%{opacity:.5; transform:scale(.8);} }
        .confetti { position:fixed; width:10px; height:10px; position:absolute; animation: confetti-fall 3s linear; }
        @keyframes confetti-fall { to { transform: translateY(100vh) rotate(360deg);} }
        .modal-content { animation: modalFadeIn .3s ease-out; }
        @keyframes modalFadeIn { from{opacity:0; transform:scale(.9);} to{opacity:1; transform:scale(1);} }
    </style>
</head>
<body>
<div class="animated-bg"></div>
<div class="p-4 md:p-8 relative z-10">
    <header class="text-center mb-8">
        <h1 class="text-4xl md:text-7xl font-black text-white drop-shadow-lg bounce-in">
            👕 لباس آرزوهای من ✨
        </h1>
        <p class="text-lg md:text-xl text-white/90 mt-2">
            خوش اومدی <?php echo $currentUser['name']; ?>! <?php echo $currentUser['isAdmin'] ? '👨‍💼' : '🌟'; ?>
        </p>
    </header>

    <main class="max-w-7xl mx-auto">
        <div class="flex justify-center gap-4 mb-8">
            <button id="tab-create" class="tab-button active bg-white text-purple-600 font-bold py-3 px-6 md:px-8 rounded-full shadow-lg flex items-center gap-2 text-sm md:text-base">
                <i class="fas fa-magic"></i> ساخت لباس من
            </button>
            <button id="tab-wall" class="tab-button bg-white text-pink-600 font-bold py-3 px-6 md:px-8 rounded-full shadow-lg flex items-center gap-2 text-sm md:text-base">
                <i class="fas fa-wallpaper"></i> دیوار آرزوها
            </button>
        </div>

        <section id="create-content" class="tab-content">
            <?php if ($userOutfit): ?>
                <div class="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl p-6 md:p-8 text-center">
                    <div class="text-6xl mb-4 sparkle">🎉</div>
                    <h2 class="text-2xl md:text-3xl font-bold text-purple-600 mb-4">هورا! تو قبلاً لباست رو ساختی!</h2>
                    <p class="text-base md:text-lg text-gray-700 mb-6">
                        آرزوی تو بودن: <span class="font-bold"><?php echo $userOutfit['dream_text']; ?></span>
                    </p>

                    <div class="relative flex justify-center items-center mb-6">
                        <img src="/<?php echo $userOutfit['image_path']; ?>" alt="لباس آرزوی شما" class="w-80 h-80 object-cover rounded-2xl shadow-xl">
                        <button onclick="openRefineModal('<?php echo $userOutfit['image_path']; ?>','<?php echo $userOutfit['dream_text']; ?>')" class="absolute top-2 left-2 bg-white/90 text-gray-700 p-2 rounded-full shadow-lg hover:bg-white">
                            <i class="fas fa-wand-magic-sparkles"></i>
                        </button>
                    </div>

                    <button onclick="switchTab('wall')" class="bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold py-3 px-6 rounded-full hover:shadow-xl transition-all">
                        برو به دیوار برای دیدن بقیه! 🚀
                    </button>
                </div>
            <?php else: ?>
                <form id="create-form" class="bg-white/90 backdrop-blur-md rounded-3xl shadow-2xl پ-6 md:p-8" enctype="multipart/form-data">
                    <h2 class="text-2xl md:text-3xl font-bold text-center text-purple-600 mb-6">
                        <i class="fas fa-wand-magic-sparkles"></i> لباس آرزوی خودت رو بساز!
                    </h2>

                    <div class="mb-6">
                        <label class="block text-gray-700 font-bold mb-4">من می‌خوام بشم...</label>
                        <input type="hidden" id="dreamText" name="dreamText" required>
                        <div class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3 mb-4" id="jobButtonsContainer">
                            <?php foreach($jobButtons as $job): ?>
                                <button type="button" class="job-button text-white font-bold py-3 px-2 rounded-xl text-xs md:text-sm shadow-lg" style="background-color: <?php echo $job['color']; ?>;" data-dream="<?php echo $job['title']; ?>">
                                    <span class="text-lg md:text-2xl block mb-1"><?php echo $job['icon']; ?></span>
                                    <?php echo $job['title']; ?>
                                </button>
                            <?php endforeach; ?>
                            <button type="button" class="job-button text-gray-700 font-bold py-3 px-2 rounded-xl text-xs md:text-sm shadow-lg bg-gradient-to-br from-gray-200 to-gray-400" data-dream="other" id="otherJobBtn">
                                <span class="text-lg md:text-2xl block mb-1">✨</span> سایر
                            </button>
                        </div>
                        <div id="otherJobInput" class="hidden">
                            <input type="text" id="customDreamText" maxlength="30" class="w-full px-4 py-3 border-2 border-pink-300 rounded-full text-center text-lg focus:outline-none focus:border-purple-500" placeholder="آرزوی خودت رو بنویس...">
                        </div>
                        <span id="dreamCharCount" class="text-sm text-gray-500">0/30</span>
                    </div>

                    <div class="mb-6">
                        <label class="block text-gray-700 font-bold mb-2">یه دسته برای آرزوت انتخاب کن:</label>
                        <select id="category" name="category" required class="w-full px-4 py-3 border-2 border-pink-300 rounded-full text-center focus:outline-none focus:border-purple-500">
                            <option value="">انتخاب کن...</option>
                            <?php foreach($categories as $key => $cat): ?>
                                <option value="<?php echo $key; ?>"><?php echo $cat['icon']; ?> <?php echo $cat['title']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-6">
                        <label class="block text-gray-700 font-bold mb-2">عکس خودت رو بفرست 📸</label>
                        <div class="border-4 border-dashed border-pink-300 rounded-2xl p-6 text-center hover:border-purple-500 transition-colors">
                            <input type="file" id="photo" name="photo" accept="image/*" class="hidden">
                            <label for="photo" class="cursor-pointer">
                                <div id="photo-placeholder">
                                    <i class="fas fa-cloud-upload-alt text-6xl text-pink-400 mb-3"></i>
                                    <p class="text-gray-600">اینجا کلیک کن و عکستو انتخاب کن</p>
                                </div>
                                <img id="photo-preview" src="" alt="پیش‌نمایش" class="hidden w-32 h-32 object-cover rounded-2xl mx-auto">
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-600 text-white font-bold py-4 rounded-full text-xl hover:shadow-2xl transition-all transform hover:scale-105">
                        <i class="fas fa-sparkles"></i> جادو کن! لباسمو بساز!
                    </button>
                </form>
            <?php endif; ?>
        </section>

        <section id="wall-content" class="tab-content hidden">
            <div class="mb-6 flex justify-center gap-2 flex-wrap">
                <button class="filter-btn active bg-white text-purple-600 font-bold py-2 px-4 rounded-full shadow" data-category="all">همه</button>
                <?php foreach($categories as $key => $cat): ?>
                    <button class="filter-btn bg-white text-gray-600 font-bold py-2 px-4 rounded-full shadow hover:bg-purple-100" data-category="<?php echo $key; ?>">
                        <?php echo $cat['icon']; ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <div id="wall-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"></div>
        </section>
    </main>
</div>

<!-- Modal بزرگ‌نمایی -->
<div id="imageModal" class="fixed inset-0 bg-black/80 z-50 hidden items-center justify-center p-4">
    <div class="modal-content max-w-4xl max-h-full relative">
        <img id="modalImage" src="" alt="عکس بزرگ" class="max-w-full max-h-full rounded-2xl">
        <button onclick="closeModal()" class="absolute top-4 right-4 text-white text-4xl bg-black/50 rounded-full w-10 h-10">&times;</button>
    </div>
</div>

<!-- Modal تأیید -->
<div id="publishConfirmationModal" class="fixed inset-0 bg-black/70 z-50 hidden items-center justify-center p-4">
    <div class="modal-content bg-white rounded-3xl p-8 max-w-lg w-full text-center">
        <h2 class="text-2xl md:text-3xl font-bold text-purple-600 mb-4">وای چقدر قشنگ! ✨</h2>
        <div class="flex justify-center items-center h-96 mb-4">
            <img id="confirmationImage" src="" alt="لباس آرزوی شما" class="max-w-full max-h-full object-contain rounded-2xl shadow-lg">
        </div>
        <p id="confirmationDreamText" class="text-lg mb-6"></p>
        <div class="flex gap-4 justify-center flex-wrap">
            <button id="publishFinalBtn" class="bg-green-500 text-white font-bold py-2 px-6 rounded-full hover:bg-green-600">آره، بزن رو دیوار! 🎉</button>
            <button id="refineImageBtn" class="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold py-2 px-6 rounded-full hover:shadow-xl">یکم دیگه روش کار کن 🪄</button>
        </div>
    </div>
</div>

<!-- Modal اصلاح -->
<div id="refinePromptModal" class="fixed inset-0 bg-black/70 z-50 hidden items-center justify-center p-4">
    <div class="modal-content bg-white rounded-3xl p-8 max-w-md w-full">
        <h3 class="text-2xl font-bold text-purple-600 mb-4">جادوی جدید رو بنویس! 🪄</h3>
        <img id="refineModalImage" src="" alt="عکس" class="w-full h-48 object-cover rounded-2xl mb-4">
        <textarea id="newPrompt" class="w-full p-3 border-2 border-purple-300 rounded-xl" rows="4" placeholder="مثلاً: لباس رو رنگارنگ‌تر کن یا یک کلاه جادویی اضافه کن..."></textarea>
        <input type="hidden" id="refineImagePath">
        <div class="flex gap-4 justify-end mt-6">
            <button onclick="closeRefinePromptModal()" class="bg-gray-300 text-gray-700 font-bold py-2 px-6 rounded-full hover:bg-gray-400">انصراف</button>
            <button onclick="applyImageEdit()" class="bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold py-2 px-6 rounded-full hover:shadow-xl">اعمال جادو ✨</button>
        </div>
    </div>
</div>

<script>
// نقش ادمین از PHP به JS
const IS_ADMIN = <?php echo $currentUser['isAdmin'] ? 'true' : 'false'; ?>;

document.addEventListener('DOMContentLoaded', function () {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    const createForm  = document.getElementById('create-form');
    const photoInput  = document.getElementById('photo');
    const photoPreview= document.getElementById('photo-preview');
    const photoPlaceholder = document.getElementById('photo-placeholder');
    const dreamText   = document.getElementById('dreamText');
    const customDreamText = document.getElementById('customDreamText');
    const dreamCharCount  = document.getElementById('dreamCharCount');

    let currentImagePath = '';
    let currentCategory  = '';

    // -------- JSON parser with fallback --------
    async function parseJsonSafe(response) {
        const raw = await response.text();
        try {
            return { data: JSON.parse(raw), raw, status: response.status };
        } catch (e) {
            return { data: null, raw, status: response.status, error: e };
        }
    }

    // -------- UI helpers --------
    window.switchTab = function (tabName) {
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.add('hidden'));

        if (tabName === 'create') {
            document.getElementById('tab-create').classList.add('active');
            document.getElementById('create-content').classList.remove('hidden');
        } else {
            document.getElementById('tab-wall').classList.add('active');
            document.getElementById('wall-content').classList.remove('hidden');
            loadWall('all');
        }
    };

    window.openModal = function (src) {
        document.getElementById('modalImage').src = src;
        document.getElementById('imageModal').style.display = 'flex';
    };
    window.closeModal = function () {
        document.getElementById('imageModal').style.display = 'none';
    };

    window.openRefineModal = function (imagePath, dreamTextValue) {
        document.getElementById('publishConfirmationModal').style.display = 'none';
        document.getElementById('refineModalImage').src = '/' + imagePath;
        document.getElementById('refineImagePath').value = imagePath;
        document.getElementById('newPrompt').value = `برای آرزوی "${dreamTextValue}" عکس رو بهتر کن: `;
        document.getElementById('refinePromptModal').style.display = 'flex';
    };
    window.closeRefinePromptModal = function () {
        document.getElementById('refinePromptModal').style.display = 'none';
    };

    window.deleteOutfit = async function (id) {
        if (!confirm('مطمئنی می‌خوای حذفش کنی؟')) return;
        const formData = new FormData();
        formData.append('id', id);

        const response = await fetch('?action=delete', { method: 'POST', body: formData });
        const { data, raw } = await parseJsonSafe(response);
        if (!data) {
            console.error('Invalid JSON:', raw);
            alert('پاسخ نامعتبر از سرور.');
            return;
        }
        if (data.ok) {
            alert(data.msg);
            loadWall(document.querySelector('.filter-btn.active').dataset.category);
        } else {
            alert('خطا: ' + data.msg);
        }
    };

    // -------- Jobs buttons --------
    document.querySelectorAll('.job-button').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const target = e.currentTarget;
            document.querySelectorAll('.job-button').forEach(b => b.classList.remove('selected'));
            target.classList.add('selected');

            const dream = target.dataset.dream;
            const otherInput = document.getElementById('otherJobInput');
            if (dream === 'other') {
                otherInput.classList.remove('hidden');
                if (customDreamText) customDreamText.focus();
                dreamText.value = '';
            } else {
                otherInput.classList.add('hidden');
                dreamText.value = dream;
                if (customDreamText) customDreamText.value = '';
            }
            updateCharCount();
        });
    });
    function updateCharCount() {
        dreamCharCount.textContent = `${(dreamText.value || '').length}/30`;
    }
    if (customDreamText) {
        customDreamText.addEventListener('input', () => {
            dreamText.value = customDreamText.value;
            updateCharCount();
        });
    }

    // -------- Create form submit --------
    if (createForm) {
        createForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!dreamText.value.trim()) {
                alert('لطفاً یک آرزو انتخاب کن!');
                return;
            }
            const categorySel = document.getElementById('category');
            if (!categorySel.value) {
                alert('لطفاً یک دسته برای آرزوت انتخاب کن!');
                return;
            }

            const submitBtn = e.target.querySelector('button[type="submit"]');
            const original = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> داره جادو میشه...';

            const formData = new FormData(createForm);
            const response = await fetch('?action=upload_and_generate', { method: 'POST', body: formData });
            const { data, raw } = await parseJsonSafe(response);

            submitBtn.disabled = false;
            submitBtn.innerHTML = original;

            if (!data) {
                console.error('Invalid JSON:', raw);
                alert('پاسخ سرور معتبر نیست. لطفاً دوباره تلاش کن.');
                return;
            }
            if (data.ok) {
                currentImagePath = data.previewUrl;
                currentCategory  = categorySel.value;
                showPublishConfirmation(data.previewUrl, dreamText.value);
            } else {
                alert('ساخت عکس با هوش مصنوعی ناموفق بود! پیام: ' + data.msg);
            }
        });
    }

    // -------- File preview --------
    if (photoInput) {
        photoInput.addEventListener('change', (e) => {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                photoPreview.src = ev.target.result;
                photoPreview.classList.remove('hidden');
                photoPlaceholder.classList.add('hidden');
            };
            reader.readAsDataURL(file);
        });
    }

    // -------- Publish confirmation modal --------
    function showPublishConfirmation(imagePath, dreamTextValue) {
        const modal = document.getElementById('publishConfirmationModal');
        document.getElementById('confirmationImage').src = '/' + imagePath;
        document.getElementById('confirmationDreamText').textContent =
            `آرزوی تو "${dreamTextValue}" بود. آماده‌ای که این لباس رو روی دیوار نصب کنیم؟`;
        modal.style.display = 'flex';

        document.getElementById('publishFinalBtn').onclick = () => publishOutfit(imagePath, dreamTextValue, currentCategory);
        document.getElementById('refineImageBtn').onclick = () => openRefineModal(imagePath, dreamTextValue);
    }

    window.publishOutfit = async function (imagePath, dreamTextValue, category) {
        const formData = new FormData();
        formData.append('dreamText', dreamTextValue);
        formData.append('category',  category);
        formData.append('previewUrl', imagePath);

        const response = await fetch('?action=publish', { method: 'POST', body: formData });
        const { data, raw } = await parseJsonSafe(response);

        document.getElementById('publishConfirmationModal').style.display = 'none';

        if (!data) {
            console.error('Invalid JSON:', raw);
            alert('پاسخ نامعتبر از سرور.');
            return;
        }
        if (data.ok) {
            showConfetti();
            alert(data.msg);
            location.reload();
        } else {
            alert('خطا در انتشار: ' + data.msg);
        }
    };

    // -------- Wall listing --------
    async function loadWall(category = 'all') {
        const grid = document.getElementById('wall-grid');
        grid.innerHTML = '<div class="col-span-full text-center text-2xl">در حال بارگذاری...</div>';

        const response = await fetch(`?action=list&category=${encodeURIComponent(category)}`);
        const { data, raw } = await parseJsonSafe(response);

        grid.innerHTML = '';
        if (!data) {
            console.error('Invalid JSON:', raw);
            grid.innerHTML = '<div class="col-span-full text-center text-red-600">پاسخ نامعتبر از سرور.</div>';
            return;
        }
        if (data.ok && data.items.length > 0) {
            data.items.forEach(item => grid.appendChild(createDreamCard(item)));
        } else {
            grid.innerHTML = '<div class="col-span-full text-center text-gray-500 text-xl">هنوز آرزویی اینجا ثبت نشده! 😊</div>';
        }
    }

    function createDreamCard(item) {
        const safeDream = String(item.dream_text ?? '').replace(/[`\\]/g, '\\$&');
        const adminControls = IS_ADMIN ? `
            <button onclick="deleteOutfit(${item.id})"
                    class="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600">
              <i class="fas fa-trash"></i>
            </button>
        ` : '';
        const refineBtn = `
            <button onclick="openRefineModal('${item.image_path}', '${safeDream}')"
                    class="absolute bottom-2 left-2 bg-white/90 text-gray-700 p-2 rounded-full shadow-lg hover:bg-white">
              <i class="fas fa-wand-magic-sparkles"></i>
            </button>
        `;
        const createdAt = item.created_at ? new Date(item.created_at).toLocaleDateString('fa-IR') : '';

        const card = document.createElement('div');
        card.className = 'dream-card rounded-2xl shadow-xl overflow-hidden relative';
        card.innerHTML = `
            <div class="image-container h-64">
              <img src="/${item.image_path}" alt="${safeDream}" class="w-full h-full object-cover">
              <div class="image-overlay" onclick="openModal('/${item.image_path}')">
                <i class="fas fa-search-plus text-white text-4xl"></i>
              </div>
              ${adminControls}
              ${refineBtn}
            </div>
            <div class="p-4">
              <h3 class="font-bold text-lg text-purple-700">${item.student_name || ''}</h3>
              <p class="text-gray-600">آرزوم: ${safeDream}</p>
              <p class="text-sm text-gray-400 mt-2">${createdAt}</p>
            </div>
        `;
        return card;
    }

    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active','bg-purple-600','text-white'));
            e.currentTarget.classList.add('active','bg-purple-600','text-white');
            loadWall(e.currentTarget.dataset.category);
        });
    });

    window.applyImageEdit = async function () {
        const newPrompt = document.getElementById('newPrompt').value;
        const imagePath = document.getElementById('refineImagePath').value;

        if (!newPrompt.trim()) {
            alert('لطفاً یه توضیح بنویس.');
            return;
        }

        closeRefinePromptModal();
        alert('در حال اعمال جادوی جدید...');

        const formData = new FormData();
        formData.append('image_path', imagePath);
        formData.append('new_prompt', newPrompt);

        const response = await fetch('?action=regenerate', { method: 'POST', body: formData });
        const { data, raw } = await parseJsonSafe(response);

        if (!data) {
            console.error('Invalid JSON:', raw);
            alert('پاسخ نامعتبر از سرور.');
            return;
        }
        if (data.ok) {
            alert(data.msg);
            const imgs = document.querySelectorAll(`img[src="/${imagePath}"]`);
            imgs.forEach(img => img.src = data.newImageUrl);
            const confirmationImg = document.getElementById('confirmationImage');
            if (confirmationImg && confirmationImg.src.includes(imagePath)) {
                confirmationImg.src = data.newImageUrl;
            }
            const activeBtn = document.querySelector('.filter-btn.active');
            if (activeBtn) loadWall(activeBtn.dataset.category);
        } else {
            alert('خطا: ' + data.msg);
        }
    };

    function showConfetti() {
        for (let i = 0; i < 100; i++) {
            setTimeout(() => {
                const c = document.createElement('div');
                c.className = 'confetti';
                c.style.left = Math.random() * 100 + '%';
                c.style.backgroundColor = `hsl(${Math.random() * 360},100%,50%)`;
                c.style.animationDelay = Math.random() * 0.5 + 's';
                document.body.appendChild(c);
                setTimeout(() => c.remove(), 3000);
            }, i * 30);
        }
    }

    document.getElementById('tab-create')?.addEventListener('click', () => switchTab('create'));
    document.getElementById('tab-wall')?.addEventListener('click', () => switchTab('wall'));
});
</script>
</body>
</html>
