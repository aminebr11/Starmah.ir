<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

// تعیین شناسه دانش‌آموز
 $studentId = null;
if (isset($_GET['student_id']) && is_numeric($_GET['student_id'])) {
    $studentId = (int)$_GET['student_id'];
} else if ($_SESSION['user_type'] === 'student') {
    $studentId = (int)$_SESSION['user_id'];
} else {
    die('<h1>خطا: شناسه دانش‌آموز معتبر نیست.</h1><a href="weekly_analysis.php">بازگشت</a>');
}

// دریافت اطلاعات دانش‌آموز
 $stmt = $conn->prepare("SELECT first_name, last_name, avatar FROM users WHERE id = ? AND user_type = 'student'");
 $stmt->execute([$studentId]);
 $student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die('<h1>خطا: دانش‌آموز یافت نشد.</h1><a href="weekly_analysis.php">بازگشت</a>');
}

// --- شروع بخش اصلاح‌شده ---

// 1. ابتدا تمام سال‌های موجود برای این دانش‌آموز را دریافت کنیم
 $yearsStmt = $conn->prepare("SELECT DISTINCT year FROM weekly_xp_summary WHERE student_id = ? ORDER BY year DESC");
 $yearsStmt->execute([$studentId]);
 $availableYears = $yearsStmt->fetchAll(PDO::FETCH_COLUMN);

// 2. سال انتخاب‌شده را تعیین کنیم
 $selectedYear = null;
if (isset($_GET['year']) && in_array((int)$_GET['year'], $availableYears)) {
    // اگر سال از طریق URL ارسال شده و معتبر است، از آن استفاده کن
    $selectedYear = (int)$_GET['year'];
} else if (!empty($availableYears)) {
    // در غیر این صورت، جدیدترین سال موجود را به عنوان پیش‌فرض انتخاب کن
    $selectedYear = (int)$availableYears[0];
} else {
    // اگر اصلاً داده‌ای وجود ندارد، سال را null بگذار
    $selectedYear = null;
}

// 3. ماه انتخاب‌شده را دریافت کنیم
 $selectedMonth = isset($_GET['month']) && $_GET['month'] !== '' ? (int)$_GET['month'] : null;

// 4. سوابق هفتگی را بر اساس سال و ماه فیلتر شده دریافت کنیم
 $weeklyHistory = [];
if ($selectedYear !== null) {
    $sql = "SELECT year, month, week_number, total_xp, `rank`, week_start_date
            FROM weekly_xp_summary 
            WHERE student_id = ? AND year = ?";
    $params = [$studentId, $selectedYear];

    if ($selectedMonth !== null) {
        $sql .= " AND month = ?";
        $params[] = $selectedMonth;
    }

    $sql .= " ORDER BY year, month, week_number ASC";
    $historyStmt = $conn->prepare($sql);
    $historyStmt->execute($params);
    $weeklyHistory = $historyStmt->fetchAll(PDO::FETCH_ASSOC);
}

// --- پایان بخش اصلاح‌شده ---


// آماده‌سازی داده‌ها
 $monthNames = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
 $chartLabels = [];
 $chartXp = [];
 $chartRanks = [];

foreach ($weeklyHistory as $record) {
    $chartLabels[] = "هفته {$record['week_number']} {$monthNames[$record['month']]}";
    $chartXp[] = (int)$record['total_xp'];
    $chartRanks[] = (int)$record['rank'];
}

// محاسبات آماری
 $totalWeeks = count($weeklyHistory);
 $totalXp = array_sum($chartXp);
 $avgXp = $totalWeeks > 0 ? round($totalXp / $totalWeeks) : 0;
 $maxXp = !empty($chartXp) ? max($chartXp) : 0;
 $minXp = !empty($chartXp) ? min($chartXp) : 0;
 $bestWeekRecord = null;
 $worstWeekRecord = null;

if (!empty($weeklyHistory)) {
    $bestWeekIndex = array_search($maxXp, $chartXp);
    $worstWeekIndex = array_search($minXp, $chartXp);
    $bestWeekRecord = $weeklyHistory[$bestWeekIndex];
    $worstWeekRecord = $weeklyHistory[$worstWeekIndex];
}

 $currentRank = !empty($chartRanks) ? end($chartRanks) : 'N/A';
 $rankTrend = '';
 $rankTrendClass = '';

if (count($chartRanks) >= 2) {
    $lastRank = end($chartRanks);
    $prevRank = $chartRanks[count($chartRanks) - 2];
    $rankDiff = abs($lastRank - $prevRank);
    
    if ($lastRank < $prevRank) {
        $rankTrend = "بهبود {$rankDiff} رتبه‌ای";
        $rankTrendClass = 'trend-up';
    } elseif ($lastRank > $prevRank) {
        $rankTrend = "کاهش {$rankDiff} رتبه‌ای";
        $rankTrendClass = 'trend-down';
    } else {
        $rankTrend = "ثابت";
        $rankTrendClass = 'trend-stable';
    }
}

// دریافت ماه‌های موجود برای سال انتخابی
 $availableMonths = [];
if ($selectedYear !== null) {
    $monthsStmt = $conn->prepare("SELECT DISTINCT month FROM weekly_xp_summary WHERE student_id = ? AND year = ? ORDER BY month ASC");
    $monthsStmt->execute([$studentId, $selectedYear]);
    $availableMonths = $monthsStmt->fetchAll(PDO::FETCH_COLUMN);
}

// بخش دیباگ کردن (اختیاری، برای عیب‌یابی)
if (isset($_GET['debug'])) {
    echo '<div style="background: #333; color: #fff; padding: 15px; margin-bottom: 20px; font-family: monospace; direction: ltr; border-radius: 8px;">';
    echo '<h3>Debug Information</h3>';
    echo '<pre>';
    echo 'Student ID: ' . $studentId . "\n";
    echo 'Available Years: ' . print_r($availableYears, true) . "\n";
    echo 'Selected Year (from URL): ' . ($_GET['year'] ?? 'not set') . "\n";
    echo 'Final Selected Year: ' . $selectedYear . "\n";
    echo 'Available Months for Selected Year: ' . print_r($availableMonths, true) . "\n";
    echo 'Selected Month: ' . ($selectedMonth ?? 'null') . "\n";
    echo 'Weekly History Count: ' . count($weeklyHistory) . "\n";
    if (isset($sql)) echo 'SQL Query: ' . $sql . "\n";
    if (isset($params)) echo 'SQL Params: ' . print_r($params, true) . "\n";
    echo '</pre>';
    echo '</div>';
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تحلیل عملکرد - <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #8b5cf6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
            --light: #f8fafc;
            --dark: #1e293b;
            --gray: #64748b;
            --border: #e2e8f0;
        }

        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: var(--dark);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header */
        .header {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 25px;
            margin-bottom: 25px;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .back-btn {
            background: var(--light);
            color: var(--dark);
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .back-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateX(5px);
        }

        .avatar-container {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            padding: 4px;
            flex-shrink: 0;
        }

        .avatar {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: var(--gray);
            overflow: hidden;
        }

        .avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .student-info {
            flex: 1;
        }

        .student-info h1 {
            font-size: 1.8rem;
            color: var(--dark);
            margin-bottom: 8px;
        }

        .student-info p {
            color: var(--gray);
            font-size: 1rem;
        }

        /* Filters */
        .filters-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }

        .filters-form {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .filter-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            background: white;
            color: var(--dark);
            font-size: 1rem;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-group select:hover {
            border-color: var(--primary);
        }

        .filter-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        .filter-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 32px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }

        .stat-card:hover::before {
            transform: scaleX(1);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 15px;
        }

        .stat-card.primary .stat-icon { background: rgba(99, 102, 241, 0.1); color: var(--primary); }
        .stat-card.success .stat-icon { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .stat-card.warning .stat-icon { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .stat-card.info .stat-icon { background: rgba(59, 130, 246, 0.1); color: var(--info); }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray);
            font-size: 0.95rem;
            margin-bottom: 8px;
        }

        .stat-trend {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .trend-up {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .trend-down {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .trend-stable {
            background: rgba(100, 116, 139, 0.1);
            color: var(--gray);
        }

        /* Charts & Table */
        .chart-card, .table-card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }

        .chart-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light);
        }

        .chart-header i {
            font-size: 1.5rem;
            color: var(--primary);
        }

        .chart-header h2 {
            font-size: 1.3rem;
            color: var(--dark);
        }

        .chart-container {
            position: relative;
            height: 320px;
        }

        .no-data {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 200px;
            color: var(--gray);
            text-align: center;
        }

        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.3;
        }

        .no-data p {
            font-size: 1rem;
            line-height: 1.6;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: right;
            border-bottom: 1px solid var(--border);
        }

        .data-table thead th {
            background-color: var(--light);
            font-weight: 600;
            color: var(--dark);
        }

        .data-table tbody tr:hover {
            background-color: rgba(99, 102, 241, 0.05);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                text-align: center;
            }

            .filters-form {
                flex-direction: column;
            }

            .filter-group {
                width: 100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .student-info h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header class="header">
        <a href="weekly_analysis.php" class="back-btn">
            <i class="fas fa-arrow-right"></i>
            بازگشت
        </a>
        <div class="avatar-container">
            <div class="avatar">
                <?php if ($student['avatar']): ?>
                    <img src="../<?= htmlspecialchars($student['avatar']) ?>" alt="Avatar">
                <?php else: ?>
                    <i class="fas fa-user"></i>
                <?php endif; ?>
            </div>
        </div>
        <div class="student-info">
            <h1><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></h1>
            <p>تحلیل جامع عملکرد هفتگی</p>
        </div>
    </header>

    <!-- Filters -->
    <?php if (!empty($availableYears)): ?>
    <div class="filters-card">
        <form method="GET" action="" class="filters-form">
            <input type="hidden" name="student_id" value="<?= $studentId ?>">
            
            <div class="filter-group">
                <label for="year"><i class="fas fa-calendar"></i> سال تحصیلی</label>
                <select name="year" id="year">
                    <?php foreach ($availableYears as $year): ?>
                        <option value="<?= $year ?>" <?= $year == $selectedYear ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="month"><i class="fas fa-calendar-alt"></i> ماه</label>
                <select name="month" id="month">
                    <option value="">همه ماه‌ها</option>
                    <?php foreach ($availableMonths as $monthNum): ?>
                        <option value="<?= $monthNum ?>" <?= $monthNum == $selectedMonth ? 'selected' : '' ?>>
                            <?= $monthNames[$monthNum] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" class="filter-btn">
                <i class="fas fa-filter"></i>
                اعمال فیلتر
            </button>
        </form>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card primary">
            <div class="stat-icon">
                <i class="fas fa-trophy"></i>
            </div>
            <div class="stat-value"><?= number_format($totalXp) ?></div>
            <div class="stat-label">مجموع امتیاز کسب شده</div>
        </div>

        <div class="stat-card success">
            <div class="stat-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-value"><?= number_format($avgXp) ?></div>
            <div class="stat-label">میانگین امتیاز در هفته</div>
        </div>

        <div class="stat-card warning">
            <div class="stat-icon">
                <i class="fas fa-medal"></i>
            </div>
            <div class="stat-value"><?= $currentRank ?></div>
            <div class="stat-label">رتبه در آخرین هفته</div>
            <?php if ($rankTrend): ?>
                <span class="stat-trend <?= $rankTrendClass ?>">
                    <i class="fas fa-<?= $rankTrendClass === 'trend-up' ? 'arrow-up' : ($rankTrendClass === 'trend-down' ? 'arrow-down' : 'minus') ?>"></i>
                    <?= $rankTrend ?>
                </span>
            <?php endif; ?>
        </div>

        <div class="stat-card info">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-value">
                <?= $bestWeekRecord ? number_format($bestWeekRecord['total_xp']) : 'N/A' ?>
            </div>
            <div class="stat-label">
                <?php if ($bestWeekRecord): ?>
                    بهترین هفته: هفته <?= $bestWeekRecord['week_number'] ?> <?= $monthNames[$bestWeekRecord['month']] ?>
                <?php else: ?>
                    بهترین عملکرد
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="charts-grid">
        <div class="chart-card">
            <div class="chart-header">
                <i class="fas fa-chart-area"></i>
                <h2>روند تغییرات امتیاز</h2>
            </div>
            <div class="chart-container">
                <?php if (!empty($chartLabels)): ?>
                    <canvas id="xpChart"></canvas>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-chart-line"></i>
                        <p>
                        <?php 
                        if (empty($availableYears)) {
                            echo 'این دانش‌آموز تاکنون هیچ فعالیت هفتگی ثبت‌شده‌ای نداشته است.';
                        } else {
                            echo 'داده‌ای برای بازه زمانی انتخاب شده وجود ندارد. لطفاً سال یا ماه دیگری را انتخاب کنید.';
                        }
                        ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="chart-card">
            <div class="chart-header">
                <i class="fas fa-ranking-star"></i>
                <h2>روند تغییرات رتبه</h2>
            </div>
            <div class="chart-container">
                <?php if (!empty($chartLabels)): ?>
                    <canvas id="rankChart"></canvas>
                <?php else: ?>
                    <div class="no-data">
                        <i class="fas fa-list-ol"></i>
                        <p>داده‌ای برای نمایش وجود ندارد.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Weekly Details Table -->
    <div class="table-card">
        <div class="chart-header">
            <i class="fas fa-table"></i>
            <h2>جزئیات عملکرد هفتگی</h2>
        </div>
        <div class="table-container">
            <?php if (!empty($weeklyHistory)): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>هفته</th>
                            <th>امتیاز</th>
                            <th>رتبه</th>
                            <th>تاریخ شروع</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($weeklyHistory as $record): ?>
                            <tr>
                                <td>هفته <?= $record['week_number'] ?> <?= $monthNames[$record['month']] ?> <?= $record['year'] ?></td>
                                <td><?= number_format($record['total_xp']) ?></td>
                                <td><?= $record['rank'] ?></td>
                                <td><?= date('Y/m/d', strtotime($record['week_start_date'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>داده‌ای برای نمایش وجود ندارد.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const labels = <?= json_encode($chartLabels) ?>;
const xpData = <?= json_encode($chartXp) ?>;
const rankData = <?= json_encode($chartRanks) ?>;

Chart.defaults.font.family = 'Vazirmatn, sans-serif';
Chart.defaults.color = '#64748b';

// XP Chart
if (document.getElementById('xpChart') && labels.length > 0) {
    new Chart(document.getElementById('xpChart'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'امتیاز (XP)',
                data: xpData,
                fill: true,
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                borderColor: 'rgb(99, 102, 241)',
                borderWidth: 3,
                pointBackgroundColor: 'rgb(99, 102, 241)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: { size: 14, weight: 'bold' },
                    bodyFont: { size: 13 },
                    cornerRadius: 8
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.05)' },
                    ticks: { font: { size: 12 } }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 11 } }
                }
            }
        }
    });
}

// Rank Chart
if (document.getElementById('rankChart') && labels.length > 0) {
    new Chart(document.getElementById('rankChart'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'رتبه',
                data: rankData,
                fill: true,
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderColor: 'rgb(245, 158, 11)',
                borderWidth: 3,
                pointBackgroundColor: 'rgb(245, 158, 11)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: { size: 14, weight: 'bold' },
                    bodyFont: { size: 13 },
                    cornerRadius: 8,
                    callbacks: {
                        label: context => ` رتبه: ${context.parsed.y}`
                    }
                }
            },
            scales: {
                y: {
                    reverse: true,
                    grid: { color: 'rgba(0, 0, 0, 0.05)' },
                    ticks: { 
                        stepSize: 1,
                        font: { size: 12 }
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 11 } }
                }
            }
        }
    });
}
</script>

</body>
</html>