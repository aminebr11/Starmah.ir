<?php
// homework section - only show if logged in
if (!isLoggedIn()) {
    exit();
}

// Array of subjects for use in the form and for displaying cards
$subjects = [
    'math' => ['icon' => '🔢', 'title' => 'ریاضی', 'color' => '#FF6B6B'],
    'science' => ['icon' => '🔬', 'title' => 'علوم', 'color' => '#4ECDC4'],
    'persian' => ['icon' => '📖', 'title' => 'فارسی', 'color' => '#45B7D1'],
    'social' => ['icon' => '🗺️', 'title' => 'مطالعات اجتماعی', 'color' => '#F9CA24'],
    'art' => ['icon' => '🎨', 'title' => 'هنر', 'color' => '#A29BFE'],
    'heavenly_gifts' => ['icon' => '📖', 'title' => 'هدیه های آسمانی', 'color' => '#9B59B6'],
    'other' => ['icon' => '📌', 'title' => 'سایر', 'color' => '#778ca3']
];
?>

<!-- Persian Datepicker Libraries -->
<link rel="stylesheet" href="https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css"/>

<section id="homework" class="section">
    <h2 class="section-title">📝 تکالیف روزانه</h2>

   <div class="subject-tabs">
    <button class="tab-btn active" data-subject="all">
        <span>✨</span>
        همه تکالیف
    </button>
    <?php foreach($subjects as $key => $subject): ?>
    <button class="tab-btn" data-subject="<?php echo $key; ?>">
        <span><?php echo $subject['icon']; ?></span>
        <?php echo $subject['title']; ?>
    </button>
    <?php endforeach; ?>
</div>

    <!-- Homework Grid -->
    <div id="homeworkContainer" class="materials-grid">
        <?php
        $homeworks = getHomeworks($conn); 

        if ($homeworks && count($homeworks) > 0) {
            foreach($homeworks as $hw) {
                $subject_info = $subjects[$hw['subject']] ?? $subjects['other'];
        ?>
        <div class="material-card readable-card" data-subject="<?php echo htmlspecialchars($hw['subject']); ?>">
            <div class="material-header">
                <div class="file-icon" style="background: <?php echo $subject_info['color']; ?>20">
                    <?php echo $subject_info['icon']; ?>
                </div>
                <div class="material-info">
                    <h3><?php echo htmlspecialchars($hw['title']); ?></h3>
                    <p class="material-meta">
                        <span class="subject-tag" style="background: <?php echo $subject_info['color']; ?>">
                            <?php echo $subject_info['title']; ?>
                        </span>
                    </p>
                </div>
            </div>

            <?php if(!empty($hw['description'])): ?>
            <div class="material-description">
                <?php echo nl2br(htmlspecialchars($hw['description'])); ?>
            </div>
            <?php endif; ?>

            <div class="material-footer">
                <div class="material-stats">
                    <span><i class="fa fa-calendar-plus"></i> ثبت: <?php echo convertToJalali($hw['created_at']); ?></span>
                    <span><i class="fa fa-calendar-check"></i> تحویل: <?php echo convertToJalali($hw['due_date']); ?></span>
                </div>
                <div class="material-actions">
                    <?php if (!empty($hw['file_path'])): ?>
                        <a href="<?php echo htmlspecialchars($hw['file_path']); ?>" download class="download-btn">
                            <span><i class="fa fa-download"></i></span> دانلود
                        </a>
                    <?php endif; ?>
                    <?php if(isAdmin()): ?>
                    <button class="delete-btn" onclick="deleteHomework(<?php echo $hw['id']; ?>)">
                        <span><i class="fa fa-trash"></i> حذف</span>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo '<div class="empty-state" style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: #666;">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">📚</div>
                    <h3 style="color: #333; margin-bottom: 0.5rem;">هیچ تکلیفی موجود نیست</h3>
                    <p>در حال حاضر تکلیف جدیدی برای نمایش وجود ندارد.</p>
                  </div>';
        }
        ?>
    </div>

    <?php if(isAdmin()): ?>
    <!-- Admin Upload Section -->
    <div class="upload-section-pro">
        <div class="upload-header">
            <h3><i class="fa fa-plus-circle"></i> ثبت تکلیف جدید</h3>
        </div>
        <form id="uploadHomeworkForm" class="upload-form-pro" enctype="multipart/form-data">
            <div class="form-row">
                <div class="form-group pro-group">
                    <label for="title">عنوان تکلیف <span style="color: red;">*</span></label>
                    <input type="text" id="title" name="title" placeholder="مثلا: تمرین ریاضی صفحه ۵۲" required>
                </div>
                <div class="form-group pro-group">
                    <label for="subject">درس <span style="color: red;">*</span></label>
                    <select id="subject" name="subject" required>
                        <option value="" disabled selected>درس را انتخاب کنید</option>
                        <?php foreach($subjects as $key => $subject): ?>
                        <option value="<?php echo $key; ?>"><?php echo $subject['title']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <!-- فیلد تاریخ بهبود یافته -->
            <div class="form-group pro-group">
                <label for="due_date_picker">تاریخ تحویل <span style="color: red;">*</span></label>
                <div class="date-input-wrapper">
                    <input type="text" 
                           name="due_date" 
                           id="due_date_picker" 
                           class="form-control date-input" 
                           autocomplete="off" 
                           placeholder="مثال: 1403/09/15 یا از تقویم انتخاب کنید" 
                           required>
                    
                    <button type="button" id="calendar_btn" class="calendar-btn" title="باز کردن تقویم">
                        📅
                    </button>
                    
                    <div class="quick-date-selectors">
                        <label style="font-size: 0.8rem; color: #666; margin-bottom: 5px; display: block;">انتخاب سریع:</label>
                        <div class="date-selects">
                            <select id="year_select" class="mini-select">
                                <option value="">سال</option>
                            </select>
                            <select id="month_select" class="mini-select">
                                <option value="">ماه</option>
                                <option value="1">فروردین</option>
                                <option value="2">اردیبهشت</option>
                                <option value="3">خرداد</option>
                                <option value="4">تیر</option>
                                <option value="5">مرداد</option>
                                <option value="6">شهریور</option>
                                <option value="7">مهر</option>
                                <option value="8">آبان</option>
                                <option value="9">آذر</option>
                                <option value="10">دی</option>
                                <option value="11">بهمن</option>
                                <option value="12">اسفند</option>
                            </select>
                            <select id="day_select" class="mini-select">
                                <option value="">روز</option>
                            </select>
                            <button type="button" id="apply_date_btn" class="apply-date-btn">اعمال</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="form-group pro-group">
                <label for="description">توضیحات (اختیاری)</label>
                <textarea id="description" name="description" rows="4" placeholder="توضیحات بیشتر در مورد تکلیف..."></textarea>
            </div>
            <div class="form-group pro-group">
                <label for="homework_file">فایل ضمیمه (اختیاری)</label>
                <input type="file" id="homework_file" name="homework_file" class="form-control-file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.txt">
                <small style="color: #666; font-size: 0.8rem; margin-top: 5px; display: block;">
                    فرمت‌های مجاز: PDF, DOC, DOCX, JPG, PNG, TXT - حداکثر 5MB
                </small>
            </div>
            <button type="submit" class="submit-btn-pro">
                <span><i class="fa fa-upload"></i> ثبت و ارسال تکلیف</span>
            </button>
        </form>
    </div>
    <?php endif; ?>
</section>
<script>
// قبل از هر استفاده از style این را اجرا کن
const style = document.createElement('style');
style.type = 'text/css';
style.textContent = `
  /* CSS دلخواهت */
  .podcast-section { scroll-behavior: smooth; }
`;
document.head.appendChild(style);
</script>
<!-- استایل‌های CSS -->
<style>
    /* Readable Card Styles */
    .readable-card {
        background: #fff !important;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
    }
    
    .readable-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        transform: translateY(-2px);
    }
    
    .readable-card, .readable-card h3, .readable-card p, .readable-card span {
        font-family: Tahoma, sans-serif;
        color: #333 !important;
    }
    
    .readable-card .subject-tag {
        color: white !important;
        font-weight: bold;
        padding: 4px 12px;
        border-radius: 16px;
        font-size: 0.85rem;
    }
    
    .readable-card .material-description {
        color: #555 !important;
        line-height: 1.8;
        padding: 1rem;
        background: #f9f9f9;
        margin: 1rem;
        border-radius: 8px;
        border-right: 4px solid #4CAF50;
    }
    
    .material-stats {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }
    
    .material-stats span {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 0.85rem;
        color: #666 !important;
    }
    
    .material-stats .fa {
        color: #888;
    }

    /* Date Input Styles */
    .date-input-wrapper {
        position: relative;
    }

    .date-input {
        padding-left: 50px !important;
    }

    .calendar-btn {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: #667eea;
        color: white;
        border: none;
        border-radius: 6px;
        width: 35px;
        height: 35px;
        cursor: pointer;
        font-size: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        z-index: 5;
    }

    .calendar-btn:hover {
        background: #5a6fd8;
        transform: translateY(-50%) scale(1.1);
    }

    .quick-date-selectors {
        margin-top: 10px;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 8px;
        border: 1px solid #e9ecef;
    }

    .date-selects {
        display: flex;
        gap: 8px;
        align-items: end;
        flex-wrap: wrap;
    }

    .mini-select {
        flex: 1;
        min-width: 80px;
        padding: 6px 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 0.85rem;
        font-family: Tahoma, sans-serif;
        background: white;
    }

    .mini-select:focus {
        border-color: #667eea;
        outline: none;
        box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
    }

    .apply-date-btn {
        padding: 6px 12px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 0.85rem;
        font-family: Tahoma, sans-serif;
        cursor: pointer;
        white-space: nowrap;
        transition: background 0.3s ease;
    }

    .apply-date-btn:hover {
        background: #218838;
    }

    /* Professional Upload Form */
    .upload-section-pro {
        margin-top: 4rem;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        border-radius: 16px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        overflow: hidden;
        border: 1px solid #e2e8f0;
    }
    
    .upload-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        text-align: center;
    }
    
    .upload-header h3 {
        margin: 0;
        font-family: 'Vazirmatn', Tahoma, sans-serif;
        font-weight: 600;
        color: white !important;
        font-size: 1.2rem;
    }
    
    .upload-form-pro {
        padding: 2.5rem;
        background: white;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }
    
    .pro-group {
        margin-bottom: 1.5rem;
    }
    
    .pro-group label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: #2d3748;
        font-family: Tahoma, sans-serif;
        font-size: 0.9rem;
    }
    
    .pro-group input, .pro-group select, .pro-group textarea {
        width: 100%;
        padding: 12px 16px;
        border: 2px solid #e2e8f0;
        border-radius: 8px;
        background: #fff;
        color: #2d3748;
        font-family: Tahoma, sans-serif;
        font-size: 0.9rem;
        transition: all 0.3s ease;
        box-sizing: border-box;
    }
    
    .pro-group input:focus, .pro-group select:focus, .pro-group textarea:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        background: #f8f9ff;
    }
    
    .pro-group textarea {
        resize: vertical;
        min-height: 100px;
    }
    
    .form-control-file {
        padding: 8px 12px !important;
        font-family: Tahoma, sans-serif;
        border: 2px dashed #e2e8f0 !important;
        background: #f8f9fa !important;
    }
    
    .form-control-file:hover {
        border-color: #667eea !important;
        background: #f0f2ff !important;
    }
    
    .submit-btn-pro {
        display: block;
        width: 100%;
        padding: 1rem 2rem;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 700;
        font-family: Tahoma, sans-serif;
        cursor: pointer;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    
    .submit-btn-pro:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    }
    
    .submit-btn-pro:disabled {
        opacity: 0.7;
        cursor: not-allowed;
        transform: none;
    }
    
    /* Subject Tabs */
    .subject-tabs {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .tab-btn {
        padding: 0.75rem 1.5rem;
        border: 2px solid #e2e8f0;
        background: white;
        border-radius: 25px;
        font-family: Tahoma, sans-serif;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .tab-btn:hover {
        border-color: #667eea;
        background: #f0f2ff;
    }
    
    .tab-btn.active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-color: #667eea;
    }
    
    /* Materials Grid */
    .materials-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    
    .material-card {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        padding: 1.5rem;
    }
    
    .material-header {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .file-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        flex-shrink: 0;
    }
    
    .material-info {
        flex: 1;
    }
    
    .material-info h3 {
        margin: 0 0 0.5rem 0;
        font-size: 1.1rem;
        font-weight: 600;
    }
    
    .material-meta {
        margin: 0;
    }
    
    .material-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 1rem;
        margin-top: auto;
        padding-top: 1rem;
        border-top: 1px solid #e0e0e0;
    }
    
    .material-actions {
        display: flex;
        gap: 0.5rem;
    }
    
    .download-btn, .delete-btn {
        padding: 0.5rem 1rem;
        border-radius: 6px;
        text-decoration: none;
        font-size: 0.85rem;
        font-weight: 600;
        font-family: Tahoma, sans-serif;
        cursor: pointer;
        border: none;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .download-btn {
        background: #4CAF50;
        color: white;
    }
    
    .download-btn:hover {
        background: #45a049;
        transform: translateY(-1px);
    }
    
    /* تغییر دکمه حذف - اضافه کردن متن "حذف" */
    .delete-btn {
        background: #dc3545;
        color: white;
        font-weight: bold;
    }
    
    .delete-btn:hover {
        background: #c82333;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
    }
    
    /* Empty State */
    .empty-state {
        grid-column: 1 / -1;
        text-align: center;
        padding: 3rem;
        color: #666;
        background: #f9f9f9;
        border-radius: 12px;
        border: 2px dashed #ddd;
    }
    
    /* Success/Error Messages */
    .success-message, .error-message {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        font-family: Tahoma, sans-serif;
        max-width: 400px;
        word-wrap: break-word;
    }
    
    .success-message {
        background: #4CAF50;
        color: white;
    }
    
    .error-message {
        background: #f44336;
        color: white;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
        
        .materials-grid {
            grid-template-columns: 1fr;
        }
        
        .subject-tabs {
            justify-content: flex-start;
            overflow-x: auto;
            padding-bottom: 0.5rem;
        }
        
        .tab-btn {
            flex-shrink: 0;
        }
        
        .material-stats {
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .material-footer {
            flex-direction: column;
            align-items: stretch;
        }
        
        .material-actions {
            justify-content: center;
        }
        
        .date-selects {
            flex-direction: column;
        }
        
        .mini-select {
            min-width: 100%;
        }
    }
    
    /* Animation for slide in */
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    /* Input Error Styles */
    .input-error {
        color: #f44336;
        font-size: 0.85rem;
        margin-top: 5px;
        font-family: Tahoma, sans-serif;
    }
    // اضافه کردن CSS برای انیمیشن fadeInOut
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInOut {
        0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
        20% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
        80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
        100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
    }
    
    /* اصلاح استایل دکمه‌های فیلتر */
    .subject-tabs .tab-btn {
        transition: all 0.3s ease;
        cursor: pointer;
        user-select: none;
    }
    
    .subject-tabs .tab-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    
    .subject-tabs .tab-btn.active {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }
    
    /* بهبود انیمیشن کارت‌ها */
    .material-card {
        transition: opacity 0.3s ease, transform 0.3s ease, display 0.3s ease;
    }
    
    /* اصلاح نمایش پیام خالی */
    .empty-state {
        animation: fadeIn 0.5s ease;
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
</style>

<!-- JavaScript Libraries -->
<script src="https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js"></script>
<script src="https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>

<!-- Main JavaScript -->
<script>
// JavaScript اصلاح شده برای homework.php

document.addEventListener("DOMContentLoaded", function() {
    console.log('Homework section JavaScript loaded');
    
    // راه‌اندازی همه عملکردها
    initializePersianDatepicker();
    initializeHomeworkForm();
    initializeHomeworkFiltering();
    initializeFormValidation();
    initializeDateSelectors();
    
    // اصلاح مشکل فیلتر تکالیف
    fixHomeworkFiltering();
});

/**
 * اصلاح مشکل فیلتر تکالیف
 */
function fixHomeworkFiltering() {
    // پیدا کردن همه دکمه‌های فیلتر
    const filterButtons = document.querySelectorAll('#homework .subject-tabs .tab-btn');
    
    // اضافه کردن event listener به هر دکمه
    filterButtons.forEach(button => {
        // حذف onclick attribute قبلی
        button.removeAttribute('onclick');
        
        // اضافه کردن event listener جدید
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // استخراج subject از دکمه
            const subject = extractSubjectFromButton(this);
            
            console.log('Filter button clicked:', subject);
            
            // فراخوانی تابع فیلتر
            filterHomework(this, subject);
        });
    });
    
    console.log('Homework filtering fixed - found', filterButtons.length, 'filter buttons');
}

/**
 * استخراج subject از دکمه فیلتر
 */
function extractSubjectFromButton(button) {
    // بررسی onclick attribute
    const onclickAttr = button.getAttribute('onclick');
    if (onclickAttr) {
        const match = onclickAttr.match(/filterHomework\(this,\s*['"]([^'"]+)['"]\)/);
        if (match) {
            return match[1];
        }
    }
    
    // بررسی data attribute
    if (button.hasAttribute('data-subject')) {
        return button.getAttribute('data-subject');
    }
    
    // بررسی متن دکمه برای تشخیص نوع
    const buttonText = button.textContent.trim();
    
    if (buttonText.includes('همه') || buttonText.includes('✨')) {
        return 'all';
    } else if (buttonText.includes('ریاضی') || buttonText.includes('🔢')) {
        return 'math';
    } else if (buttonText.includes('علوم') || buttonText.includes('🔬')) {
        return 'science';
    } else if (buttonText.includes('فارسی') || buttonText.includes('📖')) {
        return 'persian';
    } else if (buttonText.includes('مطالعات') || buttonText.includes('🗺️')) {
        return 'social';
    } else if (buttonText.includes('هنر') || buttonText.includes('🎨')) {
        return 'art';
    } else if (buttonText.includes('هدیه های آسمانی') || buttonText.includes('📖')) {
    return 'heavenly_gifts';
        
    } else if (buttonText.includes('سایر') || buttonText.includes('📌')) {
        return 'other';
    }
    
    return 'all'; // پیش‌فرض
}

/**
 * فیلتر کردن تکالیف بر اساس درس - نسخه اصلاح شده
 */
function filterHomework(clickedElement, subject) {
    console.log('filterHomework called with:', subject);
    
    // پیدا کردن container تکالیف
    const homeworkContainer = document.getElementById('homeworkContainer');
    if (!homeworkContainer) {
        console.error('Homework container not found');
        return;
    }
    
    // پیدا کردن همه کارت‌های تکالیف
    const items = homeworkContainer.querySelectorAll('.material-card');
    console.log('Found', items.length, 'homework items');
    
    // پیدا کردن همه دکمه‌های فیلتر
    const tabs = document.querySelectorAll('#homework .subject-tabs .tab-btn');
    
    // حذف کلاس active از همه دکمه‌ها
    tabs.forEach(tab => tab.classList.remove('active'));
    
    // اضافه کردن کلاس active به دکمه کلیک شده
    if (clickedElement) {
        clickedElement.classList.add('active');
    }

    let visibleCount = 0;
    
    // فیلتر کردن آیتم‌ها
    items.forEach(item => {
        const itemSubject = item.getAttribute('data-subject') || item.dataset.subject;
        
        console.log('Item subject:', itemSubject, 'Filter:', subject);
        
        if (subject === 'all' || itemSubject === subject) {
            item.style.display = 'flex';
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
            visibleCount++;
        } else {
            item.style.display = 'none';
            item.style.opacity = '0';
            item.style.transform = 'scale(0.8)';
        }
    });
    
    console.log('Showing', visibleCount, 'items for subject:', subject);
    
    // مدیریت پیام خالی بودن
    handleEmptyState(homeworkContainer, visibleCount, subject);
}

/**
 * مدیریت نمایش پیام خالی بودن
 */
function handleEmptyState(container, visibleCount, subject) {
    let emptyMessage = container.querySelector('.empty-state');
    
    if (visibleCount === 0) {
        if (!emptyMessage) {
            emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-state';
            emptyMessage.style.cssText = `
                grid-column: 1 / -1;
                text-align: center;
                padding: 3rem;
                color: #666;
                background: #f9f9f9;
                border-radius: 12px;
                border: 2px dashed #ddd;
            `;
            
            const subjectNames = {
                'all': 'همه تکالیف',
                'math': 'ریاضی',
                'science': 'علوم', 
                'persian': 'فارسی',
                'social': 'مطالعات اجتماعی',
                'art': 'هنر',
               'heavenly_gifts': 'هدیه های آسمانی',
                'other': 'سایر'
            };
            
            const subjectName = subjectNames[subject] || 'این درس';
            
            emptyMessage.innerHTML = `
                <div style="font-size: 4rem; margin-bottom: 1rem;">📚</div>
                <h3 style="color: #333; margin-bottom: 0.5rem;">تکلیفی یافت نشد</h3>
                <p>${subject === 'all' ? 'هیچ تکلیفی موجود نیست' : 'برای ' + subjectName + ' تکلیفی موجود نیست'}</p>
            `;
            
            container.appendChild(emptyMessage);
        }
    } else if (emptyMessage) {
        emptyMessage.remove();
    }
}

/**
 * راه‌اندازی انتخابگرهای تاریخ سریع
 */
function initializeDateSelectors() {
    // پر کردن لیست سال‌ها
    const yearSelect = document.getElementById('year_select');
    if (yearSelect) {
        const currentYear = 1403; // سال جاری شمسی
        for (let i = currentYear; i <= currentYear + 5; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            yearSelect.appendChild(option);
        }
    }
    
    // پر کردن لیست روزها
    const daySelect = document.getElementById('day_select');
    if (daySelect) {
        for (let i = 1; i <= 31; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            daySelect.appendChild(option);
        }
    }
    
    // رویداد تغییر ماه برای بروزرسانی روزها
    const monthSelect = document.getElementById('month_select');
    if (monthSelect) {
        monthSelect.addEventListener('change', function() {
            updateDaysForMonth(this.value, document.getElementById('year_select').value);
        });
    }
    
    // رویداد اعمال تاریخ
    const applyDateBtn = document.getElementById('apply_date_btn');
    if (applyDateBtn) {
        applyDateBtn.addEventListener('click', applySelectedDate);
    }
    
    // رویداد باز کردن تقویم
    const calendarBtn = document.getElementById('calendar_btn');
    if (calendarBtn) {
        calendarBtn.addEventListener('click', function() {
            const dateInput = document.getElementById('due_date_picker');
            if (dateInput) {
                dateInput.focus();
                // اگر datepicker وجود دارد، آن را باز کن
                if (window.datepickerInstance) {
                    window.datepickerInstance.show();
                }
            }
        });
    }
}

/**
 * بروزرسانی روزها بر اساس ماه انتخاب شده
 */
function updateDaysForMonth(month, year) {
    const daySelect = document.getElementById('day_select');
    if (!daySelect) return;
    
    const currentDay = daySelect.value;
    
    // پاک کردن روزهای قبلی
    daySelect.innerHTML = '<option value="">روز</option>';
    
    let maxDays = 31;
    if (month) {
        // ماه‌های 6 روزه
        if (parseInt(month) <= 6) {
            maxDays = 31;
        } 
        // ماه‌های 30 روزه
        else if (parseInt(month) <= 11) {
            maxDays = 30;
        }
        // اسفند
        else {
            maxDays = isLeapYear(year) ? 30 : 29;
        }
    }
    
    // اضافه کردن روزهای جدید
    for (let i = 1; i <= maxDays; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        if (i == currentDay && i <= maxDays) {
            option.selected = true;
        }
        daySelect.appendChild(option);
    }
}

/**
 * بررسی سال کبیسه
 */
function isLeapYear(year) {
    year = parseInt(year);
    return ((year % 33 * 4 + 1) % 128) < 5;
}

/**
 * اعمال تاریخ انتخاب شده
 */
function applySelectedDate() {
    const year = document.getElementById('year_select')?.value;
    const month = document.getElementById('month_select')?.value;
    const day = document.getElementById('day_select')?.value;
    
    if (year && month && day) {
        const formattedDate = `${year}/${month.padStart(2, '0')}/${day.padStart(2, '0')}`;
        const dateInput = document.getElementById('due_date_picker');
        if (dateInput) {
            dateInput.value = formattedDate;
            clearInputError(dateInput);
            
            // نمایش پیام موفقیت کوتاه
            showQuickMessage('تاریخ اعمال شد ✅', 'success');
        }
    } else {
        showQuickMessage('لطفا همه فیلدها را پر کنید', 'error');
    }
}

/**
 * نمایش پیام سریع
 */
function showQuickMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: ${type === 'success' ? '#4CAF50' : '#f44336'};
        color: white;
        padding: 10px 20px;
        border-radius: 8px;
        font-family: Tahoma, sans-serif;
        font-size: 0.9rem;
        z-index: 10001;
        animation: fadeInOut 2s ease;
    `;
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 2000);
}

/**
 * راه‌اندازی تقویم شمسی
 */
function initializePersianDatepicker() {
    const dateInput = document.getElementById('due_date_picker');
    if (dateInput && window.PDatepicker) {
        try {
            window.datepickerInstance = new window.PDatepicker({
                input: dateInput,
                format: 'YYYY/MM/DD',
                autoClose: true,
                initialValue: false,
                observer: true,
                calendar: {
                    persian: {
                        locale: 'fa'
                    }
                },
                toolbox: {
                    calendarSwitch: {
                        enabled: true
                    }
                },
                onSelect: function(unixDate) {
                    console.log('Date selected from picker:', unixDate);
                    // بروزرسانی انتخابگرها بر اساس تاریخ انتخاب شده
                    const selectedDate = new Date(unixDate);
                    updateSelectorsFromDate(dateInput.value);
                }
            });
            console.log('Persian datepicker initialized successfully');
        } catch (error) {
            console.error('Error initializing Persian datepicker:', error);
            dateInput.placeholder = 'مثال: 1403/09/15';
            dateInput.addEventListener('input', validatePersianDate);
        }
    } else {
        console.warn('Persian datepicker library not found');
        if (dateInput) {
            dateInput.placeholder = 'مثال: 1403/09/15';
            dateInput.addEventListener('input', validatePersianDate);
        }
    }
}

/**
 * بروزرسانی انتخابگرها بر اساس تاریخ تایپ شده
 */
function updateSelectorsFromDate(dateString) {
    const dateParts = dateString.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
    if (dateParts) {
        const yearSelect = document.getElementById('year_select');
        const monthSelect = document.getElementById('month_select');
        const daySelect = document.getElementById('day_select');
        
        if (yearSelect) yearSelect.value = dateParts[1];
        if (monthSelect) monthSelect.value = parseInt(dateParts[2]);
        if (daySelect) daySelect.value = parseInt(dateParts[3]);
        
        updateDaysForMonth(parseInt(dateParts[2]), dateParts[1]);
    }
}

/**
 * validation تاریخ شمسی
 */
function validatePersianDate(event) {
    const value = event.target.value;
    const persianDatePattern = /^\d{4}\/\d{1,2}\/\d{1,2}$/;
    
    if (value && !persianDatePattern.test(value)) {
        showInputError(event.target, 'فرمت تاریخ باید به صورت yyyy/mm/dd باشد');
    } else {
        clearInputError(event.target);
        if (value && persianDatePattern.test(value)) {
            updateSelectorsFromDate(value);
        }
    }
}

/**
 * راه‌اندازی فرم آپلود تکلیف
 */
function initializeHomeworkForm() {
    const uploadForm = document.getElementById('uploadHomeworkForm');
    if (!uploadForm) {
        console.log('Upload form not found - user might not be admin');
        return;
    }
    
    uploadForm.addEventListener('submit', handleHomeworkSubmit);
    console.log('Homework upload form initialized');
}

/**
 * مدیریت submit فرم تکلیف
 */
async function handleHomeworkSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const submitBtn = form.querySelector('.submit-btn-pro');
    const originalBtnText = submitBtn.innerHTML;
    
    if (!validateHomeworkForm(form)) {
        return;
    }
    
    setButtonLoading(submitBtn, true);
    
    try {
        const formData = new FormData(form);
        
        console.log('Submitting homework with data:');
        for (let [key, value] of formData.entries()) {
            console.log(key, ':', value);
        }
        
        const response = await fetch('ajax/upload-homework.php', {
            method: 'POST',
            body: formData
        });
        
        console.log('Response status:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Server response:', result);
        
        if (result.success) {
            showSuccessMessage('تکلیف با موفقیت ثبت شد! 🎉');
            form.reset();
            
            // ریست کردن انتخابگرها
            document.getElementById('year_select').value = '';
            document.getElementById('month_select').value = '';
            document.getElementById('day_select').value = '';
            
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            throw new Error(result.message || 'خطای نامشخص رخ داد');
        }
        
    } catch (error) {
        console.error('Upload error:', error);
        
        let errorMessage = 'خطا در ارسال تکلیف: ';
        if (error.message.includes('Failed to fetch')) {
            errorMessage += 'مشکل در اتصال به سرور. لطفا اتصال اینترنت خود را بررسی کنید.';
        } else {
            errorMessage += error.message;
        }
        
        showErrorMessage(errorMessage);
        
    } finally {
        setButtonLoading(submitBtn, false, originalBtnText);
    }
}

/**
 * validation فرم تکلیف
 */
function validateHomeworkForm(form) {
    const title = form.querySelector('#title');
    const subject = form.querySelector('#subject');
    const dueDate = form.querySelector('#due_date_picker');
    
    let isValid = true;
    
    if (!title?.value.trim()) {
        showInputError(title, 'عنوان تکلیف الزامی است');
        isValid = false;
    } else {
        clearInputError(title);
    }
    
    if (!subject?.value) {
        showInputError(subject, 'انتخاب درس الزامی است');
        isValid = false;
    } else {
        clearInputError(subject);
    }
    
    if (!dueDate?.value.trim()) {
        showInputError(dueDate, 'تاریخ تحویل الزامی است');
        isValid = false;
    } else {
        clearInputError(dueDate);
    }
    
    return isValid;
}

/**
 * تغییر وضعیت دکمه به loading
 */
function setButtonLoading(button, isLoading, originalText = '') {
    if (!button) return;
    
    if (isLoading) {
        button.disabled = true;
        button.innerHTML = '<span><i class="fa fa-spinner fa-spin"></i> در حال ارسال...</span>';
    } else {
        button.disabled = false;
        button.innerHTML = originalText || '<span><i class="fa fa-upload"></i> ثبت و ارسال تکلیف</span>';
    }
}

/**
 * نمایش پیام موفقیت
 */
function showSuccessMessage(message) {
    removeExistingMessages();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.style.animation = 'slideInRight 0.3s ease';
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 3000);
}

/**
 * نمایش پیام خطا
 */
function showErrorMessage(message) {
    removeExistingMessages();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.style.animation = 'slideInRight 0.3s ease';
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

/**
 * حذف پیام‌های موجود
 */
function removeExistingMessages() {
    const existingMessages = document.querySelectorAll('.success-message, .error-message');
    existingMessages.forEach(msg => msg.remove());
}

/**
 * نمایش خطای input
 */
function showInputError(input, message) {
    if (!input) return;
    
    clearInputError(input);
    
    input.style.borderColor = '#f44336';
    input.style.boxShadow = '0 0 5px rgba(244, 67, 54, 0.5)';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'input-error';
    errorDiv.textContent = message;
    
    input.parentNode.appendChild(errorDiv);
}

/**
 * پاک کردن خطای input
 */
function clearInputError(input) {
    if (!input) return;
    
    input.style.borderColor = '';
    input.style.boxShadow = '';
    
    const existingError = input.parentNode.querySelector('.input-error');
    if (existingError) {
        existingError.remove();
    }
}

/**
 * راه‌اندازی validation فرم
 */
function initializeFormValidation() {
    const form = document.getElementById('uploadHomeworkForm');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input[required], select[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                showInputError(this, 'این فیلد الزامی است');
            } else {
                clearInputError(this);
            }
        });
        
        input.addEventListener('input', function() {
            clearInputError(this);
        });
    });
}

/**
 * راه‌اندازی فیلترینگ تکالیف
 */
function initializeHomeworkFiltering() {
    console.log('Initializing homework filtering');
}

/**
 * حذف تکلیف
 */
async function deleteHomework(homeworkId) {
    if (!confirm('آیا از حذف این تکلیف مطمئن هستید؟')) {
        return;
    }
    
    try {
        const response = await fetch('ajax/delete-homework.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ homework_id: homeworkId })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            showSuccessMessage('تکلیف با موفقیت حذف شد');
            
            const cards = document.querySelectorAll('.material-card');
            cards.forEach(card => {
                const deleteButton = card.querySelector(`button[onclick*="deleteHomework(${homeworkId})"]`);
                if (deleteButton) {
                    card.style.transition = 'opacity 0.5s, transform 0.5s';
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.9)';
                    setTimeout(() => {
                        if (card.parentNode) {
                            card.remove();
                        }
                    }, 500);
                }
            });
        } else {
            throw new Error(result.message || 'خطا در حذف تکلیف');
        }
    } catch (error) {
        console.error('Delete error:', error);
        showErrorMessage('خطا در حذف تکلیف: ' + error.message);
    }
}

// Export کردن توابع برای استفاده global
window.filterHomework = filterHomework;
window.deleteHomework = deleteHomework;


document.head.appendChild(style);

console.log('Homework JavaScript fully loaded with enhanced filtering');
</script>