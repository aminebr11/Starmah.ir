<?php
session_start();
// فرض شده که config.php و functions.php در روت اصلی هستند
require_once '../config.php';
require_once '../functions.php';

// بررسی وجود سشن و دسترسی ادمین
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// کوئری درست با جدول student_xp
$stmt = $conn->prepare("
    SELECT u.*, 
           IFNULL(sx.total_xp, 0) as total_score,
           IFNULL(sx.level, 1) as student_level
    FROM users u 
    LEFT JOIN student_xp sx ON u.id = sx.student_id 
    WHERE u.user_type = 'student' 
    ORDER BY sx.total_xp DESC, u.first_name ASC
");
$stmt->execute();
$students = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎓 مدیریت دانش‌آموزان</title>
    
    <!-- فونت ایرانی -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    
    <!-- کتابخانه‌های مورد نیاز -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>
    
    <!-- کتابخانه تبدیل تاریخ شمسی -->
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment-jalaali@0.9.6/index.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Vazirmatn', Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .main-container {
            max-width: 1400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 25px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
            backdrop-filter: blur(10px);
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-title {
            color: #2c3e50;
            font-size: 2.2rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            background: linear-gradient(45deg, #3498db, #9b59b6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .btn {
            border: none;
            padding: 12px 24px;
            border-radius: 50px;
            cursor: pointer;
            font-family: 'Vazirmatn', sans-serif;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        .btn-back {
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: white;
        }

        .btn-add {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
        }

        .btn-view {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        .btn-edit {
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: white;
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        .btn-delete {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        .btn-print {
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
            color: white;
            margin-top: 20px;
        }

        /* جدول دسکتاپ */
        .desktop-table {
            display: block;
            overflow-x: auto;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }

        .students-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: white;
            border-radius: 20px;
            overflow: hidden;
        }

        .students-table thead tr {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .students-table th {
            padding: 20px 15px;
            text-align: center;
            font-weight: 700;
            font-size: 1.1rem;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }

        .students-table tbody tr {
            transition: all 0.3s ease;
        }

        .students-table tbody tr:nth-child(odd) {
            background: #f8f9fa;
        }

        .students-table tbody tr:nth-child(even) {
            background: white;
        }

        .students-table tbody tr:hover {
            background: linear-gradient(135deg, #e3f2fd, #f3e5f5);
            transform: scale(1.01);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .students-table td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }

        .rank-cell {
            font-size: 1.3rem;
            font-weight: bold;
            color: #2c3e50;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .status-active {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
        }

        .status-inactive {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
        }

        /* کارت‌های موبایل */
        .mobile-cards {
            display: none;
            gap: 20px;
        }

        .student-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 3px solid transparent;
            background-clip: padding-box;
            position: relative;
            overflow: hidden;
        }

        .student-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4, #feca57);
            background-size: 300% 100%;
            animation: rainbow 3s ease infinite;
        }

        @keyframes rainbow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .student-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-rank {
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
        }

        .card-name {
            font-size: 1.3rem;
            font-weight: 700;
            color: #2c3e50;
            text-align: center;
            margin-bottom: 15px;
        }

        .card-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .info-item {
            text-align: center;
            padding: 15px;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 15px;
            border: 2px solid #e9ecef;
        }

        .info-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 5px;
        }

        .info-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: #2c3e50;
        }

        .card-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }

        /* مودال‌های کودک‌پسند */
        .modal {
            display: none;
            position: fixed;
            z-index: 99999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 3% auto;
            padding: 0;
            border-radius: 25px;
            width: 95%;
            max-width: 800px;
            max-height: 90vh;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: modalSlideIn 0.3s ease-out;
            position: relative;
        }

        @keyframes modalSlideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 25px 30px;
            position: relative;
            overflow: hidden;
        }

        .modal-header::before {
            content: '🌟';
            position: absolute;
            top: 10px;
            right: 30px;
            font-size: 2rem;
            animation: twinkle 2s ease-in-out infinite;
        }

        .modal-header::after {
            content: '✨';
            position: absolute;
            bottom: 10px;
            left: 30px;
            font-size: 1.5rem;
            animation: twinkle 2s ease-in-out infinite 1s;
        }

        @keyframes twinkle {
            0%, 100% { opacity: 0.5; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.2); }
        }

        .modal-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .modal-close {
            position: absolute;
            top: 15px;
            left: 20px;
            color: white;
            font-size: 2rem;
            font-weight: bold;
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 30px;
            overflow-y: auto;
            max-height: calc(90vh - 200px);
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-weight: 600;
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            font-size: 1rem;
            font-family: 'Vazirmatn', sans-serif;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .modal-footer {
            padding: 20px 30px;
            border-top: 1px solid #e9ecef;
            text-align: center;
            background: #f8f9fa;
        }

        .student-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .detail-item {
            padding: 15px;
            background: linear-gradient(135deg, #f8f9fa, #ffffff);
            border-radius: 15px;
            border: 2px solid #e9ecef;
            text-align: right;
        }

        .detail-label {
            font-weight: 600;
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 5px;
        }

        .detail-value {
            font-size: 1.1rem;
            color: #2c3e50;
            font-weight: 500;
        }

        /* لودینگ */
        .loading-modal {
            display: none;
            position: fixed;
            z-index: 100000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(5px);
        }

        .loading-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .no-students {
            text-align: center;
            padding: 60px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .no-students-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            display: block;
        }

        .no-students-text {
            color: #6c757d;
            font-size: 1.3rem;
            font-weight: 500;
        }

        /* ریسپانسیو */
        @media (max-width: 768px) {
            .main-container {
                padding: 20px;
                margin: 10px;
                border-radius: 20px;
            }

            .page-title {
                font-size: 1.8rem;
                text-align: center;
            }

            .header-section {
                flex-direction: column;
                text-align: center;
            }

            .desktop-table {
                display: none;
            }

            .mobile-cards {
                display: flex;
                flex-direction: column;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .student-details {
                grid-template-columns: 1fr;
            }

            .modal-content {
                margin: 5% auto;
                width: 98%;
            }

            .modal-body {
                padding: 20px;
            }

            .btn {
                padding: 10px 20px;
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .card-info {
                grid-template-columns: 1fr;
            }

            .card-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
        /* استایل برای فیلدهای اجباری */
        .form-label span {
            color: #e74c3c;
            font-weight: bold;
            margin-right: 3px;
        }

        .form-control:focus:invalid {
            border-color: #e74c3c;
            box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.1);
        }

        .form-control:focus:valid {
            border-color: #27ae60;
            box-shadow: 0 0 0 3px rgba(39, 174, 96, 0.1);
        }

        /* انیمیشن برای مودال */
        #addStudentModal.show {
            display: block;
            animation: fadeIn 0.3s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- هدر صفحه -->
        <div class="header-section">
            <h1 class="page-title">🎓 مدیریت دانش‌آموزان</h1>
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <a href="../index.php" class="btn btn-back">
                    🏠 بازگشت به پنل مدیریت
                </a>
            <button onclick="openAddStudentModal()" class="btn btn-add">
    ➕ افزودن دانش‌آموز جدید
</button>
            
            </div>
        </div>

        <?php if ($students): ?>
            <!-- نمایش جدولی برای دسکتاپ -->
            <div class="desktop-table">
                <table class="students-table">
                    <thead>
                        <tr>
                            <th>🏆 رتبه</th>
                            <th>👤 نام و نام خانوادگی</th>
                            <th>🆔 کد ملی</th>
                            <th>⭐ امتیاز کل</th>
                            <th>📊 سطح</th>
                            <th>🔄 وضعیت</th>
                            <th>⚙️ عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $rank = 1;
                        foreach($students as $student): 
                        ?>
                        <tr>
                            <td class="rank-cell">
                                <?php 
                                if ($rank == 1) echo '<span style="font-size: 1.8rem;">🥇</span>';
                                elseif ($rank == 2) echo '<span style="font-size: 1.8rem;">🥈</span>';
                                elseif ($rank == 3) echo '<span style="font-size: 1.8rem;">🥉</span>';
                                else echo $rank;
                                ?>
                            </td>
                            <td style="text-align: right; font-weight: 600; color: #2c3e50;">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                            </td>
                            <td style="color: #6c757d; font-weight: 500;">
                                <?php echo htmlspecialchars($student['national_id']); ?>
                            </td>
                            <td style="color: #27ae60; font-weight: bold; font-size: 1.1rem;">
                                <?php echo $student['total_score'] ?? 0; ?> XP
                            </td>
                            <td style="color: #f39c12; font-weight: bold;">
                                سطح <?php echo $student['student_level']; ?> ⭐
                            </td>
                            <td>
                                <span class="status-badge <?php echo $student['is_active'] ? 'status-active' : 'status-inactive'; ?>"
                                      onclick="toggleStudentStatus(<?php echo $student['id']; ?>, <?php echo $student['is_active'] ? 1 : 0; ?>)">
                                    <?php echo $student['is_active'] ? '✅ فعال' : '❌ غیرفعال'; ?>
                                </span>
                            </td>
                            <td>
                                <button onclick="viewStudent(<?php echo $student['id']; ?>)" class="btn btn-view">
                                    👁️ مشاهده
                                </button>
                                <button onclick="loadStudentForEdit(<?php echo $student['id']; ?>)" class="btn btn-edit">
                                    ✏️ ویرایش
                                </button>
                                <button onclick="deleteStudent(<?php echo $student['id']; ?>)" class="btn btn-delete">
                                    🗑️ حذف
                                </button>
                            </td>
                        </tr>
                        <?php 
                        $rank++;
                        endforeach; 
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- نمایش کارتی برای موبایل -->
            <div class="mobile-cards">
                <?php 
                $rank = 1;
                foreach($students as $student): 
                ?>
                <div class="student-card">
                    <div class="card-header">
                        <div class="card-rank">
                            <?php 
                            if ($rank == 1) echo '🥇';
                            elseif ($rank == 2) echo '🥈';
                            elseif ($rank == 3) echo '🥉';
                            else echo "#$rank";
                            ?>
                        </div>
                        <span class="status-badge <?php echo $student['is_active'] ? 'status-active' : 'status-inactive'; ?>"
                              onclick="toggleStudentStatus(<?php echo $student['id']; ?>, <?php echo $student['is_active'] ? 1 : 0; ?>)">
                            <?php echo $student['is_active'] ? '✅ فعال' : '❌ غیرفعال'; ?>
                        </span>
                    </div>
                    
                    <div class="card-name">
                        <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                    </div>
                    
                    <div class="card-info">
                        <div class="info-item">
                            <div class="info-label">🆔 کد ملی</div>
                            <div class="info-value"><?php echo htmlspecialchars($student['national_id']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">⭐ امتیاز</div>
                            <div class="info-value"><?php echo $student['total_score'] ?? 0; ?> XP</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">📊 سطح</div>
                            <div class="info-value">سطح <?php echo $student['student_level']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">📅 تاریخ ثبت</div>
                            <div class="info-value" data-date="<?php echo $student['created_at']; ?>">
                                در حال بارگذاری...
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-actions">
                        <button onclick="viewStudent(<?php echo $student['id']; ?>)" class="btn btn-view">
                            👁️ مشاهده
                        </button>
                        <button onclick="loadStudentForEdit(<?php echo $student['id']; ?>)" class="btn btn-edit">
                            ✏️ ویرایش
                        </button>
                        <button onclick="deleteStudent(<?php echo $student['id']; ?>)" class="btn btn-delete">
                            🗑️ حذف
                        </button>
                    </div>
                </div>
                <?php 
                $rank++;
                endforeach; 
                ?>
            </div>

            <!-- دکمه چاپ -->
            <div style="text-align: center;">
                <button onclick="printStudentsList()" class="btn btn-print">
                    🖨️ چاپ لیست کامل دانش‌آموزان
                </button>
            </div>

        <?php else: ?>
            <div class="no-students">
                <span class="no-students-icon">😔</span>
                <p class="no-students-text">هیچ دانش‌آموزی ثبت نشده است.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- مودال مشاهده دانش‌آموز -->
    <div id="studentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">👤 مشخصات دانش‌آموز</h3>
                <span class="modal-close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div id="studentModalContent" class="student-details">
                    <!-- اطلاعات توسط جاوااسکریپت بارگذاری می‌شود -->
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="printStudentDetails()" class="btn" style="background: linear-gradient(135deg, #6c757d, #5a6268); color: white; margin-left: 10px;">
                    🖨️ چاپ اطلاعات
                </button>
                <button onclick="closeModal()" class="btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71); color: white;">
                    ✅ بستن
                </button>
            </div>
        </div>
    </div>

    <!-- مودال ویرایش دانش‌آموز -->
    <div id="editStudentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">✏️ ویرایش اطلاعات دانش‌آموز</h3>
                <span class="modal-close" onclick="closeEditModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editStudentForm">
                    <input type="hidden" id="editStudentId" name="student_id">
                    
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label class="form-label">👤 نام کاربری:</label>
                            <input type="text" id="editUsername" name="username" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📝 نام:</label>
                            <input type="text" id="editFirstName" name="first_name" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📝 نام خانوادگی:</label>
                            <input type="text" id="editLastName" name="last_name" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">🆔 کد ملی:</label>
                            <input type="text" id="editNationalId" name="national_id" class="form-control" required maxlength="10" minlength="10">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📅 تاریخ تولد:</label>
                            <input type="text" id="editBirthDate" name="birth_date" class="form-control" placeholder="سال/ماه/روز">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">👨 نام پدر:</label>
                            <input type="text" id="editFatherName" name="father_name" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📞 تلفن پدر:</label>
                            <input type="tel" id="editFatherPhone" name="father_phone" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">👩 نام مادر:</label>
                            <input type="text" id="editMotherName" name="mother_name" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📞 تلفن مادر:</label>
                            <input type="tel" id="editMotherPhone" name="mother_phone" class="form-control">
                        </div>
                        
                        <div class="form-group full-width">
                            <label class="form-label">🏠 آدرس:</label>
                            <textarea id="editAddress" name="address" class="form-control" rows="3"></textarea>
                        </div>
                        
                       <div class="form-group">
    <label class="form-label">🔒 رمز عبور جدید (اختیاری):</label>
    <input type="password" id="editPassword" name="password" class="form-control" placeholder="برای تغییر رمز عبور وارد کنید">
</div>
                        
                        <div class="form-group">
                            <label class="form-label">🔄 وضعیت:</label>
                            <select id="editIsActive" name="is_active" class="form-control">
                                <option value="1">✅ فعال</option>
                                <option value="0">❌ غیرفعال</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="submit" form="editStudentForm" class="btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; margin-left: 10px;">
                    💾 ذخیره تغییرات
                </button>
                <button type="button" onclick="closeEditModal()" class="btn" style="background: linear-gradient(135deg, #6c757d, #5a6268); color: white;">
                    ❌ انصراف
                </button>
            </div>
        </div>
    </div>
<!-- مودال افزودن دانش‌آموز جدید -->
    <div id="addStudentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">➕ افزودن دانش‌آموز جدید</h3>
                <span class="modal-close" onclick="closeAddModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="addStudentForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">📝 نام: <span style="color: red;">*</span></label>
                            <input type="text" id="addFirstName" name="first_name" class="form-control" required placeholder="مثال: محمد">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">📝 نام خانوادگی: <span style="color: red;">*</span></label>
                            <input type="text" id="addLastName" name="last_name" class="form-control" required placeholder="مثال: احمدی">
                        </div>
                        
                        <div class="form-group full-width">
                            <label class="form-label">🆔 کد ملی (نام کاربری): <span style="color: red;">*</span></label>
                            <input type="text" id="addNationalId" name="national_id" class="form-control" required maxlength="10" minlength="10" pattern="[0-9]{10}" placeholder="1234567890">
                            <small style="color: #6c757d; display: block; margin-top: 5px;">⚠️ کد ملی 10 رقمی - این کد به عنوان نام کاربری نیز استفاده می‌شود</small>
                        </div>
                        
                        <div class="form-group full-width">
                            <label class="form-label">🔒 رمز عبور: <span style="color: red;">*</span></label>
                            <input type="password" id="addPassword" name="password" class="form-control" required placeholder="رمز عبور دلخواه را وارد کنید">
                            <small style="color: #6c757d; display: block; margin-top: 5px;">💡 حداقل 3 کاراکتر</small>
                        </div>
                    </div>
                    
                    <div style="background: linear-gradient(135deg, #e3f2fd, #f3e5f5); border-radius: 15px; padding: 20px; margin-top: 20px; border: 2px dashed #667eea;">
                        <p style="margin: 0; color: #2c3e50; font-weight: 600; text-align: center;">
                            ℹ️ پس از ثبت‌نام، دانش‌آموز می‌تواند با کد ملی و رمز عبور وارد سیستم شود
                        </p>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="submit" form="addStudentForm" class="btn" style="background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; margin-left: 10px;">
                    ✅ ثبت دانش‌آموز
                </button>
                <button type="button" onclick="closeAddModal()" class="btn" style="background: linear-gradient(135deg, #6c757d, #5a6268); color: white;">
                    ❌ انصراف
                </button>
            </div>
        </div>
    </div>

    <!-- مودال لودینگ -->
    <div id="loadingModal" class="loading-modal">
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <p style="color: #2c3e50; font-weight: 600; font-size: 1.1rem;">🔄 در حال پردازش...</p>
        </div>
    </div>


    <script>
        // تابع تبدیل تاریخ میلادی به شمسی
        function convertToJalali(gregorianDate) {
            if (!gregorianDate || gregorianDate === '0000-00-00' || gregorianDate === '') {
                return 'وارد نشده';
            }
            
            try {
                // اگر moment-jalaali موجود باشد از آن استفاده کنیم
                if (typeof moment !== 'undefined' && moment.loadPersian) {
                    return moment(gregorianDate).format('jYYYY/jMM/jDD');
                }
                
                // در غیر این صورت تبدیل دستی
                const date = new Date(gregorianDate);
                if (isNaN(date.getTime())) {
                    return gregorianDate; // اگر تاریخ نامعتبر بود، همان را برگردان
                }
                
                // تبدیل ساده (تقریبی) به شمسی
                const jYear = date.getFullYear() - 621;
                const jMonth = String(date.getMonth() + 1).padStart(2, '0');
                const jDay = String(date.getDate()).padStart(2, '0');
                
                return `${jYear}/${jMonth}/${jDay}`;
            } catch (e) {
                console.log('خطا در تبدیل تاریخ:', e);
                return gregorianDate;
            }
        }

        // تابع فرمت کردن تاریخ برای نمایش
        function formatDisplayDate(dateStr) {
            if (!dateStr || dateStr === '0000-00-00 00:00:00' || dateStr === '') {
                return 'وارد نشده';
            }
            
            try {
                if (typeof moment !== 'undefined' && moment.loadPersian) {
                    return moment(dateStr).format('jYYYY/jMM/jDD');
                }
                
                // تبدیل دستی
                const date = new Date(dateStr);
                const options = { 
                    year: 'numeric', 
                    month: '2-digit', 
                    day: '2-digit',
                    calendar: 'persian',
                    numberingSystem: 'persian'
                };
                
                // سعی می‌کنیم از Intl.DateTimeFormat استفاده کنیم
                if (typeof Intl !== 'undefined' && Intl.DateTimeFormat) {
                    try {
                        return new Intl.DateTimeFormat('fa-IR', options).format(date);
                    } catch (e) {
                        // اگر خطا داد، به روش دستی ادامه می‌دهیم
                    }
                }
                
                // تبدیل دستی (تقریبی)
                const jYear = date.getFullYear() - 621;
                const jMonth = String(date.getMonth() + 1).padStart(2, '0');
                const jDay = String(date.getDate()).padStart(2, '0');
                
                return `${jYear}/${jMonth}/${jDay}`;
            } catch (e) {
                return dateStr.split(' ')[0]; // فقط قسمت تاریخ را برگردان
            }
        }

        // تابع مسیردهی Ajax
        function getAjaxPath(filename) {
            return '../ajax/' + filename; 
        }

        // مدیریت پاسخ Ajax
        function handleAjaxResponse(response) {
            return response.text().then(text => {
                console.log('Raw response:', text);
                if (!text.trim()) {
                    throw new Error('پاسخ خالی از سرور دریافت شد');
                }
                try {
                    return JSON.parse(text);
                } catch (e) {
                    console.error('JSON Parse Error:', e);
                    console.log('Response text:', text);
                    if (text.includes('<html>') || text.includes('<!DOCTYPE')) {
                        throw new Error('سرور صفحه خطا ارسال کرده است. لطفاً console را بررسی کنید.');
                    }
                    throw new Error('پاسخ سرور نامعتبر است: ' + text.substring(0, 100));
                }
            });
        }

        // نمایش و مخفی کردن لودینگ
        function showLoading() {
            document.getElementById('loadingModal').style.display = 'block';
        }

        function hideLoading() {
            document.getElementById('loadingModal').style.display = 'none';
        }

        // بستن مودال‌ها
        function closeModal() {
            document.getElementById('studentModal').style.display = 'none';
        }

        function closeEditModal() {
            document.getElementById('editStudentModal').style.display = 'none';
            document.getElementById('editStudentForm').reset();
        }

        // تابع تغییر بخش (برای ناوبری صفحه)
        function showSection(sectionId) {
            // این تابع برای ناوبری بین بخش‌های صفحه اصلی استفاده می‌شود
            if (sectionId === 'register') {
                window.location.href = 'register_student.php';
            } else {
                console.log('Navigating to section: ' + sectionId);
            }
        }

        // مشاهده دانش‌آموز
        function viewStudent(studentId) {
            showLoading();
            fetch(getAjaxPath('get_student.php'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ student_id: parseInt(studentId) })
            })
            .then(response => {
                hideLoading();
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                try {
                    const data = JSON.parse(text);
                    if (data.success) {
                        const student = data.student;
                        const content = `
                            <div class="detail-item">
                                <div class="detail-label">📝 نام</div>
                                <div class="detail-value">${student.first_name || 'نامشخص'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">📝 نام خانوادگی</div>
                                <div class="detail-value">${student.last_name || 'نامشخص'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">👤 نام کاربری</div>
                                <div class="detail-value">${student.username || 'نامشخص'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">🆔 کد ملی</div>
                                <div class="detail-value">${student.national_id || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">📅 تاریخ تولد</div>
                                <div class="detail-value">${formatDisplayDate(student.birth_date)}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">👨 نام پدر</div>
                                <div class="detail-value">${student.father_name || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">📞 تلفن پدر</div>
                                <div class="detail-value">${student.father_phone || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">👩 نام مادر</div>
                                <div class="detail-value">${student.mother_name || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">📞 تلفن مادر</div>
                                <div class="detail-value">${student.mother_phone || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item" style="grid-column: 1 / -1;">
                                <div class="detail-label">🏠 آدرس</div>
                                <div class="detail-value">${student.address || 'وارد نشده'}</div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">🔄 وضعیت</div>
                                <div class="detail-value" style="color: ${student.is_active == 1 ? '#27ae60' : '#e74c3c'}; font-weight: bold;">
                                    ${student.is_active == 1 ? '✅ فعال' : '❌ غیرفعال'}
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">📅 تاریخ ثبت نام</div>
                                <div class="detail-value">${formatDisplayDate(student.created_at)}</div>
                            </div>
                        `;
                        document.getElementById('studentModalContent').innerHTML = content;
                        document.getElementById('studentModal').style.display = 'block';
                    } else {
                        alert('خطا در دریافت اطلاعات: ' + (data.message || 'خطای نامشخص'));
                    }
                } catch (e) {
                    console.error('JSON Parse Error:', e);
                    alert('خطا در پردازش پاسخ سرور. لطفاً console را بررسی کنید.');
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Fetch Error:', error);
                alert('خطای اتصال: ' + error.message);
            });
        }

        // بارگذاری اطلاعات دانش‌آموز برای ویرایش
        function loadStudentForEdit(studentId) {
            showLoading();
            fetch(getAjaxPath('get_student.php'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ student_id: parseInt(studentId) })
            })
            .then(response => {
                hideLoading();
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return handleAjaxResponse(response);
            })
            .then(data => {
                console.log('داده‌های دریافت شده از سرور:', data); // برای دیباگ
                
                if (data.success && data.student) {
                    const student = data.student;
                    console.log('اطلاعات دانش‌آموز:', student); // برای دیباگ
                    
                    // پر کردن فیلدهای فرم با بررسی وجود هر فیلد
                    const setFieldValue = (fieldId, value) => {
                        const field = document.getElementById(fieldId);
                        if (field) {
                            field.value = value || '';
                            console.log(`فیلد ${fieldId} تنظیم شد به: ${value || 'خالی'}`);
                        } else {
                            console.error(`فیلد ${fieldId} یافت نشد!`);
                        }
                    };
                    
                    setFieldValue('editStudentId', student.id);
                    setFieldValue('editUsername', student.username);
                    setFieldValue('editFirstName', student.first_name);
                    setFieldValue('editLastName', student.last_name);
                    setFieldValue('editNationalId', student.national_id);
                    
                    // تبدیل تاریخ تولد به فرمت شمسی برای نمایش
                    if (student.birth_date && student.birth_date !== '0000-00-00') {
                        setFieldValue('editBirthDate', convertToJalali(student.birth_date));
                    } else {
                        setFieldValue('editBirthDate', '');
                    }
                    
                    // فیلدهایی که ممکن است در دیتابیس موجود نباشند
                    setFieldValue('editFatherName', student.father_name || student.fatherName || student.father || '');
                    setFieldValue('editFatherPhone', student.father_phone || student.fatherPhone || student.father_tel || '');
                    setFieldValue('editMotherName', student.mother_name || student.motherName || student.mother || '');
                    setFieldValue('editMotherPhone', student.mother_phone || student.motherPhone || student.mother_tel || '');
                    setFieldValue('editAddress', student.address || '');
                    
                    // تنظیم وضعیت
                    setFieldValue('editIsActive', student.is_active == 1 ? '1' : '0');
                    
                    // رمز عبور همیشه خالی
                    setFieldValue('editPassword', '');

                    // نمایش مودال
                    document.getElementById('editStudentModal').style.display = 'block';
                } else {
                    console.error('خطا در دریافت اطلاعات:', data);
                    alert('خطا در دریافت اطلاعات دانش‌آموز برای ویرایش: ' + (data.message || 'خطای نامشخص'));
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Fetch Error:', error);
                alert('خطای اتصال یا دریافت اطلاعات: ' + error.message);
            });
        }

        // چاپ جزئیات دانش‌آموز
        function printStudentDetails() {
            const content = document.getElementById('studentModalContent').innerHTML;
            const printWindow = window.open('', '', 'height=500, width=800');
            printWindow.document.write('<html><head><title>چاپ اطلاعات دانش‌آموز</title>');
            printWindow.document.write('<style>body { font-family: Vazirmatn, Tahoma, sans-serif; direction: rtl; text-align: right; padding: 20px; } .detail-item { display: block !important; margin: 15px 0; padding: 10px; border-bottom: 1px solid #eee; } .detail-label { font-weight: bold; color: #666; font-size: 0.9rem; } .detail-value { font-size: 1.1rem; margin-top: 5px; color: #333; }</style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h2 style="text-align: center; color: #2c3e50; margin-bottom: 30px;">🎓 اطلاعات دانش‌آموز</h2>');
            printWindow.document.write(content);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

        // چاپ لیست دانش‌آموزان
        function printStudentsList() {
            const table = document.querySelector('.students-table');
            if (!table) {
                alert('لیست دانش‌آموزان یافت نشد.');
                return;
            }
            
            const printWindow = window.open('', '', 'height=700, width=1000');
            printWindow.document.write('<html><head><title>لیست دانش‌آموزان</title>');
            printWindow.document.write('<style>');
            printWindow.document.write('body { font-family: Vazirmatn, Tahoma, sans-serif; direction: rtl; text-align: right; padding: 20px; }');
            printWindow.document.write('table { width: 100%; border-collapse: collapse; margin-top: 20px; }');
            printWindow.document.write('th, td { border: 1px solid #ddd; padding: 12px; text-align: center; }');
            printWindow.document.write('th { background-color: #667eea; color: white; font-weight: bold; }');
            printWindow.document.write('tr:nth-child(even) { background-color: #f8f9fa; }');
            printWindow.document.write('h2 { text-align: center; color: #2c3e50; margin-bottom: 30px; }');
            printWindow.document.write('button { display: none; }');
            printWindow.document.write('</style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h2>🎓 لیست کامل دانش‌آموزان</h2>');
            printWindow.document.write(table.outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

        // تغییر وضعیت دانش‌آموز
        function toggleStudentStatus(studentId, currentStatus) {
            const newStatus = currentStatus ? 0 : 1;
            const actionText = newStatus ? "فعال" : "غیرفعال";
            
            if (!confirm(`🤔 آیا از ${actionText} کردن این کاربر مطمئن هستید؟`)) return;

            showLoading();
            
            fetch(getAjaxPath('toggle_student_status.php'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    student_id: parseInt(studentId), 
                    new_status: parseInt(newStatus) 
                })
            })
            .then(response => {
                hideLoading();
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return handleAjaxResponse(response);
            })
            .then(data => {
                if (data.success) {
                    alert('✅ ' + (data.message || 'وضعیت کاربر با موفقیت تغییر کرد.'));
                    location.reload();
                } else {
                    alert('❌ خطا در تغییر وضعیت: ' + (data.message || 'خطای نامشخص'));
                }
            })
            .catch(error => {
                hideLoading();
                alert('❌ خطای اتصال: ' + error.message);
            });
        }

        // حذف دانش‌آموز
        function deleteStudent(studentId) {
            if (!confirm('⚠️ آیا از حذف کامل این دانش‌آموز مطمئن هستید؟ این عمل غیرقابل بازگشت است.')) return;
            
            showLoading();
            fetch(getAjaxPath('delete_student.php'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ student_id: parseInt(studentId) })
            })
            .then(response => {
                hideLoading();
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return handleAjaxResponse(response);
            })
            .then(data => {
                if (data.success) {
                    alert('✅ دانش‌آموز با موفقیت حذف شد.');
                    location.reload();
                } else {
                    alert('❌ خطا در حذف: ' + (data.message || 'خطای نامشخص'));
                }
            })
            .catch(error => {
                hideLoading();
                alert('❌ خطای اتصال: ' + error.message);
            });
        }

        // رویدادهای صفحه
        document.addEventListener('DOMContentLoaded', function() {
            // تنظیم moment-jalaali اگر موجود باشد
            if (typeof moment !== 'undefined' && typeof moment.loadPersian !== 'undefined') {
                moment.loadPersian({usePersianDigits: true, dialect: 'persian-modern'});
            }
            
            // به‌روزرسانی تاریخ‌ها در کارت‌های موبایل
            const dateElements = document.querySelectorAll('[data-date]');
            dateElements.forEach(function(element) {
                const dateValue = element.getAttribute('data-date');
                if (dateValue) {
                    element.textContent = formatDisplayDate(dateValue);
                }
            });
            
            // مدیریت فرم ویرایش
            const editForm = document.getElementById('editStudentForm');
            if (editForm) {
                editForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    showLoading();
                    
                    const formData = new FormData(editForm);
                    const studentData = {};
                    
                    for (let [key, value] of formData.entries()) {
                        studentData[key] = value.trim();
                    }
                    
                    // تبدیل تاریخ شمسی به میلادی اگر وارد شده باشد
                    if (studentData['birth_date']) {
                        try {
                            // اگر تاریخ به فرمت شمسی است، تبدیل کنیم
                            if (studentData['birth_date'].includes('/') && typeof moment !== 'undefined' && moment.loadPersian) {
                                const jalaliDate = moment(studentData['birth_date'], 'jYYYY/jMM/jDD');
                                studentData['birth_date'] = jalaliDate.format('YYYY-MM-DD');
                            }
                        } catch (e) {
                            console.log('خطا در تبدیل تاریخ:', e);
                        }
                    }
                    
                    // حذف رمز عبور خالی
                    if (!studentData['password']) {
                        delete studentData['password'];
                    }
                    
                    console.log('داده‌های ارسالی:', studentData); // برای دیباگ
                    
                    fetch(getAjaxPath('update_student.php'), {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(studentData)
                    })
                    .then(response => {
                        hideLoading();
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return handleAjaxResponse(response);
                    })
                    .then(data => {
                        if (data.success) {
                            alert('✅ اطلاعات دانش‌آموز با موفقیت بروزرسانی شد.');
                            closeEditModal();
                            location.reload();
                        } else {
                            alert('❌ خطا در بروزرسانی: ' + (data.message || 'خطای نامشخص'));
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        alert('❌ خطای اتصال: ' + error.message);
                    });
                });
            }

            // تقویم فارسی برای تاریخ تولد
            if (typeof $.fn.persianDatepicker !== 'undefined') {
                $('#editBirthDate').persianDatepicker({
                    format: 'YYYY/MM/DD',
                    autoClose: true,
                    altField: '#editBirthDate',
                    altFormat: 'YYYY/MM/DD',
                    initialValueType: 'persian'
                });
            }
        });

        // بستن مودال با کلیک خارج از آن
        window.onclick = function(event) {
            const modal = document.getElementById('studentModal');
            const editModal = document.getElementById('editStudentModal');
            const addModal = document.getElementById('addStudentModal');
            
            if (event.target == modal) {
                closeModal();
            }
            if (event.target == editModal) {
                closeEditModal();
            }
            if (event.target == addModal) {
                closeAddModal();
            }
        }
        // باز کردن مودال افزودن دانش‌آموز
        function openAddStudentModal() {
            document.getElementById('addStudentModal').style.display = 'block';
            document.getElementById('addStudentForm').reset();
        }

        // بستن مودال افزودن
        function closeAddModal() {
            document.getElementById('addStudentModal').style.display = 'none';
            document.getElementById('addStudentForm').reset();
        }

        // مدیریت فرم افزودن دانش‌آموز
        document.getElementById('addStudentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const studentData = {};
            
            for (let [key, value] of formData.entries()) {
                studentData[key] = value.trim();
            }
            
            // اعتبارسنجی کد ملی
            if (studentData.national_id.length !== 10 || !/^\d{10}$/.test(studentData.national_id)) {
                alert('❌ کد ملی باید دقیقاً 10 رقم باشد');
                return;
            }
            
            // اعتبارسنجی رمز عبور
            if (studentData.password.length < 3) {
                alert('❌ رمز عبور باید حداقل 3 کاراکتر باشد');
                return;
            }
            
            showLoading();
            
            fetch(getAjaxPath('add_student.php'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(studentData)
            })
            .then(response => {
                hideLoading();
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return handleAjaxResponse(response);
            })
            .then(data => {
                if (data.success) {
                    alert('✅ ' + data.message);
                    closeAddModal();
                    location.reload();
                } else {
                    alert('❌ خطا: ' + (data.message || 'خطای نامشخص'));
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Fetch Error:', error);
                alert('❌ خطای اتصال: ' + error.message);
            });
        });
    </script>
</body>
</html>