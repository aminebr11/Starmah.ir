<?php
session_start();
require_once 'config.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    header('HTTP/1.1 403 Forbidden');
    exit('دسترسی غیرمجاز');
}

// بارگیری TCPDF
require_once('libs/tcpdf/tcpdf.php');

$studentId = $_SESSION['user_id'];

// تابع تبدیل تاریخ میلادی به شمسی
function toJalali($timestamp) {
    if (!$timestamp) return 'نامشخص';
    
    $date = new DateTime($timestamp);
    $year = (int)$date->format('Y');
    $month = (int)$date->format('m');
    $day = (int)$date->format('d');
    $hour = $date->format('H');
    $minute = $date->format('i');
    
    $jYear = $year - 621;
    $jMonth = $month;
    $jDay = $day;
    
    if ($month > 3) {
        $jMonth = $month - 3;
    } else {
        $jMonth = $month + 9;
        $jYear--;
    }
    
    $monthNames = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];
    
    return "$jDay {$monthNames[$jMonth]} $jYear - $hour:$minute";
}

try {
    // دریافت اطلاعات دانش‌آموز
    $studentStmt = $conn->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.national_id,
            u.created_at as registration_date,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    
    $studentStmt->execute([$studentId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        exit('اطلاعات دانش‌آموز یافت نشد');
    }
    
    // محاسبه رنک کلی
    $rankStmt = $conn->prepare("
        SELECT COUNT(*) + 1 as student_rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student' AND sx.total_xp > ?
    ");
    $rankStmt->execute([$student['total_xp']]);
    $globalRank = $rankStmt->fetchColumn() ?: 1;
    
    // محاسبه رنک در کلاس
    $classRankStmt = $conn->prepare("
        SELECT COUNT(*) + 1 as class_rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student' AND sx.total_xp > ?
    ");
    $classRankStmt->execute([$student['total_xp']]);
    $classRank = $classRankStmt->fetchColumn() ?: 1;
    
    // تعداد کل دانش‌آموزان
    $totalStudentsStmt = $conn->query("SELECT COUNT(*) FROM users WHERE user_type = 'student'");
    $totalStudents = $totalStudentsStmt->fetchColumn();
    
    // تاریخچه امتیازات XP
    $xpHistoryStmt = $conn->prepare("
        SELECT 
            h.subject,
            h.amount,
            h.reason,
            h.created_at,
            u_admin.first_name as admin_name
        FROM xp_history h
        LEFT JOIN users u_admin ON h.admin_id = u_admin.id
        WHERE h.student_id = ?
        ORDER BY h.created_at DESC
        LIMIT 30
    ");
    $xpHistoryStmt->execute([$studentId]);
    $xpHistory = $xpHistoryStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تاریخچه بازی‌ها
    $gamesStmt = $conn->prepare("
        SELECT 
            g.title as game_title,
            g.subject,
            gr.score,
            gr.accuracy,
            gr.time_spent,
            gr.completed_at
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        ORDER BY gr.completed_at DESC
        LIMIT 20
    ");
    $gamesStmt->execute([$studentId]);
    $gameHistory = $gamesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // آمار بازی‌ها
    $statsStmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_games,
            AVG(score) as avg_score,
            MAX(score) as best_score,
            AVG(accuracy) as avg_accuracy,
            SUM(time_spent) as total_time
        FROM game_results
        WHERE student_id = ?
    ");
    $statsStmt->execute([$studentId]);
    $gameStats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    exit('خطا در دریافت اطلاعات: ' . $e->getMessage());
}

// تنظیمات PDF
class StudentPDF extends TCPDF {
    public function Header() {
        // لوگو و عنوان
        $this->SetFont('dejavusans', 'B', 16);
        $this->SetTextColor(52, 73, 94);
        $this->Cell(0, 15, 'گزارش پیشرفت تحصیلی', 0, 1, 'C');
        $this->SetFont('dejavusans', '', 10);
        $this->SetTextColor(127, 140, 141);
        $this->Cell(0, 10, 'سیستم مدیریت یادگیری', 0, 1, 'C');
        $this->Ln(5);
    }
    
    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('dejavusans', 'I', 8);
        $this->SetTextColor(149, 165, 166);
        $this->Cell(0, 10, 'صفحه ' . $this->getAliasNumPage() . ' از ' . $this->getAliasNbPages(), 0, 0, 'C');
    }
}

// ایجاد PDF
$pdf = new StudentPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// تنظیمات اصلی
$pdf->SetCreator('سیستم مدیریت یادگیری');
$pdf->SetAuthor('سیستم آموزشی');
$pdf->SetTitle('گزارش پیشرفت - ' . $student['first_name'] . ' ' . $student['last_name']);
$pdf->SetSubject('گزارش تحصیلی');
$pdf->SetKeywords('گزارش, دانش‌آموز, پیشرفت, تحصیل');

// تنظیمات صفحه
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(15, 30, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(10);
$pdf->SetAutoPageBreak(TRUE, 25);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// اضافه کردن صفحه
$pdf->AddPage();

// محتوای PDF
$html = '
<style>
    body { font-family: dejavusans; direction: rtl; }
    .header-box { 
        background-color: #3498db; 
        color: white; 
        padding: 15px; 
        text-align: center; 
        border-radius: 8px;
        margin-bottom: 20px;
    }
    .info-table { 
        width: 100%; 
        border-collapse: collapse; 
        margin: 15px 0;
        border: 2px solid #34495e;
    }
    .info-table th { 
        background-color: #34495e; 
        color: white; 
        padding: 10px; 
        text-align: center;
        font-weight: bold;
    }
    .info-table td { 
        padding: 8px; 
        border: 1px solid #bdc3c7; 
        text-align: center;
    }
    .highlight { 
        background-color: #f1c40f; 
        font-weight: bold; 
        color: #2c3e50;
    }
    .success { 
        background-color: #2ecc71; 
        color: white; 
        font-weight: bold;
    }
    .info { 
        background-color: #3498db; 
        color: white;
    }
    .section-title {
        background-color: #e74c3c;
        color: white;
        padding: 8px;
        text-align: center;
        font-weight: bold;
        margin: 15px 0 5px 0;
    }
    .rank-box {
        background-color: #ecf0f1;
        border: 2px solid #95a5a6;
        padding: 10px;
        margin: 10px 0;
        text-align: center;
    }
    .xp-positive { color: #27ae60; font-weight: bold; }
    .xp-negative { color: #e74c3c; font-weight: bold; }
</style>

<div class="header-box">
    <h2>گزارش جامع پیشرفت تحصیلی</h2>
    <h3>' . $student['first_name'] . ' ' . $student['last_name'] . '</h3>
    <p>تاریخ تولید: ' . toJalali(date('Y-m-d H:i:s')) . '</p>
</div>

<div class="rank-box">
    <h3>🏆 رتبه‌بندی و آمار کلی</h3>
    <table style="width: 100%; text-align: center;">
        <tr>
            <td><strong>رنک کلی:</strong> ' . $globalRank . ' از ' . $totalStudents . '</td>
            <td><strong>رنک در کلاس:</strong> ' . $classRank . '</td>
        </tr>
        <tr>
            <td><strong>سطح فعلی:</strong> ' . $student['level'] . '</td>
            <td><strong>کل امتیاز XP:</strong> ' . number_format($student['total_xp']) . '</td>
        </tr>
    </table>
</div>

<div class="section-title">📋 اطلاعات شخصی</div>
<table class="info-table">
    <tr>
        <th style="width: 25%;">نام و نام خانوادگی</th>
        <td style="width: 25%;">' . $student['first_name'] . ' ' . $student['last_name'] . '</td>
        <th style="width: 25%;">کد ملی</th>
        <td style="width: 25%;">' . $student['national_id'] . '</td>
    </tr>
    <tr>
        <th>تاریخ عضویت</th>
        <td>' . toJalali($student['registration_date']) . '</td>
        <th>آخرین فعالیت</th>
        <td>' . ($student['updated_at'] ? toJalali($student['updated_at']) : 'هرگز') . '</td>
    </tr>
</table>

<div class="section-title">📊 آمار عملکرد</div>
<table class="info-table">
    <tr>
        <th>تعداد بازی انجام شده</th>
        <td>' . ($gameStats['total_games'] ?: 0) . '</td>
        <th>میانگین امتیاز</th>
        <td class="highlight">' . ($gameStats['avg_score'] ? round($gameStats['avg_score']) : 0) . '</td>
    </tr>
    <tr>
        <th>بهترین امتیاز</th>
        <td class="success">' . ($gameStats['best_score'] ?: 0) . '</td>
        <th>میانگین دقت</th>
        <td class="info">' . ($gameStats['avg_accuracy'] ? round($gameStats['avg_accuracy']) . '%' : '0%') . '</td>
    </tr>
</table>

<div class="section-title">📚 امتیازات موضوعی</div>
<table class="info-table">
    <tr>
        <th>موضوع درسی</th>
        <th>امتیاز XP</th>
        <th>درصد از کل</th>
        <th>ارزیابی</th>
    </tr>';

$subjects = [
    'math' => ['name' => '🔢 ریاضی', 'xp' => $student['math_xp']],
    'science' => ['name' => '🔬 علوم', 'xp' => $student['science_xp']],
    'persian' => ['name' => '📖 فارسی', 'xp' => $student['persian_xp']],
    'social' => ['name' => '🌍 اجتماعی', 'xp' => $student['social_xp']],
    'religion' => ['name' => '📿 دینی', 'xp' => $student['religion_xp']]
];

foreach ($subjects as $subject) {
    $percentage = $student['total_xp'] > 0 ? round(($subject['xp'] / $student['total_xp']) * 100, 1) : 0;
    $evaluation = $percentage >= 25 ? 'عالی' : ($percentage >= 20 ? 'خوب' : ($percentage >= 15 ? 'متوسط' : 'ضعیف'));
    
    $html .= '
    <tr>
        <td>' . $subject['name'] . '</td>
        <td class="highlight">' . number_format($subject['xp']) . '</td>
        <td>' . $percentage . '%</td>
        <td><strong>' . $evaluation . '</strong></td>
    </tr>';
}

$html .= '</table>';

// تاریخچه امتیازات XP
if (!empty($xpHistory)) {
    $html .= '
    <div class="section-title">💎 تاریخچه امتیازات XP (30 مورد اخیر)</div>
    <table class="info-table">
        <tr>
            <th style="width: 20%;">تاریخ</th>
            <th style="width: 20%;">موضوع</th>
            <th style="width: 15%;">تغییر</th>
            <th style="width: 30%;">دلیل</th>
            <th style="width: 15%;">مسئول</th>
        </tr>';
    
    foreach (array_slice($xpHistory, 0, 15) as $history) {
        $subjectNames = [
            'total' => 'کل',
            'math' => 'ریاضی',
            'science' => 'علوم',
            'persian' => 'فارسی',
            'social' => 'اجتماعی',
            'religion' => 'دینی',
            'reset' => 'ریست'
        ];
        $subjectName = $subjectNames[$history['subject']] ?? $history['subject'];
        $changeText = $history['amount'] > 0 ? '+' . $history['amount'] : $history['amount'];
        $changeClass = $history['amount'] > 0 ? 'xp-positive' : 'xp-negative';
        
        $html .= '
        <tr>
            <td style="font-size: 9px;">' . toJalali($history['created_at']) . '</td>
            <td>' . $subjectName . '</td>
            <td class="' . $changeClass . '">' . $changeText . '</td>
            <td style="font-size: 9px;">' . htmlspecialchars(mb_substr($history['reason'] ?: 'بدون دلیل', 0, 25)) . '</td>
            <td style="font-size: 9px;">' . ($history['admin_name'] ?: 'سیستم') . '</td>
        </tr>';
    }
    
    $html .= '</table>';
}

// تاریخچه بازی‌ها
if (!empty($gameHistory)) {
    $html .= '
    <div class="section-title">🎮 تاریخچه بازی‌ها (20 مورد اخیر)</div>
    <table class="info-table">
        <tr>
            <th style="width: 15%;">تاریخ</th>
            <th style="width: 25%;">نام بازی</th>
            <th style="width: 20%;">موضوع</th>
            <th style="width: 15%;">امتیاز</th>
            <th style="width: 15%;">دقت</th>
            <th style="width: 10%;">زمان</th>
        </tr>';
    
    foreach (array_slice($gameHistory, 0, 15) as $game) {
        $subjectNames = [
            'math' => 'ریاضی',
            'science' => 'علوم',
            'persian' => 'فارسی',
            'social' => 'اجتماعی',
            'religion' => 'دینی'
        ];
        $subjectName = $subjectNames[$game['subject']] ?? $game['subject'];
        $scoreClass = $game['score'] >= 80 ? 'success' : ($game['score'] >= 60 ? 'info' : '');
        
        $html .= '
        <tr>
            <td style="font-size: 8px;">' . toJalali($game['completed_at']) . '</td>
            <td style="font-size: 9px;">' . htmlspecialchars(mb_substr($game['game_title'], 0, 20)) . '</td>
            <td>' . $subjectName . '</td>
            <td class="' . $scoreClass . '">' . $game['score'] . '</td>
            <td>' . round($game['accuracy']) . '%</td>
            <td>' . round($game['time_spent']) . 's</td>
        </tr>';
    }
    
    $html .= '</table>';
}

// اطلاعات نهایی
$html .= '
<div style="margin-top: 30px; padding: 15px; background-color: #ecf0f1; border: 1px solid #bdc3c7;">
    <h4 style="text-align: center; color: #2c3e50;">📊 خلاصه گزارش</h4>
    <table style="width: 100%; text-align: center;">
        <tr>
            <td><strong>تولید شده در:</strong> ' . toJalali(date('Y-m-d H:i:s')) . '</td>
            <td><strong>تعداد رکوردها:</strong> ' . (count($gameHistory) + count($xpHistory)) . '</td>
        </tr>
        <tr>
            <td colspan="2" style="padding-top: 10px; font-style: italic; color: #7f8c8d;">
                این گزارش توسط سیستم مدیریت یادگیری تولید شده است
            </td>
        </tr>
    </table>
</div>';

// نوشتن HTML در PDF
$pdf->writeHTML($html, true, false, true, false, '');

// نام فایل
$filename = 'گزارش-' . $student['first_name'] . '-' . $student['last_name'] . '-' . date('Y-m-d') . '.pdf';

// خروجی PDF
$pdf->Output($filename, 'D');

exit();
?>