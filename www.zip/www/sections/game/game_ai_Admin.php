<?php
/* =============================================================
 * Working Game Creator - بازی‌ساز کاربردی
 * نسخه تست شده و کاربردی
 * ============================================================= */

// Start session
if (session_status() === PHP_SESSION_NONE) { @session_start(); }

// Check user access
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'admin') {
    header('Location: ../../index.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Fixed configurations
$ANTHROPIC_API_KEY = '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';
$ANTHROPIC_MODEL = 'claude-3-haiku-20240307';

// Database connection
try {
    $db = new PDO("mysql:host=localhost:3306;dbname=qwaepiuv_starmah_db;charset=utf8mb4", 
                  'qwaepiuv_aminebr', 'Test12345!@#', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('خطا در اتصال به دیتابیس: ' . $e->getMessage());
}

// Helper function
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// Simple AI call function
function callAnthropicAPI($prompt) {
    global $ANTHROPIC_API_KEY, $ANTHROPIC_MODEL;
    
    $data = [
        'model' => $ANTHROPIC_MODEL,
        'max_tokens' => 2000,
        'messages' => [['role' => 'user', 'content' => $prompt]]
    ];
    
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-key: ' . $ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01'
        ],
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($result === false || $httpCode !== 200) {
        return false;
    }
    
    $decoded = json_decode($result, true);
    return $decoded['content'][0]['text'] ?? false;
}

// Variables
$step = $_POST['step'] ?? $_GET['step'] ?? 'form';
$message = '';
$error = '';
$debug = isset($_GET['debug']);

// Debug function
function debugMsg($msg) {
    global $debug;
    if ($debug) {
        echo "<div style='background: #ffffcc; padding: 10px; margin: 5px 0; border: 1px solid #ccc; border-radius: 5px;'>";
        echo "<strong>DEBUG:</strong> " . htmlspecialchars($msg);
        echo "</div>";
    }
}

// Step 1: Generate Ideas
if (isset($_POST['generate_ideas'])) {
    debugMsg("Generate ideas form submitted");
    
    $lesson = trim($_POST['lesson'] ?? '');
    $topic = trim($_POST['topic'] ?? '');
    $grade = trim($_POST['grade'] ?? '');
    $goal = trim($_POST['goal'] ?? '');
    $gameType = trim($_POST['game_type'] ?? '');
    $style = trim($_POST['style'] ?? '');
    $interaction = trim($_POST['interaction'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $difficulty = trim($_POST['difficulty'] ?? '');
    $features = $_POST['features'] ?? [];
    
    debugMsg("Form data - Lesson: $lesson, Topic: $topic, Grade: $grade");
    
    if (empty($lesson) || empty($topic) || empty($grade) || empty($goal)) {
        $error = 'لطفاً فیلدهای الزامی (*) را پر کنید';
        $step = 'form';
        debugMsg("Validation failed: empty required fields");
    } else {
        debugMsg("Calling AI API...");
        
        $featuresText = !empty($features) ? implode(', ', $features) : 'ساده';
        
        $prompt = "شما یک متخصص طراحی بازی‌های آموزشی برای کودکان هستید. 

مشخصات درخواست:
- درس: $lesson
- موضوع: $topic  
- پایه: $grade
- هدف آموزشی: $goal
- نوع بازی: $gameType
- سبک طراحی: $style
- نوع تعامل: $interaction
- مدت زمان: $duration
- سطح سختی: $difficulty
- ویژگی‌های خاص: $featuresText

لطفاً 3 ایده متنوع و خلاقانه برای بازی آموزشی ارائه دهید که با این مشخصات مطابقت داشته باشد.

فقط این فرمت JSON برگردانید (بدون هیچ متن اضافی):
[
  {\"title\": \"عنوان جذاب بازی 1\", \"desc\": \"توضیح کامل و جذاب بازی شامل نحوه بازی و یادگیری\"},
  {\"title\": \"عنوان جذاب بازی 2\", \"desc\": \"توضیح کامل و جذاب بازی شامل نحوه بازی و یادگیری\"},
  {\"title\": \"عنوان جذاب بازی 3\", \"desc\": \"توضیح کامل و جذاب بازی شامل نحوه بازی و یادگیری\"}
]";

        $response = callAnthropicAPI($prompt);
        
        if ($response === false) {
            $error = 'خطا در ارتباط با AI. دوباره تلاش کنید.';
            $step = 'form';
            debugMsg("AI call failed");
        } else {
            debugMsg("AI response received: " . substr($response, 0, 200) . "...");
            
            // Clean response
            $response = trim($response);
            $response = preg_replace('/^```json\s*/m', '', $response);
            $response = preg_replace('/\s*```$/m', '', $response);
            
            // Extract JSON
            if (preg_match('/\[[\s\S]*?\]/', $response, $matches)) {
                $jsonStr = $matches[0];
                debugMsg("Found JSON: " . $jsonStr);
                
                $ideas = json_decode($jsonStr, true);
                if ($ideas && is_array($ideas) && count($ideas) > 0) {
                    $_SESSION['temp_ideas'] = $ideas;
                    $_SESSION['temp_form'] = compact('lesson', 'topic', 'grade', 'goal', 'gameType', 'style', 'interaction', 'duration', 'difficulty', 'features');
                    $step = 'select';
                    $message = 'ایده‌ها تولید شدند!';
                    debugMsg("Ideas saved successfully: " . count($ideas) . " ideas");
                } else {
                    $error = 'پاسخ AI نامعتبر بود. دوباره تلاش کنید.';
                    $step = 'form';
                    debugMsg("JSON decode failed or empty array");
                }
            } else {
                $error = 'فرمت پاسخ AI صحیح نبود. دوباره تلاش کنید.';
                $step = 'form';
                debugMsg("No JSON pattern found in response");
            }
        }
    }
}

// Step 2: Create Game
if (isset($_POST['create_game'])) {
    debugMsg("Create game form submitted");
    
    $selectedIndex = (int)($_POST['selected_idea'] ?? -1);
    $ideas = $_SESSION['temp_ideas'] ?? [];
    $formData = $_SESSION['temp_form'] ?? [];
    
    debugMsg("Selected index: $selectedIndex, Ideas count: " . count($ideas));
    
    if ($selectedIndex < 0 || !isset($ideas[$selectedIndex]) || empty($formData)) {
        $error = 'اطلاعات ناقص است. از ابتدا شروع کنید.';
        $step = 'form';
        debugMsg("Invalid selection or missing data");
    } else {
        $selectedIdea = $ideas[$selectedIndex];
        debugMsg("Selected idea: " . $selectedIdea['title']);
        
        $gamePrompt = "یک بازی HTML کامل و حرفه‌ای برای موضوع زیر بساز:

عنوان: " . $selectedIdea['title'] . "
توضیح: " . $selectedIdea['desc'] . "
درس: " . $formData['lesson'] . "
موضوع: " . $formData['topic'] . "
پایه: " . $formData['grade'] . "
هدف آموزشی: " . ($formData['goal'] ?? '') . "
نوع بازی: " . ($formData['gameType'] ?? 'تعاملی') . "
سبک طراحی: " . ($formData['style'] ?? 'رنگارنگ') . "
نوع تعامل: " . ($formData['interaction'] ?? 'کلیک') . "
مدت زمان: " . ($formData['duration'] ?? '10-15 دقیقه') . "
سطح سختی: " . ($formData['difficulty'] ?? 'متوسط') . "

الزامات فنی:
- فایل HTML کامل با CSS و JavaScript داخلی
- طراحی واکنش‌گرا (Responsive) برای موبایل و تبلت
- راست به چپ (RTL) برای زبان فارسی
- رنگ‌بندی مناسب و جذاب برای کودکان
- فونت‌های خوانا مثل Tahoma
- دکمه شروع مجدد و راهنما
- سیستم امتیازدهی واضح
- بازخورد فوری به کاربر (صحیح/غلط)
- انیمیشن‌های ساده و جذاب
- صدای اختیاری (اگر مناسب باشد)

ویژگی‌های اضافی: " . (isset($formData['features']) ? implode(', ', $formData['features']) : 'ساده') . "

فقط کد HTML کامل برگردان (بدون توضیح):";

        $gameCode = callAnthropicAPI($gamePrompt);
        
        if ($gameCode === false) {
            $error = 'خطا در ساخت بازی. دوباره تلاش کنید.';
            $step = 'select';
            debugMsg("Game creation failed");
        } else {
            debugMsg("Game code received, length: " . strlen($gameCode));
            
            // Clean code
            $gameCode = preg_replace('/^```html\n?/m', '', $gameCode);
            $gameCode = preg_replace('/\n?```$/m', '', $gameCode);
            $gameCode = trim($gameCode);
            
            // Save to database
            try {
                $stmt = $db->prepare("INSERT INTO games (title, lesson, topic, code, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $selectedIdea['title'],
                    $formData['lesson'],
                    $formData['topic'],
                    $gameCode,
                    $userId
                ]);
                
                $_SESSION['created_game'] = [
                    'id' => $db->lastInsertId(),
                    'title' => $selectedIdea['title'],
                    'code' => $gameCode
                ];
                
                $step = 'done';
                $message = 'بازی با موفقیت ساخته شد!';
                debugMsg("Game saved successfully with ID: " . $db->lastInsertId());
                
            } catch (Exception $e) {
                $error = 'خطا در ذخیره: ' . $e->getMessage();
                $step = 'select';
                debugMsg("Database error: " . $e->getMessage());
            }
        }
    }
}

// Handle game management operations
if (isset($_POST['delete_game'])) {
    $gameId = (int)($_POST['game_id'] ?? 0);
    if ($gameId > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM games WHERE id = ? AND created_by = ?");
            $stmt->execute([$gameId, $userId]);
            $message = 'بازی با موفقیت حذف شد.';
        } catch (Exception $e) {
            $error = 'خطا در حذف بازی: ' . $e->getMessage();
        }
    }
}

if (isset($_POST['edit_game'])) {
    $gameId = (int)($_POST['game_id'] ?? 0);
    if ($gameId > 0) {
        $step = 'edit';
        $_SESSION['edit_game_id'] = $gameId;
    }
}

if (isset($_POST['save_edit'])) {
    $gameId = (int)($_SESSION['edit_game_id'] ?? 0);
    $newCode = $_POST['game_code'] ?? '';
    $newTitle = trim($_POST['game_title'] ?? '');
    
    if ($gameId > 0 && !empty($newCode) && !empty($newTitle)) {
        try {
            $stmt = $db->prepare("UPDATE games SET title = ?, code = ? WHERE id = ? AND created_by = ?");
            $stmt->execute([$newTitle, $newCode, $gameId, $userId]);
            $message = 'بازی با موفقیت ویرایش شد.';
            $step = 'form';
            unset($_SESSION['edit_game_id']);
        } catch (Exception $e) {
            $error = 'خطا در ویرایش بازی: ' . $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بازی‌ساز کاربردی</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Tahoma, Arial, sans-serif; 
            direction: rtl; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; 
            padding: 20px; 
            color: #333; 
        }
        .container { 
            max-width: 700px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 15px; 
            padding: 30px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
        }
        h1 { text-align: center; color: #2c3e50; margin-bottom: 20px; }
        .step-nav { 
            display: flex; 
            justify-content: center; 
            gap: 15px; 
            margin-bottom: 30px; 
        }
        .step-btn { 
            padding: 8px 16px; 
            border-radius: 20px; 
            background: #ecf0f1; 
            color: #7f8c8d; 
            font-size: 14px; 
        }
        .step-btn.active { background: #3498db; color: white; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; color: #2c3e50; }
        input, select, textarea { 
            width: 100%; 
            padding: 12px; 
            border: 2px solid #bdc3c7; 
            border-radius: 8px; 
            font-size: 16px; 
        }
        input:focus, select:focus, textarea:focus { 
            outline: none; 
            border-color: #3498db; 
        }
        .btn { 
            background: #3498db; 
            color: white; 
            border: none; 
            padding: 15px 30px; 
            border-radius: 8px; 
            font-size: 16px; 
            cursor: pointer; 
            transition: all 0.3s ease; 
        }
        .btn:hover { background: #2980b9; }
        .btn:disabled { background: #95a5a6; cursor: not-allowed; }
        .idea-card { 
            border: 2px solid #ecf0f1; 
            border-radius: 10px; 
            padding: 20px; 
            margin: 15px 0; 
            cursor: pointer; 
            transition: all 0.3s ease; 
        }
        .idea-card:hover { border-color: #3498db; }
        .idea-card.selected { border-color: #3498db; background: #ebf3fd; }
        .message { 
            padding: 15px; 
            border-radius: 8px; 
            margin-bottom: 20px; 
            text-align: center; 
            font-weight: bold; 
        }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        .preview { 
            border: 2px solid #bdc3c7; 
            border-radius: 10px; 
            overflow: hidden; 
            margin: 20px 0; 
        }
        .preview iframe { width: 100%; height: 400px; border: none; }
        .games-list { margin-top: 30px; padding-top: 20px; border-top: 2px solid #ecf0f1; }
        .game-item { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start; 
            padding: 15px; 
            background: #f8f9fa; 
            border-radius: 8px; 
            margin: 10px 0; 
            border-left: 4px solid #3498db;
        }
        .center { text-align: center; }
        
        /* Enhanced form styles */
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #3498db;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .checkbox-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            padding: 8px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        
        .checkbox-item:hover {
            background-color: rgba(52, 152, 219, 0.1);
        }
        
        .section-header {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.1rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 بازی‌ساز کاربردی</h1>
        <p class="center" style="color: #7f8c8d; margin-bottom: 20px;">
            سلام <?= h($userName) ?>!
            <?php if ($debug): ?>
                <br><small style="background: yellow; padding: 2px 8px; border-radius: 3px;">🔧 حالت دیباگ فعال</small>
            <?php endif; ?>
        </p>
        
        <?php if ($debug): ?>
            <div style="background: #f0f8ff; padding: 15px; margin-bottom: 20px; border-radius: 8px; border: 1px solid #4CAF50;">
                <strong>وضعیت فعلی:</strong><br>
                - مرحله: <?= $step ?><br>
                - ایده‌ها در session: <?= isset($_SESSION['temp_ideas']) ? count($_SESSION['temp_ideas']) : '0' ?><br>
                - اطلاعات فرم در session: <?= isset($_SESSION['temp_form']) ? 'موجود' : 'ناموجود' ?><br>
                - بازی ساخته شده: <?= isset($_SESSION['created_game']) ? 'موجود' : 'ناموجود' ?><br>
            </div>
        <?php endif; ?>
        
        <!-- Step Navigator -->
        <div class="step-nav">
            <div class="step-btn <?= $step === 'form' ? 'active' : '' ?>">1. اطلاعات</div>
            <div class="step-btn <?= $step === 'select' ? 'active' : '' ?>">2. انتخاب ایده</div>
            <div class="step-btn <?= $step === 'done' ? 'active' : '' ?>">3. بازی آماده</div>
        </div>
        
        <!-- Messages -->
        <?php if ($message): ?>
            <div class="message success"><?= h($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message error"><?= h($error) ?></div>
        <?php endif; ?>
        
        <?php if ($step === 'form'): ?>
            <!-- Step 1: Enhanced Form -->
            <form method="POST">
                <input type="hidden" name="generate_ideas" value="1">
                <?php if ($debug): ?><input type="hidden" name="debug" value="1"><?php endif; ?>
                
                <h3 style="color: #2c3e50; margin-bottom: 20px; text-align: center;">📋 مشخصات بازی آموزشی</h3>
                
                <!-- اطلاعات پایه -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h4 style="color: #3498db; margin-bottom: 15px;">🎯 اطلاعات پایه *</h4>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label>نام درس *:</label>
                            <select name="lesson" required>
                                <option value="">انتخاب کنید...</option>
                                <option value="ریاضی">ریاضی</option>
                                <option value="فارسی">فارسی</option>
                                <option value="علوم">علوم تجربی</option>
                                <option value="مطالعات اجتماعی">مطالعات اجتماعی</option>
                                <option value="انگلیسی">زبان انگلیسی</option>
                                <option value="هنر">هنر و تربیت بدنی</option>
                                <option value="قرآن">قرآن و معارف</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>پایه تحصیلی *:</label>
                            <select name="grade" required>
                                <option value="">انتخاب کنید...</option>
                                <option value="پیش دبستانی">پیش دبستانی</option>
                                <option value="اول">اول دبستان</option>
                                <option value="دوم">دوم دبستان</option>
                                <option value="سوم">سوم دبستان</option>
                                <option value="چهارم">چهارم دبستان</option>
                                <option value="پنجم">پنجم دبستان</option>
                                <option value="ششم">ششم دبستان</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>موضوع درس *:</label>
                        <input type="text" name="topic" placeholder="مثال: جمع و تفریق، املا، چرخه آب، تاریخ ایران" required>
                    </div>
                    
                    <div class="form-group">
                        <label>هدف آموزشی *:</label>
                        <textarea name="goal" placeholder="مثال: دانش‌آموزان باید بتوانند اعداد دو رقمی را بدون نگاه به جدول جمع کنند و نتیجه را در کمتر از 10 ثانیه محاسبه نمایند." required style="min-height: 80px;"></textarea>
                    </div>
                </div>
                
                <!-- تنظیمات بازی -->
                <div style="background: #e8f5e8; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h4 style="color: #27ae60; margin-bottom: 15px;">🎮 تنظیمات بازی</h4>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label>نوع بازی:</label>
                            <select name="game_type">
                                <option value="سوال و جواب">سوال و جواب</option>
                                <option value="پازل و معما">پازل و معما</option>
                                <option value="شبیه‌سازی">شبیه‌سازی</option>
                                <option value="داستان تعاملی">داستان تعاملی</option>
                                <option value="مسابقه">مسابقه و رقابت</option>
                                <option value="ماجراجویی">بازی ماجراجویی</option>
                                <option value="خلاقیت">خلاقیت و طراحی</option>
                                <option value="ورزشی">ورزشی و حرکتی</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>سبک طراحی:</label>
                            <select name="style">
                                <option value="رنگارنگ و شاد">رنگارنگ و شاد</option>
                                <option value="ساده و مینیمال">ساده و مینیمال</option>
                                <option value="کارتونی">کارتونی و بامزه</option>
                                <option value="واقع‌گرایانه">واقع‌گرایانه</option>
                                <option value="فانتزی">فانتزی و جادویی</option>
                                <option value="طبیعی">طبیعی و آرامش‌بخش</option>
                            </select>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label>نوع تعامل:</label>
                            <select name="interaction">
                                <option value="کلیک و انتخاب">کلیک و انتخاب</option>
                                <option value="کشیدن و رها کردن">کشیدن و رها کردن</option>
                                <option value="تایپ کردن">تایپ کردن</option>
                                <option value="لمس و حرکت">لمس و حرکت</option>
                                <option value="ترکیبی">ترکیبی</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>مدت زمان بازی:</label>
                            <select name="duration">
                                <option value="5-10 دقیقه">5-10 دقیقه</option>
                                <option value="10-15 دقیقه">10-15 دقیقه</option>
                                <option value="15-20 دقیقه">15-20 دقیقه</option>
                                <option value="20-30 دقیقه">20-30 دقیقه</option>
                                <option value="آزاد">زمان آزاد</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>سطح سختی:</label>
                        <select name="difficulty">
                            <option value="خیلی آسان">خیلی آسان</option>
                            <option value="آسان">آسان</option>
                            <option value="متوسط">متوسط</option>
                            <option value="سخت">سخت</option>
                            <option value="تطبیقی">تطبیقی (خودکار)</option>
                        </select>
                    </div>
                </div>
                
                <!-- ویژگی‌های ویژه -->
                <div style="background: #fff3e0; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h4 style="color: #f57c00; margin-bottom: 15px;">⭐ ویژگی‌های ویژه</h4>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="صدا و موسیقی">
                            <span>🔊 صدا و موسیقی</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="انیمیشن">
                            <span>🎬 انیمیشن‌های زیبا</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="چندسطحی">
                            <span>🎯 چند سطح</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="امتیاز و جایزه">
                            <span>🏆 سیستم جایزه</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="راهنمای صوتی">
                            <span>🎤 راهنمای صوتی</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="گزارش پیشرفت">
                            <span>📊 گزارش پیشرفت</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="چندنفره">
                            <span>👥 بازی چندنفره</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="features[]" value="ذخیره پیشرفت">
                            <span>💾 ذخیره پیشرفت</span>
                        </label>
                    </div>
                </div>
                
                <div class="center">
                    <button type="submit" class="btn" style="font-size: 18px; padding: 15px 40px;">
                        🚀 تولید ایده‌های خلاقانه
                    </button>
                    <?php if (!$debug): ?>
                        <br><br><small><a href="?debug=1" style="color: #3498db;">مشکل دارید؟ حالت دیباگ</a></small>
                    <?php endif; ?>
                </div>
            </form>
            
        <?php elseif ($step === 'select' && !empty($_SESSION['temp_ideas'])): ?>
            <!-- Step 2: Select Idea -->
            <h2 class="center" style="margin-bottom: 20px;">انتخاب ایده:</h2>
            
            <form method="POST">
                <input type="hidden" name="create_game" value="1">
                <?php if ($debug): ?><input type="hidden" name="debug" value="1"><?php endif; ?>
                
                <?php foreach ($_SESSION['temp_ideas'] as $i => $idea): ?>
                    <div class="idea-card" onclick="selectIdea(<?= $i ?>)">
                        <input type="radio" name="selected_idea" value="<?= $i ?>" style="display: none;" required>
                        <h3><?= h($idea['title']) ?></h3>
                        <p><?= h($idea['desc']) ?></p>
                    </div>
                <?php endforeach; ?>
                
                <div class="center">
                    <button type="submit" class="btn" id="createBtn" disabled>🎮 ساخت بازی</button>
                    <br><br>
                    <a href="?step=form<?= $debug ? '&debug=1' : '' ?>">← بازگشت</a>
                </div>
            </form>
            
        <?php elseif ($step === 'done' && !empty($_SESSION['created_game'])): ?>
            <!-- Step 3: Game Ready -->
            <?php $game = $_SESSION['created_game']; ?>
            <h2 class="center" style="margin-bottom: 20px;">بازی شما آماده است!</h2>
            
            <div class="preview">
                <iframe srcdoc="<?= h($game['code']) ?>" sandbox="allow-scripts allow-same-origin"></iframe>
            </div>
            
            <div class="center">
                <button onclick="downloadGame()" class="btn">📥 دانلود بازی</button>
                <button onclick="copyCode()" class="btn" style="background: #95a5a6; margin-right: 10px;">📋 کپی کد</button>
                <br><br>
                <a href="?step=form" class="btn" style="background: #27ae60; text-decoration: none;">🔄 ساخت بازی جدید</a>
            </div>
            
            <textarea id="gameCode" style="display: none;"><?= h($game['code']) ?></textarea>
            
        <?php elseif ($step === 'edit' && $editGame): ?>
            <!-- Edit Game -->
            <h2 class="center" style="margin-bottom: 20px;">✏️ ویرایش بازی</h2>
            
            <form method="POST">
                <input type="hidden" name="save_edit" value="1">
                <?php if ($debug): ?><input type="hidden" name="debug" value="1"><?php endif; ?>
                
                <div class="form-group">
                    <label>عنوان بازی:</label>
                    <input type="text" name="game_title" value="<?= h($editGame['title']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label>کد HTML بازی:</label>
                    <textarea name="game_code" style="min-height: 300px; font-family: monospace; direction: ltr; text-align: left;" required><?= h($editGame['code']) ?></textarea>
                </div>
                
                <div class="center">
                    <button type="submit" class="btn" style="background: #27ae60;">💾 ذخیره تغییرات</button>
                    <a href="?step=form<?= $debug ? '&debug=1' : '' ?>" class="btn" style="background: #95a5a6; text-decoration: none; margin-right: 10px;">← انصراف</a>
                </div>
            </form>
            
            <!-- Live Preview -->
            <div style="margin-top: 30px;">
                <h3>پیش‌نمایش زنده:</h3>
                <div class="preview">
                    <iframe id="livePreview" srcdoc="<?= h($editGame['code']) ?>" sandbox="allow-scripts allow-same-origin"></iframe>
                </div>
                <div class="center">
                    <button onclick="updatePreview()" class="btn" style="background: #3498db;">🔄 به‌روزرسانی پیش‌نمایش</button>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Error State -->
            <div class="center">
                <h3>مشکلی پیش آمده است</h3>
                <br>
                <a href="?step=form" class="btn">🔄 شروع مجدد</a>
            </div>
              
    
    <script>
        function selectIdea(index) {
            document.querySelectorAll('.idea-card').forEach(card => card.classList.remove('selected'));
            document.querySelectorAll('input[name="selected_idea"]')[index].checked = true;
            document.querySelectorAll('.idea-card')[index].classList.add('selected');
            document.getElementById('createBtn').disabled = false;
        }
        
        function downloadGame() {
            const code = document.getElementById('gameCode').value;
            const blob = new Blob([code], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'بازی_آموزشی.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            alert('بازی دانلود شد!');
        }
        
        function copyCode() {
            const textarea = document.getElementById('gameCode');
            textarea.style.display = 'block';
            textarea.select();
            document.execCommand('copy');
            textarea.style.display = 'none';
            alert('کد کپی شد!');
        }
        
        function viewGame(gameId) {
            window.open(`view_game.php?id=${gameId}`, '_blank', 'width=800,height=600');
        }
        
        function downloadGameCode(gameId, title) {
            // Create a form to request game code
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'download_game.php';
            form.target = '_blank';
            
            const gameIdInput = document.createElement('input');
            gameIdInput.type = 'hidden';
            gameIdInput.name = 'game_id';
            gameIdInput.value = gameId;
            
            form.appendChild(gameIdInput);
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        }
        
        function updatePreview() {
            const codeTextarea = document.querySelector('textarea[name="game_code"]');
            const preview = document.getElementById('livePreview');
            
            if (codeTextarea && preview) {
                preview.srcdoc = codeTextarea.value;
            }
        }
        
        // Auto-update preview while typing (with debounce)
        let previewTimeout;
        document.addEventListener('input', function(e) {
            if (e.target.name === 'game_code') {
                clearTimeout(previewTimeout);
                previewTimeout = setTimeout(updatePreview, 1000);
            }
        });
        
        // Loading states
        document.addEventListener('submit', function(e) {
            const btn = e.target.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '⏳ در حال پردازش...';
            }
        });
    </script>
</body>
</html>