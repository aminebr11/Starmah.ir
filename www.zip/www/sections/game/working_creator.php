<?php
/* =============================================================
 * Enhanced Game Creator - بازی‌ساز بهبود یافته
 * بازی‌های جذاب‌تر با گرافیک بهتر و امکانات پیشرفته
 * ============================================================= */

// Start session
if (session_status() === PHP_SESSION_NONE) { @session_start(); }

// Check user access
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'admin') {
    header('Location: ../../index.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'کاربر';

// Database and AI configuration
$ANTHROPIC_API_KEY = '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';
$ANTHROPIC_MODEL = 'claude-3-haiku-20240307';

// Database connection
try {
    $db = new PDO("mysql:host=localhost:3306;dbname=qwaepiuv_starmah_db;charset=utf8mb4", 
                  'qwaepiuv_aminebr', 'Test12345!@#', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('خطا در اتصال به دیتابیس: ' . $e->getMessage());
}

// Helper functions
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function callAnthropicAPI($prompt) {
    global $ANTHROPIC_API_KEY, $ANTHROPIC_MODEL;
    
    $data = [
        'model' => $ANTHROPIC_MODEL,
        'max_tokens' => 4000, // افزایش حد مجاز برای بازی‌های پیچیده‌تر
        'messages' => [['role' => 'user', 'content' => $prompt]]
    ];
    
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-key: ' . $ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01'
        ],
        CURLOPT_TIMEOUT => 90, // افزایش timeout برای بازی‌های پیچیده‌تر
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($result === false || $httpCode !== 200) {
        return false;
    }
    
    $decoded = json_decode($result, true);
    return $decoded['content'][0]['text'] ?? false;
}

// Variables
$step = $_POST['step'] ?? $_GET['step'] ?? 'form';
$message = '';
$error = '';

// Handle Generate Ideas
if (isset($_POST['generate_ideas'])) {
    $lesson = trim($_POST['lesson'] ?? '');
    $topic = trim($_POST['topic'] ?? '');
    $grade = trim($_POST['grade'] ?? '');
    $goal = trim($_POST['goal'] ?? '');
    $gameType = trim($_POST['game_type'] ?? 'سوال و جواب');
    $style = trim($_POST['style'] ?? 'رنگارنگ و شاد');
    $interaction = trim($_POST['interaction'] ?? 'کلیک و انتخاب');
    $duration = trim($_POST['duration'] ?? '10-15 دقیقه');
    $difficulty = trim($_POST['difficulty'] ?? 'متوسط');
    $graphics = trim($_POST['graphics'] ?? 'مدرن و جذاب');
    $features = $_POST['features'] ?? [];
    
    if (empty($lesson) || empty($topic) || empty($grade) || empty($goal)) {
        $error = 'لطفاً فیلدهای الزامی (*) را پر کنید';
        $step = 'form';
    } else {
        $featuresText = !empty($features) ? implode(', ', $features) : 'ساده';
        
        // پرامپت بهبود یافته برای تولید ایده‌های خلاقانه‌تر
        $prompt = "شما یک متخصص ارشد طراحی بازی‌های آموزشی دیجیتال برای کودکان هستید که بازی‌های بصری خلاقانه و تعاملی می‌سازید.

📋 مشخصات پروژه:
• درس: $lesson
• موضوع: $topic  
• پایه: $grade
• هدف آموزشی: $goal
• نوع بازی: $gameType
• سبک طراحی: $style
• کیفیت گرافیک: $graphics
• نوع تعامل: $interaction
• مدت زمان: $duration
• سطح سختی: $difficulty
• ویژگی‌های ویژه: $featuresText

🎯 الزامات طراحی:
- بازی باید کاملاً تعاملی و بصری باشد
- گرافیک مدرن با رنگ‌های جذاب و متناسب سن
- انیمیشن‌های روان و چشم‌نواز
- سیستم امتیازدهی پیشرفته با feedback بصری
- صداهای مناسب (بیپ، تشویق، موسیقی پس‌زمینه)
- طراحی responsive برای موبایل و دسکتاپ
- المان‌های گیمیفیکیشن (سکه، ستاره، مدال)
- پیشرفت بصری (progress bar، level up)

🎨 ایده‌ها باید:
- خلاقانه و منحصربه‌فرد باشند
- دارای عناصر داستان و شخصیت باشند
- چالش‌برانگیز ولی مناسب سن باشند
- قابلیت replay داشته باشند
- دارای اهداف کوتاه‌مدت و بلندمدت باشند

لطفاً 3 ایده کاملاً متفاوت و خلاقانه ارائه دهید که هر کدام یک تجربه منحصربه‌فرد باشند.

فقط این فرمت JSON برگردانید:
[
  {\"title\": \"عنوان فوق‌العاده جذاب 1\", \"desc\": \"توضیح کامل و هیجان‌انگیز که تمام جزئیات بازی، شخصیت‌ها، مکانیک‌ها و ویژگی‌های بصری را شرح دهد\"},
  {\"title\": \"عنوان فوق‌العاده جذاب 2\", \"desc\": \"توضیح کامل و هیجان‌انگیز که تمام جزئیات بازی، شخصیت‌ها، مکانیک‌ها و ویژگی‌های بصری را شرح دهد\"},
  {\"title\": \"عنوان فوق‌العاده جذاب 3\", \"desc\": \"توضیح کامل و هیجان‌انگیز که تمام جزئیات بازی، شخصیت‌ها، مکانیک‌ها و ویژگی‌های بصری را شرح دهد\"}
]";

        $response = callAnthropicAPI($prompt);
        
        if ($response === false) {
            $error = 'خطا در ارتباط با AI. دوباره تلاش کنید.';
            $step = 'form';
        } else {
            // Extract JSON
            $response = trim($response);
            $response = preg_replace('/^```json\s*/m', '', $response);
            $response = preg_replace('/\s*```$/m', '', $response);
            
            if (preg_match('/\[[\s\S]*?\]/', $response, $matches)) {
                $ideas = json_decode($matches[0], true);
                if ($ideas && is_array($ideas) && count($ideas) > 0) {
                    $_SESSION['temp_ideas'] = $ideas;
                    $_SESSION['temp_form'] = compact('lesson', 'topic', 'grade', 'goal', 'gameType', 'style', 'interaction', 'duration', 'difficulty', 'graphics', 'features');
                    $step = 'select';
                    $message = 'ایده‌های خلاقانه تولید شدند!';
                } else {
                    $error = 'پاسخ AI نامعتبر بود. دوباره تلاش کنید.';
                    $step = 'form';
                }
            } else {
                $error = 'فرمت پاسخ AI صحیح نبود. دوباره تلاش کنید.';
                $step = 'form';
            }
        }
    }
}

// Handle Create Game
if (isset($_POST['create_game'])) {
    $selectedIndex = (int)($_POST['selected_idea'] ?? -1);
    $ideas = $_SESSION['temp_ideas'] ?? [];
    $formData = $_SESSION['temp_form'] ?? [];
    
    if ($selectedIndex < 0 || !isset($ideas[$selectedIndex]) || empty($formData)) {
        $error = 'اطلاعات ناقص است. از ابتدا شروع کنید.';
        $step = 'form';
    } else {
        $selectedIdea = $ideas[$selectedIndex];
        
        // پرامپت پیشرفته برای ساخت بازی
        $gamePrompt = "شما یک برنامه‌نویس front-end متخصص در ساخت بازی‌های HTML5 تعاملی و بصری هستید.

🎮 مشخصات بازی:
عنوان: " . $selectedIdea['title'] . "
شرح: " . $selectedIdea['desc'] . "
درس: " . $formData['lesson'] . "
موضوع: " . $formData['topic'] . "
پایه: " . $formData['grade'] . "
هدف: " . $formData['goal'] . "
سطح گرافیک: " . $formData['graphics'] . "

🚀 الزامات فنی حیاتی:
✅ HTML5 کامل با CSS3 و JavaScript مدرن
✅ طراحی مدرن و responsive (موبایل + دسکتاپ)
✅ RTL کامل برای متن فارسی
✅ انیمیشن‌های CSS روان (transitions, transforms, keyframes)
✅ گرافیک وکتوری با SVG
✅ پالت رنگی مدرن و چشم‌نواز
✅ تایپوگرافی زیبا و خوانا

🎯 سیستم امتیازدهی پیشرفته:
- امتیاز نمایش داده شود + انیمیشن افزایش
- ذخیره امتیاز در localStorage
- نمایش بهترین امتیاز
- سیستم ستاره/مدال برای عملکرد
- Progress bar برای پیشرفت
- تشویق بصری و متنی

🎨 ویژگی‌های بصری لازم:
- آیکون‌های مناسب (SVG یا Unicode)
- گرادیانت‌های زیبا
- سایه‌ها و عمق بصری
- انیمیشن hover و focus
- ذرات یا افکت‌های بصری
- loading states
- modal یا overlay برای راهنما

🔊 المان‌های صوتی:
- بیپ برای کلیک (با Audio API یا data URLs)
- صدای موفقیت/شکست
- موسیقی پس‌زمینه اختیاری

📱 قابلیت‌های تعاملی:
- کنترل‌های لمسی برای موبایل
- کیبورد shortcuts
- دکمه تمام‌صفحه
- دکمه reset و راهنما
- منوی تنظیمات

🎮 گیم پلی:
- چندین سطح سختی
- سیستم زمان‌سنج
- چالش‌های متنوع
- بازخورد فوری
- امکان pause/resume

💾 ذخیره‌سازی:
- ذخیره امتیاز در localStorage
- ذخیره تنظیمات کاربر
- ذخیره پیشرفت بازی

کد HTML کامل و حرفه‌ای بنویس که همه الزامات بالا را داشته باشد:";

        $gameCode = callAnthropicAPI($gamePrompt);
        
        if ($gameCode === false) {
            $error = 'خطا در ساخت بازی. دوباره تلاش کنید.';
            $step = 'select';
        } else {
            // Clean code
            $gameCode = preg_replace('/^```html\n?/m', '', $gameCode);
            $gameCode = preg_replace('/\n?```$/m', '', $gameCode);
            $gameCode = trim($gameCode);
            
            // Save to database
            try {
                $stmt = $db->prepare("INSERT INTO games (title, lesson, topic, code, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $selectedIdea['title'],
                    $formData['lesson'],
                    $formData['topic'],
                    $gameCode,
                    $userId
                ]);
                
                $_SESSION['created_game'] = [
                    'id' => $db->lastInsertId(),
                    'title' => $selectedIdea['title'],
                    'code' => $gameCode
                ];
                
                $step = 'done';
                $message = 'بازی پیشرفته با موفقیت ساخته شد!';
                
            } catch (Exception $e) {
                $error = 'خطا در ذخیره: ' . $e->getMessage();
                $step = 'select';
            }
        }
    }
}

// Handle Game Management (unchanged)
if (isset($_POST['delete_game'])) {
    $gameId = (int)($_POST['game_id'] ?? 0);
    if ($gameId > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM games WHERE id = ? AND created_by = ?");
            $stmt->execute([$gameId, $userId]);
            $message = 'بازی با موفقیت حذف شد.';
        } catch (Exception $e) {
            $error = 'خطا در حذف بازی: ' . $e->getMessage();
        }
    }
}

if (isset($_POST['edit_game'])) {
    $gameId = (int)($_POST['game_id'] ?? 0);
    if ($gameId > 0) {
        $step = 'edit';
        $_SESSION['edit_game_id'] = $gameId;
    }
}

if (isset($_POST['save_edit'])) {
    $gameId = (int)($_SESSION['edit_game_id'] ?? 0);
    $newCode = $_POST['game_code'] ?? '';
    $newTitle = trim($_POST['game_title'] ?? '');
    
    if ($gameId > 0 && !empty($newCode) && !empty($newTitle)) {
        try {
            $stmt = $db->prepare("UPDATE games SET title = ?, code = ? WHERE id = ? AND created_by = ?");
            $stmt->execute([$newTitle, $newCode, $gameId, $userId]);
            $message = 'بازی با موفقیت ویرایش شد.';
            $step = 'form';
            unset($_SESSION['edit_game_id']);
        } catch (Exception $e) {
            $error = 'خطا در ویرایش بازی: ' . $e->getMessage();
        }
    }
}

// Get user games
$stmt = $db->prepare("SELECT id, title, lesson, topic, code, created_at FROM games WHERE created_by = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$userId]);
$userGames = $stmt->fetchAll();

// Get game for editing
$editGame = null;
if ($step === 'edit' && isset($_SESSION['edit_game_id'])) {
    $stmt = $db->prepare("SELECT * FROM games WHERE id = ? AND created_by = ?");
    $stmt->execute([$_SESSION['edit_game_id'], $userId]);
    $editGame = $stmt->fetch();
    if (!$editGame) {
        $error = 'بازی مورد نظر یافت نشد.';
        $step = 'form';
        unset($_SESSION['edit_game_id']);
    }
}

?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎮 بازی‌ساز هوشمند پیشرفته - <?= h($userName) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif; 
            direction: rtl; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height: 100vh; 
            padding: 20px; 
            color: #333; 
            position: relative;
            overflow-x: hidden;
        }
        
        /* انیمیشن پس‌زمینه */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(circle at 20% 50%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 80%, rgba(120, 219, 255, 0.3) 0%, transparent 50%);
            animation: float 20s ease-in-out infinite;
            pointer-events: none;
            z-index: -1;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0px, 0px) rotate(0deg); }
            33% { transform: translate(30px, -30px) rotate(120deg); }
            66% { transform: translate(-20px, 20px) rotate(240deg); }
        }
        
        .container { 
            max-width: 1000px; 
            margin: 0 auto; 
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 25px; 
            padding: 40px; 
            box-shadow: 
                0 20px 40px rgba(0,0,0,0.1),
                0 0 0 1px rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
        }
        
        h1 { 
            text-align: center; 
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px; 
            font-size: 2.5rem;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .subtitle {
            text-align: center;
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 30px;
            opacity: 0;
            animation: fadeInUp 1s ease 0.3s forwards;
        }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .step-nav { 
            display: flex; 
            justify-content: center; 
            gap: 20px; 
            margin-bottom: 40px; 
            flex-wrap: wrap;
        }
        
        .step-btn { 
            padding: 15px 25px; 
            border-radius: 50px; 
            background: rgba(236, 240, 241, 0.8);
            backdrop-filter: blur(10px);
            color: #7f8c8d; 
            font-size: 14px; 
            font-weight: 600;
            border: 2px solid transparent;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
        }
        
        .step-btn.active { 
            background: linear-gradient(135deg, #3498db, #2ecc71);
            color: white; 
            border-color: rgba(255,255,255,0.3);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.3);
        }
        
        .form-group { 
            margin-bottom: 25px; 
            opacity: 0;
            animation: slideInRight 0.6s ease forwards;
        }
        
        .form-group:nth-child(odd) {
            animation: slideInLeft 0.6s ease forwards;
        }
        
        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(50px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        @keyframes slideInLeft {
            from { opacity: 0; transform: translateX(-50px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        label { 
            display: block; 
            margin-bottom: 10px; 
            font-weight: 600; 
            color: #2c3e50; 
            font-size: 1rem;
        }
        
        input, select, textarea { 
            width: 100%; 
            padding: 15px 20px; 
            border: 2px solid rgba(189, 195, 199, 0.3); 
            border-radius: 15px; 
            font-size: 16px; 
            font-family: inherit;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        input:focus, select:focus, textarea:focus { 
            outline: none; 
            border-color: #3498db; 
            box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.1);
            transform: translateY(-2px);
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .btn { 
            background: linear-gradient(135deg, #3498db, #2ecc71); 
            color: white; 
            border: none; 
            padding: 15px 30px; 
            border-radius: 50px; 
            font-size: 16px; 
            font-weight: 600;
            cursor: pointer; 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
            text-decoration: none;
            display: inline-block;
            position: relative;
            overflow: hidden;
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .btn:hover { 
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(52, 152, 219, 0.4);
        }
        
        .btn:active {
            transform: translateY(-1px);
        }
        
        .btn:disabled { 
            background: linear-gradient(135deg, #95a5a6, #7f8c8d); 
            cursor: not-allowed; 
            transform: none;
            box-shadow: none;
        }
        
        .btn-success { 
            background: linear-gradient(135deg, #27ae60, #2ecc71); 
        }
        .btn-success:hover { 
            box-shadow: 0 15px 30px rgba(39, 174, 96, 0.4);
        }
        
        .btn-warning { 
            background: linear-gradient(135deg, #f39c12, #e67e22); 
        }
        .btn-warning:hover { 
            box-shadow: 0 15px 30px rgba(243, 156, 18, 0.4);
        }
        
        .btn-danger { 
            background: linear-gradient(135deg, #e74c3c, #c0392b); 
        }
        .btn-danger:hover { 
            box-shadow: 0 15px 30px rgba(231, 76, 60, 0.4);
        }
        
        .btn-secondary { 
            background: linear-gradient(135deg, #95a5a6, #7f8c8d); 
        }
        
        .idea-card { 
            border: 3px solid rgba(236, 240, 241, 0.5); 
            border-radius: 20px; 
            padding: 25px; 
            margin: 20px 0; 
            cursor: pointer; 
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); 
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(15px);
            position: relative;
            overflow: hidden;
        }
        
        .idea-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, transparent, rgba(52, 152, 219, 0.05));
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .idea-card:hover::before {
            opacity: 1;
        }
        
        .idea-card:hover { 
            border-color: #3498db; 
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(52, 152, 219, 0.2);
        }
        
        .idea-card.selected { 
            border-color: #3498db; 
            background: rgba(52, 152, 219, 0.1);
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(52, 152, 219, 0.3);
        }
        
        .message { 
            padding: 20px; 
            border-radius: 15px; 
            margin-bottom: 25px; 
            text-align: center; 
            font-weight: 600;
            backdrop-filter: blur(10px);
            animation: bounceIn 0.6s ease;
        }
        
        @keyframes bounceIn {
            0% { opacity: 0; transform: scale(0.3); }
            50% { opacity: 1; transform: scale(1.05); }
            70% { transform: scale(0.9); }
            100% { transform: scale(1); }
        }
        
        .success { 
            background: rgba(212, 237, 218, 0.9); 
            color: #155724;
            border: 2px solid rgba(39, 174, 96, 0.3);
        }
        
        .error { 
            background: rgba(248, 215, 218, 0.9); 
            color: #721c24; 
            border: 2px solid rgba(231, 76, 60, 0.3);
        }
        
        .preview { 
            border: 3px solid rgba(189, 195, 199, 0.3); 
            border-radius: 20px; 
            overflow: hidden; 
            margin: 25px 0;
            background: white;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }
        
        .preview iframe { 
            width: 100%; 
            height: 600px; 
            border: none; 
        }
        
        .games-list { 
            margin-top: 50px; 
            padding-top: 40px; 
            border-top: 3px solid rgba(236, 240, 241, 0.5); 
        }
        
        .game-item { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start; 
            padding: 25px; 
            background: rgba(248, 249, 250, 0.8);
            backdrop-filter: blur(15px);
            border-radius: 20px; 
            margin: 20px 0; 
            border-right: 5px solid #3498db;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0;
            animation: slideInUp 0.6s ease forwards;
        }
        
        .game-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .center { 
            text-align: center; 
        }
        
        .form-section {
            background: rgba(248, 249, 250, 0.6);
            backdrop-filter: blur(15px);
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 30px;
            border-right: 5px solid #3498db;
            opacity: 0;
            animation: fadeInScale 0.8s ease forwards;
        }
        
        @keyframes fadeInScale {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        .form-section.success-section {
            background: rgba(232, 245, 232, 0.6);
            border-right-color: #27ae60;
        }
        
        .form-section.warning-section {
            background: rgba(255, 243, 224, 0.6);
            border-right-color: #f39c12;
        }
        
        .form-section.premium-section {
            background: linear-gradient(135deg, rgba(106, 17, 203, 0.1), rgba(37, 117, 252, 0.1));
            border-right-color: #6a11cb;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .checkbox-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 12px 16px;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: rgba(255, 255, 255, 0.5);
            border: 2px solid transparent;
        }
        
        .checkbox-item:hover {
            background: rgba(52, 152, 219, 0.1);
            border-color: rgba(52, 152, 219, 0.3);
            transform: translateY(-2px);
        }
        
        .checkbox-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
            accent-color: #3498db;
        }
        
        .section-header {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.3rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .feature-highlight {
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 700;
        }
        
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .tooltip {
            position: relative;
            cursor: help;
        }
        
        .tooltip::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 125%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.9);
            color: white;
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            pointer-events: none;
            z-index: 1000;
        }
        
        .tooltip:hover::after {
            opacity: 1;
            visibility: visible;
        }
        
        .progress-container {
            background: rgba(236, 240, 241, 0.5);
            border-radius: 10px;
            padding: 4px;
            margin: 20px 0;
        }
        
        .progress-bar {
            height: 8px;
            background: linear-gradient(135deg, #3498db, #2ecc71);
            border-radius: 6px;
            transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        @media (max-width: 768px) {
            .container { 
                padding: 25px; 
                margin: 15px;
                border-radius: 20px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .checkbox-grid {
                grid-template-columns: 1fr;
            }
            
            .game-item {
                flex-direction: column;
                gap: 20px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .step-nav {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }
        
        /* Elegant scroll bar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(241, 243, 244, 0.5);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #3498db, #2ecc71);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #2980b9, #27ae60);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 بازی‌ساز هوشمند پیشرفته</h1>
        <p class="subtitle">
            سلام <span class="feature-highlight"><?= h($userName) ?></span>! بیایید بازی‌های آموزشی خلاقانه و گرافیکی بسازیم
        </p>
        
        <!-- Step Navigator -->
        <div class="step-nav">
            <div class="step-btn <?= $step === 'form' ? 'active' : '' ?>">📋 مشخصات پروژه</div>
            <div class="step-btn <?= $step === 'select' ? 'active' : '' ?>">💡 انتخاب ایده خلاقانه</div>
            <div class="step-btn <?= $step === 'done' ? 'active' : '' ?>">🎮 بازی پیشرفته</div>
            <?php if ($step === 'edit'): ?>
                <div class="step-btn active">✏️ ویرایش حرفه‌ای</div>
            <?php endif; ?>
        </div>
        
        <!-- Messages -->
        <?php if ($message): ?>
            <div class="message success">✅ <?= h($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="message error">❌ <?= h($error) ?></div>
        <?php endif; ?>
        
        <?php if ($step === 'form'): ?>
            <!-- Step 1: Enhanced Form -->
            <form method="POST">
                <input type="hidden" name="generate_ideas" value="1">
                
                <!-- اطلاعات پایه -->
                <div class="form-section">
                    <div class="section-header">🎯 مشخصات آموزشی</div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>نام درس <span style="color: #e74c3c;">*</span>:</label>
                            <select name="lesson" required>
                                <option value="">انتخاب کنید...</option>
                                <option value="ریاضی">📊 ریاضی</option>
                                <option value="فارسی">📚 فارسی</option>
                                <option value="علوم">🔬 علوم تجربی</option>
                                <option value="مطالعات اجتماعی">🌍 مطالعات اجتماعی</option>
                                <option value="انگلیسی">🌐 زبان انگلیسی</option>
                                <option value="هنر">🎨 هنر و تربیت بدنی</option>
                                <option value="قرآن">📖 قرآن و معارف</option>
                                <option value="کامپیوتر">💻 کامپیوتر و فناوری</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>پایه تحصیلی <span style="color: #e74c3c;">*</span>:</label>
                            <select name="grade" required>
                                <option value="">انتخاب کنید...</option>
                                <option value="پیش دبستانی">🧸 پیش دبستانی</option>
                                <option value="اول">1️⃣ اول دبستان</option>
                                <option value="دوم">2️⃣ دوم دبستان</option>
                                <option value="سوم">3️⃣ سوم دبستان</option>
                                <option value="چهارم">4️⃣ چهارم دبستان</option>
                                <option value="پنجم">5️⃣ پنجم دبستان</option>
                                <option value="ششم">6️⃣ ششم دبستان</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>موضوع درس <span style="color: #e74c3c;">*</span>:</label>
                        <input type="text" name="topic" placeholder="مثال: جمع و تفریق، املا، چرخه آب، تاریخ ایران، اعداد انگلیسی" required>
                    </div>
                    
                    <div class="form-group">
                        <label>هدف آموزشی <span style="color: #e74c3c;">*</span>:</label>
                        <textarea name="goal" placeholder="مثال: دانش‌آموزان باید بتوانند اعداد دو رقمی را جمع کنند و نتیجه را در کمتر از 10 ثانیه محاسبه نمایند و از طریق بازی لذت ببرند." required></textarea>
                    </div>
                </div>
                
                <!-- تنظیمات بازی -->
                <div class="form-section success-section">
                    <div class="section-header">🎮 تنظیمات گیم‌پلی</div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>نوع بازی:</label>
                            <select name="game_type">
                                <option value="سوال و جواب">❓ سوال و جواب تعاملی</option>
                                <option value="پازل و معما">🧩 پازل و معما</option>
                                <option value="شبیه‌سازی">🎭 شبیه‌سازی و آزمایش</option>
                                <option value="داستان تعاملی">📱 داستان تعاملی</option>
                                <option value="مسابقه">🏆 مسابقه و رقابت</option>
                                <option value="ماجراجویی">🗺️ بازی ماجراجویی</option>
                                <option value="خلاقیت">🎨 خلاقیت و طراحی</option>
                                <option value="ورزشی">⚽ ورزشی و حرکتی</option>
                                <option value="کارت و حافظه">🃏 کارت و تقویت حافظه</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>سبک طراحی:</label>
                            <select name="style">
                                <option value="رنگارنگ و شاد">🌈 رنگارنگ و شاد</option>
                                <option value="ساده و مینیمال">⚪ ساده و مینیمال</option>
                                <option value="کارتونی">🦄 کارتونی و بامزه</option>
                                <option value="واقع‌گرایانه">📷 واقع‌گرایانه</option>
                                <option value="فانتزی">🧙‍♂️ فانتزی و جادویی</option>
                                <option value="طبیعی">🌿 طبیعی و آرامش‌بخش</option>
                                <option value="فضایی">🚀 فضایی و مدرن</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>نوع تعامل:</label>
                            <select name="interaction">
                                <option value="کلیک و انتخاب">👆 کلیک و انتخاب</option>
                                <option value="کشیدن و رها کردن">🖱️ کشیدن و رها کردن</option>
                                <option value="تایپ کردن">⌨️ تایپ کردن</option>
                                <option value="لمس و حرکت">📱 لمس و حرکت</option>
                                <option value="ترکیبی">🔄 ترکیبی و متنوع</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>مدت زمان بازی:</label>
                            <select name="duration">
                                <option value="5-10 دقیقه">⏱️ 5-10 دقیقه</option>
                                <option value="10-15 دقیقه">⏲️ 10-15 دقیقه</option>
                                <option value="15-20 دقیقه">⏰ 15-20 دقیقه</option>
                                <option value="20-30 دقیقه">🕐 20-30 دقیقه</option>
                                <option value="آزاد">♾️ زمان آزاد</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>سطح سختی:</label>
                        <select name="difficulty">
                            <option value="خیلی آسان">😊 خیلی آسان</option>
                            <option value="آسان">🙂 آسان</option>
                            <option value="متوسط">😐 متوسط</option>
                            <option value="سخت">😤 سخت</option>
                            <option value="تطبیقی">🤖 تطبیقی (هوشمند)</option>
                        </select>
                    </div>
                </div>
                
                <!-- کیفیت گرافیک - بخش جدید -->
                <div class="form-section premium-section">
                    <div class="section-header">🎨 کیفیت بصری و گرافیک</div>
                    
                    <div class="form-group">
                        <label>سطح گرافیک و بصری 
                            <span class="tooltip" data-tooltip="کیفیت بصری بازی را تعیین می‌کند">ℹ️</span>:
                        </label>
                        <select name="graphics">
                            <option value="ساده و کلاسیک">📱 ساده و کلاسیک</option>
                            <option value="مدرن و جذاب">✨ مدرن و جذاب</option>
                            <option value="حرفه‌ای و پیشرفته">🎯 حرفه‌ای و پیشرفته</option>
                            <option value="سه‌بعدی و متحرک">🎬 سه‌بعدی و متحرک</option>
                            <option value="فوق‌پیشرفته">🚀 فوق‌پیشرفته (AAA Quality)</option>
                        </select>
                    </div>
                </div>
                
                <!-- ویژگی‌های پیشرفته -->
                <div class="form-section warning-section">
                    <div class="section-header">⭐ ویژگی‌های پیشرفته و گیمیفیکیشن</div>
                    
                    <div class="checkbox-grid">
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="صدا و موسیقی پیشرفته">
                            <span>🎵 صداها و موسیقی پیشرفته</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="انیمیشن سینمایی">
                            <span>🎬 انیمیشن‌های سینمایی</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="چندسطحی پیشرفته">
                            <span>🎯 چندسطحی پیشرفته</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="سیستم جایزه و مدال">
                            <span>🏆 سیستم جایزه و مدال</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="راهنمای صوتی هوشمند">
                            <span>🎤 راهنمای صوتی هوشمند</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="گزارش پیشرفت تحلیلی">
                            <span>📊 آمار و تحلیل پیشرفت</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="بازی چندنفره آنلاین">
                            <span>👥 بازی چندنفره</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="ذخیره پیشرفت ابری">
                            <span>☁️ ذخیره پیشرفت ابری</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="AI هوشمند">
                            <span>🤖 هوش مصنوعی پاسخگو</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="واقعیت افزوده">
                            <span>🥽 واقعیت افزوده (AR)</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="شخصی‌سازی کامل">
                            <span>⚙️ شخصی‌سازی کامل</span>
                        </label>
                        <label class="checkbox-item">
                            <input type="checkbox" name="features[]" value="انیمیشن ذرات">
                            <span>✨ انیمیشن ذرات و افکت</span>
                        </label>
                    </div>
                </div>
                
                <div class="center">
                    <button type="submit" class="btn" style="font-size: 20px; padding: 20px 50px; border-radius: 50px;">
                        🚀 تولید ایده‌های فوق‌العاده خلاقانه
                    </button>
                </div>
            </form>
            
        <?php elseif ($step === 'select' && !empty($_SESSION['temp_ideas'])): ?>
            <!-- Step 2: Select Idea -->
            <h2 class="center" style="margin-bottom: 30px; color: #2c3e50;">💡 انتخاب ایده برتر و خلاقانه</h2>
            
            <form method="POST">
                <input type="hidden" name="create_game" value="1">
                
                <?php foreach ($_SESSION['temp_ideas'] as $i => $idea): ?>
                    <div class="idea-card" onclick="selectIdea(<?= $i ?>)">
                        <input type="radio" name="selected_idea" value="<?= $i ?>" style="display: none;" required>
                        <h3 style="color: #2c3e50; margin-bottom: 15px; font-size: 1.4rem; font-weight: 700;">
                            <?= h($idea['title']) ?>
                        </h3>
                        <p style="color: #555; line-height: 1.8; font-size: 1rem;">
                            <?= h($idea['desc']) ?>
                        </p>
                    </div>
                <?php endforeach; ?>
                
                <div class="center">
                    <button type="submit" class="btn btn-success" id="createBtn" disabled style="font-size: 20px; padding: 20px 50px; border-radius: 50px;">
                        🎮 ساخت بازی پیشرفته
                        <span class="loading-spinner" style="display: none; margin-right: 10px;"></span>
                    </button>
                    <br><br>
                    <a href="?step=form" class="btn btn-secondary">← بازگشت به فرم</a>
                </div>
            </form>
            
        <?php elseif ($step === 'done' && !empty($_SESSION['created_game'])): ?>
            <!-- Step 3: Game Ready -->
            <?php $game = $_SESSION['created_game']; ?>
            <h2 class="center" style="margin-bottom: 30px; color: #2c3e50;">🎉 بازی پیشرفته شما آماده است!</h2>
            
            <div class="preview">
                <iframe srcdoc="<?= h($game['code']) ?>" sandbox="allow-scripts allow-same-origin allow-forms"></iframe>
            </div>
            
            <div class="center">
                <button onclick="downloadGame()" class="btn btn-success" style="margin: 10px; padding: 15px 30px;">
                    📥 دانلود بازی پیشرفته
                </button>
                <button onclick="copyCode()" class="btn btn-secondary" style="margin: 10px; padding: 15px 30px;">
                    📋 کپی کد HTML
                </button>
                <button onclick="shareGame()" class="btn btn-warning" style="margin: 10px; padding: 15px 30px;">
                    📤 اشتراک‌گذاری
                </button>
                <a href="?step=form" class="btn" style="margin: 10px; padding: 15px 30px;">
                    🔄 ساخت بازی جدید
                </a>
            </div>
            
            <textarea id="gameCode" style="display: none;"><?= h($game['code']) ?></textarea>
            
        <?php elseif ($step === 'edit' && $editGame): ?>
            <!-- Edit Game -->
            <h2 class="center" style="margin-bottom: 30px; color: #2c3e50;">✏️ ویرایش حرفه‌ای بازی</h2>
            
            <form method="POST">
                <input type="hidden" name="save_edit" value="1">
                
                <div class="form-group">
                    <label>عنوان بازی:</label>
                    <input type="text" name="game_title" value="<?= h($editGame['title']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label>کد HTML بازی:</label>
                    <textarea name="game_code" style="min-height: 400px; font-family: 'Fira Code', 'Courier New', monospace; direction: ltr; text-align: left; font-size: 14px;" required><?= h($editGame['code']) ?></textarea>
                </div>
                
                <div class="center">
                    <button type="submit" class="btn btn-success" style="padding: 15px 30px;">💾 ذخیره تغییرات</button>
                    <a href="?step=form" class="btn btn-secondary" style="margin-right: 15px; padding: 15px 30px;">← انصراف</a>
                </div>
            </form>
            
            <!-- Live Preview -->
            <div style="margin-top: 40px;">
                <h3 style="margin-bottom: 20px; color: #2c3e50;">🔍 پیش‌نمایش زنده:</h3>
                <div class="preview">
                    <iframe id="livePreview" srcdoc="<?= h($editGame['code']) ?>" sandbox="allow-scripts allow-same-origin allow-forms"></iframe>
                </div>
                <div class="center">
                    <button onclick="updatePreview()" class="btn" style="padding: 12px 25px;">🔄 به‌روزرسانی پیش‌نمایش</button>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Error State -->
            <div class="center">
                <h3 style="color: #e74c3c; margin-bottom: 20px;">⚠️ مشکلی پیش آمده است</h3>
                <p style="color: #7f8c8d; margin-bottom: 30px;">لطفاً از ابتدا شروع کنید</p>
                <a href="?step=form" class="btn">🔄 شروع مجدد</a>
            </div>
        <?php endif; ?>
        
        <!-- User Games List -->
        <?php if (!empty($userGames) && $step !== 'edit'): ?>
            <div class="games-list">
                <h3 style="margin-bottom: 25px; color: #2c3e50; font-size: 1.5rem;">🎮 مجموعه بازی‌های شما</h3>
                
                <?php foreach ($userGames as $index => $game): ?>
                    <div class="game-item" style="animation-delay: <?= $index * 0.1 ?>s;">
                        <div style="flex: 1;">
                            <h4 style="color: #2c3e50; margin-bottom: 10px; font-size: 1.2rem; font-weight: 700;">
                                <?= h($game['title']) ?>
                            </h4>
                            <p style="color: #7f8c8d; font-size: 14px; margin-bottom: 8px; display: flex; align-items: center; gap: 15px;">
                                <span>📚 <?= h($game['lesson']) ?></span>
                                <span>📖 <?= h($game['topic']) ?></span>
                            </p>
                            <p style="color: #95a5a6; font-size: 12px; display: flex; align-items: center; gap: 8px;">
                                <span>📅 <?= date('Y/m/d', strtotime($game['created_at'])) ?></span>
                                <span>🕒 <?= date('H:i', strtotime($game['created_at'])) ?></span>
                            </p>
                        </div>
                        <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                            <button onclick="viewGame(<?= $game['id'] ?>)" class="btn" style="padding: 10px 18px; font-size: 14px; border-radius: 25px;">
                                👁️ مشاهده
                            </button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="game_id" value="<?= $game['id'] ?>">
                                <button type="submit" name="edit_game" class="btn btn-warning" style="padding: 10px 18px; font-size: 14px; border-radius: 25px;">
                                    ✏️ ویرایش
                                </button>
                            </form>
                            <button onclick="downloadGameCode(<?= $game['id'] ?>, '<?= h($game['title']) ?>')" class="btn btn-success" style="padding: 10px 18px; font-size: 14px; border-radius: 25px;">
                                📥 دانلود
                            </button>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('⚠️ آیا مطمئن هستید که می‌خواهید این بازی را حذف کنید؟')">
                                <input type="hidden" name="game_id" value="<?= $game['id'] ?>">
                                <button type="submit" name="delete_game" class="btn btn-danger" style="padding: 10px 18px; font-size: 14px; border-radius: 25px;">
                                    🗑️ حذف
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="center" style="margin-top: 50px; padding-top: 30px; border-top: 2px solid rgba(236, 240, 241, 0.5);">
            <p style="color: #95a5a6; font-size: 1rem; margin-bottom: 10px;">
                ساخته شده با ❤️ برای معلمان عزیز
            </p>
            <p style="color: #bdc3c7; font-size: 0.9rem;">
                نسخه پیشرفته با قابلیت‌های گرافیکی و تعاملی بالا
            </p>
        </div>
    </div>
    
    <script>
        // Enhanced JavaScript with new features
        
        function selectIdea(index) {
            // Remove selection from all cards
            document.querySelectorAll('.idea-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selection to clicked card with animation
            const selectedCard = document.querySelectorAll('.idea-card')[index];
            selectedCard.classList.add('selected');
            
            // Check the radio button
            document.querySelectorAll('input[name="selected_idea"]')[index].checked = true;
            
            // Enable create button with animation
            const createBtn = document.getElementById('createBtn');
            createBtn.disabled = false;
            createBtn.style.transform = 'scale(1.05)';
            setTimeout(() => {
                createBtn.style.transform = 'scale(1)';
            }, 200);
        }
        
        function downloadGame() {
            const code = document.getElementById('gameCode').value;
            const blob = new Blob([code], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'بازی_آموزشی_پیشرفته_' + new Date().toISOString().split('T')[0] + '.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            // Show success notification
            showNotification('✅ بازی با موفقیت دانلود شد!', 'success');
        }
        
        function copyCode() {
            const textarea = document.getElementById('gameCode');
            textarea.style.display = 'block';
            textarea.select();
            document.execCommand('copy');
            textarea.style.display = 'none';
            
            // Show success notification
            showNotification('✅ کد با موفقیت کپی شد!', 'success');
        }
        
        function shareGame() {
            if (navigator.share) {
                navigator.share({
                    title: 'بازی آموزشی پیشرفته',
                    text: 'بازی آموزشی خلاقانه‌ای که با بازی‌ساز هوشمند ساخته شده',
                    url: window.location.href
                });
            } else {
                // Fallback: copy URL to clipboard
                navigator.clipboard.writeText(window.location.href).then(() => {
                    showNotification('🔗 لینک کپی شد!', 'info');
                });
            }
        }
        
        function viewGame(gameId) {
            const popup = window.open(`view_game.php?id=${gameId}`, '_blank', 
                'width=1000,height=800,scrollbars=yes,resizable=yes,location=no,menubar=no,status=no,toolbar=no');
            
            if (!popup) {
                showNotification('⚠️ لطفاً popup blocker را غیرفعال کنید', 'warning');
            }
        }
        
        function downloadGameCode(gameId, title) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'download_game.php';
            form.target = '_blank';
            
            const gameIdInput = document.createElement('input');
            gameIdInput.type = 'hidden';
            gameIdInput.name = 'game_id';
            gameIdInput.value = gameId;
            
            form.appendChild(gameIdInput);
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
            
            showNotification('📥 دانلود آغاز شد...', 'info');
        }
        
        function updatePreview() {
            const codeTextarea = document.querySelector('textarea[name="game_code"]');
            const preview = document.getElementById('livePreview');
            
            if (codeTextarea && preview) {
                preview.srcdoc = codeTextarea.value;
                showNotification('🔄 پیش‌نمایش به‌روزرسانی شد', 'info');
            }
        }
        
        // Notification system
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.innerHTML = message;
            
            // Styling based on type
            const styles = {
                success: 'background: linear-gradient(135deg, #27ae60, #2ecc71); color: white;',
                error: 'background: linear-gradient(135deg, #e74c3c, #c0392b); color: white;',
                warning: 'background: linear-gradient(135deg, #f39c12, #e67e22); color: white;',
                info: 'background: linear-gradient(135deg, #3498db, #2980b9); color: white;'
            };
            
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 50px;
                font-weight: 600;
                z-index: 10000;
                transform: translateX(400px);
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                backdrop-filter: blur(10px);
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                ${styles[type]}
            `;
            
            document.body.appendChild(notification);
            
            // Animate in
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);
            
            // Auto remove
            setTimeout(() => {
                notification.style.transform = 'translateX(400px)';
                setTimeout(() => {
                    if (document.body.contains(notification)) {
                        document.body.removeChild(notification);
                    }
                }, 400);
            }, 3000);
        }
        
        // Auto-update preview while typing (with debounce)
        let previewTimeout;
        document.addEventListener('input', function(e) {
            if (e.target.name === 'game_code') {
                clearTimeout(previewTimeout);
                previewTimeout = setTimeout(updatePreview, 2000);
            }
        });
        
        // Enhanced loading states for form submissions
        document.addEventListener('submit', function(e) {
            const submitBtn = e.target.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                const originalText = submitBtn.innerHTML;
                const spinner = submitBtn.querySelector('.loading-spinner');
                
                submitBtn.disabled = true;
                
                if (spinner) {
                    spinner.style.display = 'inline-block';
                } else {
                    submitBtn.innerHTML = '⏳ در حال پردازش...';
                }
                
                // Progress simulation
                let progress = 0;
                const progressInterval = setInterval(() => {
                    progress += Math.random() * 20;
                    if (progress >= 100) {
                        clearInterval(progressInterval);
                        progress = 100;
                    }
                }, 500);
                
                // Re-enable after timeout as failsafe
                setTimeout(() => {
                    submitBtn.disabled = false;
                    if (spinner) {
                        spinner.style.display = 'none';
                    } else {
                        submitBtn.innerHTML = originalText;
                    }
                    clearInterval(progressInterval);
                }, 90000);
            }
        });
        
        // Enhanced animations on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Staggered animation for elements
            const elements = document.querySelectorAll('.form-section, .idea-card, .game-item');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                setTimeout(() => {
                    el.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, index * 150);
            });
            
            // Animate step navigation
            const stepBtns = document.querySelectorAll('.step-btn');
            stepBtns.forEach((btn, index) => {
                btn.style.opacity = '0';
                btn.style.transform = 'scale(0.8)';
                setTimeout(() => {
                    btn.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
                    btn.style.opacity = '1';
                    btn.style.transform = 'scale(1)';
                }, index * 100 + 200);
            });
            
            // Enhanced form interactions
            const inputs = document.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'translateY(-2px)';
                    this.parentElement.style.filter = 'drop-shadow(0 5px 15px rgba(52, 152, 219, 0.2))';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'translateY(0)';
                    this.parentElement.style.filter = 'none';
                });
            });
            
            // Add hover effects to buttons
            const buttons = document.querySelectorAll('.btn');
            buttons.forEach(btn => {
                btn.addEventListener('mouseenter', function() {
                    this.style.filter = 'brightness(1.1)';
                });
                
                btn.addEventListener('mouseleave', function() {
                    this.style.filter = 'brightness(1)';
                });
            });
        });
        
        // Advanced features
        
        // Auto-save form data
        function saveFormData() {
            const formData = new FormData(document.querySelector('form'));
            const data = Object.fromEntries(formData.entries());
            localStorage.setItem('gameCreatorFormData', JSON.stringify(data));
        }
        
        function loadFormData() {
            const savedData = localStorage.getItem('gameCreatorFormData');
            if (savedData) {
                const data = JSON.parse(savedData);
                Object.keys(data).forEach(key => {
                    const input = document.querySelector(`[name="${key}"]`);
                    if (input && input.type !== 'checkbox') {
                        input.value = data[key];
                    }
                });
            }
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl+S to save (if editing)
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                const saveBtn = document.querySelector('button[name="save_edit"]');
                if (saveBtn) {
                    saveBtn.click();
                }
            }
            
            // Ctrl+Enter to submit form
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                const submitBtn = document.querySelector('button[type="submit"]');
                if (submitBtn && !submitBtn.disabled) {
                    submitBtn.click();
                }
            }
        });
        
        // Initialize
        if (document.querySelector('form')) {
            loadFormData();
            document.addEventListener('input', saveFormData);
        }
        
        // Console welcome message
        console.log('%c🎮 بازی‌ساز هوشمند پیشرفته آماده است!', 
            'background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 10px 20px; border-radius: 10px; font-size: 16px; font-weight: bold;');
        console.log('%cویژگی‌های جدید: گرافیک پیشرفته، انیمیشن‌های روان، سیستم امتیازدهی، و بسیاری موارد دیگر!', 
            'color: #3498db; font-size: 14px;');
        
        // Performance monitoring
        window.addEventListener('load', function() {
            const loadTime = performance.now();
            console.log(`⚡ صفحه در ${Math.round(loadTime)}ms بارگذاری شد`);
        });
    </script>
</body>
</html>