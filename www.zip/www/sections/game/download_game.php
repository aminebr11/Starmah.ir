<?php
/* =============================================================
 * Download Game - دانلود بازی
 * فایل دانلود کد بازی‌ها
 * ============================================================= */

// Start session
if (session_status() === PHP_SESSION_NONE) { @session_start(); }

// Check access
if (!isset($_SESSION['user_id'])) {
    die('دسترسی غیرمجاز');
}

$gameId = (int)($_POST['game_id'] ?? $_GET['id'] ?? 0);
if (!$gameId) {
    die('شناسه بازی نامعتبر');
}

try {
    $db = new PDO("mysql:host=localhost:3306;dbname=qwaepiuv_starmah_db;charset=utf8mb4", 
                  'qwaepiuv_aminebr', 'Test12345!@#', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    $stmt = $db->prepare('SELECT * FROM games WHERE id = ? AND created_by = ?');
    $stmt->execute([$gameId, $_SESSION['user_id']]);
    $game = $stmt->fetch();
    
    if (!$game) {
        die('بازی یافت نشد یا دسترسی ندارید');
    }
    
    // Prepare safe filename
    $filename = preg_replace('/[^\w\s\-آ-ی]/u', '', $game['title']);
    $filename = trim($filename);
    if (empty($filename)) {
        $filename = 'بازی_آموزشی';
    }
    $filename .= '_' . date('Y-m-d_H-i') . '.html';
    
    // Set headers for download
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($game['code']));
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    // Output the game code
    echo $game['code'];
    
} catch (Exception $e) {
    die('خطا در دانلود: ' . $e->getMessage());
}
?>