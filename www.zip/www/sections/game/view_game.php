<?php
/* =============================================================
 * View Game - مشاهده بازی
 * فایل نمایش بازی‌ها
 * ============================================================= */

// Start session
if (session_status() === PHP_SESSION_NONE) { @session_start(); }

// Check access
if (!isset($_SESSION['user_id'])) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>خطا</title></head><body style="font-family:Tahoma;text-align:center;padding:50px;"><h3>دسترسی غیرمجاز</h3><p>لطفاً ابتدا وارد شوید.</p></body></html>');
}

$gameId = (int)($_GET['id'] ?? 0);
if (!$gameId) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>خطا</title></head><body style="font-family:Tahoma;text-align:center;padding:50px;"><h3>شناسه بازی نامعتبر</h3></body></html>');
}

try {
    $db = new PDO("mysql:host=localhost:3306;dbname=qwaepiuv_starmah_db;charset=utf8mb4", 
                  'qwaepiuv_aminebr', 'Test12345!@#', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    $stmt = $db->prepare('SELECT * FROM games WHERE id = ? AND created_by = ?');
    $stmt->execute([$gameId, $_SESSION['user_id']]);
    $game = $stmt->fetch();
    
    if (!$game) {
        die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>خطا</title></head><body style="font-family:Tahoma;text-align:center;padding:50px;"><h3>بازی یافت نشد</h3><p>شما دسترسی به این بازی ندارید.</p></body></html>');
    }
    
    // Output the game code directly
    echo $game['code'];
    
} catch (Exception $e) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>خطا</title></head><body style="font-family:Tahoma;text-align:center;padding:50px;"><h3>خطا در بارگیری</h3><p>' . htmlspecialchars($e->getMessage()) . '</p></body></html>');
}
?>