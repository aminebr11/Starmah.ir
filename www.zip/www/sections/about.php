<?php
// About section - Can be viewed by all
// Get about settings from database
 $aboutSettings = getAboutSettings($conn);
?>
<section id="about" class="section">
    <div class="about-hero">
        <div class="hero-content">
            <h1 class="about-title">درباره کلاس ستاره‌های درخشان</h1>
            <p class="about-subtitle">جایی که یادگیری با عشق و خلاقیت آمیخته می‌شود</p>
            
            <!-- ===== بخش لینک‌های راهنما (به‌روز شده) ===== -->
            <div class="help-links-container">
                <!-- دکمه راهنمای امتیازات -->
                <a href="sections/xp_help.php" class="help-link-button xp-help">
                    <span class="help-link-icon">🌟</span>
                    <div class="help-link-content">
                        <span class="help-link-text">چطور امتیاز بگیریم؟</span>
                        <span class="help-link-subtext">(راهنمای کامل قهرمانان)</span>
                    </div>
                </a>
                
                <!-- دکمه جدید: آشنایی با ستاره ماه -->
                <a href="sections/Starmah_power.php" class="help-link-button starmah-power">
                    <div class="power-glow"></div>
                    <span class="help-link-icon">🚀</span>
                    <div class="help-link-content">
                        <span class="help-link-text">سفر به دنیای ستاره ماه</span>
                        <span class="help-link-subtext">(قدرت و جادوی یادگیری)</span>
                    </div>
                    <div class="star-trail">
                        <span class="trail-star" style="animation-delay: 0s;">⭐</span>
                        <span class="trail-star" style="animation-delay: 0.5s;">✨</span>
                        <span class="trail-star" style="animation-delay: 1s;">🌟</span>
                    </div>
                </a>
            </div>
            <!-- ===== پایان بخش لینک‌های راهنما ===== -->

        </div>
        <div class="floating-stars">
            <span class="floating-star" style="animation-delay: 0s;">⭐</span>
            <span class="floating-star" style="animation-delay: 1s;">🌟</span>
            <span class="floating-star" style="animation-delay: 2s;">✨</span>
            <span class="floating-moon">🌙</span>
        </div>
    </div>
    
    <!-- Teacher Section -->
    <div class="teacher-section">
        <div class="teacher-card">
            <div class="teacher-image">
                <div class="teacher-photo">
                    <img src="images/naj.jpg" alt="معلم و دانش‌آموزان" />
                </div>
                           </div>
            <div class="teacher-info">
                <h2><?php echo htmlspecialchars($aboutSettings['teacher_name']); ?></h2>
                <p class="teacher-title"><?php echo htmlspecialchars($aboutSettings['teacher_title']); ?></p>
                <div class="teacher-details">
                    <div class="detail-item">
                        <span class="detail-icon">🎓</span>
                        <span><?php echo htmlspecialchars($aboutSettings['teacher_education']); ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">📚</span>
                        <span>بیش از یک دهه سابقه تدریس</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🏆</span>
                        <span>برنده جایزه معلم نمونه</span>
                    </div>
                </div>
                <div class="teacher-quote">
                    <p>"<?php echo htmlspecialchars($aboutSettings['teacher_quote']); ?>"</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Philosophy Section -->
    <div class="philosophy-section">
        <h2 class="section-title">فلسفه آموزشی ما</h2>
        <div class="philosophy-grid">
            <div class="philosophy-card">
                <div class="card-icon">🌱</div>
                <h3>رشد همه‌جانبه</h3>
                <p>ما به رشد تحصیلی، اجتماعی، عاطفی و اخلاقی دانش‌آموزان توجه داریم.</p>
            </div>
            <div class="philosophy-card">
                <div class="card-icon">🎨</div>
                <h3>خلاقیت و نوآوری</h3>
                <p>تشویق دانش‌آموزان به تفکر خلاق و یافتن راه‌حل‌های نوآورانه برای مسائل.</p>
            </div>
            <div class="philosophy-card">
                <div class="card-icon">🤝</div>
                <h3>یادگیری مشارکتی</h3>
                <p>ایجاد محیطی که دانش‌آموزان با همکاری یکدیگر یاد بگیرند و رشد کنند.</p>
            </div>
            <div class="philosophy-card">
                <div class="card-icon">💡</div>
                <h3>یادگیری با لذت</h3>
                <p>استفاده از بازی، داستان و فناوری برای جذاب‌تر کردن فرآیند یادگیری.</p>
            </div>
            <div class="philosophy-card">
                <div class="card-icon">⭐</div>
                <h3>کشف استعدادها</h3>
                <p>شناخت و پرورش استعدادهای منحصربه‌فرد هر دانش‌آموز و هدایت آن‌ها به سمت موفقیت.</p>
            </div>
            <div class="philosophy-card">
                <div class="card-icon">🌍</div>
                <h3>آموزش مسئولیت‌پذیری</h3>
                <p>تربیت شهروندان آگاه و مسئول که برای جامعه و محیط زیست احساس مسئولیت کنند.</p>
            </div>
        </div>
    </div>
    
    <!-- Goals Section -->
    <div class="goals-section">
        <h2 class="section-title">اهداف آموزشی سال تحصیلی</h2>
        <div class="goals-container">
            <div class="goal-item">
                <div class="goal-number">01</div>
                <div class="goal-content">
                    <h4>تقویت مهارت‌های پایه</h4>
                    <p>تسلط بر خواندن، نوشتن، و محاسبات ریاضی به عنوان پایه‌های اصلی یادگیری</p>
                </div>
            </div>
            <div class="goal-item">
                <div class="goal-number">02</div>
                <div class="goal-content">
                    <h4>پرورش تفکر انتقادی</h4>
                    <p>آموزش مهارت‌های حل مسئله و تحلیل اطلاعات به شیوه‌های خلاقانه</p>
                </div>
            </div>
            <div class="goal-item">
                <div class="goal-number">03</div>
                <div class="goal-content">
                    <h4>توسعه مهارت‌های اجتماعی</h4>
                    <p>یادگیری کار گروهی، احترام به دیگران و مسئولیت‌پذیری</p>
                </div>
            </div>
            <div class="goal-item">
                <div class="goal-number">04</div>
                <div class="goal-content">
                    <h4>افزایش اعتماد به نفس</h4>
                    <p>کمک به دانش‌آموزان برای باور به توانایی‌های خود و بیان آزادانه نظرات</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Class Features -->
    <div class="features-section">
        <h2 class="section-title">ویژگی‌های کلاس ما</h2>
        <div class="features-grid">
            <div class="feature-box">
                <div class="feature-icon">📱</div>
                <div class="feature-content">
                    <h4>فناوری آموزشی</h4>
                    <p>استفاده از تبلت‌های هوشمند و نرم‌افزارهای آموزشی تعاملی</p>
                </div>
            </div>
            <div class="feature-box">
                <div class="feature-icon">🌱</div>
                <div class="feature-content">
                    <h4>فعالیت‌های محیط زیستی</h4>
                    <p>انجام پروژه‌های سبز و آموزش حفاظت از محیط زیست</p>
                </div>
            </div>
            <div class="feature-box">
                <div class="feature-icon">📖</div>
                <div class="feature-content">
                    <h4>کتابخانه کلاسی</h4>
                    <p>مجموعه‌ای از کتاب‌های داستان و آموزشی مناسب سن دانش‌آموزان</p>
                </div>
            </div>
            <div class="feature-box">
                <div class="feature-icon">🎯</div>
                <div class="feature-content">
                    <h4>آموزش هدفمند</h4>
                    <p>برنامه‌ریزی شخصی برای هر دانش‌آموز بر اساس نیازها و استعدادهایش</p>
                </div>
            </div>
            <div class="feature-box">
                <div class="feature-icon">🎭</div>
                <div class="feature-content">
                    <h4>فعالیت‌های هنری</h4>
                    <p>نقاشی، کاردستی و نمایش برای پرورش خلاقیت</p>
                </div>
            </div>
            <div class="feature-box">
                <div class="feature-icon">🏃</div>
                <div class="feature-content">
                    <h4>ورزش و تحرک</h4>
                    <p>فعالیت‌های بدنی منظم برای سلامت جسم و روح</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Parents Section -->
    <div class="parents-section">
        <h2 class="section-title">نقش والدین</h2>
        <div class="parents-content">
            <div class="parents-text">
                <h3>همراهی شما، کلید موفقیت فرزندتان</h3>
                <p>ما معتقدیم که والدین شریک اصلی ما در فرآیند آموزش هستند. با همکاری و هماهنگی میان خانه و مدرسه، می‌توانیم بهترین نتایج را برای فرزندان عزیزمان رقم بزنیم.</p>
                <ul class="parents-list">
                    <li>شرکت در جلسات والدین</li>
                    <li>پیگیری تکالیف و فعالیت‌های درسی</li>
                    <li>ارائه بازخورد سازنده</li>
                    <li>مشارکت در برنامه‌های کلاسی</li>
                </ul>
            </div>
            <div class="parents-image">
                <div class="parents-photo">
                    <img src="images/parent.jpg" alt="والدین و فرزندان" />
                </div>
            </div>
        </div>
    </div>
    
    <!-- Contact Section -->
    <div class="contact-section">
        <h2 class="section-title">ارتباط با ما</h2>
        <div class="contact-cards">
            <div class="contact-card">
                <div class="contact-icon">📍</div>
                <h4>آدرس</h4>
                <p>تهران، نیاوران، دبستان فرزانه 3</p>
            </div>
            <div class="contact-card">
                <div class="contact-icon">📞</div>
                <h4>تلفن</h4>
                <p>02126452784</p>
            </div>
            <div class="contact-card">
                <div class="contact-icon">📧</div>
                <h4>ایمیل</h4>
                <p>info@starmah.ir</p>
            </div>
            <div class="contact-card">
                <div class="contact-icon">🕐</div>
                <h4>ساعات پاسخگویی</h4>
                <p>شنبه تا چهارشنبه<br>ساعت 8 تا 13</p>
            </div>
        </div>
    </div>
</section>

<style>
/* About Page Modern Design */
.about-hero {
    background: linear-gradient(135deg, 
        rgba(255, 107, 107, 0.1) 0%, 
        rgba(138, 43, 226, 0.1) 50%, 
        rgba(0, 191, 255, 0.1) 100%);
    padding: 4rem 2rem;
    border-radius: 25px;
    text-align: center;
    margin-bottom: 3rem;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
}

.about-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, 
        rgba(255, 255, 255, 0.1) 0%, 
        transparent 50%, 
        rgba(255, 255, 255, 0.05) 100%);
    border-radius: 25px;
}

.hero-content {
    position: relative;
    z-index: 2;
}

.about-title {
    font-size: 3.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #FF6B6B, #4ECDC4, #45B7D1);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1rem;
    animation: fadeInUp 1s ease;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.about-subtitle {
    font-size: 1.4rem;
    color: #666;
    font-weight: 500;
    animation: fadeInUp 1s ease 0.2s;
    animation-fill-mode: both;
}

.floating-stars {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    pointer-events: none;
}

.floating-star, .floating-moon {
    position: absolute;
    font-size: 2.5rem;
    animation: floatAround 20s infinite ease-in-out;
    filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.5));
}

.floating-moon {
    font-size: 3.5rem;
    top: 20px;
    right: 50px;
}

@keyframes floatAround {
    0%, 100% {
        transform: translateY(0) translateX(0) rotate(0deg);
    }
    25% {
        transform: translateY(-30px) translateX(20px) rotate(90deg);
    }
    50% {
        transform: translateY(20px) translateX(-30px) rotate(180deg);
    }
    75% {
        transform: translateY(-20px) translateX(30px) rotate(270deg);
    }
}

/* ===== بخش استایل لینک‌های راهنما (به‌روز شده) ===== */
.help-links-container {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    justify-content: center;
    margin-top: 2.5rem;
    animation: fadeInUp 1s ease 0.4s;
    animation-fill-mode: both;
}

.help-link-button {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 15px 35px;
    border-radius: 50px;
    text-decoration: none;
    font-weight: 700;
    font-size: 1.1rem;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    min-width: 280px;
    max-width: 350px;
}

/* دکمه راهنمای امتیازات */
.help-link-button.xp-help {
    background: linear-gradient(135deg, var(--sunshine-yellow, #FFD93D), #FFA500);
    color: #333;
    box-shadow: 0 8px 25px rgba(255, 215, 0, 0.4);
}

.help-link-button.xp-help:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 12px 35px rgba(255, 165, 0, 0.5);
    color: #222;
}

/* دکمه جدید: آشنایی با ستاره ماه */
.help-link-button.starmah-power {
    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
    color: white;
    box-shadow: 0 8px 25px rgba(37, 117, 252, 0.4);
}

.help-link-button.starmah-power:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 12px 35px rgba(106, 17, 203, 0.6);
    color: white;
}

.power-glow {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle at center, rgba(255, 255, 255, 0.3) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.help-link-button.starmah-power:hover .power-glow {
    opacity: 1;
}

.star-trail {
    position: absolute;
    left: -15px;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    flex-direction: column;
    gap: 5px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.help-link-button.starmah-power:hover .star-trail {
    opacity: 1;
}

.trail-star {
    font-size: 1rem;
    animation: trailFloat 2s infinite ease-in-out;
}

@keyframes trailFloat {
    0%, 100% {
        transform: translateX(0);
        opacity: 0.7;
    }
    50% {
        transform: translateX(-10px);
        opacity: 1;
    }
}

.help-link-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
    transition: left 0.5s;
}

.help-link-button:hover::before {
    left: 100%;
}

.help-link-icon {
    font-size: 1.5rem;
    animation: pulse 2s infinite;
}

.help-link-content {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.help-link-text {
    font-size: 1.2rem;
    line-height: 1.2;
}

.help-link-subtext {
    font-size: 0.9rem;
    opacity: 0.8;
    font-weight: 500;
}
/* ===== پایان بخش استایل لینک‌های راهنما ===== */


/* Teacher Section */
.teacher-section {
    margin: 4rem 0;
}

.teacher-card {
    background: linear-gradient(135deg, 
        rgba(255, 255, 255, 0.95) 0%, 
        rgba(248, 249, 250, 0.95) 100%);
    border-radius: 25px;
    padding: 3rem;
    box-shadow: 
        0 20px 60px rgba(0, 0, 0, 0.1),
        0 4px 16px rgba(0, 0, 0, 0.05);
    display: grid;
    grid-template-columns: 320px 1fr;
    gap: 3rem;
    align-items: center;
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
}

.teacher-image {
    text-align: center;
    position: relative;
}

.teacher-photo {
    width: 220px;
    height: 220px;
    border-radius: 50%;
    overflow: hidden;
    margin: 0 auto;
    border: 6px solid transparent;
    background: linear-gradient(135deg, #FF6B6B, #4ECDC4);
    padding: 6px;
    box-shadow: 0 15px 35px rgba(255, 107, 107, 0.3);
}

.teacher-photo img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.teacher-badge {
    background: linear-gradient(135deg, #FFD700, #FFA500);
    color: #333;
    padding: 0.8rem 1.5rem;
    border-radius: 25px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    font-weight: bold;
    font-size: 0.9rem;
    box-shadow: 0 8px 20px rgba(255, 215, 0, 0.4);
    border: 2px solid rgba(255, 255, 255, 0.8);
}

.teacher-info h2 {
    color: #2c3e50;
    font-size: 2.2rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.teacher-title {
    color: #7f8c8d;
    font-size: 1.3rem;
    font-weight: 500;
    margin-bottom: 2rem;
}

.teacher-details {
    display: grid;
    gap: 1.2rem;
    margin-bottom: 2rem;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 15px;
    backdrop-filter: blur(5px);
    transition: all 0.3s ease;
}

.detail-item:hover {
    transform: translateX(5px);
    background: rgba(255, 255, 255, 0.8);
}

.detail-icon {
    font-size: 1.8rem;
    filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
}

.teacher-quote {
    background: linear-gradient(135deg, 
        rgba(240, 248, 255, 0.9) 0%, 
        rgba(230, 247, 255, 0.9) 100%);
    padding: 2rem;
    border-radius: 20px;
    border-right: 5px solid #4ECDC4;
    position: relative;
    overflow: hidden;
}

.teacher-quote::before {
    content: '"';
    position: absolute;
    top: -10px;
    left: 15px;
    font-size: 4rem;
    color: rgba(78, 205, 196, 0.3);
    font-family: Georgia, serif;
}

.teacher-quote p {
    font-style: italic;
    color: #555;
    line-height: 1.8;
    font-size: 1.1rem;
}

/* Philosophy Section */
.philosophy-section {
    background: linear-gradient(135deg, 
        rgba(245, 246, 250, 0.8) 0%, 
        rgba(255, 255, 255, 0.9) 100%);
    padding: 4rem 2rem;
    border-radius: 25px;
    margin: 4rem 0;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.section-title {
    text-align: center;
    font-size: 2.8rem;
    font-weight: 700;
    background: linear-gradient(135deg, #FF6B6B, #4ECDC4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 3rem;
}

.philosophy-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
}

.philosophy-card {
    background: linear-gradient(135deg, 
        rgba(255, 255, 255, 0.95) 0%, 
        rgba(248, 249, 250, 0.95) 100%);
    padding: 2.5rem;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
    position: relative;
    overflow: hidden;
}

.philosophy-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, 
        transparent 0%, 
        rgba(255, 255, 255, 0.4) 50%, 
        transparent 100%);
    transition: left 0.6s ease;
}

.philosophy-card:hover {
    transform: translateY(-15px) scale(1.02);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
}

.philosophy-card:hover::before {
    left: 100%;
}

.card-icon {
    font-size: 3.5rem;
    margin-bottom: 1.5rem;
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
}

.philosophy-card h3 {
    color: #2c3e50;
    font-size: 1.3rem;
    font-weight: 600;
    margin-bottom: 1rem;
}

.philosophy-card p {
    color: #666;
    line-height: 1.7;
    font-size: 0.95rem;
}

/* Goals Section */
.goals-section {
    margin: 4rem 0;
}

.goals-container {
    display: grid;
    gap: 2rem;
    max-width: 900px;
    margin: 0 auto;
}

.goal-item {
    display: flex;
    align-items: center;
    gap: 2.5rem;
    background: linear-gradient(135deg, 
        rgba(255, 255, 255, 0.95) 0%, 
        rgba(248, 249, 250, 0.95) 100%);
    padding: 2.5rem;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: all 0.4s ease;
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
}

.goal-item:hover {
    transform: translateX(-15px);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
}

.goal-number {
    font-size: 4rem;
    font-weight: 800;
    background: linear-gradient(135deg, #FF6B6B, #4ECDC4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    opacity: 0.8;
    min-width: 80px;
}

.goal-content h4 {
    color: #2c3e50;
    font-size: 1.4rem;
    font-weight: 600;
    margin-bottom: 0.8rem;
}

.goal-content p {
    color: #666;
    line-height: 1.7;
    font-size: 1rem;
}

/* Features Section */
.features-section {
    background: linear-gradient(135deg, 
        rgba(224, 242, 233, 0.6) 0%, 
        rgba(230, 230, 250, 0.6) 100%);
    padding: 4rem 2rem;
    border-radius: 25px;
    margin: 4rem 0;
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 2rem;
}

.feature-box {
    background: linear-gradient(135deg, 
        rgba(255, 255, 255, 0.95) 0%, 
        rgba(248, 249, 250, 0.95) 100%);
    padding: 2rem;
    border-radius: 18px;
    display: flex;
    align-items: flex-start;
    gap: 1.5rem;
    transition: all 0.4s ease;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
}

.feature-box:hover {
    transform: scale(1.05);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
}

.feature-icon {
    font-size: 2.8rem;
    flex-shrink: 0;
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
}

.feature-content h4 {
    color: #2c3e50;
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 0.8rem;
}

.feature-content p {
    color: #666;
    font-size: 0.95rem;
    line-height: 1.6;
}

/* Parents Section */
.parents-section {
    background: linear-gradient(135deg, 
        rgba(248, 249, 250, 0.8) 0%, 
        rgba(255, 255, 255, 0.9) 100%);
    padding: 4rem 2rem;
    border-radius: 25px;
    margin: 4rem 0;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.parents-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    align-items: center;
}

.parents-text h3 {
    color: #2c3e50;
    font-size: 2rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
}

.parents-text p {
    color: #666;
    line-height: 1.8;
    font-size: 1rem;
    margin-bottom: 2rem;
}

.parents-list {
    list-style: none;
    padding: 0;
}

.parents-list li {
    color: #555;
    padding: 0.8rem 0;
    padding-right: 2.5rem;
    position: relative;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.parents-list li:before {
    content: "✨";
    position: absolute;
    right: 0;
    font-size: 1.2rem;
    animation: sparkle 2s ease-in-out infinite;
}

.parents-list li:hover {
    color: #2c3e50;
    transform: translateX(5px);
}

.parents-image {
    text-align: center;
}

.parents-photo {
    width: 320px;
    height: 320px;
    border-radius: 25px;
    overflow: hidden;
    margin: 0 auto;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
    border: 3px solid rgba(255, 255, 255, 0.8);
    background: linear-gradient(135deg, 
        rgba(255, 228, 225, 0.8) 0%, 
        rgba(224, 242, 233, 0.8) 100%);
}

.parents-photo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.parents-photo:hover img {
    transform: scale(1.05);
}

/* Contact Section */
.contact-section {
    margin: 4rem 0;
}

.contact-cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
}

.contact-card {
    background: linear-gradient(135deg, 
        rgba(255, 255, 255, 0.95) 0%, 
        rgba(248, 249, 250, 0.95) 100%);
    padding: 1.8rem 1.2rem;
    border-radius: 18px;
    text-align: center;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    transition: all 0.4s ease;
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
    position: relative;
    overflow: hidden;
}

.contact-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(45deg, 
        transparent 30%, 
        rgba(255, 255, 255, 0.1) 50%, 
        transparent 70%);
    transform: rotate(45deg);
    transition: all 0.6s ease;
    opacity: 0;
}

.contact-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
}

.contact-card:hover::before {
    opacity: 1;
    transform: rotate(45deg) translate(50%, 50%);
}

.contact-icon {
    font-size: 2.8rem;
    margin-bottom: 1rem;
    filter: drop-shadow(0 3px 6px rgba(0, 0, 0, 0.1));
}

.contact-card h4 {
    color: #2c3e50;
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 0.8rem;
}

.contact-card p {
    color: #666;
    margin: 0.3rem 0;
    font-size: 0.9rem;
    line-height: 1.5;
}

/* Animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes sparkle {
    0%, 100% { 
        opacity: 1; 
        transform: scale(1);
    }
    50% { 
        opacity: 0.5; 
        transform: scale(1.2);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .about-title {
        font-size: 2.5rem;
    }
    
    .about-subtitle {
        font-size: 1.1rem;
    }
    
    .teacher-card {
        grid-template-columns: 1fr;
        text-align: center;
        padding: 2rem;
    }
    
    .teacher-photo {
        width: 180px;
        height: 180px;
    }
    
    .philosophy-grid,
    .features-grid {
        grid-template-columns: 1fr;
    }
    
    .parents-content {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .goal-item {
        flex-direction: column;
        text-align: center;
        gap: 1.5rem;
    }
    
    .goal-number {
        font-size: 3rem;
    }
    
    .contact-cards {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    
    .contact-card {
        padding: 1.5rem 1rem;
    }
    
    .contact-icon {
        font-size: 2.5rem;
    }
    
    .image-placeholder {
        width: 250px;
        height: 250px;
        font-size: 6rem;
    }
    
    .parents-photo {
        width: 250px;
        height: 250px;
    }
}

@media (max-width: 1024px) {
    .contact-cards {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.2rem;
    }
}

@media (max-width: 480px) {
    .contact-cards {
        grid-template-columns: 1fr;
    }
    
    .contact-card {
        padding: 1.2rem 0.8rem;
    }
    
    .contact-icon {
        font-size: 2.2rem;
    }
    
    .about-hero {
        padding: 2rem 1rem;
    }
    
    .teacher-card,
    .philosophy-section,
    .features-section,
    .parents-section {
        padding: 2rem 1rem;
    }
}
</style>