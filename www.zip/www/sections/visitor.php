<?php
// sections/visitor.php
// Session check
if (session_status() === PHP_SESSION_NONE) { 
    @session_start(); 
}
require_once '../config.php';
require_once '../functions.php';

$db = $conn;

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$isLoggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? '';
$userName = $_SESSION['user_name'] ?? 'کاربر';

// تنظیمات صفحه‌بندی
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// فیلترها
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$user_type_filter = isset($_GET['user_type']) ? $_GET['user_type'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

// ساخت کوئری با فیلترها
$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR v.ip_address LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
}

if (!empty($date_from)) {
    $where_conditions[] = "DATE(v.visit_date) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $where_conditions[] = "DATE(v.visit_date) <= ?";
    $params[] = $date_to;
}

if (!empty($user_type_filter)) {
    $where_conditions[] = "u.user_type = ?";
    $params[] = $user_type_filter;
}

if (!empty($status)) {
    $where_conditions[] = "u.is_active = ?";
    $params[] = ($status === 'active') ? 1 : 0;
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// آمار کلی - اصلاح شده برای جدول visits
function getVisitorStats($conn) {
    $stats = [];
    
    try {
        // تست اتصال دیتابیس
        $stmt = $conn->prepare("SELECT 1");
        $stmt->execute();
        
        // کل بازدیدها
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM visits");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['total_visitors'] = $result['total'] ?? 0;
        
        // بازدیدکنندگان امروز
        $stmt = $conn->prepare("SELECT COUNT(*) as today FROM visits WHERE DATE(visit_date) = CURDATE()");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['today_visitors'] = $result['today'] ?? 0;
        
        // دانش‌آموزان فعال
        $stmt = $conn->prepare("SELECT COUNT(*) as active_students FROM users WHERE user_type = 'student' AND is_active = 1");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['active_students'] = $result['active_students'] ?? 0;
        
        // آنلاین اکنون - بررسی heartbeat-based
        $stmt = $conn->prepare("
            SELECT COUNT(DISTINCT v.user_id) as online_now 
            FROM visits v 
            WHERE v.user_id IS NOT NULL 
            AND v.visit_date >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
            AND NOT EXISTS (
                SELECT 1 FROM visits v2 
                WHERE v2.user_id = v.user_id 
                AND v2.user_agent LIKE 'LOGOUT%' 
                AND v2.visit_date > v.visit_date
            )
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['online_now'] = $result['online_now'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("Error getting visitor stats: " . $e->getMessage());
        // در صورت خطا، مقادیر پیش‌فرض
        $stats = ['total_visitors' => 0, 'today_visitors' => 0, 'active_students' => 0, 'online_now' => 0];
    }
    
    return $stats;
}

// گرفتن آمار
$stats = getVisitorStats($conn);

// گرفتن داده‌های بازدیدکنندگان - اصلاح شده برای جدول visits
try {
    // ابتدا تست می‌کنیم که آیا جداول وجود دارند
    $test_query = "SHOW TABLES LIKE 'users'";
    $test_stmt = $conn->prepare($test_query);
    $test_stmt->execute();
    $users_exists = $test_stmt->rowCount() > 0;
    
    $test_query = "SHOW TABLES LIKE 'visits'";
    $test_stmt = $conn->prepare($test_query);
    $test_stmt->execute();
    $visits_exists = $test_stmt->rowCount() > 0;
    
    if (!$users_exists || !$visits_exists) {
        throw new Exception("جداول مورد نیاز یافت نشدند");
    }
    
    // کوئری اصلی - اصلاح شده برای حل مشکل NULL و آنلاین
    $sql = "SELECT 
        u.id as user_id,
        u.username,
        u.first_name,
        u.last_name,
        u.email,
        u.user_type,
        u.is_active,
        u.avatar,
        u.last_login,
        u.created_at,
        u.national_id,
        u.birth_date,
        u.father_name,
        u.father_phone,
        u.mother_name,
        u.mother_phone,
        u.address,
        COALESCE((SELECT v1.ip_address FROM visits v1 WHERE v1.user_id = u.id ORDER BY v1.visit_date DESC LIMIT 1), 'بازدیدی نداشته') as ip_address,
        COALESCE((SELECT v2.user_agent FROM visits v2 WHERE v2.user_id = u.id ORDER BY v2.visit_date DESC LIMIT 1), 'نامشخص') as user_agent,
        (SELECT v3.visit_date FROM visits v3 WHERE v3.user_id = u.id ORDER BY v3.visit_date DESC LIMIT 1) as visit_date,
        COALESCE((SELECT COUNT(*) FROM visits v4 WHERE v4.user_id = u.id), 0) as visit_count,
        CASE 
            WHEN EXISTS(
                SELECT 1 FROM visits v5 
                WHERE v5.user_id = u.id 
                AND v5.visit_date >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                AND NOT EXISTS (
                    SELECT 1 FROM visits v6 
                    WHERE v6.user_id = v5.user_id 
                    AND v6.user_agent LIKE 'LOGOUT%' 
                    AND v6.visit_date > v5.visit_date
                )
            ) 
            THEN 1 ELSE 0 
        END as is_online
    FROM users u
    $where_clause
    ORDER BY is_online DESC, 
             COALESCE((SELECT v6.visit_date FROM visits v6 WHERE v6.user_id = u.id ORDER BY v6.visit_date DESC LIMIT 1), u.last_login, u.created_at) DESC
    LIMIT $limit OFFSET $offset";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $visitors = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // کل تعداد رکوردها برای صفحه‌بندی
    $count_sql = "SELECT COUNT(*) as total FROM users u $where_clause";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->execute($params);
    $total_records = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    $total_pages = ceil($total_records / $limit);

} catch (Exception $e) {
    error_log("Error getting visitors: " . $e->getMessage());
    $visitors = [];
    $total_records = 0;
    $total_pages = 1;
    $error_message = $e->getMessage();
}

// پردازش درخواست‌های AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    $user_id = (int)($_POST['user_id'] ?? 0);
    
    switch ($action) {
        case 'get_live_stats':
            // گرفتن آمار زنده
            $live_stats = getVisitorStats($conn);
            
            // گرفتن لیست کاربران آنلاین با بررسی دقیق‌تر
            $stmt = $conn->prepare("
                SELECT DISTINCT u.id, u.username, u.first_name, u.last_name
                FROM visits v 
                JOIN users u ON v.user_id = u.id 
                WHERE v.user_id IS NOT NULL 
                AND v.visit_date >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                AND NOT EXISTS (
                    SELECT 1 FROM visits v2 
                    WHERE v2.user_id = v.user_id 
                    AND v2.user_agent LIKE 'LOGOUT%' 
                    AND v2.visit_date > v.visit_date
                )
                ORDER BY u.username
            ");
            $stmt->execute();
            $online_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $live_stats['online_users'] = $online_users;
            echo json_encode($live_stats);
            exit;
            
        case 'ping_online':
            // ثبت ping برای نگه داشتن کاربر آنلاین
            if (isset($_SESSION['user_id'])) {
                $current_user_id = $_SESSION['user_id'];
                $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                $user_agent = 'PING - ' . ($_SERVER['HTTP_USER_AGENT'] ?? '');
                
                $stmt = $conn->prepare("INSERT INTO visits (user_id, ip_address, user_agent, visit_date) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$current_user_id, $ip_address, $user_agent]);
                
                echo json_encode(['success' => true, 'user_id' => $current_user_id]);
            } else {
                echo json_encode(['success' => false]);
            }
            exit;
        case 'toggle_user_status':
            try {
                $new_status = (int)($_POST['status'] ?? 0);
                $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                $result = $stmt->execute([$new_status, $user_id]);
                echo json_encode(['success' => $result]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
            exit;
            
        case 'delete_user_data':
            try {
                $conn->beginTransaction();
                
                // حذف رکوردهای بازدید
                $stmt1 = $conn->prepare("DELETE FROM visits WHERE user_id = ?");
                $stmt1->execute([$user_id]);
                
                // حذف کاربر (اگر ادمین فعلی نباشد)
                if ($user_id != $_SESSION['user_id']) {
                    $stmt2 = $conn->prepare("DELETE FROM users WHERE id = ?");
                    $stmt2->execute([$user_id]);
                }
                
                $conn->commit();
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                $conn->rollBack();
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
            exit;
            
        case 'get_user_details':
            try {
                $stmt = $conn->prepare("
                    SELECT u.*, 
                    COUNT(v.id) as total_visits,
                    MAX(v.visit_date) as last_visit,
                    MIN(v.visit_date) as first_visit
                    FROM users u 
                    LEFT JOIN visits v ON u.id = v.user_id 
                    WHERE u.id = ? 
                    GROUP BY u.id
                ");
                $stmt->execute([$user_id]);
                $user_details = $stmt->fetch();
                echo json_encode($user_details ?: []);
            } catch (PDOException $e) {
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;
            
        case 'clear_old_visits':
            try {
                $days = (int)($_POST['days'] ?? 180);
                $stmt = $conn->prepare("DELETE FROM visits WHERE visit_date < DATE_SUB(NOW(), INTERVAL ? DAY)");
                $result = $stmt->execute([$days]);
                $affected = $stmt->rowCount();
                echo json_encode(['success' => $result, 'deleted_count' => $affected]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
            exit;
    }
}

// خروجی CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    try {
        $export_sql = "SELECT 
            u.username,
            u.first_name,
            u.last_name,
            u.email,
            u.user_type,
            u.national_id,
            u.is_active,
            v.ip_address,
            v.visit_date,
            COUNT(v.id) as visit_count
        FROM users u
        LEFT JOIN visitors v ON u.id = v.user_id
        $where_clause
        GROUP BY u.id
        ORDER BY v.visit_date DESC";
        
        $export_stmt = $conn->prepare($export_sql);
        $export_stmt->execute($params);
        $export_data = $export_stmt->fetchAll();
        
        // تنظیم هدرهای CSV
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="visitors_' . date('Y-m-d') . '.csv"');
        
        // BOM برای نمایش صحیح فارسی در Excel
        echo "\xEF\xBB\xBF";
        
        $output = fopen('php://output', 'w');
        
        // هدر CSV
        fputcsv($output, ['نام کاربری', 'نام', 'نام خانوادگی', 'ایمیل', 'نوع کاربر', 'کد ملی', 'وضعیت', 'IP', 'آخرین بازدید', 'تعداد بازدید'], ';');
        
        // داده‌ها
        foreach ($export_data as $row) {
            fputcsv($output, [
                $row['username'],
                $row['first_name'],
                $row['last_name'],
                $row['email'] ?? '',
                $row['user_type'] === 'student' ? 'دانش‌آموز' : 'مدیر',
                $row['national_id'],
                $row['is_active'] ? 'فعال' : 'غیرفعال',
                $row['ip_address'] ?? '',
                $row['visit_date'] ? date('Y/m/d H:i', strtotime($row['visit_date'])) : '',
                $row['visit_count']
            ], ';');
        }
        
        fclose($output);
        exit;
        
    } catch (PDOException $e) {
        error_log("Export error: " . $e->getMessage());
        header('Location: visitor.php?error=export_failed');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت بازدیدکنندگان - <?php echo SITE_NAME; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .page-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
            transform: translateX(-100%);
            transition: transform 0.6s;
        }

        .page-header:hover::before {
            transform: translateX(100%);
        }

        .page-header h1 {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 10px;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            color: rgba(255, 255, 255, 0.8);
            text-align: center;
            font-size: 1.1rem;
            position: relative;
            z-index: 1;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 15px 35px rgba(31, 38, 135, 0.5);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
            transform: translateX(-100%);
            transition: transform 0.6s;
        }

        .stat-card:hover::before {
            transform: translateX(100%);
        }

        .stat-icon {
            font-size: 3.5rem;
            margin-bottom: 15px;
            display: block;
            z-index: 1;
            position: relative;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: white;
            margin-bottom: 5px;
            z-index: 1;
            position: relative;
        }

        .stat-label {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1rem;
            z-index: 1;
            position: relative;
        }

        .control-panel {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }

        .control-row {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 15px;
        }

        .control-row:last-child {
            margin-bottom: 0;
        }

        .search-box, .date-filter, .filter-select {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            padding: 12px 15px;
            color: white;
            font-size: 14px;
            min-width: 200px;
            transition: all 0.3s ease;
        }

        .search-box:focus, .date-filter:focus, .filter-select:focus {
            background: rgba(255, 255, 255, 0.3);
            outline: none;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
        }

        .search-box::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .filter-select option {
            background: #2c3e50;
            color: white;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
        }

        .btn-success {
            background: linear-gradient(135deg, #2ed573 0%, #1e90ff 100%);
        }

        .table-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            overflow-x: auto;
        }

        .visitors-table {
            width: 100%;
            border-collapse: collapse;
            color: white;
            min-width: 1000px;
        }

        .visitors-table th {
            background: rgba(255, 255, 255, 0.2);
            padding: 15px 10px;
            text-align: right;
            font-weight: bold;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3);
            font-size: 14px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .visitors-table td {
            padding: 12px 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            vertical-align: middle;
            font-size: 13px;
        }

        .visitors-table tr:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: scale(1.01);
            transition: all 0.2s ease;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }

        .user-avatar:hover {
            transform: scale(1.2);
            border-color: rgba(255, 255, 255, 0.8);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .status-active {
            background: rgba(46, 213, 115, 0.3);
            color: #2ed573;
            border: 1px solid #2ed573;
        }

        .status-inactive {
            background: rgba(255, 107, 107, 0.3);
            color: #ff6b6b;
            border: 1px solid #ff6b6b;
        }

        .user-type {
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .type-student {
            background: rgba(30, 144, 255, 0.3);
            color: #1e90ff;
        }

        .type-admin {
            background: rgba(255, 165, 0, 0.3);
            color: #ffa500;
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .pagination a {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            padding: 8px 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .pagination a:hover, .pagination a.active {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .action-btn {
            background: transparent;
            border: none;
            color: white;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 0 2px;
            font-size: 18px;
        }

        .action-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.2);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            backdrop-filter: blur(5px);
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            color: white;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .close {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 24px;
            cursor: pointer;
            color: white;
            transition: all 0.3s ease;
        }

        .close:hover {
            transform: scale(1.2);
            color: #ff6b6b;
        }

        .back-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            color: white;
            cursor: pointer;
            margin-bottom: 20px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateX(-5px);
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px;
            color: white;
            animation: slideIn 0.5s ease;
        }

        .alert-success {
            background: rgba(46, 213, 115, 0.2);
            border: 1px solid #2ed573;
        }

        .alert-error {
            background: rgba(255, 107, 107, 0.2);
            border: 1px solid #ff6b6b;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .no-data {
            text-align: center;
            padding: 60px;
            color: rgba(255,255,255,0.7);
            font-size: 1.1rem;
        }

        .no-data::before {
            content: "😔";
            display: block;
            font-size: 4rem;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .page-header h1 {
                font-size: 2rem;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .control-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box, .date-filter, .filter-select {
                min-width: auto;
                width: 100%;
            }
            
            .visitors-table {
                font-size: 11px;
                min-width: 800px;
            }
            
            .visitors-table th,
            .visitors-table td {
                padding: 6px 4px;
            }
            
            .stat-icon {
                font-size: 2.5rem;
            }
        }

        .loading {
            text-align: center;
            padding: 40px;
            color: rgba(255, 255, 255, 0.8);
        }

        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid white;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        @keyframes slideInRight {
            from {
                transform: translateX(300px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(300px);
                opacity: 0;
            }
        }

        .pulse-online {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- دکمه برگشت -->
        <a href="<?php echo SITE_URL; ?>" class="back-btn">← بازگشت به صفحه اصلی</a>

        <!-- نمایش پیام‌های خطا یا موفقیت -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">عملیات با موفقیت انجام شد!</div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">خطا در انجام عملیات!</div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-error">خطا: <?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <!-- Debug Info بهبود یافته -->
        <?php if (isset($_GET['debug'])): ?>
        <div class="alert" style="background: rgba(255, 255, 0, 0.2); border: 1px solid yellow;">
            <h3>اطلاعات دیباگ کامل:</h3>
            <?php
            try {
                echo "<p>✅ اتصال به دیتابیس موفق</p>";
                echo "<p>🔑 کاربر جاری: " . $_SESSION['user_id'] . " (نوع: " . $_SESSION['user_type'] . ")</p>";
                
                // تست جدول users
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users");
                $stmt->execute();
                $users_count = $stmt->fetch()['count'];
                echo "<p>👥 تعداد کل کاربران: " . $users_count . "</p>";
                
                // تست جدول visits
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM visits");
                $stmt->execute();
                $visits_count = $stmt->fetch()['count'];
                echo "<p>👁️ تعداد کل بازدیدها: " . $visits_count . "</p>";
                
                // کاربران فعال
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
                $stmt->execute();
                $active_users = $stmt->fetch()['count'];
                echo "<p>✅ کاربران فعال: " . $active_users . "</p>";
                
                // آخرین بازدیدها
                $stmt = $conn->prepare("SELECT v.*, u.username FROM visits v LEFT JOIN users u ON v.user_id = u.id ORDER BY v.visit_date DESC LIMIT 10");
                $stmt->execute();
                $recent_visits = $stmt->fetchAll();
                echo "<p>🕐 آخرین 10 بازدید:</p>";
                echo "<div style='max-height: 200px; overflow-y: scroll; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 5px;'>";
                foreach($recent_visits as $visit) {
                    $username = $visit['username'] ? $visit['username'] : 'مهمان';
                    echo "<small>👤 " . $username . " | User ID: " . ($visit['user_id'] ?: 'null') . " | IP: " . $visit['ip_address'] . " | تاریخ: " . $visit['visit_date'] . "</small><br>";
                }
                echo "</div>";
                
                // کاربران آنلاین - بروزرسانی برای 2 دقیقه
                $stmt = $conn->prepare("
                    SELECT DISTINCT v.user_id, u.username, v.visit_date
                    FROM visits v 
                    JOIN users u ON v.user_id = u.id 
                    WHERE v.user_id IS NOT NULL 
                    AND v.visit_date >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                    AND NOT EXISTS (
                        SELECT 1 FROM visits v2 
                        WHERE v2.user_id = v.user_id 
                        AND v2.user_agent LIKE 'LOGOUT%' 
                        AND v2.visit_date > v.visit_date
                    )
                    ORDER BY v.visit_date DESC
                ");
                $stmt->execute();
                $online_users = $stmt->fetchAll();
                echo "<p>🟢 کاربران آنلاین (2 دقیقه گذشته):</p>";
                if (empty($online_users)) {
                    echo "<small style='color: #ff6b6b;'>❌ هیچ کاربری آنلاین نیست!</small><br>";
                } else {
                    foreach($online_users as $online) {
                        $lastActivity = date('H:i:s', strtotime($online['visit_date']));
                        echo "<small>🔵 " . $online['username'] . " (ID: " . $online['user_id'] . ") - آخرین فعالیت: " . $lastActivity . "</small><br>";
                    }
                }
                
                // نمایش آخرین logout ها
                $stmt = $conn->prepare("
                    SELECT v.*, u.username 
                    FROM visits v 
                    LEFT JOIN users u ON v.user_id = u.id 
                    WHERE v.user_agent LIKE 'LOGOUT%' 
                    ORDER BY v.visit_date DESC 
                    LIMIT 5
                ");
                $stmt->execute();
                $recent_logouts = $stmt->fetchAll();
                echo "<p>🚪 آخرین 5 خروج:</p>";
                if (empty($recent_logouts)) {
                    echo "<small style='color: #888;'>هیچ logout ثبت نشده</small><br>";
                } else {
                    foreach($recent_logouts as $logout) {
                        $username = $logout['username'] ? $logout['username'] : 'مهمان';
                        echo "<small>🔴 " . $username . " | " . $logout['visit_date'] . "</small><br>";
                    }
                }
                
                // کاربرانی که هیچ بازدیدی ندارند
                $stmt = $conn->prepare("SELECT u.id, u.username FROM users u LEFT JOIN visits v ON u.id = v.user_id WHERE v.user_id IS NULL");
                $stmt->execute();
                $no_visits = $stmt->fetchAll();
                if (!empty($no_visits)) {
                    echo "<p>⚠️ کاربران بدون بازدید:</p>";
                    foreach($no_visits as $user) {
                        echo "<small>❌ " . $user['username'] . " (ID: " . $user['id'] . ") - هیچ بازدیدی ندارد</small><br>";
                    }
                }
                
            } catch (Exception $e) {
                echo "<p>❌ خطا: " . $e->getMessage() . "</p>";
            }
            ?>
            <p><a href="visitor.php" style="color: yellow;">حذف Debug</a></p>
        </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="page-header">
            <h1>📊 پنل مدیریت بازدیدکنندگان</h1>
            <p>نظارت و تحلیل بازدیدکنندگان سایت <?php echo SITE_NAME; ?></p>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-icon">👥</span>
                <div class="stat-number"><?php echo number_format($stats['total_visitors']); ?></div>
                <div class="stat-label">کل بازدیدکنندگان</div>
            </div>
            <div class="stat-card">
                <span class="stat-icon">📅</span>
                <div class="stat-number"><?php echo number_format($stats['today_visitors']); ?></div>
                <div class="stat-label">بازدیدکنندگان امروز</div>
            </div>
            <div class="stat-card">
                <span class="stat-icon">🎓</span>
                <div class="stat-number"><?php echo number_format($stats['active_students']); ?></div>
                <div class="stat-label">دانش‌آموزان فعال</div>
            </div>
            <div class="stat-card">
                <span class="stat-icon">⚡</span>
                <div class="stat-number"><?php echo number_format($stats['online_now']); ?></div>
                <div class="stat-label">آنلاین اکنون</div>
            </div>
        </div>

        <!-- Control Panel -->
        <div class="control-panel">
            <form method="GET" action="visitor.php">
                <div class="control-row">
                    <input type="text" name="search" class="search-box" placeholder="🔍 جستجو در نام، ایمیل یا IP..." value="<?php echo htmlspecialchars($search); ?>">
                    <input type="date" name="date_from" class="date-filter" placeholder="از تاریخ" value="<?php echo htmlspecialchars($date_from); ?>">
                    <input type="date" name="date_to" class="date-filter" placeholder="تا تاریخ" value="<?php echo htmlspecialchars($date_to); ?>">
                    <select name="user_type" class="filter-select">
                        <option value="">همه کاربران</option>
                        <option value="student" <?php echo $user_type_filter === 'student' ? 'selected' : ''; ?>>دانش‌آموزان</option>
                        <option value="admin" <?php echo $user_type_filter === 'admin' ? 'selected' : ''; ?>>مدیران</option>
                    </select>
                    <select name="status" class="filter-select">
                        <option value="">همه وضعیت‌ها</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>فعال</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>غیرفعال</option>
                    </select>
                </div>
                <div class="control-row">
                    <button type="submit" class="btn">🔍 اعمال فیلتر</button>
                    <a href="visitor.php?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>" class="btn btn-success">📄 خروجی CSV</a>
                    <button type="button" class="btn btn-danger" onclick="clearOldData()">🗑️ پاکسازی داده‌های قدیمی</button>
                    <a href="visitor.php" class="btn">🔄 بروزرسانی</a>
                </div>
            </form>
        </div>

        <!-- Visitors Table -->
        <div class="table-container">
            <?php if (!empty($visitors)): ?>
            <table class="visitors-table">
                <thead>
                    <tr>
                        <th>عکس</th>
                        <th>نام کاربری</th>
                        <th>نام کامل</th>
                        <th>نوع کاربر</th>
                        <th>ایمیل</th>
                        <th>کد ملی</th>
                        <th>IP آخرین بازدید</th>
                        <th>آخرین فعالیت</th>
                        <th>تعداد بازدید</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($visitors as $visitor): ?>
                    <tr <?php echo $visitor['is_online'] ? 'style="background: rgba(46, 213, 115, 0.1); border-left: 4px solid #2ed573;"' : ''; ?>>
                        <td>
                            <?php if (!empty($visitor['avatar'])): ?>
                                <img src="../<?php echo htmlspecialchars($visitor['avatar']); ?>" class="user-avatar" alt="آواتار">
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($visitor['first_name'] . ' ' . $visitor['last_name']); ?>&background=667eea&color=fff&size=40" class="user-avatar" alt="آواتار">
                            <?php endif; ?>
                            <?php if ($visitor['is_online']): ?>
                                <span style="position: absolute; width: 12px; height: 12px; background: #2ed573; border-radius: 50%; margin-left: -15px; margin-top: 25px; border: 2px solid white; animation: pulse 2s infinite;"></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($visitor['username'] ?? ''); ?>
                            <?php if ($visitor['is_online']): ?>
                                <span style="color: #2ed573; font-size: 12px; margin-right: 5px;">● آنلاین</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars(trim(($visitor['first_name'] ?? '') . ' ' . ($visitor['last_name'] ?? ''))); ?></td>
                        <td>
                            <span class="user-type type-<?php echo $visitor['user_type']; ?>">
                                <?php echo $visitor['user_type'] === 'student' ? '🎓 دانش‌آموز' : '👨‍💼 مدیر'; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($visitor['email'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($visitor['national_id'] ?? '-'); ?></td>
                        <td>
                            <code style="background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 4px; font-size: 11px;">
                                <?php echo htmlspecialchars($visitor['ip_address'] ?? '-'); ?>
                            </code>
                        </td>
                        <td>
                            <?php 
                            $date_to_show = $visitor['visit_date'] ?? $visitor['last_login'] ?? $visitor['created_at'];
                            if ($date_to_show) {
                                echo convertToJalali($date_to_show);
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?php echo number_format($visitor['visit_count'] ?? 0); ?></td>
                        <td>
                            <span class="status-badge <?php echo $visitor['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                <?php echo $visitor['is_active'] ? '✅ فعال' : '❌ غیرفعال'; ?>
                            </span>
                        </td>
                        <td>
                            <button class="action-btn" onclick="viewUserDetails(<?php echo $visitor['user_id']; ?>)" title="مشاهده جزئیات">👁️</button>
                            <button class="action-btn" onclick="toggleUserStatus(<?php echo $visitor['user_id']; ?>, <?php echo $visitor['is_active'] ? 0 : 1; ?>)" title="<?php echo $visitor['is_active'] ? 'غیرفعال کردن' : 'فعال کردن'; ?>">
                                <?php echo $visitor['is_active'] ? '🚫' : '✅'; ?>
                            </button>
                            <?php if ($visitor['user_id'] != $_SESSION['user_id']): ?>
                            <button class="action-btn" onclick="deleteUserData(<?php echo $visitor['user_id']; ?>)" title="حذف کاربر">🗑️</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="visitor.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page-1])); ?>">⏮️ قبلی</a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
                    <a href="visitor.php?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                       class="<?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="visitor.php?<?php echo http_build_query(array_merge($_GET, ['page' => $page+1])); ?>">بعدی ⏭️</a>
                <?php endif; ?>
            </div>
            
            <div style="text-align: center; color: rgba(255,255,255,0.7); margin-top: 15px; font-size: 0.9rem;">
                📊 نمایش <?php echo number_format($offset + 1); ?> تا <?php echo number_format(min($offset + $limit, $total_records)); ?> از <?php echo number_format($total_records); ?> کاربر
            </div>
            <?php endif; ?>

            <?php else: ?>
            <div class="no-data">
                هیچ بازدیدکننده‌ای با فیلترهای انتخابی یافت نشد.
                <br><small>فیلترها را تغییر دهید یا صفحه را بروزرسانی کنید.</small>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal" id="userModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>📋 جزئیات کامل کاربر</h2>
            <div id="userDetails">
                <div class="loading">
                    <div class="spinner"></div>
                    <p>در حال بارگذاری...</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function viewUserDetails(userId) {
            document.getElementById('userDetails').innerHTML = `
                <div class="loading">
                    <div class="spinner"></div>
                    <p>در حال بارگذاری اطلاعات...</p>
                </div>
            `;
            document.getElementById('userModal').style.display = 'block';

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'visitor.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        const user = JSON.parse(xhr.responseText);
                        if (user && user.id) {
                            const birthDate = user.birth_date ? convertToJalali(user.birth_date) : '-';
                            const createdAt = user.created_at ? convertToJalali(user.created_at) : '-';
                            const lastLogin = user.last_login ? convertToJalali(user.last_login) : '-';
                            const lastVisit = user.last_visit ? convertToJalali(user.last_visit) : '-';
                            const firstVisit = user.first_visit ? convertToJalali(user.first_visit) : '-';
                            
                            const userDetails = `
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; line-height: 2;">
                                    <p><strong>🆔 شناسه کاربر:</strong> ${user.id}</p>
                                    <p><strong>👤 نام کاربری:</strong> ${user.username || '-'}</p>
                                    <p><strong>📝 نام:</strong> ${user.first_name || '-'}</p>
                                    <p><strong>👨‍👩‍👧‍👦 نام خانوادگی:</strong> ${user.last_name || '-'}</p>
                                    <p><strong>📧 ایمیل:</strong> ${user.email || '-'}</p>
                                    <p><strong>🆔 کد ملی:</strong> ${user.national_id || '-'}</p>
                                    <p><strong>🎂 تاریخ تولد:</strong> ${birthDate}</p>
                                    <p><strong>👔 نوع کاربر:</strong> ${user.user_type === 'student' ? '🎓 دانش‌آموز' : '👨‍💼 مدیر'}</p>
                                    <p><strong>👨 نام پدر:</strong> ${user.father_name || '-'}</p>
                                    <p><strong>📱 تلفن پدر:</strong> ${user.father_phone || '-'}</p>
                                    <p><strong>👩 نام مادر:</strong> ${user.mother_name || '-'}</p>
                                    <p><strong>📲 تلفن مادر:</strong> ${user.mother_phone || '-'}</p>
                                    <p><strong>📅 تاریخ عضویت:</strong> ${createdAt}</p>
                                    <p><strong>🔐 آخرین ورود:</strong> ${lastLogin}</p>
                                    <p><strong>🏁 اولین بازدید:</strong> ${firstVisit}</p>
                                    <p><strong>🏃 آخرین بازدید:</strong> ${lastVisit}</p>
                                    <p><strong>📊 تعداد کل بازدیدها:</strong> ${user.total_visits || 0}</p>
                                    <p><strong>⚡ وضعیت:</strong> ${user.is_active == 1 ? '✅ فعال' : '❌ غیرفعال'}</p>
                                </div>
                                ${user.address ? `<div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 10px;"><strong>🏠 آدرس:</strong><br>${user.address}</div>` : ''}
                            `;
                            document.getElementById('userDetails').innerHTML = userDetails;
                        } else {
                            document.getElementById('userDetails').innerHTML = '<p style="text-align: center; color: #ff6b6b;">خطا در دریافت اطلاعات کاربر</p>';
                        }
                    } catch (e) {
                        console.error('JSON parsing error:', e);
                        document.getElementById('userDetails').innerHTML = '<p style="text-align: center; color: #ff6b6b;">خطا در پردازش داده‌ها</p>';
                    }
                }
            };
            
            xhr.send('action=get_user_details&user_id=' + userId);
        }

        function toggleUserStatus(userId, newStatus) {
            const message = newStatus ? 'فعال' : 'غیرفعال';
            
            if (confirm(`آیا مطمئن هستید که می‌خواهید این کاربر را ${message} کنید؟`)) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'visitor.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                alert(`✅ کاربر ${message} شد.`);
                                location.reload();
                            } else {
                                alert('❌ خطا در انجام عملیات: ' + (response.error || 'خطای ناشناخته'));
                            }
                        } catch (e) {
                            alert('❌ خطا در پردازش پاسخ سرور');
                        }
                    }
                };
                
                xhr.send(`action=toggle_user_status&user_id=${userId}&status=${newStatus}`);
            }
        }

        function deleteUserData(userId) {
            if (confirm('⚠️ آیا مطمئن هستید که می‌خواهید این کاربر و تمام داده‌هایش را حذف کنید؟\n🚨 این عمل غیرقابل برگشت است!')) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'visitor.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                alert('✅ کاربر و داده‌هایش با موفقیت حذف شدند.');
                                location.reload();
                            } else {
                                alert('❌ خطا در حذف: ' + (response.error || 'خطای ناشناخته'));
                            }
                        } catch (e) {
                            alert('❌ خطا در پردازش پاسخ سرور');
                        }
                    }
                };
                
                xhr.send('action=delete_user_data&user_id=' + userId);
            }
        }

        function clearOldData() {
            const days = prompt('📅 داده‌های بازدید قدیمی‌تر از چند روز حذف شوند؟', '180');
            
            if (days && !isNaN(days) && days > 0) {
                if (confirm(`⚠️ آیا مطمئن هستید که می‌خواهید داده‌های بازدید قدیمی‌تر از ${days} روز را حذف کنید؟\n\n🗑️ این عملیات باعث حذف رکوردهای بازدید می‌شود (نه خود کاربران)`)) {
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'visitor.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            try {
                                const response = JSON.parse(xhr.responseText);
                                if (response.success) {
                                    alert(`✅ ${response.deleted_count} رکورد بازدید با موفقیت حذف شد.`);
                                    location.reload();
                                } else {
                                    alert('❌ خطا در حذف: ' + (response.error || 'خطای ناشناخته'));
                                }
                            } catch (e) {
                                alert('❌ خطا در پردازش پاسخ سرور');
                            }
                        }
                    };
                    
                    xhr.send(`action=clear_old_visits&days=${days}`);
                }
            }
        }

        function closeModal() {
            document.getElementById('userModal').style.display = 'none';
        }

        // Helper function for date conversion
        function convertToJalali(date) {
            if (!date) return '-';
            try {
                const d = new Date(date);
                return d.toLocaleDateString('fa-IR');
            } catch (e) {
                return date;
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('userModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        }

        // Real-time updates و ping system
        let lastOnlineCount = 0;
        let updateInterval = null;
        let pingInterval = null;

        function updateLiveStats() {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'visitor.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        const stats = JSON.parse(xhr.responseText);
                        
                        // بروزرسانی آمار
                        const totalElement = document.querySelector('.stat-number');
                        if (totalElement) totalElement.textContent = stats.total_visitors.toLocaleString();
                        
                        const todayElements = document.querySelectorAll('.stat-number');
                        if (todayElements[1]) todayElements[1].textContent = stats.today_visitors.toLocaleString();
                        
                        const studentsElements = document.querySelectorAll('.stat-number');
                        if (studentsElements[2]) studentsElements[2].textContent = stats.active_students.toLocaleString();
                        
                        const onlineElements = document.querySelectorAll('.stat-number');
                        if (onlineElements[3]) {
                            const newCount = parseInt(stats.online_now);
                            onlineElements[3].textContent = newCount.toLocaleString();
                            
                            // اگر تعداد آنلاین‌ها تغییر کرده، افکت نشان بده
                            if (newCount !== lastOnlineCount) {
                                onlineElements[3].style.animation = 'none';
                                setTimeout(() => {
                                    onlineElements[3].style.animation = 'pulse 0.5s ease-in-out 3';
                                }, 10);
                                lastOnlineCount = newCount;
                                
                                // اگر کاربر جدید آنلاین شده، نوتیفیکیشن نشان بده
                                if (newCount > lastOnlineCount && lastOnlineCount > 0) {
                                    showNotification('👋 کاربر جدید آنلاین شد!', 'success');
                                }
                            }
                        }
                        
                        // بروزرسانی لیست کاربران آنلاین در جدول (اگر صفحه در حال نمایش است)
                        if (stats.online_users && stats.online_users.length > 0) {
                            updateOnlineUsersInTable(stats.online_users);
                        }
                        
                    } catch (e) {
                        console.log('خطا در parse کردن آمار:', e);
                    }
                }
            };
            
            xhr.send('action=get_live_stats');
        }

        function pingOnline() {
            // ارسال ping برای نگه داشتن کاربر فعلی آنلاین
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'visitor.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        const result = JSON.parse(xhr.responseText);
                        if (!result.success) {
                            console.log('کاربر لاگین نیست - متوقف کردن ping');
                            clearInterval(pingInterval);
                        }
                    } catch (e) {
                        console.log('خطا در ping:', e);
                    }
                }
            };
            
            xhr.send('action=ping_online');
        }

        function updateOnlineUsersInTable(onlineUsers) {
            // بروزرسانی نشان‌دهنده آنلاین در جدول
            const tableRows = document.querySelectorAll('.visitors-table tbody tr');
            const onlineUserIds = onlineUsers.map(user => user.id.toString());
            
            tableRows.forEach(row => {
                const userId = row.querySelector('[onclick*="viewUserDetails"]')?.getAttribute('onclick')?.match(/\d+/)?.[0];
                if (userId) {
                    const isOnline = onlineUserIds.includes(userId);
                    if (isOnline) {
                        row.style.background = 'rgba(46, 213, 115, 0.1)';
                        row.style.borderLeft = '4px solid #2ed573';
                    } else {
                        row.style.background = '';
                        row.style.borderLeft = '';
                    }
                }
            });
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? 'rgba(46, 213, 115, 0.9)' : 'rgba(54, 162, 235, 0.9)'};
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                z-index: 10000;
                font-weight: bold;
                animation: slideInRight 0.5s ease-out;
            `;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.5s ease-in';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 500);
            }, 3000);
        }

        // شروع بروزرسانی خودکار
        function startRealTimeUpdates() {
            // بروزرسانی آمار هر 5 ثانیه برای تشخیص سریع‌تر logout
            updateInterval = setInterval(updateLiveStats, 5000);
            
            // ping هر 1 دقیقه برای نگه داشتن کاربر آنلاین (کاهش یافته)
            pingInterval = setInterval(pingOnline, 60000);
            
            // اولین بروزرسانی فوری
            setTimeout(updateLiveStats, 1000);
            
            console.log('🔄 سیستم بروزرسانی زنده فعال شد (5 ثانیه)');
        }

        // متوقف کردن بروزرسانی
        function stopRealTimeUpdates() {
            if (updateInterval) clearInterval(updateInterval);
            if (pingInterval) clearInterval(pingInterval);
            console.log('⏹️ سیستم بروزرسانی زنده متوقف شد');
        }

        // شروع خودکار
        document.addEventListener('DOMContentLoaded', function() {
            startRealTimeUpdates();
            
            // متوقف کردن هنگام خروج از صفحه
            window.addEventListener('beforeunload', stopRealTimeUpdates);
            
            // از سر گیری هنگام فوکس دوباره صفحه
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    stopRealTimeUpdates();
                } else {
                    startRealTimeUpdates();
                }
            });
        });

        // Smooth scroll for long tables
        document.addEventListener('DOMContentLoaded', function() {
            const tableContainer = document.querySelector('.table-container');
            if (tableContainer) {
                tableContainer.style.scrollBehavior = 'smooth';
            }
        });

        // Add loading animation for buttons
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', function() {
                if (this.type === 'submit') {
                    this.innerHTML = '⏳ در حال پردازش...';
                    this.disabled = true;
                    setTimeout(() => {
                        this.disabled = false;
                    }, 3000);
                }
            });
        });
    </script>
</body>
</html>