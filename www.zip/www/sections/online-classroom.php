<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>راهنمای کلاس آنلاین - starmah.ir</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            line-height: 1.8;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            color: white;
            padding: 40px 20px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .url-box {
            background: rgba(255,255,255,0.2);
            padding: 15px 30px;
            border-radius: 50px;
            display: inline-block;
            margin-top: 20px;
            font-size: 1.3em;
            font-weight: bold;
        }
        
        .url-box a {
            color: white;
            text-decoration: none;
        }
        
        .tabs {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 30px 0;
        }
        
        .tab-btn {
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 1.1em;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .tab-btn.teacher {
            background: #e74c3c;
            color: white;
        }
        
        .tab-btn.student {
            background: #3498db;
            color: white;
        }
        
        .tab-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        
        .tab-btn.active {
            transform: scale(1.1);
            box-shadow: 0 5px 25px rgba(0,0,0,0.4);
        }
        
        .content {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        .section-title {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 3px solid #667eea;
        }
        
        .step {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            border-right: 5px solid #667eea;
        }
        
        .step-number {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            font-weight: bold;
            margin-left: 15px;
        }
        
        .step-title {
            font-size: 1.3em;
            color: #2c3e50;
            display: inline-block;
            vertical-align: middle;
        }
        
        .step-content {
            margin-top: 15px;
            color: #555;
            padding-right: 55px;
        }
        
        .tip {
            background: #e8f5e9;
            border-radius: 10px;
            padding: 15px 20px;
            margin: 15px 0;
            border-right: 4px solid #4caf50;
        }
        
        .tip::before {
            content: "💡 نکته: ";
            font-weight: bold;
            color: #2e7d32;
        }
        
        .warning {
            background: #fff3e0;
            border-radius: 10px;
            padding: 15px 20px;
            margin: 15px 0;
            border-right: 4px solid #ff9800;
        }
        
        .warning::before {
            content: "⚠️ توجه: ";
            font-weight: bold;
            color: #e65100;
        }
        
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .feature-card {
            background: linear-gradient(135deg, #f5f7fa, #e4e8ec);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: transform 0.3s;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .feature-icon {
            font-size: 3em;
            margin-bottom: 15px;
        }
        
        .feature-title {
            font-size: 1.1em;
            color: #2c3e50;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .feature-desc {
            color: #666;
            font-size: 0.95em;
        }
        
        .shortcut-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .shortcut-table th,
        .shortcut-table td {
            padding: 12px 15px;
            text-align: right;
            border-bottom: 1px solid #ddd;
        }
        
        .shortcut-table th {
            background: #667eea;
            color: white;
        }
        
        .shortcut-table tr:hover {
            background: #f5f5f5;
        }
        
        .key {
            background: #2c3e50;
            color: white;
            padding: 5px 12px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.9em;
        }
        
        .button-example {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 8px;
            margin: 5px;
            color: white;
            font-weight: bold;
        }
        
        .btn-red { background: #e74c3c; }
        .btn-blue { background: #3498db; }
        .btn-green { background: #27ae60; }
        .btn-orange { background: #f39c12; }
        .btn-purple { background: #9b59b6; }
        
        .qr-section {
            text-align: center;
            padding: 30px;
            background: #f8f9fa;
            border-radius: 15px;
            margin-top: 30px;
        }
        
        .faq {
            margin-top: 30px;
        }
        
        .faq-item {
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .faq-question {
            background: #f8f9fa;
            padding: 15px 20px;
            cursor: pointer;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .faq-question:hover {
            background: #e9ecef;
        }
        
        .faq-answer {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .faq-item.open .faq-answer {
            padding: 20px;
            max-height: 500px;
        }
        
        .faq-item.open .faq-toggle {
            transform: rotate(180deg);
        }
        
        .faq-toggle {
            transition: transform 0.3s;
        }
        
        .footer {
            text-align: center;
            color: white;
            padding: 30px;
            opacity: 0.9;
        }
        
        @media (max-width: 600px) {
            .header h1 {
                font-size: 1.8em;
            }
            
            .tabs {
                flex-direction: column;
            }
            
            .tab-btn {
                width: 100%;
            }
            
            .content {
                padding: 20px;
            }
            
            .step-content {
                padding-right: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎓 راهنمای کلاس آنلاین</h1>
            <p>آموزش کامل استفاده از سیستم ویدیو کنفرانس</p>
            <div class="url-box">
                <a href="https://class.starmah.ir">🌐 class.starmah.ir</a>
            </div>
        </div>
        
        <div class="tabs">
            <button class="tab-btn teacher active" onclick="showSection('teacher')">
                👨‍🏫 راهنمای معلم
            </button>
            <button class="tab-btn student" onclick="showSection('student')">
                👨‍🎓 راهنمای دانش‌آموز
            </button>
        </div>
        
        <div class="content">
            <!-- بخش معلم -->
            <div id="teacher-section" class="section active">
                <h2 class="section-title">👨‍🏫 راهنمای معلم</h2>
                
                <div class="step">
                    <span class="step-number">۱</span>
                    <span class="step-title">ورود به سیستم</span>
                    <div class="step-content">
                        <p>آدرس <strong>https://class.starmah.ir</strong> را در مرورگر باز کنید.</p>
                        <div class="tip">از مرورگر Chrome یا Firefox استفاده کنید برای بهترین کیفیت.</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۲</span>
                    <span class="step-title">ساخت کلاس جدید</span>
                    <div class="step-content">
                        <p>در کادر وسط صفحه، یک نام برای کلاس خود انتخاب کنید:</p>
                        <ul style="margin: 15px 0; padding-right: 20px;">
                            <li><strong>ریاضی-پایه-چهارم</strong></li>
                            <li><strong>علوم-کلاس-۴الف</strong></li>
                            <li><strong>فارسی-۱۴۰۴۰۹۱۵</strong></li>
                        </ul>
                        <p>سپس روی <span class="button-example btn-blue">Start meeting</span> کلیک کنید.</p>
                        <div class="warning">از فاصله و کاراکترهای فارسی در نام کلاس استفاده نکنید. فقط حروف انگلیسی، اعداد و خط تیره (-) مجاز است.</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۳</span>
                    <span class="step-title">اجازه دسترسی به دوربین و میکروفون</span>
                    <div class="step-content">
                        <p>مرورگر از شما می‌پرسد آیا اجازه دسترسی به دوربین و میکروفون را می‌دهید.</p>
                        <p>روی <span class="button-example btn-green">Allow / اجازه</span> کلیک کنید.</p>
                        <div class="tip">اگر اشتباهاً روی Block زدید، روی آیکون قفل کنار آدرس سایت کلیک کنید و دسترسی‌ها را تغییر دهید.</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۴</span>
                    <span class="step-title">دعوت از دانش‌آموزان</span>
                    <div class="step-content">
                        <p>برای دعوت از دانش‌آموزان، لینک کلاس را کپی کنید:</p>
                        <ol style="margin: 15px 0; padding-right: 20px;">
                            <li>روی دکمه <strong>Participants</strong> (👥) در پایین صفحه کلیک کنید</li>
                            <li>روی <strong>Invite</strong> کلیک کنید</li>
                            <li>لینک را کپی کنید</li>
                            <li>لینک را در گروه واتساپ یا تلگرام کلاس بفرستید</li>
                        </ol>
                        <div class="tip">می‌توانید فقط نام کلاس را به دانش‌آموزان بدهید. آن‌ها باید به class.starmah.ir بروند و نام کلاس را وارد کنند.</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۵</span>
                    <span class="step-title">اشتراک‌گذاری صفحه نمایش</span>
                    <div class="step-content">
                        <p>برای نمایش محتوا به دانش‌آموزان:</p>
                        <ol style="margin: 15px 0; padding-right: 20px;">
                            <li>روی دکمه <strong>Share screen</strong> (🖥️) کلیک کنید</li>
                            <li>انتخاب کنید چه چیزی را می‌خواهید به اشتراک بگذارید:
                                <ul>
                                    <li><strong>Entire Screen:</strong> کل صفحه نمایش</li>
                                    <li><strong>Window:</strong> یک برنامه خاص</li>
                                    <li><strong>Chrome Tab:</strong> یک تب مرورگر</li>
                                </ul>
                            </li>
                            <li>روی Share کلیک کنید</li>
                        </ol>
                    </div>
                </div>
                
                <h3 style="margin: 30px 0 20px; color: #2c3e50;">🎛️ امکانات مدیریتی معلم</h3>
                
                <div class="feature-grid">
                    <div class="feature-card">
                        <div class="feature-icon">🔇</div>
                        <div class="feature-title">Mute همه</div>
                        <div class="feature-desc">صدای همه شرکت‌کنندگان را قطع کنید</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🚫</div>
                        <div class="feature-title">اخراج</div>
                        <div class="feature-desc">افراد مزاحم را از کلاس حذف کنید</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🔒</div>
                        <div class="feature-title">قفل کلاس</div>
                        <div class="feature-desc">جلوی ورود افراد جدید را بگیرید</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">⏺️</div>
                        <div class="feature-title">ضبط کلاس</div>
                        <div class="feature-desc">کلاس را ضبط کنید برای غایبین</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">✋</div>
                        <div class="feature-title">دست بالا</div>
                        <div class="feature-desc">ببینید چه کسی سؤال دارد</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">💬</div>
                        <div class="feature-title">چت</div>
                        <div class="feature-desc">پیام متنی با دانش‌آموزان</div>
                    </div>
                </div>
                
                <h3 style="margin: 30px 0 20px; color: #2c3e50;">⌨️ کلیدهای میانبر</h3>
                
                <table class="shortcut-table">
                    <tr>
                        <th>کلید</th>
                        <th>عملکرد</th>
                    </tr>
                    <tr>
                        <td><span class="key">M</span></td>
                        <td>قطع/وصل میکروفون</td>
                    </tr>
                    <tr>
                        <td><span class="key">V</span></td>
                        <td>قطع/وصل دوربین</td>
                    </tr>
                    <tr>
                        <td><span class="key">C</span></td>
                        <td>باز کردن چت</td>
                    </tr>
                    <tr>
                        <td><span class="key">R</span></td>
                        <td>بالا بردن دست</td>
                    </tr>
                    <tr>
                        <td><span class="key">S</span></td>
                        <td>اشتراک‌گذاری صفحه</td>
                    </tr>
                    <tr>
                        <td><span class="key">F</span></td>
                        <td>تمام صفحه</td>
                    </tr>
                    <tr>
                        <td><span class="key">W</span></td>
                        <td>تغییر نمای ویدیوها</td>
                    </tr>
                </table>
                
                <div class="step" style="border-right-color: #e74c3c;">
                    <span class="step-number" style="background: #e74c3c;">!</span>
                    <span class="step-title">پایان کلاس</span>
                    <div class="step-content">
                        <p>برای پایان کلاس:</p>
                        <ol style="margin: 15px 0; padding-right: 20px;">
                            <li>روی دکمه قرمز <span class="button-example btn-red">Leave</span> کلیک کنید</li>
                            <li>گزینه <strong>"End meeting for all"</strong> را انتخاب کنید تا کلاس برای همه بسته شود</li>
                        </ol>
                    </div>
                </div>
            </div>
            
            <!-- بخش دانش‌آموز -->
            <div id="student-section" class="section">
                <h2 class="section-title">👨‍🎓 راهنمای دانش‌آموز</h2>
                
                <div class="step">
                    <span class="step-number">۱</span>
                    <span class="step-title">ورود به کلاس</span>
                    <div class="step-content">
                        <p><strong>روش اول:</strong> لینکی که معلم فرستاده را کلیک کنید.</p>
                        <p><strong>روش دوم:</strong></p>
                        <ol style="margin: 15px 0; padding-right: 20px;">
                            <li>آدرس <strong>https://class.starmah.ir</strong> را باز کنید</li>
                            <li>نام کلاس را که معلم داده وارد کنید</li>
                            <li>روی <span class="button-example btn-blue">Join meeting</span> کلیک کنید</li>
                        </ol>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۲</span>
                    <span class="step-title">وارد کردن نام</span>
                    <div class="step-content">
                        <p>نام و نام خانوادگی خود را وارد کنید تا معلم شما را بشناسد.</p>
                        <div class="warning">حتماً نام واقعی خود را بنویسید نه اسم مستعار!</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۳</span>
                    <span class="step-title">اجازه دسترسی</span>
                    <div class="step-content">
                        <p>وقتی مرورگر پرسید، روی <span class="button-example btn-green">Allow</span> بزنید.</p>
                        <div class="tip">اگر دوربین یا میکروفون ندارید، می‌توانید فقط ببینید و بشنوید.</div>
                    </div>
                </div>
                
                <div class="step">
                    <span class="step-number">۴</span>
                    <span class="step-title">رفتار در کلاس</span>
                    <div class="step-content">
                        <p>قوانین کلاس آنلاین:</p>
                        <ul style="margin: 15px 0; padding-right: 20px;">
                            <li>🔇 <strong>میکروفون را Mute نگه دارید</strong> مگر وقتی می‌خواهید صحبت کنید</li>
                            <li>✋ <strong>برای سؤال، دست بالا ببرید</strong> (دکمه Raise Hand)</li>
                            <li>💬 <strong>از چت استفاده کنید</strong> برای سؤالات کوتاه</li>
                            <li>👀 <strong>به صفحه معلم توجه کنید</strong></li>
                            <li>🚫 <strong>صفحه خود را Share نکنید</strong> مگر معلم بخواهد</li>
                        </ul>
                    </div>
                </div>
                
                <h3 style="margin: 30px 0 20px; color: #2c3e50;">🎮 دکمه‌های مهم</h3>
                
                <div class="feature-grid">
                    <div class="feature-card">
                        <div class="feature-icon">🎤</div>
                        <div class="feature-title">میکروفون</div>
                        <div class="feature-desc">روشن/خاموش کردن صدا</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📷</div>
                        <div class="feature-title">دوربین</div>
                        <div class="feature-desc">روشن/خاموش کردن تصویر</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">✋</div>
                        <div class="feature-title">دست بالا</div>
                        <div class="feature-desc">اعلام سؤال به معلم</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">💬</div>
                        <div class="feature-title">چت</div>
                        <div class="feature-desc">پیام متنی</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">😀</div>
                        <div class="feature-title">واکنش</div>
                        <div class="feature-desc">ایموجی و واکنش</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🚪</div>
                        <div class="feature-title">خروج</div>
                        <div class="feature-desc">ترک کلاس</div>
                    </div>
                </div>
                
                <h3 style="margin: 30px 0 20px; color: #2c3e50;">⌨️ کلیدهای میانبر</h3>
                
                <table class="shortcut-table">
                    <tr>
                        <th>کلید</th>
                        <th>عملکرد</th>
                    </tr>
                    <tr>
                        <td><span class="key">M</span></td>
                        <td>قطع/وصل میکروفون</td>
                    </tr>
                    <tr>
                        <td><span class="key">V</span></td>
                        <td>قطع/وصل دوربین</td>
                    </tr>
                    <tr>
                        <td><span class="key">C</span></td>
                        <td>باز کردن چت</td>
                    </tr>
                    <tr>
                        <td><span class="key">R</span></td>
                        <td>بالا بردن دست</td>
                    </tr>
                    <tr>
                        <td><span class="key">F</span></td>
                        <td>تمام صفحه</td>
                    </tr>
                </table>
                
                <div class="faq">
                    <h3 style="margin-bottom: 20px; color: #2c3e50;">❓ سؤالات متداول</h3>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            صدای معلم را نمی‌شنوم
                            <span class="faq-toggle">▼</span>
                        </div>
                        <div class="faq-answer">
                            <ol>
                                <li>مطمئن شوید صدای کامپیوتر/گوشی روشن است</li>
                                <li>هدفون یا اسپیکر را چک کنید</li>
                                <li>صفحه را Refresh کنید (F5)</li>
                                <li>از کلاس خارج شوید و دوباره وارد شوید</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            دوربین من کار نمی‌کند
                            <span class="faq-toggle">▼</span>
                        </div>
                        <div class="faq-answer">
                            <ol>
                                <li>روی آیکون قفل کنار آدرس سایت کلیک کنید</li>
                                <li>دسترسی Camera را Allow کنید</li>
                                <li>صفحه را Refresh کنید</li>
                                <li>برنامه‌های دیگر که از دوربین استفاده می‌کنند را ببندید</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            صفحه قطع و وصل می‌شود
                            <span class="faq-toggle">▼</span>
                        </div>
                        <div class="faq-answer">
                            <ol>
                                <li>اینترنت خود را چک کنید</li>
                                <li>به WiFi نزدیک‌تر شوید</li>
                                <li>برنامه‌های دیگر که اینترنت مصرف می‌کنند را ببندید</li>
                                <li>دوربین خود را خاموش کنید تا پهنای باند کمتری مصرف شود</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            چگونه از گوشی وارد شوم؟
                            <span class="faq-toggle">▼</span>
                        </div>
                        <div class="faq-answer">
                            <ol>
                                <li>اپلیکیشن <strong>Jitsi Meet</strong> را از Play Store یا App Store نصب کنید</li>
                                <li>آدرس سرور را وارد کنید: <strong>class.starmah.ir</strong></li>
                                <li>نام کلاس را وارد کنید</li>
                                <li>وارد شوید!</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>🌟 ستاره ماه - starmah.ir</p>
            <p>برای پشتیبانی با معلم خود تماس بگیرید</p>
        </div>
    </div>
    
    <script>
        function showSection(type) {
            // Hide all sections
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            
            // Show selected section
            document.getElementById(type + '-section').classList.add('active');
            document.querySelector('.tab-btn.' + type).classList.add('active');
        }
        
        function toggleFaq(element) {
            element.parentElement.classList.toggle('open');
        }
    </script>
</body>
</html>