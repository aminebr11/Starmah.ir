<?php
// sections/dashboard.php - بروزرسانی شده برای موارد انضباطی

// بررسی وجود session و تعریف userType
if (!isset($_SESSION)) {
    session_start();
}

// تعریف userType در صورت عدم وجود
if (!isset($userType)) {
    $userType = $_SESSION['user_type'] ?? $_SESSION['userType'] ?? 'student';
}

// بررسی وجود اتصال به دیتابیس و تلاش برای اتصال
if (!isset($conn)) {
    // تلاش برای include کردن فایل config
    $config_files = [
        'config.php',
        '../config.php',
        'includes/config.php',
        '../includes/config.php',
        'db_config.php',
        '../db_config.php'
    ];
    
    $connected = false;
    foreach ($config_files as $config_file) {
        if (file_exists($config_file)) {
            try {
                include_once $config_file;
                if (isset($conn) && $conn instanceof PDO) {
                    $connected = true;
                    break;
                }
            } catch (Exception $e) {
                continue;
            }
        }
    }
    
    if (!$connected) {
        echo '<div style="color: red; text-align: center; padding: 2rem; background: #ffe6e6; border: 2px solid #ff6b6b; border-radius: 10px; margin: 20px;">
                <h3>⚠️ خطا در اتصال به پایگاه داده</h3>
                <p>لطفاً موارد زیر را بررسی کنید:</p>
                <ul style="text-align: right; display: inline-block;">
                    <li>فایل config.php وجود دارد؟</li>
                    <li>اطلاعات اتصال به دیتابیس صحیح است؟</li>
                    <li>سرور دیتابیس روشن است؟</li>
                </ul>
                <p style="margin-top: 20px; font-size: 0.9rem; color: #666;">
                    در صورت ادامه مشکل با مدیر سیستم تماس بگیرید.
                </p>
              </div>';
        return;
    }
}

// بررسی وجود user_id در session
if (!isset($_SESSION['user_id'])) {
    echo '<div style="text-align: center; padding: 2rem; color: #666;">
            <h3>خطا</h3>
            <p>لطفاً ابتدا وارد سیستم شوید.</p>
          </div>';
    return;
}

// فقط برای کاربران student
if ($userType !== 'student') {
    echo '<div style="text-align: center; padding: 2rem; color: #666;">
            <h3>دسترسی محدود</h3>
            <p>این بخش فقط برای دانش‌آموزان در دسترس است.</p>
          </div>';
    return;
}

// تعریف متغیرهای مورد نیاز برای منو
$isLoggedIn = isset($_SESSION['user_id']);
$userName = $_SESSION['user_name'] ?? 'دانش‌آموز';

try {
    // گرفتن جمع کل امتیاز منفی
    $stmt = $conn->prepare("SELECT SUM(score) as total_negative FROM discipline_records WHERE student_id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $result = $stmt->fetch();
    $totalNegativeScore = abs($result['total_negative'] ?? 0);

    // گرفتن آخرین ورود کاربر برای تشخیص موارد جدید
    $todayDate = date('Y-m-d');

    // بررسی موارد انضباطی جدید (موارد امروز)
    $stmt = $conn->prepare("SELECT COUNT(*) as new_count FROM discipline_records WHERE student_id = :user_id AND gregorian_date = :today_date");
    $stmt->execute(['user_id' => $_SESSION['user_id'], 'today_date' => $todayDate]);
    $result = $stmt->fetch();
    $newRecords = $result['new_count'] ?? 0;

    // Get all discipline records for the user
    $stmt = $conn->prepare("SELECT * FROM discipline_records WHERE student_id = :user_id ORDER BY gregorian_date DESC, created_at DESC");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo '<div style="color: red; text-align: center; padding: 2rem;">
            <h3>خطا در بارگذاری اطلاعات</h3>
            <p>لطفاً دوباره تلاش کنید یا با مدیر سیستم تماس بگیرید.</p>
          </div>';
    error_log("Database error in dashboard.php: " . $e->getMessage());
    return;
}

// تابع تبدیل تاریخ میلادی به شمسی
function convertToJalali($gregorianDate) {
    $persianMonths = [
        '01' => 'فروردین', '02' => 'اردیبهشت', '03' => 'خرداد',
        '04' => 'تیر', '05' => 'مرداد', '06' => 'شهریور',
        '07' => 'مهر', '08' => 'آبان', '09' => 'آذر',
        '10' => 'دی', '11' => 'بهمن', '12' => 'اسفند'
    ];
    
    $date = date('Y-m-d', strtotime($gregorianDate));
    list($year, $month, $day) = explode('-', $date);
    
    // تبدیل ساده (برای دقت بیشتر از کتابخانه jdf استفاده کنید)
    $persianYear = $year - 621;
    $monthName = $persianMonths[$month] ?? $month;
    
    return "$persianYear/$month/$day";
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📋 موارد انضباطی من - ستاره ماه</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Vazir', 'Tahoma', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
            direction: rtl;
            text-align: right;
        }

        /* پس‌زمینه ستاره‌ای */
        .stars {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
        }

        .star {
            position: absolute;
            width: 2px;
            height: 2px;
            background: #fff;
            border-radius: 50%;
            animation: twinkle 4s infinite ease-in-out;
        }

        .moon {
            position: fixed;
            top: 10%;
            right: 10%;
            width: 80px;
            height: 80px;
            background: radial-gradient(circle at 30% 30%, #fff, #f0f0f0);
            border-radius: 50%;
            box-shadow: 0 0 20px rgba(255,255,255,0.3);
            z-index: -1;
        }

        @keyframes twinkle {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        /* منوی ناوبری - مطابق index.php */
        nav {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            margin-bottom: 2rem;
        }

        .nav-container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1rem;
    flex-wrap: wrap;
    gap: 0rem; /* اضافه کردن gap کوچک */
}

        .logo {
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.05);
        }

        .logo img {
            height: 130px;
            width: auto;
        }

        .desktop-menu {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .menu-row {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .menu-row a {
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 600;
            white-space: nowrap;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .menu-row a:hover {
            background: rgba(255,255,255,0.25);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        /* موبایل منو */
        .mobile-menu-container {
            display: none;
        }

        .mobile-menu-btn {
    background: linear-gradient(135deg, #2563eb, #1d4ed8); /* آبی پررنگ */
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 25px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3); /* سایه آبی */
    transition: all 0.3s ease;
}

.mobile-menu-btn:hover {
    background: linear-gradient(135deg, #1d4ed8, #1e40af); /* آبی تیره‌تر در hover */
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
}

.mobile-menu-btn.active {
    background: linear-gradient(135deg, #1e40af, #1e3a8a); /* آبی خیلی تیره وقتی active */
    box-shadow: 0 6px 20px rgba(30, 64, 175, 0.5);
}

       .mobile-dropdown {
    position: absolute;
    top: calc(100% + 10px); /* درست زیر دکمه */
    right: 0; /* تراز با سمت راست دکمه */
    background: rgba(255,255,255,0.95);
    backdrop-filter: blur(20px);
    border-radius: 15px;
    min-width: 200px;
    display: none;
    margin-top: 0.5rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    overflow: hidden;
    z-index: 1001;
}
.mobile-dropdown-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 9998;
    display: none;
}

.mobile-dropdown-overlay.show {
    display: block;
}
        .mobile-dropdown.show {
            display: block;
        }

        .mobile-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .mobile-dropdown li a {
            display: block;
            padding: 1rem 1.5rem;
            color: #333;
            text-decoration: none;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .mobile-dropdown li:last-child a {
            border-bottom: none;
        }

        .mobile-dropdown li a:hover {
            background: rgba(102,126,234,0.1);
            color: #667eea;
            transform: translateX(-5px);
        }

        /* Auth section */
        .auth-section {
            display: flex;
            align-items: center;
        }

        .user-info {
    background: linear-gradient(135deg, rgba(37, 99, 235, 0.2), rgba(59, 130, 246, 0.15)); /* آبی کم‌رنگ */
    backdrop-filter: blur(10px);
    border: 1px solid rgba(37, 99, 235, 0.3); /* حاشیه آبی */
    padding: 0.5rem 1rem;
    border-radius: 25px;
    color: white;
    display: flex;
    align-items: center;
    gap: 1rem;
    flex-wrap: wrap;
    box-shadow: 0 4px 15px rgba(37, 99, 235, 0.2); /* سایه آبی کم‌رنگ */
}

        .logout-btn {
            background: rgba(255,107,107,0.8);
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 15px;
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: rgba(255,107,107,1);
            transform: translateY(-1px);
            box-shadow: 0 5px 15px rgba(255,107,107,0.4);
        }

        .login-btn {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .login-btn:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        /* محتوای اصلی */
        .dashboard-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .glass-effect {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            border-radius: 20px;
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.2);
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        @keyframes alertBounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(-20px); }
        }

        /* Responsive */
       @media (max-width: 768px) {
    .desktop-menu {
        display: none;
    }
    
    .mobile-menu-container {
        display: block;
        position: relative;
        margin-right: -0.5rem; /* چسباندن به لوگو */
    }
    
    .nav-container {
        justify-content: flex-start; /* تراز کردن از سمت چپ */
        gap: 0.5rem; /* فاصله کم بین لوگو و منو */
    }
    
    .auth-section {
        margin-left: auto; /* حساب کاربری در سمت راست */
    }
    
    .form-container {
        padding: 1rem;
    }
    
    table {
        font-size: 0.9rem;
    }
    
    th, td {
        padding: 0.8rem !important;
    }
    
    #improvementModal > div {
        width: 95% !important;
        margin: 10% auto !important;
        padding: 20px !important;
    }
    
    .auth-section .user-info {
        flex-direction: column;
        gap: 0.5rem;
    }
}
    </style>
</head>
<body>
    <!-- پس‌زمینه -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>

    <!-- ناوبری -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem">🏠 خانه</a>
                    <a href="/index.php#about" role="menuitem">📖 درباره کلاس</a>
                    <a href="/index.php#homework" role="menuitem">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" role="menuitem">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" role="menuitem">🎮 آزمون و بازی</a>
                    <a href="/index.php#podcast" role="menuitem">🎧 پادکست</a>
                    <a href="/index.php#gallery" role="menuitem">🖼️ گالری</a>
                    <a href="/index.php#feedback" role="menuitem">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" role="menuitem">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی ناوبری" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span><span class="menu-icon">▼</span>
                </button>
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" role="menuitem">🎮 آزمون و بازی</a></li>
                        <li><a href="/index.php#podcast" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <!-- Auth Section -->
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <section id="dashboard" class="section" aria-labelledby="dashboardTitle">
            <?php if ($newRecords > 0): ?>
            <div id="newDisciplineAlert" style="background: linear-gradient(135deg, #ff6b6b, #ff4757); color: white; padding: 20px; border-radius: 20px; margin-bottom: 20px; text-align: center; box-shadow: 0 10px 30px rgba(255,107,107,0.3); animation: alertBounce 2s ease-in-out;">
                <div style="font-size: 2rem; margin-bottom: 10px;">⚠️</div>
                <h3 style="margin: 0 0 10px 0; font-size: 1.5rem;">اعلان مهم!</h3>
                <p style="margin: 0; font-size: 1.1rem;">شما <?php echo $newRecords; ?> مورد انضباطی جدید دارید. لطفاً موارد زیر را مطالعه کنید.</p>
                <button onclick="hideNewAlert()" style="background: rgba(255,255,255,0.2); border: 2px solid white; color: white; padding: 10px 20px; border-radius: 15px; margin-top: 15px; cursor: pointer; font-weight: 600;">✅ متوجه شدم</button>
            </div>
            <?php endif; ?>

            <div class="form-container glass-effect">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 15px;">
                    <h2 id="dashboardTitle" style="color: #ff6b6b; margin: 0;">⚖️ موارد انضباطی من</h2>
                    
                    <div style="background: linear-gradient(135deg, #ff4757, #ff3838); color: white; padding: 15px 25px; border-radius: 20px; text-align: center; min-width: 200px; box-shadow: 0 5px 15px rgba(255,71,87,0.3);">
                        <div style="font-size: 1.1rem; font-weight: 600; margin-bottom: 5px;">جمع کل امتیاز منفی</div>
                        <div style="font-size: 2rem; font-weight: 800;">-<?php echo $totalNegativeScore; ?></div>
                    </div>
                </div>
                
                <?php if (empty($records)): ?>
                    <div style="text-align: center; padding: 3rem; background: linear-gradient(135deg, #e6ffe6, #ccffcc); border-radius: 20px; color: #28a745; box-shadow: 0 5px 15px rgba(40,167,69,0.2);">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">🎉</div>
                        <h3 style="color: #28a745; margin-bottom: 1rem;">عالی!</h3>
                        <p style="font-size: 1.2rem; margin: 0;">هیچ مورد انضباطی ثبت نشده است!</p>
                        <p style="font-size: 1rem; color: #20c997; margin-top: 10px;">شما دانش‌آموز نمونه‌ای هستید! 🌟</p>
                    </div>
                <?php else: ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                        <div style="background: linear-gradient(135deg, #74b9ff, #0984e3); color: white; padding: 20px; border-radius: 15px; text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 10px;">📊</div>
                            <div style="font-size: 1.5rem; font-weight: bold;"><?php echo count($records); ?></div>
                            <div style="font-size: 0.9rem; opacity: 0.9;">کل موارد ثبت شده</div>
                        </div>
                        
                        <?php
                        $thisMonthCount = 0;
                        $currentMonth = date('Y-m');
                        foreach($records as $record) {
                            if (substr($record['gregorian_date'], 0, 7) === $currentMonth) {
                                $thisMonthCount++;
                            }
                        }
                        ?>
                        <div style="background: linear-gradient(135deg, #fd79a8, #e84393); color: white; padding: 20px; border-radius: 15px; text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 10px;">📅</div>
                            <div style="font-size: 1.5rem; font-weight: bold;"><?php echo $thisMonthCount; ?></div>
                            <div style="font-size: 0.9rem; opacity: 0.9;">موارد این ماه</div>
                        </div>
                        
                        <?php
                        $mostCommon = [];
                        foreach($records as $record) {
                            $mostCommon[$record['title']] = ($mostCommon[$record['title']] ?? 0) + 1;
                        }
                        arsort($mostCommon);
                        $topItem = array_key_first($mostCommon);
                        ?>
                        <div style="background: linear-gradient(135deg, #fdcb6e, #e17055); color: white; padding: 20px; border-radius: 15px; text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 10px;">🔄</div>
                            <div style="font-size: 1.5rem; font-weight: bold;"><?php echo $mostCommon[$topItem] ?? 0; ?></div>
                            <div style="font-size: 0.9rem; opacity: 0.9;">بیشترین تکرار</div>
                        </div>
                    </div>

                    <div style="overflow-x: auto; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                        <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 15px; overflow: hidden;">
                            <thead>
                                <tr style="background: linear-gradient(135deg, #ff416c, #ff4b2b); color: white;">
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">ردیف</th>
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">تاریخ</th>
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">عنوان مورد</th>
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">نمره منفی</th>
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">توضیحات</th>
                                    <th style="padding: 1rem; text-align: right; font-weight: bold; font-size: 0.9rem;">وضعیت</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $rowNumber = 1;
                                foreach ($records as $record): 
                                    $isNew = ($record['gregorian_date'] === $todayDate);
                                    $rowClass = ($rowNumber % 2 == 0) ? 'background: #f8f9fa;' : 'background: white;';
                                    if ($isNew) {
                                        $rowClass = 'background: linear-gradient(135deg, #ffe5e5, #fff0f0); border-right: 5px solid #ff6b6b;';
                                    }
                                ?>
                                <tr style="<?php echo $rowClass; ?> border-bottom: 1px solid #eee;">
                                    <td style="padding: 0.8rem; font-weight: bold; color: #333; font-size: 0.85rem;"><?php echo $rowNumber; ?></td>
                                    <td style="padding: 0.8rem; color: #666; font-weight: 500; font-size: 0.85rem;">
                                        <?php echo !empty($record['persian_date']) ? $record['persian_date'] : convertToJalali($record['gregorian_date']); ?>
                                        <?php if ($isNew): ?>
                                        <span style="background: #ff6b6b; color: white; padding: 2px 6px; border-radius: 8px; font-size: 0.7rem; margin-right: 5px;">جدید</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 0.8rem; font-weight: bold; color: #721c24; font-size: 0.9rem;">
                                        <?php 
                                        $icons = [
                                            'تأخیر در حضور' => '⏰',
                                            'عدم انجام تکلیف' => '📝',
                                            'مزاحمت در کلاس' => '🗣️',
                                            'فراموشی لوازم درسی' => '🎒',
                                            'عدم رعایت نظم' => '⚠️',
                                            'بی احترامی' => '😤',
                                            'غیبت غیرموجه' => '❌'
                                        ];
                                        echo ($icons[$record['title']] ?? '⚠️') . ' ' . htmlspecialchars($record['title']);
                                        ?>
                                    </td>
                                    <td style="padding: 0.8rem; color: #dc3545; font-weight: bold; font-size: 1rem;">
                                        <?php echo $record['score']; ?> امتیاز
                                    </td>
                                    <td style="padding: 0.8rem; color: #666; max-width: 200px; font-size: 0.85rem;">
                                        <?php 
                                        $description = htmlspecialchars($record['description'] ?? 'بدون توضیح');
                                        echo strlen($description) > 50 ? substr($description, 0, 50) . '...' : $description;
                                        ?>
                                    </td>
                                    <td style="padding: 0.8rem; text-align: center;">
                                        <?php if ($isNew): ?>
                                        <span style="background: #ff6b6b; color: white; padding: 4px 10px; border-radius: 12px; font-size: 0.8rem; font-weight: 600;">🆕 جدید</span>
                                        <?php else: ?>
                                        <span style="background: #6c757d; color: white; padding: 4px 10px; border-radius: 12px; font-size: 0.8rem; font-weight: 600;">👁️ مشاهده شده</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php 
                                $rowNumber++;
                                endforeach; 
                                ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div style="text-align: center; margin-top: 2rem; display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                        <button onclick="printDisciplineList()" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 1rem 2rem; border: none; border-radius: 15px; cursor: pointer; font-weight: bold; box-shadow: 0 5px 15px rgba(102,126,234,0.3);">🖨️ چاپ لیست</button>
                        
                        <button onclick="exportToPDF()" style="background: linear-gradient(135deg, #ff7675, #d63031); color: white; padding: 1rem 2rem; border: none; border-radius: 15px; cursor: pointer; font-weight: bold; box-shadow: 0 5px 15px rgba(255,118,117,0.3);">📄 دانلود PDF</button>
                        
                        <button onclick="showImprovement()" style="background: linear-gradient(135deg, #00b894, #00a085); color: white; padding: 1rem 2rem; border: none; border-radius: 15px; cursor: pointer; font-weight: bold; box-shadow: 0 5px 15px rgba(0,184,148,0.3);">💡 راهکارهای بهبود</button>
                    </div>
                <?php endif; ?>
            </div>

            <div id="improvementModal" style="display: none; position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7);">
                <div style="background: white; margin: 5% auto; padding: 30px; border-radius: 20px; width: 90%; max-width: 600px; max-height: 80vh; overflow-y: auto;">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <h3 style="color: #00b894; margin-bottom: 10px;">💡 راهکارهای بهبود رفتار</h3>
                        <p style="color: #666;">با رعایت این نکات می‌توانید دانش‌آموز بهتری باشید</p>
                    </div>
                    
                    <div style="display: grid; gap: 15px;">
                        <div style="background: linear-gradient(135deg, #e8f5e8, #d4edda); padding: 20px; border-radius: 15px; border-right: 5px solid #28a745;">
                            <h4 style="color: #28a745; margin-bottom: 10px;">⏰ برای جلوگیری از تأخیر:</h4>
                            <ul style="margin: 0; padding-right: 20px; color: #333;">
                                <li>شب زودتر بخوابید تا صبح سرحال باشید</li>
                                <li>لباس‌ها و وسایل مدرسه را شب قبل آماده کنید</li>
                                <li>ساعت زنگ‌دار بگذارید و بلافاصله از تخت بلند شوید</li>
                            </ul>
                        </div>
                        
                        <div style="background: linear-gradient(135deg, #fff3cd, #ffeaa7); padding: 20px; border-radius: 15px; border-right: 5px solid #ffc107;">
                            <h4 style="color: #856404; margin-bottom: 10px;">📝 برای انجام بهتر تکالیف:</h4>
                            <ul style="margin: 0; padding-right: 20px; color: #333;">
                                <li>برنامه‌ریزی روزانه برای زمان مطالعه داشته باشید</li>
                                <li>در محیط آرام و بدون پیرتی‌حواس درس بخوانید</li>
                                <li>اگر مشکلی دارید، از معلم یا والدین کمک بگیرید</li>
                            </ul>
                        </div>
                        
                        <div style="background: linear-gradient(135deg, #e3f2fd, #bbdefb); padding: 20px; border-radius: 15px; border-right: 5px solid #2196f3;">
                            <h4 style="color: #1976d2; margin-bottom: 10px;">🎒 برای به یاد آوردن وسایل:</h4>
                            <ul style="margin: 0; padding-right: 20px; color: #333;">
                                <li>لیست وسایل مورد نیاز روز بعد را بنویسید</li>
                                <li>کیف مدرسه را شب قبل بچینید</li>
                                <li>یادآور روی تلفن یا یادداشت بگذارید</li>
                            </ul>
                        </div>
                        
                        <div style="background: linear-gradient(135deg, #fce4ec, #f8bbd9); padding: 20px; border-radius: 15px; border-right: 5px solid #e91e63;">
                            <h4 style="color: #c2185b; margin-bottom: 10px;">🤫 برای رعایت نظم کلاس:</h4>
                            <ul style="margin: 0; padding-right: 20px; color: #333;">
                                <li>قبل از صحبت، اجازه بگیرید</li>
                                <li>به صحبت‌های معلم و دوستان گوش دهید</li>
                                <li>در مواقع لازم، ساکت باشید و احترام بگذارید</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 25px;">
                        <button onclick="closeImprovementModal()" style="background: linear-gradient(135deg, #28a745, #20c997); color: white; border: none; padding: 15px 30px; border-radius: 15px; cursor: pointer; font-weight: bold;">✅ متوجه شدم</button>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        function navigateToSection(section) {
            window.location.href = '/index.php#' + section;
        }

        function hideNewAlert() {
            const alert = document.getElementById('newDisciplineAlert');
            if (alert) {
                alert.style.animation = 'fadeOut 0.5s ease';
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 500);
            }
        }

        function printDisciplineList() {
            const table = document.querySelector('#dashboard table');
            if (!table) {
                alert('جدولی برای چاپ یافت نشد!');
                return;
            }
            
            const printWindow = window.open('', '', 'height=700, width=1000');
            printWindow.document.write(`
                <html>
                <head>
                    <title>لیست موارد انضباطی</title>
                    <meta charset="UTF-8">
                    <style>
                        body { 
                            font-family: 'Vazir', Tahoma, Arial, sans-serif; 
                            direction: rtl; 
                            text-align: right; 
                            padding: 20px; 
                            line-height: 1.6;
                        }
                        table { 
                            width: 100%; 
                            border-collapse: collapse; 
                            margin: 20px 0;
                        }
                        th, td { 
                            border: 1px solid #ddd; 
                            padding: 12px; 
                            text-align: right; 
                        }
                        th { 
                            background: #ff416c; 
                            color: white; 
                            font-weight: bold; 
                        }
                        tr:nth-child(even) { 
                            background: #f8f9fa; 
                        }
                        h2 { 
                            text-align: center; 
                            color: #ff416c; 
                            margin-bottom: 30px; 
                        }
                        .header-info { 
                            text-align: center; 
                            margin-bottom: 20px; 
                            padding: 15px; 
                            background: #f8f9fa; 
                            border-radius: 10px; 
                        }
                        .print-date {
                            text-align: left;
                            margin-top: 20px;
                            font-size: 0.9rem;
                            color: #666;
                        }
                    </style>
                </head>
                <body>
                    <div class="header-info">
                        <h2>📋 لیست موارد انضباطی</h2>
                        <p><strong>تاریخ چاپ:</strong> ${new Date().toLocaleDateString('fa-IR')}</p>
                    </div>
                    ${table.outerHTML}
                    <div class="print-date">
                        <p>این گزارش از سامانه آموزشی ستاره ماه تهیه شده است</p>
                        <p>تاریخ و زمان چاپ: ${new Date().toLocaleString('fa-IR')}</p>
                    </div>
                </body>
                </html>
            `);
            printWindow.document.close();
            
            setTimeout(() => {
                printWindow.print();
            }, 500);
        }

        function exportToPDF() {
            alert('قابلیت دانلود PDF در نسخه بعدی اضافه خواهد شد.\nفعلاً می‌توانید از گزینه چاپ استفاده کنید.');
        }

        function showImprovement() {
            const modal = document.getElementById('improvementModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            }
        }

        function closeImprovementModal() {
            const modal = document.getElementById('improvementModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        window.onclick = function(event) {
            const modal = document.getElementById('improvementModal');
            if (event.target === modal) {
                closeImprovementModal();
            }
        }

        // منوی موبایل
        document.addEventListener('DOMContentLoaded', function() {
            createStars();
            
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');
            
            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                    }
                });
                
                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    }
                });
                
                mobileDropdown.addEventListener('click', function(e) {
                    if (e.target.tagName === 'A') {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                    }
                });
            }
        });

        // مخفی کردن خودکار اعلان بعد از 10 ثانیه
        setTimeout(() => {
            const alert = document.getElementById('newDisciplineAlert');
            if (alert && alert.style.display !== 'none') {
                hideNewAlert();
            }
        }, 10000);

        console.log('Dashboard loaded successfully');
    </script>
</body>
</html>