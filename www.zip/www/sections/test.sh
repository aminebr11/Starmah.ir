#!/bin/bash

###############################################################################
# اسکریپت نصب خودکار کلاس آنلاین starmah.ir
# Domain: class.starmah.ir
# IP: 141.11.45.117
###############################################################################

set -e  # خروج در صورت خطا

# رنگ‌ها برای خروجی
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# تابع برای چاپ پیام‌ها
print_msg() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[i]${NC} $1"
}

# بررسی root
if [ "$EUID" -ne 0 ]; then 
    print_error "لطفاً این اسکریپت را با دسترسی root اجرا کنید"
    echo "استفاده: sudo bash install.sh"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║         نصب خودکار سیستم کلاس آنلاین                      ║"
echo "║                 starmah.ir WebRTC Classroom               ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# دریافت اطلاعات از کاربر
read -p "دامنه شما (پیش‌فرض: class.starmah.ir): " DOMAIN
DOMAIN=${DOMAIN:-class.starmah.ir}

read -p "ایمیل برای SSL (برای Let's Encrypt): " EMAIL

if [ -z "$EMAIL" ]; then
    print_error "ایمیل الزامی است!"
    exit 1
fi

print_info "دامنه: $DOMAIN"
print_info "ایمیل: $EMAIL"
echo ""

read -p "آیا ادامه می‌دهیم؟ (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_warning "نصب لغو شد"
    exit 1
fi

echo ""
print_msg "شروع نصب..."
echo ""

# =========================================
# مرحله 1: به‌روزرسانی سیستم
# =========================================
print_info "مرحله 1/9: به‌روزرسانی سیستم..."
apt update -qq > /dev/null 2>&1
apt upgrade -y -qq > /dev/null 2>&1
apt install -y curl wget git nano ufw > /dev/null 2>&1
print_msg "سیستم به‌روزرسانی شد"

# =========================================
# مرحله 2: نصب Node.js
# =========================================
print_info "مرحله 2/9: نصب Node.js 18..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash - > /dev/null 2>&1
    apt install -y nodejs > /dev/null 2>&1
    print_msg "Node.js نصب شد ($(node -v))"
else
    print_msg "Node.js از قبل نصب است ($(node -v))"
fi

# =========================================
# مرحله 3: ایجاد ساختار پوشه‌ها
# =========================================
print_info "مرحله 3/9: ایجاد پوشه‌های پروژه..."
mkdir -p /var/www/webrtc-classroom/public
cd /var/www/webrtc-classroom
print_msg "پوشه‌ها ایجاد شدند"

# =========================================
# مرحله 4: ایجاد فایل server.js
# =========================================
print_info "مرحله 4/9: ایجاد فایل server.js..."
cat > server.js << 'SERVERJS'
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const rooms = new Map();

io.on('connection', (socket) => {
  console.log('کاربر جدید متصل شد:', socket.id);

  socket.on('join-room', ({ roomId, userName, isTeacher }) => {
    socket.join(roomId);
    
    if (!rooms.has(roomId)) {
      rooms.set(roomId, {
        teacher: null,
        students: new Map()
      });
    }

    const room = rooms.get(roomId);
    
    if (isTeacher) {
      room.teacher = { id: socket.id, name: userName };
      console.log(`معلم ${userName} وارد اتاق ${roomId} شد`);
    } else {
      room.students.set(socket.id, { name: userName });
      console.log(`دانش‌آموز ${userName} وارد اتاق ${roomId} شد`);
    }

    socket.to(roomId).emit('user-joined', {
      userId: socket.id,
      userName: userName,
      isTeacher: isTeacher
    });

    const users = [];
    if (room.teacher) {
      users.push({
        userId: room.teacher.id,
        userName: room.teacher.name,
        isTeacher: true
      });
    }
    room.students.forEach((student, id) => {
      users.push({
        userId: id,
        userName: student.name,
        isTeacher: false
      });
    });
    
    socket.emit('room-users', users.filter(u => u.userId !== socket.id));
  });

  socket.on('offer', ({ targetId, offer, userName }) => {
    io.to(targetId).emit('offer', {
      senderId: socket.id,
      offer: offer,
      userName: userName
    });
  });

  socket.on('answer', ({ targetId, answer }) => {
    io.to(targetId).emit('answer', {
      senderId: socket.id,
      answer: answer
    });
  });

  socket.on('ice-candidate', ({ targetId, candidate }) => {
    io.to(targetId).emit('ice-candidate', {
      senderId: socket.id,
      candidate: candidate
    });
  });

  socket.on('chat-message', ({ roomId, message, userName }) => {
    io.to(roomId).emit('chat-message', {
      userId: socket.id,
      userName: userName,
      message: message,
      timestamp: new Date().toISOString()
    });
  });

  socket.on('disconnect', () => {
    console.log('کاربر قطع شد:', socket.id);
    
    rooms.forEach((room, roomId) => {
      if (room.teacher && room.teacher.id === socket.id) {
        room.teacher = null;
        io.to(roomId).emit('user-left', { userId: socket.id, isTeacher: true });
      } else if (room.students.has(socket.id)) {
        room.students.delete(socket.id);
        io.to(roomId).emit('user-left', { userId: socket.id, isTeacher: false });
      }
      
      if (!room.teacher && room.students.size === 0) {
        rooms.delete(roomId);
      }
    });
  });
});

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    rooms: rooms.size,
    timestamp: new Date().toISOString()
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`✅ سرور در حال اجرا بر روی پورت ${PORT}`);
  console.log(`🌐 آدرس: http://localhost:${PORT}`);
});
SERVERJS

print_msg "فایل server.js ایجاد شد"

# =========================================
# مرحله 5: ایجاد فایل package.json
# =========================================
print_info "مرحله 5/9: ایجاد فایل package.json..."
cat > package.json << 'PACKAGEJSON'
{
  "name": "webrtc-classroom-starmah",
  "version": "1.0.0",
  "description": "سیستم کلاس آنلاین starmah.ir",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "keywords": ["webrtc", "classroom", "starmah"],
  "author": "starmah.ir",
  "license": "MIT",
  "dependencies": {
    "express": "^4.18.2",
    "socket.io": "^4.6.1",
    "cors": "^2.8.5"
  }
}
PACKAGEJSON

print_msg "فایل package.json ایجاد شد"

# =========================================
# مرحله 6: نصب وابستگی‌ها
# =========================================
print_info "مرحله 6/9: نصب وابستگی‌های npm..."
npm install --silent > /dev/null 2>&1
print_msg "وابستگی‌ها نصب شدند"

# =========================================
# مرحله 7: نصب PM2
# =========================================
print_info "مرحله 7/9: نصب و تنظیم PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2 --silent > /dev/null 2>&1
    print_msg "PM2 نصب شد"
fi

# حذف برنامه قبلی (اگر وجود داشت)
pm2 delete classroom 2>/dev/null || true

# راه‌اندازی برنامه
pm2 start server.js --name classroom > /dev/null 2>&1
pm2 save > /dev/null 2>&1
pm2 startup > /dev/null 2>&1
print_msg "PM2 راه‌اندازی شد"

# =========================================
# مرحله 8: نصب و تنظیم Nginx
# =========================================
print_info "مرحله 8/9: نصب و تنظیم Nginx..."
if ! command -v nginx &> /dev/null; then
    apt install -y nginx > /dev/null 2>&1
    print_msg "Nginx نصب شد"
else
    print_msg "Nginx از قبل نصب است"
fi

# ایجاد فایل کانفیگ
cat > /etc/nginx/sites-available/$DOMAIN << NGINXCONF
server {
    listen 80;
    server_name $DOMAIN;

    access_log /var/log/nginx/classroom-access.log;
    error_log /var/log/nginx/classroom-error.log;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location /socket.io/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
NGINXCONF

# فعال‌سازی سایت
ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# تست و راه‌اندازی مجدد
nginx -t > /dev/null 2>&1
systemctl restart nginx
systemctl enable nginx > /dev/null 2>&1
print_msg "Nginx تنظیم شد"

# =========================================
# مرحله 9: نصب SSL
# =========================================
print_info "مرحله 9/9: نصب SSL با Let's Encrypt..."
if ! command -v certbot &> /dev/null; then
    apt install -y certbot python3-certbot-nginx > /dev/null 2>&1
    print_msg "Certbot نصب شد"
fi

# دریافت گواهی SSL
certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email $EMAIL --redirect > /dev/null 2>&1
if [ $? -eq 0 ]; then
    print_msg "SSL نصب شد ✓"
else
    print_warning "SSL نصب نشد. لطفاً دستی اجرا کنید: certbot --nginx -d $DOMAIN"
fi

# =========================================
# مرحله 10: تنظیم Firewall
# =========================================
print_info "تنظیم Firewall..."
ufw --force enable > /dev/null 2>&1
ufw allow 22/tcp > /dev/null 2>&1
ufw allow 80/tcp > /dev/null 2>&1
ufw allow 443/tcp > /dev/null 2>&1
ufw allow 10000:20000/udp > /dev/null 2>&1
print_msg "Firewall تنظیم شد"

# =========================================
# نمایش اطلاعات نهایی
# =========================================
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                  ✅ نصب با موفقیت انجام شد!               ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
print_msg "دامنه: https://$DOMAIN"
print_msg "وضعیت سرور: $(pm2 list | grep classroom | awk '{print $10}')"
echo ""
echo "دستورات مفید:"
echo "  pm2 status          - وضعیت سرویس"
echo "  pm2 logs classroom  - مشاهده لاگ‌ها"
echo "  pm2 restart classroom - راه‌اندازی مجدد"
echo ""
print_info "حالا می‌توانید به https://$DOMAIN بروید و کلاس خود را شروع کنید!"
echo ""