<?php
session_start();
require_once '../config.php';
require_once '../functions.php'; // <-- این خط را اضافه کنید


// تابع محاسبه شنبه و جمعه هفته قبل
function getPreviousWeekBounds() {
    $now = time();
    $currentWeekday = (int)jdate('w', $now); // 0=شنبه
    $saturdayTimestamp = $now - ($currentWeekday * 86400);
    
    // برای گرفتن هفته قبل، 7 روز از شنبه این هفته کم می‌کنیم
    $prevSaturdayTimestamp = $saturdayTimestamp - (7 * 86400);
    $prevFridayTimestamp = $prevSaturdayTimestamp + (6 * 86400);

    // اطلاعات هفته قبل برای ذخیره در جدول خلاصه
    $fridayPersianDate = jdate('Y-n-j', $prevFridayTimestamp);
    list($year, $month, $day) = explode('-', $fridayPersianDate);
    $weekNumber = ceil($day / 7);

    return [
        'start' => date('Y-m-d 00:00:00', $prevSaturdayTimestamp),
        'end' => date('Y-m-d 23:59:59', $prevFridayTimestamp),
        'year' => $year,
        'month' => $month,
        'week_number' => $weekNumber,
        'week_start_date' => date('Y-m-d', $prevSaturdayTimestamp)
    ];
}

try {
    $bounds = getPreviousWeekBounds();

    // چک کردن اینکه آیا برای این هفته داده قبلا ذخیره شده یا نه
    $checkStmt = $conn->prepare("SELECT id FROM weekly_xp_summary WHERE year = :year AND month = :month AND week_number = :week_number");
    $checkStmt->execute([
        ':year' => $bounds['year'],
        ':month' => $bounds['month'],
        ':week_number' => $bounds['week_number']
    ]);

    if ($checkStmt->fetch()) {
        echo "Data for week {$bounds['week_number']} of {$bounds['month']}/{$bounds['year']} already exists.\n";
        exit;
    }

    // کوئری اصلی برای محاسبه و ذخیره امتیازات
    $sql = "
        INSERT INTO weekly_xp_summary (student_id, year, month, week_number, total_xp, week_start_date)
        SELECT 
            h.student_id,
            :year as year,
            :month as month,
            :week_number as week_number,
            COALESCE(SUM(CASE WHEN h.amount > 0 THEN h.amount ELSE 0 END), 0) as weekly_xp,
            :week_start_date as week_start_date
        FROM xp_history h
        WHERE h.created_at >= :week_start AND h.created_at <= :week_end
        GROUP BY h.student_id
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':year' => $bounds['year'],
        ':month' => $bounds['month'],
        ':week_number' => $bounds['week_number'],
        ':week_start_date' => $bounds['week_start_date'],
        ':week_start' => $bounds['start'],
        ':week_end' => $bounds['end']
    ]);

    echo "Successfully aggregated data for week {$bounds['week_number']} of {$bounds['month']}/{$bounds['year']}. Records inserted: " . $stmt->rowCount() . "\n";

} catch (PDOException $e) {
    error_log("PDO Error in aggregate_weekly_xp: " . $e->getMessage());
    echo "An error occurred: " . $e->getMessage();
}
?>