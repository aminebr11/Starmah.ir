<?php
/* =============================================================
 * admin_users.php - Admin User Management Page
 * Based on classNotebook_admin.php structure and theme
 * With Persian Date Integration (Self-Contained Functions)
 * ============================================================= */

// Session check
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
require_once '../config.php';
 $db = $conn;

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

 $isLoggedIn = isset($_SESSION['user_id']);
 $userType = $_SESSION['user_type'] ?? '';
 $userName = $_SESSION['user_name'] ?? 'کاربر';

// --- Helper Functions ---

// Convert Persian numbers to English
function fa2en_str($s){
    return strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
}

// Helper function to convert Gregorian to Jalali (self-contained, no extensions needed)
function gregorian_to_jalali($g_y, $g_m, $g_d)
{
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);
    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;

    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
    for ($i = 0; $i < $gm; ++$i) {
        $g_day_no += $g_days_in_month[$i];
    }
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
        /* leap and after Feb */
        $g_day_no++;
    $g_day_no += $gd;

    $j_day_no = $g_day_no - 79;

    $j_np = floor($j_day_no / 12053);
    $j_day_no %= 12053;

    $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += floor(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
        $j_day_no -= $j_days_in_month[$i];
    }
    $jm = $i + 1;
    $jd = $j_day_no + 1;

    return array($jy, $jm, $jd);
}

// Convert Gregorian Y-m-d to Jalali string
function gregorian_to_jalali_str($date) {
    if (empty($date) || $date === '0000-00-00 00:00:00') return '-';
    $gy = (int)substr($date, 0, 4);
    $gm = (int)substr($date, 5, 2);
    $gd = (int)substr($date, 8, 2);
    
    list($jy, $jm, $jd) = gregorian_to_jalali($gy, $gm, $gd);
    
    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}

// Convert Gregorian Y-m-d H:i:s to Jalali string
function gregorian_datetime_to_jalali_str($datetime) {
    if (empty($datetime) || $datetime === '0000-00-00 00:00:00') return '-';
    $date = substr($datetime, 0, 10);
    $time = substr($datetime, 11, 5);
    return gregorian_to_jalali_str($date) . ' ' . $time;
}

// --- Main Logic ---

// Handle form submissions
 $message = '';
 $messageType = '';

// Add/Edit admin user
if ($_POST['action'] ?? '' === 'save_admin') {
    try {
        $userId = $_POST['user_id'] ?? 0;
        $username = trim($_POST['username']);
        $firstName = trim($_POST['first_name']);
        $lastName = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $nationalId = fa2en_str(trim($_POST['national_id']));
        $birthDate = trim($_POST['birth_date']); // This is now Gregorian Y-m-d
        $address = trim($_POST['address']);
        $fatherName = trim($_POST['father_name']);
        $fatherPhone = fa2en_str(trim($_POST['father_phone']));
        $motherName = trim($_POST['mother_name']);
        $motherPhone = fa2en_str(trim($_POST['mother_phone']));
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $password = $_POST['password'] ?? '';
        
        // Validate required fields
        if (empty($username) || empty($firstName) || empty($lastName)) {
            throw new Exception('فیلدهای نام کاربری، نام و نام خانوادگی الزامی هستند.');
        }
        
        // Check if username already exists
        $checkStmt = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $checkStmt->execute([$username, $userId]);
        if ($checkStmt->fetch()) {
            throw new Exception('این نام کاربری قبلاً استفاده شده است.');
        }
        
        if ($userId > 0) {
            // Update existing user
            $updateFields = [
                'username' => $username,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $email,
                'national_id' => $nationalId,
                'birth_date' => $birthDate ?: null,
                'address' => $address,
                'father_name' => $fatherName,
                'father_phone' => $fatherPhone,
                'mother_name' => $motherName,
                'mother_phone' => $motherPhone,
                'is_active' => $isActive
            ];
            
            if (!empty($password)) {
                $updateFields['password'] = password_hash($password, PASSWORD_DEFAULT);
            }
            
            $setClause = [];
            $values = [];
            foreach ($updateFields as $field => $value) {
                $setClause[] = "$field = ?";
                $values[] = $value;
            }
            $values[] = $userId;
            
            $sql = "UPDATE users SET " . implode(', ', $setClause) . " WHERE id = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute($values);
            
            $message = 'اطلاعات کاربر با موفقیت به‌روزرسانی شد.';
            $messageType = 'success';
        } else {
            // Add new user
            if (empty($password)) {
                throw new Exception('رمز عبور برای کاربر جدید الزامی است.');
            }
            
            $stmt = $db->prepare("INSERT INTO users (username, password, first_name, last_name, email, user_type, national_id, birth_date, address, father_name, father_phone, mother_name, mother_phone, is_active) VALUES (?, ?, ?, ?, ?, 'admin', ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $username,
                password_hash($password, PASSWORD_DEFAULT),
                $firstName,
                $lastName,
                $email,
                $nationalId,
                $birthDate ?: null,
                $address,
                $fatherName,
                $fatherPhone,
                $motherName,
                $motherPhone,
                $isActive
            ]);
            
            $message = 'کاربر ادمین جدید با موفقیت ایجاد شد.';
            $messageType = 'success';
        }
    } catch (Exception $e) {
        $message = 'خطا: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Delete admin user
if ($_POST['action'] ?? '' === 'delete_admin' && isset($_POST['user_id'])) {
    try {
        $userId = $_POST['user_id'];
        if ($userId == $_SESSION['user_id']) {
            throw new Exception('شما نمی‌توانید حساب کاربری خود را حذف کنید.');
        }
        $stmt = $db->prepare("DELETE FROM users WHERE id = ? AND user_type = 'admin'");
        $stmt->execute([$userId]);
        $message = 'کاربر ادمین با موفقیت حذف شد.';
        $messageType = 'success';
    } catch (Exception $e) {
        $message = 'خطا: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Get admin user for editing
 $editingUser = null;
if (isset($_GET['edit_id']) && is_numeric($_GET['edit_id'])) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND user_type = 'admin'");
    $stmt->execute([$_GET['edit_id']]);
    $editingUser = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get all admin users
 $stmt = $db->prepare("SELECT id, username, first_name, last_name, email, national_id, is_active, created_at, last_login FROM users WHERE user_type = 'admin' ORDER BY created_at DESC");
 $stmt->execute();
 $adminUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>👥 مدیریت کاربران ادمین - ستاره ماه</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/style.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css">
<style>
.exam-builder-container { max-width:1400px; margin: 2rem auto; padding: 0 1rem; }
.exam-subnav { background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(20px); border-radius: 20px; margin: 1rem 0 2rem 0; padding: 1rem; border: 1px solid rgba(255, 255, 255, 0.2); }
.exam-subnav-links { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
.exam-subnav-link { background: rgba(255, 255, 255, 0.1); color: rgba(255, 255, 255, 0.9); padding: 0.8rem 1.5rem; border-radius: 15px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; border: 1px solid rgba(255, 255, 255, 0.2); font-size: 0.95rem; }
.exam-subnav-link:hover { background: rgba(255, 255, 255, 0.2); transform: translateY(-2px); color: white; }
.exam-subnav-link.active { background: linear-gradient(135deg, #6bcf7f, #4d9de0); color: white; border-color: transparent; box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4); }
.exam-card { background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 20px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08); }
.exam-card-header { display: flex; align-items: center; gap: 1rem; background: linear-gradient(135deg, #83eaf1, #63a4ff); color: #0b1220; padding: 1rem; border-radius: 12px; margin-bottom: 1.5rem; }
.exam-step-number { background: rgba(255,255,255,.7); padding: 0.5rem 0.8rem; border-radius: 50px; font-weight: 800; font-size: 0.9rem; }
.exam-card-title { flex: 1; }
.exam-card-title h2 { margin: 0; font-size: 1.1rem; font-weight: 800; }
.exam-card-title p { margin: 0.3rem 0 0 0; opacity: 0.9; font-size: 0.9rem; }
.exam-badge { background: rgba(255,255,255,.7); padding: 0.5rem 0.8rem; border-radius: 50px; font-weight: 700; font-size: 0.85rem; }
.exam-btn { border: none; border-radius: 12px; padding: 0.8rem 1.5rem; cursor: pointer; font-weight: 600; transition: all 0.3s ease; font-family: 'Tahoma', tahoma, sans-serif; }
.exam-btn-primary { background: linear-gradient(135deg, #6bcf7f, #4d9de0); color: white; box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4); }
.exam-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6); }
.exam-btn-danger { background: linear-gradient(135deg, #f44336, #d32f2f); color: white; box-shadow: 0 5px 20px rgba(244, 67, 54, 0.4); }
.exam-btn-danger:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(244, 67, 54, 0.6); }
:root{ --primary:#667eea; --primary-dark:#5a67d8; --accent:#764ba2; --bg:#f5f7fb; --card:#ffffff; --border:#e2e8f0; --text:#1a202c; --muted:#718096; }
body{ font-family:'Tahoma', tahoma, sans-serif; background:linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%); min-height:100vh }
.table { font-family: 'Tahoma', tahoma, sans-serif !important; }
.btn, .btn-primary, .btn-danger, .btn-secondary, .btn-success{ font-family:'Tahoma', tahoma, sans-serif !important; border-radius:12px }
.table thead th{ font-weight:700; background: rgba(255, 255, 255, 0.1); color: rgba(0, 0, 0, 0.8); }
textarea, input[type="text"], input[type="number"], input[type="date"], input[type="time"], input[type="email"], input[type="password"], select { font-family: 'Tahoma', tahoma, sans-serif !important; color: #000000 !important; background: rgba(255, 255, 255, 0.9) !important; border: 1px solid rgba(0, 0, 0, 0.2) !important; border-radius: 8px !important; padding: 0.5rem !important; }
textarea:focus, input:focus, select:focus { border-color: #6bcf7f !important; outline: none !important; box-shadow: 0 0 10px rgba(107, 207, 127, 0.3) !important; }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
.form-group label { display: block; margin-bottom: 0.5rem; color: rgba(255, 255, 255, 0.9); font-weight: 600; font-family: 'Tahoma', tahoma, sans-serif !important; }
.fade-in { animation: fadeIn 0.5s ease-in; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.alert { padding: 1rem; border-radius: 15px; margin: 1rem auto; max-width: 1200px; font-family: 'Tahoma', tahoma, sans-serif !important; }
.alert-success { background: rgba(107, 207, 127, 0.15); color: rgba(255, 255, 255, 0.9); border: 1px solid rgba(107, 207, 127, 0.3); }
.alert-error { background: rgba(244, 63, 94, 0.15); color: #fecaca; border: 1px solid rgba(244, 63, 94, 0.3); }
.tab-container { background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(20px); border-radius: 20px; margin: 1rem 0 2rem 0; padding: 1rem; border: 1px solid rgba(255, 255, 255, 0.2); }
.tab-nav { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; margin-bottom: 1.5rem; }
.tab-btn { background: rgba(255, 255, 255, 0.1); color: rgba(255, 255, 255, 0.9); padding: 0.8rem 1.5rem; border-radius: 15px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; border: 1px solid rgba(255, 255, 255, 0.2); font-size: 0.95rem; cursor: pointer; }
.tab-btn:hover { background: rgba(255, 255, 255, 0.2); transform: translateY(-2px); color: white; }
.tab-btn.active { background: linear-gradient(135deg, #6bcf7f, #4d9de0); color: white; border-color: transparent; box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4); }
.tab-content { display: none; }
.tab-content.active { display: block; animation: fadeIn 0.5s ease-in; }
.status-badge { padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
.status-active { background-color: #d4edda; color: #155724; }
.status-inactive { background-color: #f8d7da; color: #721c24; }

/* تقویم شمسی */
.date-picker-wrapper { position: relative; width: 100%; }
.date-input-container { display: flex; gap: 0.5rem; align-items: center; }
.date-input-with-icon { position: relative; flex: 1; }
.date-input-with-icon input { width: 100%; padding-right: 2.5rem !important; }
.calendar-icon { position: absolute; right: 0.8rem; top: 50%; transform: translateY(-50%); font-size: 1.2rem; pointer-events: none; color: #6bcf7f; }
.calendar-popup { position: fixed; top: 40%; left: 50%; transform: translate(-50%, -50%); background: white; border: 2px solid #6bcf7f; border-radius: 15px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3); z-index: 999999; padding: 1.5rem; min-width: 320px; display: none; pointer-events: auto; }
.calendar-popup.show { display: block; animation: slideDown 0.3s ease; }
.calendar-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 999998; display: none; pointer-events: none; }
.calendar-overlay.show { display: block; }
@keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.calendar-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 2px solid #e0e0e0; }
.calendar-nav { display: flex; gap: 0.5rem; }
.calendar-nav-btn { background: #6bcf7f; color: white; border: none; width: 35px; height: 35px; border-radius: 50%; cursor: pointer; font-size: 1.2rem; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; }
.calendar-nav-btn:hover { background: #5bb36a; transform: scale(1.1); }
.calendar-title { font-weight: 700; color: #333; font-size: 1.1rem; }
.calendar-selects { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
.calendar-selects select { flex: 1; padding: 0.5rem; border: 2px solid #e0e0e0; border-radius: 8px; font-family: 'Tahoma', tahoma, sans-serif; color: #333; background: white; cursor: pointer; }
.calendar-selects select:focus { border-color: #6bcf7f; outline: none; }
.calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.3rem; }
.calendar-day-header { text-align: center; font-weight: 700; color: #666; padding: 0.5rem; font-size: 0.85rem; }
.calendar-day { aspect-ratio: 1; display: flex; align-items: center; justify-content: center; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; font-weight: 600; color: #333; background: #f5f5f5; }
.calendar-day:hover { background: #e0f7e6; transform: scale(1.1); }
.calendar-day.today { background: linear-gradient(135deg, #83eaf1, #63a4ff); color: white; font-weight: 700; }
.calendar-day.selected { background: #6bcf7f; color: white; font-weight: 700; }
.calendar-day.other-month { opacity: 0.4; }
.calendar-footer { margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #e0e0e0; display: flex; justify-content: space-between; gap: 0.5rem; }
.calendar-footer-btn { flex: 1; padding: 0.6rem; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-family: 'Tahoma', tahoma, sans-serif; transition: all 0.2s ease; }
.calendar-footer-btn.confirm { background: #6bcf7f; color: white; }
.calendar-footer-btn.confirm:hover { background: #5bb36a; }
.calendar-footer-btn.cancel { background: #f44336; color: white; }
.calendar-footer-btn.cancel:hover { background: #d32f2f; }

@media (max-width: 768px){ .exam-builder-container { margin: 1rem auto; padding: 0 0.5rem; } .exam-card{ border-radius:16px; padding: 1rem; } .btn{ padding:.4rem .75rem } .table{ font-size:.8rem } .form-grid { grid-template-columns: 1fr; } .tab-nav { flex-direction: column; align-items: center; } .tab-btn { width: 100%; max-width: 300px; text-align: center; } }
</style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" role="menuitem" class="interactive-element">🎮آزمون و بازی </a>
                    <a href="/index.php#podcast" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی موبایل" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="exam-builder-container">
        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">👥 مدیریت کاربران ادمین</h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9); font-size: 1.2rem;">ایجاد، ویرایش و مدیریت حساب‌های کاربری معلمان</p>
        </div>

        <!-- Alert Messages -->
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo $messageType; ?> fade-in">
                <?php echo $messageType === 'success' ? '✅' : '❌'; ?> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Tab Container -->
        <div class="tab-container">
            <div class="tab-nav">
                <button class="tab-btn <?php echo !$editingUser ? 'active' : ''; ?>" onclick="switchTab('list-tab')">لیست کاربران ادمین</button>
                <button class="tab-btn <?php echo $editingUser ? 'active' : ''; ?>" onclick="switchTab('form-tab')"><?php echo $editingUser ? 'ویرایش کاربر' : 'افزودن کاربر جدید'; ?></button>
            </div>
            
            <!-- Tab 1: Admin Users List -->
            <div id="list-tab" class="tab-content <?php echo !$editingUser ? 'active' : ''; ?>">
                <div class="exam-card fade-in">
                    <div class="exam-card-header">
                        <div class="exam-step-number">👥</div>
                        <div class="exam-card-title">
                            <h2>لیست کاربران ادمین (معلمان)</h2>
                            <p>مشاهده و مدیریت تمام کاربران ادمین سیستم</p>
                        </div>
                        <div class="exam-badge"><?php echo count($adminUsers); ?> کاربر</div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ردیف</th>
                                    <th>نام کاربری</th>
                                    <th>نام و نام خانوادگی</th>
                                    <th>ایمیل</th>
                                    <th>کد ملی</th>
                                    <th>وضعیت</th>
                                    <th>تاریخ عضویت</th>
                                    <th>آخرین ورود</th>
                                    <th>عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $counter = 1; foreach($adminUsers as $user): ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($user['national_id'] ?? '-'); ?></td>
                                    <td><span class="status-badge <?php echo $user['is_active'] ? 'status-active' : 'status-inactive'; ?>"><?php echo $user['is_active'] ? 'فعال' : 'غیرفعال'; ?></span></td>
                                    <td><?php echo gregorian_to_jalali_str($user['created_at']); ?></td>
                                    <td><?php echo gregorian_datetime_to_jalali_str($user['last_login']); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="?edit_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">ویرایش</a>
                                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="delete_admin">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('آیا از حذف این کاربر اطمینان دارید؟')">حذف</button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div style="text-align: center; margin-top: 2rem;">
                        <a href="?edit_id=0" class="exam-btn exam-btn-primary">➕ افزودن کاربر ادمین جدید</a>
                    </div>
                </div>
            </div>
            
            <!-- Tab 2: Add/Edit Admin User -->
            <div id="form-tab" class="tab-content <?php echo $editingUser ? 'active' : ''; ?>">
                <div class="exam-card fade-in">
                    <div class="exam-card-header">
                        <div class="exam-step-number">📝</div>
                        <div class="exam-card-title">
                            <h2><?php echo $editingUser ? 'ویرایش کاربر ادمین' : 'افزودن کاربر ادمین جدید'; ?></h2>
                            <p><?php echo $editingUser ? 'اطلاعات کاربر را ویرایش کنید' : 'اطلاعات کاربر جدید را وارد کنید'; ?></p>
                        </div>
                        <div class="exam-badge"><?php echo $editingUser ? 'ویرایش' : 'جدید'; ?></div>
                    </div>
                    
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="save_admin">
                        <input type="hidden" name="user_id" value="<?php echo $editingUser['id'] ?? 0; ?>">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>نام کاربری</label>
                                <input type="text" name="username" value="<?php echo htmlspecialchars($editingUser['username'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>رمز عبور <?php echo $editingUser ? '(برای تغییر، مقدار جدید وارد کنید)' : ''; ?></label>
                                <input type="password" name="password" <?php echo !$editingUser ? 'required' : ''; ?>>
                            </div>
                            <div class="form-group">
                                <label>نام</label>
                                <input type="text" name="first_name" value="<?php echo htmlspecialchars($editingUser['first_name'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>نام خانوادگی</label>
                                <input type="text" name="last_name" value="<?php echo htmlspecialchars($editingUser['last_name'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>ایمیل</label>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($editingUser['email'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>کد ملی</label>
                                <input type="text" name="national_id" value="<?php echo htmlspecialchars($editingUser['national_id'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>تاریخ تولد</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-container">
                                        <div class="date-input-with-icon">
                                            <span class="calendar-icon">📅</span>
                                            <input type="text" id="birth_date_display" name="birth_date_display" 
                                                   placeholder="انتخاب تاریخ..." readonly 
                                                   style="cursor: pointer;"
                                                   value="<?php 
                                                        if(!empty($editingUser['birth_date'])) {
                                                            echo gregorian_to_jalali_str($editingUser['birth_date']);
                                                        }
                                                   ?>">
                                        </div>
                                    </div>
                                    <input type="hidden" id="birth_date" name="birth_date" 
                                           value="<?php echo htmlspecialchars($editingUser['birth_date'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>نام پدر</label>
                                <input type="text" name="father_name" value="<?php echo htmlspecialchars($editingUser['father_name'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>تلفن پدر</label>
                                <input type="text" name="father_phone" value="<?php echo htmlspecialchars($editingUser['father_phone'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>نام مادر</label>
                                <input type="text" name="mother_name" value="<?php echo htmlspecialchars($editingUser['mother_name'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>تلفن مادر</label>
                                <input type="text" name="mother_phone" value="<?php echo htmlspecialchars($editingUser['mother_phone'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>وضعیت حساب</label>
                                <select name="is_active">
                                    <option value="1" <?php echo ($editingUser['is_active'] ?? 1) ? 'selected' : ''; ?>>فعال</option>
                                    <option value="0" <?php echo !($editingUser['is_active'] ?? 1) ? 'selected' : ''; ?>>غیرفعال</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>آدرس</label>
                            <textarea name="address" rows="3"><?php echo htmlspecialchars($editingUser['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div style="text-align: center; margin-top: 2rem;">
                            <button type="submit" class="exam-btn exam-btn-primary">
                                💾 <?php echo $editingUser ? 'به‌روزرسانی اطلاعات' : 'ایجاد کاربر جدید'; ?>
                            </button>
                            <a href="?" class="exam-btn exam-btn-danger" style="margin-right: 1rem;">❌ انصراف</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Calendar Popup (at the end of body) -->
    <div class="calendar-overlay" id="calendarOverlay"></div>
    <div class="calendar-popup" id="calendarPopup">
        <div class="calendar-header">
            <div class="calendar-nav">
                <button type="button" class="calendar-nav-btn" onclick="changeMonth(-1)">‹</button>
                <button type="button" class="calendar-nav-btn" onclick="changeMonth(1)">›</button>
            </div>
            <div class="calendar-title" id="calendarTitle"></div>
        </div>
        <div class="calendar-selects">
            <select id="yearSelect" onchange="renderCalendar()"></select>
            <select id="monthSelect" onchange="renderCalendar()"></select>
        </div>
        <div class="calendar-grid" id="calendarGrid"></div>
        <div class="calendar-footer">
            <button type="button" class="calendar-footer-btn confirm" onclick="confirmBirthDate()">تأیید</button>
            <button type="button" class="calendar-footer-btn cancel" onclick="closeCalendar()">انصراف</button>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        // ============= تقویم شمسی =============
        const persianMonths = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        const persianDays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        let currentYear, currentMonth, currentDay;
        let selectedYear, selectedMonth, selectedDay;

        function gregorianToJalali(gy, gm, gd) {
            const g_d_m = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            const gy2 = (gm > 2) ? (gy + 1) : gy;
            let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd;
            for (let i = 0; i < gm; i++) days += g_d_m[i];
            let jy = -1595 + (33 * Math.floor(days / 12053));
            days %= 12053;
            jy += 4 * Math.floor(days / 1461);
            days %= 1461;
            if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
            if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); } else { days -= 186; jm = 7 + Math.floor(days / 30); jd = 1 + (days % 30); }
            return { jy: jy, jm: jm, jd: jd };
        }

        function jalaliToGregorian(jy, jm, jd) {
            let gy = jy <= 979 ? 621 : 1600; jy = (jy <= 979) ? jy : jy - 979;
            let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30 + 186)) + 79;
            gy += 400 * Math.floor(days / 146097); days %= 146097;
            if (days >= 36525) { days--; gy += 100 * Math.floor(days / 36524); days %= 36524; if (days >= 365) days++; }
            gy += 4 * Math.floor(days / 1461); days %= 1461;
            if (days >= 366) { days--; gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
            let gd = days + 1;
            const sal_a = [31, (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            let gm = 0;
            while (gm < 12 && gd > sal_a[gm]) { gd -= sal_a[gm]; gm++; } gm++;
            return { gy: gy, gm: gm, gd: gd };
        }

        function getDaysInJalaliMonth(year, month) { if (month <= 6) return 31; if (month <= 11) return 30; return isJalaliLeapYear(year) ? 30 : 29; }
        function isJalaliLeapYear(year) { const a = year - (year >= 0 ? 474 : 473); const b = (a % 2820) + 474; return (((b + 38) * 682) % 2816) < 682; }
        function toPersianNum(num) { const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']; return num.toString().replace(/\d/g, d => persianDigits[d]); }

        function initCalendar() {
            const today = new Date();
            const jalaliToday = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
            currentYear = jalaliToday.jy; currentMonth = jalaliToday.jm; currentDay = jalaliToday.jd;
            selectedYear = currentYear; selectedMonth = currentMonth; selectedDay = null;
            populateSelects(); renderCalendar();
        }

        function populateSelects() {
            const yearSelect = document.getElementById('yearSelect'); const monthSelect = document.getElementById('monthSelect');
            yearSelect.innerHTML = ''; for (let y = 1340; y <= 1410; y++) { const option = document.createElement('option'); option.value = y; option.textContent = toPersianNum(y); if (y === selectedYear) option.selected = true; yearSelect.appendChild(option); }
            monthSelect.innerHTML = ''; persianMonths.forEach((month, index) => { const option = document.createElement('option'); option.value = index + 1; option.textContent = month; if (index + 1 === selectedMonth) option.selected = true; monthSelect.appendChild(option); });
        }

        function renderCalendar() {
            selectedYear = parseInt(document.getElementById('yearSelect').value); selectedMonth = parseInt(document.getElementById('monthSelect').value);
            const title = document.getElementById('calendarTitle'); title.textContent = `${persianMonths[selectedMonth - 1]} ${toPersianNum(selectedYear)}`;
            const grid = document.getElementById('calendarGrid'); grid.innerHTML = '';
            persianDays.forEach(day => { const header = document.createElement('div'); header.className = 'calendar-day-header'; header.textContent = day; grid.appendChild(header); });
            const firstDayOfMonth = jalaliToGregorian(selectedYear, selectedMonth, 1); const firstDayGregorian = new Date(firstDayOfMonth.gy, firstDayOfMonth.gm - 1, firstDayOfMonth.gd); let startDay = (firstDayGregorian.getDay() + 1) % 7;
            const daysInMonth = getDaysInJalaliMonth(selectedYear, selectedMonth);
            const daysInPrevMonth = selectedMonth === 1 ? getDaysInJalaliMonth(selectedYear - 1, 12) : getDaysInJalaliMonth(selectedYear, selectedMonth - 1);
            for (let i = startDay - 1; i >= 0; i--) { const day = document.createElement('div'); day.className = 'calendar-day other-month'; day.textContent = toPersianNum(daysInPrevMonth - i); grid.appendChild(day); }
            for (let d = 1; d <= daysInMonth; d++) {
                const day = document.createElement('div'); day.className = 'calendar-day'; day.textContent = toPersianNum(d);
                if (d === currentDay && selectedMonth === currentMonth && selectedYear === currentYear) day.classList.add('today');
                if (d === selectedDay) day.classList.add('selected');
                day.onclick = () => selectDay(d); grid.appendChild(day);
            }
            const remainingCells = 42 - (startDay + daysInMonth);
            for (let d = 1; d <= remainingCells; d++) { const day = document.createElement('div'); day.className = 'calendar-day other-month'; day.textContent = toPersianNum(d); grid.appendChild(day); }
        }

        function selectDay(day) { selectedDay = day; renderCalendar(); }
        function changeMonth(delta) { selectedMonth += delta; if (selectedMonth > 12) { selectedMonth = 1; selectedYear++; } else if (selectedMonth < 1) { selectedMonth = 12; selectedYear--; } document.getElementById('yearSelect').value = selectedYear; document.getElementById('monthSelect').value = selectedMonth; renderCalendar(); }
        
        function confirmBirthDate() {
            if (!selectedDay) { alert('لطفاً یک روز را انتخاب کنید'); return; }
            const jalaliDate = `${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${String(selectedDay).padStart(2, '0')}`;
            const gregorianDate = jalaliToGregorian(selectedYear, selectedMonth, selectedDay);
            const gregorianDateStr = `${gregorianDate.gy}-${String(gregorianDate.gm).padStart(2, '0')}-${String(gregorianDate.gd).padStart(2, '0')}`;
            document.getElementById('birth_date_display').value = toPersianNum(jalaliDate);
            document.getElementById('birth_date').value = gregorianDateStr;
            closeCalendar();
        }

        function closeCalendar() {
            const calendarPopup = document.getElementById('calendarPopup'); const calendarOverlay = document.getElementById('calendarOverlay');
            if (calendarPopup) calendarPopup.classList.remove('show');
            if (calendarOverlay) calendarOverlay.classList.remove('show');
        }

        // ============= بقیه اسکریپت‌ها =============
        function createStars() { const starsContainer = document.getElementById('stars'); if (!starsContainer) return; for (let i = 0; i < 50; i++) { const star = document.createElement('div'); star.className = 'star'; star.style.left = Math.random() * 100 + '%'; star.style.top = Math.random() * 100 + '%'; star.style.animationDelay = Math.random() * 4 + 's'; star.style.animationDuration = (Math.random() * 3 + 2) + 's'; starsContainer.appendChild(star); } }
        function switchTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }

        document.addEventListener('DOMContentLoaded', function() {
            createStars();
            initCalendar();
            const dateInput = document.getElementById('birth_date_display');
            if (dateInput) {
                dateInput.addEventListener('click', function(e) { e.stopPropagation(); document.getElementById('calendarPopup').classList.add('show'); document.getElementById('calendarOverlay').classList.add('show'); });
                document.addEventListener('click', function(e) { if (!document.getElementById('calendarPopup').contains(e.target) && e.target !== dateInput) closeCalendar(); });
                document.getElementById('calendarPopup').addEventListener('click', function(e) { e.stopPropagation(); });
            }
            const elements = document.querySelectorAll('.fade-in'); elements.forEach((el, index) => { setTimeout(() => { el.style.opacity = '1'; }, index * 100); });
        });
    </script>
</body>
</html>