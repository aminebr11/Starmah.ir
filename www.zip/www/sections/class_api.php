<?php
/**
 * کلاس آنلاین پایدار برای تعداد بالا (تا 1 میلیون نفر هم پشتیبانی میکند)
 * تکنولوژی: Agora SDK - معماری: Host/Audience
 */

session_start();

// احراز هویت ساده (مشابه کد قبلی خودتان)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = rand(1000, 9999);
    $_SESSION['full_name'] = isset($_GET['name']) ? $_GET['name'] : 'کاربر مهمان ' . rand(1, 100);
    // تعیین نقش: اگر در url عبارت ?admin=1 باشد، نقش هاست میگیرد
    $_SESSION['role'] = isset($_GET['admin']) ? 'host' : 'audience'; 
}

$userRole = $_SESSION['role']; // 'host' (مدیر/معلم) یا 'audience' (دانش آموز)
$uid = $_SESSION['user_id'];
$classCode = isset($_GET['class']) ? "cls_" . $_GET['class'] : 'moonstar_demo_101';

// ============================================
// !!! حتما App ID خود را در اینجا قرار دهید !!!
$APP_ID = "caecd45cf272443d92f25b1a09cd92a2"; 
// ============================================

if ($APP_ID == "YOUR_AGORA_APP_ID_HERE") {
    die("<div style='direction:rtl;text-align:center;margin-top:50px;'><h3>⚠️ لطفاً App ID آگورا را در فایل کد وارد کنید.</h3><p>ثبت نام در console.agora.io رایگان است.</p></div>");
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>کلاس آنلاین (نسخه پایدار)</title>
    <style>
        /* استایل بهینه شده */
        :root { --bg: #212121; --primary: #0088cc; --video-bg: #323232; }
        body { margin: 0; padding: 0; font-family: 'Tahoma', sans-serif; background: var(--bg); color: white; height: 100vh; overflow: hidden; }
        
        .main-container { display: flex; height: 100%; }
        
        /* بخش ویدیوها */
        .video-stage { flex: 3; position: relative; display: flex; flex-direction: column; padding: 10px; gap: 10px; }
        #full-stream { flex: 1; background: #000; border-radius: 10px; position: relative; overflow: hidden; border: 2px solid #444; }
        .stream-name { position: absolute; bottom: 10px; right: 10px; background: rgba(0,0,0,0.6); padding: 5px 10px; border-radius: 5px; font-size: 12px; pointer-events: none; z-index: 10; }
        
        /* پنل کناری */
        .sidebar { flex: 1; background: #2a2a2a; border-left: 1px solid #444; display: flex; flex-direction: column; max-width: 300px; }
        .sidebar-header { padding: 15px; background: #333; text-align: center; border-bottom: 1px solid #444; font-weight: bold; }
        .log-area { flex: 1; padding: 10px; overflow-y: auto; font-size: 12px; color: #aaa; font-family: monospace; direction: ltr; text-align: left; }
        
        /* کنترل بار */
        .controls { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); display: flex; gap: 15px; z-index: 20; padding: 10px; background: rgba(0,0,0,0.5); border-radius: 50px; backdrop-filter: blur(5px); }
        .btn { width: 50px; height: 50px; border-radius: 50%; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 20px; transition: 0.3s; }
        .btn.primary { background: var(--primary); color: white; }
        .btn.danger { background: #e74c3c; color: white; }
        .btn:hover { transform: scale(1.1); }
        .btn:disabled { background: #555; opacity: 0.5; cursor: not-allowed; }
        
        /* لودینگ */
        #loader { position: fixed; inset: 0; background: var(--bg); z-index: 999; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .msg-box { margin-top: 20px; color: #00cec9; animation: pulse 1s infinite; }
        @keyframes pulse { 50% { opacity: 0.5; } }

        /* پنهان سازی برای دانش آموزان */
        .teacher-only { display: <?php echo ($userRole === 'host') ? 'flex' : 'none !important'; ?>; }
        
        /* کلاس برای ویدیوی داخل کانتینر */
        .agora_video_player { object-fit: cover !important; }
    </style>
    <!-- لود کتابخانه آگورا (نسخه پایدار و سبک) -->
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N-4.11.0.js"></script>
</head>
<body>

    <!-- لودینگ اولیه -->
    <div id="loader">
        <h2>🚀 در حال اتصال به شبکه پرسرعت...</h2>
        <div class="msg-box" id="loader-msg">لطفا صبر کنید</div>
    </div>

    <div class="main-container">
        <!-- پنل ویدیو اصلی (تصویر استاد) -->
        <div class="video-stage">
            <div id="full-stream">
                <div class="stream-name" id="main-name-label">
                    <?php echo ($userRole === 'host') ? 'تصویر شما (منتظر شروع)' : 'منتظر تصویر استاد...'; ?>
                </div>
            </div>
            
            <!-- دکمه های کنترل (فقط برای استاد) -->
            <div class="controls teacher-only">
                <button class="btn primary" id="btn-mic" onclick="toggleMic()">🎤</button>
                <button class="btn primary" id="btn-cam" onclick="toggleCam()">📷</button>
                <button class="btn danger" onclick="leave()">🚪</button>
            </div>
            
             <!-- دکمه خروج دانش آموز -->
             <div class="controls" style="display: <?php echo ($userRole === 'audience') ? 'flex' : 'none'; ?>">
                <button class="btn danger" onclick="leave()">🚪 خروج</button>
            </div>
        </div>

        <!-- سایدبار اطلاعات -->
        <div class="sidebar">
            <div class="sidebar-header">
                👤 <?php echo $_SESSION['full_name']; ?> 
                <span style="font-size:11px; display:block; margin-top:5px; color:#888;">
                    (<?php echo ($userRole === 'host') ? 'معلم / پخش کننده' : 'دانش‌آموز / بیننده'; ?>)
                </span>
            </div>
            <div class="log-area" id="log-box"></div>
        </div>
    </div>

    <script>
        // === تنظیمات ===
        const APP_ID = "<?php echo $APP_ID; ?>";
        const CHANNEL = "<?php echo $classCode; ?>";
        const ROLE = "<?php echo $userRole; ?>"; // 'host' or 'audience'
        const UID = <?php echo $uid; ?>;
        
        // شیء کلاینت
        const client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });
        let localTracks = { videoTrack: null, audioTrack: null };

        // --- شروع سیستم ---
        async function init() {
            try {
                updateLog("سیستم شروع شد...");
                client.setClientRole(ROLE);
                
                // مدیریت رویداد: وقتی کاربر دیگری (استاد) پخش را شروع کرد
                client.on("user-published", handleUserPublished);
                client.on("user-unpublished", handleUserUnpublished);

                // ورود به کانال
                updateLog("در حال ورود به کانال...");
                await client.join(APP_ID, CHANNEL, null, UID);
                updateLog(`وارد شدید. شناسه شما: ${UID}`);

                if (ROLE === 'host') {
                    // اگر معلم هستید، دوربین و میکروفون را روشن کنید
                    updateLog("در حال دریافت دسترسی دوربین...");
                    localTracks.audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
                    localTracks.videoTrack = await AgoraRTC.createCameraVideoTrack();
                    
                    // نمایش تصویر خود معلم برای خودش
                    localTracks.videoTrack.play("full-stream");
                    document.getElementById("main-name-label").innerText = "شما (در حال پخش)";
                    
                    // ارسال صدا و تصویر به شبکه
                    updateLog("در حال انتشار تصویر...");
                    await client.publish([localTracks.audioTrack, localTracks.videoTrack]);
                    updateLog("تصویر شما در حال پخش است.");
                } else {
                    // اگر دانش آموز هستید
                    updateLog("شما در حالت تماشاچی هستید. منتظر استاد باشید.");
                }

                // حذف لودینگ
                document.getElementById('loader').style.display = 'none';

            } catch (error) {
                console.error(error);
                updateLog("ERROR: " + error.message);
                document.getElementById('loader-msg').innerHTML = "خطا در اتصال:<br>" + error.message + "<br><small>بررسی کنید AppID صحیح باشد</small>";
                document.getElementById('loader-msg').style.color = "red";
            }
        }

        // --- وقتی کسی ویدیو منتشر کرد ---
        async function handleUserPublished(user, mediaType) {
            await client.subscribe(user, mediaType);
            updateLog(`دریافت استریم از: ${user.uid}`);

            if (mediaType === 'video') {
                // اگر قبلا پلیری هست، حذفش نمیکنیم چون تک استریم است، جایگزین میشود
                // ویدیو را در کادر اصلی پخش کن
                user.videoTrack.play("full-stream");
                document.getElementById("main-name-label").innerText = "تصویر استاد";
            }
            if (mediaType === 'audio') {
                user.audioTrack.play();
            }
        }

        // --- وقتی کسی قطع کرد ---
        function handleUserUnpublished(user) {
            updateLog(`کاربر ${user.uid} قطع شد`);
            // صفحه سیاه نمیشود، آخرین فریم میماند یا میتوان پیغام گذاشت
             document.getElementById("main-name-label").innerText = "استاد تصویر را قطع کرد";
        }

        // --- کنترل دکمه ها (مخصوص معلم) ---
        async function toggleMic() {
            if (localTracks.audioTrack) {
                const muted = localTracks.audioTrack.muted;
                await localTracks.audioTrack.setMuted(!muted);
                document.getElementById('btn-mic').innerText = !muted ? '🔇' : '🎤';
                document.getElementById('btn-mic').classList.toggle('danger');
            }
        }

        async function toggleCam() {
            if (localTracks.videoTrack) {
                const muted = localTracks.videoTrack.muted;
                await localTracks.videoTrack.setMuted(!muted);
                document.getElementById('btn-cam').innerText = !muted ? '⬛' : '📷';
                document.getElementById('btn-cam').classList.toggle('danger');
            }
        }

        async function leave() {
            for (trackName in localTracks) {
                var track = localTracks[trackName];
                if (track) {
                    track.stop();
                    track.close();
                    localTracks[trackName] = undefined;
                }
            }
            await client.leave();
            window.location.href = '../index.php';
        }

        // --- لاگر ساده ---
        function updateLog(msg) {
            const box = document.getElementById('log-box');
            const p = document.createElement('div');
            p.innerText = "> " + msg;
            box.appendChild(p);
            box.scrollTop = box.scrollHeight;
        }

        // اجرای خودکار
        init();
    </script>
</body>
</html>