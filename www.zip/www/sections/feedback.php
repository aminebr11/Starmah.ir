<?php
if (!isLoggedIn()) { exit(); }
$userId   = (int)($_SESSION['user_id'] ?? 0);
$userType = $_SESSION['user_type'] ?? 'student';

$first = $_SESSION['first_name'] ?? '';
$last  = $_SESSION['last_name']  ?? '';
$stuFullName = trim($first.' '.$last);

/* مپ فارسی موضوع‌ها */
$subjectFa = [
  'academic'=>'پیشرفت تحصیلی',
  'homework'=>'تکالیف و برنامه‌ریزی',
  'attention'=>'تمرکز/توجه',
  'behavior'=>'رفتار و اخلاق',
  'bullying'=>'تنمر/همسالان',
  'motivation'=>'انگیزه و اعتمادبه‌نفس',
  'schedule'=>'زمان‌بندی/حضور',
  'health'=>'سلامت/خواب/تغذیه',
  'special'=>'نیازهای ویژه',
  'suggestion'=>'پیشنهاد',
  'complaint'=>'شکایت/نگرانی',
  'technical'=>'مشکل فنی',
  'other'=>'موضوع دلخواه',
];
?>
<section id="feedback" class="section" style="direction:rtl">
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

  <style>
    :root{
      --primary: #667eea;
      --primary-dark: #5a67d8;
      --success: #48bb78;
      --warning: #ed8936;
      --danger: #f56565;
      --info: #4299e1;
      
      --surface: #ffffff;
      --surface-elevated: #f7fafc;
      --surface-hover: #edf2f7;
      --border: #e2e8f0;
      --border-light: #f1f5f9;
      --text-primary: #2d3748;
      --text-secondary: #4a5568;
      --text-muted: #718096;
      
      --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
      --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
      --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
      
      --radius-sm: 6px;
      --radius-md: 8px;
      --radius-lg: 12px;
      --radius-xl: 16px;
    }

    #feedback {
      font-family: "Vazirmatn", -apple-system, BlinkMacSystemFont, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 2rem;
    }

    #feedback * {
      color: var(--text-primary);
      box-sizing: border-box;
    }

    .feedback-container {
      max-width: 1400px;
      margin: 0 auto;
    }

    /* Header */
    .header-section {
      background: var(--surface);
      border-radius: var(--radius-xl);
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: var(--shadow-xl);
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .header-section::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--primary), var(--info));
    }

    .header-title {
      font-size: 2rem;
      font-weight: 800;
      background: linear-gradient(90deg, var(--primary), var(--info));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      margin-bottom: 1rem;
    }

    .header-subtitle {
      color: var(--text-secondary);
      font-size: 1rem;
      margin-bottom: 0;
    }

    /* Alert Bar */
    .alert-bar {
      display: none;
      background: linear-gradient(90deg, var(--warning), #f6ad55);
      color: white;
      padding: 1rem 1.5rem;
      border-radius: var(--radius-lg);
      margin-bottom: 2rem;
      box-shadow: var(--shadow-md);
      font-weight: 600;
      text-align: center;
    }

    /* Layout */
    .main-layout {
      display: grid;
      gap: 2rem;
    }

    .user-layout {
      grid-template-columns: 400px 1fr;
    }

    .admin-layout {
      grid-template-columns: 1fr;
    }

    @media (max-width: 1024px) {
      .user-layout {
        grid-template-columns: 1fr;
      }
    }
.form-card {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: 2rem;
  box-shadow: var(--shadow-lg);
  height: auto; /* تغییر از fit-content */
  /* position: sticky; حذف این خط */
  /* top: 2rem; حذف این خط */
  margin-bottom: 2rem; /* اضافه کردن فاصله از پایین */
}

    .form-title {
      font-size: 1.25rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid var(--border-light);
    }

    .form-group {
      margin-bottom: 1.25rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    @media (max-width: 640px) {
      .form-row {
        grid-template-columns: 1fr;
      }
    }

    .form-label {
      display: block;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: var(--text-primary);
      font-size: 0.875rem;
    }

    .form-input {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 2px solid var(--border);
      border-radius: var(--radius-md);
      font-size: 0.875rem;
      transition: all 0.2s ease;
      background: var(--surface);
    }

    .form-input:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }

    .form-textarea {
      min-height: 100px;
      resize: vertical;
    }

    .hint-text {
      font-size: 0.75rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
    }

    /* Topics Grid */
    .topics-section {
      margin: 1.25rem 0;
    }

    .topics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 0.75rem;
      margin-top: 1rem;
    }

    .topic-item {
      position: relative;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .topic-input {
      position: absolute;
      opacity: 0;
      width: 100%;
      height: 100%;
      cursor: pointer;
    }

    .topic-card {
      padding: 1rem;
      background: var(--surface-elevated);
      border: 2px solid var(--border-light);
      border-radius: var(--radius-md);
      text-align: center;
      transition: all 0.2s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
      min-height: 80px;
      justify-content: center;
    }

    .topic-item:hover .topic-card {
      border-color: var(--primary);
      background: var(--surface-hover);
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }

    .topic-item.selected .topic-card {
      border-color: var(--primary);
      background: rgba(102, 126, 234, 0.1);
      box-shadow: var(--shadow-md);
    }

    .topic-icon {
      font-size: 1.25rem;
    }

    .topic-text {
      font-size: 0.75rem;
      font-weight: 600;
      line-height: 1.2;
    }

    .custom-topic-input {
      display: none;
      margin-top: 1rem;
    }

    /* Buttons */
    .btn {
      padding: 0.75rem 1.5rem;
      border-radius: var(--radius-md);
      font-weight: 600;
      font-size: 0.875rem;
      border: none;
      cursor: pointer;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      text-decoration: none;
    }

    .btn-primary {
      background: var(--primary);
      color: white;
    }

    .btn-primary:hover {
      background: var(--primary-dark);
      transform: translateY(-1px);
      box-shadow: var(--shadow-md);
    }

    .btn-success {
      background: var(--success);
      color: white;
    }

    .btn-success:hover {
      background: #38a169;
      transform: translateY(-1px);
    }

    .btn-warning {
      background: var(--warning);
      color: white;
    }

    .btn-danger {
      background: var(--danger);
      color: white;
    }

    .btn-secondary {
      background: var(--surface-elevated);
      color: var(--text-secondary);
      border: 1px solid var(--border);
    }

    .btn-secondary:hover {
      background: var(--surface-hover);
    }

    .btn-row {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      margin-top: 1.5rem;
    }

    /* AI Response */
    .ai-response {
      display: none;
      margin-top: 1.5rem;
      padding: 1.5rem;
      background: rgba(66, 153, 225, 0.1);
      border: 1px solid rgba(66, 153, 225, 0.2);
      border-radius: var(--radius-lg);
    }

    .ai-response-title {
      font-weight: 700;
      margin-bottom: 1rem;
      color: var(--info);
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    /* History Panel */
    .history-panel {
      background: var(--surface);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-lg);
    }

    .history-title {
      font-size: 1.25rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid var(--border-light);
    }

    .history-empty {
      text-align: center;
      padding: 3rem 2rem;
      color: var(--text-muted);
      background: var(--surface-elevated);
      border-radius: var(--radius-lg);
      border: 2px dashed var(--border);
    }

    /* Parent Message Cards */
    .parent-message {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      margin-bottom: 1rem;
      cursor: pointer;
      transition: all 0.2s ease;
      overflow: hidden;
    }

    .parent-message:hover {
      box-shadow: var(--shadow-md);
      transform: translateY(-1px);
    }

    .parent-message.expanded {
      box-shadow: var(--shadow-lg);
    }

    .parent-header {
      padding: 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
      background: var(--surface-elevated);
    }

    .parent-content {
      flex: 1;
    }

    .parent-subject {
      font-weight: 700;
      font-size: 1rem;
      margin-bottom: 0.5rem;
      color: var(--text-primary);
    }

    .parent-preview {
      color: var(--text-secondary);
      line-height: 1.5;
      margin-bottom: 0.5rem;
    }

    .parent-time {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .parent-status-area {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .status-badge {
      padding: 0.375rem 0.75rem;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 600;
      white-space: nowrap;
    }

    .status-pending {
      background: rgba(245, 101, 101, 0.1);
      color: var(--danger);
      border: 1px solid rgba(245, 101, 101, 0.2);
    }

    .status-responded {
      background: rgba(72, 187, 120, 0.1);
      color: var(--success);
      border: 1px solid rgba(72, 187, 120, 0.2);
    }

    .status-archived {
      background: rgba(113, 128, 150, 0.1);
      color: var(--text-muted);
      border: 1px solid rgba(113, 128, 150, 0.2);
    }

    .expand-icon {
      color: var(--text-muted);
      font-size: 1.25rem;
      transition: transform 0.2s ease;
    }

    .parent-message.expanded .expand-icon {
      transform: rotate(180deg);
    }

    /* Response Details - مخفی به صورت پیش‌فرض */
    .response-details {
      display: none !important;
      border-top: 1px solid var(--border);
    }

    .parent-message.expanded .response-details {
      display: block !important;
    }

    .response-item {
      padding: 1.5rem;
      border-bottom: 1px solid var(--border-light);
    }

    .response-item:last-child {
      border-bottom: none;
    }

    .response-header {
      font-weight: 700;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
    }

    .response-ai {
      background: rgba(66, 153, 225, 0.05);
    }

    .response-ai .response-header {
      color: var(--info);
    }

    .response-teacher {
      background: rgba(72, 187, 120, 0.05);
    }

    .response-teacher .response-header {
      color: var(--success);
    }

    .response-content {
      line-height: 1.6;
      color: var(--text-secondary);
    }

    .response-pending {
      background: rgba(237, 137, 54, 0.05);
      text-align: center;
      font-style: italic;
      color: var(--text-muted);
    }

    /* Gmail-like Admin Layout */
    .admin-panel {
      background: var(--surface);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-lg);
      height: 80vh;
      display: flex;
      overflow: hidden;
    }

    .gmail-layout {
      display: flex;
      flex-direction: row;
      height: 100%;
      width: 100%;
    }

    /* Sidebar */
    .sidebar {
      width: 220px;
      background: var(--surface);
      border-right: 1px solid var(--border);
      padding: 1rem 0;
      overflow-y: auto;
    }

    .sidebar-logo {
      padding: 1rem 1.5rem;
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--primary);
      border-bottom: 1px solid var(--border-light);
      margin-bottom: 1rem;
    }

    .nav-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .nav-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.75rem 1.5rem;
      cursor: pointer;
      transition: background 0.2s ease;
      font-weight: 500;
      position: relative;
    }

    .nav-item:hover {
      background: var(--surface-hover);
    }

    .nav-item.active {
      background: var(--surface-hover);
      color: var(--primary);
      border-right: 3px solid var(--primary);
    }

    .nav-icon {
      margin-left: 0.75rem;
      font-size: 1.1rem;
    }

    .nav-count {
      background: var(--text-muted);
      color: white;
      border-radius: 10px;
      padding: 0.125rem 0.5rem;
      font-size: 0.75rem;
      min-width: 18px;
      text-align: center;
    }

    /* Main Content */
    .main {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.75rem 1rem;
      background: var(--surface-elevated);
      border-bottom: 1px solid var(--border);
      height: 50px;
    }

    .top-bar .left {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .top-bar .checkbox {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      color: var(--text-secondary);
    }

    .top-bar .btn-icon {
      background: none;
      border: none;
      font-size: 1.2rem;
      cursor: pointer;
      padding: 0.25rem;
      border-radius: var(--radius-sm);
      transition: background 0.2s;
      color: var(--text-secondary);
    }

    .top-bar .btn-icon:hover {
      background: var(--surface-hover);
    }

    .top-bar .search {
      flex: 1;
      max-width: 400px;
      position: relative;
      margin: 0 2rem;
    }

    .top-bar input[type="search"] {
      width: 100%;
      padding: 0.5rem 1rem;
      border: 1px solid var(--border);
      border-radius: var(--radius-md);
      background: var(--surface);
    }

    .top-bar .right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    /* Content Area */
    .content {
      display: flex;
      flex: 1;
      overflow: hidden;
    }

    .message-list {
      flex: 1;
      overflow-y: auto;
      border-right: 1px solid var(--border);
    }

    .message-row {
      display: grid;
      grid-template-columns: 40px 50px 200px 1fr 120px;
      align-items: center;
      padding: 1rem;
      border-bottom: 1px solid var(--border-light);
      cursor: pointer;
      transition: background 0.2s;
      height: 60px;
    }

    .message-row:hover {
      background: var(--surface-hover);
    }

    .message-row.selected {
      background: rgba(102, 126, 234, 0.1);
    }

    .message-row.unread {
      font-weight: 500;
    }

    .col-checkbox input {
      width: 16px;
      height: 16px;
    }

    .col-avatar {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--primary);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.875rem;
      font-weight: 600;
    }

    .col-from .name {
      font-weight: 600;
      margin-bottom: 0.25rem;
    }

    .col-from .email {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .col-subject .subject-line {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 0.25rem;
    }

    .col-subject .subject {
      font-weight: 500;
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .col-subject .label {
      padding: 0.125rem 0.5rem;
      border-radius: 4px;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .label.responded {
      background: rgba(72, 187, 120, 0.2);
      color: var(--success);
    }

    .body-preview {
      font-size: 0.875rem;
      color: var(--text-secondary);
      max-width: 400px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .col-date {
      font-size: 0.75rem;
      text-align: left;
      color: var(--text-muted);
    }

    /* Message Pane */
    .message-pane {
      flex: 1;
      background: var(--surface-elevated);
      display: flex;
      flex-direction: column;
      overflow-y: auto;
    }

    .no-selection {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--text-muted);
      text-align: center;
      padding: 2rem;
    }

    .no-selection h2 {
      margin-bottom: 0.5rem;
      font-size: 1.5rem;
    }

    .message-detail {
      flex: 1;
      padding: 1rem;
      overflow-y: auto;
    }

    .message-header {
      border-bottom: 1px solid var(--border-light);
      padding-bottom: 1rem;
      margin-bottom: 1rem;
    }

    .message-header h1 {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
    }

    .message-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      font-size: 0.875rem;
      color: var(--text-secondary);
    }

    .conversation-thread {
      margin-bottom: 1rem;
    }

    .thread-message {
      margin-bottom: 1.5rem;
      padding: 1.5rem;
      border-radius: var(--radius-lg);
      border: 1px solid var(--border);
      background: var(--surface);
      box-shadow: var(--shadow-sm);
    }

    .thread-message.parent {
      background: linear-gradient(135deg, rgba(113, 128, 150, 0.05), rgba(113, 128, 150, 0.1));
      border-color: rgba(113, 128, 150, 0.3);
    }

    .thread-message.ai {
      background: linear-gradient(135deg, rgba(66, 153, 225, 0.05), rgba(66, 153, 225, 0.1));
      border-color: rgba(66, 153, 225, 0.3);
    }

    .thread-message.teacher {
      background: linear-gradient(135deg, rgba(72, 187, 120, 0.05), rgba(72, 187, 120, 0.1));
      border-color: rgba(72, 187, 120, 0.3);
    }

    .thread-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
      padding-bottom: 0.75rem;
      border-bottom: 1px solid var(--border-light);
    }

    .thread-sender {
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.95rem;
    }

    .thread-time {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .thread-content {
      line-height: 1.7;
      color: var(--text-secondary);
      white-space: pre-wrap;
    }

    .reply-section {
      background: var(--surface);
      padding: 1.5rem;
      border-radius: var(--radius-lg);
      border: 2px solid var(--success);
      box-shadow: var(--shadow-md);
      margin-top: auto;
    }

    .reply-title {
      font-weight: 700;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: var(--success);
      font-size: 1.1rem;
    }

    .reply-textarea {
      width: 100%;
      min-height: 120px;
      padding: 1rem;
      border: 2px solid var(--border);
      border-radius: var(--radius-md);
      font-family: inherit;
      resize: vertical;
      margin-bottom: 1rem;
      font-size: 0.95rem;
      line-height: 1.6;
    }

    .reply-textarea:focus {
      outline: none;
      border-color: var(--success);
      box-shadow: 0 0 0 3px rgba(72, 187, 120, 0.1);
    }

    .reply-actions {
      display: flex;
      gap: 1rem;
      justify-content: flex-end;
    }

    /* Loading */
    .loading {
      text-align: center;
      padding: 2rem;
      color: var(--text-muted);
    }

    .spinner {
      display: inline-block;
      width: 1rem;
      height: 1rem;
      border: 2px solid #f3f3f3;
      border-top: 2px solid var(--primary);
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* Responsive */
    @media (max-width: 1024px) {
      .gmail-layout {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--border);
      }

      .message-row {
        grid-template-columns: 40px 1fr 120px;
      }

      .col-from {
        grid-column: span 2;
      }

      .col-subject {
        display: none;
      }

      .message-pane {
        order: -1;
      }
    }

    @media (max-width: 768px) {
      #feedback {
        padding: 1rem;
      }

      .header-title {
        font-size: 1.5rem;
      }

      .top-bar {
        flex-wrap: wrap;
      }

      .top-bar .search {
        margin: 0.5rem 0;
        order: 3;
        width: 100%;
      }
    }

    /* Cascade Card System - برای user history */
    .conversation-cascade {
      margin-bottom: 2rem;
      position: relative;
    }

    .cascade-card {
      background: var(--surface);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-md);
      margin-bottom: 1rem;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      border: 2px solid var(--border);
      overflow: hidden;
    }

    .cascade-card:hover {
      box-shadow: var(--shadow-lg);
      transform: translateY(-2px);
    }

    /* Parent Card Styles */
    .parent-card {
      position: relative;
      border: 2px solid var(--border);
      background: linear-gradient(135deg, var(--surface) 0%, var(--surface-elevated) 100%);
    }

    .parent-card.answered {
      border-color: var(--success);
      background: linear-gradient(135deg, rgba(72, 187, 120, 0.05) 0%, var(--surface) 100%);
    }

    .parent-card.pending {
      border-color: var(--warning);
    }

    /* Card Header */
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      border-bottom: 1px solid var(--border-light);
      background: var(--surface-elevated);
    }

    .card-sender {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .sender-icon {
      font-size: 1.25rem;
    }

    .sender-name {
      font-weight: 600;
      color: var(--text-primary);
    }

    .card-meta {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .status-indicator {
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 0.25rem;
    }

    .status-indicator.answered {
      background: rgba(72, 187, 120, 0.1);
      color: var(--success);
      border: 1px solid rgba(72, 187, 120, 0.3);
    }

    .status-indicator.pending {
      background: rgba(237, 137, 54, 0.1);
      color: var(--warning);
      border: 1px solid rgba(237, 137, 54, 0.3);
    }

    .card-time {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    /* Card Body */
    .card-body {
      padding: 1.5rem;
    }

    .message-content {
      line-height: 1.7;
      color: var(--text-secondary);
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    /* Card Footer */
    .card-footer {
      padding: 0.75rem 1.5rem;
      background: var(--surface-elevated);
      border-top: 1px solid var(--border-light);
    }

    .expand-btn {
      background: none;
      border: none;
      color: var(--primary);
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 0;
      transition: all 0.2s ease;
    }

    .expand-btn:hover {
      color: var(--primary-dark);
      transform: translateX(5px);
    }

    .expand-icon {
      transition: transform 0.3s ease;
      font-size: 0.875rem;
    }

    /* Response Cards */
    .cascade-responses {
      padding-left: 2rem;
      position: relative;
    }

    .cascade-responses::before {
      content: '';
      position: absolute;
      left: 1rem;
      top: -1rem;
      bottom: 1rem;
      width: 2px;
      background: linear-gradient(180deg, var(--border) 0%, transparent 100%);
    }

    /* AI Card */
    .ai-card {
      background: linear-gradient(135deg, rgba(66, 153, 225, 0.05) 0%, var(--surface) 100%);
      border-color: rgba(66, 153, 225, 0.3);
    }

    .ai-card .card-header {
      background: rgba(66, 153, 225, 0.1);
    }

    /* Teacher Card */
    .teacher-card {
      background: linear-gradient(135deg, rgba(72, 187, 120, 0.05) 0%, var(--surface) 100%);
      border-color: rgba(72, 187, 120, 0.3);
    }

    .teacher-card .card-header {
      background: rgba(72, 187, 120, 0.1);
    }

    /* Pending Card */
    .pending-card {
      background: var(--surface-elevated);
      border: 2px dashed var(--border);
    }

    /* Card Badge */
    .card-badge {
      padding: 0.25rem 0.75rem;
      border-radius: var(--radius-sm);
      font-size: 0.7rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      background: var(--surface-elevated);
      color: var(--text-muted);
      border: 1px solid var(--border);
    }

    .card-badge.success {
      background: rgba(72, 187, 120, 0.1);
      color: var(--success);
      border-color: rgba(72, 187, 120, 0.3);
    }

    /* Pending Animation */
    .pending-animation {
      display: flex;
      justify-content: center;
      gap: 0.5rem;
    }

    .pulse-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--primary);
      animation: pulse 1.5s ease-in-out infinite;
    }

    .pulse-dot:nth-child(2) {
      animation-delay: 0.2s;
    }

    .pulse-dot:nth-child(3) {
      animation-delay: 0.4s;
    }

    @keyframes pulse {
      0%, 80%, 100% {
        opacity: 0.3;
        transform: scale(1);
      }
      40% {
        opacity: 1;
        transform: scale(1.2);
      }
    }

    /* Animations */
    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes slideUp {
      from {
        opacity: 1;
        transform: translateY(0);
      }
      to {
        opacity: 0;
        transform: translateY(-20px);
      }
    }

    .card-info {
      flex: 1;
    }

    .card-status {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .subject-badge {
      background: var(--primary);
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.7rem;
      font-weight: 600;
      margin-right: 0.5rem;
    }

    .unread-badge {
      background: var(--danger);
      color: white;
      padding: 0.25rem 0.5rem;
      border-radius: 999px;
      font-size: 0.7rem;
      font-weight: 600;
      animation: pulse 2s infinite;
    }

    .response-indicators {
      display: flex;
      gap: 0.75rem;
      margin-left: 1rem;
    }

    .indicator {
      font-size: 0.75rem;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 0.25rem;
    }

    .ai-indicator {
      color: var(--info);
    }

    .teacher-indicator {
      color: var(--success);
    }

    .card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    /* Parent card when answered */
    .parent-card.answered {
      background: linear-gradient(135deg, rgba(72, 187, 120, 0.1) 0%, var(--surface) 100%);
      border-color: var(--success);
    }

    .parent-card.answered .card-header {
      background: rgba(72, 187, 120, 0.05);
    }

    /* Admin Dashboard Styles - Legacy, but kept for compatibility */
    .admin-dashboard {
      padding: 0;
    }

    .dashboard-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid var(--border);
    }

    .dashboard-title {
      font-size: 1.75rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      color: var(--primary);
    }

    .dashboard-actions {
      display: flex;
      gap: 1rem;
    }

    /* Stats Grid */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 3rem;
    }

    .stat-card {
      background: var(--surface);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      box-shadow: var(--shadow-md);
      cursor: pointer;
      transition: all 0.3s ease;
      border: 2px solid transparent;
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .stat-card:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-lg);
    }

    .stat-card.urgent {
      background: linear-gradient(135deg, rgba(245, 101, 101, 0.1) 0%, var(--surface) 100%);
      border-color: rgba(245, 101, 101, 0.3);
    }

    .stat-card.pending {
      background: linear-gradient(135deg, rgba(237, 137, 54, 0.1) 0%, var(--surface) 100%);
      border-color: rgba(237, 137, 54, 0.3);
    }

    .stat-card.responded {
      background: linear-gradient(135deg, rgba(72, 187, 120, 0.1) 0%, var(--surface) 100%);
      border-color: rgba(72, 187, 120, 0.3);
    }

    .stat-icon {
      font-size: 2rem;
    }

    .stat-content {
      flex: 1;
    }

    .stat-number {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1;
    }

    .stat-label {
      font-size: 0.875rem;
      color: var(--text-muted);
      margin-top: 0.5rem;
    }

    /* Messages Section */
    .messages-section {
      background: var(--surface);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-lg);
    }

    .messages-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid var(--border-light);
    }

    .messages-header h3 {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--text-primary);
    }

    .messages-filters {
      display: flex;
      gap: 1rem;
    }

    .messages-container {
      display: grid;
      gap: 1rem;
    }

    /* Message Card */
    .message-card {
      background: var(--surface);
      border: 2px solid var(--border);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      transition: all 0.3s ease;
    }

    .message-card:hover {
      box-shadow: var(--shadow-md);
      transform: translateX(5px);
    }

    .message-card.urgent {
      border-color: var(--danger);
      background: linear-gradient(90deg, rgba(245, 101, 101, 0.05) 0%, var(--surface) 100%);
    }

    .message-card.responded {
      border-color: var(--success);
      opacity: 0.9;
    }

    .message-card-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }

    .message-info h4 {
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 0.25rem;
    }

    .message-subject {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      background: var(--primary);
      color: white;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .message-meta {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .badge {
      padding: 0.25rem 0.75rem;
      border-radius: 999px;
      font-size: 0.7rem;
      font-weight: 600;
    }

    .badge.urgent {
      background: rgba(245, 101, 101, 0.1);
      color: var(--danger);
      border: 1px solid rgba(245, 101, 101, 0.3);
    }

    .badge.pending {
      background: rgba(237, 137, 54, 0.1);
      color: var(--warning);
      border: 1px solid rgba(237, 137, 54, 0.3);
    }

    .badge.responded {
      background: rgba(72, 187, 120, 0.1);
      color: var(--success);
      border: 1px solid rgba(72, 187, 120, 0.3);
    }

    .message-time {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    .message-preview {
      color: var(--text-secondary);
      line-height: 1.6;
      margin-bottom: 1rem;
    }

    .message-card-actions {
      display: flex;
      gap: 0.75rem;
    }

    .btn-sm {
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
    }

    .no-messages {
      text-align: center;
      padding: 3rem;
      color: var(--text-muted);
      font-size: 1.1rem;
    }

    /* Notification */
    @keyframes slideInRight {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }
    /* ---------- بهبود تجربه موبایل ---------- */
@media (max-width: 640px) {
  /* فاصله‌ها و اندازه‌ها */
  .btn, .btn-sm { padding: 0.6rem 1rem; font-size: .9rem; }
  .form-input { padding: .65rem .9rem; font-size: .9rem; }
  .topic-card { min-height: 72px; padding: .75rem; }

  /* سربرگ چسبان کوتاه‌تر */
  .header-section { padding: 1.25rem; }

  /* کارت تاریخچه کاربر */
  .cascade-card .card-header { padding: .75rem 1rem; }
  .cascade-card .card-body { padding: 1rem; }

  /* پنل ادمین به‌صورت ستونی */
  .admin-panel { height: auto; }
  .gmail-layout { flex-direction: column; }

  /* سایدبار قابل جمع‌شدن در موبایل */
  .sidebar {
    width: 100%;
    border-right: none;
    border-bottom: 1px solid var(--border);
    display: none; /* پیش‌فرض پنهان در موبایل */
  }
  .sidebar.show { display: block; }

  /* نوار بالا: دکمه نمایش منو + جستجو تمام‌عرض */
  .top-bar { flex-wrap: wrap; gap: .5rem; }
  .top-bar .left { order: 2; width: 100%; justify-content: space-between; }
  .top-bar .search { order: 3; width: 100%; margin: .5rem 0 0; }
  .top-bar .right { order: 1; }

  /* لیست پیام‌ها: ساده و فشرده */
  .message-row {
    grid-template-columns: 36px 1fr 70px !important;
    gap: .5rem;
    padding: .75rem;
    height: auto;
  }
  .col-avatar { display: none; }
  .col-from .email { display: none; }
  .col-subject .label { display: none; }
  .col-date { font-size: .7rem; }

  /* پنل جزئیات زیر لیست بیاید */
  .message-pane { order: 3; }
}


@media (max-width: 640px) {
  .mobile-menu-btn { display: inline-flex; align-items: center; }
}

/* ---------- ظریف‌کاری تایپوگرافی و ترازبندی ---------- */
.message-header h1 { font-size: 1.25rem; }
.message-meta span { display: inline-flex; align-items: center; gap: .25rem; }
.message-meta span::before {
  content: "•"; color: var(--border); margin: 0 .25rem 0 0;
}
.message-meta span:first-child::before { content: ""; margin: 0; }

/* ---------- بازطراحی بدنهٔ پیام در جزئیات ---------- */
.thread-message {
  border: 1px solid var(--border-light);
  background: var(--surface);
  border-radius: var(--radius-lg);
  padding: 1rem;
  box-shadow: var(--shadow-sm);
  position: relative;
}
.thread-header { border-bottom: none; margin-bottom: .5rem; padding-bottom: 0; }
.thread-sender { gap: .4rem; font-weight: 700; }
.thread-time { color: var(--text-muted); }
.thread-content {
  line-height: 1.8;
  color: var(--text-secondary);
  background: var(--surface-elevated);
  border: 1px dashed var(--border);
  border-radius: var(--radius-md);
  padding: .9rem;
}

/* نوار رنگی کناری برای نقش‌ها */
.thread-message.parent { border-left: 4px solid var(--text-muted); }
.thread-message.ai     { border-left: 4px solid var(--info); }
.thread-message.teacher{ border-left: 4px solid var(--success); }

/* باکس پاسخ‌دهی زیباتر */
.reply-section {
  border: 2px solid var(--success);
  background: #f8fff9;
}
.reply-textarea {
  border-radius: var(--radius-md);
  background: var(--surface-elevated);
}

/* ---------- فقط عنوان در جدول ادمین و بقیه روی کلیک ---------- */
.body-preview { display: none !important; } /* متن در لیست پنهان شود */

/* در حالت «نمایش همه»، پیام‌های پاسخ‌داده‌نشده بولد شوند */
.message-row.pending .subject,
.message-row.unread .subject { font-weight: 800; }

/* ردیف انتخاب‌شده مشخص‌تر */
.message-row.selected {
  background: rgba(102,126,234,.12);
  outline: 2px solid rgba(102,126,234,.25);
}

  </style>

  <div class="feedback-container">
    
    <!-- Alert Bar -->
    <?php if ($userType !== 'admin'): ?>
    <div id="alertBar" class="alert-bar">
      📢 شما <span id="unreadCount">0</span> پاسخ خوانده‌نشده از مربی دارید.
    </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="header-section">
      <h1 class="header-title">
        <?php if ($userType === 'admin'): ?>
        مدیریت بازخوردهای والدین
        <?php else: ?>
        پلتفرم ارتباط والدین و مربیان
        <?php endif; ?>
      </h1>
      <p class="header-subtitle">
        <?php if ($userType === 'admin'): ?>
        مدیریت، پاسخ‌دهی و پیگیری پیام‌های والدین دانش‌آموزان
        <?php else: ?>
        فضایی امن برای گفتگو و اشتراک نظرات در مسیر پیشرفت فرزندتان
        <?php endif; ?>
      </p>
    </div>

    <!-- Main Layout -->
    <div class="main-layout <?php echo $userType === 'admin' ? 'admin-layout' : 'user-layout'; ?>">
      
      <?php if ($userType !== 'admin'): ?>
      <!-- User Form Panel -->
      <div class="form-card">
        <h2 class="form-title">
          ✍️ ارسال پیام جدید
        </h2>
        
        <form id="feedbackForm" novalidate>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">نسبت خانوادگی</label>
              <select class="form-input" name="parent_relation" required>
                <option value="">انتخاب کنید</option>
                <option value="father">پدر</option>
                <option value="mother">مادر</option>
                <option value="guardian">سرپرست</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">نام و نام خانوادگی</label>
              <input class="form-input" type="text" name="parent_name" placeholder="نام کامل" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">شماره تماس</label>
              <input class="form-input" id="parentPhone" dir="ltr" type="tel" name="parent_phone" 
                     placeholder="09123456789" pattern="^0\d{10}$" maxlength="11" required>
              <div class="hint-text">مثال: 09123456789</div>
            </div>
            <div class="form-group">
              <label class="form-label">دانش‌آموز</label>
              <input class="form-input" type="text" value="<?php echo htmlspecialchars($stuFullName,ENT_QUOTES,'UTF-8'); ?>" disabled>
            </div>
          </div>

          <div class="topics-section">
            <label class="form-label">موضوع گفتگو</label>
            <div class="topics-grid" id="topicsGrid">
              <div class="topic-item" data-value="academic">
                <input type="radio" name="subject" value="academic" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">📚</div>
                  <div class="topic-text">پیشرفت تحصیلی</div>
                </div>
              </div>
              <div class="topic-item" data-value="homework">
                <input type="radio" name="subject" value="homework" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">📝</div>
                  <div class="topic-text">تکالیف و برنامه‌ریزی</div>
                </div>
              </div>
              <div class="topic-item" data-value="attention">
                <input type="radio" name="subject" value="attention" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🎯</div>
                  <div class="topic-text">تمرکز/توجه</div>
                </div>
              </div>
              <div class="topic-item" data-value="behavior">
                <input type="radio" name="subject" value="behavior" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🤝</div>
                  <div class="topic-text">رفتار و اخلاق</div>
                </div>
              </div>
              <div class="topic-item" data-value="bullying">
                <input type="radio" name="subject" value="bullying" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🛡️</div>
                  <div class="topic-text">تنمر/همسالان</div>
                </div>
              </div>
              <div class="topic-item" data-value="motivation">
                <input type="radio" name="subject" value="motivation" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🚀</div>
                  <div class="topic-text">انگیزه و اعتمادبه‌نفس</div>
                </div>
              </div>
              <div class="topic-item" data-value="schedule">
                <input type="radio" name="subject" value="schedule" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">⏰</div>
                  <div class="topic-text">زمان‌بندی/حضور</div>
                </div>
              </div>
              <div class="topic-item" data-value="health">
                <input type="radio" name="subject" value="health" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🏥</div>
                  <div class="topic-text">سلامت/خواب/تغذیه</div>
                </div>
              </div>
              <div class="topic-item" data-value="special">
                <input type="radio" name="subject" value="special" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">🧩</div>
                  <div class="topic-text">نیازهای ویژه</div>
                </div>
              </div>
              <div class="topic-item" data-value="suggestion">
                <input type="radio" name="subject" value="suggestion" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">💡</div>
                  <div class="topic-text">پیشنهاد</div>
                </div>
              </div>
              <div class="topic-item" data-value="complaint">
                <input type="radio" name="subject" value="complaint" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">⚠️</div>
                  <div class="topic-text">شکایت/نگرانی</div>
                </div>
              </div>
              <div class="topic-item" data-value="technical">
                <input type="radio" name="subject" value="technical" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">💻</div>
                  <div class="topic-text">مشکل فنی</div>
                </div>
              </div>
              <div class="topic-item" data-value="other">
                <input type="radio" name="subject" value="other" class="topic-input">
                <div class="topic-card">
                  <div class="topic-icon">✍️</div>
                  <div class="topic-text">موضوع دلخواه</div>
                </div>
              </div>
            </div>
            
            <div id="customTopicInput" class="custom-topic-input">
              <input class="form-input" type="text" name="subject_text" placeholder="موضوع دلخواه خود را بنویسید...">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">پیام شما</label>
            <textarea class="form-input form-textarea" name="message" 
                      placeholder="لطفاً نگرانی، سوال یا پیشنهاد خود را به طور کامل بیان کنید..." required></textarea>
          </div>

          <div class="btn-row">
            <button type="submit" class="btn btn-primary">
              ارسال پیام
              <span>📤</span>
            </button>
            <button type="reset" class="btn btn-secondary">
              پاک کردن
            </button>
          </div>
        </form>

        <!-- AI Response -->
        <div id="aiResponse" class="ai-response">
          <div class="ai-response-title">
            <span>🤖</span>
            پاسخ اولیه مشاور هوشمند
          </div>
          <div id="aiResponseText" class="ai-response-text"></div>
        </div>
      </div>
      <?php endif; ?>

      <!-- History/Admin Panel -->
      <?php if ($userType !== 'admin'): ?>
      <!-- User History Panel -->
      <div class="history-panel">
        <h2 class="history-title">
          📋 تاریخچه گفتگوها
        </h2>
        <div id="historyContent">
          <!-- محتوا با AJAX بارگذاری می‌شود -->
        </div>
      </div>
      <?php else: ?>
      <!-- Gmail-like Admin Panel -->
      <div class="admin-panel">
        <div class="gmail-layout">
          <!-- Sidebar -->
          <nav class="sidebar">
            <div class="sidebar-logo">مدیریت بازخورد</div>
            <ul class="nav-list">
              <li class="nav-item active" data-filter="all">
                <span>📬 همه پیام‌ها</span>
                <span class="nav-count" id="total-count">0</span>
              </li>
              <li class="nav-item" data-filter="pending">
                <span class="nav-icon">⏳</span>
                <span>در انتظار</span>
                <span class="nav-count" id="pending-count">0</span>
              </li>
              <li class="nav-item" data-filter="responded">
                <span class="nav-icon">✅</span>
                <span>پاسخ داده شده</span>
                <span class="nav-count" id="responded-count">0</span>
              </li>
              <li class="nav-item" data-filter="archived">
                <span class="nav-icon">📁</span>
                <span>آرشیو</span>
                <span class="nav-count" id="archived-count">0</span>
              </li>
            </ul>
          </nav>

          <!-- Main -->
          <main class="main">
            <header class="top-bar">
              <div class="left">
                <label class="checkbox">
                  <input type="checkbox" id="select-all">
                  انتخاب همه
                </label>
                <button class="btn-icon" id="bulk-archive" title="آرشیو">📁</button>
                <button class="btn-icon" id="bulk-delete" title="حذف">🗑️</button>
              </div>
              <div class="search">
                <input type="search" id="searchInput" placeholder="جستجو در پیام‌ها...">
              </div>
              <div class="right">
                  <button class="mobile-menu-btn" id="mobileMenuBtn" title="منو">☰ منو</button>
                <button class="btn-icon" title="بیشتر">⋮</button>
              </div>
            </header>
            <div class="content">
              <div class="message-list" id="messageList">
                <!-- Messages will be loaded here -->
              </div>
              <div class="message-pane" id="messagePane">
                <div class="no-selection">
                  <h2>هیچ پیامی انتخاب نشده</h2>
                  <p>از لیست سمت چپ، یک پیام را انتخاب کنید تا جزئیات آن نمایش داده شود.</p>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <?php endif; ?>

    </div>
  </div>

  <script>
(function() {
  // API Endpoints
  var API = {
    submit: '/ajax/feedback-create.php',
    myList: '/ajax/feedback-my-list.php',
    adminList: '/ajax/feedback-admin-list.php',
    thread: '/ajax/feedback-thread.php',
    respond: '/ajax/feedback-respond.php',
    action: '/ajax/feedback-action.php',
    unread: '/ajax/feedback-unread-count.php',
    markSeen: '/ajax/feedback-mark-seen.php'
  };

  // Global Variables
  var userType = <?php echo json_encode($userType); ?>;
  var SUBJECT_FA = <?php echo json_encode($subjectFa, JSON_UNESCAPED_UNICODE); ?>;
  var adminData = [];
  var adminFiltered = [];
  var currentFeedbackId = null;
  var selectedRows = new Set();

  // Utility Functions
  function toJalaliDate(isoString) {
    try {
      var date = new Date(String(isoString || '').replace(' ', 'T'));
      return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: (String(isoString || '').length > 10 ? '2-digit' : undefined),
        minute: (String(isoString || '').length > 10 ? '2-digit' : undefined)
      }).format(date);
    } catch (e) {
      return isoString;
    }
  }

  function showNotification(message, type) {
    if (!type) type = 'info';
    var notification = document.createElement('div');
    notification.style.cssText =
      'position: fixed; top: 20px; right: 20px; z-index: 9999;' +
      'padding: 1rem 1.5rem; border-radius: 8px;' +
      'color: white; font-weight: 600; max-width: 420px;' +
      'box-shadow: 0 10px 15px -3px rgba(0,0,0,.1); animation: slideInRight .3s ease;';
    var bg = type === 'success' ? 'var(--success)' : (type === 'error' ? 'var(--danger)' : 'var(--info)');
    notification.style.background = bg;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(function () {
      notification.style.animation = 'slideOutRight .3s ease';
      setTimeout(function () { notification.remove(); }, 300);
    }, 4000);
  }

  function getSubjectTitle(item) {
    if (item.subject_fa) return item.subject_fa;
    if (SUBJECT_FA[item.subject]) return SUBJECT_FA[item.subject];
    if (item.subject === 'other' && item.subject_text) return 'موضوع دلخواه: ' + item.subject_text;
    if (item.subject === 'other') return 'موضوع دلخواه';
    return item.subject || 'نامشخص';
  }

  function getStatusInfo(status) {
    var s = String(status || '').toLowerCase();
    if (s === 'responded') return { 'class': 'status-responded', 'text': 'پاسخ داده شده' };
    if (s === 'archived')  return { 'class': 'status-archived',  'text': 'آرشیو شده' };
    return { 'class': 'status-pending', 'text': 'در انتظار پاسخ' };
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // Phone Input Validation (user form)
  var phoneInput = document.getElementById('parentPhone');
  if (phoneInput) {
    var toLatinDigits = function(s){
      return String(s || '')
        .replace(/[۰-۹]/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
        .replace(/[٠-٩]/g, function(d){ return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    };
    phoneInput.addEventListener('input', function () {
      var value = toLatinDigits(phoneInput.value).replace(/\D/g, '');
      if (value.length > 11) value = value.slice(0, 11);
      phoneInput.value = value;
      if (!/^0\d{10}$/.test(value)) phoneInput.setCustomValidity('شماره تماس معتبر وارد کنید');
      else phoneInput.setCustomValidity('');
    });
  }

  // Topic Selection (user form)
  var topicsGrid = document.getElementById('topicsGrid');
  var customTopicInput = document.getElementById('customTopicInput');
  if (topicsGrid) {
    topicsGrid.addEventListener('click', function(e){
      var topicItem = e.target.closest('.topic-item');
      if (!topicItem) return;
      var items = topicsGrid.querySelectorAll('.topic-item');
      for (var i=0; i<items.length; i++) items[i].classList.remove('selected');
      topicItem.classList.add('selected');
      var radio = topicItem.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
      if (topicItem.getAttribute('data-value') === 'other') {
        customTopicInput.style.display = 'block';
        var customInput = customTopicInput.querySelector('input');
        if (customInput) customInput.focus();
      } else {
        customTopicInput.style.display = 'none';
      }
    });
  }

  // User form submission
  var form = document.getElementById('feedbackForm');
  if (form) {
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var selectedRadio = form.querySelector('input[name="subject"]:checked');
      if (!selectedRadio) { showNotification('لطفاً موضوع گفتگو را انتخاب کنید','error'); return; }
      var phoneInput = document.getElementById('parentPhone');
      if (phoneInput && !/^0\d{10}$/.test(phoneInput.value)) { phoneInput.reportValidity(); return; }

      var formData = new FormData(form);
      formData.set('subject', selectedRadio.value);
      if (selectedRadio.value === 'other') {
        var customText = form.querySelector('input[name="subject_text"]');
        if (customText && customText.value.trim()) formData.set('subject_text', customText.value.trim());
        else formData.set('subject_text', 'موضوع دلخواه');
      }

      var submitBtn = form.querySelector('button[type="submit"]');
      var originalText = submitBtn.innerHTML;
      submitBtn.innerHTML = '<span class="spinner"></span> در حال ارسال...';
      submitBtn.disabled = true;

      fetch(API.submit, { method:'POST', body:formData, credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(data){
          if (!data.success) throw new Error(data.message || 'خطا در ارسال پیام');
          if (data.ai_reply) {
            var aiResponse = document.getElementById('aiResponse');
            var aiResponseText = document.getElementById('aiResponseText');
            if (aiResponse && aiResponseText) {
              aiResponseText.textContent = data.ai_reply;
              aiResponse.style.display = 'block';
            }
          }
          form.reset();
          var items = topicsGrid ? topicsGrid.querySelectorAll('.topic-item') : [];
          for (var i=0; i<items.length; i++) items[i].classList.remove('selected');
          if (customTopicInput) customTopicInput.style.display = 'none';
          showNotification('پیام شما با موفقیت ارسال شد','success');
          if (userType !== 'admin') loadUserHistory();
        })
        .catch(function(err){ console.error(err); showNotification(err.message,'error'); })
        .finally(function(){ submitBtn.innerHTML = originalText; submitBtn.disabled = false; });
    });
  }

  // Load User History
  function loadUserHistory(){
    var historyContent = document.getElementById('historyContent');
    if (!historyContent) return;
    historyContent.innerHTML = '<div style="text-align:center; padding:2rem; color:var(--text-muted);"><span class="spinner"></span> در حال بارگذاری...</div>';

    fetch(API.myList, { cache: 'no-store' })
      .then(function(r){ return r.json(); })
      .then(function(data){
        if (!data.success) throw new Error('خطا در دریافت تاریخچه');
        var items = data.items || [];
        if (items.length === 0) {
          historyContent.innerHTML =
            '<div class="history-empty">' +
              '<div style="font-size:3rem; margin-bottom:1rem;">💬</div>' +
              '<h3 style="margin-bottom:.5rem;">هنوز پیامی ارسال نکرده‌اید</h3>' +
              '<p style="color:var(--text-muted);">اولین پیام خود را از فرم کناری ارسال کنید</p>' +
            '</div>';
          return;
        }
        items.sort(function(a,b){ return new Date(b.created_at) - new Date(a.created_at); });

        var html = '';
        for (var i=0;i<items.length;i++){
          var item = items[i];
          var hasTeacherReply = item.has_teacher_reply === true;
          var hasAiReply = !!(item.ai_reply && String(item.ai_reply).trim() !== '');
          var time = toJalaliDate(item.created_at);
          var subject = item.subject_fa || 'نامشخص';
          var message = item.message || 'پیام شما';
          var unreadCount = parseInt(item.unread_teacher_count || 0, 10);

          html +=
            '<div class="conversation-cascade" data-id="'+ item.id +'" data-index="'+ i +'">' +
              '<div class="cascade-card parent-card '+ (hasTeacherReply ? 'answered' : 'pending') +'">' +
                '<div class="card-header">' +
                  '<div class="card-info">' +
                    '<div class="card-sender">' +
                      '<span class="sender-icon">👤</span>' +
                      '<span class="sender-name">پیام شما</span>' +
                      '<span class="subject-badge">'+ subject +'</span>' +
                    '</div>' +
                    '<div class="card-time">'+ time +'</div>' +
                  '</div>' +
                  '<div class="card-status">' +
                    (hasTeacherReply
                      ? '<span class="status-indicator answered">✅ پاسخ داده شده</span>'
                      : '<span class="status-indicator pending">⏳ در انتظار پاسخ</span>') +
                    (unreadCount > 0 ? '<span class="unread-badge">'+ unreadCount +' جدید</span>' : '') +
                  '</div>' +
                '</div>' +
                '<div class="card-body"><div class="message-content">'+ escapeHtml(message) +'</div></div>' +
                '<div class="card-footer">' +
                  '<div class="response-indicators">' +
                    (hasAiReply ? '<span class="indicator ai-indicator">🤖 پاسخ هوشمند</span>' : '') +
                    (hasTeacherReply ? '<span class="indicator teacher-indicator">👩‍🏫 پاسخ معلم</span>' : '') +
                  '</div>' +
                  '<button class="expand-btn" onclick="toggleConversation('+ i +')">' +
                    '<span class="expand-text">مشاهده پاسخ‌ها</span>' +
                    '<span class="expand-icon">▼</span>' +
                  '</button>' +
                '</div>' +
              '</div>' +
              '<div class="cascade-responses" id="responses-'+ i +'" style="display:none;">' +
                (hasAiReply
                  ? '<div class="cascade-card ai-card">' +
                      '<div class="card-header">' +
                        '<div class="card-sender"><span class="sender-icon">🤖</span><span class="card-sender-name">مشاور هوشمند</span></div>' +
                        '<span class="card-badge">پاسخ خودکار</span>' +
                      '</div>' +
                      '<div class="card-body"><div class="message-content">'+ escapeHtml(item.ai_reply).replace(/\n/g,'<br>') +'</div></div>' +
                    '</div>'
                  : '') +
                (hasTeacherReply
                  ? '<div class="cascade-card teacher-card">' +
                      '<div class="card-header">' +
                        '<div class="card-sender"><span class="sender-icon">👩‍🏫</span><span class="card-sender-name">پاسخ معلم</span></div>' +
                        '<span class="card-badge success">✅ پاسخ نهایی</span>' +
                      '</div>' +
                      '<div class="card-body"><div class="message-content">'+ escapeHtml(item.teacher_reply || '').replace(/\n/g,'<br>') +'</div></div>' +
                    '</div>'
                  : '<div class="cascade-card pending-card">' +
                      '<div class="card-body" style="text-align:center; padding:2rem;">' +
                        '<div class="pending-animation"><span class="pulse-dot"></span><span class="pulse-dot"></span><span class="pulse-dot"></span></div>' +
                        '<p style="color:var(--text-muted); margin-top:1rem;">در انتظار پاسخ معلم...</p>' +
                      '</div>' +
                    '</div>') +
              '</div>' +
            '</div>';
        }
        historyContent.innerHTML = html;
      })
      .catch(function(err){
        historyContent.innerHTML = '<div style="text-align:center; padding:2rem; color:var(--danger);">خطا در بارگذاری تاریخچه: ' + escapeHtml(err.message) + '</div>';
      });
  }

  // Toggle conversation expansion (user side)
  window.toggleConversation = function(index) {
    var responses = document.getElementById('responses-' + index);
    var btn = document.querySelector('[data-index="'+ index +'"] .expand-btn');
    var icon = btn ? btn.querySelector('.expand-icon') : null;
    var text = btn ? btn.querySelector('.expand-text') : null;

    if (responses.style.display === 'none') {
      responses.style.display = 'block';
      responses.style.animation = 'slideDown .3s ease';
      if (icon) icon.style.transform = 'rotate(180deg)';
      if (text) text.textContent = 'بستن پاسخ‌ها';
      var conversationElement = document.querySelector('[data-index="'+ index +'"]');
      var feedbackId = conversationElement ? conversationElement.getAttribute('data-id') : null;
      if (userType !== 'admin' && feedbackId) {
        fetch(API.markSeen, {
          method: 'POST',
          headers: { 'Content-Type':'application/json' },
          body: JSON.stringify({ feedback_id: parseInt(feedbackId,10) })
        }).then(function(){ checkUnreadMessages(); });
      }
    } else {
      responses.style.animation = 'slideUp .3s ease';
      setTimeout(function(){ responses.style.display = 'none'; }, 300);
      if (icon) icon.style.transform = 'rotate(0deg)';
      if (text) text.textContent = 'مشاهده پاسخ‌ها';
    }
  };

  // Check Unread Messages (user)
  function checkUnreadMessages(){
    if (userType === 'admin') return;
    var alertBar = document.getElementById('alertBar');
    var unreadCount = document.getElementById('unreadCount');
    fetch(API.unread, { cache:'no-store' })
      .then(function(r){ return r.json(); })
      .then(function(data){
        var count = parseInt((data && data.count) || 0, 10);
        if (count > 0) {
          if (unreadCount) unreadCount.textContent = count;
          if (alertBar) alertBar.style.display = 'block';
        } else {
          if (alertBar) alertBar.style.display = 'none';
        }
      })
      .catch(function(e){ console.error('Unread check error:', e); });
  }

  // Admin Functions
  function loadAdminData(){
    if (userType !== 'admin') return;
    fetch(API.adminList, { cache:'no-store' })
      .then(function(r){ return r.json(); })
      .then(function(data){
        if (!data.success) throw new Error('خطا در دریافت داده‌ها');
        adminData = data.items || [];
        updateAdminCounts();
        applyAdminFilters();
      })
      .catch(function(err){
        console.error('Error loading admin data:', err);
        showNotification('خطا در بارگذاری داده‌ها', 'error');
      });
  }

  function updateAdminCounts(){
    var total = adminData.length;
    var pending = adminData.filter(function(item){
      var s = String(item.status || '').toLowerCase();
      return (s === 'pending' || s === '');
    }).length;
    var responded = adminData.filter(function(item){
      return String(item.status || '').toLowerCase() === 'responded';
    }).length;
    var archived = adminData.filter(function(item){
      return String(item.status || '').toLowerCase() === 'archived';
    }).length;

    var elTotal = document.getElementById('total-count');
    var elPending = document.getElementById('pending-count');
    var elResponded = document.getElementById('responded-count');
    var elArchived = document.getElementById('archived-count');
    if (elTotal) elTotal.textContent = total;
    if (elPending) elPending.textContent = pending;
    if (elResponded) elResponded.textContent = responded;
    if (elArchived) elArchived.textContent = archived;
  }

  function applyAdminFilters(){
    var searchInput = document.getElementById('searchInput');
    var searchTerm = String((searchInput && searchInput.value) || '').toLowerCase();
    var activeNav = document.querySelector('.nav-item.active');
    var statusValue = activeNav ? activeNav.getAttribute('data-filter') : 'all';

    adminFiltered = adminData.filter(function(item){
      var itemStatus = String(item.status || '').toLowerCase();
      var statusMatch = false;
      if (statusValue === 'all') statusMatch = true;
      else if (statusValue === 'pending') statusMatch = (itemStatus === 'pending' || itemStatus === '');
      else if (statusValue === 'responded') statusMatch = (itemStatus === 'responded');
      else if (statusValue === 'archived') statusMatch = (itemStatus === 'archived');

      var searchText = [
        item.student_name || '',
        item.parent_name || '',
        item.parent_phone || '',
        getSubjectTitle(item) || '',
        item.message || ''
      ].join(' ').toLowerCase();

      var searchMatch = (!searchTerm || searchText.indexOf(searchTerm) !== -1);
      return statusMatch && searchMatch;
    });

    renderMessageList();
  }

  // Renders admin message list (title only + collapsible preview)
  function renderMessageList(){
    var list = document.getElementById('messageList');
    if (!list) return;
    if (adminFiltered.length === 0) {
      list.innerHTML = '<div class="no-messages">موردی یافت نشد</div>';
      return;
    }
    var html = '';
    for (var i=0;i<adminFiltered.length;i++){
      var item = adminFiltered[i];
      var subject = getSubjectTitle(item);
      var st = String(item.status || '').toLowerCase();
      var statusClass = (st === 'responded') ? 'responded' : (st === 'archived' ? 'archived' : 'pending');
      var date = toJalaliDate(item.created_at);
      var avatarInitial = (item.parent_name || 'P').charAt(0);
      var id = String(item.id);
      html +=
        '<div class="message-row '+ statusClass +'" data-id="'+ id +'" tabindex="0" role="button" aria-selected="false">' +
          '<div class="col-checkbox"><input type="checkbox" class="msg-checkbox"></div>' +
          '<div class="col-avatar"><div class="avatar">'+ avatarInitial +'</div></div>' +
          '<div class="col-from">' +
            '<div class="name">'+ escapeHtml(item.parent_name || 'نامشخص') +'</div>' +
            '<div class="email">'+ escapeHtml(item.student_name || '') +'</div>' +
          '</div>' +
          '<div class="col-subject">' +
            '<div class="subject-line">' +
              '<span class="subject">'+ escapeHtml(subject) +'</span>' +
              (st === 'responded' ? '<span class="label responded">پاسخ داده شده</span>' : '') +
              '<span class="expand-icon" title="نمایش متن">▾</span>' +
            '</div>' +
          '</div>' +
          '<div class="col-date">'+ date +'</div>' +
        '</div>' +
        '<div class="row-preview" data-preview-for="'+ id +'" style="display:none; padding:.75rem 1rem; border-bottom:1px solid var(--border-light); background: var(--surface-elevated);">' +
          '<div style="font-size:.9rem;color:var(--text-secondary);line-height:1.8;">' +
            escapeHtml((item.message || '')).replace(/\n/g,'<br>') +
          '</div>' +
        '</div>';
    }
    list.innerHTML = html;
  }

  // Load Message Detail (admin right pane) - safe strings (no backticks)
  function statusChip(cls, txt){
    return '<span class="status-badge ' + cls + '" style="margin-inline-start:.25rem;">' + txt + '</span>';
  }

  function loadMessageDetail(feedbackId){
    var pane = document.getElementById('messagePane');
    if (pane) pane.innerHTML = '<div class="loading"><span class="spinner"></span> در حال بارگذاری...</div>';

    fetch(API.thread + '?id=' + encodeURIComponent(feedbackId))
      .then(function(r){ return r.json(); })
      .then(function(data){
        if (!data.success) throw new Error(data.message || 'خطا در دریافت جزئیات');

        currentFeedbackId = feedbackId;
        var feedback = data.feedback || {};
        var messages = data.messages || [];
        var subject = getSubjectTitle(feedback);
        var status = getStatusInfo(feedback.status);
        var createDate = toJalaliDate(feedback.created_at);

        var headerHtml =
          '<div class="message-header">' +
            '<h1>' + escapeHtml(subject) + '</h1>' +
            '<div class="message-meta">' +
              '<span>از: ' + escapeHtml(feedback.parent_name || 'نامشخص') + '</span>' +
              '<span>دانش‌آموز: ' + escapeHtml(feedback.student_name || 'نامشخص') + '</span>' +
              '<span>تاریخ: ' + createDate + '</span>' +
              '<span>وضعیت: ' + statusChip(status['class'], status['text']) + '</span>' +
            '</div>' +
          '</div>';

        var convHtml = '<div class="conversation-thread">';
        for (var i=0;i<messages.length;i++){
          var msg = messages[i];
          var roleInfo = {
            'parent':  { icon: '👪', title: 'والد',   'class': 'parent' },
            'ai':      { icon: '🤖', title: 'هوش مصنوعی', 'class': 'ai' },
            'teacher': { icon: '👩‍🏫', title: 'مربی',  'class': 'teacher' }
          };
          var info = roleInfo[msg.sender_role] || { icon:'👤', title:'کاربر', 'class':'user' };
          var t = toJalaliDate(msg.created_at);
          var safeBody = escapeHtml(msg.body || '').replace(/\n/g,'<br>');

          convHtml +=
            '<div class="thread-message ' + info['class'] + '">' +
              '<div class="thread-header">' +
                '<div class="thread-sender"><span>' + info.icon + '</span>' + info.title + '</div>' +
                '<div class="thread-time">' + t + '</div>' +
              '</div>' +
              '<div class="thread-content">' + safeBody + '</div>' +
            '</div>';
        }
        convHtml += '</div>';

        var isResponded = (String(feedback.status || '').toLowerCase() === 'responded');
        var replyHtml = '';
        if (!isResponded) {
          replyHtml =
            '<div class="reply-section">' +
              '<div class="reply-title">👩‍🏫 ارسال پاسخ به والدین</div>' +
              '<textarea class="reply-textarea" placeholder="پاسخ خود را با لحن محترمانه و راهگشا بنویسید..."></textarea>' +
              '<div class="reply-actions">' +
                '<button id="sendReplyBtn" class="btn btn-success">ارسال پاسخ</button>' +
                '<button id="saveDraftBtn" class="btn btn-secondary">ذخیره پیش‌نویس</button>' +
              '</div>' +
            '</div>';
        }

        if (pane) pane.innerHTML = headerHtml + convHtml + replyHtml;

        // Draft restore
        var draftKey = 'draft_' + String(feedbackId);
        var textarea = pane ? pane.querySelector('.reply-textarea') : null;
        var draft = localStorage.getItem(draftKey);
        if (textarea && draft) textarea.value = draft;

        var sendBtn = pane ? pane.querySelector('#sendReplyBtn') : null;
        var draftBtn = pane ? pane.querySelector('#saveDraftBtn') : null;

        if (sendBtn) {
          sendBtn.addEventListener('click', function(){ sendReply(feedbackId, pane); });
        }
        if (draftBtn) {
          draftBtn.addEventListener('click', function(){
            var t = textarea ? String(textarea.value || '').trim() : '';
            if (t) {
              localStorage.setItem(draftKey, t);
              showNotification('پیش‌نویس ذخیره شد', 'success');
            }
          });
        }
      })
      .catch(function(err){
        if (pane) pane.innerHTML = '<div class="loading" style="color:var(--danger);">خطا: ' + escapeHtml(err.message) + '</div>';
      });
  }

  function sendReply(feedbackId, pane){
    var textarea = pane ? pane.querySelector('.reply-textarea') : null;
    var replyText = textarea ? String(textarea.value || '').trim() : '';
    if (!replyText) { showNotification('لطفاً متن پاسخ را وارد کنید','error'); return; }

    var sendBtn = pane ? pane.querySelector('#sendReplyBtn') : null;
    var originalText = sendBtn ? sendBtn.innerHTML : '';
    if (sendBtn) { sendBtn.innerHTML = '<span class="spinner"></span> در حال ارسال...'; sendBtn.disabled = true; }

    fetch(API.respond, {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ id: feedbackId, body: replyText })
    })
    .then(function(r){ return r.json(); })
    .then(function(data){
      if (!data.success) throw new Error(data.message || 'خطا در ارسال پاسخ');
      return fetch(API.action, {
        method: 'POST',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify({ action:'mark_responded', id: feedbackId })
      });
    })
    .then(function(r){ return r.json(); })
    .then(function(_ok){
      showNotification('پاسخ ارسال شد و وضعیت به‌روزرسانی شد','success');
      return loadAdminData(), loadMessageDetail(feedbackId);
    })
    .catch(function(err){
      showNotification('خطا در ارسال: ' + err.message, 'error');
    })
    .finally(function(){
      if (sendBtn) { sendBtn.innerHTML = originalText; sendBtn.disabled = false; }
    });
  }

  function deleteItems(ids){
    var p = Promise.resolve();
    ids.forEach(function(id){
      p = p.then(function(){
        return fetch(API.action, {
          method:'POST',
          headers:{ 'Content-Type':'application/json' },
          body: JSON.stringify({ action:'delete', id:id })
        }).then(function(r){ return r.json(); });
      });
    });
    p.then(function(){
      showNotification(ids.length + ' پیام حذف شد','success');
      return loadAdminData();
    }).then(function(){
      var pane = document.getElementById('messagePane');
      if (pane) pane.innerHTML = '<div class="no-selection"><h2>هیچ پیامی انتخاب نشده</h2><p>از لیست سمت چپ، یک پیام را انتخاب کنید تا جزئیات آن نمایش داده شود.</p></div>';
    });
  }

  // Admin Event Listeners
  if (userType === 'admin') {
    // Sidebar navigation
    var navItems = document.querySelectorAll('.nav-item');
    for (var i=0;i<navItems.length;i++){
      navItems[i].addEventListener('click', function(){
        var all = document.querySelectorAll('.nav-item');
        for (var j=0;j<all.length;j++) all[j].classList.remove('active');
        this.classList.add('active');
        applyAdminFilters();
      });
    }

    // Search
    var searchInput = document.getElementById('searchInput');
    if (searchInput) {
      var searchTimer = null;
      searchInput.addEventListener('input', function(){
        if (searchTimer) clearTimeout(searchTimer);
        searchTimer = setTimeout(applyAdminFilters, 300);
      });
    }

    // Select all
    var selectAll = document.getElementById('select-all');
    if (selectAll) {
      selectAll.addEventListener('change', function(e){
        var cbs = document.querySelectorAll('.msg-checkbox');
        for (var i=0;i<cbs.length;i++){
          cbs[i].checked = e.target.checked;
          var row = cbs[i].closest('.message-row');
          var id = row ? row.getAttribute('data-id') : null;
          if (!id) continue;
          if (e.target.checked) { selectedRows.add(id); if (row) row.classList.add('selected'); }
          else { selectedRows.delete(id); if (row) row.classList.remove('selected'); }
        }
      });
    }

    // Bulk archive
    var bulkArchive = document.getElementById('bulk-archive');
    if (bulkArchive) {
      bulkArchive.addEventListener('click', function(){
        var ids = Array.from(selectedRows);
        if (!ids.length) return;
        if (!confirm('آیا ' + ids.length + ' پیام را آرشیو کنید؟')) return;
        var p = Promise.resolve();
        ids.forEach(function(id){
          p = p.then(function(){
            return fetch(API.action, {
              method:'POST',
              headers:{ 'Content-Type':'application/json' },
              body: JSON.stringify({ action:'archive', id:id })
            }).then(function(r){ return r.json(); });
          });
        });
        p.then(function(){
          showNotification('پیام‌ها آرشیو شد','success');
          return loadAdminData();
        });
      });
    }

    // Bulk delete
    var bulkDelete = document.getElementById('bulk-delete');
    if (bulkDelete) {
      bulkDelete.addEventListener('click', function(){
        var ids = Array.from(selectedRows);
        if (!ids.length) return;
        if (!confirm('آیا ' + ids.length + ' پیام را حذف کنید؟')) return;
        deleteItems(ids);
      });
    }

    // Row interactions (preview toggle vs detail load)
    document.addEventListener('click', function(e){
      var row = e.target.closest('.message-row');
      if (!row) return;
      var id = row.getAttribute('data-id');

      var isCheckbox = (e.target.classList && e.target.classList.contains('msg-checkbox')) || e.target.type === 'checkbox';
      if (isCheckbox) {
        var cb = e.target;
        if (cb.checked) { selectedRows.add(id); row.classList.add('selected'); }
        else { selectedRows.delete(id); row.classList.remove('selected'); }
        return;
      }

      var clickedSubject = (e.target.classList && (e.target.classList.contains('subject') || e.target.classList.contains('expand-icon')));
      if (clickedSubject) {
        var preview = document.querySelector('.row-preview[data-preview-for="'+ id +'"]');
        var icon = row.querySelector('.expand-icon');
        var visible = preview && preview.style.display !== 'none';
        var previews = document.querySelectorAll('.row-preview');
        for (var i=0;i<previews.length;i++) previews[i].style.display = 'none';
        var icons = document.querySelectorAll('.expand-icon');
        for (var j=0;j<icons.length;j++) icons[j].style.transform = 'rotate(0deg)';
        if (preview) {
          if (visible) {
            preview.style.display = 'none';
            if (icon) icon.style.transform = 'rotate(0deg)';
          } else {
            preview.style.display = 'block';
            if (icon) icon.style.transform = 'rotate(180deg)';
          }
        }
        return;
      }

      // Ctrl/Cmd: multi-select
      if (e.ctrlKey || e.metaKey) {
        var cb2 = row.querySelector('.msg-checkbox');
        var was = cb2 && cb2.checked;
        if (cb2) cb2.checked = !was;
        if (!was) { selectedRows.add(id); row.classList.add('selected'); }
        else { selectedRows.delete(id); row.classList.remove('selected'); }
        return;
      }

      // Normal click: single select + load detail
      var previews2 = document.querySelectorAll('.row-preview');
      for (var k=0;k<previews2.length;k++) previews2[k].style.display = 'none';
      var icons2 = document.querySelectorAll('.expand-icon');
      for (var t=0;t<icons2.length;t++) icons2[t].style.transform = 'rotate(0deg)';

      selectedRows.clear();
      var selectedRowsEls = document.querySelectorAll('.message-row.selected');
      for (var x=0;x<selectedRowsEls.length;x++) selectedRowsEls[x].classList.remove('selected');
      var checkboxes = document.querySelectorAll('.msg-checkbox');
      for (var y=0;y<checkboxes.length;y++) checkboxes[y].checked = false;

      row.classList.add('selected');
      var cb3 = row.querySelector('.msg-checkbox');
      if (cb3) cb3.checked = true;
      selectedRows.add(id);

      loadMessageDetail(id);
    });

    // Checkbox manual change (outside click handler)
    document.addEventListener('change', function(e){
      if (e.target.classList && e.target.classList.contains('msg-checkbox')) {
        var row = e.target.closest('.message-row');
        var id = row ? row.getAttribute('data-id') : null;
        if (!id) return;
        if (e.target.checked) { selectedRows.add(id); row.classList.add('selected'); }
        else { selectedRows.delete(id); row.classList.remove('selected'); }
      }
    });

    // Mobile menu toggle
    var mobileMenuBtn = document.getElementById('mobileMenuBtn');
    if (mobileMenuBtn) {
      mobileMenuBtn.addEventListener('click', function(){
        var sb = document.querySelector('.sidebar');
        if (sb) sb.classList.toggle('show');
      });
    }
  }

  // Initialize
  if (userType === 'admin') {
    loadAdminData();
    setInterval(loadAdminData, 30000);
  } else {
    loadUserHistory();
    checkUnreadMessages();
    setInterval(checkUnreadMessages, 60000);
  }

  // Animations (ensure present)
  var style = document.createElement('style');
  style.textContent =
    '@keyframes slideInRight{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}' +
    '@keyframes slideOutRight{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:0}}' +
    '@keyframes slideDown{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}' +
    '@keyframes slideUp{from{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-20px)}}';
  document.head.appendChild(style);
})();
  </script>
</section>