<?php
/**
 * بخش بازی‌ها و آزمون‌ها - نسخه اصلاح شده
 * تاریخ شمسی + رفع مشکل دکمه خروج
 */

// ==================== تابع تبدیل تاریخ میلادی به شمسی ====================
if (!function_exists('gregorianToJalali')) {
    function gregorianToJalali($gy, $gm, $gd) {
        $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + (int)($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int)(($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return array($jy, $jm, $jd);
    }
}

if (!function_exists('formatDateShamsi')) {
    function formatDateShamsi($date) {
        if (empty($date)) return 'نامشخص';
        $timestamp = strtotime($date);
        if (!$timestamp) return 'نامشخص';
        $gy = (int)date('Y', $timestamp);
        $gm = (int)date('m', $timestamp);
        $gd = (int)date('d', $timestamp);
        list($jy, $jm, $jd) = gregorianToJalali($gy, $gm, $gd);
        $months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        return $jd . ' ' . $months[$jm] . ' ' . $jy;
    }
}

// ==================== INITIALIZE ====================
$current_student_id = $_SESSION['user_id'] ?? 0;
$userType = $_SESSION['user_type'] ?? 'guest';
$userName = $_SESSION['username'] ?? 'کاربر';
$isLoggedIn = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);

$userFullName = $userName;
if ($isLoggedIn && $userType === 'student') {
    try {
        $stmt = $conn->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
        $stmt->execute([$current_student_id]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($userData) {
            $userFullName = trim(($userData['first_name'] ?? '') . ' ' . ($userData['last_name'] ?? ''));
            if (empty($userFullName)) $userFullName = $userName;
        }
    } catch (Exception $e) {}
}

$publishedExams = [];
$games = [];
$leaderboard = [];
$unfinishedExamsCount = 0;
$unfinishedGamesCount = 0;
$student_xp = ['total_xp' => 0, 'math_xp' => 0, 'science_xp' => 0, 'persian_xp' => 0, 'social_xp' => 0, 'religion_xp' => 0, 'level' => 1];

if ($isLoggedIn && $userType === 'student') {
    try {
        $stmt = $conn->prepare("SELECT * FROM student_xp WHERE student_id = ?");
        $stmt->execute([$current_student_id]);
        $xp_data = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($xp_data) {
            foreach (['total_xp', 'math_xp', 'science_xp', 'persian_xp', 'social_xp', 'religion_xp', 'level'] as $key) {
                $student_xp[$key] = (int)($xp_data[$key] ?? 0);
            }
            $calculated = $student_xp['math_xp'] + $student_xp['science_xp'] + $student_xp['persian_xp'] + $student_xp['social_xp'] + $student_xp['religion_xp'];
            $student_xp['total_xp'] = max($student_xp['total_xp'], $calculated);
        }
    } catch (Exception $e) {}

    try {
        $stmt = $conn->prepare("SELECT q.*, q.questions_count as question_count, CASE WHEN qa.id IS NOT NULL THEN 1 ELSE 0 END as has_attempted, qa.score, qa.total_score FROM quizzes q LEFT JOIN quiz_attempts qa ON q.id = qa.quiz_id AND qa.student_id = ? WHERE q.is_active = 1 AND q.is_visible = 1 ORDER BY q.id DESC");
        $stmt->execute([$current_student_id]);
        $publishedExams = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $unfinishedExamsCount = count(array_filter($publishedExams, fn($e) => !$e['has_attempted']));
    } catch (Exception $e) {}

    try {
        $stmt = $conn->prepare("SELECT g.*, gc.name as category_name, gc.icon as category_icon, gr.score as best_score, gr.accuracy as best_accuracy FROM games g LEFT JOIN game_categories gc ON g.category_id = gc.id LEFT JOIN game_results gr ON g.id = gr.game_id AND gr.student_id = ? WHERE g.is_active = 1 ORDER BY g.created_at DESC");
        $stmt->execute([$current_student_id]);
        $games = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt = $conn->query("SELECT COUNT(*) as total FROM games WHERE is_active = 1");
        $totalGamesCount = $stmt->fetch()['total'];
        $stmt = $conn->prepare("SELECT COUNT(DISTINCT g.id) as played FROM games g LEFT JOIN game_results gr ON g.id = gr.game_id AND gr.student_id = ? WHERE g.is_active = 1 AND gr.id IS NOT NULL");
        $stmt->execute([$current_student_id]);
        $unfinishedGamesCount = $totalGamesCount - $stmt->fetch()['played'];
    } catch (Exception $e) {}

    try {
        $stmt = $conn->query("SELECT u.first_name, u.last_name, sx.total_xp, sx.level, (sx.math_xp + sx.science_xp + sx.persian_xp + sx.social_xp + sx.religion_xp) as calc_xp FROM users u JOIN student_xp sx ON u.id = sx.student_id WHERE u.user_type = 'student' AND u.is_active = 1 AND (sx.total_xp > 0 OR (sx.math_xp + sx.science_xp + sx.persian_xp + sx.social_xp + sx.religion_xp) > 0) ORDER BY GREATEST(sx.total_xp, (sx.math_xp + sx.science_xp + sx.persian_xp + sx.social_xp + sx.religion_xp)) DESC LIMIT 10");
        $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($leaderboard as &$p) { $p['final_xp'] = max((int)$p['total_xp'], (int)$p['calc_xp']); }
    } catch (Exception $e) {}
}
?>

<section id="games" class="section">
<style>
#games{--g-primary:#6C5CE7;--g-secondary:#00CEC9;--g-accent:#FDCB6E;--g-pink:#FD79A8;--g-green:#00B894;--g-orange:#E17055;--g-red:#FF6B6B;--g-dark:#2D3436;--g-radius:24px}
#games .games-wrapper{max-width:1400px;margin:0 auto;padding:1.5rem}
#games .games-header{text-align:center;padding:2rem 0 2.5rem}
#games .games-header h2{font-size:clamp(1.8rem,5vw,2.8rem);color:white;text-shadow:3px 3px 0 var(--g-primary),4px 4px 15px rgba(0,0,0,0.3);margin-bottom:0.5rem;animation:g-bounce 2s ease-in-out infinite}
@keyframes g-bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
#games .games-header p{color:rgba(255,255,255,0.9);font-size:1.1rem}
#games .games-tabs{display:flex;justify-content:center;gap:1rem;margin-bottom:2rem;flex-wrap:wrap}
#games .games-tab-btn{position:relative;background:white;border:none;border-radius:50px;padding:0.9rem 2rem;font-family:inherit;font-size:1rem;font-weight:700;color:var(--g-dark);cursor:pointer;display:flex;align-items:center;gap:0.6rem;transition:all 0.3s;box-shadow:0 6px 25px rgba(0,0,0,0.12)}
#games .games-tab-btn:hover{transform:translateY(-4px);box-shadow:0 12px 35px rgba(108,92,231,0.35)}
#games .games-tab-btn.active{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white}
#games .games-tab-btn .tab-icon{font-size:1.5rem}
#games .games-tab-badge{position:absolute;top:-8px;right:-8px;background:linear-gradient(135deg,var(--g-red),#EE5A5A);color:white;min-width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.8rem;font-weight:900;border:2px solid white}
#games .games-tab-content{display:none;animation:g-fadeIn 0.4s}
#games .games-tab-content.active{display:block}
@keyframes g-fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
#games .games-profile{background:linear-gradient(135deg,rgba(255,255,255,0.95),rgba(255,255,255,0.88));border-radius:var(--g-radius);padding:1.75rem;margin-bottom:2rem;box-shadow:0 10px 40px rgba(108,92,231,0.3);position:relative;overflow:hidden}
#games .games-profile::before{content:'';position:absolute;top:0;left:0;right:0;height:5px;background:linear-gradient(90deg,var(--g-primary),var(--g-pink),var(--g-secondary),var(--g-accent));background-size:300% 100%;animation:g-gradient 3s ease infinite}
@keyframes g-gradient{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
#games .profile-top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1.5rem;margin-bottom:1.5rem}
#games .profile-user{display:flex;align-items:center;gap:1rem}
#games .profile-avatar{width:75px;height:75px;background:linear-gradient(135deg,var(--g-primary),var(--g-pink));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;color:white;font-weight:900;box-shadow:0 8px 25px rgba(108,92,231,0.4);position:relative}
#games .profile-avatar::after{content:'⭐';position:absolute;bottom:-3px;right:-3px;font-size:1.3rem;animation:g-spin 4s linear infinite}
@keyframes g-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
#games .profile-info h3{font-size:1.3rem;color:var(--g-dark);margin:0 0 0.4rem;font-weight:800}
#games .profile-level{display:inline-flex;align-items:center;gap:0.3rem;background:linear-gradient(135deg,var(--g-accent),#F8B739);color:var(--g-dark);padding:0.35rem 0.9rem;border-radius:50px;font-size:0.85rem;font-weight:700}
#games .profile-xp-box{text-align:center;padding:0.9rem 1.5rem;background:linear-gradient(135deg,var(--g-primary),var(--g-pink));border-radius:18px}
#games .profile-xp-num{font-size:2rem;font-weight:900;color:white}
#games .profile-xp-label{color:rgba(255,255,255,0.9);font-size:0.8rem}
#games .subjects-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:0.9rem}
#games .subject-box{background:#F8F9FA;border-radius:14px;padding:0.9rem 1rem;display:flex;align-items:center;gap:0.8rem;border-right:4px solid transparent;transition:all 0.3s}
#games .subject-box:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,0.08)}
#games .subject-box.math{border-right-color:var(--g-primary)}
#games .subject-box.science{border-right-color:var(--g-green)}
#games .subject-box.persian{border-right-color:var(--g-pink)}
#games .subject-box.social{border-right-color:var(--g-orange)}
#games .subject-icon{font-size:1.8rem;width:45px;height:45px;display:flex;align-items:center;justify-content:center;background:#F0F0F0;border-radius:10px}
#games .subject-info{flex:1}
#games .subject-name{font-weight:700;color:var(--g-dark);font-size:0.9rem;margin-bottom:0.35rem}
#games .subject-bar{height:8px;background:#E9ECEF;border-radius:8px;overflow:hidden}
#games .subject-fill{height:100%;border-radius:8px;transition:width 1s}
#games .subject-box.math .subject-fill{background:linear-gradient(90deg,var(--g-primary),#A29BFE)}
#games .subject-box.science .subject-fill{background:linear-gradient(90deg,var(--g-green),#55EFC4)}
#games .subject-box.persian .subject-fill{background:linear-gradient(90deg,var(--g-pink),#FDA7DF)}
#games .subject-box.social .subject-fill{background:linear-gradient(90deg,var(--g-orange),#FAB1A0)}
#games .subject-xp{font-weight:900;font-size:1rem;min-width:45px;text-align:left}
#games .subject-box.math .subject-xp{color:var(--g-primary)}
#games .subject-box.science .subject-xp{color:var(--g-green)}
#games .subject-box.persian .subject-xp{color:var(--g-pink)}
#games .subject-box.social .subject-xp{color:var(--g-orange)}
#games .games-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem;margin-bottom:2.5rem}
#games .game-card{background:white;border-radius:var(--g-radius);overflow:hidden;box-shadow:0 10px 35px rgba(0,0,0,0.1);transition:all 0.4s cubic-bezier(0.175,0.885,0.32,1.275)}
#games .game-card:hover{transform:translateY(-10px) scale(1.02);box-shadow:0 20px 50px rgba(108,92,231,0.25)}
#games .game-card-top{height:110px;background:linear-gradient(135deg,var(--g-primary),var(--g-pink));display:flex;align-items:center;justify-content:center}
#games .game-card:nth-child(2n) .game-card-top{background:linear-gradient(135deg,var(--g-secondary),var(--g-green))}
#games .game-card:nth-child(3n) .game-card-top{background:linear-gradient(135deg,var(--g-accent),var(--g-orange))}
#games .game-icon{font-size:3.5rem;filter:drop-shadow(0 4px 8px rgba(0,0,0,0.2))}
#games .game-card-body{padding:1.4rem}
#games .game-title{font-size:1.15rem;font-weight:800;color:var(--g-dark);margin-bottom:0.6rem}
#games .game-desc{color:#636E72;font-size:0.9rem;line-height:1.5;margin-bottom:0.9rem;min-height:42px}
#games .game-tags{display:flex;gap:0.6rem;margin-bottom:1rem;flex-wrap:wrap}
#games .game-tag{background:#F0F3F5;padding:0.35rem 0.8rem;border-radius:50px;font-size:0.8rem;color:#636E72;font-weight:600}
#games .play-btn{width:100%;padding:0.9rem;background:linear-gradient(135deg,var(--g-primary),var(--g-pink));border:none;border-radius:14px;color:white;font-family:inherit;font-size:1rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.5rem;transition:all 0.3s}
#games .play-btn:hover{transform:scale(1.03);box-shadow:0 10px 30px rgba(108,92,231,0.4)}
#games .game-score{text-align:center;margin-top:0.9rem;padding:0.6rem;background:linear-gradient(135deg,#FFF9E6,#FFF3CD);border-radius:10px;font-weight:700;color:#856404;font-size:0.9rem}
#games .exams-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1.5rem}
#games .exam-card{background:white;border-radius:var(--g-radius);overflow:hidden;box-shadow:0 10px 35px rgba(0,0,0,0.1);transition:all 0.4s;position:relative}
#games .exam-card:hover{transform:translateY(-8px)}
#games .exam-ribbon{position:absolute;top:18px;left:-32px;background:linear-gradient(135deg,var(--g-green),#00D2A0);color:white;padding:0.45rem 2.5rem;font-size:0.75rem;font-weight:700;transform:rotate(-45deg);z-index:2}
#games .exam-card.done .exam-ribbon{background:linear-gradient(135deg,var(--g-accent),#F8B739);color:var(--g-dark)}
#games .exam-card-head{padding:1.75rem 1.4rem 1.25rem;background:#F8F9FA;border-bottom:3px dashed #E9ECEF;position:relative}
#games .exam-icon-bg{position:absolute;top:0.8rem;left:0.8rem;font-size:2.2rem;opacity:0.15}
#games .exam-title{font-size:1.2rem;font-weight:800;color:var(--g-dark);padding-left:2.5rem}
#games .exam-card-body{padding:1.4rem}
#games .exam-info-row{display:grid;grid-template-columns:repeat(2,1fr);gap:0.9rem;margin-bottom:1.25rem}
#games .exam-info-item{display:flex;align-items:center;gap:0.5rem;padding:0.65rem;background:#F8F9FA;border-radius:10px}
#games .exam-info-icon{font-size:1.2rem}
#games .exam-info-text{font-size:0.85rem;color:#636E72}
#games .exam-info-text strong{display:block;color:var(--g-dark);font-weight:700}
#games .exam-result{background:linear-gradient(135deg,#D4EDDA,#C3E6CB);border-radius:14px;padding:1.1rem;text-align:center;margin-bottom:0.9rem}
#games .exam-result-score{font-size:1.8rem;font-weight:900;color:var(--g-green)}
#games .exam-result-label{font-size:0.85rem;color:#155724;font-weight:600}
#games .exam-btn{width:100%;padding:0.9rem;border:none;border-radius:14px;font-family:inherit;font-size:1rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.5rem;transition:all 0.3s}
#games .exam-btn.start{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white}
#games .exam-btn.view{background:linear-gradient(135deg,var(--g-secondary),var(--g-green));color:white}
#games .exam-btn:hover{transform:scale(1.03);box-shadow:0 10px 25px rgba(0,0,0,0.18)}
#games .leaderboard-box{background:rgba(255,255,255,0.95);border-radius:var(--g-radius);padding:1.75rem;margin-top:2rem;box-shadow:0 10px 40px rgba(108,92,231,0.3)}
#games .leaderboard-title{font-size:1.6rem;font-weight:900;color:var(--g-dark);text-align:center;margin-bottom:1.25rem}
#games .leader-list{display:flex;flex-direction:column;gap:0.65rem}
#games .leader-row{display:flex;align-items:center;gap:0.9rem;padding:0.9rem 1.1rem;background:#F8F9FA;border-radius:14px;transition:all 0.3s}
#games .leader-row:hover{transform:translateX(-5px)}
#games .leader-rank{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:1.2rem}
#games .leader-row:nth-child(1) .leader-rank{background:linear-gradient(135deg,#FFD700,#FFA500);color:white}
#games .leader-row:nth-child(2) .leader-rank{background:linear-gradient(135deg,#C0C0C0,#A0A0A0);color:white}
#games .leader-row:nth-child(3) .leader-rank{background:linear-gradient(135deg,#CD7F32,#B87333);color:white}
#games .leader-row:nth-child(n+4) .leader-rank{background:#E9ECEF;color:var(--g-dark);font-size:1rem}
#games .leader-name{flex:1;font-weight:700;color:var(--g-dark)}
#games .leader-lvl{font-size:0.75rem;color:#636E72;background:#E9ECEF;padding:0.2rem 0.5rem;border-radius:50px}
#games .leader-pts{font-weight:900;font-size:1rem;color:var(--g-primary);min-width:65px;text-align:left}
#games .empty-box{text-align:center;padding:3.5rem 2rem;background:white;border-radius:var(--g-radius)}
#games .empty-icon{font-size:4.5rem;margin-bottom:0.9rem}
#games .empty-title{font-size:1.4rem;font-weight:800;color:var(--g-dark);margin-bottom:0.4rem}
#games .empty-text{color:#636E72}
#games .login-box{text-align:center;padding:3.5rem 2rem;background:white;border-radius:var(--g-radius)}
#games .login-icon{font-size:4.5rem;margin-bottom:0.9rem}
#games .login-box h3{font-size:1.4rem;color:var(--g-dark);margin-bottom:1rem}
#games .login-link{display:inline-flex;align-items:center;gap:0.5rem;padding:0.9rem 2rem;background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white;text-decoration:none;border-radius:50px;font-weight:700}
#games .g-modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(45,52,54,0.95);z-index:10000;overflow-y:auto}
#games .g-modal-box{background:white;border-radius:28px;width:95%;max-width:800px;max-height:92vh;overflow-y:auto;margin:2rem auto;box-shadow:0 30px 100px rgba(0,0,0,0.4)}
#games .g-modal-head{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));padding:1.4rem 1.75rem;border-radius:28px 28px 0 0;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem}
#games .g-modal-user{display:flex;align-items:center;gap:0.9rem}
#games .g-modal-avatar{width:50px;height:50px;background:linear-gradient(135deg,var(--g-accent),#F8B739);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:900;color:var(--g-dark);border:3px solid white}
#games .g-modal-info h3{color:white;font-size:1.05rem;margin:0 0 0.2rem}
#games .g-modal-info span{color:rgba(255,255,255,0.85);font-size:0.85rem}
#games .g-timer{background:rgba(255,255,255,0.2);padding:0.65rem 1.1rem;border-radius:50px;color:white;font-weight:700;font-size:1.05rem}
#games .g-progress-bar{padding:0.9rem 1.75rem;background:#F8F9FA;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.9rem}
#games .g-progress-info{font-weight:700;color:var(--g-dark)}
#games .g-progress-track{width:180px;height:10px;background:#E9ECEF;border-radius:8px;overflow:hidden}
#games .g-progress-fill{height:100%;background:linear-gradient(90deg,var(--g-primary),var(--g-pink));border-radius:8px;transition:width 0.3s}
#games .g-modal-content{padding:1.75rem}
#games .g-question h4{font-size:1.15rem;line-height:1.7;color:var(--g-dark);margin-bottom:1.25rem;padding:1.25rem;background:#F8F9FA;border-radius:14px;border-right:4px solid var(--g-primary)}
#games .g-options{display:flex;flex-direction:column;gap:0.65rem}
#games .g-option{display:block;width:100%;background:white;border:3px solid #E9ECEF;padding:1.1rem 1.3rem;border-radius:14px;text-align:right;cursor:pointer;transition:all 0.3s;font-family:inherit;font-size:1rem;font-weight:500;color:var(--g-dark)}
#games .g-option:hover{border-color:var(--g-primary);background:#F8F9FF;transform:translateX(-5px)}
#games .g-option.selected{border-color:var(--g-primary);background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white;transform:translateX(-8px)}
#games textarea.g-option{min-height:130px;resize:vertical}
#games .g-controls{display:flex;justify-content:space-between;gap:0.9rem;margin-top:1.75rem;padding-top:1.25rem;border-top:3px dashed #E9ECEF}
#games .g-nav-btn{padding:0.9rem 1.75rem;border:none;border-radius:50px;font-family:inherit;font-size:0.95rem;font-weight:700;cursor:pointer;transition:all 0.3s;display:flex;align-items:center;gap:0.4rem}
#games .g-btn-prev{background:#E9ECEF;color:var(--g-dark)}
#games .g-btn-next{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white}
#games .g-btn-submit{background:linear-gradient(135deg,var(--g-green),#00D2A0);color:white}
#games .g-nav-btn:hover:not(:disabled){transform:translateY(-3px)}
#games .g-nav-btn:disabled{opacity:0.5;cursor:not-allowed}
#games .g-modal-foot{padding:1.25rem 1.75rem;text-align:center;background:#F8F9FA;border-radius:0 0 28px 28px}
#games .g-exit-btn{background:linear-gradient(135deg,var(--g-red),#EE5A5A);color:white;padding:0.9rem 1.75rem;border:none;border-radius:50px;font-family:inherit;font-size:1rem;font-weight:700;cursor:pointer;transition:all 0.3s}
#games .g-exit-btn:hover{transform:scale(1.05)}
#games .g-alert{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(45,52,54,0.9);z-index:20000;align-items:center;justify-content:center}
#games .g-alert-box{background:white;border-radius:28px;padding:2.25rem;max-width:400px;width:90%;text-align:center}
#games .g-alert-icon{font-size:4.5rem;margin-bottom:0.9rem}
#games .g-alert-title{font-size:1.5rem;font-weight:900;color:var(--g-dark);margin-bottom:0.9rem}
#games .g-alert-msg{color:#636E72;line-height:1.7;margin-bottom:1.25rem}
#games .g-alert-btns{display:flex;gap:0.9rem;justify-content:center;flex-wrap:wrap}
#games .g-alert-btn{padding:0.8rem 1.75rem;border:none;border-radius:50px;font-family:inherit;font-weight:700;cursor:pointer;transition:all 0.3s}
#games .g-alert-btn-primary{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white}
#games .g-alert-btn-danger{background:linear-gradient(135deg,var(--g-red),#EE5A5A);color:white}
#games .g-alert-btn-secondary{background:#E9ECEF;color:var(--g-dark)}
#games .g-alert-btn:hover{transform:translateY(-3px)}
#games .g-stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:0.9rem;margin-bottom:1.75rem}
#games .g-stat-card{background:white;border-radius:18px;padding:1.1rem;text-align:center;box-shadow:0 5px 18px rgba(0,0,0,0.08)}
#games .g-stat-icon{font-size:2.2rem;margin-bottom:0.4rem}
#games .g-stat-value{font-size:1.3rem;font-weight:900;margin-bottom:0.2rem}
#games .g-stat-value.excellent{color:var(--g-green)}
#games .g-stat-value.good{color:var(--g-secondary)}
#games .g-stat-value.average{color:var(--g-accent)}
#games .g-stat-value.poor{color:var(--g-red)}
#games .g-stat-label{font-size:0.8rem;color:#636E72;font-weight:600}
#games .g-q-result{background:white;border-radius:18px;padding:1.35rem;margin-bottom:1.25rem;border:3px solid transparent}
#games .g-q-result.correct{border-color:var(--g-green);background:#F0FFF4}
#games .g-q-result.incorrect{border-color:var(--g-red);background:#FFF5F5}
#games .g-q-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:0.9rem;padding-bottom:0.9rem;border-bottom:2px dashed #E9ECEF}
#games .g-q-num{background:linear-gradient(135deg,var(--g-primary),var(--g-pink));color:white;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900}
#games .g-q-pts{background:#F8F9FA;padding:0.45rem 0.9rem;border-radius:50px;font-size:0.85rem;font-weight:700}
#games .g-q-text{font-size:1.05rem;line-height:1.6;margin-bottom:0.9rem;color:var(--g-dark)}
#games .g-result-badge{display:inline-flex;padding:0.55rem 1.1rem;border-radius:50px;font-weight:700;font-size:0.9rem}
#games .badge-ok{background:#D4EDDA;color:#155724}
#games .badge-no{background:#F8D7DA;color:#721C24}
#games .g-ans-section{display:grid;gap:0.9rem;margin-top:0.9rem}
#games .g-ans-block{padding:0.9rem;border-radius:10px;border:2px solid #E9ECEF}
#games .g-ans-label{font-size:0.8rem;font-weight:700;margin-bottom:0.4rem;color:#636E72}
#games .g-ans-text{font-size:0.95rem;color:var(--g-dark)}
#games .g-ans-block.user{background:#F8F9FA}
#games .g-ans-block.user.correct{background:#D4EDDA;border-color:var(--g-green)}
#games .g-ans-block.user.incorrect{background:#F8D7DA;border-color:var(--g-red)}
#games .g-ans-block.correct-ans{background:#D1ECF1;border-color:#17a2b8}
#games .g-mcq-opts{margin-top:0.9rem}
#games .g-mcq-opt{padding:0.8rem 1.1rem;margin:0.45rem 0;border-radius:10px;background:#F8F9FA;border:2px solid #E9ECEF}
#games .g-mcq-opt.user-sel{background:#FFF3CD;border-color:var(--g-accent);font-weight:700}
#games .g-mcq-opt.correct-opt{background:#D4EDDA;border-color:var(--g-green);font-weight:700}
@media(max-width:768px){#games .games-wrapper{padding:1rem}#games .profile-top,#games .profile-user{flex-direction:column;text-align:center}#games .profile-xp-box{width:100%}#games .subjects-row,#games .games-grid,#games .exams-grid{grid-template-columns:1fr}#games .g-modal-box{width:100%;border-radius:22px 22px 0 0;margin:0;margin-top:auto}#games .g-controls{flex-wrap:wrap}#games .g-nav-btn{flex:1;min-width:90px;justify-content:center}#games .g-stats-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:480px){#games .games-header h2{font-size:1.6rem}#games .exam-info-row{grid-template-columns:1fr}}
</style>

<div class="games-wrapper">
    <header class="games-header">
        <h2>🎮 سرزمین بازی و آزمون 📝</h2>
        <p>یادگیری با بازی، موفقیت با تلاش!</p>
    </header>

    <nav class="games-tabs">
        <button class="games-tab-btn active" onclick="gamesTabSwitch('play')" data-tab="play">
            <span class="tab-icon">🎮</span><span>بازی‌ها</span>
            <?php if ($unfinishedGamesCount > 0): ?><span class="games-tab-badge"><?= $unfinishedGamesCount ?></span><?php endif; ?>
        </button>
        <button class="games-tab-btn" onclick="gamesTabSwitch('quiz')" data-tab="quiz">
            <span class="tab-icon">📝</span><span>آزمون‌ها</span>
            <?php if ($unfinishedExamsCount > 0): ?><span class="games-tab-badge"><?= $unfinishedExamsCount ?></span><?php endif; ?>
        </button>
    </nav>

    <div id="games-play-tab" class="games-tab-content active">
        <?php if (!$isLoggedIn): ?>
            <div class="login-box"><div class="login-icon">🔐</div><h3>برای ورود به سرزمین بازی‌ها، اول وارد شو!</h3><a href="javascript:void(0)" onclick="showSection('login')" class="login-link"><span>ورود به حساب</span><span>🚀</span></a></div>
        <?php else: ?>
            <div class="games-profile">
                <div class="profile-top">
                    <div class="profile-user">
                        <div class="profile-avatar"><?= mb_substr($userFullName, 0, 1, 'UTF-8') ?></div>
                        <div class="profile-info"><h3><?= htmlspecialchars($userFullName) ?></h3><div class="profile-level"><span>👑</span><span>سطح <?= $student_xp['level'] ?></span></div></div>
                    </div>
                    <div class="profile-xp-box"><div class="profile-xp-num"><?= number_format($student_xp['total_xp']) ?></div><div class="profile-xp-label">امتیاز کل ⭐</div></div>
                </div>
                <div class="subjects-row">
                    <?php $subjects = [['icon'=>'🧮','name'=>'ریاضی','key'=>'math_xp','class'=>'math'],['icon'=>'🔬','name'=>'علوم','key'=>'science_xp','class'=>'science'],['icon'=>'📖','name'=>'فارسی','key'=>'persian_xp','class'=>'persian'],['icon'=>'🗺️','name'=>'اجتماعی','key'=>'social_xp','class'=>'social']];
                    foreach ($subjects as $s): $xp = $student_xp[$s['key']]; $percent = min(100, ($xp / 500) * 100); ?>
                    <div class="subject-box <?= $s['class'] ?>"><div class="subject-icon"><?= $s['icon'] ?></div><div class="subject-info"><div class="subject-name"><?= $s['name'] ?></div><div class="subject-bar"><div class="subject-fill" style="width:<?= $percent ?>%"></div></div></div><div class="subject-xp"><?= $xp ?></div></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php if (empty($games)): ?>
                <div class="empty-box"><div class="empty-icon">🎮</div><h3 class="empty-title">هنوز بازی‌ای اضافه نشده!</h3><p class="empty-text">به زودی بازی‌های جذاب اضافه می‌شن</p></div>
            <?php else: ?>
                <div class="games-grid">
                    <?php $gameIcons = ['🎯','🎲','🧩','🎪','🎨','🎸','🎭','🎰']; foreach ($games as $i => $g): $icon = $gameIcons[$i % count($gameIcons)]; ?>
                    <article class="game-card">
                        <div class="game-card-top"><span class="game-icon"><?= $icon ?></span></div>
                        <div class="game-card-body">
                            <h3 class="game-title"><?= htmlspecialchars($g['title']) ?></h3>
                            <p class="game-desc"><?= $g['description'] ? htmlspecialchars(mb_substr($g['description'], 0, 70, 'UTF-8')).'...' : 'یه بازی هیجان‌انگیز!' ?></p>
                            <div class="game-tags"><?php if ($g['category_name']): ?><span class="game-tag"><?= $g['category_icon'] ?> <?= htmlspecialchars($g['category_name']) ?></span><?php endif; ?><?php if (isset($g['estimated_time']) && $g['estimated_time']): ?><span class="game-tag">⏱️ <?= $g['estimated_time'] ?> دقیقه</span><?php endif; ?></div>
                            <button class="play-btn" onclick="startGame(<?= $g['id'] ?>)"><span>🚀</span><span>بزن بریم!</span></button>
                            <?php if ($g['best_score']): ?><div class="game-score">🏆 رکورد تو: <?= $g['best_score'] ?> (<?= round($g['best_accuracy']) ?>%)</div><?php endif; ?>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <section class="leaderboard-box">
                <h2 class="leaderboard-title"><span>🏆</span> قهرمانان کلاس <span>🏆</span></h2>
                <?php if (empty($leaderboard)): ?><p style="text-align:center;color:#636E72;">هنوز کسی امتیاز نگرفته!</p>
                <?php else: ?>
                <div class="leader-list">
                    <?php $medals = ['🥇','🥈','🥉']; foreach ($leaderboard as $i => $p): ?>
                    <div class="leader-row"><div class="leader-rank"><?= $i < 3 ? $medals[$i] : ($i + 1) ?></div><div class="leader-name"><?= htmlspecialchars($p['first_name'].' '.$p['last_name']) ?></div><div class="leader-lvl">سطح <?= $p['level'] ?></div><div class="leader-pts"><?= number_format($p['final_xp']) ?> ⭐</div></div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    </div>

    <div id="games-quiz-tab" class="games-tab-content">
        <?php if (empty($publishedExams)): ?>
            <div class="empty-box"><div class="empty-icon">📚</div><h3 class="empty-title">هنوز آزمونی نداریم!</h3><p class="empty-text">وقتی معلم آزمون بذاره، اینجا نشون داده می‌شه</p></div>
        <?php else: ?>
            <div class="exams-grid">
                <?php foreach($publishedExams as $e): ?>
                <article class="exam-card <?= $e['has_attempted'] ? 'done' : '' ?>">
                    <div class="exam-ribbon"><?= $e['has_attempted'] ? '✅ انجام شده' : '🆕 جدید' ?></div>
                    <div class="exam-card-head"><span class="exam-icon-bg">📝</span><h3 class="exam-title"><?= htmlspecialchars($e['title']) ?></h3></div>
                    <div class="exam-card-body">
                        <div class="exam-info-row">
                            <div class="exam-info-item"><span class="exam-info-icon">📅</span><div class="exam-info-text"><strong><?= formatDateShamsi($e['exam_date']) ?></strong>تاریخ</div></div>
                            <div class="exam-info-item"><span class="exam-info-icon">⏰</span><div class="exam-info-text"><strong><?= $e['exam_time'] ?: 'نامشخص' ?></strong>ساعت</div></div>
                            <div class="exam-info-item"><span class="exam-info-icon">⏱️</span><div class="exam-info-text"><strong><?= $e['duration_minutes'] ?> دقیقه</strong>مدت</div></div>
                            <div class="exam-info-item"><span class="exam-info-icon">❓</span><div class="exam-info-text"><strong><?= $e['question_count'] ?> سوال</strong>تعداد</div></div>
                        </div>
                        <?php if ($e['has_attempted']): ?>
                            <div class="exam-result"><div class="exam-result-score"><?= $e['score'] ?> / <?= $e['total_score'] ?></div><div class="exam-result-label">نمره تو 🎉</div></div>
                            <button class="exam-btn view" onclick="viewExamResults(<?= $e['id'] ?>)"><span>📊</span><span>ببین چی جواب دادی</span></button>
                        <?php else: ?>
                            <button class="exam-btn start" onclick="startExam(<?= $e['id'] ?>)"><span>🚀</span><span>شروع آزمون</span></button>
                        <?php endif; ?>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Exam Modal -->
<div id="gamesExamModal" class="g-modal">
    <div class="g-modal-box">
        <header class="g-modal-head">
            <div class="g-modal-user"><div class="g-modal-avatar"><?= mb_substr($userFullName, 0, 1, 'UTF-8') ?></div><div class="g-modal-info"><h3 id="gamesExamTitle">عنوان آزمون</h3><span><?= htmlspecialchars($userFullName) ?></span></div></div>
            <div class="g-timer"><span>⏰</span><span id="gamesExamTimer">00:00</span></div>
        </header>
        <div class="g-progress-bar"><span class="g-progress-info" id="gamesQuestionProgress">سوال 1 از 10</span><div class="g-progress-track"><div class="g-progress-fill" id="gamesExamProgressBar"></div></div></div>
        <div class="g-modal-content"><div class="g-question"><h4 id="gamesCurrentQuestion">در حال بارگذاری سوال...</h4><div id="gamesQuestionOptions" class="g-options"></div></div>
            <div class="g-controls">
                <button id="gamesPrevQuestion" class="g-nav-btn g-btn-prev" onclick="gamesPrevQ()" disabled><span>⬅️</span><span>قبلی</span></button>
                <button id="gamesNextQuestion" class="g-nav-btn g-btn-next" onclick="gamesNextQ()"><span>بعدی</span><span>➡️</span></button>
                <button id="gamesSubmitExam" class="g-nav-btn g-btn-submit" onclick="gamesSubmit()" style="display:none"><span>✅</span><span>اتمام</span></button>
            </div>
        </div>
        <footer class="g-modal-foot"><button class="g-exit-btn" onclick="gamesExit()"><span>❌</span><span>خروج از آزمون</span></button></footer>
    </div>
</div>

<!-- Alert Modal -->
<div id="gamesAlertModal" class="g-alert">
    <div class="g-alert-box"><div class="g-alert-icon" id="gamesAlertIcon">🎉</div><div class="g-alert-title" id="gamesAlertTitle">عنوان</div><div class="g-alert-msg" id="gamesAlertMessage">پیام</div><div class="g-alert-btns" id="gamesAlertButtons"></div></div>
</div>

<!-- Results Modal -->
<div id="gamesResultsModal" class="g-modal">
    <div class="g-modal-box" style="max-width:900px">
        <header class="g-modal-head"><div class="g-modal-user"><div class="g-modal-avatar"><?= mb_substr($userFullName, 0, 1, 'UTF-8') ?></div><div class="g-modal-info"><h3 id="gamesResultsExamTitle">نتایج آزمون</h3><span><?= htmlspecialchars($userFullName) ?></span></div></div><button class="g-nav-btn g-btn-prev" onclick="gamesCloseResults()"><span>✖</span><span>بستن</span></button></header>
        <div id="gamesResultsStats" style="padding:1.75rem;background:#F8F9FA"></div>
        <div style="padding:1.75rem"><h3 style="color:#2D3436;margin-bottom:1.25rem;text-align:center">📋 بررسی سوالات و پاسخ‌ها</h3><div id="gamesResultsQuestions"></div></div>
    </div>
</div>
</section>

<script>
(function(){
    'use strict';
    
    // متغیرهای سراسری آزمون
    var gExam = null;
    var gQIdx = 0;
    var gQuestions = [];
    var gAnswers = {};
    var gTimer = null;
    var gTimeLeft = 0;
    var gExamActive = false;
    
    // ==================== توابع Alert ====================
    window.gamesAlert = function(opts) {
        var m = document.getElementById('gamesAlertModal');
        document.getElementById('gamesAlertIcon').textContent = opts.icon || '🎉';
        document.getElementById('gamesAlertTitle').textContent = opts.title || 'توجه';
        document.getElementById('gamesAlertMessage').innerHTML = opts.message || '';
        var btns = document.getElementById('gamesAlertButtons');
        btns.innerHTML = '';
        
        if (opts.buttons && opts.buttons.length > 0) {
            opts.buttons.forEach(function(b) {
                var btn = document.createElement('button');
                btn.className = 'g-alert-btn ' + (b.cls || 'g-alert-btn-primary');
                btn.textContent = b.text;
                btn.onclick = function() {
                    m.style.display = 'none';
                    if (b.cb) b.cb();
                };
                btns.appendChild(btn);
            });
        } else {
            var btn = document.createElement('button');
            btn.className = 'g-alert-btn g-alert-btn-primary';
            btn.textContent = 'باشه! 👍';
            btn.onclick = function() {
                m.style.display = 'none';
                if (opts.callback) opts.callback();
            };
            btns.appendChild(btn);
        }
        m.style.display = 'flex';
    };

    window.gamesConfirm = function(opts) {
        gamesAlert({
            icon: opts.icon || '🤔',
            title: opts.title || 'آیا مطمئن هستید؟',
            message: opts.message || '',
            buttons: [
                { text: opts.cancelText || 'انصراف', cls: 'g-alert-btn-secondary', cb: opts.onCancel },
                { text: opts.confirmText || 'بله', cls: opts.danger ? 'g-alert-btn-danger' : 'g-alert-btn-primary', cb: opts.onConfirm }
            ]
        });
    };

    // ==================== تب‌ها ====================
    window.gamesTabSwitch = function(tab) {
        document.querySelectorAll('#games .games-tab-btn').forEach(function(b) {
            b.classList.toggle('active', b.dataset.tab === tab);
        });
        document.querySelectorAll('#games .games-tab-content').forEach(function(c) {
            c.classList.remove('active');
        });
        document.getElementById('games-' + tab + '-tab').classList.add('active');
    };

    // ==================== بازی ====================
    window.startGame = function(id) {
        var w = window.open('game-player.php?game_id=' + id, '_blank', 'width=1200,height=800');
        if (!w) gamesAlert({ icon: '🚫', title: 'خطا!', message: 'پاپ‌آپ مسدود شده!' });
    };

    // ==================== آزمون ====================
    window.startExam = function(id) {
        gamesConfirm({
            icon: '📝',
            title: 'آماده‌ای؟',
            message: '<p style="color:#FF6B6B;font-weight:bold">قبل از شروع بدون! 🔔</p><p>📝 این آزمون فقط یک بار قابل انجامه</p><p>🚫 اگه خارج شی، نمره‌ات صفر می‌شه</p><p>⏰ بعد از شروع نمی‌تونی متوقفش کنی</p>',
            confirmText: 'شروع! 💪',
            cancelText: 'بعداً 🙈',
            onConfirm: function() { loadExam(id); }
        });
    };

    function loadExam(id) {
        fetch('ajax/load_exam.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exam_id: id })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            if (d.success) {
                gExam = d.exam;
                gQuestions = d.questions;
                gAnswers = {};
                gQIdx = 0;
                if (!gQuestions || gQuestions.length === 0) {
                    gamesAlert({ icon: '😕', title: 'اوپس!', message: 'این آزمون سوالی نداره!' });
                    return;
                }
                setupExam();
            } else {
                gamesAlert({ icon: '❌', title: 'خطا!', message: d.message });
            }
        })
        .catch(function() {
            gamesAlert({ icon: '😵', title: 'خطا!', message: 'اینترنتت رو چک کن!' });
        });
    }

    function setupExam() {
        document.getElementById('gamesExamTitle').textContent = gExam.title;
        gTimeLeft = gExam.duration_minutes * 60;
        gExamActive = true;
        document.getElementById('gamesExamModal').style.display = 'block';
        document.body.style.overflow = 'hidden';
        startTimer();
        loadQ(0);
    }

    function startTimer() {
        if (gTimer) clearInterval(gTimer);
        gTimer = setInterval(function() {
            gTimeLeft--;
            if (gTimeLeft <= 0) {
                doSubmit(true);
                return;
            }
            var m = Math.floor(gTimeLeft / 60);
            var s = gTimeLeft % 60;
            var el = document.getElementById('gamesExamTimer');
            el.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
            el.style.color = gTimeLeft <= 60 ? '#FF6B6B' : (gTimeLeft <= 300 ? '#FDCB6E' : 'white');
        }, 1000);
    }

    function loadQ(idx) {
        if (idx < 0 || idx >= gQuestions.length) return;
        gQIdx = idx;
        var q = gQuestions[idx];
        document.getElementById('gamesCurrentQuestion').textContent = q.question_text || 'سوال';
        document.getElementById('gamesExamProgressBar').style.width = ((idx + 1) / gQuestions.length * 100) + '%';
        document.getElementById('gamesQuestionProgress').innerHTML = 'سوال ' + (idx + 1) + ' از ' + gQuestions.length + ' <small>(' + Object.keys(gAnswers).length + ' جواب)</small>';
        loadOpts(q);
        updateNav(idx);
    }

    function loadOpts(q) {
        var c = document.getElementById('gamesQuestionOptions');
        c.innerHTML = '';
        if (q.question_type === 'mcq') {
            var d = q.question_data;
            if (typeof d === 'string') try { d = JSON.parse(d); } catch(e) { d = {}; }
            var opts = d.options || d.choices || [];
            opts.forEach(function(opt, i) {
                var txt = typeof opt === 'string' ? opt : (opt.text || String(opt));
                var btn = document.createElement('button');
                btn.className = 'g-option' + (gAnswers[q.id] === txt ? ' selected' : '');
                btn.textContent = String.fromCharCode(65 + i) + ') ' + txt;
                btn.onclick = function() { selectAns(q.id, txt, btn); };
                c.appendChild(btn);
            });
        } else if (q.question_type === 'tf') {
            [{ v: 'true', t: '✅ درست' }, { v: 'false', t: '❌ نادرست' }].forEach(function(o) {
                var btn = document.createElement('button');
                btn.className = 'g-option' + (gAnswers[q.id] === o.v ? ' selected' : '');
                btn.textContent = o.t;
                btn.onclick = function() { selectAns(q.id, o.v, btn); };
                c.appendChild(btn);
            });
        } else if (q.question_type === 'short') {
            var ta = document.createElement('textarea');
            ta.className = 'g-option';
            ta.placeholder = 'پاسخت رو بنویس... ✍️';
            ta.value = gAnswers[q.id] || '';
            ta.oninput = function() { gAnswers[String(q.id)] = ta.value.trim(); };
            c.appendChild(ta);
        }
    }

    function selectAns(qid, ans, btn) {
        gAnswers[String(qid)] = String(ans).trim();
        document.querySelectorAll('#gamesQuestionOptions .g-option').forEach(function(b) { b.classList.remove('selected'); });
        if (btn) btn.classList.add('selected');
        document.getElementById('gamesQuestionProgress').innerHTML = 'سوال ' + (gQIdx + 1) + ' از ' + gQuestions.length + ' <small>(' + Object.keys(gAnswers).length + ' جواب)</small>';
    }

    function updateNav(idx) {
        document.getElementById('gamesPrevQuestion').disabled = (idx === 0);
        document.getElementById('gamesNextQuestion').disabled = (idx === gQuestions.length - 1);
        document.getElementById('gamesNextQuestion').style.display = (idx === gQuestions.length - 1) ? 'none' : 'inline-flex';
        document.getElementById('gamesSubmitExam').style.display = (idx === gQuestions.length - 1) ? 'inline-flex' : 'none';
    }

    window.gamesPrevQ = function() { if (gQIdx > 0) loadQ(gQIdx - 1); };
    window.gamesNextQ = function() { if (gQIdx < gQuestions.length - 1) loadQ(gQIdx + 1); };

    window.gamesSubmit = function() {
        var unanswered = gQuestions.length - Object.keys(gAnswers).length;
        if (unanswered > 0) {
            gamesConfirm({
                icon: '⚠️',
                title: 'صبر کن!',
                message: '<p style="color:#FF6B6B;font-weight:bold">' + unanswered + ' سوال جواب ندادی!</p><p>مطمئنی تموم کنی؟</p>',
                confirmText: 'تموم کن 🏁',
                cancelText: 'برگردم 🔙',
                danger: true,
                onConfirm: function() { doSubmit(false); }
            });
            return;
        }
        doSubmit(false);
    };

    function doSubmit(auto) {
        stopTimer();
        var time = gExam ? Math.floor((gExam.duration_minutes * 60 - gTimeLeft) / 60) : 0;
        
        fetch('ajax/submit_exam.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exam_id: gExam.id, answers: gAnswers, time_taken: time, auto_submit: auto })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            hideExam();
            if (d.success) {
                var icon = '🎉', title = 'آفرین!';
                if (auto) { icon = '⏰'; title = 'زمان تمام شد!'; }
                else if (d.percentage >= 90) { icon = '🏆'; title = 'عالی!'; }
                else if (d.percentage >= 70) { icon = '👏'; title = 'خوب بود!'; }
                else if (d.percentage >= 50) { icon = '😊'; title = 'قبول!'; }
                else { icon = '📚'; title = 'بیشتر تلاش کن!'; }
                var msg = '<p>نمره: <strong>' + d.score + '/' + d.total_score + '</strong> (' + d.percentage + '%)</p>';
                if (d.xp_earned > 0) msg += '<p style="background:#FDCB6E;padding:0.5rem;border-radius:10px">+' + d.xp_earned + ' امتیاز! 🌟</p>';
                gamesAlert({ icon: icon, title: title, message: msg, callback: function() { location.reload(); } });
            } else {
                gamesAlert({ icon: '❌', title: 'خطا!', message: d.message });
            }
        })
        .catch(function() {
            hideExam();
            gamesAlert({ icon: '😵', title: 'خطا!', message: 'ارسال نشد!' });
        });
    }

    // ==================== خروج از آزمون - اصلاح شده ====================
    window.gamesExit = function() {
        gamesConfirm({
            icon: '🚨',
            title: 'می‌خوای بری؟',
            message: '<p style="color:#FF6B6B;font-weight:bold">اگه بری نمره‌ات صفر می‌شه!</p><p>دیگه نمی‌تونی شرکت کنی!</p>',
            confirmText: 'می‌رم 😭',
            cancelText: 'نه، ادامه! 💪',
            danger: true,
            onConfirm: function() {
                forceExit();
            }
        });
    };

    function forceExit() {
        console.log('forceExit called');
        
        // اول تایمر رو متوقف کن
        stopTimer();
        
        // اطلاعات لازم رو ذخیره کن
        var examId = gExam ? gExam.id : 0;
        var time = gExam ? Math.floor((gExam.duration_minutes * 60 - gTimeLeft) / 60) : 0;
        
        // مودال رو ببند
        hideExam();
        
        // پیام در حال ارسال نشون بده
        gamesAlert({
            icon: '⏳',
            title: 'صبر کن...',
            message: 'در حال ثبت خروج...'
        });
        
        // درخواست خروج بفرست
        fetch('ajax/submit_exam.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                exam_id: examId,
                answers: {},
                time_taken: time,
                force_exit: true
            })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            console.log('Exit response:', d);
            gamesAlert({
                icon: '😢',
                title: 'خارج شدی!',
                message: 'نمره‌ات صفر شد. دفعه بعد بیشتر تلاش کن! 💪',
                callback: function() { location.reload(); }
            });
        })
        .catch(function(e) {
            console.error('Exit error:', e);
            gamesAlert({
                icon: '❌',
                title: 'خطا!',
                message: 'مشکلی پیش اومد ولی خارج شدی.',
                callback: function() { location.reload(); }
            });
        });
    }

    function stopTimer() {
        if (gTimer) {
            clearInterval(gTimer);
            gTimer = null;
        }
    }

    function hideExam() {
        console.log('hideExam called');
        stopTimer();
        gExamActive = false;
        var modal = document.getElementById('gamesExamModal');
        if (modal) modal.style.display = 'none';
        document.body.style.overflow = '';
        gExam = null;
        gQuestions = [];
        gAnswers = {};
        gQIdx = 0;
        gTimeLeft = 0;
    }

    // ==================== نتایج آزمون ====================
    window.viewExamResults = function(id) {
        gamesAlert({ icon: '⏳', title: 'صبر کن', message: 'در حال بارگذاری...' });
        fetch('ajax/get_exam_details.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exam_id: id })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
            document.getElementById('gamesAlertModal').style.display = 'none';
            if (d.success) {
                renderResults(d);
                document.getElementById('gamesResultsModal').style.display = 'block';
                document.body.style.overflow = 'hidden';
            } else {
                gamesAlert({ icon: '❌', title: 'خطا!', message: d.message || 'بارگذاری نشد' });
            }
        })
        .catch(function() {
            document.getElementById('gamesAlertModal').style.display = 'none';
            gamesAlert({ icon: '😵', title: 'خطا!', message: 'اینترنتت رو چک کن' });
        });
    };

    function renderResults(d) {
        var att = d.attempt, st = d.statistics;
        document.getElementById('gamesResultsExamTitle').textContent = d.exam.title;
        var gc = att.percentage >= 90 ? 'excellent' : (att.percentage >= 70 ? 'good' : (att.percentage >= 50 ? 'average' : 'poor'));
        var ge = att.percentage >= 90 ? '🏆' : (att.percentage >= 70 ? '🥈' : (att.percentage >= 50 ? '🥉' : '📝'));
        document.getElementById('gamesResultsStats').innerHTML = '<div class="g-stats-grid"><div class="g-stat-card"><div class="g-stat-icon">' + ge + '</div><div class="g-stat-value ' + gc + '">' + att.score + '/' + att.total_score + '</div><div class="g-stat-label">نمره</div></div><div class="g-stat-card"><div class="g-stat-icon">📊</div><div class="g-stat-value ' + gc + '">' + att.percentage + '%</div><div class="g-stat-label">درصد</div></div><div class="g-stat-card"><div class="g-stat-icon">✅</div><div class="g-stat-value excellent">' + st.correct_answers + '</div><div class="g-stat-label">درست</div></div><div class="g-stat-card"><div class="g-stat-icon">❌</div><div class="g-stat-value poor">' + st.wrong_answers + '</div><div class="g-stat-label">غلط</div></div></div>';
        
        var html = '';
        d.questions.forEach(function(q, i) {
            var cls = q.is_correct ? 'correct' : 'incorrect';
            html += '<div class="g-q-result ' + cls + '"><div class="g-q-head"><div class="g-q-num">' + (i + 1) + '</div><div class="g-q-pts">' + q.points_earned + '/' + q.points + '</div></div><div class="g-q-text">' + q.question_text + '</div><div class="g-result-badge ' + (q.is_correct ? 'badge-ok' : 'badge-no') + '">' + (q.is_correct ? '✅ درست' : '❌ نادرست') + '</div>';
            if (q.question_type === 'mcq' && q.options) {
                html += '<div class="g-mcq-opts">';
                q.options.forEach(function(opt, j) {
                    var oc = 'g-mcq-opt' + (opt === q.user_answer ? ' user-sel' : '') + (opt === q.correct_answer ? ' correct-opt' : '');
                    html += '<div class="' + oc + '">' + String.fromCharCode(65 + j) + ') ' + opt + '</div>';
                });
                html += '</div>';
            } else if (q.question_type === 'tf') {
                html += '<div class="g-ans-section"><div class="g-ans-block user ' + cls + '"><div class="g-ans-label">جواب تو</div><div class="g-ans-text">' + (q.user_answer === 'true' ? 'درست' : 'نادرست') + '</div></div><div class="g-ans-block correct-ans"><div class="g-ans-label">جواب درست</div><div class="g-ans-text">' + (q.correct_answer === 'true' ? 'درست' : 'نادرست') + '</div></div></div>';
            } else if (q.question_type === 'short') {
                html += '<div class="g-ans-section"><div class="g-ans-block user ' + cls + '"><div class="g-ans-label">جواب تو</div><div class="g-ans-text">' + (q.user_answer || '-') + '</div></div><div class="g-ans-block correct-ans"><div class="g-ans-label">جواب درست</div><div class="g-ans-text">' + q.correct_answer + '</div></div></div>';
            }
            html += '</div>';
        });
        document.getElementById('gamesResultsQuestions').innerHTML = html;
    }

    window.gamesCloseResults = function() {
        document.getElementById('gamesResultsModal').style.display = 'none';
        document.body.style.overflow = '';
    };

    // جلوگیری از خروج تصادفی
    window.addEventListener('beforeunload', function(e) {
        if (gExamActive && gTimer) {
            e.preventDefault();
            e.returnValue = 'آزمون در حال اجراست!';
            return e.returnValue;
        }
    });

    console.log('🎮 بخش بازی‌ها بارگذاری شد ✅');
})();
</script>
