<?php
session_start();
require_once '../config.php';
require_once '../functions.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    header('Location: login.php');
    exit();
}

 $studentId = $_SESSION['user_id'];

// === تابع تبدیل اعداد انگلیسی به فارسی ===
function convertNumbersToPersian($string) {
    $persian_digits = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    $english_digits = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    return str_replace($english_digits, $persian_digits, $string);
}

// === تابع فرمت کردن عدد با کاما و تبدیل به فارسی ===
function formatPersianNumber($number) {
    return convertNumbersToPersian(number_format($number));
}

// === جایگزین تابع‌های قبلی تبدیل میلادی به شمسی ===

/**
 * تبدیل تاریخ میلادی (G) به شمسی (J) — الگوریتم استاندارد
 * ورودی: سال، ماه، روز میلادی (integers)
 * خروجی: آرایه [jYear, jMonth, jDay]
 */
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_days_in_month = array(31,28,31,30,31,30,31,31,30,31,30,31);
    $j_days_in_month = array(31,31,31,31,31,31,30,30,30,30,30,29);

    $gy2 = $gy - 1600;
    $gm2 = $gm - 1;
    $gd2 = $gd - 1;

    $g_day_no = 365*$gy2 + intval(($gy2+3)/4) - intval(($gy2+99)/100) + intval(($gy2+399)/400);
    for ($i=0; $i < $gm2; ++$i) $g_day_no += $g_days_in_month[$i];
    // leap year adjustment
    if ($gm2 > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) $g_day_no += 1;
    $g_day_no += $gd2;

    $j_day_no = $g_day_no - 79;

    $j_np = intval($j_day_no / 12053); // 12053 = 33 years * 365 + 8 leap days
    $j_day_no = $j_day_no % 12053;

    $jy = 979 + 33 * $j_np + 4 * intval($j_day_no / 1461); // 1461 = 4*365 + 1
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += intval(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    $jm = 0;
    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) {
        $j_day_no -= $j_days_in_month[$i];
        $jm++;
    }
    $jd = $j_day_no + 1;
    $jm += 1;

    return array($jy, $jm, $jd);
}

/**
 * دریافت رشته تاریخ شمسی (YYYY/MM/DD) از timestamp یا رشته تاریخ میلادی
 */
function toJalaliDate($timestamp) {
    if (!$timestamp || $timestamp === '0000-00-00' || trim($timestamp) === '') return 'نامشخص';

    try {
        $date = new DateTime($timestamp);
    } catch (Exception $e) {
        return 'نامشخص';
    }

    $gy = (int)$date->format('Y');
    $gm = (int)$date->format('m');
    $gd = (int)$date->format('d');

    list($jy, $jm, $jd) = gregorian_to_jalali($gy, $gm, $gd);

    // صفرپر کردن ماه/روز برای قالب یکنواخت
    $jm = str_pad($jm, 2, '0', STR_PAD_LEFT);
    $jd = str_pad($jd, 2, '0', STR_PAD_LEFT);

    return convertNumbersToPersian("{$jy}/{$jm}/{$jd}");
}

/**
 * دریافت رشته تاریخ و زمان شمسی (YYYY/MM/DD HH:MM) از timestamp یا رشته تاریخ-زمان میلادی
 */
function toJalaliDateTime($timestamp) {
    if (!$timestamp || $timestamp === '0000-00-00' || trim($timestamp) === '') return 'نامشخص';

    try {
        $date = new DateTime($timestamp);
    } catch (Exception $e) {
        return 'نامشخص';
    }

    $gy = (int)$date->format('Y');
    $gm = (int)$date->format('m');
    $gd = (int)$date->format('d');

    $hour = $date->format('H');
    $minute = $date->format('i');

    list($jy, $jm, $jd) = gregorian_to_jalali($gy, $gm, $gd);

    $jm = str_pad($jm, 2, '0', STR_PAD_LEFT);
    $jd = str_pad($jd, 2, '0', STR_PAD_LEFT);

    return convertNumbersToPersian("{$jy}/{$jm}/{$jd} {$hour}:{$minute}");
}

// === پایان جایگزینی ===

try {
    // دریافت اطلاعات دانش‌آموز
    $studentStmt = $conn->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.national_id,
            u.created_at,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    
    $studentStmt->execute([$studentId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        die('اطلاعات دانش‌آموز یافت نشد');
    }
    
    // محاسبه رنک کلی
    $rankStmt = $conn->prepare("
        SELECT COUNT(*) + 1 as student_rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student' AND sx.total_xp > ?
    ");
    $rankStmt->execute([$student['total_xp']]);
    $globalRank = $rankStmt->fetchColumn() ?: 1;
    
    // محاسبه رنک در کلاس (فرض: همه دانش‌آموزان در یک کلاس هستند)
    $classRankStmt = $conn->prepare("
        SELECT COUNT(*) + 1 as class_rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student' AND sx.total_xp > ?
    ");
    $classRankStmt->execute([$student['total_xp']]);
    $classRank = $classRankStmt->fetchColumn() ?: 1;
    
    // دریافت تعداد کل دانش‌آموزان
    $totalStudentsStmt = $conn->query("SELECT COUNT(*) FROM users WHERE user_type = 'student'");
    $totalStudents = $totalStudentsStmt->fetchColumn();
    
    // دریافت تاریخچه امتیازات XP
    $xpHistoryStmt = $conn->prepare("
        SELECT 
            h.subject,
            h.amount,
            h.reason,
            h.created_at,
            u_admin.first_name as admin_name
        FROM xp_history h
        LEFT JOIN users u_admin ON h.admin_id = u_admin.id
        WHERE h.student_id = ?
        ORDER BY h.created_at DESC
        LIMIT 50
    ");
    $xpHistoryStmt->execute([$studentId]);
    $xpHistory = $xpHistoryStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // دریافت تاریخچه بازی‌ها
    $gamesStmt = $conn->prepare("
        SELECT 
            g.title as game_title,
            gr.score,
            gr.accuracy,
            gr.time_spent,
            gr.completed_at,
            g.subject
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        ORDER BY gr.completed_at DESC
        LIMIT 20
    ");
    $gamesStmt->execute([$studentId]);
    $gameHistory = $gamesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // آمار بازی‌ها
    $statsStmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_games,
            AVG(score) as avg_score,
            MAX(score) as best_score,
            AVG(accuracy) as avg_accuracy,
            SUM(time_spent) as total_time
        FROM game_results
        WHERE student_id = ?
    ");
    $statsStmt->execute([$studentId]);
    $gameStats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    // آمار XP در ماه جاری
    $currentMonthXPStmt = $conn->prepare("
        SELECT COALESCE(SUM(amount), 0) as monthly_xp
        FROM xp_history
        WHERE student_id = ? AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())
    ");
    $currentMonthXPStmt->execute([$studentId]);
    $monthlyXP = $currentMonthXPStmt->fetchColumn() ?: 0;
    
} catch (Exception $e) {
    die('خطا در بارگیری اطلاعات: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پروفایل من - <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Baloo+Bhaijaan+2:wght@400;500;600;700;800&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            font-family: 'Baloo Bhaijaan 2', cursive;
            margin: 0;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        /* انیمیشن پس‌زمینه */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
            z-index: -1;
            animation: floatBackground 20s ease-in-out infinite;
        }
        
        @keyframes floatBackground {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            33% { transform: translate(-20px, -20px) rotate(1deg); }
            66% { transform: translate(20px, -10px) rotate(-1deg); }
        }
        
        .profile-container {
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
        }
        
        /* هدر پروفایل */
        .profile-header {
            background: rgba(255,255,255,0.95);
            border-radius: 30px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
            animation: fadeInDown 0.8s ease;
        }
        
        .profile-header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, #ff9a9e, #fad0c4, #fad0c4, #ff9a9e);
            opacity: 0.1;
            z-index: -1;
            animation: rotateGradient 15s linear infinite;
        }
        
        @keyframes rotateGradient {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .profile-avatar {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ffd700, #ffed4e);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3.5rem;
            margin: 0 auto 1.5rem;
            color: #333;
            font-weight: 800;
            position: relative;
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.4);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(255, 215, 0, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0); }
        }
        
        .profile-avatar::after {
            content: '🎓';
            position: absolute;
            bottom: -5px;
            right: -5px;
            font-size: 2.5rem;
            background: white;
            border-radius: 50%;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .profile-name {
            font-size: 2.5rem;
            font-weight: 800;
            color: #333;
            margin-bottom: 0.8rem;
            text-shadow: 2px 2px 0px rgba(0,0,0,0.1);
        }
        
        .profile-details {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }
        
        /* کارت‌های رنک */
        .rank-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
            padding: 1.5rem;
            background: rgba(102,126,234,0.1);
            border-radius: 20px;
        }
        
        .rank-card {
            text-align: center;
            padding: 1.5rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .rank-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #6a11cb, #2575fc);
        }
        
        .rank-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        .rank-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: #6a11cb;
            margin-bottom: 0.5rem;
        }
        
        .rank-label {
            font-size: 1rem;
            color: #666;
            font-weight: 600;
        }
        
        /* کارت‌های آمار */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.8s ease;
        }
        
        .stat-card::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.8) 0%, transparent 70%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .stat-card:hover::before {
            opacity: 1;
        }
        
        .stat-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .stat-icon {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            display: inline-block;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-15px); }
            60% { transform: translateY(-7px); }
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: #333;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }
        
        .stat-label {
            color: #666;
            font-weight: 600;
            font-size: 1.1rem;
            position: relative;
            z-index: 1;
        }
        
        /* بخش موضوعات */
        .subjects-section {
            background: rgba(255,255,255,0.95);
            border-radius: 25px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .subjects-section::before {
            content: "";
            position: absolute;
            top: -50px;
            right: -50px;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f093fb, #f5576c);
            opacity: 0.1;
            z-index: 0;
        }
        
        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            position: relative;
            z-index: 1;
        }
        
        .subject-card {
            background: linear-gradient(135deg, var(--bg-color), var(--bg-color-light));
            color: white;
            padding: 2rem;
            border-radius: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .subject-card::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .subject-card:hover::before {
            opacity: 1;
        }
        
        .subject-card:hover {
            transform: translateY(-10px) scale(1.05);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        
        .subject-math { --bg-color: #ff6b6b; --bg-color-light: #ff8e53; }
        .subject-science { --bg-color: #4ecdc4; --bg-color-light: #44a08d; }
        .subject-persian { --bg-color: #667eea; --bg-color-light: #764ba2; }
        .subject-social { --bg-color: #f093fb; --bg-color-light: #f5576c; }
        .subject-religion { --bg-color: #4facfe; --bg-color-light: #00f2fe; }
        
        .subject-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        .subject-xp {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }
        
        .subject-name {
            font-size: 1.2rem;
            opacity: 0.9;
            font-weight: 600;
            position: relative;
            z-index: 1;
        }
        
        /* بخش تاریخچه */
        .xp-history-section,
        .games-section {
            background: rgba(255,255,255,0.95);
            border-radius: 25px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .xp-history-section::before,
        .games-section::before {
            content: "";
            position: absolute;
            top: -50px;
            left: -50px;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            opacity: 0.1;
            z-index: 0;
        }
        
        .history-table,
        .games-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            position: relative;
            z-index: 1;
        }
        
        .history-table th,
        .games-table th {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            padding: 1rem;
            text-align: right;
            font-weight: 700;
            border: none;
        }
        
        .history-table th:first-child,
        .games-table th:first-child {
            border-top-right-radius: 10px;
        }
        
        .history-table th:last-child,
        .games-table th:last-child {
            border-top-left-radius: 10px;
        }
        
        .history-table td,
        .games-table td {
            padding: 1rem;
            border-bottom: 1px solid #eee;
            color: #333;
        }
        
        .history-table tbody tr:hover,
        .games-table tbody tr:hover {
            background: rgba(106, 17, 203, 0.05);
            transform: scale(1.01);
            transition: all 0.2s ease;
        }
        
        .xp-positive {
            color: #28a745;
            font-weight: 700;
        }
        
        .xp-negative {
            color: #dc3545;
            font-weight: 700;
        }
        
        .xp-neutral {
            color: #6c757d;
            font-weight: 700;
        }
        
        /* دکمه‌های عملیات */
        .action-buttons {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            margin-top: 2.5rem;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 1.2rem 2.5rem;
            border: none;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.8rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .btn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.2);
            transition: left 0.5s ease;
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #4ecdc4, #44a08d);
            color: white;
        }
        
        .btn-info {
            background: linear-gradient(135deg, #ffd700, #ffed4e);
            color: #333;
        }
        
        .btn-analysis {
            background: linear-gradient(135deg, #f093fb, #f5576c);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }
        
        .section-title {
            font-size: 1.8rem;
            font-weight: 800;
            color: #333;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            position: relative;
            z-index: 1;
        }
        
        .section-title::after {
            content: "";
            flex-grow: 1;
            height: 3px;
            background: linear-gradient(90deg, #6a11cb, transparent);
            border-radius: 3px;
            margin-right: 1rem;
        }
        
        /* تب‌ها */
        .tab-buttons {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            background: #f8f9fa;
            padding: 0.5rem;
            border-radius: 15px;
        }
        
        .tab-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            background: transparent;
            color: #666;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        
        .tab-btn.active {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            box-shadow: 0 5px 15px rgba(106, 17, 203, 0.3);
        }
        
        .tab-content {
            display: none;
            animation: fadeIn 0.5s ease;
        }
        
        .tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* ریسپانسیو */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .subjects-grid {
                grid-template-columns: 1fr;
            }
            
            .rank-info {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
            
            .history-table,
            .games-table {
                font-size: 0.9rem;
            }
            
            .history-table th,
            .history-table td,
            .games-table th,
            .games-table td {
                padding: 0.5rem;
            }
            
            .tab-buttons {
                flex-wrap: wrap;
            }
            
            .tab-btn {
                flex: 1;
                min-width: 120px;
            }
            
            .profile-name {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
        }
        
        /* استایل‌های پرینت */
        @media print {
            body {
                background: white !important;
                color: black !important;
                font-family: 'Times New Roman', serif !important;
                font-size: 12pt !important;
                line-height: 1.4 !important;
                margin: 0 !important;
                padding: 20px !important;
            }
            
            .profile-container {
                max-width: none !important;
                margin: 0 !important;
                box-shadow: none !important;
            }
            
            .profile-header,
            .subjects-section,
            .xp-history-section,
            .games-section,
            .stat-card {
                background: white !important;
                border: 2px solid black !important;
                border-radius: 0 !important;
                box-shadow: none !important;
                margin: 15px 0 !important;
                page-break-inside: avoid;
            }
            
            .profile-avatar {
                border: 2px solid black !important;
                background: white !important;
                color: black !important;
            }
            
            .profile-avatar::after {
                display: none !important;
            }
            
            .stats-grid {
                display: grid !important;
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 10px !important;
                page-break-inside: avoid;
            }
            
            .subjects-grid {
                display: grid !important;
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 10px !important;
                page-break-inside: avoid;
            }
            
            .subject-card {
                background: white !important;
                color: black !important;
                border: 2px solid black !important;
                border-radius: 0 !important;
                text-align: center !important;
            }
            
            .rank-info {
                display: grid !important;
                grid-template-columns: repeat(4, 1fr) !important;
                gap: 10px !important;
                border: 2px solid black !important;
                padding: 10px !important;
                background: #f0f0f0 !important;
            }
            
            .rank-card {
                background: white !important;
                border: 1px solid black !important;
                padding: 10px !important;
                text-align: center !important;
            }
            
            .history-table,
            .games-table {
                width: 100% !important;
                border-collapse: collapse !important;
                border: 2px solid black !important;
                font-size: 10pt !important;
            }
            
            .history-table th,
            .history-table td,
            .games-table th,
            .games-table td {
                border: 1px solid black !important;
                padding: 5px !important;
                text-align: center !important;
                background: white !important;
                color: black !important;
            }
            
            .history-table th,
            .games-table th {
                background: #e0e0e0 !important;
                font-weight: bold !important;
            }
            
            .section-title {
                background: #d0d0d0 !important;
                color: black !important;
                border: 2px solid black !important;
                padding: 10px !important;
                text-align: center !important;
                font-weight: bold !important;
                font-size: 14pt !important;
                margin: 20px 0 10px 0 !important;
            }
            
            .action-buttons {
                display: none !important;
            }
            
            .xp-positive {
                color: black !important;
                font-weight: bold !important;
            }
            
            .xp-negative {
                color: black !important;
                font-weight: bold !important;
            }
            
            .xp-neutral {
                color: black !important;
                font-weight: bold !important;
            }
            
            /* شکستن صفحه */
            .page-break {
                page-break-before: always;
            }
            
            .no-break {
                page-break-inside: avoid;
            }
            
            /* هدر پرینت */
            .print-header {
                display: block !important;
                text-align: center !important;
                border-bottom: 3px solid black !important;
                padding-bottom: 15px !important;
                margin-bottom: 20px !important;
            }
            
            .print-date {
                display: block !important;
                text-align: left !important;
                font-size: 10pt !important;
                margin-top: 10px !important;
            }
        }
        
        /* هدر پرینت - مخفی در نمایش عادی */
        .print-header {
            display: none;
        }
        
        .print-date {
            display: none;
        }
        
        /* استایل‌های اضافی برای جذابیت بیشتر */
        .sparkle {
            position: absolute;
            width: 5px;
            height: 5px;
            background: white;
            border-radius: 50%;
            box-shadow: 0 0 10px 2px rgba(255, 255, 255, 0.8);
            animation: sparkle 3s linear infinite;
            opacity: 0;
        }
        
        @keyframes sparkle {
            0% { opacity: 0; transform: scale(0); }
            50% { opacity: 1; transform: scale(1); }
            100% { opacity: 0; transform: scale(0); }
        }
        
        .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #f0f;
            opacity: 0.7;
            animation: confetti-fall 3s linear infinite;
        }
        
        @keyframes confetti-fall {
            0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
        
        .achievement-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #ffd700, #ffed4e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
            animation: bounce 2s infinite;
        }
        
        .progress-ring {
            transform: rotate(-90deg);
        }
        
        .progress-ring-circle {
            transition: stroke-dashoffset 0.35s;
            stroke: #6a11cb;
            stroke-width: 4;
            fill: transparent;
        }
        
        .progress-ring-bg {
            stroke: #eee;
            stroke-width: 4;
            fill: transparent;
        }
        
        .floating-shapes {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }
        
        .shape {
            position: absolute;
            opacity: 0.1;
            animation: float-shape 20s infinite linear;
        }
        
        @keyframes float-shape {
            0% { transform: translateY(100vh) rotate(0deg); }
            100% { transform: translateY(-100vh) rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- اشکال شناور در پس‌زمینه -->
    <div class="floating-shapes">
        <div class="shape" style="width: 80px; height: 80px; background: #ff6b6b; border-radius: 50%; left: 10%; animation-delay: 0s; animation-duration: 15s;"></div>
        <div class="shape" style="width: 60px; height: 60px; background: #4ecdc4; border-radius: 30%; left: 20%; animation-delay: 2s; animation-duration: 18s;"></div>
        <div class="shape" style="width: 100px; height: 100px; background: #667eea; border-radius: 20%; left: 35%; animation-delay: 4s; animation-duration: 20s;"></div>
        <div class="shape" style="width: 40px; height: 40px; background: #f093fb; border-radius: 50%; left: 50%; animation-delay: 1s; animation-duration: 12s;"></div>
        <div class="shape" style="width: 70px; height: 70px; background: #4facfe; border-radius: 40%; left: 65%; animation-delay: 3s; animation-duration: 17s;"></div>
        <div class="shape" style="width: 90px; height: 90px; background: #ffd700; border-radius: 30%; left: 80%; animation-delay: 5s; animation-duration: 19s;"></div>
        <div class="shape" style="width: 50px; height: 50px; background: #ff8e53; border-radius: 50%; left: 90%; animation-delay: 2.5s; animation-duration: 14s;"></div>
    </div>
    
    <div class="profile-container">
        <!-- هدر مخصوص پرینت -->
        <div class="print-header">
            <h1>🎓 گزارش پیشرفت تحصیلی</h1>
            <h2><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h2>
            <h3>سیستم مدیریت یادگیری</h3>
            <div class="print-date">تاریخ چاپ: <span id="print-date-span"></span></div>
        </div>
        
        <!-- هدر پروفایل -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?php echo mb_substr($student['first_name'], 0, 1) . mb_substr($student['last_name'], 0, 1); ?>
            </div>
            <div class="profile-name"><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></div>
            <div class="profile-details">
                کد ملی: <?php echo convertNumbersToPersian($student['national_id']); ?> | 
                سطح: <?php echo convertNumbersToPersian($student['level']); ?>
            </div>
            <div class="profile-details">
                عضویت از: <?php echo toJalaliDate($student['created_at']); ?>
                <?php if ($student['updated_at']): ?>
                | آخرین بروزرسانی: <?php echo toJalaliDateTime($student['updated_at']); ?>
                <?php endif; ?>
            </div>
            
            <!-- اطلاعات رنک -->
            <div class="rank-info">
                <div class="rank-card">
                    <div class="rank-number"><?php echo convertNumbersToPersian($globalRank); ?></div>
                    <div class="rank-label">رتبه کلی</div>
                </div>
                <div class="rank-card">
                    <div class="rank-number"><?php echo convertNumbersToPersian($classRank); ?></div>
                    <div class="rank-label">رتبه در کلاس</div>
                </div>
                <div class="rank-card">
                    <div class="rank-number"><?php echo convertNumbersToPersian($totalStudents); ?></div>
                    <div class="rank-label">کل دانش‌آموزان</div>
                </div>
                <div class="rank-card">
                    <div class="rank-number"><?php echo formatPersianNumber($monthlyXP); ?></div>
                    <div class="rank-label">XP ماه جاری</div>
                </div>
            </div>
        </div>

        <!-- آمار کلی -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">🏆</div>
                <div class="stat-number"><?php echo formatPersianNumber($student['total_xp']); ?></div>
                <div class="stat-label">کل امتیاز XP</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🎮</div>
                <div class="stat-number"><?php echo convertNumbersToPersian($gameStats['total_games'] ?: 0); ?></div>
                <div class="stat-label">بازی انجام شده</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-number"><?php echo convertNumbersToPersian($gameStats['avg_score'] ? round($gameStats['avg_score']) : 0); ?></div>
                <div class="stat-label">میانگین امتیاز</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🎯</div>
                <div class="stat-number"><?php echo convertNumbersToPersian($gameStats['avg_accuracy'] ? round($gameStats['avg_accuracy']) : 0) . '%'; ?></div>
                <div class="stat-label">درصد میانگین دقت</div>
            </div>
        </div>

        <!-- امتیازات موضوعی -->
        <div class="subjects-section">
            <div class="section-title">
                📚 امتیازات موضوعی
            </div>
            <div class="subjects-grid">
                <div class="subject-card subject-math">
                    <span class="subject-icon">🔢</span>
                    <div class="subject-xp"><?php echo formatPersianNumber($student['math_xp']); ?></div>
                    <div class="subject-name">ریاضی</div>
                </div>
                <div class="subject-card subject-science">
                    <span class="subject-icon">🔬</span>
                    <div class="subject-xp"><?php echo formatPersianNumber($student['science_xp']); ?></div>
                    <div class="subject-name">علوم</div>
                </div>
                <div class="subject-card subject-persian">
                    <span class="subject-icon">📖</span>
                    <div class="subject-xp"><?php echo formatPersianNumber($student['persian_xp']); ?></div>
                    <div class="subject-name">فارسی</div>
                </div>
                <div class="subject-card subject-social">
                    <span class="subject-icon">🌍</span>
                    <div class="subject-xp"><?php echo formatPersianNumber($student['social_xp']); ?></div>
                    <div class="subject-name">اجتماعی</div>
                </div>
                <div class="subject-card subject-religion">
                    <span class="subject-icon">📿</span>
                    <div class="subject-xp"><?php echo formatPersianNumber($student['religion_xp']); ?></div>
                    <div class="subject-name">دینی</div>
                </div>
            </div>
        </div>

        <!-- تب‌ها برای تاریخچه -->
        <div class="xp-history-section">
            <div class="tab-buttons">
                <button class="tab-btn active" onclick="showTab('xp-history')">💎 تاریخچه امتیازات</button>
                <button class="tab-btn" onclick="showTab('games-history')">🎮 تاریخچه بازی‌ها</button>
            </div>
            
            <!-- تب تاریخچه امتیازات -->
            <div id="xp-history" class="tab-content active">
                <?php if (!empty($xpHistory)): ?>
                    <div style="overflow-x: auto;">
                        <table class="history-table">
                            <thead>
                                <tr>
                                    <th>تاریخ</th>
                                    <th>موضوع</th>
                                    <th>تغییر امتیاز</th>
                                    <th>دلیل</th>
                                    <th>توسط</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($xpHistory as $history): 
                                    $subjectNames = [
                                        'total' => 'کل امتیاز',
                                        'math' => 'ریاضی',
                                        'science' => 'علوم',
                                        'persian' => 'فارسی',
                                        'social' => 'اجتماعی',
                                        'religion' => 'دینی',
                                        'level_change' => 'تغییر سطح',
                                        'reset' => 'ریست کامل'
                                    ];
                                    $subjectName = $subjectNames[$history['subject']] ?? $history['subject'];
                                    $amountClass = $history['amount'] > 0 ? 'xp-positive' : ($history['amount'] < 0 ? 'xp-negative' : 'xp-neutral');
                                    $changeText = $history['amount'] > 0 ? '+' . convertNumbersToPersian($history['amount']) : convertNumbersToPersian($history['amount']);
                                ?>
                                <tr>
                                    <td><?php echo toJalaliDateTime($history['created_at']); ?></td>
                                    <td style="font-weight: 600;"><?php echo $subjectName; ?></td>
                                    <td class="<?php echo $amountClass; ?>"><?php echo $changeText; ?></td>
                                    <td><?php echo htmlspecialchars($history['reason'] ?: 'بدون دلیل'); ?></td>
                                    <td style="font-size: 0.9rem;"><?php echo $history['admin_name'] ?: 'سیستم'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 3rem; color: #666;">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">💎</div>
                        <div style="font-size: 1.2rem; font-weight: 600;">هنوز هیچ امتیازی دریافت نکرده‌اید</div>
                        <div style="margin-top: 0.5rem;">با انجام بازی‌ها و فعالیت‌ها، امتیاز کسب کنید!</div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- تب تاریخچه بازی‌ها -->
            <div id="games-history" class="tab-content">
                <?php if (!empty($gameHistory)): ?>
                    <div style="overflow-x: auto;">
                        <table class="games-table">
                            <thead>
                                <tr>
                                    <th>نام بازی</th>
                                    <th>موضوع</th>
                                    <th>امتیاز</th>
                                    <th>دقت</th>
                                    <th>زمان</th>
                                    <th>تاریخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($gameHistory as $game): ?>
                                <tr>
                                    <td style="font-weight: 600;"><?php echo htmlspecialchars($game['game_title']); ?></td>
                                    <td>
                                        <?php
                                        $subjects = [
                                            'math' => '🔢 ریاضی',
                                            'science' => '🔬 علوم',
                                            'persian' => '📖 فارسی',
                                            'social' => '🌍 اجتماعی',
                                            'religion' => '📿 دینی'
                                        ];
                                        echo $subjects[$game['subject']] ?? $game['subject'];
                                        ?>
                                    </td>
                                    <td style="font-weight: 700; color: #28a745;"><?php echo convertNumbersToPersian($game['score']); ?></td>
                                    <td style="color: #17a2b8;"><?php echo convertNumbersToPersian(round($game['accuracy'])) . '%'; ?></td>
                                    <td style="color: #6c757d;"><?php echo convertNumbersToPersian(round($game['time_spent'])) . 's'; ?></td>
                                    <td style="font-size: 0.9rem;"><?php echo toJalaliDateTime($game['completed_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 3rem; color: #666;">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">🎯</div>
                        <div style="font-size: 1.2rem; font-weight: 600;">هنوز هیچ بازی انجام نداده‌اید</div>
                        <div style="margin-top: 0.5rem;">برای شروع، روی دکمه "شروع بازی" کلیک کنید</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="action-buttons">
    <a href="student_analysis.php" class="btn btn-analysis">
        <i class="fas fa-chart-line"></i>
        تحلیل امتیازات
    </a>

    <!-- دکمه جدید: تحلیل آزمون‌ها -->
    <a href="/sections/exams/student_report.php" class="btn btn-analysis">
        <i class="fas fa-chart-pie"></i>
        تحلیل آزمون‌ها
    </a>

    <button onclick="printReport()" class="btn btn-success">
        <i class="fas fa-print"></i>
        پرینت گزارش
    </button>
    <a href="../index.php" class="btn btn-primary">
        <i class="fas fa-gamepad"></i>
        شروع بازی
    </a>
    <a href="../index.php" class="btn btn-info">
        <i class="fas fa-home"></i>
        صفحه اصلی
    </a>
</div>

    
    <script>
        // انیمیشن‌های تعاملی
        document.addEventListener('DOMContentLoaded', function() {
            // ایجاد برق‌های کوچک در پس‌زمینه
            createSparkles();
            
            // اثر hover برای کارت‌های آمار
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-10px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
            
            // اثر hover برای کارت‌های موضوعی
            const subjectCards = document.querySelectorAll('.subject-card');
            subjectCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-10px) scale(1.05)';
                    this.style.boxShadow = '0 20px 40px rgba(0,0,0,0.2)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                    this.style.boxShadow = '0 10px 25px rgba(0,0,0,0.1)';
                });
            });
            
            // اثر hover برای کارت‌های رنک
            const rankCards = document.querySelectorAll('.rank-card');
            rankCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px)';
                    this.style.boxShadow = '0 10px 25px rgba(102,126,234,0.3)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                    this.style.boxShadow = '0 5px 15px rgba(0,0,0,0.05)';
                });
            });
            
            // هایلایت کردن سطرهای جدول هنگام hover
            const tableRows = document.querySelectorAll('.history-table tbody tr, .games-table tbody tr');
            tableRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.backgroundColor = 'rgba(106, 17, 203, 0.05)';
                    this.style.transform = 'scale(1.01)';
                    this.style.transition = 'all 0.2s ease';
                });
                
                row.addEventListener('mouseleave', function() {
                    this.style.backgroundColor = '';
                    this.style.transform = 'scale(1)';
                });
            });
            
            console.log('Student profile loaded successfully');
            console.log('Student ID: <?php echo $studentId; ?>');
            console.log('Total XP: <?php echo $student['total_xp']; ?>');
            console.log('Global Rank: <?php echo $globalRank; ?>');
        });
        
        // تابع ایجاد برق‌های کوچک
        function createSparkles() {
            const container = document.querySelector('.profile-container');
            
            for (let i = 0; i < 20; i++) {
                setTimeout(() => {
                    const sparkle = document.createElement('div');
                    sparkle.className = 'sparkle';
                    sparkle.style.left = Math.random() * 100 + '%';
                    sparkle.style.top = Math.random() * 100 + '%';
                    sparkle.style.animationDelay = Math.random() * 3 + 's';
                    container.appendChild(sparkle);
                    
                    setTimeout(() => {
                        if (sparkle.parentNode) {
                            sparkle.parentNode.removeChild(sparkle);
                        }
                    }, 3000);
                }, i * 200);
            }
            
            // تکرار فرآیند
            setTimeout(createSparkles, 10000);
        }
        
        // تابع نمایش تب‌ها
        function showTab(tabId) {
            // مخفی کردن همه تب‌ها
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(content => {
                content.classList.remove('active');
            });
            
            // غیرفعال کردن همه دکمه‌های تب
            const tabButtons = document.querySelectorAll('.tab-btn');
            tabButtons.forEach(button => {
                button.classList.remove('active');
            });
            
            // نمایش تب مورد نظر
            document.getElementById(tabId).classList.add('active');
            
            // فعال کردن دکمه تب مورد نظر
            event.target.classList.add('active');
        }
        
        // تابع پرینت گزارش
        function printReport() {
            // اضافه کردن هدر پرینت
            const printHeader = document.createElement('div');
            printHeader.className = 'print-header';
            printHeader.innerHTML = `
                <h1>🎓 گزارش پیشرفت تحصیلی</h1>
                <h2><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></h2>
                <h3>سیستم مدیریت یادگیری</h3>
                <div class="print-date">تاریخ چاپ: ${new Date().toLocaleDateString('fa-IR')} - ${new Date().toLocaleTimeString('fa-IR')}</div>
            `;
            
            // اضافه کردن هدر به ابتدای صفحه
            const container = document.querySelector('.profile-container');
            container.insertBefore(printHeader, container.firstChild);
            
            // اضافه کردن کلاس page-break برای بخش‌های مختلف
            const sections = document.querySelectorAll('.subjects-section, .xp-history-section');
            sections.forEach((section, index) => {
                if (index === 1) { // بخش دوم در صفحه جدید
                    section.classList.add('page-break');
                }
                section.classList.add('no-break');
            });
            
            // نمایش پیغام آماده‌سازی
            showNotification('در حال آماده‌سازی برای چاپ...', 'info');
            
            // تاخیر کوتاه برای اعمال تغییرات CSS
            setTimeout(() => {
                // باز کردن دیالوگ پرینت
                window.print();
                
                // حذف هدر پرینت پس از چاپ
                setTimeout(() => {
                    if (printHeader.parentNode) {
                        printHeader.parentNode.removeChild(printHeader);
                    }
                    
                    // حذف کلاس‌های page-break
                    sections.forEach(section => {
                        section.classList.remove('page-break', 'no-break');
                    });
                    
                    showNotification('گزارش آماده چاپ است!', 'success');
                }, 1000);
            }, 500);
        }
        
        // تابع نمایش اعلان
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 10px;
                color: white;
                font-weight: 600;
                z-index: 10000;
                animation: slideIn 0.3s ease;
                min-width: 300px;
                text-align: center;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
                    notification.textContent = '✅ ' + message;
                    break;
                case 'error':
                    notification.style.background = 'linear-gradient(135deg, #dc3545, #c82333)';
                    notification.textContent = '❌ ' + message;
                    break;
                default:
                    notification.style.background = 'linear-gradient(135deg, #17a2b8, #138496)';
                    notification.textContent = 'ℹ️ ' + message;
            }
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        }
        
        // رویداد پس از بسته شدن دیالوگ پرینت
        window.addEventListener('afterprint', function() {
            showNotification('چاپ تکمیل شد', 'success');
        });
        
        // رویداد قبل از باز شدن دیالوگ پرینت
        window.addEventListener('beforeprint', function() {
            console.log('شروع فرآیند چاپ...');
        });
        
        // کلید میانبر برای پرینت (Ctrl+P)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                printReport();
            }
        });
        
        console.log('✅ All profile features loaded successfully');
    </script>
</body>
</html>