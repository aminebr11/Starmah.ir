<?php
/* =============================================================
 * classNotebook_admin.php - Enhanced Admin panel for class notebook
 * Fully integrated with main site theme and navigation (matching library.php)
 * With XP System Integration + غایب در توصیفی + تقویم حرفه‌ای
 * ============================================================= */

// Session check
if (session_status() === PHP_SESSION_NONE) { @session_start(); }
require_once '../config.php';
 $db = $conn;

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

 $isLoggedIn = isset($_SESSION['user_id']);
 $userType = $_SESSION['user_type'] ?? '';
 $userName = $_SESSION['user_name'] ?? 'کاربر';

// Persian months for Shamsi calendar
 $persianMonths = [
    1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد', 4 => 'تیر',
    5 => 'مرداد', 6 => 'شهریور', 7 => 'مهر', 8 => 'آبان',
    9 => 'آذر', 10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
];

// Get subjects and topics functions
function getSubjects($db) {
    try {
        $stmt = $db->prepare("SELECT setting_value FROM class_settings WHERE setting_type = 'subject' AND is_active = 1");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return ['ریاضی', 'فارسی', 'علوم', 'مطالعات اجتماعی', 'انگلیسی'];
    }
}

function getTopics($db) {
    try {
        $stmt = $db->prepare("SELECT setting_value FROM class_settings WHERE setting_type = 'topic' AND is_active = 1");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return ['فصل اول', 'فصل دوم', 'فصل سوم', 'تمرین کلاسی', 'آزمون', 'تکلیف منزل'];
    }
}

// تبدیل اعداد فارسی به انگلیسی
function fa2en_str($s){
    return strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
}

// تبدیل جلالی به میلادی و برگرداندن Y-m-d
function jalali_to_gregorian_ymd($jy,$jm,$jd){
    $gy = ($jy<=979) ? 621 : 1600;
    $jy = ($jy<=979) ? $jy : $jy-979;
    $days = 365*$jy + intdiv($jy,33)*8 + intdiv(($jy%33)+3,4) + $jd + (($jm<7)?($jm-1)*31:(($jm-7)*30+186)) + 79;
    $gy+=400*intdiv($days,146097); $days %= 146097;
    if ($days >= 36525){
        $days--;
        $gy += 100*intdiv($days,36524); $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4*intdiv($days,1461); $days %= 1461;
    if ($days >= 366){
        $days--;
        $gy += intdiv($days,365); $days %= 365;
    }
    $gd = $days + 1;
    $sal_a = [31, (($gy%4==0 && $gy%100!=0) || $gy%400==0) ? 29 : 28, 31,30,31,30,31,31,30,31,30,31];
    $gm = 0;
    while ($gm<12 && $gd>$sal_a[$gm]) { $gd -= $sal_a[$gm]; $gm++; }
    $gm++;
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function getStudents($db) {
    try {
        $stmt = $db->prepare("SELECT id, first_name, last_name, username FROM users WHERE user_type = 'student' AND is_active = 1 ORDER BY last_name, first_name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

// XP System Functions
function calculateNumericXP($score, $maxScore = 20) {
    return round(($score / $maxScore) * 100);
}

function calculateDescriptiveXP($grade) {
    $xpMap = [
        'خیلی خوب' => 100,
        'خوب' => 75,
        'قابل قبول' => 50,
        'نیاز به تلاش' => 25,
        'غایب' => -25
    ];
    return $xpMap[$grade] ?? 0;
}

function calculateHomeworkXP($status) {
    $xpMap = [
        'کامل' => 50,
        'ناقص' => 25,
        'انجام نداده' => -15,
        'غایب' =>-25
    ];
    return $xpMap[$status] ?? 0;
}

function getSubjectXPField($lesson) {
    $lesson = trim($lesson);
    
    $subjectMapping = [
        'ریاضی' => 'math_xp',
        'علوم' => 'science_xp',
        'علوم تجربی' => 'science_xp',
        'فارسی' => 'persian_xp',
        'زبان فارسی' => 'persian_xp',
        'مطالعات اجتماعی' => 'social_xp',
        'مطالعات' => 'social_xp',
        'دین' => 'religion_xp',
        'دینی' => 'religion_xp',
        'قرآن' => 'religion_xp',
         'تکلیف روز' => 'other_xp',
          'آزمون جامع' => 'other_xp',
        'هدیه های آسمانی' => 'religion_xp',
        'هدیه‌های آسمانی' => 'religion_xp'
    ];
    
    return $subjectMapping[$lesson] ?? null;
}

function updateStudentXP($db, $student_id, $lesson, $xp_amount, $reason, $admin_id = null) {
    try {
        if ($admin_id === null && isset($_SESSION['user_id'])) {
            $admin_id = $_SESSION['user_id'];
        }
        
        $checkStmt = $db->prepare("SELECT id FROM student_xp WHERE student_id = ?");
        $checkStmt->execute([$student_id]);
        
        if (!$checkStmt->fetch()) {
            $insertStmt = $db->prepare("
                INSERT INTO student_xp 
                (student_id, math_xp, science_xp, persian_xp, social_xp, religion_xp, podcast_xp, dic_xp , other_xp) 
                VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0)
            ");
            
            if (!$insertStmt->execute([$student_id])) {
                error_log("Failed to insert student_xp: " . print_r($insertStmt->errorInfo(), true));
                return false;
            }
        }
        
        $xpField = getSubjectXPField($lesson);
        
        if ($xpField) {
            $updateStmt = $db->prepare("
                UPDATE student_xp 
                SET {$xpField} = {$xpField} + ?
                WHERE student_id = ?
            ");
            
            if (!$updateStmt->execute([$xp_amount, $student_id])) {
                error_log("Failed to update {$xpField}: " . print_r($updateStmt->errorInfo(), true));
                return false;
            }
        } else {
            error_log("Unknown lesson: " . $lesson);
            return false;
        }
        
        $historyStmt = $db->prepare("
            INSERT INTO xp_history 
            (student_id, game_result_id, subject, amount, reason, admin_id, created_at) 
            VALUES (?, NULL, ?, ?, ?, ?, NOW())
        ");
        
        if (!$historyStmt->execute([$student_id, $lesson, $xp_amount, $reason, $admin_id])) {
            error_log("Failed to insert xp_history: " . print_r($historyStmt->errorInfo(), true));
            return false;
        }
        
        return true;
        
    } catch (PDOException $e) {
        error_log("PDO Error in updateStudentXP: " . $e->getMessage());
        return false;
    } catch (Exception $e) {
        error_log("General Error in updateStudentXP: " . $e->getMessage());
        return false;
    }
}

 $subjects = getSubjects($db);
 $topics = getTopics($db);
 $students = getStudents($db);

// Handle form submission
if ($_POST['action'] ?? '' === 'add_activity') {
    try {
        $title = $_POST['title'];
        $maxScoreFromForm = $_POST['grade_max'] ?? 20;
        if ($_POST['score_type'] === 'numeric') {
            if ($maxScoreFromForm != 20) {
                $title .= " (از $maxScoreFromForm نمره)";
            }
        }
        
        $raw_jalali = $_POST['activity_date'] ?? '';
        $raw_jalali = fa2en_str(trim($raw_jalali));
        $raw_greg   = $_POST['activity_date_gregorian'] ?? '';
        $raw_greg   = trim($raw_greg);

        $date_for_db = null;

        if ($raw_greg && preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw_greg)) {
            $date_for_db = $raw_greg;
        } else if (preg_match('/^\d{4}\/\d{2}\/\d{2}$/', $raw_jalali)) {
            $jy = (int)substr($raw_jalali,0,4);
            $jm = (int)substr($raw_jalali,5,2);
            $jd = (int)substr($raw_jalali,8,2);
            $date_for_db = jalali_to_gregorian_ymd($jy,$jm,$jd);
        } else {
            throw new Exception('تاریخ نامعتبر است. لطفاً تاریخ را صحیح وارد کنید.');
        }

        $activity_data = [
            'date'       => $date_for_db,
            'lesson'     => $_POST['lesson'],
            'topic'      => $_POST['topic'],
            'score_type' => $_POST['score_type'],
            'title'      => $title
        ];

        $stmt = $db->prepare("INSERT INTO activities (date, lesson, topic, score_type, title) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$activity_data['date'], $activity_data['lesson'], $activity_data['topic'], $activity_data['score_type'], $activity_data['title']]);

        $activity_id = $db->lastInsertId();
        
        if (isset($_POST['student_results']) && is_array($_POST['student_results'])) {
            $stmt = $db->prepare("INSERT INTO activity_results (activity_id, student_id, score, status, feedback) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($_POST['student_results'] as $student_id => $result) {
                if (!empty($result['score']) || !empty($result['feedback'])) {
                    // *** شروع تغییر شماره 1: ذخیره نمره خام ***
                    // نمره دقیقا همانطور که وارد شده ذخیره می‌شود، بدون تبدیل.
                    $scoreToSave = $result['score'];
                    // *** پایان تغییر شماره 1 ***
                    
                    $stmt->execute([
                        $activity_id,
                        $student_id,
                        $scoreToSave,
                        'submitted',
                        $result['feedback'] ?? ''
                    ]);
                    
                    $xp = 0;
                    $scoreType = $_POST['score_type'];
                    $lesson = $_POST['lesson'];
                    
                    if ($scoreType === 'numeric' && !empty($result['score'])) {
                        // محاسبه XP بر اساس نمره وارد شده و حداکثر نمره تنظیم شده
                        $xp = calculateNumericXP($result['score'], $maxScoreFromForm);
                        $reason = "نمره کلاسی درس {$lesson} - نمره: {$result['score']} از {$maxScoreFromForm}";
                    } elseif ($scoreType === 'descriptive' && !empty($result['score'])) {
                        $xp = calculateDescriptiveXP($result['score']);
                        $reason = "نمره کلاسی درس {$lesson} - ارزیابی: {$result['score']}";
                    } elseif ($scoreType === 'homework' && !empty($result['score'])) {
                        $xp = calculateHomeworkXP($result['score']);
                        $reason = "تکلیف درس {$lesson} - وضعیت: {$result['score']}";
                    }
                    
                    if ($xp != 0)  {
                        updateStudentXP($db, $student_id, $lesson, $xp, $reason);
                    }
                }
            }
        }
        
        $success_message = "فعالیت با موفقیت ثبت شد و XP دانش‌آموزان بروزرسانی گردید.";
    } catch (Exception $e) {
        $error_message = "خطا در ثبت فعالیت: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>📓 دفتر کلاسی - پنل معلم - ستاره ماه</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/style.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css">
<style>
.exam-builder-container {
  max-width:1400px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.exam-subnav {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  margin: 1rem 0 2rem 0;
  padding: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.exam-subnav-links {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.exam-subnav-link {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  padding: 0.8rem 1.5rem;
  border-radius: 15px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 0.95rem;
}

.exam-subnav-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  color: white;
}

.exam-subnav-link.active {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border-color: transparent;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.exam-card {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
}

.exam-card-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: linear-gradient(135deg, #83eaf1, #63a4ff);
  color: #0b1220;
  padding: 1rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
}

.exam-step-number {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 800;
  font-size: 0.9rem;
}

.exam-card-title {
  flex: 1;
}

.exam-card-title h2 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 800;
}

.exam-card-title p {
  margin: 0.3rem 0 0 0;
  opacity: 0.9;
  font-size: 0.9rem;
}

.exam-badge {
  background: rgba(255,255,255,.7);
  padding: 0.5rem 0.8rem;
  border-radius: 50px;
  font-weight: 700;
  font-size: 0.85rem;
}

.exam-btn {
  border: none;
  border-radius: 12px;
  padding: 0.8rem 1.5rem;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
  font-family: 'Tahoma', tahoma, sans-serif;
}

.exam-btn-primary {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.exam-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(107, 207, 127, 0.6);
}

.exam-btn-soft {
  background-color: #e0f0ff;
  color: #0056b3;
  border: 1px solid #b3d7ff;
  border-radius: .4rem;
  padding: .3rem .6rem;
  cursor: pointer;
  transition: all .2s ease;
}

.exam-btn-soft:hover {
  background-color: #cce4ff;
}

.exam-btn-soft.active {
  background-color: #28a745;
  color: #fff;
  border-color: #1a7ed9;
}

.exam-btn-danger {
  background: rgba(244,63,94,.15);
  color: #fecaca;
  border: 1px solid rgba(244,63,94,.3);
}

:root{ 
  --primary:#667eea; --primary-dark:#5a67d8; --accent:#764ba2;
  --bg:#f5f7fb; --card:#ffffff; --border:#e2e8f0; --text:#1a202c;
  --muted:#718096;
}

body{
  font-family:'Tahoma', tahoma, sans-serif;
  background:linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
  min-height:100vh
}

.table {
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.btn, .btn-primary, .btn-danger, .btn-secondary, .btn-success{
  font-family:'Tahoma', tahoma, sans-serif !important;
  border-radius:12px
}

.table thead th{
  font-weight:700;
  background: rgba(255, 255, 255, 0.1);
  color: rgba(0, 0, 0, 0.8);
}

textarea,
input[type="text"],
input[type="number"],
input[type="date"],
input[type="time"],
select {
  font-family: 'Tahoma', tahoma, sans-serif !important;
  color: #000000 !important;
  background: rgba(255, 255, 255, 0.9) !important;
  border: 1px solid rgba(0, 0, 0, 0.2) !important;
  border-radius: 8px !important;
  padding: 0.5rem !important;
}

textarea:focus,
input:focus,
select:focus {
  border-color: #6bcf7f !important;
  outline: none !important;
  box-shadow: 0 0 10px rgba(107, 207, 127, 0.3) !important;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: rgba(255, 255, 255, 0.9);
  font-weight: 600;
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.grade-range-container {
  background: rgba(255, 255, 255, 0.1);
  max-width: 220px;
  border-radius: 10px;
  padding: 1rem;
  margin-bottom: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.grade-range-inputs {
  display: flex;
  align-items: center;
  gap: 1rem;
  color: rgba(255, 255, 255, 0.9);
}

.grade-range-inputs input {
  width: 80px;
  text-align: center;
  font-weight: bold;
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.students-section {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 15px;
  padding: 1.5rem;
  margin-top: 2rem;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.section-header h3 {
  color: #333;
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.search-box {
  padding: 0.8rem;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  min-width: 250px;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  background: white;
  color: #333;
}

.students-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
}

.students-table th {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  padding: 0.8rem 0.5rem;
  text-align: right;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  font-size: 0.9rem;
}

.students-table th:first-child {
  border-radius: 10px 0 0 0;
  width: 50px;
}

.students-table th:last-child {
  border-radius: 0 10px 0 0;
}

.students-table td {
  padding: 0.5rem;
  border-bottom: 1px solid #eee;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  vertical-align: top;
  color: #000000 !important;
}

.students-table tr:hover {
  background: #f8f9fa;
}

.grade-btn {
  padding: 0.3rem 0.6rem;
  margin: 0.1rem;
  border: 2px solid #ddd;
  border-radius: 15px;
  background: white;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  font-size: 0.75rem;
  white-space: nowrap;
}

.grade-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.grade-btn.selected {
  background: #6bcf7f;
  color: white;
  border-color: #6bcf7f;
}

.numeric-input {
  width: 70px;
  padding: 0.4rem;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  text-align: center;
  font-weight: bold;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  background: white;
  color: #333;
}

.feedback-input {
  width: 100%;
  min-height: 40px;
  padding: 0.4rem;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  resize: vertical;
  font-family: 'Tahoma', tahoma, sans-serif !important;
  font-size: 0.85rem;
  background: white;
  color: #333;
}

.fade-in {
  animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.alert {
  padding: 1rem;
  border-radius: 15px;
  margin: 1rem auto;
  max-width: 1200px;
  font-family: 'Tahoma', tahoma, sans-serif !important;
}

.alert-success {
  background: rgba(107, 207, 127, 0.15);
  color: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(107, 207, 127, 0.3);
}

.alert-error {
  background: rgba(244, 63, 94, 0.15);
  color: #fecaca;
  border: 1px solid rgba(244, 63, 94, 0.3);
}

/* تقویم حرفه‌ای */
.date-picker-wrapper {
  position: relative;
  width: 100%;
}

.date-input-container {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.date-input-with-icon {
  position: relative;
  flex: 1;
}

.date-input-with-icon input {
  width: 100%;
  padding-right: 2.5rem !important;
}

.calendar-icon {
  position: absolute;
  right: 0.8rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 1.2rem;
  pointer-events: none;
  color: #6bcf7f;
}

.today-btn {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border: none;
  padding: 0.6rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  white-space: nowrap;
  transition: all 0.3s ease;
}

.today-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(107, 207, 127, 0.4);
}

.calendar-popup {
  position: fixed;
  top: 40%;
  left: 35%;
  transform: translate(-50%, -50%);
  background: white;
  border: 2px solid #6bcf7f;
  border-radius: 15px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  z-index: 999999;
  padding: 1.5rem;
  min-width: 320px;
  display: none;
  pointer-events: auto; /* اضافه کردن این خط */
}

.calendar-popup.show {
  display: block;
  animation: slideDown 0.3s ease;
}

.calendar-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999998;
  display: none;
  pointer-events: none; /* اضافه کردن این خط */
}

.calendar-overlay.show {
  display: block;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.calendar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid #e0e0e0;
}

.calendar-nav {
  display: flex;
  gap: 0.5rem;
}

.calendar-nav-btn {
  background: #6bcf7f;
  color: white;
  border: none;
  width: 35px;
  height: 35px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 1.2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
}

.calendar-nav-btn:hover {
  background: #5bb36a;
  transform: scale(1.1);
}

.calendar-title {
  font-weight: 700;
  color: #333;
  font-size: 1.1rem;
}

.calendar-selects {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.calendar-selects select {
  flex: 1;
  padding: 0.5rem;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-family: 'Tahoma', tahoma, sans-serif;
  color: #333;
  background: white;
  cursor: pointer;
}

.calendar-selects select:focus {
  border-color: #6bcf7f;
  outline: none;
}

.calendar-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 0.3rem;
}

.calendar-day-header {
  text-align: center;
  font-weight: 700;
  color: #666;
  padding: 0.5rem;
  font-size: 0.85rem;
}

.calendar-day {
  aspect-ratio: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-weight: 600;
  color: #333;
  background: #f5f5f5;
}

.calendar-day:hover {
  background: #e0f7e6;
  transform: scale(1.1);
}

.calendar-day.today {
  background: linear-gradient(135deg, #83eaf1, #63a4ff);
  color: white;
  font-weight: 700;
}

.calendar-day.selected {
  background: #6bcf7f;
  color: white;
  font-weight: 700;
}

.calendar-day.disabled {
  opacity: 0.3;
  cursor: not-allowed;
  pointer-events: none;
}

.calendar-day.other-month {
  opacity: 0.4;
}

.calendar-footer {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 2px solid #e0e0e0;
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
}

.calendar-footer-btn {
  flex: 1;
  padding: 0.6rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-family: 'Tahoma', tahoma, sans-serif;
  transition: all 0.2s ease;
}

.calendar-footer-btn.confirm {
  background: #6bcf7f;
  color: white;
}

.calendar-footer-btn.confirm:hover {
  background: #5bb36a;
}

.calendar-footer-btn.cancel {
  background: #f44336;
  color: white;
}

.calendar-footer-btn.cancel:hover {
  background: #d32f2f;
}

.date-help-text {
  display: block;
  margin-top: 0.5rem;
  color: rgba(255, 255, 255, 0.8);
  font-size: 0.85rem;
}

/* استایل برای تب‌ها */
.tab-container {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border-radius: 20px;
  margin: 1rem 0 2rem 0;
  padding: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.tab-nav {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 1.5rem;
}

.tab-btn {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.9);
  padding: 0.8rem 1.5rem;
  border-radius: 15px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 0.95rem;
  cursor: pointer;
}

.tab-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  color: white;
}

.tab-btn.active {
  background: linear-gradient(135deg, #6bcf7f, #4d9de0);
  color: white;
  border-color: transparent;
  box-shadow: 0 5px 20px rgba(107, 207, 127, 0.4);
}

.tab-content {
  display: none;
}

.tab-content.active {
  display: block;
  animation: fadeIn 0.5s ease-in;
}

/* استایل برای نمایش نمرات */
.grade-display {
  font-weight: bold;
  padding: 0.3rem 0.6rem;
  border-radius: 8px;
  text-align: center;
}

.grade-excellent {
  background-color: #d4edda;
  color: #155724;
}

.grade-good {
  background-color: #cce5ff;
  color: #004085;
}

.grade-acceptable {
  background-color: #fff3cd;
  color: #856404;
}

.grade-needs-improvement {
  background-color: #f8d7da;
  color: #721c24;
}

.grade-absent {
  background-color: #e2e3e5;
  color: #383d41;
}

/* استایل برای iframe */
.manager-iframe {
    width: 100%;
    height: 800px; /* ارتفاع مناسب برای iframe */
    border: none;
    border-radius: 15px;
    background: white;
}

@media (max-width: 768px){
  .exam-builder-container {
    margin: 1rem auto;
    padding: 0 0.5rem;
  }
  
  .exam-card{
    border-radius:16px;
    padding: 1rem;
  }
  
  .btn{
    padding:.4rem .75rem
  }
  
  .table{
    font-size:.8rem
  }
  
  .exam-subnav {
    margin: 0.5rem 0 1rem 0;
    padding: 0.8rem;
  }
  
  .exam-subnav-link {
    padding: 0.6rem 1rem;
    font-size: 0.9rem;
  }
  
  .form-grid {
    grid-template-columns: 1fr;
  }
  
  .students-table {
    font-size: 0.75rem;
  }
  
  .students-table th,
  .students-table td {
    padding: 0.3rem;
  }
  
  .numeric-input {
    width: 50px;
  }
  
  .grade-btn {
    font-size: 0.7rem;
    padding: 0.2rem 0.4rem;
  }
  
  .tab-nav {
    flex-direction: column;
    align-items: center;
  }
  
  .tab-btn {
    width: 100%;
    max-width: 300px;
    text-align: center;
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .search-box {
    width: 100%;
  }
}
</style>
</head>
<body>
    <!-- Background Elements -->
    <div class="stars" id="stars" aria-hidden="true"></div>
    <div class="moon" aria-hidden="true"></div>
    
    <!-- Main Navigation -->
    <nav role="navigation" aria-label="منوی اصلی">
        <div class="nav-container">
            <div class="logo interactive-element" onclick="window.location.href='/index.php'" role="button" tabindex="0" aria-label="صفحه اصلی ستاره ماه">
                <img src="/images/logo.png" alt="لوگو ستاره ماه">
            </div>
            
            <!-- Desktop Menu -->
            <div class="desktop-menu" role="menubar">
                <div class="menu-row">
                    <a href="/index.php" role="menuitem" class="interactive-element">🏠 خانه</a>
                    <a href="/index.php#about" onclick="window.location.href='/index.php'; setTimeout(() => showSection('about'), 100);" role="menuitem" class="interactive-element">📖 درباره کلاس</a>
                    <a href="/index.php#homework" onclick="window.location.href='/index.php'; setTimeout(() => showSection('homework'), 100);" role="menuitem" class="interactive-element">📝 تکالیف روزانه</a>
                    <a href="/index.php#materials" onclick="window.location.href='/index.php'; setTimeout(() => showSection('materials'), 100);" role="menuitem" class="interactive-element">📚 مطالب درسی</a>
                </div>
                <div class="menu-row">
                    <a href="/index.php#games" onclick="window.location.href='/index.php'; setTimeout(() => showSection('games'), 100);" role="menuitem" class="interactive-element">🎮آزمون و بازی </a>
                    <a href="/index.php#podcast" onclick="window.location.href='/index.php'; setTimeout(() => showSection('podcast'), 100);" role="menuitem" class="interactive-element">🎧 پادکست</a>
                    <a href="/index.php#gallery" onclick="window.location.href='/index.php'; setTimeout(() => showSection('gallery'), 100);" role="menuitem" class="interactive-element">🖼️ گالری</a>
                    <a href="/index.php#feedback" onclick="window.location.href='/index.php'; setTimeout(() => showSection('feedback'), 100);" role="menuitem" class="interactive-element">💬 بازخورد</a>
                    <?php if($isLoggedIn && $userType == 'admin'): ?>
                    <a href="/index.php#admin" onclick="window.location.href='/index.php'; setTimeout(() => showSection('admin'), 100);" role="menuitem" class="interactive-element">⚙️ پنل مدیریت</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu-container">
                <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="منوی موبایل" aria-expanded="false" aria-controls="mobileDropdown">
                    <span>منو</span>
                    <span class="menu-icon">▼</span>
                </button>
                
                <div class="mobile-dropdown" id="mobileDropdown" role="menu">
                    <ul>
                        <li><a href="/index.php" role="menuitem">🏠 خانه</a></li>
                        <li><a href="/index.php#about" onclick="navigateToSection('about')" role="menuitem">📖 درباره کلاس</a></li>
                        <li><a href="/index.php#homework" onclick="navigateToSection('homework')" role="menuitem">📝 تکالیف روزانه</a></li>
                        <li><a href="/index.php#materials" onclick="navigateToSection('materials')" role="menuitem">📚 مطالب درسی</a></li>
                        <li><a href="/index.php#games" onclick="navigateToSection('games')" role="menuitem">🎮 بازی‌ها</a></li>
                        <li><a href="/index.php#podcast" onclick="navigateToSection('podcast')" role="menuitem">🎧 پادکست</a></li>
                        <li><a href="/index.php#gallery" onclick="navigateToSection('gallery')" role="menuitem">🖼️ گالری</a></li>
                        <li><a href="/index.php#feedback" onclick="navigateToSection('feedback')" role="menuitem">💬 بازخورد</a></li>
                        <?php if($isLoggedIn && $userType == 'admin'): ?>
                        <li><a href="/index.php#admin" onclick="navigateToSection('admin')" role="menuitem">⚙️ پنل مدیریت</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Auth Section -->
            <div class="auth-section">
                <?php if ($isLoggedIn): ?>
                    <div class="user-info glass-effect">
                        <span>سلام <?php echo htmlspecialchars($userName); ?> عزیز! 👋</span>
                        <a href="/logout.php" class="logout-btn interactive-element">خروج</a>
                    </div>
                <?php else: ?>
                    <button class="login-btn interactive-element" onclick="window.location.href='/index.php'">ورود به حساب</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="exam-builder-container">
        <!-- Hero Section -->
        <div class="hero glass-effect" style="text-align: center; padding: 3rem 2rem; margin-bottom: 2rem;">
            <h1 style="margin: 0 0 1rem 0; font-size: 2.5rem; background: linear-gradient(45deg, #ff6b6b, #ffd93d, #6bcf7f); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">📓 دفتر کلاسی هوشمند</h1>
            <p style="margin: 0; color: rgba(255, 255, 255, 0.9); font-size: 1.2rem;">مدیریت عملکرد روزانه دانش‌آموزان با سهولت و دقت</p>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success fade-in">
                ✅ <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-error fade-in">
                ❌ <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Tab Container -->
        <div class="tab-container">
            <div class="tab-nav">
                <button class="tab-btn active" onclick="switchTab('register-tab')">ثبت فعالیت</button>
                <button class="tab-btn" onclick="switchTab('history-tab')">مدیریت سوابق نمرات</button>
            </div>
            
            <!-- Tab 1: Register Activity -->
            <div id="register-tab" class="tab-content active">
                <form id="activityForm" method="POST" action="">
                    <input type="hidden" name="action" value="add_activity">
                    
                    <!-- Activity Details Card -->
                    <div class="exam-card fade-in">
                        <div class="exam-card-header">
                            <div class="exam-step-number">1️⃣</div>
                            <div class="exam-card-title">
                                <h2>مشخصات فعالیت</h2>
                                <p>درس، موضوع و نوع نمره‌دهی را انتخاب کنید</p>
                            </div>
                            <div class="exam-badge">تنظیمات</div>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>📚 درس</label>
                                <select name="lesson" required>
                                    <option value="">انتخاب کنید...</option>
                                    <?php foreach ($subjects as $subject): ?>
                                    <option value="<?php echo htmlspecialchars($subject); ?>">
                                        <?php echo htmlspecialchars($subject); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>📋 موضوع</label>
                                <select name="topic" required>
                                    <option value="">انتخاب کنید...</option>
                                    <?php foreach ($topics as $topic): ?>
                                    <option value="<?php echo htmlspecialchars($topic); ?>">
                                        <?php echo htmlspecialchars($topic); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>🎯 نوع نمره</label>
                                <select name="score_type" id="scoreType" onchange="toggleScoreType()" required>
                                    <option value="numeric">عددی</option>
                                    <option value="descriptive">توصیفی</option>
                                    <option value="homework">تکلیف</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>📅 تاریخ</label>
                                <div class="date-picker-wrapper">
                                    <div class="date-input-container">
                                        <div class="date-input-with-icon">
                                            <span class="calendar-icon">📅</span>
                                            <input type="text" id="activity_date" name="activity_date" 
                                                   placeholder="انتخاب تاریخ..." readonly 
                                                   style="cursor: pointer;">
                                        </div>
                                        <button type="button" class="today-btn" onclick="setTodayDate()">امروز</button>
                                    </div>
                                    <input type="hidden" id="activity_date_gregorian" name="activity_date_gregorian">
                                    <small class="date-help-text">تاریخ شمسی را از تقویم انتخاب کنید</small>
                                    
                                    <!-- Calendar Popup -->
                                    <div class="calendar-popup" id="calendarPopup">
                                        <div class="calendar-header">
                                            <div class="calendar-nav">
                                                <button type="button" class="calendar-nav-btn" onclick="changeMonth(-1)">‹</button>
                                                <button type="button" class="calendar-nav-btn" onclick="changeMonth(1)">›</button>
                                            </div>
                                            <div class="calendar-title" id="calendarTitle"></div>
                                        </div>
                                        
                                        <div class="calendar-selects">
                                            <select id="yearSelect" onchange="renderCalendar()"></select>
                                            <select id="monthSelect" onchange="renderCalendar()"></select>
                                        </div>
                                        
                                        <div class="calendar-grid" id="calendarGrid"></div>
                                        
                                        <div class="calendar-footer">
                                            <button type="button" class="calendar-footer-btn confirm" onclick="confirmDate()">تأیید</button>
                                            <button type="button" class="calendar-footer-btn cancel" onclick="closeCalendar()">انصراف</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>✏️ عنوان فعالیت</label>
                            <input type="text" name="title" placeholder="مثال: آزمون فصل 3 ریاضی" required>
                        </div>
                    </div>
                    
                    <!-- Students Grades Card -->
                    <div class="exam-card fade-in">
                        <div class="exam-card-header">
                            <div class="exam-step-number">2️⃣</div>
                            <div class="exam-card-title">
                                <h2>ثبت نمرات</h2>
                                <p>نمره و بازخورد هر دانش‌آموز را وارد کنید</p>
                            </div>
                            <div class="exam-badge">ارزیابی</div>
                        </div>
                        
                        <div class="students-section">
                            <div class="section-header">
                                <h3>لیست دانش‌آموزان</h3>
                                <div class="grade-range-container" id="gradeRange" 
                                   style="display:flex;align-items:center;gap:.5rem;">
                                    <label for="gradeMax" 
                                     style="margin:0; color: inherit; font-size:0.85rem;">📊 تنظیم نمره</label>
                                    <div class="grade-range-inputs" style="display:flex;align-items:center;gap:.3rem;">
                                        <input type="number" name="grade_max" id="gradeMax" 
                                         value="20" min="1" max="100" onchange="updateGradeRange()">
                                    </div>
                                </div>
                                
                                <div style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
                                    <!-- دکمه‌های اعمال به همه توصیفی -->
                                    <div class="apply-all-section" id="applyAllSection" style="display: none;">
                                        <label style="color: #333; font-size: 0.9rem; margin-left: 0.5rem;">اعمال به همه:</label>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAll('خیلی خوب')">همه خیلی خوب</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAll('خوب')">همه خوب</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAll('قابل قبول')">همه قابل قبول</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAll('نیاز به تلاش')">همه نیاز به تلاش</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAll('غایب')">همه غایب</button>
                                    </div>
                                    
                                    <!-- دکمه‌های اعمال به همه تکلیف -->
                                    <div class="apply-all-homework-section" id="applyAllHomeworkSection" style="display: none;">
                                        <label style="color: #333; font-size: 0.9rem; margin-left: 0.5rem;">اعمال به همه:</label>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAllHomework('کامل')">همه کامل</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAllHomework('ناقص')">همه ناقص</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAllHomework('انجام نداده')">همه انجام نداده</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAllHomework('غایب')">همه غایب</button>
                                    </div>
                                    
                                    <!-- دکمه‌های اعمال به همه عددی -->
                                    <div class="apply-all-numeric-section" id="applyAllNumericSection" style="display: none;">
                                        <label style="color: #333; font-size: 0.9rem; margin-left: 0.5rem;">اعمال به همه:</label>
                                        <input type="number" id="applyAllValue" placeholder="نمره" style="width: 80px; padding: 0.3rem; border: 1px solid #ddd; border-radius: 5px; text-align: center;">
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="applyToAllNumeric()">اعمال به همه</button>
                                        <button type="button" class="exam-btn exam-btn-soft btn-sm" onclick="clearAllNumeric()">پاک کردن همه</button>
                                    </div>
                                    
                                    <input type="text" class="search-box" placeholder="🔍 جستجوی نام..." 
                                           onkeyup="searchStudents(this.value)">
                                </div>
                            </div>
                            
                            <table class="students-table">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;">ردیف</th>
                                        <th style="width: 150px;">نام و نام خانوادگی</th>
                                        <th style="width: 220px;">نمره</th>
                                        <th style="width: 120px;">بازخورد</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $counter = 1;
                                    foreach($students as $student): 
                                    ?>
                                    <tr class="student-row" data-student-name="<?php echo strtolower($student['first_name'] . ' ' . $student['last_name']); ?>" 
                                        data-student-id="<?php echo $student['id']; ?>">
                                        <td style="text-align: center;"><?php echo $counter++; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                                        </td>
                                        <td>
                                            <!-- Numeric Grade -->
                                            <div class="numeric-section grade-section">
                                                <input type="number" name="student_results[<?php echo $student['id']; ?>][score]" 
                                                       class="numeric-input" min="0" max="20" step="0.25">
                                            </div>
                                            
                                            <!-- Descriptive Grade -->
                                            <div class="descriptive-section grade-section" style="display: none;">
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'خیلی خوب')">خیلی خوب</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'خوب')">خوب</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'قابل قبول')">قابل قبول</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'نیاز به تلاش')">نیاز به تلاش</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'غایب')">🚫 غایب</button>
                                                <input type="hidden" class="selected-grade">
                                            </div>
                                            
                                            <!-- Homework Status -->
                                            <div class="homework-section grade-section" style="display: none;">
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'کامل')">✅ کامل</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'ناقص')">⚠️ ناقص</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'انجام نداده')">❌ انجام نداده</button>
                                                <button type="button" class="grade-btn" onclick="selectGrade(this, '<?php echo $student['id']; ?>', 'غایب')">🚫 غایب</button>
                                                <input type="hidden" class="selected-grade">
                                            </div>
                                        </td>
                                        <td>
                                            <textarea name="student_results[<?php echo $student['id']; ?>][feedback]" 
                                                      class="feedback-input" placeholder="بازخورد..."></textarea>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div style="text-align: center; margin-top: 2rem;">
                            <button type="submit" class="exam-btn exam-btn-primary">
                                💾 ذخیره فعالیت و نمرات
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Tab 2: Grade History Management -->
            <div id="history-tab" class="tab-content">
                <div class="exam-card fade-in">
                    <div class="exam-card-header">
                        <div class="exam-step-number">📊</div>
                        <div class="exam-card-title">
                            <h2>مدیریت سوابق نمرات</h2>
                            <p>مشاهده و ویرایش سوابق نمرات دانش‌آموزان</p>
                        </div>
                        <div class="exam-badge">سوابق</div>
                    </div>
                    
                    <div class="students-section">
                        <!-- *** شروع تغییر: جایگزینی div با iframe *** -->
                        <iframe src="manager_new.php" class="manager-iframe" title="مدیریت سوابق نمرات"></iframe>
                        <!-- *** پایان تغییر *** -->
                    </div>
                </div>
            </div>
        </div>
    <!-- اسکریپت‌های مورد نیاز -->
    <script>
        // ============= تقویم شمسی حرفه‌ای =============
        const persianMonths = [
            'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
            'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
        ];
        
        const persianDays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        
        let currentYear, currentMonth, currentDay;
        let selectedYear, selectedMonth, selectedDay;
        
        // تبدیل میلادی به شمسی
        function gregorianToJalali(gy, gm, gd) {
            const g_d_m = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            const gy2 = (gm > 2) ? (gy + 1) : gy;
            let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd;
            for (let i = 0; i < gm; i++) days += g_d_m[i];
            let jy = -1595 + (33 * Math.floor(days / 12053));
            days %= 12053;
            jy += 4 * Math.floor(days / 1461);
            days %= 1461;
            if (days > 365) {
                jy += Math.floor((days - 1) / 365);
                days = (days - 1) % 365;
            }
            if (days < 186) {
                jm = 1 + Math.floor(days / 31);
                jd = 1 + (days % 31);
            } else {
                days -= 186;
                jm = 7 + Math.floor(days / 30);
                jd = 1 + (days % 30);
            }
            return { jy: jy, jm: jm, jd: jd };
        }
        
        function jalaliToGregorian(jy, jm, jd) {
    let gy = jy <= 979 ? 621 : 1600;
    jy = (jy <= 979) ? jy : jy - 979;
    let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30 + 186)) + 79;
    gy += 400 * Math.floor(days / 146097); days %= 146097;
    if (days >= 36525) {
        days--;
        gy += 100 * Math.floor(days / 36524); days %= 36524;
        if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days >= 366) {
        days--;
        gy += Math.floor((days - 1) / 365); days = (days - 1) % 365;
    }
    let gd = days + 1; // *** این خط اصلاح شد: const به let تغییر کرد ***
    const sal_a = [31, (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    while (gm < 12 && gd > sal_a[gm]) { gd -= sal_a[gm]; gm++; }
    gm++;
    return { gy: gy, gm: gm, gd: gd };
}
        
        // تعداد روزهای ماه شمسی
        function getDaysInJalaliMonth(year, month) {
            if (month <= 6) return 31;
            if (month <= 11) return 30;
            return isJalaliLeapYear(year) ? 30 : 29;
        }
        
        // سال کبیسه شمسی
        function isJalaliLeapYear(year) {
            const a = year - (year >= 0 ? 474 : 473);
            const b = (a % 2820) + 474;
            return (((b + 38) * 682) % 2816) < 682;
        }
        
        // اعداد فارسی
        function toPersianNum(num) {
            const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            return num.toString().replace(/\d/g, d => persianDigits[d]);
        }
        
        // مقداردهی اولیه تقویم
        function initCalendar() {
            const today = new Date();
            const jalaliToday = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
            currentYear = jalaliToday.jy;
            currentMonth = jalaliToday.jm;
            currentDay = jalaliToday.jd;
            selectedYear = currentYear;
            selectedMonth = currentMonth;
            selectedDay = null;
            
            populateSelects();
            renderCalendar();
        }
        
        // پر کردن لیست‌های انتخاب
        function populateSelects() {
            const yearSelect = document.getElementById('yearSelect');
            const monthSelect = document.getElementById('monthSelect');
            
            // سال‌ها (۱۳۸۰ تا ۱۴۵۰)
            yearSelect.innerHTML = '';
            for (let y = 1380; y <= 1450; y++) {
                const option = document.createElement('option');
                option.value = y;
                option.textContent = toPersianNum(y);
                if (y === selectedYear) option.selected = true;
                yearSelect.appendChild(option);
            }
            
            // ماه‌ها
            monthSelect.innerHTML = '';
            persianMonths.forEach((month, index) => {
                const option = document.createElement('option');
                option.value = index + 1;
                option.textContent = month;
                if (index + 1 === selectedMonth) option.selected = true;
                monthSelect.appendChild(option);
            });
        }
        
        // رندر تقویم
        function renderCalendar() {
            selectedYear = parseInt(document.getElementById('yearSelect').value);
            selectedMonth = parseInt(document.getElementById('monthSelect').value);
            
            const title = document.getElementById('calendarTitle');
            title.textContent = `${persianMonths[selectedMonth - 1]} ${toPersianNum(selectedYear)}`;
            
            const grid = document.getElementById('calendarGrid');
            grid.innerHTML = '';
            
            // هدر روزهای هفته
            persianDays.forEach(day => {
                const header = document.createElement('div');
                header.className = 'calendar-day-header';
                header.textContent = day;
                grid.appendChild(header);
            });
            
            // محاسبه روز شروع ماه
            const firstDayOfMonth = jalaliToGregorian(selectedYear, selectedMonth, 1);
            const firstDayGregorian = new Date(firstDayOfMonth.gy, firstDayOfMonth.gm - 1, firstDayOfMonth.gd);
            let startDay = (firstDayGregorian.getDay() + 1) % 7; // شنبه = 0
            
            const daysInMonth = getDaysInJalaliMonth(selectedYear, selectedMonth);
            const daysInPrevMonth = selectedMonth === 1 ? 
                getDaysInJalaliMonth(selectedYear - 1, 12) : 
                getDaysInJalaliMonth(selectedYear, selectedMonth - 1);
            
            // روزهای ماه قبل
            for (let i = startDay - 1; i >= 0; i--) {
                const day = document.createElement('div');
                day.className = 'calendar-day other-month';
                day.textContent = toPersianNum(daysInPrevMonth - i);
                grid.appendChild(day);
            }
            
            // روزهای ماه جاری
            for (let d = 1; d <= daysInMonth; d++) {
                const day = document.createElement('div');
                day.className = 'calendar-day';
                day.textContent = toPersianNum(d);
                
                // امروز
                if (d === currentDay && selectedMonth === currentMonth && selectedYear === currentYear) {
                    day.classList.add('today');
                }
                
                // روز انتخاب شده
                if (d === selectedDay && selectedMonth === parseInt(document.getElementById('monthSelect').value) && 
                    selectedYear === parseInt(document.getElementById('yearSelect').value)) {
                    day.classList.add('selected');
                }
                
                day.onclick = () => selectDay(d);
                grid.appendChild(day);
            }
            
            // روزهای ماه بعد
            const remainingCells = 42 - (startDay + daysInMonth);
            for (let d = 1; d <= remainingCells; d++) {
                const day = document.createElement('div');
                day.className = 'calendar-day other-month';
                day.textContent = toPersianNum(d);
                grid.appendChild(day);
            }
        }
        
        // انتخاب روز
        function selectDay(day) {
            selectedDay = day;
            renderCalendar();
        }
        
        // تغییر ماه
        function changeMonth(delta) {
            selectedMonth += delta;
            if (selectedMonth > 12) {
                selectedMonth = 1;
                selectedYear++;
            } else if (selectedMonth < 1) {
                selectedMonth = 12;
                selectedYear--;
            }
            document.getElementById('yearSelect').value = selectedYear;
            document.getElementById('monthSelect').value = selectedMonth;
            renderCalendar();
        }
        
        // تأیید تاریخ
        function confirmDate() {
            if (!selectedDay) {
                alert('لطفاً یک روز را انتخاب کنید');
                return;
            }
            
            const jalaliDate = `${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${String(selectedDay).padStart(2, '0')}`;
            const gregorianDate = jalaliToGregorian(selectedYear, selectedMonth, selectedDay);
            const gregorianDateStr = `${gregorianDate.gy}-${String(gregorianDate.gm).padStart(2, '0')}-${String(gregorianDate.gd).padStart(2, '0')}`;
            
            document.getElementById('activity_date').value = toPersianNum(jalaliDate);
            document.getElementById('activity_date_gregorian').value = gregorianDateStr;
            
            closeCalendar();
        }
        
        // بستن تقویم
        function closeCalendar() {
            const calendarPopup = document.getElementById('calendarPopup');
            const calendarOverlay = document.getElementById('calendarOverlay');
            
            if (calendarPopup) {
                calendarPopup.classList.remove('show');
            }
            if (calendarOverlay) {
                calendarOverlay.classList.remove('show');
            }
        }
        
        // تنظیم تاریخ امروز
        function setTodayDate() {
            const today = new Date();
            const jalaliToday = gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
            
            selectedYear = jalaliToday.jy;
            selectedMonth = jalaliToday.jm;
            selectedDay = jalaliToday.jd;
            
            const jalaliDate = `${jalaliToday.jy}/${String(jalaliToday.jm).padStart(2, '0')}/${String(jalaliToday.jd).padStart(2, '0')}`;
            const gregorianDateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
            
            document.getElementById('activity_date').value = toPersianNum(jalaliDate);
            document.getElementById('activity_date_gregorian').value = gregorianDateStr;
            
            renderCalendar();
        }
        
        // ============= بقیه اسکریپت‌ها =============
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const mobileDropdown = document.getElementById('mobileDropdown');
            const menuOverlay = document.getElementById('menuOverlay');

            if (mobileMenuBtn && mobileDropdown) {
                mobileMenuBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = mobileDropdown.classList.contains('show');
                    if (isOpen) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    } else {
                        mobileDropdown.classList.add('show');
                        mobileMenuBtn.classList.add('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'true');
                        if (menuOverlay) menuOverlay.classList.add('show');
                    }
                });

                document.addEventListener('click', function(e) {
                    if (!mobileMenuBtn.contains(e.target) && !mobileDropdown.contains(e.target)) {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });

                mobileDropdown.addEventListener('click', function(e) {
                    if (e.target.tagName === 'A') {
                        mobileDropdown.classList.remove('show');
                        mobileMenuBtn.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        if (menuOverlay) menuOverlay.classList.remove('show');
                    }
                });
            }
        });

        // Initialize stars animation
        function createStars() {
            const starsContainer = document.getElementById('stars');
            if (!starsContainer) return;
            for (let i = 0; i < 50; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 4 + 's';
                star.style.animationDuration = (Math.random() * 3 + 2) + 's';
                starsContainer.appendChild(star);
            }
        }

        // نکات تعاملی برای تجربه کاربری بهتر
        function navigateToSection(section) {
            window.location.href = '/index.php#' + section;
        }

        // ============= منطق تب‌ها =============
        // تابع برای جابجایی بین تب‌ها
        function switchTab(tabId) {
            // پنهان کردن تمام محتویات تب‌ها
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // حذف کلاس فعال از تمام دکمه‌های تب
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // نمایش محتوای تب مورد نظر
            document.getElementById(tabId).classList.add('active');
            
            // فعال کردن دکمه تب مورد نظر
            event.target.classList.add('active');
        }
        
        // Toggle score type
        function toggleScoreType() {
            const scoreType = document.getElementById('scoreType').value;
            const numericSections = document.querySelectorAll('.numeric-section');
            const descriptiveSections = document.querySelectorAll('.descriptive-section');
            const homeworkSections = document.querySelectorAll('.homework-section');
            const applyAllSection = document.getElementById('applyAllSection');
            const applyAllHomeworkSection = document.getElementById('applyAllHomeworkSection');
            const applyAllNumericSection = document.getElementById('applyAllNumericSection');
            const gradeRangeContainer = document.getElementById('gradeRange');
            
            // Hide all sections
            numericSections.forEach(s => s.style.display = 'none');
            descriptiveSections.forEach(s => s.style.display = 'none');
            homeworkSections.forEach(s => s.style.display = 'none');
            applyAllSection.style.display = 'none';
            applyAllHomeworkSection.style.display = 'none';
            applyAllNumericSection.style.display = 'none';
            if (gradeRangeContainer) gradeRangeContainer.style.display = 'none';
            
            // Show relevant section
            if (scoreType === 'numeric') {
                applyAllNumericSection.style.display = 'block';
                if (gradeRangeContainer) gradeRangeContainer.style.display = 'flex';
                numericSections.forEach(s => {
                    s.style.display = 'block';
                    const input = s.querySelector('input');
                    if (input) {
                        const studentId = s.closest('[data-student-id]').getAttribute('data-student-id');
                        input.setAttribute('name', `student_results[${studentId}][score]`);
                    }
                });
                updateGradeRange();
            } else if (scoreType === 'descriptive') {
                applyAllSection.style.display = 'block';
                descriptiveSections.forEach(s => {
                    s.style.display = 'block';
                    const hiddenInput = s.querySelector('.selected-grade');
                    const studentId = s.closest('[data-student-id]').getAttribute('data-student-id');
                    hiddenInput.setAttribute('name', `student_results[${studentId}][score]`);
                });
            } else if (scoreType === 'homework') {
                applyAllHomeworkSection.style.display = 'block';
                homeworkSections.forEach(s => {
                    s.style.display = 'block';
                    const hiddenInput = s.querySelector('.selected-grade');
                    const studentId = s.closest('[data-student-id]').getAttribute('data-student-id');
                    hiddenInput.setAttribute('name', `student_results[${studentId}][score]`);
                });
            }
        }
        
        // Apply grade to all students (descriptive)
        function applyToAll(grade) {
            const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
            visibleRows.forEach(row => {
                const gradeButtons = row.querySelectorAll('.descriptive-section .grade-btn');
                const hiddenInput = row.querySelector('.descriptive-section .selected-grade');
                
                // Remove selected from all buttons
                gradeButtons.forEach(btn => btn.classList.remove('selected'));
                
                // Find and select the matching button
                gradeButtons.forEach(btn => {
                    if (btn.textContent.trim() === grade || btn.textContent.includes(grade)) {
                        btn.classList.add('selected');
                        if (hiddenInput) {
                            hiddenInput.value = grade;
                        }
                    }
                });
            });
        }
        
        // Apply homework status to all students
        function applyToAllHomework(status) {
            const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
            visibleRows.forEach(row => {
                const gradeButtons = row.querySelectorAll('.homework-section .grade-btn');
                const hiddenInput = row.querySelector('.homework-section .selected-grade');
                
                // Remove selected from all buttons
                gradeButtons.forEach(btn => btn.classList.remove('selected'));
                
                // Find and select the matching button
                gradeButtons.forEach(btn => {
                    if (btn.textContent.includes(status)) {
                        btn.classList.add('selected');
                        if (hiddenInput) {
                            hiddenInput.value = status;
                        }
                    }
                });
            });
        }
        
        // Apply numeric grade to all students
        function applyToAllNumeric() {
            const value = document.getElementById('applyAllValue').value;
            const maxGrade = document.getElementById('gradeMax').value;
            
            if (!value || value === '') {
                alert('لطفا نمره مورد نظر را وارد کنید');
                return;
            }
            
            if (parseFloat(value) > parseFloat(maxGrade)) {
                alert(`نمره نمی‌تواند بیشتر از ${maxGrade} باشد`);
                return;
            }
            
            const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
            visibleRows.forEach(row => {
                const numericInput = row.querySelector('.numeric-section input');
                if (numericInput) {
                    numericInput.value = value;
                }
            });
        }
        
        // Clear all numeric grades
        function clearAllNumeric() {
            const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
            visibleRows.forEach(row => {
                const numericInput = row.querySelector('.numeric-section input');
                if (numericInput) {
                    numericInput.value = '';
                }
            });
        }
        
        // Update grade range
        function updateGradeRange() {
            const maxGrade = document.getElementById('gradeMax').value;
            const numericInputs = document.querySelectorAll('.numeric-input');
            
            numericInputs.forEach(input => {
                input.setAttribute('max', maxGrade);
                input.setAttribute('placeholder', `0-${maxGrade}`);
            });
        }
        
        // Select grade button
        function selectGrade(button, studentId, grade) {
            const parent = button.parentElement;
            const buttons = parent.querySelectorAll('.grade-btn');
            
            // Remove selected from all buttons
            buttons.forEach(btn => btn.classList.remove('selected'));
            
            // Add selected to clicked button
            button.classList.add('selected');
            
            // Set hidden input value
            const hiddenInput = parent.querySelector('.selected-grade');
            if (hiddenInput) {
                hiddenInput.value = grade;
            }
        }
        
        // جستجوی نام دانش‌آموز
        function searchStudents(term) {
            const rows = document.querySelectorAll('.student-row');
            const searchTerm = term.toLowerCase();
            
            rows.forEach(row => {
                const name = row.getAttribute('data-student-name');
                if (name.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Initialize on load
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize stars and animations
            createStars();
            
            toggleScoreType();
            
            // باز کردن تقویم
            const dateInput = document.getElementById('activity_date');
            const calendarPopup = document.getElementById('calendarPopup');
            
            if (dateInput && calendarPopup) {
                initCalendar();
                
                dateInput.addEventListener('click', function(e) {
                    e.stopPropagation();
                    calendarPopup.classList.toggle('show');
                    // نمایش overlay
                    const overlay = document.getElementById('calendarOverlay');
                    if(overlay) overlay.classList.add('show');
                });
                
                // بستن با کلیک بیرون
                document.addEventListener('click', function(e) {
                    if (!calendarPopup.contains(e.target) && e.target !== dateInput) {
                        closeCalendar();
                    }
                });
                
                calendarPopup.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
            
            // Animation initialization
            const elements = document.querySelectorAll('.fade-in');
            elements.forEach((el, index) => {
                setTimeout(() => {
                    el.style.opacity = '1';
                }, index * 100);
            });
        });
        
        // Form validation before submit
        document.getElementById('activityForm').addEventListener('submit', function(e) {
            const dateInput = document.getElementById('activity_date');
            const gregorianInput = document.getElementById('activity_date_gregorian');
            
            if (!dateInput.value || !gregorianInput.value) {
                e.preventDefault();
                alert('لطفاً تاریخ را انتخاب کنید');
                return false;
            }
        });
    </script>
   <div class="calendar-overlay" id="calendarOverlay"></div>
 

</body>
</html>