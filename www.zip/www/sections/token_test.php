<?php
session_start();

// فقط برای تست، سشن بسازیم
$_SESSION['full_name'] = $_SESSION['full_name'] ?? 'Test User';
$_SESSION['user_id']   = $_SESSION['user_id'] ?? ('u_' . rand(1000,9999));
$_SESSION['class']     = $_SESSION['class'] ?? '4A';

// اگر ?teacher=1 بود نقش معلم شود
$_SESSION['role'] = (isset($_GET['teacher']) && $_GET['teacher'] == '1') ? 'teacher' : 'student';

header('Location: livekit_token.php?class=' . urlencode($_SESSION['class']));
exit;
