<?php
/* =============================================================
 * auto_level_updater.php - سیستم خودکار بروزرسانی سطح دانش‌آموزان
 * این فایل هر ساعت توسط Cron Job اجرا می‌شود
 * ============================================================= */

// بررسی دسترسی - اگر از مرورگر اجرا شده، نیاز به احراز هویت
if (php_sapi_name() !== 'cli') {
    // شروع session برای بررسی دسترسی مدیر
    if (session_status() === PHP_SESSION_NONE) {
        @session_start();
    }
    
    // اگر درخواست AJAX نیست و کاربر مدیر نیست، دسترسی مسدود
    if (!isset($_GET['manual_run']) && !isset($_POST['action']) && !isset($_GET['status_report'])) {
        if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
            die("Access Denied: دسترسی محدود به مدیران سیستم");
        }
    }
    
    // برای درخواست‌های AJAX هم بررسی کن
    if ((isset($_GET['manual_run']) || isset($_POST['action']) || isset($_GET['status_report'])) && 
        (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin')) {
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'دسترسی محدود به مدیران سیستم'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

require_once dirname(__FILE__) . '/../config.php';

// Log function
function writeLog($message) {
    $logFile = dirname(__FILE__) . '/logs/level_updater.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND | LOCK_EX);
}

class AutoLevelUpdater {
    private $db;
    
    // تنظیمات سطح - می‌توانید تغییر دهید
    private $levelThresholds = [
        1 => 0,      // سطح 1: 0 تا 999 XP
        2 => 1000,   // سطح 2: 1000 تا 2499 XP  
        3 => 2500,   // سطح 3: 2500 تا 4999 XP
        4 => 5000,   // سطح 4: 5000 تا 9999 XP
        5 => 10000,  // سطح 5: 10000 تا 19999 XP
        6 => 20000,  // سطح 6: 20000 تا 39999 XP
        7 => 40000,  // سطح 7: 40000 تا 79999 XP
        8 => 80000,  // سطح 8: 80000 تا 159999 XP
        9 => 160000, // سطح 9: 160000 تا 319999 XP
        10 => 320000 // سطح 10: 320000+ XP
    ];
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * محاسبه سطح بر اساس کل XP
     */
    private function calculateLevel($totalXP) {
        $level = 1;
        foreach ($this->levelThresholds as $targetLevel => $requiredXP) {
            if ($totalXP >= $requiredXP) {
                $level = $targetLevel;
            } else {
                break;
            }
        }
        return $level;
    }
    
    /**
     * بروزرسانی سطح همه دانش‌آموزان
     */
    public function updateAllLevels() {
        try {
            writeLog("شروع بروزرسانی خودکار سطح‌ها...");
            
            // دریافت همه دانش‌آموزان با XP فعلی
            $stmt = $this->db->prepare("
                SELECT s.id, s.student_id, s.total_xp, s.level as current_level,
                       u.first_name, u.last_name
                FROM student_xp s
                INNER JOIN users u ON s.student_id = u.id 
                WHERE u.user_type = 'student' AND u.is_active = 1
            ");
            $stmt->execute();
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($students)) {
                writeLog("هیچ دانش‌آموزی یافت نشد.");
                return ['success' => true, 'message' => 'هیچ دانش‌آموزی یافت نشد.'];
            }
            
            $updatedCount = 0;
            $errors = [];
            
            foreach ($students as $student) {
                $newLevel = $this->calculateLevel($student['total_xp']);
                
                // فقط در صورت تغییر سطح، بروزرسانی کن
                if ($newLevel != $student['current_level']) {
                    $success = $this->updateStudentLevel(
                        $student['student_id'], 
                        $newLevel, 
                        $student['current_level'],
                        $student['total_xp']
                    );
                    
                    if ($success) {
                        $updatedCount++;
                        $studentName = $student['first_name'] . ' ' . $student['last_name'];
                        writeLog("سطح {$studentName} از {$student['current_level']} به {$newLevel} تغییر کرد (XP: {$student['total_xp']})");
                    } else {
                        $errors[] = "خطا در بروزرسانی سطح دانش‌آموز ID: {$student['student_id']}";
                    }
                }
            }
            
            // ثبت آمار
            $totalStudents = count($students);
            writeLog("بروزرسانی کامل شد. کل: {$totalStudents}, بروزرسانی شده: {$updatedCount}");
            
            if (!empty($errors)) {
                writeLog("خطاها: " . implode(', ', $errors));
            }
            
            return [
                'success' => true, 
                'message' => "بروزرسانی سطح‌ها انجام شد. {$updatedCount} از {$totalStudents} دانش‌آموز بروزرسانی شدند.",
                'updated_count' => $updatedCount,
                'total_count' => $totalStudents,
                'errors' => $errors
            ];
            
        } catch (Exception $e) {
            $errorMsg = "خطا در بروزرسانی خودکار: " . $e->getMessage();
            writeLog($errorMsg);
            return ['success' => false, 'message' => $errorMsg];
        }
    }
    
    /**
     * بروزرسانی سطح یک دانش‌آموز
     */
    private function updateStudentLevel($studentId, $newLevel, $oldLevel, $totalXP) {
        try {
            // بروزرسانی سطح در جدول student_xp
            $stmt = $this->db->prepare("
                UPDATE student_xp 
                SET level = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE student_id = ?
            ");
            $result = $stmt->execute([$newLevel, $studentId]);
            
            // ثبت تاریخچه تغییر سطح
            if ($result) {
                $this->logLevelChange($studentId, $newLevel, $oldLevel, $totalXP);
            }
            
            return $result;
            
        } catch (Exception $e) {
            writeLog("خطا در بروزرسانی سطح دانش‌آموز {$studentId}: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * ثبت تاریخچه تغییر سطح
     */
    private function logLevelChange($studentId, $newLevel, $oldLevel, $totalXP) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO xp_history (student_id, subject, amount, reason, admin_id) 
                VALUES (?, 'level_change', ?, ?, 18)
            ");
            
            $reason = "تغییر خودکار سطح از {$oldLevel} به {$newLevel} (بر اساس کل XP: {$totalXP})";
            $stmt->execute([$studentId, 0, $reason]);
            
        } catch (Exception $e) {
            writeLog("خطا در ثبت تاریخچه تغییر سطح: " . $e->getMessage());
        }
    }
    
    /**
     * گزارش وضعیت فعلی
     */
    public function getStatusReport() {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(*) as total_students,
                    AVG(total_xp) as avg_xp,
                    MAX(total_xp) as max_xp,
                    MIN(total_xp) as min_xp,
                    AVG(level) as avg_level,
                    MAX(level) as max_level
                FROM student_xp s
                INNER JOIN users u ON s.student_id = u.id
                WHERE u.user_type = 'student' AND u.is_active = 1
            ");
            $stmt->execute();
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // توزیع سطوح
            $levelStmt = $this->db->prepare("
                SELECT level, COUNT(*) as count
                FROM student_xp s
                INNER JOIN users u ON s.student_id = u.id
                WHERE u.user_type = 'student' AND u.is_active = 1
                GROUP BY level
                ORDER BY level
            ");
            $levelStmt->execute();
            $levelDistribution = $levelStmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'stats' => $stats,
                'level_distribution' => $levelDistribution,
                'timestamp' => date('Y-m-d H:i:s')
            ];
            
        } catch (Exception $e) {
            writeLog("خطا در تولید گزارش وضعیت: " . $e->getMessage());
            return null;
        }
    }
}

// اجرای اسکریپت
if (isset($conn)) {
    $updater = new AutoLevelUpdater($conn);
    
    // اگر از طریق وب درخواست شده (برای تست دستی)
    if (isset($_GET['manual_run']) || isset($_POST['action'])) {
        header('Content-Type: application/json; charset=utf-8');
        $result = $updater->updateAllLevels();
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // اگر گزارش وضعیت درخواست شده
    if (isset($_GET['status_report'])) {
        header('Content-Type: application/json; charset=utf-8');
        $report = $updater->getStatusReport();
        echo json_encode($report, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // اجرای عادی (از Cron Job)
    $result = $updater->updateAllLevels();
    
    if ($result['success']) {
        echo "✅ " . $result['message'] . "\n";
    } else {
        echo "❌ " . $result['message'] . "\n";
        exit(1); // Exit code برای Cron
    }
    
} else {
    writeLog("خطا: اتصال به دیتابیس برقرار نشد.");
    echo "❌ خطا: اتصال به دیتابیس برقرار نشد.\n";
    exit(1);
}
?>

<!-- HTML برای تست دستی (اختیاری) -->
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تست سیستم بروزرسانی خودکار سطح</title>
    <style>
        body { font-family: tahoma; margin: 20px; }
        .btn { padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .result { margin: 20px 0; padding: 15px; border-radius: 5px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow: auto; }
    </style>
</head>
<body>
    <h1>🔄 تست سیستم بروزرسانی خودکار سطح</h1>
    
    <button class="btn btn-primary" onclick="runUpdate()">🚀 اجرای دستی بروزرسانی</button>
    <button class="btn btn-success" onclick="getStatus()">📊 گزارش وضعیت</button>
    
    <div id="result"></div>
    
    <script>
        function runUpdate() {
            document.getElementById('result').innerHTML = '⏳ در حال اجرا...';
            
            fetch('?manual_run=1')
                .then(response => response.json())
                .then(data => {
                    const resultDiv = document.getElementById('result');
                    if (data.success) {
                        resultDiv.innerHTML = `
                            <div class="result success">
                                <h3>✅ موفقیت آمیز</h3>
                                <p>${data.message}</p>
                                <p>تعداد بروزرسانی شده: ${data.updated_count} از ${data.total_count}</p>
                                ${data.errors.length > 0 ? '<p>خطاها: ' + data.errors.join(', ') + '</p>' : ''}
                            </div>
                        `;
                    } else {
                        resultDiv.innerHTML = `
                            <div class="result error">
                                <h3>❌ خطا</h3>
                                <p>${data.message}</p>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    document.getElementById('result').innerHTML = `
                        <div class="result error">
                            <h3>❌ خطا</h3>
                            <p>خطا در ارتباط: ${error.message}</p>
                        </div>
                    `;
                });
        }
        
        function getStatus() {
            document.getElementById('result').innerHTML = '⏳ در حال بارگذاری گزارش...';
            
            fetch('?status_report=1')
                .then(response => response.json())
                .then(data => {
                    const stats = data.stats;
                    const levels = data.level_distribution;
                    
                    let levelChart = '<h4>توزیع سطوح:</h4><ul>';
                    levels.forEach(level => {
                        levelChart += `<li>سطح ${level.level}: ${level.count} نفر</li>`;
                    });
                    levelChart += '</ul>';
                    
                    document.getElementById('result').innerHTML = `
                        <div class="result success">
                            <h3>📊 گزارش وضعیت - ${data.timestamp}</h3>
                            <p><strong>کل دانش‌آموزان:</strong> ${stats.total_students} نفر</p>
                            <p><strong>میانگین XP:</strong> ${Math.round(stats.avg_xp)} امتیاز</p>
                            <p><strong>حداکثر XP:</strong> ${stats.max_xp} امتیاز</p>
                            <p><strong>حداقل XP:</strong> ${stats.min_xp} امتیاز</p>
                            <p><strong>میانگین سطح:</strong> ${Math.round(stats.avg_level * 10) / 10}</p>
                            <p><strong>بالاترین سطح:</strong> ${stats.max_level}</p>
                            ${levelChart}
                        </div>
                    `;
                })
                .catch(error => {
                    document.getElementById('result').innerHTML = `
                        <div class="result error">
                            <h3>❌ خطا</h3>
                            <p>خطا در دریافت گزارش: ${error.message}</p>
                        </div>
                    `;
                });
        }
    </script>
</body>
</html>