<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once 'config.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    die('دسترسی غیرمجاز');
}

$studentId = $_SESSION['user_id'];

try {
    // دریافت اطلاعات کامل دانش‌آموز
    $studentStmt = $conn->prepare("
        SELECT 
            u.id,
            u.first_name,
            u.last_name,
            u.national_id,
            u.created_at as registration_date,
            COALESCE(sx.total_xp, 0) as total_xp,
            COALESCE(sx.math_xp, 0) as math_xp,
            COALESCE(sx.science_xp, 0) as science_xp,
            COALESCE(sx.persian_xp, 0) as persian_xp,
            COALESCE(sx.social_xp, 0) as social_xp,
            COALESCE(sx.religion_xp, 0) as religion_xp,
            COALESCE(sx.level, 1) as level,
            sx.updated_at
        FROM users u
        LEFT JOIN student_xp sx ON u.id = sx.student_id
        WHERE u.id = ? AND u.user_type = 'student'
    ");
    
    $studentStmt->execute([$studentId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        die('اطلاعات دانش‌آموز یافت نشد');
    }
    
    // محاسبه رنک
    $rankStmt = $conn->prepare("
        SELECT COUNT(*) + 1 as student_rank
        FROM student_xp sx
        JOIN users u ON sx.student_id = u.id
        WHERE u.user_type = 'student' AND sx.total_xp > ?
    ");
    $rankStmt->execute([$student['total_xp']]);
    $rank = $rankStmt->fetchColumn() ?: 1;
    
    // تعداد کل دانش‌آموزان
    $totalStudentsStmt = $conn->query("SELECT COUNT(*) FROM users WHERE user_type = 'student'");
    $totalStudents = $totalStudentsStmt->fetchColumn();
    
    // تاریخچه کامل بازی‌ها
    $gamesStmt = $conn->prepare("
        SELECT 
            g.title as game_title,
            g.subject,
            gr.score,
            gr.accuracy,
            gr.time_spent,
            gr.completed_at
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        ORDER BY gr.completed_at DESC
    ");
    $gamesStmt->execute([$studentId]);
    $gameHistory = $gamesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // آمار کامل
    $statsStmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_games,
            AVG(score) as avg_score,
            MAX(score) as best_score,
            MIN(score) as lowest_score,
            AVG(accuracy) as avg_accuracy,
            MAX(accuracy) as best_accuracy,
            SUM(time_spent) as total_time
        FROM game_results
        WHERE student_id = ?
    ");
    $statsStmt->execute([$studentId]);
    $gameStats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    // آمار هر موضوع
    $subjectStatsStmt = $conn->prepare("
        SELECT 
            g.subject,
            COUNT(*) as games_count,
            AVG(gr.score) as avg_score,
            MAX(gr.score) as best_score,
            AVG(gr.accuracy) as avg_accuracy
        FROM game_results gr
        JOIN games g ON gr.game_id = g.id
        WHERE gr.student_id = ?
        GROUP BY g.subject
        ORDER BY games_count DESC
    ");
    $subjectStatsStmt->execute([$studentId]);
    $subjectStats = $subjectStatsStmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    die('خطا در تولید گزارش: ' . $e->getMessage());
}

// تابع تبدیل تاریخ میلادی به شمسی
function toJalali($timestamp) {
    if (!$timestamp) return 'نامشخص';
    
    $date = new DateTime($timestamp);
    $year = (int)$date->format('Y');
    $month = (int)$date->format('m');
    $day = (int)$date->format('d');
    $hour = $date->format('H');
    $minute = $date->format('i');
    
    // تبدیل ساده میلادی به شمسی
    $jYear = $year - 621;
    $jMonth = $month;
    $jDay = $day;
    
    // اصلاح تقریبی
    if ($month > 3) {
        $jMonth = $month - 3;
    } else {
        $jMonth = $month + 9;
        $jYear--;
    }
    
    $monthNames = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];
    
    return "$jDay {$monthNames[$jMonth]} $jYear - $hour:$minute";
}

// تنظیم هدرها برای دانلود Excel
$filename = 'گزارش-' . $student['first_name'] . '-' . $student['last_name'] . '-' . date('Y-m-d') . '.xls';

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');

// UTF-8 BOM
echo "\xEF\xBB\xBF";
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <style>
        body { 
            direction: rtl; 
            font-family: Tahoma, Arial; 
            font-size: 12px;
        }
        table { 
            border-collapse: collapse; 
            width: 100%; 
            margin: 10px 0;
        }
        th, td { 
            border: 1px solid #333; 
            padding: 8px; 
            text-align: center; 
        }
        th { 
            background-color: #4CAF50; 
            color: white; 
            font-weight: bold; 
        }
        .header { 
            background-color: #2196F3; 
            color: white; 
            font-size: 18px; 
            font-weight: bold; 
            text-align: center; 
            padding: 15px; 
        }
        .section-header {
            background-color: #FF9800;
            color: white;
            font-weight: bold;
        }
        .subject-math { background-color: #ffebee; }
        .subject-science { background-color: #e8f5e8; }
        .subject-persian { background-color: #e3f2fd; }
        .subject-social { background-color: #fce4ec; }
        .subject-religion { background-color: #e0f2f1; }
        .highlight { background-color: #fff3cd; font-weight: bold; }
    </style>
</head>

<body>
    <!-- عنوان گزارش -->
    <table>
        <tr>
            <td class="header" colspan="6">
                🎓 گزارش کامل پیشرفت تحصیلی<br>
                <?php echo $student['first_name'] . ' ' . $student['last_name']; ?>
            </td>
        </tr>
    </table>

    <!-- اطلاعات شخصی -->
    <table>
        <tr>
            <th colspan="4" class="section-header">📋 اطلاعات شخصی</th>
        </tr>
        <tr>
            <th>نام و نام خانوادگی</th>
            <td><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></td>
            <th>کد ملی</th>
            <td><?php echo $student['national_id']; ?></td>
        </tr>
        <tr>
            <th>تاریخ ثبت‌نام</th>
            <td><?php echo toJalali($student['registration_date']); ?></td>
            <th>آخرین فعالیت</th>
            <td><?php echo $student['updated_at'] ? toJalali($student['updated_at']) : 'هرگز'; ?></td>
        </tr>
    </table>

    <!-- آمار کلی -->
    <table>
        <tr>
            <th colspan="4" class="section-header">📊 آمار کلی عملکرد</th>
        </tr>
        <tr>
            <th>رنک کلی</th>
            <td class="highlight"><?php echo $rank; ?> از <?php echo $totalStudents; ?></td>
            <th>سطح فعلی</th>
            <td class="highlight"><?php echo $student['level']; ?></td>
        </tr>
        <tr>
            <th>کل امتیاز XP</th>
            <td class="highlight"><?php echo number_format($student['total_xp']); ?></td>
            <th>تعداد بازی انجام شده</th>
            <td><?php echo $gameStats['total_games'] ?: 0; ?></td>
        </tr>
        <tr>
            <th>میانگین امتیاز</th>
            <td><?php echo $gameStats['avg_score'] ? round($gameStats['avg_score']) : 0; ?></td>
            <th>بهترین امتیاز</th>
            <td class="highlight"><?php echo $gameStats['best_score'] ?: 0; ?></td>
        </tr>
        <tr>
            <th>میانگین دقت</th>
            <td><?php echo $gameStats['avg_accuracy'] ? round($gameStats['avg_accuracy']) . '%' : '0%'; ?></td>
            <th>کل زمان بازی</th>
            <td><?php echo $gameStats['total_time'] ? gmdate("H:i:s", $gameStats['total_time']) : '00:00:00'; ?></td>
        </tr>
    </table>

    <!-- امتیازات موضوعی -->
    <table>
        <tr>
            <th colspan="3" class="section-header">📚 امتیازات موضوعی</th>
        </tr>
        <tr>
            <th>موضوع</th>
            <th>امتیاز XP</th>
            <th>درصد از کل</th>
        </tr>
        <?php
        $subjects = [
            'math' => ['name' => '🔢 ریاضی', 'xp' => $student['math_xp'], 'class' => 'subject-math'],
            'science' => ['name' => '🔬 علوم', 'xp' => $student['science_xp'], 'class' => 'subject-science'],
            'persian' => ['name' => '📖 فارسی', 'xp' => $student['persian_xp'], 'class' => 'subject-persian'],
            'social' => ['name' => '🌍 اجتماعی', 'xp' => $student['social_xp'], 'class' => 'subject-social'],
            'religion' => ['name' => '📿 دینی', 'xp' => $student['religion_xp'], 'class' => 'subject-religion']
        ];
        
        foreach ($subjects as $key => $subject):
            $percentage = $student['total_xp'] > 0 ? round(($subject['xp'] / $student['total_xp']) * 100, 1) : 0;
        ?>
        <tr class="<?php echo $subject['class']; ?>">
            <td style="font-weight: bold;"><?php echo $subject['name']; ?></td>
            <td style="font-weight: bold;"><?php echo number_format($subject['xp']); ?></td>
            <td><?php echo $percentage; ?>%</td>
        </tr>
        <?php endforeach; ?>
    </table>

    <!-- آمار موضوعی بازی‌ها -->
    <?php if (!empty($subjectStats)): ?>
    <table>
        <tr>
            <th colspan="5" class="section-header">🎮 آمار بازی‌ها به تفکیک موضوع</th>
        </tr>
        <tr>
            <th>موضوع</th>
            <th>تعداد بازی</th>
            <th>میانگین امتیاز</th>
            <th>بهترین امتیاز</th>
            <th>میانگین دقت</th>
        </tr>
        <?php foreach ($subjectStats as $stat): 
            $subjectNames = [
                'math' => '🔢 ریاضی',
                'science' => '🔬 علوم',
                'persian' => '📖 فارسی',
                'social' => '🌍 اجتماعی',
                'religion' => '📿 دینی'
            ];
            $subjectName = $subjectNames[$stat['subject']] ?? $stat['subject'];
        ?>
        <tr>
            <td style="font-weight: bold;"><?php echo $subjectName; ?></td>
            <td><?php echo $stat['games_count']; ?></td>
            <td><?php echo round($stat['avg_score']); ?></td>
            <td class="highlight"><?php echo $stat['best_score']; ?></td>
            <td><?php echo round($stat['avg_accuracy']); ?>%</td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>

    <!-- تاریخچه کامل بازی‌ها -->
    <?php if (!empty($gameHistory)): ?>
    <table>
        <tr>
            <th colspan="6" class="section-header">📝 تاریخچه کامل بازی‌ها</th>
        </tr>
        <tr>
            <th>ردیف</th>
            <th>نام بازی</th>
            <th>موضوع</th>
            <th>امتیاز</th>
            <th>دقت</th>
            <th>تاریخ و زمان</th>
        </tr>
        <?php foreach ($gameHistory as $index => $game): 
            $subjectNames = [
                'math' => '🔢 ریاضی',
                'science' => '🔬 علوم',
                'persian' => '📖 فارسی',
                'social' => '🌍 اجتماعی',
                'religion' => '📿 دینی'
            ];
            $subjectName = $subjectNames[$game['subject']] ?? $game['subject'];
        ?>
        <tr>
            <td><?php echo $index + 1; ?></td>
            <td><?php echo htmlspecialchars($game['game_title']); ?></td>
            <td><?php echo $subjectName; ?></td>
            <td class="highlight"><?php echo $game['score']; ?></td>
            <td><?php echo round($game['accuracy']); ?>%</td>
            <td><?php echo toJalali($game['completed_at']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php else: ?>
    <table>
        <tr>
            <th colspan="6" class="section-header">📝 تاریخچه بازی‌ها</th>
        </tr>
        <tr>
            <td colspan="6" style="text-align: center; padding: 30px; color: #666;">
                هیچ بازی انجام نشده است
            </td>
        </tr>
    </table>
    <?php endif; ?>

    <!-- اطلاعات گزارش -->
    <table>
        <tr>
            <th colspan="2" class="section-header">ℹ️ اطلاعات گزارش</th>
        </tr>
        <tr>
            <td style="font-weight: bold;">تاریخ تولید گزارش</td>
            <td><?php echo toJalali(date('Y-m-d H:i:s')); ?></td>
        </tr>
        <tr>
            <td style="font-weight: bold;">نام فایل</td>
            <td><?php echo $filename; ?></td>
        </tr>
        <tr>
            <td style="font-weight: bold;">تولید شده توسط</td>
            <td>سیستم مدیریت یادگیری</td>
        </tr>
        <tr>
            <td style="font-weight: bold;">تعداد کل رکوردها</td>
            <td><?php echo count($gameHistory); ?> بازی</td>
        </tr>
    </table>

</body>
</html>