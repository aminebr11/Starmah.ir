<?php
$host = 'localhost:3306';
$user = 'qwaepiuv_aminebr';
$pass = 'Test12345!@#';
$dbname = 'qwaepiuv_starmah_db';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>