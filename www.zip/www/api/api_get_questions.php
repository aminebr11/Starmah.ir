<?php
header("Content-Type: application/json");

// اتصال به دیتابیس
$conn = new mysqli("localhost", "your_db_user", "your_db_pass", "qwaepiuv_starmah_db");
$conn->set_charset("utf8");

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

// اجرای Query
$result = $conn->query("SELECT * FROM question_bank");

// جمع‌آوری داده‌ها
$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}

// خروجی JSON
echo json_encode(["data" => $questions]);
?>