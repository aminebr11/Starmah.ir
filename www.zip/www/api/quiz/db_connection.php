<?php
// تنظیمات اتصال
define('DB_HOST', 'localhost:3306');
define('DB_NAME', 'qwaepiuv_starmah_db');
define('DB_USER', 'qwaepiuv_aminebr');
define('DB_PASS', 'Test12345!@#');

// اتصال با استفاده از mysqli
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// بررسی خطای اتصال
if ($conn->connect_error) {
    die("❌ خطا در اتصال به دیتابیس: " . $conn->connect_error);
}

// تنظیم charset برای پشتیبانی از فارسی
$conn->set_charset("utf8mb4");
?>