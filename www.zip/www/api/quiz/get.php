<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php'; // اتصال به دیتابیس از طریق PDO
header('Content-Type: application/json; charset=utf-8');

try {
    // ✅ دریافت شناسه آزمون از پارامتر GET
    $quiz_id = $_GET['id'] ?? null;
    if (!$quiz_id || !is_numeric($quiz_id)) {
        http_response_code(400);
        echo json_encode(["error" => "شناسه آزمون معتبر نیست"], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ✅ دریافت اطلاعات آزمون
    $stmt = $conn->prepare("SELECT id AS quiz_id, title, description, duration_seconds FROM quizzes WHERE id = ?");
    $stmt->execute([$quiz_id]);
    $quiz = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$quiz) {
        http_response_code(404);
        echo json_encode(["error" => "آزمون پیدا نشد"], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 🎯 تبدیل مدت زمان از ثانیه به دقیقه
    $quiz['duration_minutes'] = ceil($quiz['duration_seconds'] / 60);
    unset($quiz['duration_seconds']);

    // ✅ دریافت سوالات آزمون
    $stmt = $conn->prepare("SELECT id, question_text AS text FROM questions WHERE quiz_id = ? ORDER BY question_order ASC");
    $stmt->execute([$quiz_id]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($questions)) {
        $quiz['questions'] = [];
        echo json_encode($quiz, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    // ✅ دریافت گزینه‌های تمام سوالات در یک کوئری با IN(...)
    $question_ids = array_column($questions, 'id');
    $placeholders = implode(',', array_fill(0, count($question_ids), '?'));
    $sql = "SELECT id AS choice_id, question_id, choice_text AS text FROM choices WHERE question_id IN ($placeholders) ORDER BY choice_order ASC";
    $stmt = $conn->prepare($sql);

    // bind each question ID
    foreach ($question_ids as $i => $qid) {
        $stmt->bindValue($i + 1, $qid, PDO::PARAM_INT);
    }

    $stmt->execute();
    $choices = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ✅ گروه‌بندی گزینه‌ها براساس سوال‌ها
    $grouped = [];
    foreach ($choices as $c) {
        $grouped[$c['question_id']][] = [
            "id" => $c['choice_id'],
            "text" => $c['text']
        ];
    }

    // ✅ اضافه کردن گزینه‌ها به سوال‌ها
    foreach ($questions as &$q) {
        $q['choices'] = $grouped[$q['id']] ?? [];
    }

    // 📤 خروجی نهایی JSON
    $quiz['questions'] = $questions;
    echo json_encode($quiz, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "error" => "خطای داخلی سرور",
        "message" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}