<?php
// اتصال به دیتابیس
require_once '../config/db.php'; // مسیر مناسب برای پروژه‌ی شما را تنظیم کن

header('Content-Type: application/json');

// بررسی نوع درخواست
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405); // Method Not Allowed
  echo json_encode(['success' => false, 'error' => 'Only POST method allowed']);
  exit;
}

// دریافت داده‌ها
$data = json_decode(file_get_contents('php://input'), true);

// گرفتن متغیرها
$examId    = isset($data['examId']) ? intval($data['examId']) : 0;
$startTime = isset($data['startTime']) ? trim($data['startTime']) : null;
$endTime   = isset($data['endTime']) ? trim($data['endTime']) : null;

// اعتبارسنجی اولیه
if ($examId <= 0) {
  echo json_encode(['success' => false, 'error' => 'Invalid exam ID']);
  exit;
}

// آماده‌سازی کوئری
try {
  $stmt = $pdo->prepare("UPDATE exams SET start_time = :start, end_time = :end WHERE id = :id");

  // اگر هر کدام از زمان‌ها حذف شده باشه، مقدار NULL قرار بده
  $stmt->bindValue(':start', $startTime ? $startTime : null);
  $stmt->bindValue(':end',   $endTime   ? $endTime   : null);
  $stmt->bindValue(':id', $examId, PDO::PARAM_INT);

  $success = $stmt->execute();

  echo json_encode(['success' => $success]);
} catch (Exception $e) {
  http_response_code(500); // Internal Server Error
  echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
