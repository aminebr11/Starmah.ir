<?php
// نمایش خطاها برای دیباگ
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تنظیم نوع خروجی
header('Content-Type: application/json');

// اتصال به دیتابیس
require_once 'config-lite.php';

// بررسی اتصال
if (!$conn || $conn->connect_error) {
    echo json_encode([
        'status' => 'error',
        'message' => 'اتصال به پایگاه‌داده برقرار نشد'
    ]);
    exit;
}

// دریافت شناسه آزمون از GET
$quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;

if ($quiz_id <= 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'شناسه آزمون نامعتبر است'
    ]);
    exit;
}

// اجرای کوئری برای دریافت سوالات
$sql = "SELECT id, question_text FROM questions WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        'status' => 'error',
        'message' => 'آماده‌سازی کوئری ناموفق بود'
    ]);
    exit;
}

$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}

// خروجی نهایی
echo json_encode([
    'status' => 'success',
    'quiz_id' => $quiz_id,
    'questions' => $questions,
    'count' => count($questions)
]);
?>