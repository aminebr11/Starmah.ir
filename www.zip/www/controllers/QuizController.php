<?php
require_once 'models/QuizModel.php';

class QuizController {
    public function getQuizDetails($quiz_id) {
        header('Content-Type: application/json; charset=utf-8');
        $model = new QuizModel();
        $quiz = $model->getQuiz($quiz_id);
        if (!$quiz) {
            http_response_code(404);
            echo json_encode(["error" => "آزمون پیدا نشد"]);
            return;
        }

        $questions = $model->getQuestions($quiz_id);
        $choices = $model->getChoicesForQuestions(array_column($questions, 'id'));

        foreach ($questions as &$q) {
            $q['choices'] = array_values(array_filter($choices, fn($c) => $c['question_id'] == $q['id']));
        }

        $quiz['questions'] = $questions;
        echo json_encode($quiz, JSON_UNESCAPED_UNICODE);
    }
}