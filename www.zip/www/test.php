<?php
// نمایش همه خطاها
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>تست آپلود لوگو</title>
    <style>
        body { font-family: Tahoma; padding: 20px; background: #f0f0f0; }
        .box { background: white; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto; }
        .error { background: #ffe0e0; padding: 10px; border-radius: 5px; color: red; }
        .success { background: #e0ffe0; padding: 10px; border-radius: 5px; color: green; }
        pre { background: #333; color: #fff; padding: 10px; border-radius: 5px; overflow: auto; direction: ltr; text-align: left; }
    </style>
</head>
<body>
<div class="box">
    <h2>🧪 تست آپلود لوگو</h2>
    
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['logo'])) {
        echo "<h3>نتیجه آپلود:</h3>";
        
        try {
            echo "<p><strong>اطلاعات فایل:</strong></p>";
            echo "<pre>" . print_r($_FILES['logo'], true) . "</pre>";
            
            $file = $_FILES['logo'];
            
            if ($file['error'] !== UPLOAD_ERR_OK) {
                throw new Exception("خطای آپلود: کد " . $file['error']);
            }
            
            $uploadDir = __DIR__ . '/uploads/logos/';
            echo "<p>پوشه مقصد: <code>$uploadDir</code></p>";
            
            // بررسی پوشه
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0755, true);
                echo "<p class='success'>پوشه ایجاد شد</p>";
            }
            
            // نوع فایل - روش ساده
            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            echo "<p>پسوند فایل: <code>$extension</code></p>";
            
            // نام جدید - روش ساده بدون random_bytes
            $newFileName = 'logo_' . time() . '_' . mt_rand(1000, 9999) . '.' . $extension;
            $targetPath = $uploadDir . $newFileName;
            echo "<p>نام جدید: <code>$newFileName</code></p>";
            
            // انتقال فایل
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                echo "<p class='success'>✅ فایل با موفقیت آپلود شد!</p>";
                echo "<p>مسیر: <code>uploads/logos/$newFileName</code></p>";
                echo "<p><img src='uploads/logos/$newFileName' style='max-width:200px;border:1px solid #ccc;'></p>";
            } else {
                throw new Exception("خطا در انتقال فایل");
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>❌ " . $e->getMessage() . "</p>";
        }
    }
    ?>
    
    <form method="POST" enctype="multipart/form-data">
        <p>
            <label>انتخاب تصویر:</label><br>
            <input type="file" name="logo" accept="image/*" required style="margin-top:10px;">
        </p>
        <button type="submit" style="background:#667eea;color:white;padding:10px 20px;border:none;border-radius:5px;cursor:pointer;">
            📤 آپلود تست
        </button>
    </form>
    
    <hr style="margin:20px 0;">
    <p><a href="index.php">← بازگشت به سیستم آزمون</a></p>
</div>
</body>
</html>