// Enhanced JavaScript for Star-Moon Educational Website with a fully functional Mobile Menu
document.addEventListener('DOMContentLoaded', function() {

    // --- Mobile Menu System ---
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const mobileDropdown = document.getElementById('mobileDropdown');
    const menuOverlay = document.getElementById('menuOverlay');

    // Check if all required menu elements exist
    if (!mobileBtn || !mobileDropdown || !menuOverlay) {
        console.error('Mobile menu elements not found! Please ensure mobileMenuBtn, mobileDropdown, and menuOverlay IDs exist in the HTML.');
        return; // Stop execution if menu can't function
    }

    // Function to open the mobile menu
    function openMobileMenu() {
        mobileBtn.classList.add('active');
        mobileBtn.setAttribute('aria-expanded', 'true');
        mobileDropdown.classList.add('show');
        menuOverlay.classList.add('show');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    }

    // Function to close the mobile menu
    function closeMobileMenu() {
        mobileBtn.classList.remove('active');
        mobileBtn.setAttribute('aria-expanded', 'false');
        mobileDropdown.classList.remove('show');
        menuOverlay.classList.remove('show');
        document.body.style.overflow = ''; // Restore background scrolling
    }

    // Event listener for the menu button (click and touch)
    mobileBtn.addEventListener('click', function(e) {
        e.stopPropagation(); // Prevent click from bubbling up to the document
        if (mobileDropdown.classList.contains('show')) {
            closeMobileMenu();
        } else {
            openMobileMenu();
        }
    });

    // Close menu when clicking the overlay
    menuOverlay.addEventListener('click', closeMobileMenu);

    // Close menu when clicking a link inside the dropdown
    mobileDropdown.addEventListener('click', function(e) {
        // Check if the clicked element is a link
        if (e.target.tagName === 'A') {
            closeMobileMenu();
        }
    });

    // Close menu when pressing the Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mobileDropdown.classList.contains('show')) {
            closeMobileMenu();
        }
    });

    // --- Enhanced Section Switching ---
    window.showSection = function(sectionId) {
        // A link was clicked, so we should close the mobile menu if it's open
        if (mobileDropdown.classList.contains('show')) {
            closeMobileMenu();
        }

        const loading = document.getElementById('loading');
        if (loading) {
            loading.classList.add('active');
        }

        // Delay for a smoother transition
        setTimeout(() => {
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });

            // Show the target section
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.add('active');
            } else {
                // Fallback to the home section if the target doesn't exist
                const homeSection = document.getElementById('home');
                if (homeSection) {
                    homeSection.classList.add('active');
                }
            }

            // Remove loading indicator after a short delay
            if (loading) {
                setTimeout(() => {
                    loading.classList.remove('active');
                }, 300);
            }
        }, 200);

        console.log('Navigating to section:', sectionId);
    }

    // --- Enhanced Star Animation ---
    function createStars() {
        const starsContainer = document.getElementById('stars');
        if (!starsContainer) return;

        starsContainer.innerHTML = ''; // Clear existing stars
        const starTypes = ['⭐', '✨', '🌟', '💫'];
        const numberOfStars = window.innerWidth < 768 ? 40 : 70; // Adjust count for performance

        for (let i = 0; i < numberOfStars; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            
            // Add variety with different star characters
            if (Math.random() > 0.7) {
                star.innerHTML = starTypes[Math.floor(Math.random() * starTypes.length)];
                star.style.fontSize = Math.random() * 10 + 8 + 'px';
                star.style.background = 'transparent';
            }
            
            star.style.top = Math.random() * 100 + '%';
            star.style.left = Math.random() * 100 + '%';
            star.style.animationDelay = Math.random() * 5 + 's';
            star.style.animationDuration = (Math.random() * 4 + 3) + 's';
            
            starsContainer.appendChild(star);
        }
    }

    // --- Login Type Selector ---
    window.setLoginType = function(type) {
        const buttons = document.querySelectorAll('.login-type-btn');
        const hiddenInput = document.getElementById('loginUserType');
        
        buttons.forEach(btn => btn.classList.remove('active'));
        if (event && event.target) {
            event.target.classList.add('active');
        }
        
        if (hiddenInput) {
            hiddenInput.value = type;
        }
    }

    // --- Simple Form Validation Feedback ---
    function setupFormValidation() {
        const forms = document.querySelectorAll('form[novalidate]');
        
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const inputs = this.querySelectorAll('input[required], textarea[required]');
                let isValid = true;
                
                inputs.forEach(input => {
                    input.style.borderColor = ''; // Reset style
                    if (!input.value.trim()) {
                        isValid = false;
                        input.style.borderColor = '#ff6b6b';
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    // Consider adding a user-friendly alert message here
                    console.warn('Form submission blocked: Please fill all required fields.');
                }
            });
        });
    }

    // --- Admin Panel Tab Switching ---
    window.showAdminTab = function(tabName) {
        document.querySelectorAll('.admin-section').forEach(section => {
            section.style.display = 'none';
        });
        
        document.querySelectorAll('.admin-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        const targetSection = document.getElementById(tabName);
        if (targetSection) {
            targetSection.style.display = 'block';
        }
        
        if (event && event.target) {
            event.target.classList.add('active');
        }
    }

    // --- Debounced Resize Handler ---
    function debounce(func, wait = 20, immediate = true) {
        let timeout;
        return function() {
            const context = this, args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // --- Initialization ---
    function initialize() {
        createStars();
        setupFormValidation();
        
        // Ensure the correct menu is displayed on load
        if (window.innerWidth <= 992) { // Corresponds to the new CSS breakpoint
             if(document.querySelector('.desktop-menu')) document.querySelector('.desktop-menu').style.display = 'none';
             if(document.querySelector('.mobile-menu-container')) document.querySelector('.mobile-menu-container').style.display = 'block';
        } else {
             if(document.querySelector('.desktop-menu')) document.querySelector('.desktop-menu').style.display = 'flex';
             if(document.querySelector('.mobile-menu-container')) document.querySelector('.mobile-menu-container').style.display = 'none';
        }

        // Add a debounced resize listener for performance
        window.addEventListener('resize', debounce(() => {
            if (window.innerWidth <= 992) {
                if(document.querySelector('.desktop-menu')) document.querySelector('.desktop-menu').style.display = 'none';
                if(document.querySelector('.mobile-menu-container')) document.querySelector('.mobile-menu-container').style.display = 'block';
            } else {
                if(document.querySelector('.desktop-menu')) document.querySelector('.desktop-menu').style.display = 'flex';
                if(document.querySelector('.mobile-menu-container')) document.querySelector('.mobile-menu-container').style.display = 'none';
                closeMobileMenu(); // Close mobile menu when switching to desktop view
            }
        }));

        // Show the home section by default on initial load
        if (typeof showSection === 'function') {
            showSection('home');
        }

        // FIX: Prevent 'style' has already been declared error by using a unique variable name
        if (!document.getElementById('dynamic-styles')) {
            const dynamicGlobalStyles = document.createElement('style');
            dynamicGlobalStyles.id = 'dynamic-styles';
            dynamicGlobalStyles.textContent = `
                .page-loaded .hero {
                    animation: heroEntrance 1s ease-out;
                }
                
                @keyframes heroEntrance {
                    0% {
                        opacity: 0;
                        transform: scale(0.9) translateY(50px);
                    }
                    100% {
                        opacity: 1;
                        transform: scale(1) translateY(0);
                    }
                }
                
                .floating-action {
                    animation: floatingAction 3s ease-in-out infinite;
                }
                
                @keyframes floatingAction {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-10px); }
                }
            `;
            document.head.appendChild(dynamicGlobalStyles);
        }
        
        console.log('🌟 Star-Moon website initialized successfully!');
    }

   // اضافه کردن این کدها به انتهای script.js یا در script tag صفحه

// کپی کد ملی به نام کاربری
document.addEventListener('DOMContentLoaded', function() {
    const nationalIdInput = document.getElementById('nationalId');
    const usernameInput = document.getElementById('username');
    
    if (nationalIdInput && usernameInput) {
        nationalIdInput.addEventListener('input', function() {
            const nationalId = this.value.replace(/[^0-9]/g, ''); // فقط عدد
            if (nationalId.length <= 10) {
                this.value = nationalId;
                usernameInput.value = nationalId;
                
                // تغییر رنگ بر اساس طول
                if (nationalId.length === 10) {
                    usernameInput.style.backgroundColor = 'rgba(107, 207, 127, 0.3)';
                    usernameInput.style.borderColor = '#6bcf7f';
                } else {
                    usernameInput.style.backgroundColor = 'rgba(255, 217, 61, 0.2)';
                    usernameInput.style.borderColor = '#ffd93d';
                }
            } else {
                this.value = nationalId.slice(0, 10);
            }
        });
        
        // جلوگیری از ورود غیر عددی
        nationalIdInput.addEventListener('keypress', function(e) {
            if (!/[0-9]/.test(e.key) && !['Backspace', 'Delete', 'Tab', 'Enter'].includes(e.key)) {
                e.preventDefault();
            }
        });
    }
});

// تابع تغییر نوع ورود (دانش آموز/معلم)
function setLoginType(type) {
    const studentBtn = document.querySelector('button[onclick="setLoginType(\'student\')"]');
    const teacherBtn = document.querySelector('button[onclick="setLoginType(\'teacher\')"]');
    const usernameInput = document.getElementById('loginUsername');
    const userTypeInput = document.getElementById('loginUserType');
    
    if (!studentBtn || !teacherBtn) return;
    
    // تغییر حالت دکمه‌ها
    studentBtn.classList.remove('active');
    teacherBtn.classList.remove('active');
    
    if (type === 'student') {
        studentBtn.classList.add('active');
        if (usernameInput) usernameInput.placeholder = 'کد ملی خود را وارد کنید';
        if (userTypeInput) userTypeInput.value = 'student';
    } else {
        teacherBtn.classList.add('active');
        if (usernameInput) usernameInput.placeholder = 'نام کاربری: admin';
        if (userTypeInput) userTypeInput.value = 'admin';
    }
}

// تقویم شمسی (در صورت وجود)
if (typeof $ !== 'undefined' && $.fn.pDatepicker) {
    $(document).ready(function() {
        $("#birthDate").pDatepicker({
            format: 'YYYY/MM/DD',
            autoClose: true,
            initialValue: false
        });
    });
}

// تابع باز کردن تقویم
function openDatePicker() {
    const birthDateInput = document.getElementById('birthDate');
    if (birthDateInput) {
        birthDateInput.focus();
        birthDateInput.click();
    }
}

console.log('✅ کدهای جدید بارگذاری شد');
    // Run initialization
    initialize();
    /* footer یا script.js */
window.sendListeningXP = function (podcastId, duration) {
  console.log('Sending XP for podcast:', podcastId, 'duration:', duration);
  return fetch('ajax/add-listening-xp.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ podcast_id: podcastId, listening_duration: duration })
  })
  .then(r => r.json())
  .then(data => {
      if (data.success && typeof showAlert === 'function') {
          showAlert('success', `🎉 شما ${data.xp_earned} امتیاز گرفتید!`);
      }
  })
  .catch(e => console.error('XP error:', e));
};
});
// غیرفعال کردن اعتبارسنجی عمومی برای فرم ویرایش
(function() {
    const editForm = document.getElementById('editProfileForm');
    if (editForm) {
        // حذف اعتبارسنجی پیش‌فرض
        editForm.setAttribute('novalidate', 'novalidate');
        
        // جلوگیری از دخالت script.js
        editForm.addEventListener('submit', function(e) {
            e.stopImmediatePropagation();
        }, true); // capture phase
    }
})();

