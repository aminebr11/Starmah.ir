<?php
session_start();

// اتصال به دیتابیس و ثبت خروج
if (isset($_SESSION['user_id'])) {
    require_once 'config.php';
    
    $user_id = $_SESSION['user_id'];
    
    try {
        // ثبت رکورد خروج با زمان دقیق فعلی
        $stmt = $conn->prepare("INSERT INTO visits (user_id, ip_address, user_agent, visit_date) VALUES (?, ?, ?, NOW())");
        $stmt->execute([
            $user_id,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'LOGOUT - IMMEDIATE' // علامت واضح برای logout
        ]);
        
        // ثبت یک رکورد اضافی 5 دقیقه در گذشته تا مطمئن شویم
        $stmt2 = $conn->prepare("INSERT INTO visits (user_id, ip_address, user_agent, visit_date) VALUES (?, ?, ?, DATE_SUB(NOW(), INTERVAL 5 MINUTE))");
        $stmt2->execute([
            $user_id,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'LOGOUT - CLEANUP'
        ]);
        
    } catch (PDOException $e) {
        error_log("Logout recording error: " . $e->getMessage());
    }
}

// پاک کردن تمام متغیرهای session
$_SESSION = array();

// نابود کردن کوکی session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// نابود کردن session
session_destroy();

// هدایت به صفحه اصلی با پیام خروج
header("Location: index.php?message=" . urlencode("با موفقیت از حساب خود خارج شدید") . "&type=success");
exit;
?>