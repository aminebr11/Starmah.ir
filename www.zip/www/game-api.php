<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once 'config.php';

$game_id = (int)($_GET['id'] ?? 0);

try {
    $stmt = $conn->prepare("SELECT * FROM games WHERE id = ? AND is_active = 1");
    $stmt->bind_param('i', $game_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $game = $result->fetch_assoc();
    
    if ($game) {
        echo json_encode(['success' => true, 'game' => $game]);
    } else {
        echo json_encode(['success' => false, 'message' => 'بازی یافت نشد']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطای دیتابیس']);
}
?>