<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

if (!isAdmin()) {
    header('Location: login.php');
    exit();
}

$gameId = $_GET['id'] ?? null;
if (!$gameId) {
    header('Location: index.php?section=admin&tab=games');
    exit();
}

// دریافت اطلاعات بازی
try {
    $stmt = $conn->prepare("
        SELECT g.*, 
               COALESCE(gc.name, g.subject) as subject_name,
               COALESCE(gc.icon, '📚') as subject_icon
        FROM games g
        LEFT JOIN game_categories gc ON g.subject = gc.name
        WHERE g.id = ?
    ");
    $stmt->execute([$gameId]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$game) {
        throw new Exception('بازی یافت نشد');
    }
    
    // دریافت تمام نتایج با جزئیات کامل
    $stmt = $conn->prepare("
        SELECT gr.*, u.first_name, u.last_name, u.national_id,
               s.total_score as student_total_score, s.class_rank
        FROM game_results gr
        JOIN users u ON gr.student_id = u.id
        LEFT JOIN students s ON u.id = s.user_id
        WHERE gr.game_id = ?
        ORDER BY gr.score DESC, gr.time_spent ASC, gr.completed_at ASC
    ");
    $stmt->execute([$gameId]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // محاسبه آمار پیشرفته
    $totalPlays = count($results);
    if ($totalPlays > 0) {
        $scores = array_column($results, 'score');
        $times = array_column($results, 'time_spent');
        $accuracies = array_column($results, 'accuracy');
        
        $avgScore = array_sum($scores) / $totalPlays;
        $highestScore = max($scores);
        $lowestScore = min($scores);
        $avgTime = array_sum($times) / $totalPlays;
        $avgAccuracy = array_sum($accuracies) / $totalPlays;
        
        // محاسبه میانه
        sort($scores);
        $medianScore = $totalPlays % 2 == 0 
            ? ($scores[$totalPlays/2 - 1] + $scores[$totalPlays/2]) / 2
            : $scores[floor($totalPlays/2)];
            
        // تشخیص سطح عملکرد
        $excellentCount = count(array_filter($scores, fn($s) => $s >= 80));
        $goodCount = count(array_filter($scores, fn($s) => $s >= 60 && $s < 80));
        $averageCount = count(array_filter($scores, fn($s) => $s >= 40 && $s < 60));
        $weakCount = count(array_filter($scores, fn($s) => $s < 40));
        
        // دانش‌آموزان برتر و ضعیف
        $topPerformers = array_slice($results, 0, 5);
        $weakPerformers = array_slice($results, -5);
        if ($totalPlays <= 5) {
            $weakPerformers = array_slice($results, max(0, $totalPlays - min(3, $totalPlays)));
        }
    } else {
        $avgScore = $highestScore = $lowestScore = $avgTime = $avgAccuracy = $medianScore = 0;
        $excellentCount = $goodCount = $averageCount = $weakCount = 0;
        $topPerformers = $weakPerformers = [];
    }
    
    // دریافت آمار بر اساس زمان
    $stmt = $conn->prepare("
        SELECT DATE(completed_at) as play_date, 
               COUNT(*) as daily_plays,
               AVG(score) as daily_avg_score
        FROM game_results 
        WHERE game_id = ? 
        GROUP BY DATE(completed_at) 
        ORDER BY play_date DESC 
        LIMIT 7
    ");
    $stmt->execute([$gameId]);
    $dailyStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>گزارش تحلیلی: <?php echo htmlspecialchars($game['title'] ?? 'نامشخص'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: rgba(255,255,255,0.98);
            border-radius: 25px;
            padding: 2rem;
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
        }
        
        .header {
            text-align: center;
            margin-bottom: 3rem;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: repeating-linear-gradient(
                45deg,
                transparent,
                transparent 10px,
                rgba(255,255,255,0.05) 10px,
                rgba(255,255,255,0.05) 20px
            );
            animation: slide 20s linear infinite;
        }
        
        @keyframes slide {
            0% { transform: translate(-50%, -50%); }
            100% { transform: translate(-40%, -40%); }
        }
        
        .header-content {
            position: relative;
            z-index: 2;
        }
        
        .game-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .game-subject {
            font-size: 1.3rem;
            opacity: 0.9;
            margin-bottom: 1rem;
        }
        
        .report-date {
            font-size: 1rem;
            opacity: 0.8;
        }
        
        .section {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: 1px solid rgba(102, 126, 234, 0.1);
        }
        
        .section-title {
            font-size: 1.8rem;
            font-weight: 800;
            color: #333;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 3px solid #667eea;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .section-icon {
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 2rem;
            border-radius: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover::before {
            transform: scale(1.5);
        }
        
        .stat-content {
            position: relative;
            z-index: 2;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .stat-label {
            font-size: 1rem;
            opacity: 0.9;
            font-weight: 600;
        }
        
        .performance-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        
        .performance-card {
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            font-weight: 700;
            color: white;
            position: relative;
        }
        
        .performance-excellent {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .performance-good {
            background: linear-gradient(135deg, #17a2b8, #138496);
        }
        
        .performance-average {
            background: linear-gradient(135deg, #ffc107, #e0a800);
        }
        
        .performance-weak {
            background: linear-gradient(135deg, #dc3545, #c82333);
        }
        
        .performance-number {
            font-size: 2rem;
            display: block;
            margin-bottom: 0.5rem;
        }
        
        .students-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin: 2rem 0;
        }
        
        .students-section {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 20px;
            padding: 1.5rem;
            border: 2px solid;
        }
        
        .top-students {
            border-color: #28a745;
        }
        
        .weak-students {
            border-color: #dc3545;
        }
        
        .student-item {
            background: white;
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }
        
        .student-item:hover {
            transform: translateX(5px);
        }
        
        .student-info {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
        }
        
        .student-name {
            font-weight: 700;
            color: #333;
            font-size: 1.1rem;
        }
        
        .student-details {
            font-size: 0.9rem;
            color: #666;
        }
        
        .student-score {
            font-size: 1.5rem;
            font-weight: 800;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            color: white;
        }
        
        .score-excellent { background: #28a745; }
        .score-good { background: #17a2b8; }
        .score-average { background: #ffc107; color: #333; }
        .score-weak { background: #dc3545; }
        
        .rank-badge {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.2rem;
            color: white;
        }
        
        .rank-1 { background: #ffd700; color: #333; }
        .rank-2 { background: #c0c0c0; color: #333; }
        .rank-3 { background: #cd7f32; }
        
        .results-table {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-top: 2rem;
        }
        
        .results-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .results-table th {
            background: linear-gradient(135deg, #333, #555);
            color: white;
            padding: 1.5rem 1rem;
            text-align: right;
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .results-table td {
            padding: 1rem;
            border-bottom: 1px solid #eee;
            transition: background 0.2s ease;
        }
        
        .results-table tbody tr:hover {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        }
        
        .daily-stats {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-radius: 20px;
            padding: 2rem;
            margin-top: 2rem;
        }
        
        .daily-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: white;
            border-radius: 12px;
            margin-bottom: 1rem;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .recommendations {
            background: linear-gradient(135deg, #fff3cd, #ffeaa7);
            border: 2px solid #ffc107;
            border-radius: 20px;
            padding: 2rem;
            margin-top: 2rem;
        }
        
        .recommendation-item {
            background: white;
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            border-right: 4px solid #ffc107;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 3rem;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 1rem 2rem;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }
        
        .btn-info {
            background: linear-gradient(135deg, #17a2b8, #138496);
            color: white;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .action-buttons {
                display: none;
            }
            
            .section {
                page-break-inside: avoid;
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .students-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .performance-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .results-table {
                overflow-x: auto;
            }
            
            .results-table table {
                min-width: 600px;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($error)): ?>
            <div class="section" style="text-align: center; color: #dc3545;">
                <h2>خطا</h2>
                <p><?php echo htmlspecialchars($error); ?></p>
                <a href="index.php?section=admin&tab=games" class="btn btn-primary">بازگشت</a>
            </div>
        <?php else: ?>
            
            <div class="header">
                <div class="header-content">
                    <div class="game-title"><?php echo htmlspecialchars($game['title']); ?></div>
                    <div class="game-subject"><?php echo $game['subject_icon']; ?> درس: <?php echo htmlspecialchars($game['subject_name']); ?></div>
                    <div class="report-date">گزارش تولید شده در: <?php echo date('Y/m/d H:i'); ?></div>
                </div>
            </div>
            
            <!-- آمار کلی -->
            <div class="section">
                <h3 class="section-title">
                    <span class="section-icon">📊</span>
                    آمار کلی عملکرد
                </h3>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo $totalPlays; ?></span>
                            <span class="stat-label">کل شرکت‌کنندگان</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo number_format($avgScore, 1); ?></span>
                            <span class="stat-label">میانگین امتیاز</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo number_format($medianScore, 1); ?></span>
                            <span class="stat-label">میانه امتیاز</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo $highestScore; ?></span>
                            <span class="stat-label">بالاترین امتیاز</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo $lowestScore; ?></span>
                            <span class="stat-label">پایین‌ترین امتیاز</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo gmdate("i:s", $avgTime); ?></span>
                            <span class="stat-label">میانگین زمان</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-content">
                            <span class="stat-number"><?php echo number_format($avgAccuracy, 1); ?>%</span>
                            <span class="stat-label">میانگین دقت</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- تحلیل سطح عملکرد -->
            <div class="section">
                <h3 class="section-title">
                    <span class="section-icon">📈</span>
                    تحلیل سطح عملکرد دانش‌آموزان
                </h3>
                <div class="performance-grid">
                    <div class="performance-card performance-excellent">
                        <span class="performance-number"><?php echo $excellentCount; ?></span>
                        <div>عالی (80-100)</div>
                        <div style="font-size: 0.9rem; opacity: 0.9;">
                            <?php echo $totalPlays > 0 ? round(($excellentCount / $totalPlays) * 100, 1) : 0; ?>%
                        </div>
                    </div>
                    <div class="performance-card performance-good">
                        <span class="performance-number"><?php echo $goodCount; ?></span>
                        <div>خوب (60-79)</div>
                        <div style="font-size: 0.9rem; opacity: 0.9;">
                            <?php echo $totalPlays > 0 ? round(($goodCount / $totalPlays) * 100, 1) : 0; ?>%
                        </div>
                    </div>
                    <div class="performance-card performance-average">
                        <span class="performance-number"><?php echo $averageCount; ?></span>
                        <div>متوسط (40-59)</div>
                        <div style="font-size: 0.9rem; opacity: 0.9;">
                            <?php echo $totalPlays > 0 ? round(($averageCount / $totalPlays) * 100, 1) : 0; ?>%
                        </div>
                    </div>
                    <div class="performance-card performance-weak">
                        <span class="performance-number"><?php echo $weakCount; ?></span>
                        <div>نیاز به تقویت (0-39)</div>
                        <div style="font-size: 0.9rem; opacity: 0.9;">
                            <?php echo $totalPlays > 0 ? round(($weakCount / $totalPlays) * 100, 1) : 0; ?>%
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if ($totalPlays > 0): ?>
            <!-- دانش‌آموزان برتر و ضعیف -->
            <div class="section">
                <h3 class="section-title">
                    <span class="section-icon">👥</span>
                    تحلیل عملکرد دانش‌آموزان
                </h3>
                <div class="students-grid">
                    <div class="students-section top-students">
                        <h4 style="color: #28a745; margin-bottom: 1rem; font-size: 1.3rem; font-weight: 800;">🏆 دانش‌آموزان برتر</h4>
                        <?php foreach($topPerformers as $index => $student): ?>
                        <div class="student-item">
                            <?php if ($index < 3): ?>
                                <div class="rank-badge rank-<?php echo $index + 1; ?>">
                                    <?php echo $index == 0 ? '🥇' : ($index == 1 ? '🥈' : '🥉'); ?>
                                </div>
                            <?php endif; ?>
                            <div class="student-info">
                                <span class="student-name"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></span>
                                <span class="student-details">
                                    زمان: <?php echo gmdate("i:s", $student['time_spent']); ?> | 
                                    دقت: <?php echo $student['accuracy']; ?>%
                                    <?php if ($student['class_rank']): ?>
                                    | رتبه کلی: <?php echo $student['class_rank']; ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="student-score score-excellent"><?php echo $student['score']; ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="students-section weak-students">
                        <h4 style="color: #dc3545; margin-bottom: 1rem; font-size: 1.3rem; font-weight: 800;">⚠️ دانش‌آموزان نیازمند تقویت</h4>
                        <?php foreach($weakPerformers as $student): ?>
                        <div class="student-item">
                            <div class="student-info">
                                <span class="student-name"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></span>
                                <span class="student-details">
                                    زمان: <?php echo gmdate("i:s", $student['time_spent']); ?> | 
                                    دقت: <?php echo $student['accuracy']; ?>%
                                    <?php if ($student['class_rank']): ?>
                                    | رتبه کلی: <?php echo $student['class_rank']; ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="student-score <?php 
                                echo $student['score'] >= 60 ? 'score-good' : 
                                    ($student['score'] >= 40 ? 'score-average' : 'score-weak'); 
                            ?>"><?php echo $student['score']; ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <!-- آمار روزانه -->
            <?php if (!empty($dailyStats)): ?>
            <div class="section">
                <h3 class="section-title">
                    <span class="section-icon">📅</span>
                    آمار هفت روز اخیر
                </h3>
                <div class="daily-stats">
                    <?php foreach($dailyStats as $daily): ?>
                    <div class="daily-item">
                        <div>
                            <strong><?php echo date('Y/m/d', strtotime($daily['play_date'])); ?></strong>
                            <br>
                            <small style="color: #666;"><?php echo date('l', strtotime($daily['play_date'])); ?></small>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: 800; color: #667eea;">
                                <?php echo $daily['daily_plays']; ?>
                            </div>
                            <small>بازی</small>
                        </div>
                        <div style="text-align: left;">
                            <div style="font-size: 1.2rem; font-weight: 700; color: #28a745;">
                                <?php echo number_format($daily['daily_avg_score'], 1); ?>
                            </div>
                            <small>میانگین امتیاز</small>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- پیشنهادات آموزشی -->
            <div class="recommendations">
                <h3 class="section-title">
                    <span class="section-icon">💡</span>
                    پیشنهادات آموزشی
                </h3>
                
                <?php if ($weakCount > 0): ?>
                <div class="recommendation-item">
                    <strong>تقویت دانش‌آموزان ضعیف:</strong>
                    <?php echo $weakCount; ?> دانش‌آموز نیاز به تمرین بیشتر دارند. پیشنهاد می‌شود تمرین‌های تکمیلی و جلسات تقویتی برای آنها در نظر بگیرید.
                </div>
                <?php endif; ?>
                
                <?php if ($avgAccuracy < 70): ?>
                <div class="recommendation-item">
                    <strong>بهبود دقت عملکرد:</strong>
                    میانگین دقت (<?php echo number_format($avgAccuracy, 1); ?>%) پایین است. توضیح بیشتر مفاهیم و تمرین دقت‌محور توصیه می‌شود.
                </div>
                <?php endif; ?>
                
                <?php if ($avgTime > $game['estimated_time'] * 60): ?>
                <div class="recommendation-item">
                    <strong>مدیریت زمان:</strong>
                    میانگین زمان بازی از حد انتظار بیشتر است. تمرین سرعت حل مسئله می‌تواند مفید باشد.
                </div>
                <?php endif; ?>
                <?php if ($excellentCount > $totalPlays * 0.7): ?>
                <div class="recommendation-item">
                    <strong>تحدی بیشتر:</strong>
                    <?php echo number_format(($excellentCount / $totalPlays) * 100, 1); ?>% دانش‌آموزان عملکرد عالی دارند. می‌توانید سطح سختی بازی را افزایش دهید.
                </div>
                <?php endif; ?>
                
                <div class="recommendation-item">
                    <strong>ادامه روند مثبت:</strong>
                    برای حفظ انگیزه، از دانش‌آموزان برتر تقدیر کرده و نتایج را با آنها به اشتراک بگذارید.
                </div>
            </div>
            
            <!-- جدول کامل نتایج -->
            <div class="section">
                <h3 class="section-title">
                    <span class="section-icon">📋</span>
                    جدول کامل نتایج
                </h3>
                <div class="results-table">
                    <table>
                        <thead>
                            <tr>
                                <th>رتبه</th>
                                <th>نام دانش‌آموز</th>
                                <th>امتیاز</th>
                                <th>زمان</th>
                                <th>دقت</th>
                                <th>وضعیت عملکرد</th>
                                <th>رتبه کلاسی</th>
                                <th>تاریخ بازی</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $rank = 1;
                            foreach($results as $result): 
                                $performanceStatus = '';
                                $performanceClass = '';
                                if ($result['score'] >= 80) {
                                    $performanceStatus = 'عالی';
                                    $performanceClass = 'score-excellent';
                                } elseif ($result['score'] >= 60) {
                                    $performanceStatus = 'خوب';
                                    $performanceClass = 'score-good';
                                } elseif ($result['score'] >= 40) {
                                    $performanceStatus = 'متوسط';
                                    $performanceClass = 'score-average';
                                } else {
                                    $performanceStatus = 'نیاز به تقویت';
                                    $performanceClass = 'score-weak';
                                }
                            ?>
                            <tr>
                                <td style="font-weight: 800; font-size: 1.1rem;">
                                    <?php 
                                    if ($rank == 1) echo '🥇 ' . $rank;
                                    elseif ($rank == 2) echo '🥈 ' . $rank;
                                    elseif ($rank == 3) echo '🥉 ' . $rank;
                                    else echo $rank;
                                    ?>
                                </td>
                                <td style="font-weight: 600;">
                                    <?php echo htmlspecialchars($result['first_name'] . ' ' . $result['last_name']); ?>
                                    <br>
                                    <small style="color: #666;">کد ملی: <?php echo htmlspecialchars($result['national_id']); ?></small>
                                </td>
                                <td>
                                    <span class="student-score <?php echo $performanceClass; ?>" style="display: inline-block; padding: 0.3rem 0.8rem; border-radius: 8px; font-size: 1.1rem;">
                                        <?php echo $result['score']; ?>
                                    </span>
                                </td>
                                <td style="font-weight: 600;"><?php echo gmdate("i:s", $result['time_spent']); ?></td>
                                <td style="font-weight: 600;"><?php echo $result['accuracy']; ?>%</td>
                                <td>
                                    <span style="padding: 0.3rem 0.8rem; border-radius: 15px; font-size: 0.9rem; font-weight: 600; color: white;" class="<?php echo $performanceClass; ?>">
                                        <?php echo $performanceStatus; ?>
                                    </span>
                                </td>
                                <td style="text-align: center; font-weight: 600;">
                                    <?php echo $result['class_rank'] ? $result['class_rank'] : '-'; ?>
                                </td>
                                <td style="font-size: 0.9rem;">
                                    <?php echo date('Y/m/d', strtotime($result['completed_at'])); ?>
                                    <br>
                                    <small style="color: #666;"><?php echo date('H:i', strtotime($result['completed_at'])); ?></small>
                                </td>
                            </tr>
                            <?php 
                            $rank++;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
            <div class="section" style="text-align: center; padding: 4rem;">
                <div style="font-size: 4rem; margin-bottom: 1rem;">🎮</div>
                <h3 style="color: #666; margin-bottom: 2rem;">هنوز کسی این بازی را انجام نداده است</h3>
                <p style="color: #888; font-size: 1.1rem;">پس از شرکت دانش‌آموزان در بازی، گزارش تحلیلی کاملی در اینجا نمایش داده خواهد شد.</p>
            </div>
            <?php endif; ?>
            
        <?php endif; ?>
        
        <!-- دکمه‌های عملیات -->
        <div class="action-buttons">
            <a href="index.php?section=admin" class="btn btn-primary">
                <span>🏠</span>
                بازگشت به پنل ادمین
            </a>
            
            <?php if ($totalPlays > 0): ?>
            <button onclick="window.print()" class="btn btn-success">
                <span>🖨️</span>
                چاپ گزارش
            </button>
            
            <button onclick="exportToExcel()" class="btn btn-info">
                <span>📊</span>
                خروجی اکسل
            </button>
            
            <button onclick="shareReport()" class="btn" style="background: linear-gradient(135deg, #ff6b6b, #ffd93d);">
                <span>📤</span>
                اشتراک گذاری
            </button>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // تابع خروجی اکسل
        function exportToExcel() {
            const gameTitle = "<?php echo addslashes($game['title']); ?>";
            const data = [
                ['گزارش تحلیلی بازی: ' + gameTitle],
                ['تاریخ تولید گزارش: ' + new Date().toLocaleDateString('fa-IR')],
                [''],
                ['رتبه', 'نام دانش‌آموز', 'امتیاز', 'زمان', 'دقت', 'وضعیت عملکرد', 'رتبه کلاسی', 'تاریخ بازی']
            ];
            
            <?php if ($totalPlays > 0): ?>
            const results = <?php echo json_encode($results); ?>;
            results.forEach((result, index) => {
                let performanceStatus = '';
                if (result.score >= 80) performanceStatus = 'عالی';
                else if (result.score >= 60) performanceStatus = 'خوب';
                else if (result.score >= 40) performanceStatus = 'متوسط';
                else performanceStatus = 'نیاز به تقویت';
                
                data.push([
                    index + 1,
                    result.first_name + ' ' + result.last_name,
                    result.score,
                    Math.floor(result.time_spent / 60) + ':' + (result.time_spent % 60).toString().padStart(2, '0'),
                    result.accuracy + '%',
                    performanceStatus,
                    result.class_rank || '-',
                    new Date(result.completed_at).toLocaleDateString('fa-IR')
                ]);
            });
            <?php endif; ?>
            
            // ایجاد فایل CSV
            let csvContent = data.map(row => row.join(',')).join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'game_results_' + gameTitle + '_' + new Date().toISOString().split('T')[0] + '.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        
        // تابع اشتراک گذاری
        function shareReport() {
            if (navigator.share) {
                navigator.share({
                    title: 'گزارش تحلیلی بازی: <?php echo addslashes($game["title"]); ?>',
                    text: 'گزارش عملکرد دانش‌آموزان در بازی آموزشی',
                    url: window.location.href
                }).catch(console.error);
            } else {
                // کپی لینک
                navigator.clipboard.writeText(window.location.href).then(() => {
                    alert('لینک گزارش کپی شد');
                });
            }
        }
        
        // انیمیشن بارگذاری
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card, .student-item, .daily-item');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>
                
