<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

echo "<h3>بررسی کاربران سیستم</h3>";

// بررسی کاربران موجود
try {
    $stmt = $conn->prepare("SELECT id, username, first_name, last_name, user_type, is_active FROM users ORDER BY id");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($users) {
        echo "<h4>کاربران موجود:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>نام کاربری</th><th>نام</th><th>نوع</th><th>فعال</th></tr>";
        foreach ($users as $user) {
            $style = $user['user_type'] === 'student' ? 'background: #e8f5e8;' : '';
            echo "<tr style='$style'>";
            echo "<td>{$user['id']}</td>";
            echo "<td>{$user['username']}</td>";
            echo "<td>{$user['first_name']} {$user['last_name']}</td>";
            echo "<td>{$user['user_type']}</td>";
            echo "<td>" . ($user['is_active'] ? 'فعال' : 'غیرفعال') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // پیدا کردن اولین دانش‌آموز فعال
        $first_student = null;
        foreach ($users as $user) {
            if ($user['user_type'] === 'student' && $user['is_active']) {
                $first_student = $user;
                break;
            }
        }
        
        if ($first_student) {
            echo "<p style='color: green;'>✅ اولین دانش‌آموز فعال: {$first_student['first_name']} {$first_student['last_name']} (ID: {$first_student['id']})</p>";
            echo "<p><strong>برای تست از ID {$first_student['id']} استفاده کنید</strong></p>";
        } else {
            echo "<p style='color: red;'>❌ هیچ دانش‌آموز فعالی یافت نشد</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ هیچ کاربری یافت نشد</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>خطا: " . $e->getMessage() . "</p>";
}

// بررسی session فعلی
echo "<h4>اطلاعات Session فعلی:</h4>";
echo "<pre>";
print_r([
    'user_id' => $_SESSION['user_id'] ?? 'تعریف نشده',
    'user_type' => $_SESSION['user_type'] ?? 'تعریف نشده',
    'username' => $_SESSION['username'] ?? 'تعریف نشده'
]);
echo "</pre>";
?>